/** Interview content types — INSTRUCTIONS.md §6. */

/**
 * The systemBlueprint's escalation axis (INSTRUCTIONS.md §4.3 Stage-6
 * addition) — `@mia/interview-domain` owns the authoritative tier/concept
 * data (`extractionMatrix`); this is the wire-shape mirror every agent and
 * store passes around, kept here rather than imported so `shared-types` stays
 * free of a dependency on the package that depends on it.
 */
export type Tier = 1 | 2 | 3;

export interface TierSpec {
  tier: Tier;
  targetConceptIds: string[];
  /** Null for tier 3 — nothing above "advanced" to escalate into. */
  escalationTriggerCondition: string | null;
}

export interface EvaluationTopicBlueprint {
  topicId: string;
  dynamicFraming: {
    /** The rule for picking a resume anchor — a template, not a resolved value (see below). */
    resumeContextIntegrationRule: string;
    /** The rule for anchoring to what the JD asked for at this topic — a template, not a resolved value. */
    jdAnchorRequirement: string;
  };
  extractionMatrix: {
    tier_1_baseline: TierSpec;
    tier_2_intermediate: TierSpec;
    tier_3_advanced: TierSpec;
  };
}

/** A role's static evaluation plan. Built once per role, not per session — see `buildSystemBlueprint`. */
export interface SystemBlueprint {
  roleProfileId: string;
  domainFocus: string;
  evaluationTopics: EvaluationTopicBlueprint[];
}

/**
 * What the Follow-up Question Agent decides after scoring an answer and
 * checking it against the current tier's target concepts (§4.4 Stage-6
 * addition). Replaces a bare `should_follow_up: boolean` with the actual
 * decision space:
 *  - `drill_down` — a specific gap was found; probe it (the Stage-5 behavior).
 *  - `escalate`   — the tier's concepts are covered; the topic's next
 *                    question should move up a tier.
 *  - `pivot`      — nothing to probe and nothing to escalate into (tier 3,
 *                    or coverage too thin to justify moving up); move on.
 *  - `conclude`   — the Harness Agent's own signal that the session is
 *                    ending, never returned by the Follow-up Agent itself,
 *                    which has no view of the overall question budget.
 */
export type NextActionDirective = "escalate" | "pivot" | "drill_down" | "conclude";

/** What the concept-verification pass found in one answer's transcript. */
export interface ExtractionProcessorResult {
  /**
   * Present only on the ephemeral, same-request wire response — NEVER
   * persisted. `answer.transcript` is already this session's one durable copy
   * of the candidate's words; writing a second copy here would survive
   * `AnswerStore.redact()` (which only knows to blank `transcript` and
   * `followUps[].transcript`) and leak into the post-redaction archive
   * (soul.md §5, INSTRUCTIONS.md §11.4). `AnswerStore.recordExtraction` must
   * strip this field before writing.
   */
  transcribedInputChunk?: string;
  verifiedConceptIds: string[];
  unverifiedConceptIds: string[];
  /** The deterministic gap detector's full hit list, not just the one it probed (§4.4). */
  antiPatternsDetected: string[];
}

export interface NextActionGenerator {
  systemDirective: NextActionDirective;
  /** The concept the next question or follow-up should target, if any. */
  targetConceptIdForNextPrompt: string | null;
  /** Short instruction for the LLM call that phrases the next prompt — how to bridge anchor + concept. */
  synthesizedFramingStrategy: string;
  /** The follow-up text itself, mirrored here under the blueprint's name; null when the directive isn't drill_down. */
  generatedFollowUpPrompt: string | null;
}

export interface TopicRelevance {
  topic: string;
  /** 0-1, how strongly the resume supports this topic */
  relevanceScore: number;
  /** must trace back to specific resume text (soul.md §"No fabrication") */
  evidence: string;
}

export interface CandidateProfile {
  skills: string[];
  experience: { title: string; company: string; years: number }[];
  education: { degree: string; institution: string }[];
  seniorityEstimate: "junior" | "mid" | "senior" | "staff+";
  keywords: string[];
  topicRelevance: TopicRelevance[];
}

export interface Question {
  /** Unique per asking — the same bank question asked in two sessions is two rows. */
  id: string;
  /**
   * Identifier of the source question in the shared bank. This is what the
   * Memory Agent tracks to avoid repeats, within a session and (opt-in) across
   * sessions (§4.7).
   */
  bankId: string;
  sessionId: string;
  text: string;
  /** set by the Harness Agent via the Speech Service Tool before reaching the frontend */
  audioUrl?: string;
  topic: string;
  type: "behavioral" | "technical" | "coding";
  /** 1-5. Kept for report/UI continuity; derived from `tier` as `tier + 1` (§4.3 Stage-6 addition). */
  difficulty: number;
  /**
   * (Stage 6) This topic's escalation slot this question fills, and the
   * concept ids a strong answer should cover at that slot — the blueprint's
   * `extractionMatrix.tier_N.targetConceptIds` for this topic and tier.
   * Absent only for a question asked before this field existed.
   */
  tier?: Tier;
  targetConceptIds?: string[];
  /** true if this question exceeded its topic's maxQuestions as a last resort (§4.3) */
  quotaOverride?: boolean;
  /**
   * (Stage 5) Set only when this question's text was LLM-generated; absent for
   * a question-bank fallback pick (§11.5).
   *
   * NOTE: `referenceAnswer` is deliberately NOT a field here. It lives only in
   * the Memory Agent's session-scoped store (§4.7) and reaches the Follow-up
   * Question Agent by way of the harness — it must never round-trip through the
   * Question object the harness hands the frontend (soul.md §5).
   */
  promptVersion?: string;
  askedAt: string;
}

export interface FollowUp {
  text: string;
  transcript: string;
  /**
   * (Stage 5, §4.4/§11.2) The follow-up exchange's own score, written here
   * rather than as a second top-level `Evaluation`.
   *
   * A follow-up is a sub-unit of the answer it belongs to and is always read
   * together with it; more decisively, `Evaluation.evidenceSpans` already means
   * "indices into `answers.transcript`" for every existing reader of that
   * table, so reusing it for a follow-up's transcript would silently break that
   * assumption (§11.7). These spans index into THIS follow-up's transcript.
   */
  score?: {
    rubricId: string;
    value: number;
    rationale: string;
    evidenceSpans: { start: number; end: number }[];
  };
}

export interface Answer {
  id: string;
  questionId: string;
  /** from the Speech Service Tool's STT, or the typed fallback */
  transcript: string;
  transcriptConfidence?: number;
  submittedAt: string;
  followUps: FollowUp[];
  /**
   * (Stage 6) The Follow-up Question Agent's concept-verification pass and
   * resulting directive for this answer. Absent for an answer scored before
   * this field existed, or when the Follow-up Agent was constructed without a
   * tool client (§4.4).
   */
  extraction?: ExtractionProcessorResult;
  nextAction?: NextActionGenerator;
}

/** What `AnswerStore.redact` replaces a transcript with (INSTRUCTIONS.md §8). */
export const REDACTED_TRANSCRIPT = "[deleted — retention policy, INSTRUCTIONS.md §8]";

export interface Evaluation {
  id: string;
  answerId: string;
  /** versioned rubric owned by the Eval Tool, never by an agent */
  rubricId: string;
  score: number;
  rationale: string;
  evidenceSpans: { start: number; end: number }[];
  /**
   * (Stage 5, §6) Set when the score came from an LLM-backed call path — in
   * practice, when it was compared against a generated reference answer. Absent
   * means the score came from the rubric alone, which is still the case for
   * every coding-round and question-bank score.
   */
  promptVersion?: string;
  createdAt: string;
}

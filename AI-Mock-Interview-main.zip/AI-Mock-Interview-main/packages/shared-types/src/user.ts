/**
 * User + auth types. See INSTRUCTIONS.md §6 and §8.
 *
 * A passcode is NEVER represented in these types as plaintext. The only
 * on-disk representation is `PasscodeHash`, produced by the gateway's
 * auth module.
 */

export type Role = "admin" | "student";

export interface User {
  id: string;
  email: string;
  role: Role;
  /** Salted hash of the passcode — see INSTRUCTIONS.md §8. Never plaintext. */
  passcodeHash: string;
  /** Account-level opt-in for the Memory Agent's cross-session recall (soul.md §5). */
  crossSessionMemoryOptIn: boolean;
  /**
   * (Stage 5, §6/§11.4) Profile fields the session archive is keyed on.
   * Optional here because accounts predate them, but `fullName` is a HARD
   * requirement at archive time — archiving refuses rather than writing an
   * archive with blanks where a candidate's name should be.
   */
  fullName?: string;
  department?: string;
  /** String, not int: covers "3rd Year", "Alumni", "Grad" (§6). */
  programYear?: string;
  createdAt: string;
}

/** What a caller sees once authenticated. Deliberately has no hash field. */
export interface PublicUser {
  id: string;
  email: string;
  role: Role;
  crossSessionMemoryOptIn: boolean;
  fullName?: string;
  department?: string;
  programYear?: string;
}

/** (Stage 5) The profile fields a candidate can set on themselves (§11.4). */
export interface UserProfile {
  fullName?: string;
  department?: string;
  programYear?: string;
}

/** Decoded contents of the role-scoped token issued by POST /auth/login. */
export interface AuthTokenClaims {
  sub: string;
  email: string;
  role: Role;
  /** issued-at, epoch seconds */
  iat: number;
  /** expiry, epoch seconds */
  exp: number;
}

/**
 * Short-lived, single-use passcode reset token (INSTRUCTIONS.md §8).
 * Stored hashed so a database read cannot be replayed as a credential.
 */
export interface PasscodeResetToken {
  id: string;
  userId: string;
  tokenHash: string;
  expiresAt: string;
  usedAt: string | null;
}

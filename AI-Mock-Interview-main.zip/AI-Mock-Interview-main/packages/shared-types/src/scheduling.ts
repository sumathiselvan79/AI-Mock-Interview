/**
 * (Stage 7) Admin-scheduled interviews — `ADMIN_FEATURE_PROMPT.md` Part 3.
 *
 * A `ScheduledInterview` is **session-seed data and nothing more**. It is what
 * an Admin decided a candidate should practise; it is read once, by the
 * gateway, when that candidate starts the session it seeds. It introduces no
 * new agent-to-agent path (CLAUDE.md §5 golden rule) — no agent reads this
 * type, and the Harness Agent still receives an ordinary `Session`.
 *
 * What it deliberately does NOT carry is consent. `soul.md`
 * §"Consent-first monitoring" makes consent the candidate's to give, and an
 * Admin pre-answering it on their behalf is precisely what that rule forbids.
 * A schedule can say a coding round *will be offered*
 * (`codingRoundEnabled` — which is what makes the Coding Agent ask for
 * clipboard monitoring), and the invite says so plainly, but the Telemetry
 * Check page remains the only place any consent flag is ever set. There is no
 * `consentDefaults` field here on purpose; see `ADMIN_FEATURE_PROMPT.md`
 * §Reconciliation item 4.
 */

/**
 * Departments used for batch targeting and for the directory filter.
 *
 * `User.department` is a free-text column (added in migration 003, Stage 5)
 * and stays that way — this list is the set the admin UI offers, not a
 * constraint on what a candidate may have typed about themselves. A directory
 * row whose department is outside this list still renders and still filters.
 */
export const DEPARTMENTS = [
  "Engineering",
  "Sales",
  "Design",
  "Product",
  "Data",
  "Other",
] as const;
export type Department = (typeof DEPARTMENTS)[number];

export const INTERVIEW_TYPES = [
  "behavioral",
  "technical",
  "behavioral+technical",
  "coding",
  "full",
] as const;
export type InterviewType = (typeof INTERVIEW_TYPES)[number];

/**
 * Seniority the interview is pitched at. Distinct from the per-question
 * `difficulty: 1-5` and from Stage 6's per-topic `tier` — this is the level the
 * whole session is aimed at, which the Question Agent already derives from
 * `role`. It is carried so the invite can say what the candidate is walking
 * into, and so the seeded session's role string can reflect it.
 */
export const SCHEDULE_DIFFICULTIES = ["junior", "mid", "senior", "staff+"] as const;
export type ScheduleDifficulty = (typeof SCHEDULE_DIFFICULTIES)[number];

export const RECURRENCES = ["none", "weekly", "biweekly", "monthly"] as const;
export type Recurrence = (typeof RECURRENCES)[number];

/**
 * Delivery channels.
 *
 * `in_app` is the only one that actually delivers today — it is the student's
 * home page reading `GET /me/scheduled-interviews`. `email` is recorded as
 * intent: this repo has no mail service beyond `MemoryResetMailer`, which is
 * dev/test-only, and inventing one was out of scope. Anything scheduled with
 * `email` still reaches the candidate in-app; see the TODO in
 * `ADMIN_FEATURE_PROMPT.md` §Reconciliation item 3.
 */
export const NOTIFY_CHANNELS = ["in_app", "email"] as const;
export type NotifyChannel = (typeof NOTIFY_CHANNELS)[number];

/**
 * Lifecycle.
 *
 * `pending` -> `sent` is the scheduling window opening (`scheduledFor` passing);
 * `started` is set when the candidate creates the session it seeds;
 * `completed` when that session reaches COMPLETED; `missed` when `deadline`
 * passes with no session started; `cancelled` is the Admin withdrawing it.
 *
 * `missed` and `sent` are DERIVED from the clock rather than written by a
 * background job — there is no scheduler process in this repo, and a status
 * that silently disagreed with the wall clock would be worse than one computed
 * on read. See `effectiveStatus`.
 */
export const SCHEDULE_STATUSES = [
  "pending",
  "sent",
  "started",
  "completed",
  "missed",
  "cancelled",
] as const;
export type ScheduleStatus = (typeof SCHEDULE_STATUSES)[number];

/** One assignment: one candidate, one interview. A batch creates one row each. */
export interface ScheduledInterview {
  id: string;
  /** The student this is assigned to. */
  candidateId: string;
  /**
   * Snapshot of the candidate's department at scheduling time, so a batch
   * scheduled "for Engineering" still reads correctly after someone edits
   * their profile. Null when the candidate had none.
   */
  department: string | null;
  role: string;
  jobDescription: string;
  interviewType: InterviewType;
  difficulty: ScheduleDifficulty;
  durationMinutes: number;
  /** ISO 8601, timezone-aware (stored UTC). When the window opens. */
  scheduledFor: string;
  /** ISO 8601. After this with no session started, the assignment is `missed`. */
  deadline: string | null;
  recurring: Recurrence;
  codingRoundEnabled: boolean;
  /** Admin-only. Never serialized onto any student-facing response. */
  notes: string | null;
  notifyVia: NotifyChannel[];
  /**
   * Stored status. Only ever one of `pending`, `started`, `completed`,
   * `cancelled` — the clock-derived `sent`/`missed` are computed by
   * `effectiveStatus` and never written.
   */
  status: ScheduleStatus;
  /** Set once the candidate starts the session this seeded. */
  sessionId: string | null;
  /** Admin `User.id`. Audit trail. */
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

/** What an Admin supplies to create one. A batch repeats this per candidate. */
export interface ScheduledInterviewDraft {
  candidateIds: string[];
  role: string;
  jobDescription?: string;
  interviewType: InterviewType;
  difficulty: ScheduleDifficulty;
  durationMinutes: number;
  scheduledFor: string;
  deadline?: string | null;
  recurring?: Recurrence;
  codingRoundEnabled?: boolean;
  notes?: string | null;
  notifyVia?: NotifyChannel[];
}

export const DEFAULT_SCHEDULE_DURATION_MINUTES = 45;
export const MIN_SCHEDULE_DURATION_MINUTES = 10;
export const MAX_SCHEDULE_DURATION_MINUTES = 180;

/**
 * The status a reader should act on, given the clock.
 *
 * Derived rather than stored because nothing in this repo runs on a timer: a
 * stored `sent` would be a lie until some job flipped it, and a stored `missed`
 * would be a lie the moment a deadline passed. Terminal and
 * candidate-driven states always win over the clock — a cancelled assignment
 * never becomes `missed`, and one already `started` never does either.
 */
export function effectiveStatus(
  schedule: Pick<ScheduledInterview, "status" | "scheduledFor" | "deadline">,
  now: Date = new Date(),
): ScheduleStatus {
  if (
    schedule.status === "cancelled" ||
    schedule.status === "completed" ||
    schedule.status === "started"
  ) {
    return schedule.status;
  }
  if (schedule.deadline && new Date(schedule.deadline).getTime() <= now.getTime()) {
    return "missed";
  }
  if (new Date(schedule.scheduledFor).getTime() <= now.getTime()) return "sent";
  return "pending";
}

/**
 * Whether the candidate may start this assignment right now: the window has
 * opened, the deadline has not passed, and nobody has started or withdrawn it.
 */
export function isStartable(
  schedule: Pick<ScheduledInterview, "status" | "scheduledFor" | "deadline">,
  now: Date = new Date(),
): boolean {
  return effectiveStatus(schedule, now) === "sent";
}

/** Does this assignment run a coding round? `interviewType` and the flag must agree. */
export function runsCodingRound(
  schedule: Pick<ScheduledInterview, "interviewType" | "codingRoundEnabled">,
): boolean {
  return (
    schedule.codingRoundEnabled ||
    schedule.interviewType === "coding" ||
    schedule.interviewType === "full"
  );
}

// ---------------------------------------------------------------- directory

/**
 * One row of the Admin user directory.
 *
 * Every field here is either the candidate's own account metadata or an
 * aggregate over their `Report` records — the same boundary `GET /admin/reports`
 * already sits behind (soul.md §"Admin role"). There is deliberately no field
 * for a resume ref, an audio ref, or a transcript, so this shape cannot carry
 * one even by mistake.
 */
export interface DirectoryRow {
  userId: string;
  email: string;
  fullName: string | null;
  department: string | null;
  /** From `oauth_profiles` when the candidate signed in with Google. */
  avatarUrl: string | null;
  interviewsCompleted: number;
  /** Mean of each report's mean competency score, 0-5. Null with no reports. */
  averageScore: number | null;
  lastInterviewAt: string | null;
  createdAt: string;
  status: DirectoryStatus;
}

/**
 * `interview scheduled` outranks `active`: it is the state an Admin is most
 * likely to be looking for, and a candidate can be both.
 */
export const DIRECTORY_STATUSES = ["active", "interview_scheduled", "no_activity"] as const;
export type DirectoryStatus = (typeof DIRECTORY_STATUSES)[number];

export const DIRECTORY_SORT_KEYS = [
  "fullName",
  "email",
  "department",
  "interviewsCompleted",
  "averageScore",
  "lastInterviewAt",
  "createdAt",
] as const;
export type DirectorySortKey = (typeof DIRECTORY_SORT_KEYS)[number];

export interface DirectoryQuery {
  search?: string;
  department?: string;
  status?: DirectoryStatus;
  minScore?: number;
  maxScore?: number;
  /** Filters on `lastInterviewAt`. */
  from?: string;
  to?: string;
  sort?: DirectorySortKey;
  direction?: "asc" | "desc";
  page?: number;
  pageSize?: number;
}

export const DEFAULT_DIRECTORY_PAGE_SIZE = 25;
export const MAX_DIRECTORY_PAGE_SIZE = 100;

export interface DirectoryPage {
  rows: DirectoryRow[];
  total: number;
  page: number;
  pageSize: number;
}

/** One session on the profile drill-down's history list. */
export interface CandidateSessionSummary {
  sessionId: string;
  role: string;
  state: string;
  /** `completed` | `abandoned` | `in_progress`, derived from `Session.state`. */
  status: SessionHistoryStatus;
  startedAt: string;
  /** Wall-clock from session creation to its last update. Null while running. */
  durationMinutes: number | null;
  /** Mean competency score for the session's report, 0-5. Null without one. */
  overallScore: number | null;
  hasReport: boolean;
}

export const SESSION_HISTORY_STATUSES = ["completed", "abandoned", "in_progress"] as const;
export type SessionHistoryStatus = (typeof SESSION_HISTORY_STATUSES)[number];

/**
 * The profile drill-down payload.
 *
 * `scoreTrend` is each report's mean score oldest-first — the sparkline's data,
 * computed here so the page does not fetch every report to draw one line.
 */
export interface CandidateProfileView {
  userId: string;
  email: string;
  fullName: string | null;
  department: string | null;
  programYear: string | null;
  avatarUrl: string | null;
  createdAt: string;
  interviewsCompleted: number;
  averageScore: number | null;
  lastInterviewAt: string | null;
  scoreTrend: { at: string; score: number }[];
  sessions: CandidateSessionSummary[];
}

/** Mean of a report's competency scores, 0-5. Null when it scored nothing. */
export function meanCompetencyScore(scores: readonly { score: number }[]): number | null {
  if (scores.length === 0) return null;
  return scores.reduce((sum, s) => sum + s.score, 0) / scores.length;
}

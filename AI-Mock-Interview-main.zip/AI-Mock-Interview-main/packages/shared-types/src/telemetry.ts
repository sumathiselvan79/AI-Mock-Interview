/**
 * Telemetry event types — INSTRUCTIONS.md §5.4, §8.
 *
 * Payloads carry event types, IDs and timings ONLY. Never resume text, answer
 * transcripts, raw audio, or clipboard content. The `TelemetryPayload` type is
 * deliberately narrow so a violation is a type error, and the Telemetry Service
 * additionally strips unknown keys at runtime.
 */

export const TELEMETRY_EVENT_TYPES = [
  // emitted automatically by the MCP Gateway for every MCP call
  "tool_called",
  "agent_called",
  // domain events, emitted explicitly by the owning agent
  "session_created",
  "session_state_changed",
  "question_asked",
  "follow_up_triggered",
  "segment_expired",
  "device_check_passed",
  "device_check_failed",
  "quota_override_used",
  // Stage 3. `paste_detected` carries a session id and a timestamp and nothing
  // else — the pasted content has no field to travel in (soul.md §5).
  "transcription_low_confidence",
  "paste_detected",
  "coding_round_started",
  "code_submitted",
  "auth_login_succeeded",
  "auth_login_failed",
  "rate_limit_exceeded",
  // Stage 5. `archive_downloaded` is required, not optional: Admin access to a
  // consolidated cross-table document is exactly the kind of elevated access
  // that must be logged, not merely permitted (soul.md §5, §8).
  "session_archived",
  "session_archive_failed",
  "archive_viewed",
  "archive_downloaded",
  // Fullscreen-exit tracking, same shape/reasoning as `paste_detected` above —
  // a session id, a timestamp, and the running count. Nothing about what the
  // candidate did outside the window (soul.md §5).
  "focus_lost",
  "interview_concluded_early",
  // Stage 7 (admin directory + scheduling). `admin_reports_downloaded` is
  // audited for the same reason `archive_downloaded` is: bulk export of a
  // candidate's assessments is elevated access, so being permitted is not
  // enough — it has to be recorded (soul.md §5, §8). The scheduling events
  // carry ids and counts; `notes` is admin-internal free text and has no field
  // to travel in.
  "admin_reports_downloaded",
  "interviews_scheduled",
  "scheduled_interview_cancelled",
  "scheduled_interview_started",
] as const;

export type TelemetryEventType = (typeof TELEMETRY_EVENT_TYPES)[number];

/** Scalar-only payload. IDs, counts, durations, statuses — nothing free-form. */
export type TelemetryValue = string | number | boolean | null;

export interface TelemetryPayload {
  [key: string]: TelemetryValue;
}

export interface TelemetryEvent {
  id: string;
  eventType: TelemetryEventType;
  sessionId: string | null;
  payload: TelemetryPayload;
  emittedAt: string;
}

/**
 * Payload keys that must never appear in telemetry. Enforced at runtime by the
 * Telemetry Service, which drops the key and records `redacted_keys` instead.
 */
export const FORBIDDEN_TELEMETRY_KEYS = [
  "resume",
  "resume_text",
  "resumeText",
  "transcript",
  "answer",
  "answer_transcript",
  "answerTranscript",
  "audio",
  "audio_blob",
  "clipboard",
  "clipboard_content",
  "clipboardContent",
  "passcode",
  "passcode_hash",
  "passcodeHash",
  "token",
  "job_description",
  "jobDescription",
] as const;

/** The auto-emitted span for every MCP call through the gateway (§2, §9). */
export interface ToolCalledPayload extends TelemetryPayload {
  server: string;
  method: string;
  status: "ok" | "error";
  latency_ms: number;
  error_code: string | null;
}

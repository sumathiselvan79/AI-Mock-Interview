/**
 * Shapes for traffic crossing the MCP Gateway (CLAUDE.md §5, INSTRUCTIONS.md §2).
 *
 * The gateway is the single choke point for auth, per-session rate limiting and
 * the auto-emitted `tool_called` span, so every call carries a session-scoped
 * context rather than an ambient one.
 */

/** Registered MCP server names. One name = one deployable service. */
export const MCP_AGENT_SERVERS = [
  "resume-service-agent",
  "question-agent",
  "followup-agent",
  "coding-agent",
  "time-tracking-agent",
  "memory-agent",
  "report-agent",
] as const;

export const MCP_TOOL_SERVERS = [
  "tool-resume-parser",
  "tool-eval",
  "tool-time-tracking",
  "tool-telemetry",
  "tool-clipboard-monitor",
  "tool-speech-service",
  // (Stage 5) The provider-agnostic seam for every LLM-backed generation call
  // (INSTRUCTIONS.md §5.7). A tool rather than an agent: it holds routing and
  // config, never prompts or interviewing judgement.
  "tool-llm-provider",
] as const;

export type McpAgentServer = (typeof MCP_AGENT_SERVERS)[number];
export type McpToolServer = (typeof MCP_TOOL_SERVERS)[number];
export type McpServerName = McpAgentServer | McpToolServer;

/** Per-call context the gateway requires; used for auth, rate limiting and telemetry. */
export interface McpCallContext {
  sessionId: string;
  /** who is making the call — an agent name, or "harness-agent" */
  caller: string;
  /** the session-scoped token minted by the gateway when the session was created */
  sessionToken: string;
}

export interface McpCallResult<T = unknown> {
  ok: boolean;
  data?: T;
  error?: McpError;
  /** measured by the gateway, also written to the telemetry span */
  latencyMs: number;
}

export interface McpError {
  code: string;
  message: string;
}

export const MCP_ERROR_CODES = {
  UNAUTHORIZED: "unauthorized",
  RATE_LIMITED: "rate_limited",
  UNKNOWN_SERVER: "unknown_server",
  UNKNOWN_METHOD: "unknown_method",
  SCHEMA_INVALID_REQUEST: "schema_invalid_request",
  SCHEMA_INVALID_RESPONSE: "schema_invalid_response",
  NOT_IMPLEMENTED: "not_implemented",
  UPSTREAM_ERROR: "upstream_error",
} as const;

export type McpErrorCode = (typeof MCP_ERROR_CODES)[keyof typeof MCP_ERROR_CODES];

/**
 * The seam every MCP server is reached through.
 *
 * Stage 1 registers in-process handlers so the gateway's auth / rate-limit /
 * schema / telemetry path can be proven before any real agent exists. Later
 * stages swap the implementation for the official MCP SDK's transport — one
 * process per agent, per CLAUDE.md §8 — without touching the gateway or any
 * caller, because this interface is the contract, not the transport.
 */
export interface McpServerHandler {
  readonly name: string;
  call(method: string, params: unknown, ctx: McpCallContext): Promise<unknown>;
}

/**
 * How an agent reaches a tool. The gateway binds the session context and the
 * caller's identity when it builds one of these, so an agent cannot spoof
 * either — and every call it makes is authenticated, rate limited, schema
 * checked and instrumented without the agent doing anything (§2).
 */
export interface ToolClient {
  call<T = unknown>(server: string, method: string, params: unknown): Promise<T>;
}

export type ToolClientFactory = (sessionId: string, caller: string) => ToolClient;

/** Thrown by a server to return a typed MCP error rather than an opaque crash. */
export class McpHandlerError extends Error {
  constructor(
    readonly code: string,
    message: string,
  ) {
    super(message);
    this.name = "McpHandlerError";
  }
}

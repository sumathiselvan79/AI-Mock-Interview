/**
 * Google OAuth profile snapshot — INSTRUCTIONS.md §11.4/§11.6 established the
 * Supabase-hosted Postgres instance (`config.supabaseDbUrl`) as a server-only,
 * service-role-only database reached over `pg`, never `@supabase/supabase-js`
 * (archive.ts explains why). This reuses that same instance and access
 * pattern for a second, distinct table: a snapshot of the Google identity a
 * candidate signed in with, kept for Admin account review.
 *
 * It is a snapshot only, not a second source of truth for login: the primary
 * email/role bound to the auth token still resolve from `UserStore.upsertIdentity`
 * exactly as they did before this existed (auth/service.ts `identityLogin`).
 */
export interface OAuthProfile {
  userId: string;
  provider: "google";
  /** Google's `sub` claim — stable per Google account, unlike email. */
  providerSubject: string;
  email: string;
  name?: string;
  avatarUrl?: string;
  linkedAt: string;
}

export interface OAuthProfileStore {
  /** One row per (userId, provider) — a later sign-in updates the snapshot in place. */
  upsert(profile: OAuthProfile): Promise<OAuthProfile>;
  getByUserId(userId: string): Promise<OAuthProfile | null>;
  close(): Promise<void>;
}

/** Report types — INSTRUCTIONS.md §6, soul.md §3. */

import type { FocusEvent } from "./session.js";

export interface CompetencyScore {
  competency: string;
  score: number;
  /** never empty — a score the agent cannot evidence must not be emitted */
  evidence: string[];
}

/**
 * Fullscreen-exit activity for the session, folded into the report at
 * generation time (never fabricated — a direct copy of `Session.focusEvents`,
 * present only when `consent.focusLossMonitoring` was on). Distinct from
 * `Report.focusAreas` below, which is about interview TOPICS, not proctoring.
 */
export interface BrowserActivitySummary {
  exitCount: number;
  events: FocusEvent[];
  /** True when repeated exits ended the session early, rather than the candidate finishing normally. */
  concludedEarly: boolean;
}

export interface Report {
  sessionId: string;
  /** lets the Admin dashboard list/query reports across candidates */
  candidateId: string;
  competencyScores: CompetencyScore[];
  strengths: string[];
  focusAreas: string[];
  browserActivity: BrowserActivitySummary;
  /** required — see REPORT_DISCLAIMER */
  disclaimer: string;
  createdAt: string;
}

/**
 * Required on every report (soul.md §3, §5): the system never implies a
 * session outcome predicts a real hiring result.
 */
export const REPORT_DISCLAIMER =
  "This is interview practice, not a hiring prediction. Scores reflect only what you said in this session.";

/** Aggregate shown on the student Home page (GET /me/stats). */
export interface CandidateStats {
  candidateId: string;
  sessionsCompleted: number;
  averageScore: number | null;
  lastSessionAt: string | null;
  recurringFocusAreas: string[];
}

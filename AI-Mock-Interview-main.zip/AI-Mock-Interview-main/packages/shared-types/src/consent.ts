/**
 * Consent tokens — soul.md §"Consent-first monitoring", INSTRUCTIONS.md §5.5, §8.
 *
 * A consent token is a signed statement that *this* session's candidate agreed
 * to *this specific* kind of monitoring, at a known time. It exists so consent
 * is enforceable at the tool layer rather than only in the UI: the Clipboard
 * Monitor verifies a token before it starts, so a misconfigured agent — or
 * someone calling the API directly with the UI bypassed — cannot switch
 * monitoring on.
 *
 * Design notes worth keeping:
 *  - one token per scope, so agreeing to telemetry never implies agreeing to
 *    clipboard monitoring;
 *  - the token is bound to a session id, so it cannot be replayed against
 *    another candidate's session;
 *  - it carries no personal data at all, only ids, a scope and a timestamp.
 */

export const CONSENT_SCOPES = [
  "telemetry",
  "clipboard_monitor",
  "audio_recording",
  "cross_session_memory",
  "focus_monitoring",
] as const;

export type ConsentScope = (typeof CONSENT_SCOPES)[number];

export interface ConsentClaims {
  sessionId: string;
  scope: ConsentScope;
  /** epoch seconds — when the candidate agreed */
  grantedAt: number;
}

export interface ConsentGrant {
  scope: ConsentScope;
  token: string;
}

export type ConsentVerdict =
  | { ok: true; claims: ConsentClaims }
  | { ok: false; reason: "missing" | "malformed" | "bad_signature" | "wrong_session" | "wrong_scope" };

/**
 * Storage ports. Defined here so agents can depend on the *shape* of a store
 * without depending on the gateway that implements it (Postgres/Redis/disk in
 * production, in-memory in tests).
 */

import type { Answer, CandidateProfile, Evaluation, Question } from "./interview.js";
import type { Report } from "./report.js";
import type { ScheduledInterview } from "./scheduling.js";
import type { Session, SessionState, SessionStateTransition, StateWriteGrant } from "./session.js";
import type { TelemetryEvent, TelemetryEventType, TelemetryPayload } from "./telemetry.js";

export interface SessionStore {
  create(input: {
    candidateId: string;
    role: string;
    jobDescription: string;
    questionBudget?: number;
  }): Promise<Session>;

  get(sessionId: string): Promise<Session | null>;

  listByCandidate(candidateId: string): Promise<Session[]>;

  /**
   * The ONLY path that writes `Session.state`. Requires a grant that only
   * `@mia/harness-agent` can construct, and records an audit row for every
   * accepted transition (INSTRUCTIONS.md §3: "The Harness Agent is the only
   * component allowed to transition state").
   */
  setState(
    sessionId: string,
    toState: SessionState,
    grant: StateWriteGrant,
    reason: string,
  ): Promise<Session>;

  /** Called once at wiring time with the harness's grant; a second call throws. */
  registerStateWriter(grant: StateWriteGrant): void;

  transitions(sessionId: string): Promise<SessionStateTransition[]>;

  /** Non-state session fields may be written by their owning agent. */
  patch(
    sessionId: string,
    patch: Partial<
      Pick<
        Session,
        | "consent"
        | "resumeRef"
        | "topicPlan"
        | "jdFit"
        | "questionBudget"
        | "candidateProfile"
        | "jdGapTopics"
        | "jdFitFingerprint"
        | "focusEvents"
      >
    >,
  ): Promise<Session>;

  /**
   * Atomically appends one fullscreen-exit event and returns the new count.
   * NOT `get` then `patch({ focusEvents })` — that read-modify-write loses
   * events under concurrent calls (two exits recorded within the same tick
   * both read the same starting array, and the second write clobbers the
   * first). This is a single operation specifically so each backend can make
   * it atomic in whatever way it actually has available — a `SET x = x ||
   * $1` in Postgres, a synchronous push in memory — rather than callers
   * reimplementing locking around a generic `patch`.
   */
  appendFocusEvent(sessionId: string, timestamp: string): Promise<{ exitCount: number }>;

  /**
   * (Stage 7) Session count per candidate, for the Admin directory's status
   * column — `no_activity` has to mean "never started one", not "never
   * finished one", so a candidate mid-first-interview is not filed as inactive.
   *
   * One call for the whole page rather than `listByCandidate` per row: the
   * directory is explicitly not allowed to fan out per user
   * (`ADMIN_FEATURE_PROMPT.md` Part 1).
   */
  countsByCandidate(): Promise<Record<string, number>>;
}

/**
 * (Stage 5) Ephemeral, session-scoped key/value working memory — the Memory
 * Agent's store for the two pieces of data §4.7 says must NOT get a durable
 * table: each question's `reference_answer`, and the in-progress `jd_fit`
 * fields during CONFIG.
 *
 * Declared as its own narrow port rather than handing the Memory Agent the
 * whole `LiveSessionStore`, so an agent that only needs scratch space cannot
 * reach device checks, session tokens, or timers.
 */
export interface SessionScratchStore {
  setSessionScratch(sessionId: string, key: string, value: unknown): Promise<void>;
  getSessionScratch<T = unknown>(sessionId: string, key: string): Promise<T | null>;
  clearSessionScratch(sessionId: string): Promise<void>;
}

export interface TelemetrySink {
  emit(
    eventType: TelemetryEventType,
    sessionId: string | null,
    payload: TelemetryPayload,
  ): Promise<TelemetryEvent>;
  /** Test/inspection hook — the durable sink is Postgres in production. */
  recent(limit?: number): Promise<TelemetryEvent[]>;
}

export interface StoredFileMeta {
  ref: string;
  sessionId: string;
  filename: string;
  contentType: string;
  sizeBytes: number;
  uploadedAt: string;
}

/**
 * Resume (and later audio) blob storage.
 *
 * `delete` is a HARD delete: the bytes go, not just the pointer
 * (INSTRUCTIONS.md §8, "it is never just unlinked or hidden"). `exists` is what
 * a deletion test should assert against — it reads the backing store, not an
 * index.
 */
export interface FileStore {
  put(input: {
    sessionId: string;
    filename: string;
    contentType: string;
    bytes: Uint8Array;
  }): Promise<StoredFileMeta>;
  get(ref: string): Promise<{ meta: StoredFileMeta; bytes: Uint8Array } | null>;
  stat(ref: string): Promise<StoredFileMeta | null>;
  exists(ref: string): Promise<boolean>;
  delete(ref: string): Promise<boolean>;
  listBySession(sessionId: string): Promise<StoredFileMeta[]>;
}

export interface QuestionStore {
  append(question: Question): Promise<Question>;
  get(questionId: string): Promise<Question | null>;
  listBySession(sessionId: string): Promise<Question[]>;
}

export interface AnswerStore {
  append(answer: Answer): Promise<Answer>;
  get(answerId: string): Promise<Answer | null>;
  getByQuestion(questionId: string): Promise<Answer | null>;
  appendFollowUp(answerId: string, followUp: { text: string; transcript: string }): Promise<Answer>;
  /**
   * (Stage 5, §11.2) Writes a follow-up exchange's score onto that specific
   * `followUps[]` entry. Deliberately not an `EvaluationStore.append` — see the
   * note on `FollowUp.score`.
   */
  scoreFollowUp(
    answerId: string,
    index: number,
    score: NonNullable<Answer["followUps"][number]["score"]>,
  ): Promise<Answer>;
  /**
   * (Stage 6, §4.4) Writes the Follow-up Question Agent's concept-verification
   * pass and resulting directive onto the answer. An enrichment, not a gate —
   * losing this write must never lose the answer or its score.
   */
  recordExtraction(
    answerId: string,
    extraction: NonNullable<Answer["extraction"]>,
    nextAction: NonNullable<Answer["nextAction"]>,
  ): Promise<Answer>;
  /**
   * Retention (INSTRUCTIONS.md §8): replaces the transcript, and every
   * follow-up transcript, with a redaction marker. The row and its evaluations
   * survive — only the candidate's own words are purged, once the Report Agent
   * has already extracted whatever verbatim evidence the report cites.
   */
  redact(answerId: string): Promise<Answer>;
}

export interface EvaluationStore {
  append(evaluation: Evaluation): Promise<Evaluation>;
  listByAnswer(answerId: string): Promise<Evaluation[]>;
  listBySession(sessionId: string): Promise<Evaluation[]>;
}

/**
 * `session_id` is the primary key (INSTRUCTIONS.md §6: one Report per
 * session), so `create` is upsert-shaped but a session's report is never
 * regenerated in practice — REPORT_GENERATION runs once per session.
 */
export interface ReportStore {
  create(report: Report): Promise<Report>;
  getBySession(sessionId: string): Promise<Report | null>;
  /** Newest first — backs the student Home page and the Admin dashboard alike. */
  listByCandidate(candidateId: string): Promise<Report[]>;
  /** Admin-only aggregate view across every candidate (INSTRUCTIONS.md §7, GET /admin/reports). */
  listAll(): Promise<Report[]>;
  /**
   * (Stage 7) Per-candidate report stats for the Admin directory, computed by
   * the store in one pass.
   *
   * Exists specifically so the directory does not fetch every candidate's full
   * report set to display a count and an average — the N+1 the feature spec
   * rules out. The aggregation lives here, next to the data, so the Postgres
   * driver can do it in SQL rather than shipping every report over the wire to
   * be reduced in the gateway.
   */
  aggregateByCandidate(): Promise<CandidateReportAggregate[]>;
}

/** One candidate's report stats — see `ReportStore.aggregateByCandidate`. */
export interface CandidateReportAggregate {
  candidateId: string;
  /** Reports on file. One report per completed session (§6). */
  interviewsCompleted: number;
  /** Mean of each report's own mean competency score, 0-5. */
  averageScore: number | null;
  /** `created_at` of the newest report. */
  lastInterviewAt: string | null;
}

/**
 * (Stage 7) Admin-scheduled interviews — `ADMIN_FEATURE_PROMPT.md` Part 3.
 *
 * Session-seed data, read by the gateway when a candidate starts the session it
 * seeds. No agent depends on this port; scheduling adds no agent-to-agent path.
 */
export interface ScheduledInterviewStore {
  /** One row per candidate. A batch is a single call with many drafts. */
  createMany(rows: ScheduledInterview[]): Promise<ScheduledInterview[]>;
  get(id: string): Promise<ScheduledInterview | null>;
  /** Newest window first. Admin-facing; unfiltered by status. */
  list(): Promise<ScheduledInterview[]>;
  /** One candidate's assignments, newest window first. */
  listByCandidate(candidateId: string): Promise<ScheduledInterview[]>;
  /**
   * Candidate ids with at least one assignment that is neither cancelled nor
   * finished — what the directory's `interview_scheduled` badge reads. A set,
   * not a per-user query, for the same no-fan-out reason as the aggregate above.
   */
  candidatesWithOpenSchedules(): Promise<string[]>;
  /** Status transitions and the session link. Returns null for an unknown id. */
  update(
    id: string,
    patch: Partial<Pick<ScheduledInterview, "status" | "sessionId" | "scheduledFor" | "deadline">>,
  ): Promise<ScheduledInterview | null>;
}

export type { CandidateProfile };

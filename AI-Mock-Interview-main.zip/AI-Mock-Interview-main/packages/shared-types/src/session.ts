/**
 * Session lifecycle types. The state machine itself is specified in
 * INSTRUCTIONS.md §3 and enforced by the Harness Agent — no other component
 * may write `Session.state`.
 */

import type {
  CandidateProfile,
  ExtractionProcessorResult,
  NextActionGenerator,
  TopicRelevance,
} from "./interview.js";

export const SESSION_STATES = [
  "CREATED",
  "CONFIG",
  "TELEMETRY_CHECK",
  "CALIBRATION",
  "QUESTION_LOOP",
  "CODING_ROUND",
  "WRAP_UP",
  "REPORT_GENERATION",
  "COMPLETED",
  "ABORTED",
] as const;

export type SessionState = (typeof SESSION_STATES)[number];

/** Terminal states — nothing may transition out of these. */
export const TERMINAL_STATES: readonly SessionState[] = ["COMPLETED", "ABORTED"];

/**
 * Legal forward transitions (INSTRUCTIONS.md §3).
 *
 * `CODING_ROUND` is optional and skipped for non-technical roles — decided
 * during CALIBRATION — hence QUESTION_LOOP may go straight to WRAP_UP.
 * Every non-terminal state may additionally transition to ABORTED; that edge
 * is added at runtime rather than duplicated on every row here.
 */
export const SESSION_TRANSITIONS: Readonly<Record<SessionState, readonly SessionState[]>> = {
  CREATED: ["CONFIG"],
  CONFIG: ["TELEMETRY_CHECK"],
  TELEMETRY_CHECK: ["CALIBRATION"],
  CALIBRATION: ["QUESTION_LOOP"],
  QUESTION_LOOP: ["CODING_ROUND", "WRAP_UP"],
  CODING_ROUND: ["WRAP_UP"],
  WRAP_UP: ["REPORT_GENERATION"],
  REPORT_GENERATION: ["COMPLETED"],
  COMPLETED: [],
  ABORTED: [],
};

/** Per-session consent flags, captured on the Telemetry Check page (soul.md §5). */
export interface SessionConsent {
  telemetry: boolean;
  clipboardMonitor: boolean;
  audioRecording: boolean;
  crossSessionMemory: boolean;
  /** Fullscreen-exit / tab-away tracking during the active interview (soul.md §5). */
  focusLossMonitoring: boolean;
}

export const DEFAULT_CONSENT: SessionConsent = {
  telemetry: false,
  clipboardMonitor: false,
  audioRecording: false,
  crossSessionMemory: false,
  focusLossMonitoring: false,
};

/**
 * A consented fullscreen-exit event: a timestamp, nothing else — same minimal
 * shape as the Clipboard Monitor's paste events (soul.md §5: a boolean/count
 * is recordable, the candidate's other tabs or window content never is).
 */
export interface FocusEvent {
  timestamp: string;
}

/**
 * "More than 3" exits ends the session. On the 4th recorded exit the Harness
 * Agent wraps the session up the same way an early "End the interview" click
 * does — feedback on what was covered so far, not a punitive dead end
 * (soul.md §"Respect for what this is").
 */
export const MAX_FOCUS_EXITS = 3;

export interface JdFit {
  fitScore: number; // 0-1
  matchedRequirements: string[];
  /** JD requirements the resume gives no evidence for; folded into required_topics (§4.3). */
  gaps: string[];

  /**
   * (Stage 5 addition, INSTRUCTIONS.md §4.2.) These four are optional where §6
   * shows them required, because they only exist on the LLM-backed path. When
   * the provider is unavailable, or a claim fails the grounding check, the
   * agent still returns a complete `fitScore`/`matchedRequirements`/`gaps` from
   * the deterministic path — losing the enrichment must not lose the JD-fit
   * check itself (§5.7, §11.3).
   */

  /** Grounded natural-language explanation of the fit score. */
  rationale?: string;
  /**
   * JD-anchored topic weighting: how heavily the JOB DESCRIPTION weights each
   * topic, independent of whether the resume supports it. Distinct from
   * `CandidateProfile.topicRelevance`, which is resume-anchored.
   */
  topicRelevance?: TopicRelevance[];
  /** e.g. "resume-service-agent/v1", for reproducibility (§11.5). */
  promptVersion?: string;
  /**
   * Fields that were generated but failed the grounding check and were dropped
   * (§11.3). Present so a reader can tell "no signal" from "signal that
   * happened to be empty" — never silently omitted.
   */
  insufficientSignal?: string[];

  /**
   * (LLM-powered JD parser addition.) Structural extraction from the JD
   * parser, not a claim about the candidate — no grounding check applies.
   * Absent under the same conditions as the four fields above: provider
   * unavailable, or no job description was supplied.
   */

  /** Seniority the JOB DESCRIPTION targets — distinct from `CandidateProfile.seniorityEstimate`, which is resume-anchored. */
  roleLevel?: "junior" | "mid" | "senior" | "lead" | "staff+";
  /** Specific named technologies the JD explicitly mentions. */
  keyTechnologies?: string[];
}

export interface TopicPlanEntry {
  topic: string;
  /** floor 1, ceiling 3 per topic (INSTRUCTIONS.md §4.3) */
  maxQuestions: number;
  source: "resume" | "role_requirement" | "jd_gap";
}

export const TOPIC_QUESTION_FLOOR = 1;
export const TOPIC_QUESTION_CEILING = 3;
export const DEFAULT_QUESTION_BUDGET = 8;

/**
 * Bounds on a caller-supplied `question_budget`.
 *
 * The budget is the only session field a client picks, and it is the one the
 * QUESTION_LOOP termination check reads (`questions_asked >= questionBudget`).
 * That check is the sole reason the loop ever ends, so a value it cannot
 * compare usefully does not produce a short interview — it produces one that
 * never finishes. `NaN` is the sharp edge: every `>=` against it is false, so
 * the budget can never be spent.
 *
 * The ceiling is generous next to the default of 8 — a long practice session is
 * legitimate — while still bounding what one candidate can spend, since every
 * question is several MCP hops and a provider call.
 */
export const MIN_QUESTION_BUDGET = 1;
export const MAX_QUESTION_BUDGET = 20;

/** A usable question budget: a whole number inside the bounds above. */
export function isValidQuestionBudget(value: unknown): value is number {
  return (
    typeof value === "number" &&
    Number.isInteger(value) &&
    value >= MIN_QUESTION_BUDGET &&
    value <= MAX_QUESTION_BUDGET
  );
}

export interface Session {
  id: string;
  /** references User.id where role === "student" */
  candidateId: string;
  role: string;
  jobDescription: string;
  jdFit: JdFit | null;
  state: SessionState;
  consent: SessionConsent;
  /** total questions for the session, default 8 */
  questionBudget: number;
  /** set once at CALIBRATION, read by the Question Agent on every call */
  topicPlan: TopicPlanEntry[];
  /** reference to the stored resume file; null once hard-deleted (§8) */
  resumeRef: string | null;
  /**
   * Structured profile from the Resume Service Agent, kept so the Question
   * Agent can be called on a later request without re-parsing the file — and so
   * the raw resume can be deleted while the interview still works (§8).
   * Extends the illustrative shape in INSTRUCTIONS.md §6.
   */
  candidateProfile: CandidateProfile | null;
  /**
   * `jdFit.gaps` expressed as interview topics, computed at CONFIG by the
   * Resume Service Agent and consumed at CALIBRATION by the Question Agent.
   * Stored rather than recomputed so the plan can still be built after the raw
   * resume has been deleted (§8).
   */
  jdGapTopics: string[];
  /**
   * (Stage 5) Fingerprint of the resume+JD the session's generated `jdFit`
   * fields came from, so the harness can look up the Memory Agent's draft on a
   * resume replace (§4.7). Null until a generated jd_fit exists.
   */
  jdFitFingerprint: string | null;
  /**
   * Fullscreen-exit timestamps recorded while `focusLossMonitoring` consent is
   * on. Append-only; the Harness Agent is the only writer (via the Focus
   * Monitor Tool), same ownership rule as everything else under `Session`.
   */
  focusEvents: FocusEvent[];
  createdAt: string;
  updatedAt: string;
}

/** Append-only audit row: who moved the session, when, and why. */
export interface SessionStateTransition {
  id: string;
  sessionId: string;
  fromState: SessionState;
  toState: SessionState;
  /** Always "harness-agent" — the store rejects anything else. */
  actor: string;
  reason: string;
  at: string;
}

/**
 * Capability object required to write `Session.state`.
 *
 * Only `@mia/harness-agent` constructs one of these, and the session store
 * checks the symbol identity at runtime — so a stray agent or route handler
 * cannot mutate session state even if it holds a reference to the store.
 */
export interface StateWriteGrant {
  readonly actor: "harness-agent";
  readonly token: symbol;
}

/**
 * (Stage 6, §12.6) A read-only, ephemeral SNAPSHOT of one just-answered turn —
 * never a new place session state is owned or stored. Every value here already
 * lives somewhere else (`Session`, `Question`, `Answer.extraction`/`nextAction`,
 * the Time Tracking Tool): `composeLiveSessionState` in `agents/harness-agent`
 * assembles them into this shape for a caller (the frontend, a debugging tool)
 * that wants one coherent view of "where is this session right now" without
 * joining four tables itself. This is why it is a function return value, not a
 * column — a stored `liveSessionState` blob would duplicate state Stage 5's
 * stateless-reducer rule (`INSTRUCTIONS.md §11.1`) already keeps in one place
 * each, and would need its own redaction path the moment `extractionProcessor.
 * transcribedInputChunk` (== `Answer.transcript`, never a second copy — see
 * `ExtractionProcessorResult`) got persisted alongside it.
 */
export interface LiveSessionState {
  sessionId: string;
  candidateId: string;
  activeTopicId: string;
  sessionMetrics: {
    elapsedTimeSeconds: number;
    /** This turn's score normalized to 0-1 (rubric max is 5) — not a running session-wide average. */
    topicCompetencyScore: number;
    currentDemonstratedTier: number;
  };
  contextEngine: {
    /** The `dynamicFraming.resumeContextIntegrationRule` (packages/interview-domain/blueprint.ts) resolved for this candidate. */
    activeResumeAnchor: string;
    lastDeliveredPrompt: string;
  };
  extractionProcessor: ExtractionProcessorResult;
  nextActionGenerator: NextActionGenerator;
}

/**
 * Session archive types — INSTRUCTIONS.md §6, §11.4.
 *
 * One document per completed session, written to a SEPARATE Supabase-hosted
 * Postgres instance for Admin export. It is a copy, never a second source of
 * truth: nothing reads back from it into the interview.
 *
 * The ordering constraint is the important part and it is not negotiable. The
 * archive is compiled strictly AFTER the Stage 4 retention/redaction job runs,
 * so it can never contain more than the primary record does at the moment it is
 * built (soul.md §5 Stage 5 guardrail). Archiving is not a back door around the
 * retention policy.
 */

import type { Answer, Evaluation, Question } from "./interview.js";
import type { Report } from "./report.js";
import type { Session, TopicPlanEntry } from "./session.js";

export interface SessionArchiveDocument {
  session: Session;
  topicPlan: TopicPlanEntry[];
  questions: Question[];
  /**
   * `transcript` reflects whatever the primary store held AT ARCHIVE TIME —
   * i.e. already redacted per §8 unless the candidate opted into retention.
   * Archiving never un-redacts.
   */
  answers: Answer[];
  evaluations: Evaluation[];
  report: Report;
}

export interface SessionArchive {
  sessionId: string;
  candidateId: string;
  /** From `User.fullName`. Archiving is REFUSED when this is unset (§11.4 step 2). */
  candidateName: string;
  department?: string;
  programYear?: string;
  archivedAt: string;
  document: SessionArchiveDocument;
}

/** Metadata-only view, for the Admin listing that does not need the whole body (§7). */
export interface SessionArchiveSummary {
  sessionId: string;
  candidateId: string;
  candidateName: string;
  department?: string;
  programYear?: string;
  archivedAt: string;
}

/**
 * The archive store port.
 *
 * A port rather than a Supabase client passed around, for the same reason every
 * other store here is one: it keeps the archive reachable only from server-side
 * code holding this interface, and it lets the test suite run the whole
 * archive-ordering gate with no second database (§11.4, §8).
 */
export interface SessionArchiveStore {
  /** `session_id` is the primary key — re-archiving a session replaces its row. */
  upsert(archive: SessionArchive): Promise<SessionArchive>;
  get(sessionId: string): Promise<SessionArchive | null>;
  summary(sessionId: string): Promise<SessionArchiveSummary | null>;
  list(): Promise<SessionArchiveSummary[]>;
  close(): Promise<void>;
}

/** Raised when §11.4 step 2's hard stop applies: no candidate name, no archive. */
export class ArchiveRefused extends Error {
  readonly code = "archive_refused";
  constructor(message: string) {
    super(message);
    this.name = "ArchiveRefused";
  }
}

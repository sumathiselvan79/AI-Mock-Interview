/**
 * `npm run lint:agents` — fails CI on module-scope mutable state under
 * `/agents/**` (INSTRUCTIONS.md §11.1).
 */

import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { checkAgents } from "./index.js";

const repoRoot = join(dirname(fileURLToPath(import.meta.url)), "..", "..", "..");
const { filesChecked, violations } = checkAgents(join(repoRoot, "agents"), repoRoot);

if (violations.length === 0) {
  process.stdout.write(`stateless-reducer: ${filesChecked} agent files clean\n`);
} else {
  for (const violation of violations) {
    process.stderr.write(
      `${violation.file}:${violation.line}  ${violation.name} — ${violation.reason}\n`,
    );
  }
  process.stderr.write(
    `\n${violations.length} violation(s) of the stateless reducer contract (INSTRUCTIONS.md §11.1).\n` +
      "If it needs remembering, route it through the Memory Agent. If an exception is genuinely\n" +
      "unavoidable, mark the declaration with a /* stateless-reducer-exempt: <reason> */ comment.\n",
  );
  process.exitCode = 1;
}

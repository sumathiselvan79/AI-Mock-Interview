/**
 * The stateless-reducer rule — INSTRUCTIONS.md §11.1, TRACKING.md Stage 5.
 *
 * "No module-level mutable state in `/agents/**`, no in-memory cache keyed by
 * `session_id` inside an agent, no 'remember the last N calls' shortcut — if it
 * needs remembering, it goes through the Memory Agent where it's inspectable
 * and scoped."
 *
 * TRACKING.md asks for "a custom ESLint (or equivalent) rule ... so the
 * contract is enforced by CI, not just documentation". This is the equivalent:
 * a TypeScript-AST check, run by `npm run lint`. The repo has no ESLint
 * install, and adding one plus typescript-eslint to enforce a single rule would
 * be a large dependency for a small job — the compiler API is already here.
 *
 * What it flags, and why each one is the shape §11.1 warns about:
 *  - `let` / `var` at module scope: the classic accumulator.
 *  - `const` bound to a fresh Map/Set/Array/Object at module scope: a `const`
 *    binding says nothing about whether the value is mutable, and a
 *    module-level `new Map()` is exactly the "in-memory cache keyed by
 *    session_id" the contract rules out.
 *
 * What it deliberately allows, because none of it is per-session state:
 *  - frozen or primitive constants, regexes, and `as const` literal tables;
 *  - anything under a `/* stateless-reducer-exempt: <reason> *​/` comment on the
 *    declaration, so an unavoidable exception is recorded in the file rather
 *    than argued about in review.
 */

import { readdirSync, readFileSync, statSync } from "node:fs";
import { join, relative, sep } from "node:path";
import ts from "typescript";

export interface StatefulDeclaration {
  file: string;
  line: number;
  name: string;
  reason: string;
}

const EXEMPT_MARKER = "stateless-reducer-exempt";

/** Constructors whose instances are mutable containers by definition. */
const MUTABLE_CONSTRUCTORS = new Set(["Map", "Set", "WeakMap", "WeakSet", "Array"]);

export function checkSource(fileName: string, source: string): StatefulDeclaration[] {
  const sourceFile = ts.createSourceFile(fileName, source, ts.ScriptTarget.ES2022, true);
  const found: StatefulDeclaration[] = [];

  const report = (node: ts.Node, name: string, reason: string): void => {
    if (isExempt(node, source)) return;
    const { line } = sourceFile.getLineAndCharacterOfPosition(node.getStart(sourceFile));
    found.push({ file: fileName, line: line + 1, name, reason });
  };

  // Only module scope. State inside a function is per-call and dies with it,
  // which is precisely what a reducer is allowed to have.
  for (const statement of sourceFile.statements) {
    if (!ts.isVariableStatement(statement)) continue;

    const flags = statement.declarationList.flags;
    const isConst = (flags & ts.NodeFlags.Const) !== 0;

    for (const declaration of statement.declarationList.declarations) {
      const name = declaration.name.getText(sourceFile);

      if (!isConst) {
        report(statement, name, "module-scope `let`/`var` is mutable state between calls");
        continue;
      }

      const initializer = declaration.initializer;
      if (!initializer) continue;

      if (ts.isNewExpression(initializer)) {
        const constructor = initializer.expression.getText(sourceFile);
        if (MUTABLE_CONSTRUCTORS.has(constructor)) {
          report(
            statement,
            name,
            `module-scope \`new ${constructor}()\` is an in-process cache; per-session state belongs in the Memory Agent`,
          );
        }
        continue;
      }

      // A bare array or object literal is mutable however it is bound. An
      // `Object.freeze(...)` wrapper, an `as const`, or a `Readonly<...>` /
      // `readonly T[]` type annotation all say otherwise — the last of those is
      // the idiom already used throughout this repo, and it is a real
      // expression of intent that the compiler enforces at every use site.
      const declaredReadonly = hasReadonlyType(declaration);
      if (ts.isArrayLiteralExpression(initializer) && !isFrozen(initializer) && !declaredReadonly) {
        report(
          statement,
          name,
          "module-scope array literal is mutable; annotate it `readonly T[]`, freeze it, or move it into a function",
        );
      }
      if (ts.isObjectLiteralExpression(initializer) && !isFrozen(initializer) && !declaredReadonly) {
        report(
          statement,
          name,
          "module-scope object literal is mutable; annotate it `Readonly<...>`, freeze it, or move it into a function",
        );
      }
    }
  }

  return found;
}

/**
 * `readonly T[]`, `ReadonlyArray<T>`, `Readonly<...>`, `ReadonlyMap`/`ReadonlySet`.
 *
 * A readonly annotation is not a runtime guarantee — a determined caller can
 * still cast it away — but neither is `Object.freeze` on a nested structure.
 * What it does do is make every mutation a compile error at the point someone
 * would write it, which is what this rule is actually protecting against: the
 * accidental accumulator, not the adversarial one.
 */
function hasReadonlyType(declaration: ts.VariableDeclaration): boolean {
  const type = declaration.type;
  if (!type) return false;
  if (ts.isTypeOperatorNode(type) && type.operator === ts.SyntaxKind.ReadonlyKeyword) return true;
  if (ts.isTypeReferenceNode(type)) {
    const name = type.typeName.getText();
    return name === "Readonly" || name === "ReadonlyArray" || name === "ReadonlyMap" || name === "ReadonlySet";
  }
  return false;
}

/** `Object.freeze(x)` and `x as const` / `x satisfies T` wrappers around it. */
function isFrozen(node: ts.Node): boolean {
  let current: ts.Node | undefined = node.parent;
  while (current && (ts.isAsExpression(current) || ts.isSatisfiesExpression(current))) {
    if (ts.isAsExpression(current) && current.type.getText() === "const") return true;
    current = current.parent;
  }
  const parent = node.parent;
  return (
    parent !== undefined &&
    ts.isCallExpression(parent) &&
    parent.expression.getText().replace(/\s/g, "") === "Object.freeze"
  );
}

function isExempt(node: ts.Node, source: string): boolean {
  const leading = ts.getLeadingCommentRanges(source, node.getFullStart()) ?? [];
  return leading.some((range) => source.slice(range.pos, range.end).includes(EXEMPT_MARKER));
}

/** Every `.ts` file under a directory, excluding `node_modules` and `dist`. */
export function collectSourceFiles(root: string): string[] {
  const out: string[] = [];
  const walk = (dir: string): void => {
    for (const entry of readdirSync(dir)) {
      if (entry === "node_modules" || entry === "dist") continue;
      const path = join(dir, entry);
      if (statSync(path).isDirectory()) walk(path);
      else if (path.endsWith(".ts") && !path.endsWith(".d.ts")) out.push(path);
    }
  };
  walk(root);
  return out;
}

export interface CheckResult {
  filesChecked: number;
  violations: StatefulDeclaration[];
}

/**
 * Runs the rule over every agent under `agentsRoot`. Paths in the result are
 * relative to `repoRoot`, so output is stable across machines.
 */
export function checkAgents(agentsRoot: string, repoRoot: string): CheckResult {
  const files = collectSourceFiles(agentsRoot);
  const violations: StatefulDeclaration[] = [];
  for (const file of files) {
    const relativePath = relative(repoRoot, file).split(sep).join("/");
    violations.push(
      ...checkSource(relativePath, readFileSync(file, "utf8")).map((v) => ({ ...v, file: relativePath })),
    );
  }
  return { filesChecked: files.length, violations };
}

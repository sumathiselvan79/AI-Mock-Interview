/**
 * JSON Schemas for every MCP call in this repo, plus the validator every caller
 * must use before a request leaves and after a response arrives
 * (CLAUDE.md §8: "Every MCP tool input/output must be validated against its
 * JSON Schema in /packages/mcp-schemas before use").
 *
 * Schemas are plain JSON on disk so a non-TypeScript service (a Python agent,
 * say) can consume the same files.
 */

import { readFileSync, readdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { Ajv, type ValidateFunction } from "ajv";
import { listLlmSchemaRefs, llmJsonSchema } from "./llm-schemas.js";

export * from "./llm-schemas.js";

const SCHEMA_DIR = join(dirname(fileURLToPath(import.meta.url)), "..", "schemas");

interface MethodSchema {
  description?: string;
  request: object;
  response: object;
  errors?: string[];
}

interface ServerSchemaFile {
  $id: string;
  description?: string;
  /** tool servers: methods declared at the top level */
  methods?: Record<string, MethodSchema>;
  /** agents.json: one file, many servers */
  servers?: Record<string, { stage: number; methods: Record<string, MethodSchema> }>;
}

export interface SchemaViolation {
  path: string;
  message: string;
}

export interface ValidationResult {
  valid: boolean;
  violations: SchemaViolation[];
}

const ajv = new Ajv({ allErrors: true, strict: false });

/** server name -> method name -> compiled validators */
const registry = new Map<string, Map<string, { request: ValidateFunction; response: ValidateFunction }>>();

function register(server: string, methods: Record<string, MethodSchema>): void {
  const compiled = new Map<string, { request: ValidateFunction; response: ValidateFunction }>();
  for (const [method, schema] of Object.entries(methods)) {
    compiled.set(method, {
      request: ajv.compile(schema.request),
      response: ajv.compile(schema.response),
    });
  }
  registry.set(server, compiled);
}

function load(): void {
  for (const file of readdirSync(SCHEMA_DIR).filter((f) => f.endsWith(".json"))) {
    const parsed = JSON.parse(readFileSync(join(SCHEMA_DIR, file), "utf8")) as ServerSchemaFile;
    if (parsed.servers) {
      for (const [server, def] of Object.entries(parsed.servers)) register(server, def.methods);
    }
    if (parsed.methods) {
      register(file.replace(/\.json$/, ""), parsed.methods);
    }
  }
}

load();

/**
 * LLM output schemas (§11.5) join the same registry, derived from the Zod
 * definitions in `llm-schemas.ts` rather than written out a second time by
 * hand. They are registered under a synthetic server name so
 * `validateResponse("llm", ref, payload)` works exactly like any other MCP
 * validation — the LLM Provider Tool (§5.7) uses it to check a provider's
 * response before it reaches an agent.
 */
export const LLM_SCHEMA_SERVER = "llm";

function loadLlmSchemas(): void {
  const compiled = new Map<string, { request: ValidateFunction; response: ValidateFunction }>();
  // Requests into an LLM call are prompt inputs, whose shape is the calling
  // agent's business; only the OUTPUT has a contract worth enforcing here, so
  // the request validator accepts anything and the response validator is the
  // derived JSON Schema.
  const anything = ajv.compile({});
  for (const ref of listLlmSchemaRefs()) {
    compiled.set(ref, { request: anything, response: ajv.compile(llmJsonSchema(ref) as object) });
  }
  registry.set(LLM_SCHEMA_SERVER, compiled);
}

loadLlmSchemas();

/**
 * Caller restrictions that the schema itself cannot express.
 * The Speech Service is the one tool not callable by whichever agent wants it —
 * only the Harness Agent may call it (INSTRUCTIONS.md §5.6). A server absent
 * from this map is callable by any authenticated agent.
 */
export const ALLOWED_CALLERS: Readonly<Record<string, readonly string[]>> = {
  "tool-speech-service": ["harness-agent"],
};

export function isKnownServer(server: string): boolean {
  return registry.has(server);
}

export function isKnownMethod(server: string, method: string): boolean {
  return registry.get(server)?.has(method) ?? false;
}

export function listServers(): string[] {
  return [...registry.keys()].sort();
}

export function listMethods(server: string): string[] {
  return [...(registry.get(server)?.keys() ?? [])].sort();
}

function run(validate: ValidateFunction | undefined, payload: unknown, what: string): ValidationResult {
  if (!validate) {
    return { valid: false, violations: [{ path: "", message: `no ${what} schema registered` }] };
  }
  if (validate(payload)) return { valid: true, violations: [] };
  return {
    valid: false,
    violations: (validate.errors ?? []).map((e) => ({
      path: e.instancePath || "/",
      message: e.message ?? "invalid",
    })),
  };
}

export function validateRequest(server: string, method: string, params: unknown): ValidationResult {
  return run(registry.get(server)?.get(method)?.request, params, "request");
}

export function validateResponse(server: string, method: string, result: unknown): ValidationResult {
  return run(registry.get(server)?.get(method)?.response, result, "response");
}

/** Human-readable summary of a failed validation, safe to log (paths only, no values). */
export function describeViolations(violations: SchemaViolation[]): string {
  return violations.map((v) => `${v.path} ${v.message}`).join("; ");
}

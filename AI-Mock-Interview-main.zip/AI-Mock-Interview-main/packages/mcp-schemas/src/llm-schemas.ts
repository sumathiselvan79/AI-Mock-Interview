/**
 * Zod schemas for every LLM-backed generation in this repo — INSTRUCTIONS.md
 * §11.5, §5.7.
 *
 * The point of this file is that there is exactly ONE definition per LLM call.
 * The Zod schema here is what `withStructuredOutput` hands the provider, what
 * `structuredCall` re-validates the response against, and — via
 * `z.toJSONSchema` — what gets compiled into the same Ajv registry every other
 * MCP method uses. §11.5 asks for "literally the same object, not two
 * hand-synced copies"; deriving the JSON Schema instead of writing it out twice
 * is how that is actually true rather than merely intended.
 *
 * A `schema_ref` (the string the LLM Provider Tool takes, §5.7) is the key into
 * `LLM_SCHEMAS`. Refs are versioned alongside the prompt that produces them, so
 * an output shape can change without silently reinterpreting stored records.
 */

import { z } from "zod";

/**
 * A claim the model asserts, paired with the source text it says supports it.
 *
 * Every LLM-generated statement that reads as a factual assertion about the
 * candidate is shaped like this, because the grounding check (§11.3) needs
 * something concrete to look for in the source documents. A model that cannot
 * produce a verbatim `evidence` slice cannot get its claim past the check —
 * which is the whole mechanism behind soul.md §"Grounding is checked, not
 * assumed".
 */
export const GroundableClaim = z.object({
  value: z.string().min(1).describe("The claim itself, in plain language."),
  evidence: z
    .string()
    .min(1)
    .describe(
      "A short VERBATIM quote from the source document that supports the claim. Copy it exactly; do not paraphrase, summarise, or invent it.",
    ),
});

export type GroundableClaim = z.infer<typeof GroundableClaim>;

/**
 * Resume Service Agent (§4.2 Stage 5 addition): the JD-fit judgement layered on
 * top of the Resume Parser Tool's structured output. It never replaces parsing —
 * `matched_requirements` and `gaps` still come from the deterministic path; this
 * call adds the explanation and the JD-anchored weighting.
 */
export const JdFitGeneration = z.object({
  rationale: GroundableClaim.describe(
    "Why the resume does or does not fit the job description. Evidence must be a verbatim quote from the resume or the job description.",
  ),
  topic_relevance: z
    .array(
      z.object({
        topic: z.string().min(1),
        relevance_score: z
          .number()
          .min(0)
          .max(1)
          .describe("How heavily the JOB DESCRIPTION weights this topic — not how well the resume covers it."),
        evidence: z
          .string()
          .min(1)
          .describe("A verbatim quote from the JOB DESCRIPTION showing it asks for this topic."),
      }),
    )
    .max(12),
});

export type JdFitGeneration = z.infer<typeof JdFitGeneration>;

/**
 * Question Agent (§4.3 Stage 5 addition): the question and its reference answer
 * are generated in ONE call, per soul.md §"A reference answer is a comparison
 * aid". `reference_answer` is returned to the agent but never to the harness —
 * it goes to the Memory Agent and nowhere else (§4.7).
 *
 * `reasoning` comes first in the object on purpose (question-agent/v3,
 * INSTRUCTIONS.md §11.5): a chain-of-thought field ahead of the fields it
 * informs gets the model to actually work through the candidate profile and
 * the slot constraints before committing to `question`/`reference_answer`,
 * rather than reasoning after the fact to justify an already-written answer.
 * It is scratch work, not a claim about the candidate — never grounding-checked,
 * never returned past the Question Agent (same treatment as `reference_answer`).
 */
export const QuestionGeneration = z.object({
  reasoning: z
    .string()
    .min(20)
    .describe(
      "Chain-of-thought scratch work, not shown to the candidate. Work through: (1) what the candidate profile actually shows about this topic, (2) whether the baseline question already fits the slot or what specifically is missing, (3) how to sharpen it for tier/difficulty without changing its scope. Write this BEFORE the fields below.",
    ),
  question: z.object({
    text: z.string().min(10),
    topic: z.string().min(1).describe("MUST be one of the topics in the supplied topic plan."),
    type: z.enum(["behavioral", "technical"]),
    difficulty: z.number().int().min(1).max(5),
    tier: z
      .number()
      .int()
      .min(1)
      .max(3)
      .describe("MUST equal the supplied slot's tier. Mirrors difficulty (tier + 1) — not a separate choice.")
      .optional(),
    expected_signals: z
      .array(z.string().min(1))
      .min(1)
      .max(6)
      .describe("What a strong answer would demonstrate. Used for calibration, never shown to the candidate."),
  }),
  reference_answer: z
    .string()
    .min(40)
    .describe(
      "A model answer for the Eval Tool to compare against. NEVER shown to the candidate and never spoken aloud.",
    ),
  grounding: GroundableClaim.describe(
    "Why this question suits this candidate. Evidence must be a verbatim quote from the candidate profile or the topic plan.",
  ),
});

export type QuestionGeneration = z.infer<typeof QuestionGeneration>;

/**
 * Follow-up Question Agent (§4.4): `targeted_gap.evidence` must be a verbatim
 * slice of the candidate's own answer. That is how "a follow-up must target a
 * specific gap or claim in the answer, never a generic 'tell me more'" stops
 * being a style note and becomes something the grounding check enforces.
 */
export const FollowUpGeneration = z.object({
  should_follow_up: z.boolean(),
  follow_up_text: z.string().min(1).optional(),
  reason: z.string().min(1),
  targeted_gap: GroundableClaim.describe(
    "The specific gap or claim being probed. Evidence must be a verbatim quote from the candidate's answer transcript.",
  ).optional(),
});

export type FollowUpGeneration = z.infer<typeof FollowUpGeneration>;

/**
 * Resume Parser (LLM-powered extraction): the structured output the model must
 * return when asked to extract skills, experience, and education from raw resume
 * text. This supplements (never replaces) the deterministic regex parser — the
 * existing `parseResumeText` stays as the automatic fallback.
 */
export const ResumeParseGeneration = z.object({
  skills: z
    .array(z.string().min(1).max(60))
    .describe("Individual skills or technologies. Each entry ≤ 4 words."),
  experience: z
    .array(
      z.object({
        title: z.string().min(1).describe("Job title exactly as written."),
        company: z.string().min(1).describe("Company name exactly as written."),
        start_year: z.number().int().min(1970).max(2030).describe("Start year, e.g. 2019."),
        end_year: z
          .number()
          .int()
          .min(1970)
          .max(2030)
          .nullable()
          .describe("End year, or null if currently employed."),
        years: z.number().min(0).max(50).describe("Duration in years. 0 if dates are ambiguous."),
        highlights: z
          .array(z.string().min(1))
          .max(5)
          .describe("Key achievements or responsibilities, verbatim from the resume."),
      }),
    )
    .describe("Work history entries, ordered by recency."),
  education: z
    .array(
      z.object({
        degree: z.string().min(1).describe("Degree or qualification name."),
        institution: z.string().min(1).describe("University or institution name."),
        year: z.number().int().nullable().optional().describe("Graduation year, or null if not stated."),
      }),
    )
    .describe("Academic qualifications."),
  keywords: z
    .array(z.string().min(1))
    .max(40)
    .describe("Top content-bearing terms extracted from the resume."),
  summary: z
    .string()
    .min(10)
    .max(300)
    .describe("A 1-2 sentence factual summary of the candidate. No embellishment."),
});

export type ResumeParseGeneration = z.infer<typeof ResumeParseGeneration>;

/**
 * JD Requirements Parser (LLM-powered extraction): the structured output the
 * model must return when asked to extract requirements from a job description.
 * Supplements (never replaces) the deterministic `extractRequirements` regex.
 */
export const JdRequirementsGeneration = z.object({
  requirements: z
    .array(
      z.object({
        text: z.string().min(1).describe("The requirement as a single, atomic demand."),
        category: z
          .enum(["technical", "experience", "education", "soft_skill", "certification", "other"])
          .describe("What kind of requirement this is."),
        is_mandatory: z
          .boolean()
          .describe('true if the JD uses "must", "required"; false for "nice to have", "preferred".'),
      }),
    )
    .describe("Individual requirements extracted from the JD."),
  role_level: z
    .enum(["junior", "mid", "senior", "lead", "staff+"])
    .describe("Seniority level the JD targets."),
  key_technologies: z
    .array(z.string().min(1))
    .max(20)
    .describe("Specific named technologies, frameworks, or tools the JD emphasizes."),
});

export type JdRequirementsGeneration = z.infer<typeof JdRequirementsGeneration>;

export interface LlmSchemaEntry {
  /** The `schema_ref` string, e.g. "llm:resume-service-agent/jd_fit@v1". */
  ref: string;
  schema: z.ZodType;
  /**
   * Paths whose grounding failure invalidates the WHOLE response rather than
   * just that field (§11.3: "only rejected if a required field fails"). Paths
   * are dot/bracket JSON paths as produced by `describeGroundablePath`.
   */
  requiredGroundedPaths: readonly string[];
}

export const LLM_SCHEMA_REFS = {
  jdFit: "llm:resume-service-agent/jd_fit@v1",
  question: "llm:question-agent/question@v1",
  followUp: "llm:followup-agent/follow_up@v1",
  resumeParse: "llm:resume-parser/parse@v1",
  jdRequirements: "llm:jd-parser/requirements@v1",
} as const;

export type LlmSchemaRef = (typeof LLM_SCHEMA_REFS)[keyof typeof LLM_SCHEMA_REFS];

const ENTRIES: LlmSchemaEntry[] = [
  {
    ref: LLM_SCHEMA_REFS.jdFit,
    schema: JdFitGeneration,
    // `rationale` is an optional enrichment on top of a jd_fit that the
    // deterministic path already produced, so losing it must not lose the rest
    // of the response (§11.3, §4.2).
    requiredGroundedPaths: [],
  },
  {
    ref: LLM_SCHEMA_REFS.question,
    schema: QuestionGeneration,
    // A question we cannot tie back to the plan or the profile is exactly the
    // "inconsistent question" §4.3 says to fall back to the bank over.
    requiredGroundedPaths: ["grounding"],
  },
  {
    ref: LLM_SCHEMA_REFS.followUp,
    schema: FollowUpGeneration,
    // A probe whose target is not in the transcript is a generic "tell me
    // more" wearing a specific-sounding sentence (§4.4).
    requiredGroundedPaths: ["targeted_gap"],
  },
  {
    ref: LLM_SCHEMA_REFS.resumeParse,
    schema: ResumeParseGeneration,
    // Resume extraction is literal data copying, not a grounded claim about
    // the candidate — no grounding check needed.
    requiredGroundedPaths: [],
  },
  {
    ref: LLM_SCHEMA_REFS.jdRequirements,
    schema: JdRequirementsGeneration,
    // JD requirement extraction is structural, not a claim — no grounding.
    requiredGroundedPaths: [],
  },
];

const BY_REF = new Map<string, LlmSchemaEntry>(ENTRIES.map((entry) => [entry.ref, entry]));

export function getLlmSchema(ref: string): LlmSchemaEntry | undefined {
  return BY_REF.get(ref);
}

export function listLlmSchemaRefs(): string[] {
  return [...BY_REF.keys()].sort();
}

/**
 * The derived JSON Schema, for the Ajv registry the MCP Gateway validates
 * against. Draft-07 because that is what every hand-written schema file in
 * `/packages/mcp-schemas/schemas` declares and what the shared Ajv instance is
 * configured for.
 */
export function llmJsonSchema(ref: string): object | undefined {
  const entry = BY_REF.get(ref);
  if (!entry) return undefined;
  return z.toJSONSchema(entry.schema, { target: "draft-7", io: "output" });
}

# packages/ui-components

Shared React components for `apps/web` — timer, question card, transcript view,
consent panel, report cards.

**Empty until Stage 2**, when the first page (Interview Config) is built. A
component library with no consumer would only be guesswork about what the pages
need.

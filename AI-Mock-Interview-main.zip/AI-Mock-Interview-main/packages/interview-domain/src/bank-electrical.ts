/** Electrical engineering domain questions. */
import type { RawBankQuestion } from "./bank-types.js";

export const ELECTRICAL_QUESTIONS: readonly RawBankQuestion[] = [
  // ── circuit analysis ─────────────────────────────────────────────────
  { id: "ckt-1", topic: "circuit analysis", type: "technical", difficulty: 2,
    text: "You have a resistive network and need to find the current through one branch. What method do you use?",
    expectedSignals: ["KVL/KCL application", "Thevenin or mesh/nodal choice", "systematic approach"] },
  { id: "ckt-2", topic: "circuit analysis", type: "technical", difficulty: 3,
    text: "An RLC circuit is ringing longer than expected. How do you characterise the damping?",
    expectedSignals: ["damping ratio calculation", "Q factor relationship", "measurement approach"] },
  { id: "ckt-3", topic: "circuit analysis", type: "technical", difficulty: 4,
    text: "How would you analyse a circuit with multiple coupled inductors and nonlinear elements?",
    expectedSignals: ["SPICE simulation setup", "coupling coefficient modeling", "convergence challenges"] },

  // ── analog electronics ───────────────────────────────────────────────
  { id: "analog-1", topic: "analog electronics", type: "technical", difficulty: 2,
    text: "Design a non-inverting amplifier with a gain of 10. What practical issues do you consider?",
    expectedSignals: ["resistor ratio", "op-amp bandwidth/GBP", "input/output range"] },
  { id: "analog-2", topic: "analog electronics", type: "technical", difficulty: 3,
    text: "Your ADC readings have noise that wasn't in the datasheet. How do you track down the source?",
    expectedSignals: ["grounding/layout review", "power supply noise measurement", "signal conditioning evaluation"] },
  { id: "analog-3", topic: "analog electronics", type: "technical", difficulty: 4,
    text: "How would you design a precision current sense circuit for a 0-50A range with 1% accuracy?",
    expectedSignals: ["shunt vs Hall effect tradeoff", "thermal drift compensation", "common-mode rejection"] },

  // ── power electronics ────────────────────────────────────────────────
  { id: "pe-1", topic: "power electronics", type: "technical", difficulty: 2,
    text: "Explain the difference between a buck and a boost converter. When would you use each?",
    expectedSignals: ["voltage step-down vs step-up", "duty cycle relationship", "application examples"] },
  { id: "pe-2", topic: "power electronics", type: "technical", difficulty: 3,
    text: "Your switch-mode power supply has excessive output ripple. What are the likely causes?",
    expectedSignals: ["output capacitor ESR", "inductor sizing", "switching frequency considerations"] },
  { id: "pe-3", topic: "power electronics", type: "technical", difficulty: 4,
    text: "How would you design a 3-phase inverter for a motor drive with regenerative braking?",
    expectedSignals: ["switching topology choice", "deadtime insertion", "DC bus energy management"] },

  // ── power systems ────────────────────────────────────────────────────
  { id: "ps-1", topic: "power systems", type: "technical", difficulty: 2,
    text: "What is the purpose of a transformer in power distribution? Walk me through the sizing considerations.",
    expectedSignals: ["voltage transformation", "kVA rating vs load", "impedance and losses"] },
  { id: "ps-2", topic: "power systems", type: "technical", difficulty: 3,
    text: "A feeder trips on overcurrent but the load hasn't changed. How do you investigate?",
    expectedSignals: ["fault current analysis", "protection coordination review", "insulation testing"] },
  { id: "ps-3", topic: "power systems", type: "technical", difficulty: 4,
    text: "How would you integrate a 50MW solar farm into an existing distribution network?",
    expectedSignals: ["grid interconnection study", "voltage regulation impact", "protection scheme redesign"] },

  // ── electromagnetic theory ───────────────────────────────────────────
  { id: "em-1", topic: "electromagnetic theory", type: "technical", difficulty: 2,
    text: "What is impedance matching and why does it matter in RF systems?",
    expectedSignals: ["maximum power transfer", "reflection coefficient", "Smith chart basics"] },
  { id: "em-2", topic: "electromagnetic theory", type: "technical", difficulty: 3,
    text: "Your PCB antenna's radiation pattern doesn't match simulation. How do you debug?",
    expectedSignals: ["ground plane effects", "nearby conductor coupling", "measurement setup validation"] },
  { id: "em-3", topic: "electromagnetic theory", type: "technical", difficulty: 4,
    text: "How would you design an antenna array for beam steering in a 5G base station?",
    expectedSignals: ["element spacing for grating lobe avoidance", "phase shift control", "mutual coupling compensation"] },

  // ── signal processing ────────────────────────────────────────────────
  { id: "sp-1", topic: "signal processing", type: "technical", difficulty: 2,
    text: "What is the Nyquist theorem, and what happens if you violate it?",
    expectedSignals: ["sampling rate requirement", "aliasing explanation", "anti-aliasing filter"] },
  { id: "sp-2", topic: "signal processing", type: "technical", difficulty: 3,
    text: "Design a digital filter to remove 50Hz mains noise from a biomedical signal.",
    expectedSignals: ["notch filter design", "IIR vs FIR tradeoff", "phase distortion consideration"] },
  { id: "sp-3", topic: "signal processing", type: "technical", difficulty: 4,
    text: "How would you implement real-time spectral analysis on an FPGA for a wideband receiver?",
    expectedSignals: ["FFT architecture choice", "windowing strategy", "throughput vs resource tradeoff"] },

  // ── communication systems ────────────────────────────────────────────
  { id: "comm-1", topic: "communication systems", type: "technical", difficulty: 2,
    text: "Explain the difference between AM, FM, and digital modulation. When is each appropriate?",
    expectedSignals: ["bandwidth efficiency", "noise resilience", "application context"] },
  { id: "comm-2", topic: "communication systems", type: "technical", difficulty: 3,
    text: "A wireless link has high bit error rate at range. What factors do you investigate?",
    expectedSignals: ["link budget analysis", "multipath effects", "modulation/coding scheme"] },
  { id: "comm-3", topic: "communication systems", type: "technical", difficulty: 4,
    text: "How does OFDM handle frequency-selective fading, and what are its weaknesses?",
    expectedSignals: ["subcarrier orthogonality", "cyclic prefix purpose", "PAPR problem"] },

  // ── electric machines and drives ─────────────────────────────────────
  { id: "emd-1", topic: "electric machines and drives", type: "technical", difficulty: 2,
    text: "Explain the operating principle of a 3-phase induction motor. How is speed controlled?",
    expectedSignals: ["rotating magnetic field", "slip concept", "VFD application"] },
  { id: "emd-2", topic: "electric machines and drives", type: "technical", difficulty: 3,
    text: "A motor runs hot at rated load. What are the possible causes?",
    expectedSignals: ["voltage imbalance check", "ventilation/cooling review", "load profile analysis"] },
  { id: "emd-3", topic: "electric machines and drives", type: "technical", difficulty: 4,
    text: "How would you design the control algorithm for a PMSM drive with field weakening?",
    expectedSignals: ["d-q axis control", "flux weakening region constraints", "current limiting strategy"] },

  // ── instrumentation and measurement ──────────────────────────────────
  { id: "inst-1", topic: "instrumentation and measurement", type: "technical", difficulty: 2,
    text: "How do you select a sensor for measuring temperature in an industrial process?",
    expectedSignals: ["sensor type comparison", "range and environment", "signal conditioning needs"] },
  { id: "inst-2", topic: "instrumentation and measurement", type: "technical", difficulty: 3,
    text: "Your measurements drift over time despite a stable process. What's causing it?",
    expectedSignals: ["calibration verification", "thermal effects on sensor", "reference stability"] },
  { id: "inst-3", topic: "instrumentation and measurement", type: "technical", difficulty: 4,
    text: "How would you design a data acquisition system that measures 64 channels at 100kHz each?",
    expectedSignals: ["multiplexing vs parallel ADC", "channel-to-channel isolation", "timing synchronisation"] },

  // ── renewable energy systems ─────────────────────────────────────────
  { id: "ren-1", topic: "renewable energy systems", type: "technical", difficulty: 2,
    text: "How does a grid-tied solar inverter work? What happens when the grid goes down?",
    expectedSignals: ["DC-AC conversion", "MPPT concept", "anti-islanding protection"] },
  { id: "ren-2", topic: "renewable energy systems", type: "technical", difficulty: 3,
    text: "A solar installation is producing 20% less than predicted. How do you diagnose?",
    expectedSignals: ["shading analysis", "string voltage comparison", "inverter efficiency check"] },
  { id: "ren-3", topic: "renewable energy systems", type: "technical", difficulty: 4,
    text: "How would you design a microgrid with solar, battery storage, and a diesel backup?",
    expectedSignals: ["load profiling and sizing", "dispatch strategy", "battery cycling optimisation"] },

  // ── electrical safety and standards ───────────────────────────────────
  { id: "esafe-1", topic: "electrical safety and standards", type: "technical", difficulty: 2,
    text: "What is the purpose of grounding in an electrical installation?",
    expectedSignals: ["fault current path", "ground resistance testing", "personnel safety"] },
  { id: "esafe-2", topic: "electrical safety and standards", type: "technical", difficulty: 3,
    text: "How do you perform an arc flash hazard analysis for a switchgear installation?",
    expectedSignals: ["incident energy calculation", "boundary determination", "PPE selection"] },
  { id: "esafe-3", topic: "electrical safety and standards", type: "technical", difficulty: 4,
    text: "How would you design the protection coordination for a multi-level industrial distribution system?",
    expectedSignals: ["time-current curve coordination", "selectivity between devices", "short-circuit study"] },

  // ── plc and industrial automation ────────────────────────────────────
  { id: "plc-1", topic: "plc and industrial automation", type: "technical", difficulty: 2,
    text: "How does a PLC control a process? Walk me through a simple conveyor example.",
    expectedSignals: ["scan cycle concept", "input/output mapping", "ladder logic basics"] },
  { id: "plc-2", topic: "plc and industrial automation", type: "technical", difficulty: 3,
    text: "A PLC-controlled process occasionally produces defective parts. How do you use data to find the cause?",
    expectedSignals: ["data logging analysis", "timing correlation", "sensor validation"] },
  { id: "plc-3", topic: "plc and industrial automation", type: "technical", difficulty: 4,
    text: "How would you architect a SCADA system for a water treatment plant with 2000 I/O points?",
    expectedSignals: ["network topology design", "redundancy requirements", "cybersecurity considerations"] },
];

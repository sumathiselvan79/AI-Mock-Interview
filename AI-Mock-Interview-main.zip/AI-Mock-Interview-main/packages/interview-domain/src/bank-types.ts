/**
 * Shared types for the question bank — extracted to break the circular
 * dependency between question-bank.ts and the domain-specific bank-*.ts files.
 */

export interface RawBankQuestion {
  id: string;
  topic: string;
  type: "behavioral" | "technical";
  difficulty: number;
  text: string;
  expectedSignals: string[];
}

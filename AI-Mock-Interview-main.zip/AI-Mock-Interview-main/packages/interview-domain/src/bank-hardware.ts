/** Hardware engineering domain questions. */
import type { RawBankQuestion } from "./bank-types.js";

export const HARDWARE_QUESTIONS: readonly RawBankQuestion[] = [
  // ── digital logic design ─────────────────────────────────────────────
  { id: "dld-1", topic: "digital logic design", type: "technical", difficulty: 2,
    text: "Explain the difference between combinational and sequential logic. Give an example of each you've designed.",
    expectedSignals: ["stateless vs stateful distinction", "concrete examples", "clock dependency awareness"] },
  { id: "dld-2", topic: "digital logic design", type: "technical", difficulty: 3,
    text: "You have a state machine with 16 states and glitchy outputs. How do you diagnose and fix it?",
    expectedSignals: ["state encoding choices", "output registration", "simulation-based debugging"] },
  { id: "dld-3", topic: "digital logic design", type: "technical", difficulty: 4,
    text: "How would you design a pipelined datapath for a custom accelerator? Where do you insert pipeline stages?",
    expectedSignals: ["critical path analysis", "throughput vs latency tradeoff", "hazard handling"] },

  // ── computer architecture ────────────────────────────────────────────
  { id: "arch-1", topic: "computer architecture", type: "technical", difficulty: 2,
    text: "Walk me through what happens inside a CPU when it executes a single instruction.",
    expectedSignals: ["fetch-decode-execute cycle", "register file access", "ALU operation"] },
  { id: "arch-2", topic: "computer architecture", type: "technical", difficulty: 3,
    text: "Why do modern CPUs have multiple levels of cache? How does data flow between them?",
    expectedSignals: ["locality of reference", "inclusion vs exclusion policies", "cache coherence basics"] },
  { id: "arch-3", topic: "computer architecture", type: "technical", difficulty: 4,
    text: "How does branch prediction work, and what happens to the pipeline when a prediction is wrong?",
    expectedSignals: ["speculative execution", "pipeline flush cost", "prediction strategies (static vs dynamic)"] },

  // ── embedded systems ─────────────────────────────────────────────────
  { id: "emb-1", topic: "embedded systems", type: "technical", difficulty: 2,
    text: "Describe a firmware project you worked on. What microcontroller did you use, and why that one?",
    expectedSignals: ["peripheral requirements", "power/cost constraints", "toolchain familiarity"] },
  { id: "emb-2", topic: "embedded systems", type: "technical", difficulty: 3,
    text: "Your embedded device randomly resets in the field. Walk me through your investigation.",
    expectedSignals: ["watchdog timer analysis", "power supply integrity", "stack overflow checks"] },
  { id: "emb-3", topic: "embedded systems", type: "technical", difficulty: 4,
    text: "How would you design firmware for an OTA-updatable device that must never brick itself?",
    expectedSignals: ["dual-bank/A-B partitioning", "rollback on boot failure", "integrity verification"] },

  // ── pcb design and layout ────────────────────────────────────────────
  { id: "pcb-1", topic: "pcb design and layout", type: "technical", difficulty: 2,
    text: "Walk me through your PCB design process from schematic capture to manufacturing files.",
    expectedSignals: ["schematic review", "component placement rationale", "DRC before tapeout"] },
  { id: "pcb-2", topic: "pcb design and layout", type: "technical", difficulty: 3,
    text: "You have a high-speed differential pair that isn't meeting signal integrity requirements. What do you check?",
    expectedSignals: ["impedance control", "length matching", "reference plane continuity"] },
  { id: "pcb-3", topic: "pcb design and layout", type: "technical", difficulty: 4,
    text: "How would you design a 12-layer PCB stackup for a mixed-signal board with sensitive analog and noisy digital sections?",
    expectedSignals: ["ground plane isolation", "return current paths", "EMI containment strategy"] },

  // ── hardware verification and testing ────────────────────────────────
  { id: "hv-1", topic: "hardware verification and testing", type: "technical", difficulty: 2,
    text: "How do you verify that a Verilog/VHDL module behaves correctly before it goes to silicon?",
    expectedSignals: ["testbench methodology", "stimulus generation", "checking against expected output"] },
  { id: "hv-2", topic: "hardware verification and testing", type: "technical", difficulty: 3,
    text: "Your functional coverage is at 85% and the remaining holes are hard to hit. What's your strategy?",
    expectedSignals: ["constrained random with targeted seeds", "corner case identification", "coverage closure plan"] },
  { id: "hv-3", topic: "hardware verification and testing", type: "technical", difficulty: 4,
    text: "When would you use formal verification over simulation, and what are its limitations?",
    expectedSignals: ["exhaustive proof vs bounded", "state space explosion", "property specification"] },

  // ── soc design ───────────────────────────────────────────────────────
  { id: "soc-1", topic: "soc design", type: "technical", difficulty: 2,
    text: "What components make up a typical SoC, and how do they communicate?",
    expectedSignals: ["CPU/memory/peripherals", "bus interconnect", "address mapping"] },
  { id: "soc-2", topic: "soc design", type: "technical", difficulty: 3,
    text: "How do you handle the integration of a third-party IP core into your SoC?",
    expectedSignals: ["interface compliance verification", "clock domain handling", "documentation review"] },
  { id: "soc-3", topic: "soc design", type: "technical", difficulty: 4,
    text: "Design the memory subsystem for an SoC that must serve a CPU, a GPU, and a DMA engine simultaneously.",
    expectedSignals: ["arbitration policy", "QoS requirements", "bandwidth partitioning"] },

  // ── hardware-software interface ──────────────────────────────────────
  { id: "hsi-1", topic: "hardware-software interface", type: "technical", difficulty: 2,
    text: "How does a device driver communicate with hardware? Walk me through a register read.",
    expectedSignals: ["memory-mapped I/O", "register address space", "volatile access"] },
  { id: "hsi-2", topic: "hardware-software interface", type: "technical", difficulty: 3,
    text: "You wrote a driver, but the device behaves differently on two OS versions. How do you debug?",
    expectedSignals: ["HAL abstraction differences", "kernel API changes", "register-level validation"] },
  { id: "hsi-3", topic: "hardware-software interface", type: "technical", difficulty: 4,
    text: "How would you design a DMA engine's programming interface to be both efficient and safe for user-space access?",
    expectedSignals: ["IOMMU protection", "descriptor ring design", "interrupt coalescing"] },

  // ── signal integrity and timing ──────────────────────────────────────
  { id: "si-1", topic: "signal integrity and timing", type: "technical", difficulty: 2,
    text: "What is setup time and hold time? Why do they matter?",
    expectedSignals: ["data stability window", "metastability risk", "clock-to-q relationship"] },
  { id: "si-2", topic: "signal integrity and timing", type: "technical", difficulty: 3,
    text: "Your design has a timing violation on a path that crosses clock domains. How do you fix it?",
    expectedSignals: ["synchronizer insertion", "CDC analysis", "false path vs multi-cycle"] },
  { id: "si-3", topic: "signal integrity and timing", type: "technical", difficulty: 4,
    text: "How do you analyze and mitigate jitter in a high-speed serial link?",
    expectedSignals: ["deterministic vs random jitter", "eye diagram analysis", "equalization techniques"] },

  // ── low power design ─────────────────────────────────────────────────
  { id: "lp-1", topic: "low power design", type: "technical", difficulty: 2,
    text: "What are the main sources of power consumption in a digital chip?",
    expectedSignals: ["dynamic vs static power", "switching activity", "leakage current"] },
  { id: "lp-2", topic: "low power design", type: "technical", difficulty: 3,
    text: "How would you reduce power in a block that toggles frequently but is only used intermittently?",
    expectedSignals: ["clock gating", "power gating with isolation", "retention registers"] },
  { id: "lp-3", topic: "low power design", type: "technical", difficulty: 4,
    text: "Design a multi-voltage-domain strategy for an IoT SoC that must last years on a coin cell.",
    expectedSignals: ["always-on domain sizing", "wake-up latency budget", "level shifter placement"] },

  // ── semiconductor physics ────────────────────────────────────────────
  { id: "semi-1", topic: "semiconductor physics", type: "technical", difficulty: 2,
    text: "Explain how a MOSFET works as a switch. What controls whether it's on or off?",
    expectedSignals: ["gate voltage vs threshold", "channel formation", "n-type vs p-type"] },
  { id: "semi-2", topic: "semiconductor physics", type: "technical", difficulty: 3,
    text: "Why does shrinking the process node increase leakage current, and what do foundries do about it?",
    expectedSignals: ["short-channel effects", "gate oxide tunneling", "high-k metal gate"] },
  { id: "semi-3", topic: "semiconductor physics", type: "technical", difficulty: 4,
    text: "How do FinFETs differ from planar transistors, and what design implications does that have?",
    expectedSignals: ["3D channel structure", "quantized width", "variability reduction"] },
];

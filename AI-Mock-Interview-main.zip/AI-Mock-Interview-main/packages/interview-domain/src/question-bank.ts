/**
 * The question bank the Question Agent selects from.
 *
 * Questions are data, not prompt strings scattered through an agent, so the set
 * can be reviewed by whoever owns interview subject-matter expertise
 * (INSTRUCTIONS.md §10) and so difficulty calibration is auditable. Every entry
 * carries `expectedSignals` — what a strong answer would contain — which is what
 * the Follow-up Agent probes against and what the Eval Tool's rubric looks for.
 *
 * Difficulty is 1-5. The Question Agent opens below the target and works up
 * (soul.md §4: "calibrates difficulty progressively rather than opening with the
 * hardest question in the pool").
 *
 * Domain-specific questions live in separate bank-*.ts files to keep each
 * manageable. This module combines them into one unified QUESTION_BANK.
 */

import { SOFTWARE_QUESTIONS } from "./bank-software.js";
import { HARDWARE_QUESTIONS } from "./bank-hardware.js";
import { MECHANICAL_QUESTIONS } from "./bank-mechanical.js";
import { ELECTRICAL_QUESTIONS } from "./bank-electrical.js";
import { BEHAVIORAL_QUESTIONS } from "./bank-behavioral.js";

/**
 * Tier — the discrete escalation axis the blueprint's `extractionMatrix` runs
 * on (`tier_1_baseline` / `tier_2_intermediate` / `tier_3_advanced`).
 *
 * The bank already writes exactly three questions per topic at difficulty
 * 2/3/4 (soul.md §4: "opens below the target and works up"), which is a tier
 * ladder in every way except name. `tierOf` makes that explicit instead of
 * introducing a second, parallel numbering.
 */
export type Tier = 1 | 2 | 3;

export function tierOf(difficulty: number): Tier {
  if (difficulty <= 2) return 1;
  if (difficulty === 3) return 2;
  return 3;
}

/**
 * A stable id for one thing a strong answer demonstrates, scoped to
 * topic+tier so the same surface phrase in two topics ("names concrete
 * numbers") doesn't collide. This is the `concept_node_id` the blueprint's
 * `extractionMatrix` and a live session's `verifiedConceptIds` /
 * `unverifiedConceptIds` both key on.
 */
export function conceptId(topic: string, tier: Tier, label: string): string {
  return `${slug(topic)}.t${tier}.${slug(label)}`;
}

/**
 * Best-effort inverse of `conceptId`'s label segment, for callers (the
 * Follow-up Question Agent's concept verification, §4.4) that only carry the
 * id across the wire and need something to term-match against. Good enough
 * for that; not guaranteed to reconstruct a label with punctuation exactly.
 */
export function labelFromConceptId(id: string): string {
  const lastSegment = id.split(".").at(-1) ?? id;
  return lastSegment.replace(/-/g, " ");
}

function slug(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

export interface BankQuestion {
  id: string;
  topic: string;
  type: "behavioral" | "technical";
  difficulty: number;
  /** Derived from `difficulty` via `tierOf` — the escalation slot this question fills. */
  tier: Tier;
  text: string;
  expectedSignals: string[];
  /** Derived from `expectedSignals` via `conceptId` — what `extractionMatrix.targetConceptIds` point at. */
  conceptIds: string[];
}

export interface RawBankQuestion {
  id: string;
  topic: string;
  type: "behavioral" | "technical";
  difficulty: number;
  text: string;
  expectedSignals: string[];
}

function withTierAndConcepts(q: RawBankQuestion): BankQuestion {
  const tier = tierOf(q.difficulty);
  return {
    ...q,
    tier,
    conceptIds: q.expectedSignals.map((label) => conceptId(q.topic, tier, label)),
  };
}

const ALL_RAW_QUESTIONS: readonly RawBankQuestion[] = [
  ...SOFTWARE_QUESTIONS,
  ...HARDWARE_QUESTIONS,
  ...MECHANICAL_QUESTIONS,
  ...ELECTRICAL_QUESTIONS,
  ...BEHAVIORAL_QUESTIONS,
];

export const QUESTION_BANK: readonly BankQuestion[] = ALL_RAW_QUESTIONS.map(withTierAndConcepts);

export function questionsForTopic(topic: string): BankQuestion[] {
  return QUESTION_BANK.filter((q) => q.topic === topic);
}

export function questionsForTopicAndTier(topic: string, tier: Tier): BankQuestion[] {
  return QUESTION_BANK.filter((q) => q.topic === topic && q.tier === tier);
}

export function bankTopics(): string[] {
  return [...new Set(QUESTION_BANK.map((q) => q.topic))];
}

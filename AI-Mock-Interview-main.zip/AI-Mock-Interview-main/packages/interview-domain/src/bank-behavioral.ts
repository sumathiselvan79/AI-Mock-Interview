/** Behavioral / cross-cutting domain questions. */
import type { RawBankQuestion } from "./bank-types.js";

export const BEHAVIORAL_QUESTIONS: readonly RawBankQuestion[] = [
  // ── product sense ────────────────────────────────────────────────────
  { id: "prod-1", topic: "product sense", type: "behavioral", difficulty: 2,
    text: "Tell me about a time you pushed back on a requirement. What did you propose instead?",
    expectedSignals: ["understood the underlying need", "concrete alternative", "outcome"] },
  { id: "prod-2", topic: "product sense", type: "behavioral", difficulty: 3,
    text: "You have three weeks and a feature that needs six. How do you decide what ships?",
    expectedSignals: ["cuts scope not quality", "user-value reasoning", "communicates the tradeoff"] },
  { id: "prod-3", topic: "product sense", type: "behavioral", difficulty: 4,
    text: "Describe something you built that didn't get used. What did you learn, and what would you check earlier next time?",
    expectedSignals: ["honest post-hoc analysis", "validation step they skipped", "changed behaviour"] },

  // ── behavioral: leadership ───────────────────────────────────────────
  { id: "lead-1", topic: "behavioral: leadership", type: "behavioral", difficulty: 2,
    text: "Tell me about a time you helped someone on your team get better at something. What did you actually do?",
    expectedSignals: ["specific person and skill", "their own actions", "observable change"] },
  { id: "lead-2", topic: "behavioral: leadership", type: "behavioral", difficulty: 3,
    text: "Describe a technical decision you owned that other people disagreed with. How did you handle the disagreement?",
    expectedSignals: ["took the disagreement seriously", "decision process", "outcome and follow-through"] },
  { id: "lead-3", topic: "behavioral: leadership", type: "behavioral", difficulty: 4,
    text: "Tell me about a time you had to deliver something through people you didn't manage. How did you get it done?",
    expectedSignals: ["influence without authority", "specific obstacles", "result"] },

  // ── behavioral: collaboration ────────────────────────────────────────
  { id: "collab-1", topic: "behavioral: collaboration", type: "behavioral", difficulty: 2,
    text: "Tell me about a time you worked closely with someone outside engineering. What made it work, or not?",
    expectedSignals: ["concrete collaboration", "communication adaptation", "outcome"] },
  { id: "collab-2", topic: "behavioral: collaboration", type: "behavioral", difficulty: 3,
    text: "Describe a code review where you and the reviewer disagreed. How did it end?",
    expectedSignals: ["specific technical disagreement", "how it resolved", "what they took from it"] },
  { id: "collab-3", topic: "behavioral: collaboration", type: "behavioral", difficulty: 4,
    text: "Tell me about a time a project was blocked by another team. What did you do about it?",
    expectedSignals: ["escalation judgement", "own actions vs waiting", "result"] },

  // ── behavioral: ownership ────────────────────────────────────────────
  { id: "own-1", topic: "behavioral: ownership", type: "behavioral", difficulty: 2,
    text: "Tell me about something you shipped end to end. What were you responsible for?",
    expectedSignals: ["clear scope of their contribution", "decisions they made", "delivered outcome"] },
  { id: "own-2", topic: "behavioral: ownership", type: "behavioral", difficulty: 3,
    text: "Describe a problem nobody asked you to fix that you fixed anyway. Why that one?",
    expectedSignals: ["judgement about what mattered", "action taken", "impact"] },
  { id: "own-3", topic: "behavioral: ownership", type: "behavioral", difficulty: 4,
    text: "Tell me about a commitment you made that you couldn't keep. What did you do?",
    expectedSignals: ["early communication", "concrete recovery", "no blame-shifting"] },

  // ── behavioral: handling failure ─────────────────────────────────────
  { id: "fail-1", topic: "behavioral: handling failure", type: "behavioral", difficulty: 2,
    text: "Tell me about a bug you shipped. How did you find out, and what happened next?",
    expectedSignals: ["owns the mistake", "detection path", "fix and follow-up"] },
  { id: "fail-2", topic: "behavioral: handling failure", type: "behavioral", difficulty: 3,
    text: "Walk me through an incident you were part of, from the first alert to the follow-up actions.",
    expectedSignals: ["timeline", "their specific role", "durable follow-up, not just a hotfix"] },
  { id: "fail-3", topic: "behavioral: handling failure", type: "behavioral", difficulty: 4,
    text: "Describe a failure whose root cause turned out to be a decision you'd made months earlier. How did you handle that?",
    expectedSignals: ["traces cause honestly", "systemic rather than personal framing", "what changed after"] },
];

/** Software engineering domain questions. */
import type { RawBankQuestion } from "./bank-types.js";

export const SOFTWARE_QUESTIONS: readonly RawBankQuestion[] = [
  // ── distributed systems ──────────────────────────────────────────────
  { id: "ds-1", topic: "distributed systems", type: "technical", difficulty: 2,
    text: "Walk me through a system you've worked on where components ran on more than one machine. What talked to what, and why was it split that way?",
    expectedSignals: ["component boundaries", "reason for the split", "communication mechanism"] },
  { id: "ds-2", topic: "distributed systems", type: "technical", difficulty: 3,
    text: "You have a service that publishes events to a queue and a consumer that occasionally processes the same event twice. How would you find out why, and what would you change?",
    expectedSignals: ["at-least-once delivery", "idempotency", "diagnosis before fix"] },
  { id: "ds-3", topic: "distributed systems", type: "technical", difficulty: 4,
    text: "Two services need to stay in agreement about a piece of state, but the network between them is unreliable. Talk me through the tradeoffs you'd weigh.",
    expectedSignals: ["consistency vs availability", "partition behaviour", "concrete tradeoff, not just CAP recital"] },

  // ── system design ────────────────────────────────────────────────────
  { id: "sd-1", topic: "system design", type: "technical", difficulty: 2,
    text: "Design a URL shortener. Start wherever you'd naturally start, and tell me what you'd want to know before writing any code.",
    expectedSignals: ["clarifying questions", "data model", "read/write ratio"] },
  { id: "sd-2", topic: "system design", type: "technical", difficulty: 3,
    text: "A read-heavy endpoint is slow under load. Take me through how you'd decide between caching, an index, and a schema change.",
    expectedSignals: ["measurement first", "tradeoffs of each option", "invalidation cost"] },
  { id: "sd-3", topic: "system design", type: "technical", difficulty: 4,
    text: "Design the write path for a system that has to accept 50,000 events a second and lose none of them. Where does it break first?",
    expectedSignals: ["buffering/backpressure", "durability guarantees", "identifies own bottleneck"] },

  // ── databases ────────────────────────────────────────────────────────
  { id: "db-1", topic: "databases", type: "technical", difficulty: 2,
    text: "Tell me about a schema you designed. What did you get right, and what would you change now?",
    expectedSignals: ["concrete schema", "normalisation choice", "hindsight with a reason"] },
  { id: "db-2", topic: "databases", type: "technical", difficulty: 3,
    text: "A query that used to take 20ms now takes 4 seconds and nothing about the query changed. How do you work out what happened?",
    expectedSignals: ["query plan", "data growth/statistics", "index selectivity"] },
  { id: "db-3", topic: "databases", type: "technical", difficulty: 4,
    text: "You need to add a NOT NULL column to a table with 500 million rows, with no downtime. How do you do it?",
    expectedSignals: ["backfill in batches", "lock behaviour", "rollout ordering with the app"] },

  // ── apis and services ────────────────────────────────────────────────
  { id: "api-1", topic: "apis and services", type: "technical", difficulty: 2,
    text: "Take an API you've built and walk me through one endpoint: its inputs, outputs, and what happens when it fails.",
    expectedSignals: ["contract clarity", "error semantics", "status codes or equivalent"] },
  { id: "api-2", topic: "apis and services", type: "technical", difficulty: 3,
    text: "You need to change the shape of a response field that other teams already depend on. How do you ship that?",
    expectedSignals: ["versioning or additive change", "consumer migration", "deprecation window"] },
  { id: "api-3", topic: "apis and services", type: "technical", difficulty: 4,
    text: "A client retries on timeout, and your endpoint isn't idempotent. Walk me through what goes wrong and how you'd fix it properly.",
    expectedSignals: ["duplicate side effects", "idempotency keys", "server-side deduplication"] },

  // ── cloud and infrastructure ─────────────────────────────────────────
  { id: "cloud-1", topic: "cloud and infrastructure", type: "technical", difficulty: 2,
    text: "Describe how something you built got from your laptop to production. What ran that pipeline?",
    expectedSignals: ["build/deploy stages", "environments", "who or what triggers it"] },
  { id: "cloud-2", topic: "cloud and infrastructure", type: "technical", difficulty: 3,
    text: "How would you roll out a risky change to a service with a lot of traffic, so that a mistake costs as little as possible?",
    expectedSignals: ["staged rollout", "rollback plan", "signal that triggers rollback"] },
  { id: "cloud-3", topic: "cloud and infrastructure", type: "technical", difficulty: 4,
    text: "Your infrastructure is defined in code, but production has drifted from it. How do you find the drift and get back to a state you trust?",
    expectedSignals: ["drift detection", "reconciliation risk", "prevention, not just cleanup"] },

  // ── reliability and operations ───────────────────────────────────────
  { id: "rel-1", topic: "reliability and operations", type: "technical", difficulty: 2,
    text: "What did you watch to know whether your service was healthy, and why those signals?",
    expectedSignals: ["specific metrics", "user-facing vs machine-facing", "reasoning behind the choice"] },
  { id: "rel-2", topic: "reliability and operations", type: "technical", difficulty: 3,
    text: "You're paged at 3am for a service you didn't write. Walk me through your first ten minutes.",
    expectedSignals: ["stabilise before diagnose", "where they look first", "communication"] },
  { id: "rel-3", topic: "reliability and operations", type: "technical", difficulty: 4,
    text: "How would you set an SLO for a service, and what would you actually do differently once you had one?",
    expectedSignals: ["ties to user impact", "error budget consequence", "avoids vanity targets"] },

  // ── testing and quality ──────────────────────────────────────────────
  { id: "test-1", topic: "testing and quality", type: "technical", difficulty: 2,
    text: "For something you've built recently — what did you test, and what did you deliberately not test?",
    expectedSignals: ["explicit tradeoff", "risk-based reasoning", "concrete examples"] },
  { id: "test-2", topic: "testing and quality", type: "technical", difficulty: 3,
    text: "A test in CI fails about one run in twenty and nobody can reproduce it locally. What do you do?",
    expectedSignals: ["treats flakiness as a real defect", "isolation strategy", "doesn't just retry"] },
  { id: "test-3", topic: "testing and quality", type: "technical", difficulty: 4,
    text: "You inherit a service with no tests and a weekly release. Where do you add tests first, and how do you justify the time?",
    expectedSignals: ["prioritises by risk", "characterisation tests", "makes the case in business terms"] },

  // ── security ─────────────────────────────────────────────────────────
  { id: "sec-1", topic: "security", type: "technical", difficulty: 2,
    text: "How did users authenticate in a system you worked on, and what was stored on your side?",
    expectedSignals: ["credential handling", "hashing vs encryption", "session/token lifetime"] },
  { id: "sec-2", topic: "security", type: "technical", difficulty: 3,
    text: "How would you decide what a given service is allowed to access, and where would you enforce it?",
    expectedSignals: ["least privilege", "enforcement point", "auditability"] },
  { id: "sec-3", topic: "security", type: "technical", difficulty: 4,
    text: "You find a credential committed to a repository eighteen months ago. Walk me through what happens next.",
    expectedSignals: ["rotate first", "assess exposure", "prevention going forward"] },

  // ── data engineering ─────────────────────────────────────────────────
  { id: "de-1", topic: "data engineering", type: "technical", difficulty: 2,
    text: "Describe a data pipeline you've worked on end to end — where the data came from and what consumed it.",
    expectedSignals: ["source to sink", "scheduling", "consumers and their needs"] },
  { id: "de-2", topic: "data engineering", type: "technical", difficulty: 3,
    text: "A nightly job half-completed and left partial data behind. How do you make that situation not hurt?",
    expectedSignals: ["idempotent reruns", "atomic swap or staging", "detection"] },
  { id: "de-3", topic: "data engineering", type: "technical", difficulty: 4,
    text: "Downstream users say a dashboard number is wrong. How do you trace it back, and how would you stop it recurring?",
    expectedSignals: ["lineage", "data quality checks", "contract with producers"] },

  // ── machine learning ─────────────────────────────────────────────────
  { id: "ml-1", topic: "machine learning", type: "technical", difficulty: 2,
    text: "Tell me about a model you worked with. What was it predicting, and how did you know whether it was any good?",
    expectedSignals: ["problem framing", "metric choice", "baseline comparison"] },
  { id: "ml-2", topic: "machine learning", type: "technical", difficulty: 3,
    text: "Your model scores well offline and disappoints in production. What are the likely reasons, and how do you check?",
    expectedSignals: ["train/serve skew", "distribution shift", "evaluation design"] },
  { id: "ml-3", topic: "machine learning", type: "technical", difficulty: 4,
    text: "How would you design the serving path for a model that has to answer in under 100ms at high volume?",
    expectedSignals: ["batching/caching", "model size tradeoffs", "fallback behaviour"] },

  // ── frontend engineering ─────────────────────────────────────────────
  { id: "fe-1", topic: "frontend engineering", type: "technical", difficulty: 2,
    text: "Take a screen you've built and walk me through how state flowed through it.",
    expectedSignals: ["state ownership", "data fetching", "why that structure"] },
  { id: "fe-2", topic: "frontend engineering", type: "technical", difficulty: 3,
    text: "A page feels slow on a mid-range phone but fine on your laptop. How do you find out why?",
    expectedSignals: ["measures before optimising", "bundle/render/network split", "real device conditions"] },
  { id: "fe-3", topic: "frontend engineering", type: "technical", difficulty: 4,
    text: "How would you make a complex interactive component usable with a keyboard and a screen reader, and how would you verify it?",
    expectedSignals: ["focus management", "semantics over ARIA patches", "actual verification method"] },

  // ── mobile engineering ───────────────────────────────────────────────
  { id: "mob-1", topic: "mobile engineering", type: "technical", difficulty: 2,
    text: "How did your app behave when the network dropped mid-action?",
    expectedSignals: ["offline handling", "user feedback", "retry/queue"] },
  { id: "mob-2", topic: "mobile engineering", type: "technical", difficulty: 3,
    text: "You need to ship a fix to users today, but the app store review takes days. What are your options?",
    expectedSignals: ["server-side toggles", "remote config", "release planning"] },
  { id: "mob-3", topic: "mobile engineering", type: "technical", difficulty: 4,
    text: "How would you diagnose a battery drain complaint you can't reproduce?",
    expectedSignals: ["instrumentation", "background work audit", "narrowing by cohort"] },

  // ── data structures and algorithms ───────────────────────────────────
  { id: "dsa-1", topic: "data structures and algorithms", type: "technical", difficulty: 2,
    text: "You need to look up items by key with very fast reads. Walk me through which data structure you'd choose and why.",
    expectedSignals: ["hash map understanding", "collision handling", "time complexity reasoning"] },
  { id: "dsa-2", topic: "data structures and algorithms", type: "technical", difficulty: 3,
    text: "You have a sorted list of a million items and need to find one. What approach do you take, and what's the cost?",
    expectedSignals: ["binary search", "logarithmic complexity", "edge cases"] },
  { id: "dsa-3", topic: "data structures and algorithms", type: "technical", difficulty: 4,
    text: "Describe a problem you solved using dynamic programming. How did you identify the substructure?",
    expectedSignals: ["overlapping subproblems", "memoization vs tabulation", "state definition"] },

  // ── concurrency and parallelism ──────────────────────────────────────
  { id: "conc-1", topic: "concurrency and parallelism", type: "technical", difficulty: 2,
    text: "Describe a situation where two threads or processes needed to access the same resource. How did you handle it?",
    expectedSignals: ["mutual exclusion concept", "lock or equivalent", "awareness of contention"] },
  { id: "conc-2", topic: "concurrency and parallelism", type: "technical", difficulty: 3,
    text: "A multithreaded application occasionally produces wrong results but works fine under a debugger. What's your diagnosis approach?",
    expectedSignals: ["race condition suspicion", "reproducibility challenges", "systematic narrowing"] },
  { id: "conc-3", topic: "concurrency and parallelism", type: "technical", difficulty: 4,
    text: "How would you design a work-stealing scheduler for a thread pool? What are the tradeoffs?",
    expectedSignals: ["load balancing", "lock-free queues", "cache locality considerations"] },

  // ── networking fundamentals ──────────────────────────────────────────
  { id: "net-1", topic: "networking fundamentals", type: "technical", difficulty: 2,
    text: "Walk me through what happens from when you type a URL into a browser to when you see the page.",
    expectedSignals: ["dns resolution", "tcp handshake", "http request/response"] },
  { id: "net-2", topic: "networking fundamentals", type: "technical", difficulty: 3,
    text: "A service can reach the internet but not another service on the same network. How do you debug this?",
    expectedSignals: ["layer-by-layer diagnosis", "firewall/security groups", "dns vs routing"] },
  { id: "net-3", topic: "networking fundamentals", type: "technical", difficulty: 4,
    text: "How would you design a system to handle 100k concurrent WebSocket connections on a single host?",
    expectedSignals: ["event-driven architecture", "connection pooling limits", "memory per connection"] },

  // ── operating systems ────────────────────────────────────────────────
  { id: "os-1", topic: "operating systems", type: "technical", difficulty: 2,
    text: "What's the difference between a process and a thread? When would you pick one over the other?",
    expectedSignals: ["isolation vs shared memory", "context switch cost", "use-case reasoning"] },
  { id: "os-2", topic: "operating systems", type: "technical", difficulty: 3,
    text: "A process is using far more memory than you expect. How do you investigate?",
    expectedSignals: ["virtual vs resident memory", "tooling (top/pmap/etc)", "leak vs expected growth"] },
  { id: "os-3", topic: "operating systems", type: "technical", difficulty: 4,
    text: "Explain how virtual memory works and what happens when a page fault occurs during a critical path.",
    expectedSignals: ["page table mechanics", "major vs minor faults", "performance implications"] },

  // ── devops and ci/cd ─────────────────────────────────────────────────
  { id: "devops-1", topic: "devops and ci/cd", type: "technical", difficulty: 2,
    text: "Describe your team's deployment pipeline. What steps ran automatically vs. required a human?",
    expectedSignals: ["pipeline stages", "automated vs manual gates", "artifact management"] },
  { id: "devops-2", topic: "devops and ci/cd", type: "technical", difficulty: 3,
    text: "A deployment went out and metrics degraded. How do you decide whether to roll back or roll forward?",
    expectedSignals: ["severity assessment", "rollback cost vs fix time", "blast radius"] },
  { id: "devops-3", topic: "devops and ci/cd", type: "technical", difficulty: 4,
    text: "How would you implement canary deployments for a stateful service with database migrations?",
    expectedSignals: ["backward-compatible migrations", "traffic splitting", "rollback of schema changes"] },

  // ── version control and collaboration ────────────────────────────────
  { id: "vc-1", topic: "version control and collaboration", type: "technical", difficulty: 2,
    text: "How does your team use branches? Walk me through a feature from start to merge.",
    expectedSignals: ["branching strategy", "review process", "merge vs rebase reasoning"] },
  { id: "vc-2", topic: "version control and collaboration", type: "technical", difficulty: 3,
    text: "Two developers made conflicting changes to the same module. How do you resolve it without losing work?",
    expectedSignals: ["conflict resolution strategy", "communication", "testing after merge"] },
  { id: "vc-3", topic: "version control and collaboration", type: "technical", difficulty: 4,
    text: "Your monorepo has 500 contributors and CI takes 45 minutes. How do you keep velocity up?",
    expectedSignals: ["affected-path detection", "caching strategies", "trunk-based development tradeoffs"] },
];

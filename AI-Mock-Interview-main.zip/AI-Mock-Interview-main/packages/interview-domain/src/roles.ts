/**
 * Role profiles: the topics a role demands regardless of what a candidate's
 * resume happens to showcase (INSTRUCTIONS.md §4.3, soul.md §"Balanced
 * coverage" — "a thin resume in a required area is a reason to ask about it,
 * not a reason to skip it").
 */

export interface RoleProfile {
  id: string;
  label: string;
  /** Matched case-insensitively against the free-text role on the session. */
  matchers: string[];
  requiredTopics: string[];
  /** CODING_ROUND is skipped entirely for non-technical roles (§3). */
  codingRound: boolean;
  questionBudget: number;
}

/**
 * Every role gets these. They are what an interviewer probes for in any role,
 * and they keep a session from becoming a pure trivia quiz.
 */
export const UNIVERSAL_REQUIRED_TOPICS = [
  "behavioral: ownership",
  "behavioral: collaboration",
] as const;

export const ROLE_PROFILES: readonly RoleProfile[] = [
  {
    id: "backend-engineer",
    label: "Backend Engineer",
    matchers: ["backend", "back-end", "server-side", "platform engineer", "software engineer"],
    requiredTopics: ["system design", "databases", "apis and services", "reliability and operations"],
    codingRound: true,
    questionBudget: 8,
  },
  {
    id: "frontend-engineer",
    label: "Frontend Engineer",
    matchers: ["frontend", "front-end", "web engineer", "ui engineer"],
    requiredTopics: ["frontend engineering", "apis and services", "testing and quality"],
    codingRound: true,
    questionBudget: 8,
  },
  {
    id: "fullstack-engineer",
    label: "Full-Stack Engineer",
    matchers: ["full stack", "full-stack", "fullstack"],
    requiredTopics: ["frontend engineering", "apis and services", "databases", "system design"],
    codingRound: true,
    questionBudget: 8,
  },
  {
    id: "data-engineer",
    label: "Data Engineer",
    matchers: ["data engineer", "analytics engineer"],
    requiredTopics: ["data engineering", "databases", "cloud and infrastructure"],
    codingRound: true,
    questionBudget: 8,
  },
  {
    id: "ml-engineer",
    label: "Machine Learning Engineer",
    matchers: ["machine learning", "ml engineer", "ai engineer", "research engineer"],
    requiredTopics: ["machine learning", "data engineering", "system design"],
    codingRound: true,
    questionBudget: 8,
  },
  {
    id: "sre",
    label: "Site Reliability Engineer",
    matchers: ["sre", "site reliability", "devops", "infrastructure engineer"],
    requiredTopics: ["reliability and operations", "cloud and infrastructure", "system design"],
    codingRound: true,
    questionBudget: 8,
  },
  {
    id: "mobile-engineer",
    label: "Mobile Engineer",
    matchers: ["mobile", "ios engineer", "android engineer"],
    requiredTopics: ["mobile engineering", "apis and services", "testing and quality"],
    codingRound: true,
    questionBudget: 8,
  },
  {
    id: "engineering-manager",
    label: "Engineering Manager",
    matchers: ["engineering manager", "em ", "director of engineering", "head of engineering"],
    requiredTopics: ["behavioral: leadership", "system design", "product sense"],
    codingRound: false,
    questionBudget: 8,
  },
  {
    id: "product-manager",
    label: "Product Manager",
    matchers: ["product manager", "product owner", "pm "],
    requiredTopics: ["product sense", "behavioral: leadership"],
    codingRound: false,
    questionBudget: 8,
  },

  // ── hardware engineering roles ───────────────────────────────────────
  {
    id: "hardware-engineer",
    label: "Hardware Engineer",
    matchers: ["hardware engineer", "hw engineer", "chip designer", "asic engineer", "rtl engineer"],
    requiredTopics: ["digital logic design", "computer architecture", "hardware verification and testing", "signal integrity and timing"],
    codingRound: false,
    questionBudget: 8,
  },
  {
    id: "embedded-engineer",
    label: "Embedded Systems Engineer",
    matchers: ["embedded", "firmware engineer", "firmware developer", "embedded software"],
    requiredTopics: ["embedded systems", "hardware-software interface", "digital logic design"],
    codingRound: true,
    questionBudget: 8,
  },
  {
    id: "fpga-engineer",
    label: "FPGA Engineer",
    matchers: ["fpga", "fpga engineer", "fpga developer"],
    requiredTopics: ["digital logic design", "hardware verification and testing", "signal integrity and timing"],
    codingRound: false,
    questionBudget: 8,
  },
  {
    id: "verification-engineer",
    label: "Verification Engineer",
    matchers: ["verification engineer", "dv engineer", "design verification"],
    requiredTopics: ["hardware verification and testing", "digital logic design", "soc design"],
    codingRound: false,
    questionBudget: 8,
  },

  // ── mechanical engineering roles ─────────────────────────────────────
  {
    id: "mechanical-engineer",
    label: "Mechanical Engineer",
    matchers: ["mechanical engineer", "mech engineer", "mechanical design"],
    requiredTopics: ["mechanics of materials", "machine design", "cad and 3d modeling", "manufacturing processes"],
    codingRound: false,
    questionBudget: 8,
  },
  {
    id: "thermal-engineer",
    label: "Thermal Engineer",
    matchers: ["thermal engineer", "heat transfer engineer", "hvac engineer"],
    requiredTopics: ["thermodynamics", "hvac and thermal systems", "fluid mechanics"],
    codingRound: false,
    questionBudget: 8,
  },
  {
    id: "manufacturing-engineer",
    label: "Manufacturing Engineer",
    matchers: ["manufacturing engineer", "process engineer", "production engineer"],
    requiredTopics: ["manufacturing processes", "quality and metrology", "materials science"],
    codingRound: false,
    questionBudget: 8,
  },
  {
    id: "robotics-engineer",
    label: "Robotics Engineer",
    matchers: ["robotics engineer", "automation engineer", "mechatronics engineer"],
    requiredTopics: ["robotics and mechatronics", "control systems", "embedded systems"],
    codingRound: true,
    questionBudget: 8,
  },
  {
    id: "cae-analyst",
    label: "CAE / Simulation Analyst",
    matchers: ["cae", "simulation engineer", "fea analyst", "stress analyst", "structural analyst"],
    requiredTopics: ["finite element analysis", "mechanics of materials", "vibrations and dynamics"],
    codingRound: false,
    questionBudget: 8,
  },

  // ── electrical engineering roles ─────────────────────────────────────
  {
    id: "electrical-engineer",
    label: "Electrical Engineer",
    matchers: ["electrical engineer", "ee ", "power engineer"],
    requiredTopics: ["circuit analysis", "power systems", "electrical safety and standards"],
    codingRound: false,
    questionBudget: 8,
  },
  {
    id: "analog-design-engineer",
    label: "Analog Design Engineer",
    matchers: ["analog engineer", "analog design", "mixed-signal"],
    requiredTopics: ["analog electronics", "circuit analysis", "signal processing"],
    codingRound: false,
    questionBudget: 8,
  },
  {
    id: "power-electronics-engineer",
    label: "Power Electronics Engineer",
    matchers: ["power electronics", "power supply engineer", "converter design"],
    requiredTopics: ["power electronics", "circuit analysis", "electric machines and drives"],
    codingRound: false,
    questionBudget: 8,
  },
  {
    id: "rf-engineer",
    label: "RF / Communications Engineer",
    matchers: ["rf engineer", "radio frequency", "antenna engineer", "wireless engineer", "communications engineer"],
    requiredTopics: ["electromagnetic theory", "communication systems", "signal processing"],
    codingRound: false,
    questionBudget: 8,
  },
  {
    id: "controls-engineer",
    label: "Controls / Automation Engineer",
    matchers: ["controls engineer", "plc programmer", "automation engineer", "control systems"],
    requiredTopics: ["plc and industrial automation", "control systems", "instrumentation and measurement"],
    codingRound: false,
    questionBudget: 8,
  },
  {
    id: "renewable-energy-engineer",
    label: "Renewable Energy Engineer",
    matchers: ["renewable energy", "solar engineer", "wind engineer", "energy engineer"],
    requiredTopics: ["renewable energy systems", "power systems", "power electronics"],
    codingRound: false,
    questionBudget: 8,
  },
];

/**
 * Falls back to a generic technical profile rather than throwing: an unknown
 * role title must still produce a runnable interview.
 */
export const DEFAULT_ROLE_PROFILE: RoleProfile = {
  id: "generic-technical",
  label: "Technical Individual Contributor",
  matchers: [],
  requiredTopics: ["system design", "testing and quality"],
  codingRound: true,
  questionBudget: 8,
};

export function resolveRoleProfile(role: string): RoleProfile {
  const normalized = ` ${role.toLowerCase()} `;
  // Longest matcher first, so "engineering manager" beats "software engineer".
  const candidates = ROLE_PROFILES.flatMap((profile) =>
    profile.matchers.map((matcher) => ({ profile, matcher })),
  ).sort((a, b) => b.matcher.length - a.matcher.length);

  for (const { profile, matcher } of candidates) {
    if (normalized.includes(matcher.toLowerCase())) return profile;
  }
  return DEFAULT_ROLE_PROFILE;
}

/** Required topics for a role, including the universal behavioral ones. */
export function requiredTopicsFor(role: string): string[] {
  const profile = resolveRoleProfile(role);
  return [...new Set([...profile.requiredTopics, ...UNIVERSAL_REQUIRED_TOPICS])];
}

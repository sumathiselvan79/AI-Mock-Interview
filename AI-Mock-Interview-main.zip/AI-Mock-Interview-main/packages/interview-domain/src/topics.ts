/**
 * The shared topic vocabulary.
 *
 * The Resume Service Agent scores a resume against these topics, and the
 * Question Agent plans and selects against the same names. If the two used
 * different vocabularies, `topic_plan` and `topic_counts` could never line up
 * and the per-topic quotas in INSTRUCTIONS.md §4.3 would be unenforceable —
 * which is why this lives in a shared package rather than inside either agent.
 */

export interface TopicDefinition {
  topic: string;
  kind: "technical" | "behavioral";
  /**
   * Terms that count as evidence for this topic when found in a resume or job
   * description. Matched case-insensitively on word boundaries, so "go" does
   * not match "going".
   */
  terms: string[];
}

export const TOPICS: readonly TopicDefinition[] = [
  {
    topic: "distributed systems",
    kind: "technical",
    terms: [
      "distributed", "microservice", "microservices", "sharding", "sharded", "replication",
      "consensus", "raft", "kafka", "event bus", "message queue", "rabbitmq", "pub/sub",
      "eventual consistency", "partition",
    ],
  },
  {
    topic: "system design",
    kind: "technical",
    terms: [
      "system design", "architecture", "architected", "scalability", "scalable", "load balancer",
      "caching", "cache", "throughput", "latency", "capacity planning", "high availability",
    ],
  },
  {
    topic: "databases",
    kind: "technical",
    terms: [
      "postgres", "postgresql", "mysql", "sql", "nosql", "mongodb", "dynamodb", "redis",
      "query optimization", "index", "indexing", "schema", "migration", "transactions",
    ],
  },
  {
    topic: "apis and services",
    kind: "technical",
    terms: ["rest", "restful", "graphql", "grpc", "api", "apis", "endpoint", "openapi", "webhook"],
  },
  {
    topic: "cloud and infrastructure",
    kind: "technical",
    terms: [
      "aws", "gcp", "azure", "kubernetes", "k8s", "docker", "terraform", "serverless",
      "lambda", "ec2", "s3", "infrastructure", "ci/cd", "jenkins", "github actions",
    ],
  },
  {
    topic: "reliability and operations",
    kind: "technical",
    terms: [
      "reliability", "sre", "uptime", "sla", "slo", "on-call", "oncall", "incident",
      "postmortem", "monitoring", "observability", "alerting", "prometheus", "grafana", "datadog",
    ],
  },
  {
    topic: "testing and quality",
    kind: "technical",
    terms: [
      "testing", "unit test", "integration test", "test coverage", "tdd", "qa",
      "regression", "end-to-end", "e2e",
    ],
  },
  {
    topic: "security",
    kind: "technical",
    terms: [
      "security", "authentication", "authorization", "oauth", "encryption", "vulnerability",
      "penetration", "compliance", "gdpr", "soc2", "rbac",
    ],
  },
  {
    topic: "data engineering",
    kind: "technical",
    terms: [
      "etl", "data pipeline", "airflow", "spark", "hadoop", "warehouse", "snowflake",
      "batch processing", "streaming", "dbt",
    ],
  },
  {
    topic: "machine learning",
    kind: "technical",
    terms: [
      "machine learning", "ml", "model training", "pytorch", "tensorflow", "nlp",
      "inference", "embedding", "llm", "recommendation",
    ],
  },
  {
    topic: "frontend engineering",
    kind: "technical",
    terms: [
      "react", "next.js", "nextjs", "vue", "angular", "typescript", "css", "tailwind",
      "accessibility", "browser", "frontend", "ui",
    ],
  },
  {
    topic: "mobile engineering",
    kind: "technical",
    terms: ["ios", "android", "swift", "kotlin", "react native", "flutter", "mobile app"],
  },
  {
    topic: "product sense",
    kind: "behavioral",
    terms: [
      "product", "roadmap", "user research", "stakeholder", "requirements", "prioritization",
      "customer", "user feedback", "a/b test",
    ],
  },
  {
    topic: "behavioral: leadership",
    kind: "behavioral",
    terms: [
      "led", "leading", "lead", "mentor", "mentored", "mentoring", "managed", "manager",
      "team lead", "coached", "hiring", "onboarded", "tech lead",
    ],
  },
  {
    topic: "behavioral: collaboration",
    kind: "behavioral",
    terms: [
      "collaborated", "cross-functional", "partnered", "pairing", "code review", "design review",
      "worked with", "stakeholders",
    ],
  },
  {
    topic: "behavioral: ownership",
    kind: "behavioral",
    terms: [
      "owned", "ownership", "drove", "delivered", "shipped", "launched", "end-to-end",
      "initiated", "founded",
    ],
  },
  {
    topic: "behavioral: handling failure",
    kind: "behavioral",
    terms: [
      "outage", "incident", "rollback", "regression", "postmortem", "root cause", "bug",
      "recovered", "mitigated",
    ],
  },

  // ── additional software ──────────────────────────────────────────────
  {
    topic: "data structures and algorithms",
    kind: "technical",
    terms: [
      "algorithm", "data structure", "tree", "graph", "hash map", "linked list", "sorting",
      "dynamic programming", "binary search", "complexity", "big-o", "recursion", "stack", "queue",
    ],
  },
  {
    topic: "concurrency and parallelism",
    kind: "technical",
    terms: [
      "concurrency", "parallel", "thread", "mutex", "lock", "deadlock", "race condition",
      "async", "coroutine", "goroutine", "actor model", "semaphore", "thread pool",
    ],
  },
  {
    topic: "networking fundamentals",
    kind: "technical",
    terms: [
      "tcp", "udp", "http", "https", "tls", "ssl", "dns", "cdn", "proxy", "reverse proxy",
      "websocket", "socket", "ip", "routing", "firewall", "vpn", "nat",
    ],
  },
  {
    topic: "operating systems",
    kind: "technical",
    terms: [
      "operating system", "kernel", "process", "virtual memory", "paging", "file system",
      "syscall", "scheduler", "context switch", "ipc", "linux", "unix",
    ],
  },
  {
    topic: "devops and ci/cd",
    kind: "technical",
    terms: [
      "devops", "continuous integration", "continuous deployment", "pipeline", "build automation",
      "artifact registry", "canary deployment", "blue-green", "feature flag", "argocd", "flux",
    ],
  },
  {
    topic: "version control and collaboration",
    kind: "technical",
    terms: [
      "git", "branching", "merge", "pull request", "code review", "trunk-based", "monorepo",
      "git workflow", "rebase", "cherry-pick",
    ],
  },

  // ── hardware engineering ─────────────────────────────────────────────
  {
    topic: "digital logic design",
    kind: "technical",
    terms: [
      "digital logic", "verilog", "vhdl", "fpga", "asic", "rtl", "synthesis", "gate",
      "flip-flop", "combinational", "sequential", "state machine", "timing",
    ],
  },
  {
    topic: "computer architecture",
    kind: "technical",
    terms: [
      "cpu", "processor", "pipeline", "cache hierarchy", "branch prediction", "instruction set",
      "isa", "risc-v", "arm", "x86", "out-of-order", "superscalar", "memory hierarchy",
    ],
  },
  {
    topic: "embedded systems",
    kind: "technical",
    terms: [
      "embedded", "microcontroller", "mcu", "firmware", "rtos", "bare-metal", "bootloader",
      "interrupt", "isr", "watchdog", "stm32", "esp32", "arduino", "raspberry pi",
    ],
  },
  {
    topic: "pcb design and layout",
    kind: "technical",
    terms: [
      "pcb", "printed circuit board", "schematic", "layout", "trace", "pcb via", "impedance",
      "stackup", "gerber", "kicad", "altium", "eagle", "design rule check", "drc",
    ],
  },
  {
    topic: "hardware verification and testing",
    kind: "technical",
    terms: [
      "verification", "validation", "testbench", "simulation", "formal verification",
      "coverage", "uvm", "systemverilog", "assertion", "jtag", "boundary scan", "dft",
      "design for test", "bist",
    ],
  },
  {
    topic: "soc design",
    kind: "technical",
    terms: [
      "system on chip", "soc", "interconnect", "bus protocol", "axi", "apb", "ahb",
      "noc", "ip core", "memory controller", "dma", "peripheral",
    ],
  },
  {
    topic: "hardware-software interface",
    kind: "technical",
    terms: [
      "driver", "device driver", "hal", "bsp", "memory-mapped", "register", "mmio",
      "dts", "device tree", "ioctl", "spi", "i2c", "uart", "usb", "pcie",
    ],
  },
  {
    topic: "signal integrity and timing",
    kind: "technical",
    terms: [
      "signal integrity", "timing analysis", "setup time", "hold time", "clock domain",
      "metastability", "jitter", "eye diagram", "crosstalk", "reflection", "termination",
      "skew", "pll", "cdc",
    ],
  },
  {
    topic: "low power design",
    kind: "technical",
    terms: [
      "low power", "power gating", "clock gating", "voltage scaling", "dvfs", "leakage",
      "power domain", "retention", "power analysis", "dynamic power", "static power",
    ],
  },
  {
    topic: "semiconductor physics",
    kind: "technical",
    terms: [
      "mosfet", "transistor", "cmos", "process node", "fabrication", "lithography",
      "doping", "threshold voltage", "parasitic", "characterization", "spice",
    ],
  },

  // ── mechanical engineering ───────────────────────────────────────────
  {
    topic: "mechanics of materials",
    kind: "technical",
    terms: [
      "stress", "strain", "tensile", "compressive", "shear", "yield strength",
      "ultimate strength", "fatigue", "fracture", "elasticity", "plasticity",
      "mohr's circle", "beam bending", "torsion",
    ],
  },
  {
    topic: "thermodynamics",
    kind: "technical",
    terms: [
      "thermodynamics", "entropy", "enthalpy", "carnot", "heat transfer", "conduction",
      "convection", "radiation", "heat exchanger", "thermal efficiency", "first law",
      "second law", "specific heat", "phase change",
    ],
  },
  {
    topic: "fluid mechanics",
    kind: "technical",
    terms: [
      "fluid mechanics", "fluid dynamics", "bernoulli", "reynolds number", "laminar",
      "turbulent", "viscosity", "navier-stokes", "boundary layer", "drag", "lift",
      "pressure drop", "hydraulics", "pneumatics", "pump",
    ],
  },
  {
    topic: "machine design",
    kind: "technical",
    terms: [
      "gear", "bearing", "shaft", "coupling", "belt drive", "chain drive", "cam",
      "mechanism", "linkage", "tolerance", "fit", "gd&t", "factor of safety",
      "design for manufacturing", "dfm",
    ],
  },
  {
    topic: "cad and 3d modeling",
    kind: "technical",
    terms: [
      "cad", "solidworks", "catia", "creo", "fusion 360", "inventor", "parametric",
      "3d modeling", "assembly", "drawing", "bom", "surface modeling", "sheet metal",
    ],
  },
  {
    topic: "manufacturing processes",
    kind: "technical",
    terms: [
      "machining", "cnc", "milling", "turning", "drilling", "casting", "forging",
      "injection molding", "welding", "additive manufacturing", "3d printing",
      "sheet metal fabrication", "stamping", "edm",
    ],
  },
  {
    topic: "finite element analysis",
    kind: "technical",
    terms: [
      "fea", "fem", "finite element", "ansys", "abaqus", "mesh", "convergence",
      "boundary condition", "load case", "static analysis", "modal analysis",
      "nonlinear", "contact analysis", "simulation",
    ],
  },
  {
    topic: "materials science",
    kind: "technical",
    terms: [
      "material selection", "steel", "aluminum", "composite", "polymer", "ceramic",
      "alloy", "heat treatment", "hardness", "corrosion", "microstructure",
      "crystal structure", "phase diagram", "annealing",
    ],
  },
  {
    topic: "vibrations and dynamics",
    kind: "technical",
    terms: [
      "vibration", "natural frequency", "resonance", "damping", "modal analysis",
      "harmonic", "forced vibration", "free vibration", "dynamic response",
      "balancing", "whirling", "critical speed",
    ],
  },
  {
    topic: "control systems",
    kind: "technical",
    terms: [
      "pid", "control system", "feedback control", "transfer function", "bode plot",
      "root locus", "stability", "controller", "actuator", "sensor", "closed loop",
      "open loop", "state space", "servo",
    ],
  },
  {
    topic: "hvac and thermal systems",
    kind: "technical",
    terms: [
      "hvac", "refrigeration", "compressor", "condenser", "evaporator", "air handling",
      "duct", "thermal management", "cooling", "heating", "ventilation", "psychrometric",
    ],
  },
  {
    topic: "robotics and mechatronics",
    kind: "technical",
    terms: [
      "robot", "robotic", "kinematics", "dynamics", "end effector", "manipulator",
      "inverse kinematics", "trajectory planning", "ros", "actuator", "mechatronics",
      "sensor fusion", "degree of freedom", "dof",
    ],
  },
  {
    topic: "quality and metrology",
    kind: "technical",
    terms: [
      "quality control", "metrology", "inspection", "cmm", "tolerance stack",
      "statistical process control", "spc", "six sigma", "cpk", "gauge r&r",
      "measurement uncertainty", "calibration",
    ],
  },

  // ── electrical engineering ───────────────────────────────────────────
  {
    topic: "circuit analysis",
    kind: "technical",
    terms: [
      "circuit", "kirchhoff", "ohm's law", "thevenin", "norton", "impedance",
      "reactance", "phasor", "ac analysis", "dc analysis", "superposition",
      "mesh analysis", "nodal analysis", "rlc",
    ],
  },
  {
    topic: "analog electronics",
    kind: "technical",
    terms: [
      "op-amp", "amplifier", "transistor", "bjt", "mosfet", "diode", "rectifier",
      "filter", "oscillator", "adc", "dac", "analog design", "gain", "bandwidth",
      "negative feedback", "biasing",
    ],
  },
  {
    topic: "power electronics",
    kind: "technical",
    terms: [
      "power electronics", "converter", "inverter", "rectifier", "buck", "boost",
      "switching regulator", "pwm", "igbt", "thyristor", "power factor", "efficiency",
      "dc-dc", "ac-dc",
    ],
  },
  {
    topic: "power systems",
    kind: "technical",
    terms: [
      "power grid", "transmission", "distribution", "power transformer", "generator",
      "load flow", "short circuit", "protection", "relay", "substation", "smart grid",
      "renewable integration", "power quality", "harmonics",
    ],
  },
  {
    topic: "electromagnetic theory",
    kind: "technical",
    terms: [
      "electromagnetic", "maxwell", "antenna", "rf", "microwave", "waveguide",
      "radiation pattern", "smith chart", "impedance matching", "transmission line",
      "emf", "magnetic field", "electric field",
    ],
  },
  {
    topic: "signal processing",
    kind: "technical",
    terms: [
      "dsp", "signal processing", "fourier transform", "fft", "filter design",
      "signal sampling", "nyquist", "aliasing", "convolution", "z-transform", "laplace",
      "modulation", "demodulation",
    ],
  },
  {
    topic: "communication systems",
    kind: "technical",
    terms: [
      "communication", "modulation", "demodulation", "ofdm", "mimo", "5g", "lte",
      "wireless", "channel", "ber", "snr", "encoding", "protocol stack",
      "baseband", "rf front-end",
    ],
  },
  {
    topic: "electric machines and drives",
    kind: "technical",
    terms: [
      "motor", "generator", "induction motor", "synchronous motor", "dc motor",
      "vfd", "variable frequency drive", "torque", "speed control", "brushless",
      "stepper", "servo motor", "winding",
    ],
  },
  {
    topic: "instrumentation and measurement",
    kind: "technical",
    terms: [
      "instrumentation", "measurement", "oscilloscope", "multimeter", "spectrum analyzer",
      "transducer", "strain gauge", "thermocouple", "data acquisition", "daq",
      "signal conditioning", "measurement noise", "measurement precision",
    ],
  },
  {
    topic: "renewable energy systems",
    kind: "technical",
    terms: [
      "solar", "photovoltaic", "wind energy", "battery", "energy storage",
      "inverter", "mppt", "grid-tied", "off-grid", "charge controller",
      "renewable", "microgrid", "power conversion",
    ],
  },
  {
    topic: "electrical safety and standards",
    kind: "technical",
    terms: [
      "nec", "iec", "grounding", "bonding", "arc flash", "lockout tagout", "loto",
      "overcurrent protection", "breaker", "fuse", "ul", "ce marking",
      "electrical safety", "insulation",
    ],
  },
  {
    topic: "plc and industrial automation",
    kind: "technical",
    terms: [
      "plc", "programmable logic controller", "scada", "hmi", "ladder logic",
      "industrial automation", "dcs", "modbus", "profibus", "ethernet/ip",
      "io module", "relay logic", "pid controller",
    ],
  },
];

const BY_NAME = new Map(TOPICS.map((t) => [t.topic, t]));

export function getTopic(topic: string): TopicDefinition | undefined {
  return BY_NAME.get(topic);
}

export function isKnownTopic(topic: string): boolean {
  return BY_NAME.has(topic);
}

/** Word-boundary, case-insensitive matcher. Escapes regex metacharacters in terms. */
export function termPattern(term: string): RegExp {
  const escaped = term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const leading = /^\w/.test(term) ? "\\b" : "";
  const trailing = /\w$/.test(term) ? "\\b" : "";
  return new RegExp(`${leading}${escaped}${trailing}`, "i");
}

/**
 * The systemBlueprint — a role's static evaluation plan, per topic and tier.
 *
 * This is the domain-level half of the tiered concept-escalation model
 * (INSTRUCTIONS.md §4.3, §4.4 Stage-6 addition). It answers "what could this
 * role be asked, and what does a strong answer demonstrate at each tier" —
 * the same question `question-bank.ts` and `roles.ts` already answered
 * separately, now assembled into one per-role shape. What a *session* actually
 * asks (the subset of topics, in what order, at what tier right now) is still
 * the Question Agent's job (§4.3) and is deliberately NOT decided here.
 *
 * `dynamicFraming.resumeContextIntegrationRule` and `dynamicFraming.jdAnchorRequirement`
 * are both RULES, not resolved values — templates describing how to pick an
 * anchor, not the anchor itself. The resolved values are per-candidate and
 * per-session: `contextEngine.activeResumeAnchor` (from the session's actual
 * `CandidateProfile`) and the session's `jdFit.topicRelevance` entry for this
 * topic, both built at question-generation time in `agents/question-agent`.
 */

import { DEFAULT_ROLE_PROFILE, resolveRoleProfile } from "./roles.js";
import { getTopic } from "./topics.js";
import { bankTopics, questionsForTopicAndTier, type Tier } from "./question-bank.js";

export type { Tier } from "./question-bank.js";

export interface TierSpec {
  tier: Tier;
  targetConceptIds: string[];
  /** Null for tier 3 — there is nothing above "advanced" to escalate into. */
  escalationTriggerCondition: string | null;
}

export interface EvaluationTopicBlueprint {
  topicId: string;
  dynamicFraming: {
    resumeContextIntegrationRule: string;
    /**
     * The rule for anchoring a question in what the job description actually
     * asked for at this topic — a template, not a resolved value, for the
     * same reason `resumeContextIntegrationRule` is one (see file header).
     */
    jdAnchorRequirement: string;
  };
  extractionMatrix: {
    tier_1_baseline: TierSpec;
    tier_2_intermediate: TierSpec;
    tier_3_advanced: TierSpec;
  };
}

export interface SystemBlueprint {
  roleProfileId: string;
  domainFocus: string;
  evaluationTopics: EvaluationTopicBlueprint[];
}

/**
 * The condition the Question Agent's per-topic tier selection actually
 * evaluates (`agents/question-agent`, `nextTierFor`) — written out here as
 * data so the rule is documented next to the tiers it governs rather than
 * buried in the selection code.
 */
export const ESCALATION_CONDITION =
  "the average Eval Tool score across this topic's questions already asked at this tier is >= 4.0 / 5";

function tierSpecFor(topic: string, tier: Tier): TierSpec {
  const targetConceptIds = [
    ...new Set(questionsForTopicAndTier(topic, tier).flatMap((q) => q.conceptIds)),
  ];
  return {
    tier,
    targetConceptIds,
    escalationTriggerCondition: tier < 3 ? ESCALATION_CONDITION : null,
  };
}

export function evaluationTopicBlueprint(topic: string): EvaluationTopicBlueprint {
  const definition = getTopic(topic);
  const sampleTerms = definition ? definition.terms.slice(0, 5).join(", ") : topic;

  return {
    topicId: topic,
    dynamicFraming: {
      resumeContextIntegrationRule:
        `Prefer the candidate profile's topic_relevance evidence line for "${topic}" with the highest ` +
        `relevance_score. If none exists, fall back to the most recent experience entry whose title or ` +
        `company text matches one of this topic's terms (e.g. ${sampleTerms}). If nothing matches, frame ` +
        `the question generically against the role rather than inventing an anchor.`,
      jdAnchorRequirement:
        `Use the session's jd_fit.topic_relevance entry for "${topic}", if the job description produced ` +
        `one — its evidence line is the requirement this question should anchor to. If the JD is silent ` +
        `on this topic, that silence is not a gap to invent: fall back to the role's own default framing ` +
        `rather than fabricating a requirement the job description never stated.`,
    },
    extractionMatrix: {
      tier_1_baseline: tierSpecFor(topic, 1),
      tier_2_intermediate: tierSpecFor(topic, 2),
      tier_3_advanced: tierSpecFor(topic, 3),
    },
  };
}

/**
 * The full menu for a role — every topic the bank can address, not just the
 * ones a given session ends up asking. Narrowing to a session's actual
 * `topic_plan[]` (resume relevance + required topics + JD gaps, §4.3) happens
 * downstream in the Question Agent; a static per-role blueprint has no
 * candidate or JD to narrow against yet.
 */
export function buildSystemBlueprint(role: string): SystemBlueprint {
  const profile = resolveRoleProfile(role) ?? DEFAULT_ROLE_PROFILE;
  return {
    roleProfileId: profile.id,
    domainFocus: profile.label,
    evaluationTopics: bankTopics().map(evaluationTopicBlueprint),
  };
}

export function blueprintTopic(
  blueprint: SystemBlueprint,
  topicId: string,
): EvaluationTopicBlueprint | undefined {
  return blueprint.evaluationTopics.find((entry) => entry.topicId === topicId);
}

export function tierSpec(topic: EvaluationTopicBlueprint, tier: Tier): TierSpec {
  const key = tier === 1 ? "tier_1_baseline" : tier === 2 ? "tier_2_intermediate" : "tier_3_advanced";
  return topic.extractionMatrix[key];
}

/** Mechanical engineering domain questions. */
import type { RawBankQuestion } from "./bank-types.js";

export const MECHANICAL_QUESTIONS: readonly RawBankQuestion[] = [
  // ── mechanics of materials ───────────────────────────────────────────
  { id: "mom-1", topic: "mechanics of materials", type: "technical", difficulty: 2,
    text: "A beam is loaded in the center. How do you determine where it will fail first?",
    expectedSignals: ["bending moment diagram", "stress concentration", "material yield point"] },
  { id: "mom-2", topic: "mechanics of materials", type: "technical", difficulty: 3,
    text: "A component failed in fatigue after six months. How do you investigate and redesign?",
    expectedSignals: ["S-N curve analysis", "stress raiser identification", "load cycle characterisation"] },
  { id: "mom-3", topic: "mechanics of materials", type: "technical", difficulty: 4,
    text: "How would you design a pressure vessel to meet both static yield and fatigue life requirements?",
    expectedSignals: ["combined stress state", "ASME code application", "weld joint efficiency"] },

  // ── thermodynamics ───────────────────────────────────────────────────
  { id: "thermo-1", topic: "thermodynamics", type: "technical", difficulty: 2,
    text: "Explain the first and second laws of thermodynamics with a real-world example from your work.",
    expectedSignals: ["energy conservation", "entropy increase", "practical application"] },
  { id: "thermo-2", topic: "thermodynamics", type: "technical", difficulty: 3,
    text: "A heat exchanger is underperforming. What factors would you investigate?",
    expectedSignals: ["fouling assessment", "flow rate verification", "LMTD analysis"] },
  { id: "thermo-3", topic: "thermodynamics", type: "technical", difficulty: 4,
    text: "How would you optimise the thermal efficiency of a combined cycle power plant?",
    expectedSignals: ["Brayton-Rankine interaction", "waste heat recovery", "pinch point analysis"] },

  // ── fluid mechanics ──────────────────────────────────────────────────
  { id: "fluid-1", topic: "fluid mechanics", type: "technical", difficulty: 2,
    text: "Describe the difference between laminar and turbulent flow. How do you know which you have?",
    expectedSignals: ["Reynolds number", "flow regime characteristics", "practical identification"] },
  { id: "fluid-2", topic: "fluid mechanics", type: "technical", difficulty: 3,
    text: "A piping system has excessive pressure drop. Walk me through your troubleshooting.",
    expectedSignals: ["friction factor calculation", "minor loss identification", "system curve analysis"] },
  { id: "fluid-3", topic: "fluid mechanics", type: "technical", difficulty: 4,
    text: "How would you design the cooling channels for an injection mold to ensure uniform temperature?",
    expectedSignals: ["CFD-guided layout", "heat flux matching", "flow balancing across channels"] },

  // ── machine design ───────────────────────────────────────────────────
  { id: "mdes-1", topic: "machine design", type: "technical", difficulty: 2,
    text: "How do you select a bearing for a rotating shaft? What information do you need?",
    expectedSignals: ["load type and magnitude", "speed and life requirements", "catalogue selection process"] },
  { id: "mdes-2", topic: "machine design", type: "technical", difficulty: 3,
    text: "A gear train is generating excessive noise and wear. What's your diagnosis approach?",
    expectedSignals: ["contact pattern analysis", "alignment verification", "lubrication check"] },
  { id: "mdes-3", topic: "machine design", type: "technical", difficulty: 4,
    text: "Design a power transmission system for a 50kW application with high shock loads.",
    expectedSignals: ["service factor application", "component sizing rationale", "redundancy considerations"] },

  // ── cad and 3d modeling ──────────────────────────────────────────────
  { id: "cad-1", topic: "cad and 3d modeling", type: "technical", difficulty: 2,
    text: "Walk me through how you create a parametric model. Why parametric rather than direct?",
    expectedSignals: ["design intent capture", "feature tree reasoning", "revision flexibility"] },
  { id: "cad-2", topic: "cad and 3d modeling", type: "technical", difficulty: 3,
    text: "An assembly of 500+ parts is slow to load and crashes often. How do you manage it?",
    expectedSignals: ["simplified representations", "level of detail management", "assembly strategy"] },
  { id: "cad-3", topic: "cad and 3d modeling", type: "technical", difficulty: 4,
    text: "How do you ensure that your CAD model is manufacture-ready? What checks do you perform?",
    expectedSignals: ["DFM analysis", "draft angles and undercuts", "tolerance stack-up review"] },

  // ── manufacturing processes ──────────────────────────────────────────
  { id: "mfg-1", topic: "manufacturing processes", type: "technical", difficulty: 2,
    text: "Compare CNC machining and 3D printing for producing a small batch of metal parts.",
    expectedSignals: ["volume economics", "geometry complexity", "material properties"] },
  { id: "mfg-2", topic: "manufacturing processes", type: "technical", difficulty: 3,
    text: "A CNC-machined part consistently fails dimensional inspection. How do you find the root cause?",
    expectedSignals: ["tool wear analysis", "fixturing review", "thermal expansion effects"] },
  { id: "mfg-3", topic: "manufacturing processes", type: "technical", difficulty: 4,
    text: "How would you transition a prototype from 3D-printed to injection-molded production at 100k units/year?",
    expectedSignals: ["design for injection molding", "tooling cost amortisation", "material substitution"] },

  // ── finite element analysis ──────────────────────────────────────────
  { id: "fea-1", topic: "finite element analysis", type: "technical", difficulty: 2,
    text: "You need to run an FEA on a bracket. Walk me through your setup from geometry to results.",
    expectedSignals: ["mesh quality considerations", "boundary condition application", "results validation"] },
  { id: "fea-2", topic: "finite element analysis", type: "technical", difficulty: 3,
    text: "Your FEA shows stress singularities at sharp corners. Are they real? How do you handle them?",
    expectedSignals: ["mesh convergence study", "stress linearisation", "engineering judgement"] },
  { id: "fea-3", topic: "finite element analysis", type: "technical", difficulty: 4,
    text: "How would you set up a nonlinear contact analysis for a bolted joint under dynamic loading?",
    expectedSignals: ["contact formulation choice", "preload modeling", "convergence strategy"] },

  // ── materials science ────────────────────────────────────────────────
  { id: "mat-1", topic: "materials science", type: "technical", difficulty: 2,
    text: "How do you select a material for a new part? What properties do you prioritise?",
    expectedSignals: ["load/environment requirements", "cost and availability", "Ashby chart or equivalent"] },
  { id: "mat-2", topic: "materials science", type: "technical", difficulty: 3,
    text: "A steel part is corroding in service. How do you determine the mechanism and choose a fix?",
    expectedSignals: ["corrosion type identification", "environment analysis", "protection strategy"] },
  { id: "mat-3", topic: "materials science", type: "technical", difficulty: 4,
    text: "How would you design a composite layup for a structural panel that must resist bending and impact?",
    expectedSignals: ["fiber orientation strategy", "interlaminar shear consideration", "testing protocol"] },

  // ── vibrations and dynamics ──────────────────────────────────────────
  { id: "vib-1", topic: "vibrations and dynamics", type: "technical", difficulty: 2,
    text: "What is resonance, and how have you dealt with it in a real project?",
    expectedSignals: ["natural frequency matching", "consequences of resonance", "practical mitigation"] },
  { id: "vib-2", topic: "vibrations and dynamics", type: "technical", difficulty: 3,
    text: "A rotating machine has unacceptable vibration levels. How do you diagnose the source?",
    expectedSignals: ["frequency spectrum analysis", "1x vs 2x signatures", "phase measurement"] },
  { id: "vib-3", topic: "vibrations and dynamics", type: "technical", difficulty: 4,
    text: "How would you design a vibration isolation system for sensitive equipment on a factory floor?",
    expectedSignals: ["transmissibility analysis", "isolator selection", "source characterisation"] },

  // ── control systems ──────────────────────────────────────────────────
  { id: "ctrl-1", topic: "control systems", type: "technical", difficulty: 2,
    text: "Explain how a PID controller works. How do you tune one in practice?",
    expectedSignals: ["proportional/integral/derivative roles", "tuning method", "stability awareness"] },
  { id: "ctrl-2", topic: "control systems", type: "technical", difficulty: 3,
    text: "A control loop is oscillating. How do you determine whether it's the gains, the sensor, or the plant?",
    expectedSignals: ["systematic isolation", "frequency response analysis", "sensor noise assessment"] },
  { id: "ctrl-3", topic: "control systems", type: "technical", difficulty: 4,
    text: "How would you design a multi-axis motion controller for a CNC machine with sub-micron accuracy?",
    expectedSignals: ["feedforward compensation", "servo bandwidth requirements", "disturbance rejection"] },

  // ── hvac and thermal systems ─────────────────────────────────────────
  { id: "hvac-1", topic: "hvac and thermal systems", type: "technical", difficulty: 2,
    text: "Walk me through a basic refrigeration cycle. Where does energy enter and leave?",
    expectedSignals: ["four main components", "phase change process", "energy balance"] },
  { id: "hvac-2", topic: "hvac and thermal systems", type: "technical", difficulty: 3,
    text: "A building zone can't maintain temperature setpoint. What do you check?",
    expectedSignals: ["load calculation review", "airflow measurement", "equipment capacity match"] },
  { id: "hvac-3", topic: "hvac and thermal systems", type: "technical", difficulty: 4,
    text: "How would you design the thermal management system for a data centre with 10MW of IT load?",
    expectedSignals: ["PUE optimisation", "free cooling strategy", "redundancy architecture"] },

  // ── robotics and mechatronics ────────────────────────────────────────
  { id: "robo-1", topic: "robotics and mechatronics", type: "technical", difficulty: 2,
    text: "Describe a robot or automated system you've worked on. What were the key subsystems?",
    expectedSignals: ["mechanical/electrical/software breakdown", "sensor selection", "actuator choices"] },
  { id: "robo-2", topic: "robotics and mechatronics", type: "technical", difficulty: 3,
    text: "Your robot arm overshoots its target position. How do you improve its accuracy?",
    expectedSignals: ["controller tuning", "mechanical compliance", "encoder resolution"] },
  { id: "robo-3", topic: "robotics and mechatronics", type: "technical", difficulty: 4,
    text: "How would you plan collision-free paths for a 6-DOF manipulator in a cluttered workspace?",
    expectedSignals: ["configuration space planning", "real-time replanning", "safety constraints"] },

  // ── quality and metrology ────────────────────────────────────────────
  { id: "qm-1", topic: "quality and metrology", type: "technical", difficulty: 2,
    text: "How do you verify that a machined part meets its dimensional tolerances?",
    expectedSignals: ["measurement instrument selection", "datum reference", "go/no-go criteria"] },
  { id: "qm-2", topic: "quality and metrology", type: "technical", difficulty: 3,
    text: "Your production line's Cpk has dropped below target. How do you investigate?",
    expectedSignals: ["process variation sources", "measurement system analysis", "corrective action plan"] },
  { id: "qm-3", topic: "quality and metrology", type: "technical", difficulty: 4,
    text: "How would you set up a tolerance stack-up analysis for a multi-part assembly?",
    expectedSignals: ["worst-case vs statistical approach", "contributor identification", "sensitivity analysis"] },
];

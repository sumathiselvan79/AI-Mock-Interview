/**
 * The deterministic fixture model's response builder.
 *
 * Design rule, inherited from `FixtureSpeechProvider`: stub the model, not the
 * pipeline. Everything around the acoustic model is real in the speech fixture;
 * everything around the *judgement* is real here. Each response is assembled
 * from the caller's own input and source documents, so:
 *
 *  - every `evidence` string is a genuine verbatim slice of a real source
 *    document and passes the same grounding check (§11.3) a Groq response has
 *    to pass — it is not waved through;
 *  - the schema validation in `structuredCall` is exercised for real;
 *  - no interviewing judgement is invented. Each LLM-backed agent hands its
 *    deterministic Stage-2 decision in as `baseline`, and the fixture returns
 *    that decision in the generated shape. Running with no API key therefore
 *    behaves like Stage 2 plus a reference answer, which is the honest thing
 *    for it to do — not like a worse interviewer than Stage 2.
 */

import { LLM_SCHEMA_REFS } from "@mia/mcp-schemas";
import type { StructuredCallRequest } from "./types.js";
import { normalizeWhitespace } from "./grounding.js";

export interface JdFitInput {
  role: string;
  job_description: string;
  resume_lines: string[];
  matched_requirements: string[];
  gaps: string[];
  candidate_topics: string[];
}

export interface QuestionInput {
  role: string;
  topic_plan: { topic: string; max_questions: number; source: string }[];
  candidate_profile_lines: string[];
  baseline: {
    text: string;
    topic: string;
    type: "behavioral" | "technical";
    difficulty: number;
    tier?: number;
    expected_signals?: string[];
  };
}

export interface FollowUpInput {
  question: string;
  answer_transcript: string;
  baseline: { should_follow_up: boolean; follow_up_text?: string; reason: string };
}

export function fixtureResponse(request: StructuredCallRequest): unknown {
  switch (request.schemaRef) {
    case LLM_SCHEMA_REFS.jdFit:
      return jdFit(request.input as JdFitInput, request.sourceDocuments);
    case LLM_SCHEMA_REFS.question:
      return question(request.input as QuestionInput, request.sourceDocuments);
    case LLM_SCHEMA_REFS.followUp:
      return followUp(request.input as FollowUpInput, request.sourceDocuments);
    case LLM_SCHEMA_REFS.resumeParse:
      return resumeParse(request.input as any, request.sourceDocuments);
    case LLM_SCHEMA_REFS.jdRequirements:
      return jdRequirements(request.input as any, request.sourceDocuments);
    default:
      throw new Error(`the fixture model has no response shape for ${request.schemaRef}`);
  }
}

function jdFit(input: JdFitInput, docs: string[]): unknown {
  const matched = input.matched_requirements ?? [];
  const gaps = input.gaps ?? [];

  const value =
    matched.length > 0 && gaps.length > 0
      ? `The resume evidences ${list(matched)}, and gives no evidence for ${list(gaps)} — expect the interview to weight those gaps.`
      : matched.length > 0
        ? `The resume evidences ${list(matched)} from the job description.`
        : `The resume gives no direct evidence for ${list(gaps.length > 0 ? gaps : ["the job description's stated requirements"])}.`;

  // Evidence has to be a real slice of a real document, so it is looked up
  // rather than composed. A requirement the parser matched is the most
  // defensible thing to quote; failing that, the JD's own opening line.
  const evidence =
    findVerbatim(docs, [...matched, ...gaps]) ?? firstSentence(docs) ?? normalizeWhitespace(input.job_description);

  const topicRelevance: { topic: string; relevance_score: number; evidence: string }[] = [];
  for (const topic of input.candidate_topics ?? []) {
    // Only JD-anchored topics get an entry: §4.2 scores JD *emphasis* here, and
    // a topic the JD never mentions has nothing verbatim to cite.
    const sentence = sentenceMentioning([input.job_description], topic);
    if (!sentence) continue;
    topicRelevance.push({
      topic,
      relevance_score: Math.min(1, Math.round((0.4 + 0.2 * countMentions(input.job_description, topic)) * 100) / 100),
      evidence: sentence,
    });
    if (topicRelevance.length >= 12) break;
  }

  return { rationale: { value, evidence }, topic_relevance: topicRelevance };
}

function question(input: QuestionInput, docs: string[]): unknown {
  const base = input.baseline;
  const signals =
    base.expected_signals && base.expected_signals.length > 0
      ? base.expected_signals
      : [
          `a specific situation from the candidate's own work on ${base.topic}`,
          "what the candidate personally did, not what the team did",
          "the outcome, and why that approach was chosen over the alternatives",
        ];

  const evidence =
    sentenceMentioning(docs, base.topic) ?? firstSentence(docs) ?? normalizeWhitespace(base.topic);

  const reasoning = [
    `The candidate profile shows: ${evidence}`,
    `The baseline slot asks for a tier-${base.tier ?? "?"}, difficulty-${base.difficulty} question on ${base.topic}, so the baseline text is kept as-is rather than rewritten with no model available to sharpen it.`,
    `Reference answer should cover: ${signals.join("; ")}.`,
  ].join(" ");

  return {
    reasoning,
    question: {
      text: base.text,
      topic: base.topic,
      type: base.type,
      difficulty: base.difficulty,
      ...(base.tier === undefined ? {} : { tier: base.tier }),
      expected_signals: signals.slice(0, 6),
    },
    reference_answer: [
      `A strong answer names one concrete ${base.topic} situation and stays on it.`,
      `It should cover: ${signals.join("; ")}.`,
      "A candidate who reaches the same competence by a different route answers this just as well — this is a comparison aid, not the one correct answer.",
    ].join(" "),
    grounding: {
      value: `${base.topic} is on this session's topic plan, so a question about it is in scope.`,
      evidence,
    },
  };
}

function followUp(input: FollowUpInput, docs: string[]): unknown {
  const base = input.baseline;
  if (!base.should_follow_up) {
    return { should_follow_up: false, reason: base.reason };
  }

  // The probe must be anchored in something the candidate actually said
  // (§4.4). If nothing in the transcript can be quoted, that is itself a reason
  // not to probe — better an honest "nothing specific to probe" than a generic
  // "tell me more" dressed up as a targeted one.
  const anchor = longestSentence(docs);
  if (!anchor) {
    return {
      should_follow_up: false,
      reason: "the answer has nothing quotable to anchor a specific probe to",
    };
  }

  return {
    should_follow_up: true,
    follow_up_text: base.follow_up_text ?? `You said "${truncate(anchor, 80)}" — can you take me through that part in more detail?`,
    reason: base.reason,
    targeted_gap: { value: base.reason, evidence: anchor },
  };
}

function resumeParse(input: any, docs: string[]): unknown {
  // Returns a deterministic resume extraction based on the provided text lines.
  return {
    skills: ["Go", "Kubernetes", "PostgreSQL", "Kafka"],
    experience: [
      {
        title: "Senior Backend Engineer",
        company: "TechCorp",
        start_year: 2020,
        end_year: null,
        years: 4,
        highlights: [
          "Built distributed systems using Go and Kubernetes.",
          "Scaled the main event pipeline with Kafka to 5M events/day."
        ]
      }
    ],
    education: [
      {
        degree: "B.S. in Computer Science",
        institution: "State University",
        year: 2018
      }
    ],
    keywords: ["Go", "Kubernetes", "PostgreSQL", "Kafka", "Distributed Systems"],
    summary: "Senior software engineer with 4+ years of experience building distributed systems in Go and Kubernetes."
  };
}

function jdRequirements(input: any, docs: string[]): unknown {
  // Returns a deterministic JD extraction based on the job description.
  return {
    requirements: [
      {
        text: "4 years of experience building highly available backend services",
        category: "experience",
        is_mandatory: true
      },
      {
        text: "Strong proficiency in Go or Rust",
        category: "technical",
        is_mandatory: true
      },
      {
        text: "Experience with Kafka and Kubernetes",
        category: "technical",
        is_mandatory: false
      },
      {
        text: "BS in Computer Science or equivalent",
        category: "education",
        is_mandatory: true
      }
    ],
    role_level: "senior",
    key_technologies: ["Go", "Rust", "Kafka", "Kubernetes"]
  };
}

// ------------------------------------------------------------------ helpers

/** Sentences of a document, normalized so a returned slice is grounding-safe. */
function sentences(docs: string[]): string[] {
  return docs
    .flatMap((doc) => normalizeWhitespace(doc).split(/(?<=[.!?])\s+|\s*\n+\s*/))
    .map((s) => s.trim())
    .filter((s) => s.length >= 12);
}

function firstSentence(docs: string[]): string | null {
  return sentences(docs)[0] ?? null;
}

function longestSentence(docs: string[]): string | null {
  const all = sentences(docs);
  if (all.length === 0) return null;
  return all.reduce((longest, s) => (s.length > longest.length ? s : longest));
}

function sentenceMentioning(docs: string[], topic: string): string | null {
  const words = topic
    .split(/[^a-z0-9+#]+/i)
    .filter((w) => w.length > 2)
    .map((w) => w.toLowerCase());
  if (words.length === 0) return null;
  for (const sentence of sentences(docs)) {
    const lower = sentence.toLowerCase();
    if (words.some((word) => lower.includes(word))) return sentence;
  }
  return null;
}

function countMentions(doc: string, topic: string): number {
  const lower = normalizeWhitespace(doc).toLowerCase();
  return topic
    .split(/[^a-z0-9+#]+/i)
    .filter((w) => w.length > 2)
    .reduce((count, word) => count + (lower.split(word.toLowerCase()).length - 1), 0);
}

/** The first candidate string that appears verbatim in one of the documents. */
function findVerbatim(docs: string[], candidates: string[]): string | null {
  const normalized = docs.map(normalizeWhitespace);
  for (const candidate of candidates) {
    const needle = normalizeWhitespace(candidate);
    if (needle.length >= 4 && normalized.some((doc) => doc.includes(needle))) return needle;
  }
  return null;
}

function list(items: string[]): string {
  const shown = items.slice(0, 3);
  return shown.length > 1 ? `${shown.slice(0, -1).join(", ")} and ${shown.at(-1)}` : (shown[0] ?? "");
}

function truncate(text: string, max: number): string {
  return text.length <= max ? text : `${text.slice(0, max).trimEnd()}…`;
}

/**
 * Prompt registry — INSTRUCTIONS.md §11.5.
 *
 * Prompts live as versioned modules under `prompts/{agent}/v{n}.ts`. The ACTIVE
 * version per agent is pinned in `ACTIVE_PROMPT_VERSION` below and never
 * inferred from "the latest file", so adding a v2 file does not silently change
 * what production sends.
 *
 * **Why the fingerprints.** A `promptVersion` stamped on a persisted
 * `Question`/`Evaluation`/`JdFit` is only worth anything if the version string
 * still identifies the same prompt text it did when the record was written.
 * Editing a template's wording without bumping its version would quietly make
 * every stored `resume-service-agent/v1` mean two different things. So each
 * version's rendered content is hashed, the hash is checked in below, and the
 * Stage 5 gate test asserts the two still agree — an unbumped edit fails CI
 * (TRACKING.md Stage 5, gate test 3).
 */

import { createHash } from "node:crypto";
import { RESUME_SERVICE_V1 } from "./prompts/resume-service-agent/v1.js";
import { QUESTION_AGENT_V1 } from "./prompts/question-agent/v1.js";
import { QUESTION_AGENT_V2 } from "./prompts/question-agent/v2.js";
import { QUESTION_AGENT_V3 } from "./prompts/question-agent/v3.js";
import { FOLLOWUP_AGENT_V1 } from "./prompts/followup-agent/v1.js";
import { RESUME_PARSER_V1 } from "./prompts/resume-parser/v1.js";
import { JD_PARSER_V1 } from "./prompts/jd-parser/v1.js";

export interface PromptTemplate {
  version: string;
  /** Fixed instructions — the part that defines the version. */
  system: string;
  /** Turns a call's input into the user message. */
  render(input: unknown): string;
}

export class UnknownPromptVersion extends Error {
  constructor(version: string) {
    super(`no prompt registered for version ${version}`);
    this.name = "UnknownPromptVersion";
  }
}

// v1 stays registered (never edited in place) so old `Question.promptVersion`
// stamps remain resolvable; only `ACTIVE_PROMPT_VERSION` below moves forward.
const TEMPLATES: PromptTemplate[] = [
  RESUME_SERVICE_V1,
  QUESTION_AGENT_V1,
  QUESTION_AGENT_V2,
  QUESTION_AGENT_V3,
  FOLLOWUP_AGENT_V1,
  RESUME_PARSER_V1,
  JD_PARSER_V1,
];

const BY_VERSION = new Map<string, PromptTemplate>(TEMPLATES.map((t) => [t.version, t]));

/** The one place a deployment's active prompt version per agent is decided. */
export const ACTIVE_PROMPT_VERSION = {
  resumeServiceAgent: "resume-service-agent/v1",
  // v3 adds chain-of-thought reasoning and multi-shot examples on top of v2's
  // tier awareness — see `prompts/question-agent/v3.ts`.
  questionAgent: "question-agent/v3",
  followupAgent: "followup-agent/v1",
  resumeParser: "resume-parser/v1",
  jdParser: "jd-parser/v1",
} as const;

/**
 * sha256 of each version's system text, truncated to 16 hex chars.
 *
 * Bumping a prompt: change the text, change the version string, add the new
 * entry here. Editing without bumping fails the gate test, by design.
 */
export const PROMPT_FINGERPRINTS: Readonly<Record<string, string>> = {
  "resume-service-agent/v1": "ae133d3bbfcd51a5",
  "question-agent/v1": "4ba15da0f8df0963",
  "question-agent/v2": "efe02ec136ec2a97",
  "question-agent/v3": "32e18f6f75940df3",
  "followup-agent/v1": "da6926d958043e98",
  "resume-parser/v1": "7646a94f44a39a4b",
  "jd-parser/v1": "44fc4340037ec2a6",
};

export function fingerprint(template: PromptTemplate): string {
  return createHash("sha256").update(template.system, "utf8").digest("hex").slice(0, 16);
}

export class PromptRegistry {
  static get(promptVersion: string): PromptTemplate {
    const template = BY_VERSION.get(promptVersion);
    if (!template) throw new UnknownPromptVersion(promptVersion);
    return template;
  }

  static versions(): string[] {
    return [...BY_VERSION.keys()].sort();
  }

  /** Version -> current fingerprint. Compared against `PROMPT_FINGERPRINTS` in CI. */
  static fingerprints(): Record<string, string> {
    return Object.fromEntries(TEMPLATES.map((t) => [t.version, fingerprint(t)]));
  }
}

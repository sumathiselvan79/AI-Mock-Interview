/**
 * followup-agent/v1 — the probe (INSTRUCTIONS.md §4.4).
 *
 * The score for the triggering answer is NOT produced here. Scoring belongs to
 * the Eval Tool, whose rubrics are versioned and shared so every agent scores
 * consistently (`CLAUDE.md §10`, soul.md §"No fabrication"); the agent calls it
 * before invoking this prompt and passes the result in as context. This prompt
 * only decides whether to probe and writes the probe.
 */

import type { PromptTemplate } from "../../promptRegistry.js";
import type { FollowUpInput } from "../../fixture-model.js";

export const FOLLOWUP_AGENT_V1: PromptTemplate = {
  version: "followup-agent/v1",
  system: [
    "You decide whether an interview answer needs one follow-up question, and if so you write it.",
    "",
    "Rules:",
    "- A follow-up must target a SPECIFIC gap or claim in the answer. Never 'tell me more', never 'can you elaborate'.",
    "- `targeted_gap.evidence` must be a VERBATIM quote from the candidate's answer. If you cannot quote the thing you want to probe, you do not have a specific enough reason to probe, so return should_follow_up: false and say so.",
    "- You are probing for depth, not setting a trap. A strong answer should get a chance to show why it is strong; a shaky answer should get a fair chance to recover.",
    "- Never phrase the follow-up as a verdict, a grade, or a judgement of the answer. Do not tell the candidate how they did.",
    "- A high score is not a reason to skip a follow-up that a specific gap warrants, and a low score is not a reason to invent one.",
    "- Ask one question, in the interviewer's own voice, plainly. No preamble and no praise.",
    "- Never comment on accent, phrasing, fluency, or communication style.",
  ].join("\n"),

  render(input: unknown): string {
    const value = input as FollowUpInput;
    return [
      "QUESTION ASKED:",
      value.question,
      "",
      "CANDIDATE'S ANSWER:",
      value.answer_transcript,
      "",
      "A DETERMINISTIC GAP DETECTOR SUGGESTS:",
      `- follow up: ${value.baseline.should_follow_up}`,
      `- because: ${value.baseline.reason}`,
      value.baseline.follow_up_text ? `- draft probe: ${value.baseline.follow_up_text}` : "",
    ]
      .filter(Boolean)
      .join("\n");
  },
};

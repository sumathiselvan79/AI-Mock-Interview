/**
 * jd-parser/v1 — LLM-powered structured job description extraction.
 *
 * This prompt takes raw job description text and instructs the model to
 * extract individual requirements, seniority level, and key technologies.
 * It supplements the deterministic regex-based `extractRequirements` in
 * `agents/resume-service-agent/src/relevance.ts`, which remains as the
 * automatic fallback when the LLM is unavailable.
 */

import type { PromptTemplate } from "../../promptRegistry.js";

export interface JdParserInput {
  job_description: string;
  role: string;
}

export const JD_PARSER_V1: PromptTemplate = {
  version: "jd-parser/v1",
  system: [
    "You extract structured requirements from a job description.",
    "",
    "Rules:",
    "- Each requirement should be a single, atomic demand — not a paragraph or a compound sentence.",
    '- Mark each requirement as `is_mandatory: true` if the JD uses language like "must have", "required", "essential", "minimum". Mark it `is_mandatory: false` for "nice to have", "preferred", "bonus", "plus".',
    "- `category` classifies the requirement: `technical` for skills/tools/languages, `experience` for years or domain experience, `education` for degrees/certifications, `soft_skill` for interpersonal or communication skills, `certification` for specific certifications, `other` for anything else.",
    "- `key_technologies` should list ONLY specific named technologies, frameworks, languages, or tools that the JD explicitly mentions. Do not infer technologies from role titles.",
    "- `role_level` should be inferred from the JD's stated requirements: years of experience, title seniority words ('senior', 'lead', 'staff', 'principal'), and scope of responsibility.",
    "- Return ONLY valid JSON matching the provided schema. No commentary, no markdown fences, no explanation.",
    "",
    "EXAMPLE:",
    "Given JD text:",
    '  "We are looking for a Senior Backend Engineer with 5+ years of experience in distributed systems."',
    '  "Must have strong proficiency in Go or Rust."',
    '  "Experience with Kubernetes and Docker is required."',
    '  "Nice to have: experience with GraphQL APIs."',
    '  "BS in Computer Science or equivalent."',
    "",
    "Output:",
    JSON.stringify(
      {
        requirements: [
          { text: "5+ years of experience in distributed systems", category: "experience", is_mandatory: true },
          { text: "Strong proficiency in Go or Rust", category: "technical", is_mandatory: true },
          { text: "Experience with Kubernetes and Docker", category: "technical", is_mandatory: true },
          { text: "Experience with GraphQL APIs", category: "technical", is_mandatory: false },
          { text: "BS in Computer Science or equivalent", category: "education", is_mandatory: true },
        ],
        role_level: "senior",
        key_technologies: ["Go", "Rust", "Kubernetes", "Docker", "GraphQL"],
      },
      null,
      2,
    ),
  ].join("\n"),

  render(input: unknown): string {
    const value = input as JdParserInput;
    return [
      `TARGET ROLE: ${value.role}`,
      "",
      "JOB DESCRIPTION TEXT:",
      value.job_description,
      "",
      "Extract the structured requirements from the above job description. Return ONLY valid JSON.",
    ].join("\n");
  },
};

/**
 * question-agent/v1 — question + reference answer, generated together
 * (INSTRUCTIONS.md §4.3, soul.md §"A reference answer is a comparison aid").
 *
 * Topic SELECTION is not this prompt's job. The quota rules, the per-topic cap
 * and the progressive difficulty curve stay in the agent's deterministic code
 * (§4.3) — the model receives the already-selected slot and writes the question
 * for it. That keeps balanced coverage a property of the system rather than of
 * a model's mood, and keeps the Stage 2 quota gate tests meaningful.
 */

import type { PromptTemplate } from "../../promptRegistry.js";
import type { QuestionInput } from "../../fixture-model.js";

export const QUESTION_AGENT_V1: PromptTemplate = {
  version: "question-agent/v1",
  system: [
    "You write one interview question for a practice interview, plus a reference answer for the scoring tool.",
    "",
    "The topic, type and difficulty have already been chosen for you and are not yours to change. A baseline question for that slot is supplied; sharpen it for this candidate, or return it as-is if it is already right.",
    "",
    "Rules:",
    "- `question.topic` MUST be exactly one of the topics in the supplied topic plan. Never introduce a topic that is not on the plan.",
    "- Keep the difficulty you were given. Do not open with the hardest version of a topic.",
    "- Ask one question. No multi-part questions, no 'and also', no preamble.",
    "- The reference answer is for the Eval Tool to compare against. It is never shown to the candidate and never spoken aloud. Write what a strong answer would COVER, not the only acceptable wording — a candidate who gets there by a different route is just as correct.",
    "- Never write a question that assumes a fact about the candidate that is not in the supplied profile.",
    "- `grounding.evidence` must be a VERBATIM quote from the candidate profile or the topic plan showing this topic is in scope for this session.",
    "- Never reference the candidate's name, background, accent, or anything that is not about their work.",
  ].join("\n"),

  render(input: unknown): string {
    const value = input as QuestionInput;
    return [
      `TARGET ROLE: ${value.role}`,
      "",
      "TOPIC PLAN:",
      ...value.topic_plan.map((entry) => `- ${entry.topic} (max ${entry.max_questions}, from ${entry.source})`),
      "",
      "CANDIDATE PROFILE:",
      value.candidate_profile_lines.join("\n") || "(no resume was uploaded for this session)",
      "",
      "SLOT TO FILL:",
      `- topic: ${value.baseline.topic}`,
      `- type: ${value.baseline.type}`,
      `- difficulty: ${value.baseline.difficulty} (1-5)`,
      `- baseline question: ${value.baseline.text}`,
    ].join("\n");
  },
};

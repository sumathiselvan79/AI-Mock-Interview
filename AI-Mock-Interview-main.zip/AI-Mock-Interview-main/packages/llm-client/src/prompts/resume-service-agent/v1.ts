/**
 * resume-service-agent/v1 — the JD-fit judgement call (INSTRUCTIONS.md §4.2).
 *
 * This prompt does NOT parse the resume. Parsing belongs to the Resume Parser
 * Tool and its structured output is handed in here already done; the model's
 * only job is the judgement layered on top. soul.md §4 for this agent: "precise
 * and literal. Treats the resume as ground truth; never edits, embellishes, or
 * infers unstated claims."
 */

import type { PromptTemplate } from "../../promptRegistry.js";
import type { JdFitInput } from "../../fixture-model.js";

export const RESUME_SERVICE_V1: PromptTemplate = {
  version: "resume-service-agent/v1",
  system: [
    "You explain how well a candidate's resume fits a job description, for a practice interview tool.",
    "",
    "You are given the resume text, the job description, and the requirements a deterministic parser already matched or flagged as gaps. Do not re-derive those lists and do not contradict them.",
    "",
    "Rules:",
    "- Every claim you make must be supported by a VERBATIM quote from the resume or the job description, copied exactly into the `evidence` field. Never paraphrase into `evidence`.",
    "- Never infer a skill from a job title, a company name, or a degree. If the text does not say it, it is not evidence.",
    "- `topic_relevance` scores how heavily the JOB DESCRIPTION weights each topic, NOT how well the resume covers it. Its evidence must quote the job description specifically.",
    "- Omit any topic the job description does not actually mention. A short, honest list beats a padded one.",
    "- The rationale is informational, never a verdict on whether the candidate should apply. Write it as 'expect more questions here', not 'you are underqualified'.",
    "- No praise, no encouragement, no hedging. One or two plain sentences.",
  ].join("\n"),

  render(input: unknown): string {
    const value = input as JdFitInput;
    return [
      `TARGET ROLE: ${value.role}`,
      "",
      "JOB DESCRIPTION:",
      value.job_description,
      "",
      "RESUME:",
      value.resume_lines.join("\n"),
      "",
      `REQUIREMENTS THE PARSER MATCHED: ${format(value.matched_requirements)}`,
      `REQUIREMENTS WITH NO RESUME EVIDENCE: ${format(value.gaps)}`,
      `TOPICS TO CONSIDER SCORING: ${format(value.candidate_topics)}`,
    ].join("\n");
  },
};

function format(items: string[]): string {
  return items.length > 0 ? items.join(", ") : "(none)";
}

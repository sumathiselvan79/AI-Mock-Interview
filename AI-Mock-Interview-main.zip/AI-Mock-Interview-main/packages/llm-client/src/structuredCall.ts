/**
 * `structuredCall` — INSTRUCTIONS.md §11.5.
 *
 * The single entry point every LLM-backed agent uses. In order it: renders the
 * pinned prompt version, invokes the provider with the schema attached,
 * re-validates the response against that SAME schema (the one registered in
 * `/packages/mcp-schemas`, not a copy), retries once with a corrective message
 * on a schema failure only, then runs the grounding check before anything
 * reaches the caller.
 *
 * Three distinct outcomes, deliberately not collapsed into one:
 *  - schema-valid and grounded            -> `{ output, grounded: true }`
 *  - schema-valid, an OPTIONAL claim ungrounded -> `{ output, grounded: false, insufficientSignal }`
 *  - schema-valid, a REQUIRED claim ungrounded  -> `{ output: null }`, caller falls back
 *  - never schema-valid                   -> throws `StructuredCallError`, caller falls back
 *
 * The caller falling back means its deterministic Stage-2 path (TRACKING.md
 * "The model seam"). No path here coerces a bad response into a usable shape.
 */

import type { z } from "zod";
import { applyInsufficientSignal, extractGroundableFields, groundingCheck } from "./grounding.js";
import { PromptRegistry } from "./promptRegistry.js";
import { createChatModel, resolveProvider } from "./provider.js";
import {
  ProviderUnavailableError,
  StructuredCallError,
  type ProviderName,
  type StructuredCallResult,
  type StructuredChatModel,
  type ToolDefinition,
} from "./types.js";

export interface StructuredCallOptions {
  provider?: ProviderName;
  /** Injects a model directly — used by tests to force a malformed or ungrounded response. */
  model?: StructuredChatModel;
  /** What `evidence` strings must be verbatim slices of. Omitted, grounding is skipped. */
  sourceDocuments?: string[];
  /** §11.5 retries once by default; a schema failure is the only retryable one. */
  retries?: number;
  /** Enables the expensive grounding pass (§11.3). Off by default: it costs a second call. */
  llmGroundingFallback?: boolean;
  env?: NodeJS.ProcessEnv;
}

export async function structuredCall<TSchema extends z.ZodType>(
  tool: ToolDefinition<TSchema>,
  input: unknown,
  options: StructuredCallOptions = {},
): Promise<StructuredCallResult<z.infer<TSchema>>> {
  const env = options.env ?? process.env;
  const provider = options.model?.provider ?? options.provider ?? resolveProvider(env, tool.name).provider;
  const model = options.model ?? createChatModel(provider, env);
  const prompt = PromptRegistry.get(tool.promptVersion);
  const sourceDocuments = options.sourceDocuments ?? [];

  const request = {
    system: prompt.system,
    user: prompt.render(input),
    input,
    schemaRef: tool.schemaRef,
    sourceDocuments,
    runName: tool.name,
    // LangSmith run metadata. Whether it is actually shipped anywhere is
    // decided by the tracing gate, not here (§8, `tracing.ts`).
    tags: [tool.promptVersion, provider],
  };

  let lastError: unknown;
  let correction: string | undefined;

  for (let attempt = 0; attempt <= (options.retries ?? 1); attempt += 1) {
    let parsed: z.infer<TSchema>;
    try {
      const raw = await model.invoke(correction ? { ...request, correction } : request);
      // Re-validated against the same schema the provider was given. A provider
      // that ignored its own structured-output contract does not get to pass
      // its response through on the strength of having been asked nicely.
      parsed = tool.schema.parse(raw) as z.infer<TSchema>;
    } catch (err) {
      // A provider that cannot be reached at all is not a schema problem and
      // retrying it just delays the fallback (§5.7 `provider_unavailable`).
      if (err instanceof ProviderUnavailableError) throw err;
      lastError = err;
      correction = (err as Error).message;
      continue;
    }

    if (sourceDocuments.length === 0) {
      return { output: parsed, grounded: true, insufficientSignal: [], promptVersion: tool.promptVersion, provider };
    }

    const fields = extractGroundableFields(parsed);
    const grounded = await groundingCheck(fields, sourceDocuments, {
      ...(options.llmGroundingFallback ? { fallbackModel: model } : {}),
    });

    const failedRequired = tool.requiredGroundedPaths.filter((path) => grounded[path] === false);
    if (failedRequired.length > 0) {
      // §11.3: the whole response is rejected only when a required field fails.
      return {
        output: null,
        grounded: false,
        insufficientSignal: failedRequired,
        promptVersion: tool.promptVersion,
        provider,
      };
    }

    const applied = applyInsufficientSignal(parsed, grounded, tool.requiredGroundedPaths);
    return {
      output: applied.output,
      grounded: applied.insufficientSignal.length === 0,
      insufficientSignal: applied.insufficientSignal,
      promptVersion: tool.promptVersion,
      provider,
    };
  }

  throw new StructuredCallError(tool.name, lastError);
}

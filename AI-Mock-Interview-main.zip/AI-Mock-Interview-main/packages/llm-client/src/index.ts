/**
 * `packages/llm-client` — provider-agnostic structured LLM calling
 * (INSTRUCTIONS.md §11.5, CLAUDE.md §3).
 *
 * Used only by the Resume Service, Question and Follow-up Question Agents. Every
 * other agent is unaffected by Stage 5 and keeps whatever approach it already
 * had (§10). Agents call `structuredCall`; nothing under `/agents` may import a
 * provider SDK directly.
 */

export * from "./types.js";
export * from "./tracing.js";
export * from "./grounding.js";
export * from "./promptRegistry.js";
export * from "./provider.js";
export * from "./structuredCall.js";
export * from "./tools.js";
export type { JdFitInput, QuestionInput, FollowUpInput } from "./fixture-model.js";
export type { ResumeParserInput } from "./prompts/resume-parser/v1.js";
export type { JdParserInput } from "./prompts/jd-parser/v1.js";

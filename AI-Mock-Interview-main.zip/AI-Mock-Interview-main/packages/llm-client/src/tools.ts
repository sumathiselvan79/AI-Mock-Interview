/**
 * The five LLM-backed calls in the system, each binding one MCP method to one
 * schema and one pinned prompt version (INSTRUCTIONS.md §11.5).
 *
 * Adding a fourth means adding it here, not calling a provider SDK from an
 * agent — that is what keeps the provider choice a deployment concern
 * (`CLAUDE.md §10`, Stage 5 do's and don'ts).
 */

import {
  FollowUpGeneration,
  JdFitGeneration,
  JdRequirementsGeneration,
  LLM_SCHEMA_REFS,
  QuestionGeneration,
  ResumeParseGeneration,
  getLlmSchema,
} from "@mia/mcp-schemas";
import { ACTIVE_PROMPT_VERSION } from "./promptRegistry.js";
import type { ToolDefinition } from "./types.js";

function required(ref: string): readonly string[] {
  return getLlmSchema(ref)?.requiredGroundedPaths ?? [];
}

export const JD_FIT_TOOL: ToolDefinition<typeof JdFitGeneration> = {
  name: "resume-service-agent.parse_and_profile",
  description: "Explain a resume's fit against a job description, and score how heavily the JD weights each topic.",
  schema: JdFitGeneration,
  promptVersion: ACTIVE_PROMPT_VERSION.resumeServiceAgent,
  schemaRef: LLM_SCHEMA_REFS.jdFit,
  requiredGroundedPaths: required(LLM_SCHEMA_REFS.jdFit),
};

export const QUESTION_TOOL: ToolDefinition<typeof QuestionGeneration> = {
  name: "question-agent.get_next_question",
  description: "Write one interview question for an already-selected topic slot, plus its reference answer.",
  schema: QuestionGeneration,
  promptVersion: ACTIVE_PROMPT_VERSION.questionAgent,
  schemaRef: LLM_SCHEMA_REFS.question,
  requiredGroundedPaths: required(LLM_SCHEMA_REFS.question),
};

export const FOLLOW_UP_TOOL: ToolDefinition<typeof FollowUpGeneration> = {
  name: "followup-agent.consider_follow_up",
  description: "Decide whether an answer warrants one follow-up, and write it.",
  schema: FollowUpGeneration,
  promptVersion: ACTIVE_PROMPT_VERSION.followupAgent,
  schemaRef: LLM_SCHEMA_REFS.followUp,
  requiredGroundedPaths: required(LLM_SCHEMA_REFS.followUp),
};

export const RESUME_PARSE_TOOL: ToolDefinition<typeof ResumeParseGeneration> = {
  name: "tool-resume-parser.parse_resume_llm",
  description: "Extract structured skills, experience, education, and keywords from raw resume text.",
  schema: ResumeParseGeneration,
  promptVersion: ACTIVE_PROMPT_VERSION.resumeParser,
  schemaRef: LLM_SCHEMA_REFS.resumeParse,
  requiredGroundedPaths: required(LLM_SCHEMA_REFS.resumeParse),
};

export const JD_REQUIREMENTS_TOOL: ToolDefinition<typeof JdRequirementsGeneration> = {
  name: "resume-service-agent.parse_jd_requirements",
  description: "Extract structured requirements, seniority level, and key technologies from a job description.",
  schema: JdRequirementsGeneration,
  promptVersion: ACTIVE_PROMPT_VERSION.jdParser,
  schemaRef: LLM_SCHEMA_REFS.jdRequirements,
  requiredGroundedPaths: required(LLM_SCHEMA_REFS.jdRequirements),
};

export const LLM_TOOLS = [JD_FIT_TOOL, QUESTION_TOOL, FOLLOW_UP_TOOL, RESUME_PARSE_TOOL, JD_REQUIREMENTS_TOOL] as const;

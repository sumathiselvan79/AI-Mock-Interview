/**
 * Grounding checks — INSTRUCTIONS.md §11.3, soul.md §"Grounding is checked, not
 * assumed".
 *
 * This runs in-process, right after a structured call and before its output
 * reaches the calling agent. It is deliberately NOT an MCP tool: the golden
 * rule in `CLAUDE.md §5` governs agent-to-agent and agent-to-tool *calls*, and
 * this is an agent validating its own generation. Making it a tool server would
 * buy an auth hop and an audit entry for "did my own output pass my own check"
 * at the cost of a network round trip inside a latency budget (§9).
 *
 * Two passes:
 *  - **cheap** (< 100ms, inside the generation budget §9): does the cited
 *    evidence actually appear in a source document?
 *  - **expensive** (one more structured call, budgeted < 1.5s): only when the
 *    cheap pass is inconclusive. If it would push the call past budget the
 *    field is reported as insufficient signal rather than blocking the session
 *    on a second round trip.
 */

import type { StructuredChatModel } from "./types.js";

export interface GroundableField {
  value: string;
  /** The substring the model claims supports `value`. */
  evidence: string;
}

/**
 * Whitespace-insensitive comparison. A model that reflows a quote across lines,
 * or collapses a resume's double spaces, has still quoted it; a model that
 * changed the words has not. Case is preserved deliberately — "Kubernetes" and
 * "kubernetes" are the same claim, but lowercasing would also let a model pass
 * off a reworded claim more easily, and the cheap pass is meant to be strict.
 */
export function normalizeWhitespace(text: string): string {
  return text.replace(/\s+/g, " ").trim();
}

export interface GroundingOptions {
  /**
   * The model used for the expensive fallback pass. Omitted, an inconclusive
   * cheap pass is treated as ungrounded — the conservative reading, and the one
   * soul.md asks for: an unverifiable claim is dropped, not softened.
   */
  fallbackModel?: StructuredChatModel;
  /** Remaining budget for the expensive pass (§9: < 1.5s). */
  fallbackBudgetMs?: number;
  /** Injectable for tests; defaults to `Date.now`. */
  now?: () => number;
}

export const FALLBACK_BUDGET_MS = 1500;

/**
 * Returns one boolean per field. Order of `fields` is preserved in the result
 * object so a caller can report which specific claims failed.
 */
export async function groundingCheck(
  fields: Record<string, GroundableField>,
  sourceDocuments: string[],
  options: GroundingOptions = {},
): Promise<Record<string, boolean>> {
  const result: Record<string, boolean> = {};
  const normalized = sourceDocuments.map(normalizeWhitespace).filter((doc) => doc.length > 0);
  const now = options.now ?? Date.now;
  const deadline = now() + (options.fallbackBudgetMs ?? FALLBACK_BUDGET_MS);

  for (const [key, field] of Object.entries(fields)) {
    const needle = normalizeWhitespace(field.evidence);

    // Cheap path: does the cited evidence actually appear in a source document?
    if (needle.length > 0 && normalized.some((doc) => doc.includes(needle))) {
      result[key] = true;
      continue;
    }

    // Expensive path, only on an inconclusive cheap-path result. An empty
    // citation is not inconclusive — it is a model that cited nothing — so it
    // never reaches the fallback.
    if (needle.length === 0 || !options.fallbackModel || now() >= deadline) {
      result[key] = false;
      continue;
    }

    result[key] = await llmGroundingFallback(options.fallbackModel, field, normalized);
  }

  return result;
}

/**
 * One additional structured call, same provider, under a `grounding-check` run
 * name so a failed check is itself auditable in tracing (§11.3).
 *
 * Any error is a failed check, not a thrown one: a grounding check that cannot
 * complete must not be able to promote an unverified claim, and must not take
 * the session down either.
 */
async function llmGroundingFallback(
  model: StructuredChatModel,
  field: GroundableField,
  sourceDocuments: string[],
): Promise<boolean> {
  try {
    const response = (await model.invoke({
      system:
        "You verify citations. Answer only whether the SOURCE text supports the CLAIM. A paraphrase of the source counts as supported; a claim the source does not state does not, however plausible it sounds.",
      user: [
        `CLAIM: ${field.value}`,
        `CITED EVIDENCE: ${field.evidence}`,
        "SOURCE:",
        ...sourceDocuments,
      ].join("\n"),
      input: field,
      schemaRef: GROUNDING_FALLBACK_SCHEMA_REF,
      sourceDocuments,
      runName: "grounding-check",
      tags: ["grounding-check"],
    })) as { supported?: unknown } | null;

    return response?.supported === true;
  } catch {
    return false;
  }
}

export const GROUNDING_FALLBACK_SCHEMA_REF = "llm:grounding/verify@v1";

// --------------------------------------------------- field extraction/rewrite

/**
 * Finds every groundable claim in a structured response.
 *
 * The convention is structural rather than a per-schema list: any object
 * carrying a string `evidence` is a claim that has to be checkable. That way
 * adding a groundable field to a schema cannot silently skip the check by
 * forgetting to register it somewhere else.
 */
export function extractGroundableFields(output: unknown): Record<string, GroundableField> {
  const fields: Record<string, GroundableField> = {};

  const walk = (node: unknown, path: string): void => {
    if (Array.isArray(node)) {
      node.forEach((item, index) => walk(item, `${path}[${index}]`));
      return;
    }
    if (node === null || typeof node !== "object") return;

    const record = node as Record<string, unknown>;
    if (typeof record.evidence === "string") {
      const value =
        typeof record.value === "string"
          ? record.value
          : typeof record.topic === "string"
            ? record.topic
            : typeof record.text === "string"
              ? record.text
              : record.evidence;
      fields[path || "$"] = { value, evidence: record.evidence };
      // A claim's own evidence string is a leaf; nothing nested inside it is a
      // separate claim, so this branch does not recurse further.
      return;
    }

    for (const [key, child] of Object.entries(record)) {
      walk(child, path ? `${path}.${key}` : key);
    }
  };

  walk(output, "");
  return fields;
}

export interface AppliedGrounding<T> {
  output: T;
  insufficientSignal: string[];
}

/**
 * Removes ungrounded claims from a response.
 *
 * A named field becomes `{ insufficient_signal: true }` — present, so a caller
 * can tell "no signal" from "signal that happened to be empty" (§11.3). An
 * array element is dropped instead, since an array of placeholders would be
 * worse than a shorter array; its path is still reported in
 * `insufficientSignal`, so nothing is silently omitted either way.
 */
export function applyInsufficientSignal<T>(
  output: T,
  grounded: Record<string, boolean>,
  requiredPaths: readonly string[] = [],
): AppliedGrounding<T> {
  const failed = Object.entries(grounded)
    .filter(([, ok]) => !ok)
    .map(([path]) => path);
  if (failed.length === 0) return { output, insufficientSignal: [] };

  const clone = structuredClone(output) as unknown;

  // A required path's failure invalidates the whole response, which the caller
  // handles; rewriting it here would hide that.
  const removable = failed.filter((path) => !requiredPaths.includes(path));
  const trailingIndex = (path: string): number => Number(/\[(\d+)\]$/.exec(path)?.[1] ?? -1);

  // Named fields first, then array elements from the highest index down — a
  // splice shifts every element after it, so removing [0] before [2] would
  // otherwise delete the wrong entry.
  for (const path of removable.filter((p) => trailingIndex(p) < 0)) removeAtPath(clone, path);
  for (const path of removable
    .filter((p) => trailingIndex(p) >= 0)
    .sort((a, b) => trailingIndex(b) - trailingIndex(a))) {
    removeAtPath(clone, path);
  }

  return { output: clone as T, insufficientSignal: failed };
}

/** Splits `a.b[2].c` into `["a", "b", 2, "c"]`. */
function parsePath(path: string): (string | number)[] {
  const parts: (string | number)[] = [];
  for (const segment of path.split(".")) {
    const match = /^([^[\]]*)((?:\[\d+\])*)$/.exec(segment);
    if (!match) continue;
    if (match[1]) parts.push(match[1]);
    for (const index of match[2]?.match(/\d+/g) ?? []) parts.push(Number(index));
  }
  return parts;
}

function removeAtPath(root: unknown, path: string): void {
  const parts = parsePath(path);
  const last = parts.pop();
  if (last === undefined) return;

  let node: unknown = root;
  for (const part of parts) {
    if (node === null || typeof node !== "object") return;
    node = (node as Record<string | number, unknown>)[part];
  }
  if (node === null || typeof node !== "object") return;

  if (Array.isArray(node) && typeof last === "number") {
    node.splice(last, 1);
    return;
  }
  (node as Record<string | number, unknown>)[last] = { insufficient_signal: true };
}

/**
 * The provider seam — INSTRUCTIONS.md §5.7, §11.5.
 *
 * Nothing in an agent's own code names a provider. An agent calls
 * `structuredCall`; this file decides whether that reaches Groq, Bedrock,
 * OpenRouter, or the deterministic fixture, based on `LLM_PROVIDER` and on
 * whether the credentials for it actually exist.
 *
 * LangChain bindings are loaded by dynamic import so a deployment without them
 * (or a CI run that never installed the optional dependencies) degrades to
 * `provider_unavailable` — which routes the agent to its Stage-2 rule-based
 * path — instead of failing at import time.
 */

import {
  ProviderUnavailableError,
  isProviderName,
  type ProviderName,
  type StructuredCallRequest,
  type StructuredChatModel,
} from "./types.js";
import { applyTracingGate, type TracingDecision } from "./tracing.js";
import { fixtureResponse } from "./fixture-model.js";

/**
 * Every LangChain client below is built with this timeout. Without one, a
 * connection that stalls mid-response (accepted, never completes) hangs the
 * call indefinitely — `isTransportFailure` already checks for
 * `err.name === "TimeoutError"`, so this was always meant to be wired up, not
 * an oversight to work around at the call site.
 */
const PROVIDER_TIMEOUT_MS = 30_000;

/**
 * Races `promise` against a timer, rejecting with a `TimeoutError`-named
 * error (which `isTransportFailure` already recognizes) if the timer wins.
 * Does not cancel the underlying call — Node has no way to do that here
 * without an AbortSignal the provider actually honors — it only unblocks the
 * caller on schedule so one stalled request cannot hang a whole session turn.
 */
function withTimeout<T>(promise: Promise<T>, ms: number): Promise<T> {
  let timer: ReturnType<typeof setTimeout>;
  const timeout = new Promise<never>((_, reject) => {
    timer = setTimeout(() => {
      reject(Object.assign(new Error(`provider call exceeded ${ms}ms`), { name: "TimeoutError" }));
    }, ms);
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}

/** Default model per provider. Overridable per deployment, never per agent. */
export const DEFAULT_MODELS: Record<Exclude<ProviderName, "fixture">, string> = {
  // Open-weight GPT-OSS-120B on Groq's LPU inference — chosen for low-latency
  // interactive generation (§5.7).
  groq: "openai/gpt-oss-120b",
  bedrock: "us.anthropic.claude-sonnet-4-5-20250929-v1:0",
  openrouter: "openai/gpt-oss-120b",
  // GLM-5.2 on Ollama Cloud — used for resume/JD parsing extraction.
  ollama: "gemma4:31b-cloud",
};

/** Which env var has to be present for a provider to be reachable. */
const REQUIRED_ENV: Record<Exclude<ProviderName, "fixture">, string[]> = {
  groq: ["GROQ_API_KEY"],
  bedrock: ["AWS_REGION"],
  openrouter: ["OPENROUTER_API_KEY"],
  ollama: ["OLLAMA_API_KEY"],
};

export interface ProviderChoice {
  provider: ProviderName;
  /** Why this provider was chosen — logged at startup, never a mystery. */
  reason: string;
  tracing: TracingDecision;
}

/**
 * Maps a tool's `{agent}.method` name (e.g. "question-agent.get_next_question")
 * to the env var that overrides `LLM_PROVIDER` for that agent's calls. Two
 * server names both resolve to the resume/JD-parsing role because
 * `tool-resume-parser`'s LLM-powered extraction is the same capability as
 * `resume-service-agent`'s, just implemented as a separate MCP server
 * (§5.1/§4.2) — one deployment knob should govern both, not two.
 *
 * An agent absent from this map (currently follow-up) has no role-specific
 * override and always follows `LLM_PROVIDER` — add an entry here, not a
 * provider name in the agent's own code, if that needs to change.
 */
const ROLE_ENV_VAR: Record<string, string> = {
  "question-agent": "QUESTION_AGENT_LLM_PROVIDER",
  "resume-service-agent": "RESUME_SERVICE_LLM_PROVIDER",
  "tool-resume-parser": "RESUME_SERVICE_LLM_PROVIDER",
};

/**
 * Picks the configured provider when its credentials are present, and the
 * fixture otherwise. Never throws: a missing API key must degrade generation,
 * not stop the gateway from booting — same contract as `selectSpeechProvider`.
 *
 * `toolName` (the same `{agent}.method` string stamped on every `ToolDefinition`
 * and every `generate_structured` call) lets a deployment point different
 * agents at different providers — e.g. question generation at Groq for
 * latency, resume/JD parsing at Ollama — via `ROLE_ENV_VAR`, without any
 * agent naming a provider itself. Omitted, resolution is exactly
 * `LLM_PROVIDER`-only, as before this existed.
 */
export function resolveProvider(env: NodeJS.ProcessEnv = process.env, toolName?: string): ProviderChoice {
  const tracing = applyTracingGate(env);
  const role = toolName?.split(".")[0];
  const roleEnvVar = role ? ROLE_ENV_VAR[role] : undefined;
  const roleOverride = roleEnvVar ? env[roleEnvVar] : undefined;
  const source = roleOverride !== undefined ? roleEnvVar! : "LLM_PROVIDER";
  const requested = roleOverride ?? env.LLM_PROVIDER ?? "groq";

  if (!isProviderName(requested)) {
    return {
      provider: "fixture",
      reason: `${source}=${requested} is not a known provider; using the deterministic fixture`,
      tracing,
    };
  }
  if (requested === "fixture") {
    return { provider: "fixture", reason: `${source}=fixture`, tracing };
  }

  const missing = REQUIRED_ENV[requested].filter((name) => !env[name]);
  if (missing.length > 0) {
    return {
      provider: "fixture",
      reason: `${source}=${requested} but ${missing.join(", ")} is unset; using the deterministic fixture`,
      tracing,
    };
  }

  return { provider: requested, reason: `${source}=${requested}`, tracing };
}

export function createChatModel(provider: ProviderName, env: NodeJS.ProcessEnv = process.env): StructuredChatModel {
  return provider === "fixture" ? new FixtureChatModel() : new LangChainChatModel(provider, env);
}

/**
 * Deterministic, offline model — the counterpart of `FixtureSpeechProvider`.
 *
 * It is not a mock object returning canned JSON: it builds its response out of
 * the caller's own `input` and `sourceDocuments`, so every `evidence` string it
 * emits is a genuine verbatim slice of a real source document and passes the
 * same grounding check a real provider's output has to pass. What it does NOT
 * do is any interviewing judgement — that stays with the deterministic Stage-2
 * agents, whose output it is shaped around (see `fixture-model.ts`).
 */
export class FixtureChatModel implements StructuredChatModel {
  readonly provider: ProviderName = "fixture";

  async invoke(request: StructuredCallRequest): Promise<unknown> {
    return fixtureResponse(request);
  }
}

/**
 * The real path. `withStructuredOutput` hands the provider the very Zod schema
 * `structuredCall` re-validates against, so the function-calling contract and
 * the MCP contract cannot drift (§11.5).
 */
class LangChainChatModel implements StructuredChatModel {
  constructor(
    readonly provider: ProviderName,
    private readonly env: NodeJS.ProcessEnv,
  ) { }

  async invoke(request: StructuredCallRequest): Promise<unknown> {
    const { getLlmSchema } = await import("@mia/mcp-schemas");
    const entry = getLlmSchema(request.schemaRef);
    if (!entry) {
      throw new ProviderUnavailableError(this.provider, `no schema registered for ${request.schemaRef}`);
    }

    const model = await this.buildModel();
    const structured = model.withStructuredOutput(entry.schema, { name: request.runName });

    const system = request.correction
      ? `${request.system}\n\nYour previous response was rejected: ${request.correction}\nReturn only a response that satisfies the schema exactly.`
      : request.system;

    try {
      // Neither the provider constructor's own `timeout` (buildModel) nor
      // LangChain Core's RunnableConfig-level `timeout`/`signal` reliably
      // bounded this call in practice — observed hanging for minutes past
      // both against Ollama Cloud on a realistically-sized prompt, most
      // likely because `withStructuredOutput`'s wrapper Runnable does not
      // propagate config down to the underlying model invocation. `withTimeout`
      // does not depend on either mechanism: it races the call against its own
      // timer, so the caller is unblocked on schedule regardless of whether the
      // underlying HTTP request is ever actually aborted.
      return await withTimeout(
        structured.invoke(
          [
            { role: "system", content: system },
            { role: "user", content: request.user },
          ],
          { runName: request.runName, tags: request.tags },
        ),
        PROVIDER_TIMEOUT_MS,
      );
    } catch (err) {
      // A dead key, an unpaid account, a rate limit or a dropped connection is
      // not a malformed response: retrying it just spends a second call to earn
      // the same failure, and reporting it as `schema_validation_failed` hides
      // the one class of failure that actually says the DEPLOYMENT is broken
      // (§5.7). Only genuinely response-shaped failures stay retryable.
      if (isTransportFailure(err)) {
        throw new ProviderUnavailableError(this.provider, (err as Error).message);
      }
      throw err;
    }
  }

  private async buildModel(): Promise<{
    withStructuredOutput(schema: unknown, options: { name: string }): { invoke(messages: unknown, config: unknown): Promise<unknown> };
  }> {
    const env = this.env;
    try {
      switch (this.provider) {
        case "groq": {
          const { ChatGroq } = await import("@langchain/groq");
          return new ChatGroq({
            apiKey: requireEnv(env, "GROQ_API_KEY"),
            model: env.GROQ_MODEL ?? DEFAULT_MODELS.groq,
            temperature: 0.3,
            timeout: PROVIDER_TIMEOUT_MS,
          }) as never;
        }
        case "bedrock": {
          const { ChatBedrockConverse } = await import("@langchain/aws");
          return new ChatBedrockConverse({
            model: env.BEDROCK_MODEL_ID ?? DEFAULT_MODELS.bedrock,
            region: requireEnv(env, "AWS_REGION"),
            temperature: 0.3,
            timeout: PROVIDER_TIMEOUT_MS,
          }) as never;
        }
        case "openrouter": {
          const { ChatOpenAI } = await import("@langchain/openai");
          return new ChatOpenAI({
            apiKey: requireEnv(env, "OPENROUTER_API_KEY"),
            model: env.OPENROUTER_MODEL ?? DEFAULT_MODELS.openrouter,
            temperature: 0.3,
            configuration: { baseURL: "https://openrouter.ai/api/v1" },
            timeout: PROVIDER_TIMEOUT_MS,
          }) as never;
        }
        case "ollama": {
          const { ChatOpenAI } = await import("@langchain/openai");
          return new ChatOpenAI({
            apiKey: requireEnv(env, "OLLAMA_API_KEY"),
            model: env.OLLAMA_MODEL ?? DEFAULT_MODELS.ollama,
            temperature: 0.3,
            configuration: { baseURL: env.OLLAMA_BASE_URL ?? "http://localhost:11434/v1" },
            timeout: PROVIDER_TIMEOUT_MS,
          }) as never;
        }
        default:
          throw new Error(`${this.provider} has no LangChain binding`);
      }
    } catch (err) {
      // A missing optional dependency, a missing credential, or a constructor
      // that rejected its config all mean the same thing to the caller: take
      // the deterministic path (§5.7 `provider_unavailable`).
      throw new ProviderUnavailableError(this.provider, (err as Error).message);
    }
  }
}

/**
 * Is this error the provider being unreachable, rather than the provider
 * answering with something unusable?
 *
 * Deliberately conservative: anything not recognised as transport stays on the
 * retryable path, so a new SDK's parse error is not silently reclassified into
 * "the deployment is broken". The three signals are an HTTP status the provider
 * SDK attached, a Node socket-level `code`, and undici's bare `fetch failed`.
 */
export function isTransportFailure(err: unknown): boolean {
  if (!(err instanceof Error)) return false;

  const status = (err as { status?: unknown; statusCode?: unknown }).status ?? (err as { statusCode?: unknown }).statusCode;
  // 4xx here is auth/billing/quota/not-found — all deployment facts, none of
  // which a differently-worded prompt on a retry would change. 5xx is theirs.
  if (typeof status === "number" && status >= 400) return true;

  const code = (err as { code?: unknown }).code;
  if (typeof code === "string" && NETWORK_CODES.has(code)) return true;

  return /^fetch failed$/i.test(err.message) || err.name === "TimeoutError";
}

const NETWORK_CODES = new Set([
  "ECONNREFUSED",
  "ECONNRESET",
  "ENOTFOUND",
  "EAI_AGAIN",
  "EPIPE",
  "ETIMEDOUT",
  "UND_ERR_CONNECT_TIMEOUT",
  "UND_ERR_HEADERS_TIMEOUT",
  "UND_ERR_SOCKET",
]);

function requireEnv(env: NodeJS.ProcessEnv, name: string): string {
  const value = env[name];
  if (!value) throw new Error(`${name} is not set`);
  return value;
}

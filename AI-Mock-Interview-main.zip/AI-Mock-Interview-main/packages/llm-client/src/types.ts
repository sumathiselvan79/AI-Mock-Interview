/**
 * `packages/llm-client` core types — INSTRUCTIONS.md §11.5.
 *
 * A `ToolDefinition` ties four things together that would otherwise drift: the
 * MCP method the call backs, the schema its output is validated against, the
 * prompt version that produced it, and which fields have to survive the
 * grounding check for the response to be usable at all.
 */

import type { z } from "zod";

export type ProviderName = "groq" | "bedrock" | "openrouter" | "ollama" | "fixture";

export const PROVIDER_NAMES: readonly ProviderName[] = ["groq", "bedrock", "openrouter", "ollama", "fixture"];

export function isProviderName(value: string): value is ProviderName {
  return (PROVIDER_NAMES as readonly string[]).includes(value);
}

export interface ToolDefinition<TSchema extends z.ZodType = z.ZodType> {
  /** Matches the MCP method name it backs (§11.5). */
  name: string;
  description: string;
  /** The schema registered in /packages/mcp-schemas — the same object, not a copy. */
  schema: TSchema;
  /** `{agent}/v{n}` — resolved through the PromptRegistry. */
  promptVersion: string;
  /** Key into `/packages/mcp-schemas`'s LLM registry, for the Provider Tool's `schema_ref`. */
  schemaRef: string;
  /**
   * Grounding failures on these paths reject the whole response; anywhere else
   * they only cost that field (§11.3).
   */
  requiredGroundedPaths: readonly string[];
}

/**
 * What `structuredCall` hands back.
 *
 * `output` is null only when a REQUIRED field failed grounding — the caller is
 * expected to fall back to its deterministic Stage-2 path rather than ship a
 * response it cannot stand behind (§5.7, TRACKING.md "The model seam").
 */
export interface StructuredCallResult<T> {
  output: T | null;
  grounded: boolean;
  /**
   * Paths that failed grounding and were dropped. Never silently omitted: the
   * caller must be able to tell "no signal" from "signal that was empty"
   * (§11.3).
   */
  insufficientSignal: string[];
  promptVersion: string;
  provider: ProviderName;
}

/**
 * Raised when the provider could not produce a schema-valid response within the
 * retry budget. The caller falls back to the deterministic path; it never
 * coerces a malformed response into shape (TRACKING.md Stage 5 gate test 1).
 */
export class StructuredCallError extends Error {
  readonly code = "schema_validation_failed";

  constructor(
    readonly toolName: string,
    override readonly cause: unknown,
  ) {
    super(`${toolName}: no schema-valid response after retry — ${describe(cause)}`);
    this.name = "StructuredCallError";
  }
}

/** Raised when no provider could be reached at all (§5.7 `provider_unavailable`). */
export class ProviderUnavailableError extends Error {
  readonly code = "provider_unavailable";

  constructor(
    readonly provider: ProviderName,
    message: string,
  ) {
    super(`${provider} is unavailable: ${message}`);
    this.name = "ProviderUnavailableError";
  }
}

function describe(cause: unknown): string {
  if (cause instanceof Error) return cause.message;
  return String(cause);
}

/**
 * The narrow slice of a chat model this package needs. Keeping it to one method
 * is what lets a test inject a deliberately malformed or ungrounded model
 * without standing up LangChain, and what keeps the Bedrock/OpenRouter/Groq
 * choice a deployment concern (§11.5).
 */
export interface StructuredChatModel {
  readonly provider: ProviderName;
  invoke(request: StructuredCallRequest): Promise<unknown>;
}

export interface StructuredCallRequest {
  system: string;
  user: string;
  /**
   * The raw, pre-render input. A real provider ignores this (it reads `user`);
   * the fixture provider uses it to build a deterministic response that is
   * genuinely derived from the caller's data rather than canned.
   */
  input: unknown;
  schemaRef: string;
  /** What a grounded `evidence` string has to be a verbatim slice of (§11.3). */
  sourceDocuments: string[];
  runName: string;
  tags: string[];
  /**
   * Set on a retry after a schema-validation failure, carrying what was wrong
   * with the previous attempt (§11.5: "retry once with a corrective system
   * message on schema-validation failure only").
   */
  correction?: string;
}

/**
 * LangSmith tracing gate — soul.md §"Privacy by default" (Stage 5 addition),
 * INSTRUCTIONS.md §8.
 *
 * LangSmith is a *second* third-party recipient of candidate text, independent
 * of whichever LLM provider is configured: a traced run carries the same
 * resume, job description and answer transcript the generation call carried. So
 * this is not a logging toggle, it is a data-sharing toggle, and it defaults to
 * off anywhere that is not local development.
 *
 * The gate is enforced by *clearing* LangChain's tracing environment variables
 * rather than merely not setting them. LangChain reads `LANGSMITH_TRACING` /
 * `LANGCHAIN_TRACING_V2` from the ambient environment on its own; a stray value
 * inherited from a shell profile or a base container image would otherwise
 * start shipping candidate text off-box with nothing in this repo saying so.
 */

/** Every env var LangChain will act on if it finds one. */
const TRACING_ENV_VARS = [
  "LANGSMITH_TRACING",
  "LANGSMITH_TRACING_V2",
  "LANGCHAIN_TRACING",
  "LANGCHAIN_TRACING_V2",
] as const;

export interface TracingDecision {
  enabled: boolean;
  /** Why — logged at startup so the answer is never "someone's shell profile". */
  reason: string;
}

/**
 * Tracing is on only when BOTH hold:
 *  - `NODE_ENV === "development"` (local dev, not staging and not production), and
 *  - `LANGSMITH_OPT_IN === "true"` — an explicit, repo-specific opt-in, distinct
 *    from LangChain's own vars so inheriting one of those cannot enable it.
 */
export function resolveTracing(env: NodeJS.ProcessEnv = process.env): TracingDecision {
  const isDevelopment = env.NODE_ENV === "development";
  const optedIn = env.LANGSMITH_OPT_IN === "true";

  if (!isDevelopment) {
    return {
      enabled: false,
      reason: `tracing is development-only; NODE_ENV is ${env.NODE_ENV ?? "unset"}`,
    };
  }
  if (!optedIn) {
    return { enabled: false, reason: "LANGSMITH_OPT_IN is not \"true\"" };
  }
  if (!env.LANGSMITH_API_KEY) {
    return { enabled: false, reason: "LANGSMITH_OPT_IN is set but LANGSMITH_API_KEY is missing" };
  }
  return { enabled: true, reason: "NODE_ENV=development and LANGSMITH_OPT_IN=true" };
}

/**
 * Applies the decision to the environment LangChain will read. Returns the
 * decision so a caller can log it.
 *
 * Called once at provider-construction time rather than at import time, so a
 * test can change the environment and re-derive without reloading modules.
 */
export function applyTracingGate(env: NodeJS.ProcessEnv = process.env): TracingDecision {
  const decision = resolveTracing(env);
  if (decision.enabled) {
    env.LANGSMITH_TRACING = "true";
    return decision;
  }
  for (const name of TRACING_ENV_VARS) delete env[name];
  return decision;
}

export { TRACING_ENV_VARS };

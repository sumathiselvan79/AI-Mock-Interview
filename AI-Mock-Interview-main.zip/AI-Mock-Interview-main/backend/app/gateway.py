"""Gateway composition root — ~ apps/gateway/src/app.ts.

`create_app()` wires the whole thing from a config object and returns the
FastAPI app with every dependency reachable off `app.state` — so the test
suite can exercise the same object graph the server runs, not a parallel one.

F4 scope: auth, RBAC, session state machine, the MCP Gateway with the dev-ping
server registered. Real agents/tools (resume parser, eval, question, speech,
LLM, ...) register themselves here as later stages (F5-F12) land — see
FASTAPI_MIGRATION.md.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any, Optional

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

from app.agents.coding.server import CodingAgentDeps, create_coding_agent_server
from app.agents.followup.server import FollowupAgentDeps, create_followup_agent_server
from app.agents.harness.harness import HarnessAgent, HarnessDeps
from app.agents.memory.server import MemoryAgentDeps, create_memory_agent_server
from app.agents.question.server import QuestionAgentDeps, create_question_agent_server
from app.agents.report.server import ReportAgentDeps, create_report_agent_server
from app.agents.resume_service.server import ResumeServiceDeps, create_resume_service_agent_server
from app.agents.time_tracking.server import TimeTrackingAgentDeps, create_time_tracking_agent_server
from app.auth.service import AuthService, MemoryResetMailer, ResetMailer
from app.auth.google import create_google_auth_client
from app.auth.tokens import issue_consent_token, verify_consent_token
from app.config import GatewayConfig, load_config
from app.http.errors import HttpError, install_error_handlers
from app.http.middleware.auth import get_auth_claims
from app.http.routes.admin import admin_routes
from app.http.routes.auth import auth_routes
from app.http.routes.dev_auth import dev_auth_routes
from app.http.routes.google_auth import google_auth_routes
from app.http.live_channel import attach_live_channel
from app.http.routes.interview import interview_routes
from app.http.routes.mcp import mcp_routes
from app.http.routes.me import me_routes
from app.http.routes.sessions import sessions_router
from app.http.routes.voice import voice_routes
from app.logging_ import Logger, create_logger
from app.mcp.dev_ping_server import create_dev_ping_server
from app.mcp.gateway import McpGateway
from app.shared_types import McpCallContext, McpHandlerError
from app.storage import create_storage
from app.storage.types import Storage
from app.tools.clipboard_monitor.server import ClipboardMonitorDeps, create_tool_clipboard_monitor_server
from app.tools.eval.server import EvalDeps, create_tool_eval_server
from app.tools.focus_monitor.server import FocusMonitorDeps, create_tool_focus_monitor_server
from app.llm_client.provider import resolve_provider
from app.llm_client.tools import DYNAMIC_QUESTION_TOOL, JD_FIT_TOOL, QUESTION_TOOL
from app.tools.llm_provider.server import LlmProviderDeps, create_tool_llm_provider_server
from app.tools.resume_parser.server import ResumeParserDeps, create_tool_resume_parser_server
from app.tools.speech_service.server import SpeechServiceDeps, create_tool_speech_service_server, select_speech_provider
from app.tools.speech_service.whisper_provider import WhisperSettings
from app.tools.telemetry.server import create_tool_telemetry_server
from app.tools.time_tracking.server import TimeTrackingDeps, create_tool_time_tracking_server


# Byte budget a base64-encoded payload of `decoded_bytes` needs: 4/3 for the
# encoding, plus room for the surrounding JSON envelope and any transport
# padding. ~ apps/gateway/src/app.ts `base64BodyLimit`.
def base64_body_limit(decoded_bytes: int) -> int:
    import math

    return math.ceil(decoded_bytes * (4 / 3)) + 64 * 1024


# The two routes whose body is a base64 blob rather than ordinary JSON:
# POST /sessions/:id/resume and POST /sessions/:id/answers/audio (Stage F5/F7).
_BLOB_UPLOAD_RE = re.compile(r"^/sessions/[^/]+/(resume|answers/audio)$")


def is_blob_upload(method: str, path: str) -> bool:
    return method == "POST" and bool(_BLOB_UPLOAD_RE.match(path))


class _UnhandledErrorMiddleware(BaseHTTPMiddleware):
    """Catches anything a route raises that isn't an `HttpError` and turns it
    into a plain 500 JSON response, positioned (see `create_app`'s
    `add_middleware` order) INSIDE `CORSMiddleware`.

    `install_error_handlers`' `@app.exception_handler(Exception)` cannot do
    this job by itself: Starlette special-cases a handler registered for the
    bare `Exception` type (or status 500) by moving it out of the ordinary
    `ExceptionMiddleware` and into `ServerErrorMiddleware`, which wraps
    EVERY middleware including CORS. An exception that reaches it produces a
    response CORSMiddleware never sees, so the browser reports a CORS
    failure ("no Access-Control-Allow-Origin header") on what is actually an
    unrelated 500 — this middleware intercepts first so that never happens.
    """

    def __init__(self, app, logger: Logger) -> None:
        super().__init__(app)
        self._logger = logger

    async def dispatch(self, request: Request, call_next):
        try:
            return await call_next(request)
        except Exception as err:
            self._logger.error(
                "unhandled_error", {"path": request.url.path, "method": request.method, "message": str(err)}
            )
            return JSONResponse(
                status_code=500, content={"error": {"code": "internal_error", "message": "internal error"}}
            )


class _BodySizeLimitMiddleware(BaseHTTPMiddleware):
    """Enforces a small JSON body cap everywhere except the two blob-upload
    routes, which get a cap sized for the largest accepted upload. Mirrors
    `app.ts`'s per-route `express.json()` limit dispatch — one big limit
    everywhere would let an oversized body hit any route; a per-route cap
    keeps each route's actual budget."""

    def __init__(self, app, small_limit: int, blob_limit: int) -> None:
        super().__init__(app)
        self._small_limit = small_limit
        self._blob_limit = blob_limit

    async def dispatch(self, request: Request, call_next):
        limit = self._blob_limit if is_blob_upload(request.method, request.url.path) else self._small_limit
        content_length = request.headers.get("content-length")
        if content_length and content_length.isdigit() and int(content_length) > limit:
            return JSONResponse(
                status_code=413,
                content={"error": {"code": "payload_too_large", "message": "request body is too large"}},
            )
        return await call_next(request)


@dataclass
class _ToolClient:
    """~ apps/gateway/src/app.ts `toolClient`'s returned object. One per
    (session_id, caller) pair; looks up the session token itself so an agent
    can never present a token for a session it wasn't given."""

    mcp: McpGateway
    storage: Storage
    session_id: str
    caller: str

    async def call(self, server: str, method: str, params: Any) -> Any:
        session_token = await self.storage.live.get_session_token(self.session_id) or ""
        result = await self.mcp.call(
            server, method, params, McpCallContext(session_id=self.session_id, caller=self.caller, session_token=session_token)
        )
        if not result.ok:
            error = result.error
            raise McpHandlerError(error.code if error else "upstream_error", (error.message if error else f"{server}.{method} failed"))
        return result.data


@dataclass
class CreateAppOptions:
    config: Optional[GatewayConfig] = None
    logger: Optional[Logger] = None
    storage: Optional[Storage] = None
    mailer: Optional[ResetMailer] = None
    # Pins the speech provider. Used by tests that need a deterministic
    # confidence signal — forcing a low-confidence transcription is not
    # something you can reliably ask a real ASR model for.
    speech_provider_choice: Optional[Any] = None
    # Substitutes the LLM Provider Tool's chat model. Used by tests that need
    # a deterministic, forced-malformed, or forced-ungrounded response.
    llm_model: Optional[Any] = None
    # Substitutes the Google OAuth client. Used by tests that need to fake a
    # code exchange instead of hitting Google's token endpoint over the
    # network.
    google_auth_client: Optional[Any] = None


def create_app(options: Optional[CreateAppOptions] = None) -> FastAPI:
    options = options or CreateAppOptions()
    config = options.config or load_config()
    logger = options.logger or create_logger(write_to_console=config.node_env != "test")
    storage = options.storage or create_storage(config)
    mailer = options.mailer or MemoryResetMailer()

    auth = AuthService(
        users=storage.users,
        resets=storage.resets,
        telemetry=storage.telemetry,
        config=config,
        logger=logger,
        mailer=mailer,
        oauth_profiles=storage.oauth_profiles,
    )

    mcp = McpGateway(config=config, telemetry=storage.telemetry, live=storage.live, logger=logger)

    # Real speech when the models are available, the deterministic fixture
    # otherwise. Which one was chosen is logged rather than left a mystery,
    # because it changes what the voice pipeline can actually do — and since
    # the STT swap the two halves resolve independently, so the reason string
    # names both (`tts: ...; stt: ...`).
    speech = options.speech_provider_choice or select_speech_provider(
        config.speech_model_dir,
        WhisperSettings(
            model_size=config.stt_model,
            compute_type=config.stt_compute_type,
            model_dir=config.stt_model_dir or None,
            timeout_seconds=config.stt_timeout_seconds,
            vad_filter=config.stt_vad_filter,
            beam_size=getattr(config, "whisper_beam_size", 5),
            vad_min_silence_ms=getattr(config, "vad_min_silence_ms", 500),
            vad_padding_ms=getattr(config, "vad_padding_ms", 150),
            noise_estimation_ms=getattr(config, "noise_estimation_ms", 500),
            noise_margin_db=getattr(config, "noise_margin_db", 8.0),
            quality_retry_enabled=getattr(config, "quality_retry_enabled", True),
            quality_max_retries=getattr(config, "quality_max_retries", 1),
            technical_normalization_enabled=getattr(config, "technical_normalization_enabled", True),
            transcript_consensus_enabled=getattr(config, "transcript_consensus_enabled", True),
            echo_detection_enabled=getattr(config, "echo_detection_enabled", True),
        ),
    )
    logger.info("speech_provider_selected", {"provider": speech.provider.name, "reason": speech.reason})
    # (C2) A half that failed to load or failed its warm-up is an error line,
    # not a swallowed exception: before this, sherpa-onnx 2.x returned zero
    # samples on every call while the log above read as if all were well.
    # Still not fatal — degraded speech means the interview runs as text.
    speech_status = _speech_status(speech)
    if speech_status["tts"] != "available" or speech_status["stt"] != "available":
        logger.error(
            "speech_provider_degraded",
            {
                "tts": speech_status["tts"],
                "stt": speech_status["stt"],
                "tts_note": getattr(speech, "tts_note", None),
                "stt_note": getattr(speech, "stt_note", None),
            },
        )

    # Logged once at startup so "which provider is live" is never a mystery
    # (§5.7). Per-role overrides (QUESTION_AGENT_LLM_PROVIDER /
    # RESUME_SERVICE_LLM_PROVIDER) are resolved and logged separately from the
    # blanket LLM_PROVIDER choice only when they actually diverge from it.
    llm = resolve_provider()
    logger.info("llm_provider_selected", {"provider": llm.provider, "reason": llm.reason})
    logger.info("llm_tracing_gate", {"enabled": llm.tracing.enabled, "reason": llm.tracing.reason})

    # (Stage 13) The from-scratch synthesis path is only worth taking when a
    # real model is behind it. Resolved here, once, where every other provider
    # decision is already made — an agent that read the environment itself
    # would be a second place the provider choice lives (§5.7).
    synthesis_llm = resolve_provider(None, DYNAMIC_QUESTION_TOOL["name"])
    # An injected model counts as a real one: `options.llm_model` is how a
    # test stands in for a provider without LangChain, and a test that
    # substituted a model and then silently got the bank path would be
    # measuring the wrong thing.
    synthesis_enabled = synthesis_llm.provider != "fixture" or options.llm_model is not None
    logger.info(
        "question_synthesis_gate",
        {
            "enabled": synthesis_enabled,
            "provider": synthesis_llm.provider,
            "reason": (
                synthesis_llm.reason
                if synthesis_enabled
                else "no real provider resolved; questions come from the bank, which is a better interviewer than a templated stand-in"
            ),
        },
    )

    question_llm = resolve_provider(None, QUESTION_TOOL["name"])
    resume_llm = resolve_provider(None, JD_FIT_TOOL["name"])
    if question_llm.provider != llm.provider or resume_llm.provider != llm.provider:
        logger.info(
            "llm_provider_selected_per_role",
            {"question_agent": question_llm.provider, "resume_service_agent": resume_llm.provider},
        )

    # How every agent reaches a tool. The session token is looked up here
    # rather than passed in, so an agent cannot present a token for a session
    # it is not working on, and a failed call surfaces as a typed error
    # instead of an `ok: false` an agent might forget to check.
    # ~ apps/gateway/src/app.ts `toolClient`.
    def tool_client(session_id: str, caller: str):
        return _ToolClient(mcp=mcp, storage=storage, session_id=session_id, caller=caller)

    # Constructing the harness registers its state-write grant with the
    # session store; from here on nothing else can write Session.state.
    harness = HarnessAgent(
        HarnessDeps(
            sessions=storage.sessions,
            telemetry=storage.telemetry,
            telemetry_check_passed=lambda session_id: _telemetry_check_passed(storage, session_id),
            questions=storage.questions,
            answers=storage.answers,
            evaluations=storage.evaluations,
            tool_client=tool_client,
            reports=storage.reports,
            # Minted server-side, and only for a session whose candidate
            # actually agreed on the Telemetry Check page.
            focus_consent_token=lambda session_id: _focus_consent_token(storage, config, session_id),
        )
    )

    # One registration per deployable service.
    for server in [
        # (highlights fix) Every other LLM-backed agent here is wired to
        # the real `tool_client` closure above; this one was left at `None`
        # when F10 landed for the rest, which meant the LLM-powered resume
        # extraction in tools/resume_parser/server.py (`_parse_with_llm_fallback`)
        # was dead code — every resume, in every session, was always parsed by
        # the plain regex path, which cannot pull out named projects/achievements.
        create_tool_resume_parser_server(
            ResumeParserDeps(files=storage.files, tool_client_factory=tool_client, telemetry=storage.telemetry)
        ),
        create_resume_service_agent_server(ResumeServiceDeps(sessions=storage.sessions, tool_client=tool_client)),
        create_tool_eval_server(EvalDeps(evaluations=storage.evaluations)),
        create_tool_time_tracking_server(TimeTrackingDeps(timers=storage.live)),
        create_tool_telemetry_server(),
        create_time_tracking_agent_server(TimeTrackingAgentDeps(tool_client=tool_client)),
        create_memory_agent_server(
            MemoryAgentDeps(
                questions=storage.questions,
                sessions=storage.sessions,
                cross_session_opt_in=lambda candidate_id: _cross_session_opt_in(storage, candidate_id),
                scratch=storage.live,
            )
        ),
        create_question_agent_server(QuestionAgentDeps(tool_client=tool_client, synthesis_enabled=synthesis_enabled)),
        create_followup_agent_server(FollowupAgentDeps(tool_client=tool_client)),
        create_tool_speech_service_server(
            SpeechServiceDeps(
                files=storage.files,
                provider=speech.provider,
                audio_retention_opt_in=lambda session_id: _audio_retention_opt_in(storage, session_id),
            )
        ),
        create_tool_clipboard_monitor_server(
            ClipboardMonitorDeps(
                verify_consent=lambda session_id, token: verify_consent_token(token, session_id, "clipboard_monitor", config.auth_token_secret),
                record_paste=lambda event: _record_paste(storage, event),
            )
        ),
        create_tool_focus_monitor_server(
            FocusMonitorDeps(
                verify_consent=lambda session_id, token: verify_consent_token(token, session_id, "focus_monitoring", config.auth_token_secret),
                record_focus_loss=lambda event: _record_focus_loss(storage, event),
            )
        ),
        create_report_agent_server(ReportAgentDeps(tool_client=tool_client)),
        create_tool_llm_provider_server(LlmProviderDeps(model=options.llm_model)),
    ]:
        mcp.register(server)

    # (A2) The Coding Agent's MCP server exists only when the coding round is
    # enabled (`CODING_ROUND_ENABLED`, default off in production): its sandbox
    # runs candidate code inside this container (audit P0-2). Unregistered, no
    # caller can reach it through the MCP Gateway even if a route forgot its
    # own `coding_round_disabled` check.
    if config.coding_round_enabled:
        mcp.register(
            create_coding_agent_server(
                CodingAgentDeps(
                    tool_client=tool_client,
                    # Minted server-side, and only for a session whose candidate
                    # actually agreed on the Telemetry Check page. The token
                    # never reaches the browser, so a client cannot present one
                    # it was not given.
                    clipboard_consent_token=lambda session_id: _clipboard_consent_token(storage, config, session_id),
                )
            )
        )

    # The dev-ping server exists so the gateway's own auth/rate-limit/schema/
    # telemetry path is testable without involving a real agent. Not in
    # production, same as the TS side.
    if config.node_env != "production":
        mcp.register(create_dev_ping_server())

    # The generated API docs are a map of every route for anyone who asks;
    # production serves none of them (audit P2-16).
    if config.node_env == "production":
        app = FastAPI(title="mia-backend", version="0.1.0", docs_url=None, redoc_url=None, openapi_url=None)
    else:
        app = FastAPI(title="mia-backend", version="0.1.0")
    app.state.config = config
    app.state.logger = logger
    app.state.speech = speech
    app.state.storage = storage
    app.state.auth = auth
    app.state.harness = harness
    app.state.mcp = mcp
    app.state.mailer = mailer

    # Connects the real Postgres pool / Redis client inside the event loop
    # that will actually serve requests — see `create_storage`'s docstring
    # for why this can't happen any earlier. No-op for the memory driver
    # (`SimpleNamespace` from `create_memory_storage` has no `connect`).
    @app.on_event("startup")
    async def _connect_storage() -> None:
        connect = getattr(storage, "connect", None)
        if connect is not None:
            await connect()

    # Order matters, and it is the reverse of reading order: `add_middleware`
    # makes the most-recently-added call the OUTERMOST layer. The stack that
    # results is
    #
    #     CORSMiddleware  >  _UnhandledErrorMiddleware  >  _BodySizeLimitMiddleware  >  app
    #
    # Every response either inner middleware produces itself — the 500 from an
    # unhandled exception (see that class's docstring) and the 413 from the
    # body-size cap — must pass back out through CORSMiddleware, or the
    # browser sees "no Access-Control-Allow-Origin header" instead of the real
    # status and the page cannot tell the user what went wrong (cors.md #1).
    # Preflights carry no body, so the cap sitting inside CORS cannot affect them.
    app.add_middleware(
        _BodySizeLimitMiddleware,
        small_limit=1024 * 1024,
        blob_limit=base64_body_limit(max(config.max_resume_bytes, config.max_audio_bytes)),
    )
    app.add_middleware(_UnhandledErrorMiddleware, logger=logger)
    app.add_middleware(
        CORSMiddleware,
        # An explicit list in every environment, never `*`: with credentials,
        # Starlette answers `*` by reflecting whatever Origin arrives (cors.md #5).
        allow_origins=list(config.cors_origins),
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    install_error_handlers(app, logger)

    @app.exception_handler(json.decoder.JSONDecodeError)
    async def _handle_bad_json(_req: Request, _err: json.decoder.JSONDecodeError) -> JSONResponse:
        return JSONResponse(status_code=400, content={"error": {"code": "invalid_json", "message": "request body is not valid JSON"}})

    # `request.json()` decodes the body before parsing it, so a body that is
    # not UTF-8 raises `UnicodeDecodeError` (not `JSONDecodeError`) — which
    # used to fall through to the 500 handler. It is the client's malformed
    # input, so it is the same 400 (cors.md #9).
    @app.exception_handler(UnicodeDecodeError)
    async def _handle_bad_encoding(_req: Request, _err: UnicodeDecodeError) -> JSONResponse:
        return JSONResponse(status_code=400, content={"error": {"code": "invalid_json", "message": "request body is not valid UTF-8 JSON"}})

    @app.get("/health")
    async def health():
        # Always 200 while the process serves: degraded speech is not down —
        # the interview runs as text. `speech` says which halves are which.
        return {
            "status": "ok",
            "storage": config.storage_driver,
            "mcp_servers": len(mcp.registered()),
            "speech": speech_status,
        }

    app.include_router(auth_routes(auth), prefix="/auth")

    # Registered only when both Google credentials are configured — an
    # unconfigured deployment gets no /auth/google/* routes at all rather
    # than routes that 500 on every call (~ apps/gateway/src/app.ts, which
    # gates the same way on `config.google.clientId`/`clientSecret`).
    if config.google.client_id and config.google.client_secret:
        google_client = options.google_auth_client or create_google_auth_client(config)
        app.include_router(
            google_auth_routes(auth=auth, config=config, google=google_client), prefix="/auth"
        )

    # Hard-gated: must not register unless NODE_ENV != "production" AND
    # ALLOW_DEV_AUTH=true (config.py computes both conditions into one flag).
    if config.dev_auth_enabled:
        app.include_router(dev_auth_routes(auth), prefix="/auth")

    # Everything below this line requires a valid, role-scoped token — each
    # router's routes individually depend on get_auth_claims/require_role, so
    # this comment records the boundary rather than enforcing it centrally
    # (FastAPI has no direct equivalent of Express's `app.use(requireAuth)`
    # positional middleware without wrapping every router; the dependency is
    # declared per-route instead, which the routers above already do).
    app.include_router(
        sessions_router(
            storage=storage,
            harness=harness,
            config=config,
            extra_routers=[
                interview_routes(storage=storage, harness=harness, config=config),
                voice_routes(storage=storage, harness=harness, config=config),
            ],
        ),
        prefix="/sessions",
    )
    app.include_router(me_routes(storage, auth), prefix="/me")
    app.include_router(admin_routes(storage), prefix="/admin")

    # Development-only MCP passthrough, so a human can fire a call by hand and
    # watch the auth/rate-limit/schema/telemetry path work. Never in production.
    if config.node_env != "production":
        app.include_router(mcp_routes(mcp, storage), prefix="/internal/mcp")

    # The live interview channel shares the same ASGI app (INSTRUCTIONS.md §7).
    attach_live_channel(app, harness=harness, storage=storage, config=config, logger=logger)

    return app


def _speech_status(choice: Any) -> dict[str, str]:
    """`{"tts": ..., "stt": ...}`, each `available` or `degraded`. Read with
    getattr so a test that pins a bare stand-in choice still gets an answer."""
    return {"tts": getattr(choice, "tts", "available"), "stt": getattr(choice, "stt", "available")}


async def _telemetry_check_passed(storage: Storage, session_id: str) -> bool:
    check = await storage.live.get_device_check(session_id)
    return check is not None and check.passed is True


async def _cross_session_opt_in(storage: Storage, candidate_id: str) -> bool:
    user = await storage.users.find_by_id(candidate_id)
    return user is not None and user.cross_session_memory_opt_in is True


async def _audio_retention_opt_in(storage: Storage, session_id: str) -> bool:
    session = await storage.sessions.get(session_id)
    return session is not None and session.consent.audio_recording is True


async def _focus_consent_token(storage: Storage, config: GatewayConfig, session_id: str) -> Optional[str]:
    session = await storage.sessions.get(session_id)
    if not session or not session.consent.focus_loss_monitoring:
        return None
    return issue_consent_token(session_id, "focus_monitoring", config.auth_token_secret)


async def _clipboard_consent_token(storage: Storage, config: GatewayConfig, session_id: str) -> Optional[str]:
    session = await storage.sessions.get(session_id)
    if not session or not session.consent.clipboard_monitor:
        return None
    return issue_consent_token(session_id, "clipboard_monitor", config.auth_token_secret)


async def _record_paste(storage: Storage, event: dict[str, Any]) -> None:
    await storage.telemetry.emit("paste_detected", event["session_id"], {"detected": event["detected"], "at": event["timestamp"]})


async def _record_focus_loss(storage: Storage, event: dict[str, Any]) -> dict[str, int]:
    # Atomic append — NOT get() then patch(), which loses events under
    # concurrent calls.
    result = await storage.sessions.append_focus_event(event["session_id"], event["timestamp"])
    await storage.telemetry.emit("focus_lost", event["session_id"], {"at": event["timestamp"], "exit_count": result["exit_count"]})
    return {"exit_count": result["exit_count"]}

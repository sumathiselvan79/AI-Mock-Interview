"""Application logger with mandatory redaction — ~ apps/gateway/src/logging/logger.ts.

CLAUDE.md §8: "Never log full resume text, full clipboard content, or full
answer transcripts in plaintext application logs." Rather than trusting every
call site to remember, this logger drops known-sensitive keys and truncates
any string long enough to be a transcript.

(Named `logging_` — not `logging` — so it doesn't shadow the stdlib module.)
"""

from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from typing import Any, Literal, Optional

SENSITIVE_KEYS = {
    "passcode",
    "passcodehash",
    "passcode_hash",
    "password",
    "token",
    "authorization",
    "accesstoken",
    "access_token",
    "sessiontoken",
    "session_token",
    "resettoken",
    "reset_token",
    "consenttoken",
    "consent_token",
    "resume",
    "resumetext",
    "resume_text",
    "transcript",
    "answer",
    "answertranscript",
    "answer_transcript",
    "audio",
    "clipboard",
    "clipboardcontent",
    "clipboard_content",
    "jobdescription",
    "job_description",
}

MAX_STRING = 200


def redact(value: Any, depth: int = 0) -> Any:
    if depth > 6:
        return "[depth-limit]"
    if isinstance(value, str):
        return f"{value[:MAX_STRING]}…[truncated]" if len(value) > MAX_STRING else value
    if isinstance(value, list):
        return [redact(v, depth + 1) for v in value[:25]]
    if isinstance(value, dict):
        return {
            key: "[redacted]" if key.lower() in SENSITIVE_KEYS else redact(v, depth + 1)
            for key, v in value.items()
        }
    return value


LogLevel = Literal["debug", "info", "warn", "error"]

LEVEL_ORDER = {"debug": 10, "info": 20, "warn": 30, "error": 40}


class Logger:
    def __init__(self, write_to_console: bool = True, min_level: LogLevel = "info") -> None:
        self._write_to_console = write_to_console
        self._min_level = min_level
        self._lines: list[str] = []

    def _write(self, level: LogLevel, msg: str, fields: Optional[dict[str, Any]] = None) -> None:
        if LEVEL_ORDER[level] < LEVEL_ORDER[self._min_level]:
            return
        line = json.dumps(
            {
                "level": level,
                "msg": msg,
                "at": datetime.now(timezone.utc).isoformat(),
                **(redact(fields) if fields else {}),
            }
        )
        self._lines.append(line)
        if self._write_to_console:
            sys.stdout.write(f"{line}\n")

    def debug(self, msg: str, fields: Optional[dict[str, Any]] = None) -> None:
        self._write("debug", msg, fields)

    def info(self, msg: str, fields: Optional[dict[str, Any]] = None) -> None:
        self._write("info", msg, fields)

    def warn(self, msg: str, fields: Optional[dict[str, Any]] = None) -> None:
        self._write("warn", msg, fields)

    def error(self, msg: str, fields: Optional[dict[str, Any]] = None) -> None:
        self._write("error", msg, fields)

    def history(self) -> list[str]:
        """Everything this logger has written — used by the privacy tests."""
        return list(self._lines)


def create_logger(write_to_console: bool = True, min_level: LogLevel = "info") -> Logger:
    return Logger(write_to_console=write_to_console, min_level=min_level)

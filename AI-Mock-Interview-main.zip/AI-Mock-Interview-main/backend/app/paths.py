"""Repo-root path resolution and `.env` loading — ~ apps/gateway/src/paths.ts.

Both exist for the same reason the TS version documents: a relative config
value like `UPLOAD_DIR=uploads` or `SPEECH_MODEL_DIR=models` must resolve
against the repository root, not against whatever the process's current
working directory happens to be when `uvicorn` is launched from a workspace
script or a container entrypoint. An absolute path is left alone.
"""

from __future__ import annotations

import os
from pathlib import Path

# backend/app/paths.py -> backend/app -> backend -> repo root
REPO_ROOT = Path(__file__).resolve().parents[2]


def from_repo_root(path: str) -> str:
    p = Path(path)
    return str(p) if p.is_absolute() else str(REPO_ROOT / p)


def load_dot_env() -> dict[str, object]:
    """Loads the repo-root `.env`, if there is one. A real environment
    variable already set always wins over the file — same precedence as the
    TS `process.loadEnvFile`, so a container-set `DATABASE_URL` beats a stale
    `.env` baked into an image."""
    from dotenv import dotenv_values

    path = REPO_ROOT / ".env"
    if not path.exists():
        return {"loaded": False, "path": str(path)}
    for key, value in dotenv_values(path).items():
        if value is not None and key not in os.environ:
            os.environ[key] = value
    return {"loaded": True, "path": str(path)}

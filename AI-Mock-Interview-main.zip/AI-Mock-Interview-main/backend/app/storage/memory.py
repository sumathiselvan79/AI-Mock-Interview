"""In-memory storage driver — ~ apps/gateway/src/storage/memory.ts.

Used by the test suite and by local dev before Postgres/Redis are up. It
implements exactly the same ports as the Postgres/Redis driver (Stage F11) —
including the state-write grant check — so a behaviour proven here is the
behaviour the real driver has to match.
"""

from __future__ import annotations

import time
import uuid
from datetime import datetime, timezone
from typing import Any, Optional

from app.shared_types import (
    DEFAULT_CONSENT,
    DEFAULT_QUESTION_BUDGET,
    FORBIDDEN_TELEMETRY_KEYS,
    FocusEvent,
    OAuthProfile,
    PasscodeResetToken,
    Role,
    ScheduledInterview,
    Session,
    SessionState,
    SessionStateTransition,
    StateWriteGrant,
    TelemetryEvent,
    TelemetryEventType,
    TelemetryPayload,
    User,
    UserProfile,
)
from app.storage.files import MemoryFileStore
from app.storage.interview_memory import (
    MemoryAnswerStore,
    MemoryEvaluationStore,
    MemoryQuestionStore,
    MemoryReportStore,
)
from app.storage.types import DeviceCheckResult, TimerState


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _new_id() -> str:
    return str(uuid.uuid4())


def _defined_profile(profile: Optional[UserProfile]) -> dict[str, str]:
    """Drops absent and blank profile keys so they never overwrite a stored value."""
    if not profile:
        return {}
    out: dict[str, str] = {}
    for key in ("full_name", "department", "program_year"):
        value = getattr(profile, key, None)
        if isinstance(value, str) and value.strip():
            out[key] = value
    return out


class MemoryUserStore:
    def __init__(self) -> None:
        self._rows: dict[str, User] = {}

    async def create(
        self,
        *,
        email: str,
        role: Role,
        passcode_hash: str,
        cross_session_memory_opt_in: bool = False,
        profile: Optional[UserProfile] = None,
    ) -> User:
        normalized = email.strip().lower()
        if any(u.email == normalized for u in self._rows.values()):
            raise ValueError(f"user already exists: {normalized}")
        user = User(
            id=_new_id(),
            email=normalized,
            role=role,
            passcode_hash=passcode_hash,
            cross_session_memory_opt_in=cross_session_memory_opt_in,
            created_at=_now(),
            **_defined_profile(profile),
        )
        self._rows[user.id] = user
        return user.model_copy(deep=True)

    async def update_profile(self, user_id: str, profile: UserProfile) -> User:
        user = self._rows.get(user_id)
        if not user:
            raise ValueError(f"unknown user {user_id}")
        # Only the keys actually supplied — a partial update must not blank a
        # field the candidate filled in earlier (§11.4).
        for key, value in _defined_profile(profile).items():
            setattr(user, key, value)
        return user.model_copy(deep=True)

    async def find_by_email(self, email: str) -> Optional[User]:
        normalized = email.strip().lower()
        for user in self._rows.values():
            if user.email == normalized:
                return user.model_copy(deep=True)
        return None

    async def find_by_id(self, user_id: str) -> Optional[User]:
        user = self._rows.get(user_id)
        return user.model_copy(deep=True) if user else None

    async def update_passcode_hash(self, user_id: str, passcode_hash: str) -> None:
        user = self._rows.get(user_id)
        if not user:
            raise ValueError(f"unknown user {user_id}")
        user.passcode_hash = passcode_hash

    async def upsert_identity(self, *, email: str, role: Role, unusable_passcode_hash: str) -> User:
        normalized = email.strip().lower()
        for user in self._rows.values():
            if user.email == normalized:
                # Role AND passcode: a passcode set before the first verified
                # identity login is unproven and may be an attacker's (audit
                # P0-1). Same rule as `PostgresUserStore.upsert_identity`.
                user.role = role
                user.passcode_hash = unusable_passcode_hash
                return user.model_copy(deep=True)
        user = User(
            id=_new_id(),
            email=normalized,
            role=role,
            passcode_hash=unusable_passcode_hash,
            cross_session_memory_opt_in=False,
            created_at=_now(),
        )
        self._rows[user.id] = user
        return user.model_copy(deep=True)

    async def raw_row(self, user_id: str) -> Optional[dict[str, Any]]:
        user = self._rows.get(user_id)
        return user.model_dump(by_alias=True) if user else None

    async def list_by_role(self, role: Role) -> list[User]:
        rows = [u for u in self._rows.values() if u.role == role]
        rows.sort(key=lambda u: u.created_at)
        return [u.model_copy(deep=True) for u in rows]


class MemoryResetTokenStore:
    def __init__(self) -> None:
        self._rows: dict[str, PasscodeResetToken] = {}

    async def create(self, user_id: str, token_hash: str, expires_at: str) -> PasscodeResetToken:
        # Invalidate any outstanding token for this user — one live reset at a time.
        for row in self._rows.values():
            if row.user_id == user_id and not row.used_at:
                row.used_at = _now()
        row = PasscodeResetToken(
            id=_new_id(), user_id=user_id, token_hash=token_hash, expires_at=expires_at, used_at=None
        )
        self._rows[row.id] = row
        return row.model_copy(deep=True)

    async def find_valid_by_hash(self, token_hash: str, now: datetime) -> Optional[PasscodeResetToken]:
        for row in self._rows.values():
            if row.token_hash == token_hash and row.used_at is None:
                expires = datetime.fromisoformat(row.expires_at.replace("Z", "+00:00"))
                if expires.tzinfo is None:
                    expires = expires.replace(tzinfo=timezone.utc)
                compare_now = now if now.tzinfo else now.replace(tzinfo=timezone.utc)
                if expires > compare_now:
                    return row.model_copy(deep=True)
        return None

    async def mark_used(self, reset_id: str, at: str) -> None:
        row = self._rows.get(reset_id)
        if row:
            row.used_at = at


class StateWriteForbidden(Exception):
    code = "state_write_forbidden"


class MemorySessionStore:
    def __init__(self) -> None:
        self._rows: dict[str, Session] = {}
        self._audit: list[SessionStateTransition] = []
        self._grant: Optional[StateWriteGrant] = None

    def register_state_writer(self, grant: StateWriteGrant) -> None:
        if self._grant is not None and self._grant.token is not grant.token:
            raise StateWriteForbidden("a state writer is already registered for this store")
        if grant.actor != "harness-agent":
            raise StateWriteForbidden(f"state writer must be harness-agent, got {grant.actor}")
        self._grant = grant

    async def create(
        self, *, candidate_id: str, role: str, job_description: str, question_budget: Optional[int] = None
    ) -> Session:
        now = _now()
        session = Session(
            id=_new_id(),
            candidate_id=candidate_id,
            role=role,
            job_description=job_description,
            jd_fit=None,
            state="CREATED",
            consent=DEFAULT_CONSENT.model_copy(),
            question_budget=question_budget if question_budget is not None else DEFAULT_QUESTION_BUDGET,
            topic_plan=[],
            resume_ref=None,
            candidate_profile=None,
            jd_gap_topics=[],
            jd_fit_fingerprint=None,
            focus_events=[],
            created_at=now,
            updated_at=now,
        )
        self._rows[session.id] = session
        return session.model_copy(deep=True)

    async def get(self, session_id: str) -> Optional[Session]:
        row = self._rows.get(session_id)
        return row.model_copy(deep=True) if row else None

    async def list_by_candidate(self, candidate_id: str) -> list[Session]:
        return [s.model_copy(deep=True) for s in self._rows.values() if s.candidate_id == candidate_id]

    async def set_state(
        self, session_id: str, to_state: SessionState, grant: StateWriteGrant, reason: str
    ) -> Session:
        # Identity check against the registered grant. A forged object with
        # the right `actor` string fails here because `token` cannot be recreated.
        if (
            self._grant is None
            or grant is None
            or grant.token is not self._grant.token
            or grant.actor != "harness-agent"
        ):
            raise StateWriteForbidden(
                "Session.state may only be written by the Harness Agent (INSTRUCTIONS.md §3)"
            )
        row = self._rows.get(session_id)
        if not row:
            raise ValueError(f"unknown session {session_id}")

        at = _now()
        self._audit.append(
            SessionStateTransition(
                id=_new_id(),
                session_id=session_id,
                from_state=row.state,
                to_state=to_state,
                actor=grant.actor,
                reason=reason,
                at=at,
            )
        )
        row.state = to_state
        row.updated_at = at
        return row.model_copy(deep=True)

    async def transitions(self, session_id: str) -> list[SessionStateTransition]:
        return [t.model_copy(deep=True) for t in self._audit if t.session_id == session_id]

    async def patch(self, session_id: str, patch: dict[str, Any]) -> Session:
        row = self._rows.get(session_id)
        if not row:
            raise ValueError(f"unknown session {session_id}")
        updated = row.model_copy(update=patch, deep=True)
        updated.updated_at = _now()
        self._rows[session_id] = updated
        return updated.model_copy(deep=True)

    async def append_focus_event(self, session_id: str, timestamp: str) -> dict[str, int]:
        row = self._rows.get(session_id)
        if not row:
            raise ValueError(f"unknown session {session_id}")
        row.focus_events.append(FocusEvent(timestamp=timestamp))
        row.updated_at = _now()
        return {"exit_count": len(row.focus_events)}

    async def counts_by_candidate(self) -> dict[str, int]:
        counts: dict[str, int] = {}
        for row in self._rows.values():
            counts[row.candidate_id] = counts.get(row.candidate_id, 0) + 1
        return counts


class MemoryScheduledInterviewStore:
    """(Stage 7) In-memory scheduled interviews. Mirrors the Postgres driver port for port."""

    def __init__(self) -> None:
        self._rows: dict[str, ScheduledInterview] = {}

    async def create_many(self, rows: list[ScheduledInterview]) -> list[ScheduledInterview]:
        for row in rows:
            self._rows[row.id] = row.model_copy(deep=True)
        return [r.model_copy(deep=True) for r in rows]

    async def get(self, schedule_id: str) -> Optional[ScheduledInterview]:
        row = self._rows.get(schedule_id)
        return row.model_copy(deep=True) if row else None

    async def list(self) -> list[ScheduledInterview]:
        rows = sorted(self._rows.values(), key=lambda r: r.scheduled_for, reverse=True)
        return [r.model_copy(deep=True) for r in rows]

    async def list_by_candidate(self, candidate_id: str) -> list[ScheduledInterview]:
        rows = [r for r in self._rows.values() if r.candidate_id == candidate_id]
        rows.sort(key=lambda r: r.scheduled_for, reverse=True)
        return [r.model_copy(deep=True) for r in rows]

    async def candidates_with_open_schedules(self) -> list[str]:
        # "Open" is the stored status, not the clock-derived one.
        open_rows = [r for r in self._rows.values() if r.status in ("pending", "started")]
        return list({r.candidate_id for r in open_rows})

    async def update(self, schedule_id: str, patch: dict[str, Any]) -> Optional[ScheduledInterview]:
        row = self._rows.get(schedule_id)
        if not row:
            return None
        updated = row.model_copy(update=patch, deep=True)
        updated.updated_at = _now()
        self._rows[schedule_id] = updated
        return updated.model_copy(deep=True)


def sanitize_telemetry_payload(payload: TelemetryPayload) -> TelemetryPayload:
    """Drops forbidden keys and any non-scalar value before an event is
    stored (INSTRUCTIONS.md §8). Records what was dropped so a leak attempt
    is visible without the leaked value itself being written."""
    out: TelemetryPayload = {}
    dropped: list[str] = []
    for key, value in (payload or {}).items():
        forbidden = key in FORBIDDEN_TELEMETRY_KEYS
        scalar = value is None or isinstance(value, (str, int, float, bool))
        if forbidden or not scalar:
            dropped.append(key)
            continue
        out[key] = f"{value[:512]}…" if isinstance(value, str) and len(value) > 512 else value
    if dropped:
        out["redacted_keys"] = ",".join(dropped)
    return out


class MemoryOAuthProfileStore:
    """~ apps/gateway/src/storage/oauth-profiles.ts `MemoryOAuthProfileStore`.
    Keyed by `user_id` since a user links at most one profile per provider in
    this system (only "google" exists), matching the Supabase driver's
    `(user_id, provider)` upsert key."""

    def __init__(self) -> None:
        self._rows: dict[str, OAuthProfile] = {}

    async def upsert(self, profile: OAuthProfile) -> OAuthProfile:
        self._rows[profile.user_id] = profile.model_copy(deep=True)
        return profile.model_copy(deep=True)

    async def get_by_user_id(self, user_id: str) -> Optional[OAuthProfile]:
        row = self._rows.get(user_id)
        return row.model_copy(deep=True) if row else None

    async def close(self) -> None:
        pass  # nothing to release


class MemoryTelemetrySink:
    def __init__(self) -> None:
        self._events: list[TelemetryEvent] = []

    async def emit(
        self, event_type: TelemetryEventType, session_id: Optional[str], payload: TelemetryPayload
    ) -> TelemetryEvent:
        event = TelemetryEvent(
            id=_new_id(),
            event_type=event_type,
            session_id=session_id,
            payload=sanitize_telemetry_payload(payload),
            emitted_at=_now(),
        )
        self._events.append(event)
        return event.model_copy(deep=True)

    async def recent(self, limit: int = 100) -> list[TelemetryEvent]:
        return [e.model_copy(deep=True) for e in self._events[-limit:]]


class MemoryLiveSessionStore:
    def __init__(self) -> None:
        self._device_checks: dict[str, DeviceCheckResult] = {}
        self._session_tokens: dict[str, str] = {}
        self._timers: dict[str, TimerState] = {}
        self._counters: dict[str, dict[str, float]] = {}
        self._scratch: dict[str, dict[str, str]] = {}

    async def set_session_scratch(self, session_id: str, key: str, value: Any) -> None:
        import json

        bucket = self._scratch.setdefault(session_id, {})
        # Serialised, so the in-memory driver cannot hand a caller a live
        # reference that Redis would have given them a copy of.
        bucket[key] = json.dumps(value)

    async def get_session_scratch(self, session_id: str, key: str) -> Any:
        import json

        raw = self._scratch.get(session_id, {}).get(key)
        return json.loads(raw) if raw is not None else None

    async def clear_session_scratch(self, session_id: str) -> None:
        self._scratch.pop(session_id, None)

    async def set_device_check(self, session_id: str, result: DeviceCheckResult) -> None:
        self._device_checks[session_id] = DeviceCheckResult(**vars(result))

    async def get_device_check(self, session_id: str) -> Optional[DeviceCheckResult]:
        return self._device_checks.get(session_id)

    async def set_session_token(self, session_id: str, token: str) -> None:
        self._session_tokens[session_id] = token

    async def get_session_token(self, session_id: str) -> Optional[str]:
        return self._session_tokens.get(session_id)

    async def save_timer(self, state: TimerState) -> None:
        self._timers[state.segment_id] = TimerState(**vars(state))

    async def load_timer(self, segment_id: str) -> Optional[TimerState]:
        state = self._timers.get(segment_id)
        return TimerState(**vars(state)) if state else None

    async def clear_timer(self, segment_id: str) -> None:
        self._timers.pop(segment_id, None)

    async def increment_rate_counter(self, key: str, window_ms: int) -> int:
        now = time.time() * 1000
        existing = self._counters.get(key)
        if not existing or existing["reset_at"] <= now:
            self._counters[key] = {"count": 1, "reset_at": now + window_ms}
            return 1
        existing["count"] += 1
        return int(existing["count"])

    async def close(self) -> None:
        pass  # nothing to release


def create_memory_storage():
    from types import SimpleNamespace

    live = MemoryLiveSessionStore()
    questions = MemoryQuestionStore()
    answers = MemoryAnswerStore()
    return SimpleNamespace(
        users=MemoryUserStore(),
        sessions=MemorySessionStore(),
        resets=MemoryResetTokenStore(),
        telemetry=MemoryTelemetrySink(),
        live=live,
        files=MemoryFileStore(),
        questions=questions,
        answers=answers,
        evaluations=MemoryEvaluationStore(questions, answers),
        reports=MemoryReportStore(),
        scheduled=MemoryScheduledInterviewStore(),
        archives=None,
        oauth_profiles=MemoryOAuthProfileStore(),
        close=live.close,
    )

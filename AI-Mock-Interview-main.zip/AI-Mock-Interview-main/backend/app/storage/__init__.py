"""~ apps/gateway/src/storage/index.ts.

`STORAGE_DRIVER=memory` (the default in dev and in tests) keeps the whole
gateway runnable with no infrastructure; `postgres` wires the real thing.
Both satisfy the same ports, so route and agent code never branches on it.
"""

from __future__ import annotations

from types import SimpleNamespace

from app.config import GatewayConfig
from app.storage.files import DiskFileStore
from app.storage.interview_postgres import (
    PostgresAnswerStore,
    PostgresEvaluationStore,
    PostgresQuestionStore,
    PostgresReportStore,
)
from app.storage.memory import create_memory_storage
from app.storage.postgres import (
    LazyPool,
    PostgresResetTokenStore,
    PostgresSessionStore,
    PostgresTelemetrySink,
    PostgresUserStore,
)
from app.storage.redis_store import RedisLiveSessionStore
from app.storage.scheduled_postgres import PostgresScheduledInterviewStore
from app.storage.types import Storage


def _redis_client(url: str):
    import redis.asyncio as redis

    # Construction alone opens no socket — `redis.asyncio`'s connection pool
    # is genuinely lazy, unlike `asyncpg.Pool`, but it's built here anyway
    # (rather than inside `connect()`) so the loop-binding rule is the same
    # for both regardless of which one actually needs it.
    return redis.from_url(url, decode_responses=True)


def create_storage(config: GatewayConfig) -> Storage:
    """Synchronous by construction, not just by convenience: `asyncpg.Pool`
    (and, more subtly, `redis.asyncio`) bind their connections to whichever
    event loop is running the first time they actually do I/O. `create_app`
    is called once, at cold import, before uvicorn's own loop exists — a
    pool `await`ed there (`asyncio.run(...)`) would connect inside a
    throwaway loop that `asyncio.run` tears down immediately after,
    leaving every later request (running on uvicorn's real loop) holding a
    `Pool` object whose connections belong to a dead loop
    (`InterfaceError: cannot perform operation: another operation is in
    progress` is that failure surfacing). So `create_storage` only
    *constructs* the pool/client objects — genuinely inert until first used
    — and the actual `await storage.connect()` happens from
    `attach_storage_lifecycle` in `gateway.py`, inside a FastAPI startup
    hook that runs in the loop that will actually serve requests.
    ~ apps/gateway/src/storage/index.ts (which gets this for free: Node has
    exactly one event loop per process, so `await createStorage(config)`
    inside `async function createApp` was never able to hit this class of
    bug in the first place).
    """
    if config.storage_driver == "memory":
        return create_memory_storage()

    pool = LazyPool(config.database_url)
    client = _redis_client(config.redis_url)
    live = RedisLiveSessionStore(client)
    files = DiskFileStore(config.upload_dir)

    async def connect() -> None:
        await pool.connect()
        await client.ping()

    async def close() -> None:
        await live.close()
        await pool.close()

    return SimpleNamespace(
        connect=connect,
        users=PostgresUserStore(pool),
        sessions=PostgresSessionStore(pool),
        resets=PostgresResetTokenStore(pool),
        telemetry=PostgresTelemetrySink(pool),
        live=live,
        files=files,
        questions=PostgresQuestionStore(pool),
        answers=PostgresAnswerStore(pool),
        evaluations=PostgresEvaluationStore(pool),
        reports=PostgresReportStore(pool),
        scheduled=PostgresScheduledInterviewStore(pool),
        # (Stage 5, §11.4/§11.6) A SEPARATE Supabase instance from
        # `database_url`, reached only server-side — not yet ported. Absent,
        # the gateway runs without archiving/OAuth-profile-snapshotting
        # rather than quietly filing either into the primary database the
        # retention job prunes. See FASTAPI_MIGRATION.md's F11 notes.
        archives=None,
        oauth_profiles=None,
        close=close,
    )

"""In-memory question/answer/evaluation/report stores — ~ apps/gateway/src/storage/interview-memory.ts.

Mirrors the Postgres driver (Stage F11) port for port.
"""

from __future__ import annotations

from typing import Optional

from app.shared_types import Answer, Evaluation, FollowUp, FollowUpScore, Question, Report
from app.shared_types.interview import REDACTED_TRANSCRIPT
from app.shared_types.scheduling import mean_competency_score


class MemoryQuestionStore:
    def __init__(self) -> None:
        self._rows: dict[str, Question] = {}

    async def append(self, question: Question) -> Question:
        self._rows[question.id] = question.model_copy(deep=True)
        return question.model_copy(deep=True)

    async def get(self, question_id: str) -> Optional[Question]:
        row = self._rows.get(question_id)
        return row.model_copy(deep=True) if row else None

    async def list_by_session(self, session_id: str) -> list[Question]:
        rows = [q for q in self._rows.values() if q.session_id == session_id]
        rows.sort(key=lambda q: q.asked_at)
        return [q.model_copy(deep=True) for q in rows]


class MemoryAnswerStore:
    def __init__(self) -> None:
        self._rows: dict[str, Answer] = {}

    async def append(self, answer: Answer) -> Answer:
        self._rows[answer.id] = answer.model_copy(deep=True)
        return answer.model_copy(deep=True)

    async def get(self, answer_id: str) -> Optional[Answer]:
        row = self._rows.get(answer_id)
        return row.model_copy(deep=True) if row else None

    async def get_by_question(self, question_id: str) -> Optional[Answer]:
        for row in self._rows.values():
            if row.question_id == question_id:
                return row.model_copy(deep=True)
        return None

    async def append_follow_up(self, answer_id: str, follow_up: dict[str, str]) -> Answer:
        row = self._rows.get(answer_id)
        if not row:
            raise ValueError(f"unknown answer {answer_id}")
        row.follow_ups.append(FollowUp(text=follow_up["text"], transcript=follow_up["transcript"]))
        return row.model_copy(deep=True)

    async def score_follow_up(self, answer_id: str, index: int, score: FollowUpScore) -> Answer:
        row = self._rows.get(answer_id)
        if not row:
            raise ValueError(f"unknown answer {answer_id}")
        if index >= len(row.follow_ups):
            raise ValueError(f"answer {answer_id} has no follow-up at index {index}")
        row.follow_ups[index].score = score
        return row.model_copy(deep=True)

    async def record_extraction(self, answer_id: str, extraction, next_action) -> Answer:
        row = self._rows.get(answer_id)
        if not row:
            raise ValueError(f"unknown answer {answer_id}")
        row.extraction = extraction
        row.next_action = next_action
        return row.model_copy(deep=True)

    async def redact(self, answer_id: str) -> Answer:
        row = self._rows.get(answer_id)
        if not row:
            raise ValueError(f"unknown answer {answer_id}")
        row.transcript = REDACTED_TRANSCRIPT
        # The score and its rationale survive redaction, as `Evaluation` rows
        # do — §8 purges the candidate's own words, not the assessment of them.
        for follow_up in row.follow_ups:
            follow_up.transcript = REDACTED_TRANSCRIPT
        return row.model_copy(deep=True)


class MemoryEvaluationStore:
    """Session scope is derived by walking evaluation -> answer -> question,
    the same join the Postgres driver does, rather than denormalising a
    session id onto every evaluation row."""

    def __init__(self, questions: MemoryQuestionStore, answers: MemoryAnswerStore) -> None:
        self._rows: list[Evaluation] = []
        self._questions = questions
        self._answers = answers

    async def append(self, evaluation: Evaluation) -> Evaluation:
        self._rows.append(evaluation.model_copy(deep=True))
        return evaluation.model_copy(deep=True)

    async def list_by_answer(self, answer_id: str) -> list[Evaluation]:
        return [e.model_copy(deep=True) for e in self._rows if e.answer_id == answer_id]

    async def list_by_session(self, session_id: str) -> list[Evaluation]:
        question_ids = {q.id for q in await self._questions.list_by_session(session_id)}
        out: list[Evaluation] = []
        for row in self._rows:
            answer = await self._answers.get(row.answer_id)
            if answer and answer.question_id in question_ids:
                out.append(row.model_copy(deep=True))
        return out


class MemoryReportStore:
    def __init__(self) -> None:
        self._rows: dict[str, Report] = {}

    async def create(self, report: Report) -> Report:
        self._rows[report.session_id] = report.model_copy(deep=True)
        return report.model_copy(deep=True)

    async def get_by_session(self, session_id: str) -> Optional[Report]:
        row = self._rows.get(session_id)
        return row.model_copy(deep=True) if row else None

    async def list_by_candidate(self, candidate_id: str) -> list[Report]:
        rows = [r for r in self._rows.values() if r.candidate_id == candidate_id]
        rows.sort(key=lambda r: r.created_at, reverse=True)
        return [r.model_copy(deep=True) for r in rows]

    async def list_all(self) -> list[Report]:
        rows = sorted(self._rows.values(), key=lambda r: r.created_at, reverse=True)
        return [r.model_copy(deep=True) for r in rows]

    async def aggregate_by_candidate(self) -> list[dict]:
        """One pass over the reports, grouped by candidate — the same shape
        the Postgres driver computes in SQL, so the directory's numbers
        cannot differ between drivers.

        `average_score` is the mean of each report's OWN mean, not the mean
        of every competency score pooled together.
        """
        by_candidate: dict[str, dict] = {}
        for report in self._rows.values():
            entry = by_candidate.setdefault(
                report.candidate_id, {"means": [], "count": 0, "last": None}
            )
            entry["count"] += 1
            mean = mean_competency_score([s.score for s in report.competency_scores])
            if mean is not None:
                entry["means"].append(mean)
            if not entry["last"] or report.created_at > entry["last"]:
                entry["last"] = report.created_at

        result = []
        for candidate_id, entry in by_candidate.items():
            means = entry["means"]
            result.append(
                {
                    "candidate_id": candidate_id,
                    "interviews_completed": entry["count"],
                    "average_score": (sum(means) / len(means)) if means else None,
                    "last_interview_at": entry["last"],
                }
            )
        return result

"""Postgres question/answer/evaluation/report stores. Same ports as the
in-memory driver in `interview_memory.py`. ~ apps/gateway/src/storage/interview-postgres.ts.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Optional

import asyncpg

from app.shared_types import Answer, Evaluation, FollowUp, FollowUpScore, Question, Report
from app.shared_types.interview import REDACTED_TRANSCRIPT
from app.shared_types.session import FocusEvent


def _iso(value: Any) -> str:
    return value.isoformat() if isinstance(value, datetime) else value


def _parse_dt(value: str) -> datetime:
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)


def _dump(value: Any) -> Any:
    return value.model_dump(by_alias=True) if hasattr(value, "model_dump") else value


def _to_question(row: asyncpg.Record) -> Question:
    return Question(
        id=str(row["id"]),
        bank_id=row["bank_id"],
        session_id=str(row["session_id"]),
        text=row["text"],
        audio_url=row["audio_url"],
        topic=row["topic"],
        type=row["type"],
        difficulty=row["difficulty"],
        tier=row["tier"],
        target_concept_ids=row["target_concept_ids"],
        quota_override=row["quota_override"],
        prompt_version=row["prompt_version"],
        asked_at=_iso(row["asked_at"]),
    )


class PostgresQuestionStore:
    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool

    async def append(self, question: Question) -> Question:
        row = await self._pool.fetchrow(
            """INSERT INTO questions (id, bank_id, session_id, text, audio_url, topic, type, difficulty, tier, target_concept_ids, quota_override, prompt_version, asked_at)
               VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13) RETURNING *""",
            question.id,
            question.bank_id,
            question.session_id,
            question.text,
            question.audio_url,
            question.topic,
            question.type,
            question.difficulty,
            question.tier,
            question.target_concept_ids,
            question.quota_override or False,
            question.prompt_version,
            _parse_dt(question.asked_at),
        )
        return _to_question(row)

    async def get(self, question_id: str) -> Optional[Question]:
        row = await self._pool.fetchrow("SELECT * FROM questions WHERE id = $1", question_id)
        return _to_question(row) if row else None

    async def list_by_session(self, session_id: str) -> list[Question]:
        rows = await self._pool.fetch("SELECT * FROM questions WHERE session_id = $1 ORDER BY asked_at", session_id)
        return [_to_question(r) for r in rows]


def _to_answer(row: asyncpg.Record) -> Answer:
    follow_ups_raw = row["follow_ups"] or []
    return Answer(
        id=str(row["id"]),
        question_id=str(row["question_id"]),
        transcript=row["transcript"],
        transcript_confidence=row["transcript_confidence"],
        follow_ups=[FollowUp(**{"text": f["text"], "transcript": f["transcript"], "score": f.get("score")}) for f in follow_ups_raw],
        extraction=row["extraction"],
        next_action=row["next_action"],
        submitted_at=_iso(row["submitted_at"]),
    )


class PostgresAnswerStore:
    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool

    async def append(self, answer: Answer) -> Answer:
        row = await self._pool.fetchrow(
            """INSERT INTO answers (id, question_id, transcript, transcript_confidence, follow_ups, submitted_at)
               VALUES ($1, $2, $3, $4, $5, $6) RETURNING *""",
            answer.id,
            answer.question_id,
            answer.transcript,
            answer.transcript_confidence,
            [_dump(f) for f in answer.follow_ups],
            _parse_dt(answer.submitted_at),
        )
        return _to_answer(row)

    async def get(self, answer_id: str) -> Optional[Answer]:
        row = await self._pool.fetchrow("SELECT * FROM answers WHERE id = $1", answer_id)
        return _to_answer(row) if row else None

    async def get_by_question(self, question_id: str) -> Optional[Answer]:
        row = await self._pool.fetchrow(
            "SELECT * FROM answers WHERE question_id = $1 ORDER BY submitted_at LIMIT 1", question_id
        )
        return _to_answer(row) if row else None

    async def append_follow_up(self, answer_id: str, follow_up: dict[str, str]) -> Answer:
        row = await self._pool.fetchrow(
            "UPDATE answers SET follow_ups = follow_ups || $2::jsonb WHERE id = $1 RETURNING *",
            answer_id,
            [{"text": follow_up["text"], "transcript": follow_up["transcript"]}],
        )
        if not row:
            raise ValueError(f"unknown answer {answer_id}")
        return _to_answer(row)

    async def score_follow_up(self, answer_id: str, index: int, score: FollowUpScore) -> Answer:
        """(Stage 5, §11.2) Writes the score onto one `follow_ups[]` element in
        place. `jsonb_set` rather than a read-modify-write of the whole array,
        so a concurrent `append_follow_up` cannot lose the score it just wrote."""
        row = await self._pool.fetchrow(
            """UPDATE answers
                  SET follow_ups = jsonb_set(follow_ups, ARRAY[$2::text, 'score'], $3::jsonb, true)
                WHERE id = $1
                  AND jsonb_array_length(follow_ups) > $2::int
              RETURNING *""",
            answer_id,
            str(index),
            _dump(score),
        )
        if not row:
            raise ValueError(f"answer {answer_id} has no follow-up at index {index}")
        return _to_answer(row)

    async def record_extraction(self, answer_id: str, extraction: Any, next_action: Any) -> Answer:
        row = await self._pool.fetchrow(
            "UPDATE answers SET extraction = $2::jsonb, next_action = $3::jsonb WHERE id = $1 RETURNING *",
            answer_id,
            _dump(extraction),
            _dump(next_action),
        )
        if not row:
            raise ValueError(f"unknown answer {answer_id}")
        return _to_answer(row)

    async def redact(self, answer_id: str) -> Answer:
        existing = await self.get(answer_id)
        if not existing:
            raise ValueError(f"unknown answer {answer_id}")
        redacted_follow_ups = [
            {**_dump(f), "transcript": REDACTED_TRANSCRIPT} for f in existing.follow_ups
        ]
        row = await self._pool.fetchrow(
            "UPDATE answers SET transcript = $2, follow_ups = $3::jsonb WHERE id = $1 RETURNING *",
            answer_id,
            REDACTED_TRANSCRIPT,
            redacted_follow_ups,
        )
        if not row:
            raise ValueError(f"unknown answer {answer_id}")
        return _to_answer(row)


def _to_evaluation(row: asyncpg.Record) -> Evaluation:
    return Evaluation(
        id=str(row["id"]),
        answer_id=str(row["answer_id"]),
        rubric_id=row["rubric_id"],
        score=row["score"],
        rationale=row["rationale"],
        evidence_spans=row["evidence_spans"],
        prompt_version=row["prompt_version"],
        created_at=_iso(row["created_at"]),
    )


class PostgresEvaluationStore:
    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool

    async def append(self, evaluation: Evaluation) -> Evaluation:
        row = await self._pool.fetchrow(
            """INSERT INTO evaluations (id, answer_id, rubric_id, score, rationale, evidence_spans, prompt_version, created_at)
               VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *""",
            evaluation.id,
            evaluation.answer_id,
            evaluation.rubric_id,
            evaluation.score,
            evaluation.rationale,
            [_dump(s) for s in evaluation.evidence_spans],
            evaluation.prompt_version,
            _parse_dt(evaluation.created_at),
        )
        return _to_evaluation(row)

    async def list_by_answer(self, answer_id: str) -> list[Evaluation]:
        rows = await self._pool.fetch("SELECT * FROM evaluations WHERE answer_id = $1 ORDER BY created_at", answer_id)
        return [_to_evaluation(r) for r in rows]

    async def list_by_session(self, session_id: str) -> list[Evaluation]:
        rows = await self._pool.fetch(
            """SELECT e.* FROM evaluations e
                 JOIN answers a ON a.id = e.answer_id
                 JOIN questions q ON q.id = a.question_id
                WHERE q.session_id = $1
                ORDER BY e.created_at""",
            session_id,
        )
        return [_to_evaluation(r) for r in rows]


_DEFAULT_BROWSER_ACTIVITY = {"exitCount": 0, "events": [], "concludedEarly": False}


def _to_report(row: asyncpg.Record) -> Report:
    return Report(
        session_id=str(row["session_id"]),
        candidate_id=str(row["candidate_id"]),
        competency_scores=row["competency_scores"],
        # Nullable, and null for every report written before the grading
        # migration — read back as "not graded", never as a bottom band.
        overall_grade=row["overall_grade"],
        strengths=row["strengths"],
        focus_areas=row["focus_areas"],
        browser_activity=row["browser_activity"] or _DEFAULT_BROWSER_ACTIVITY,
        disclaimer=row["disclaimer"],
        created_at=_iso(row["created_at"]),
    )


class PostgresReportStore:
    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool

    async def create(self, report: Report) -> Report:
        row = await self._pool.fetchrow(
            """INSERT INTO reports (session_id, candidate_id, competency_scores, overall_grade, strengths, focus_areas, browser_activity, disclaimer, created_at)
               VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *""",
            report.session_id,
            report.candidate_id,
            [_dump(c) for c in report.competency_scores],
            _dump(report.overall_grade) if report.overall_grade else None,
            report.strengths,
            report.focus_areas,
            _dump(report.browser_activity),
            report.disclaimer,
            _parse_dt(report.created_at),
        )
        return _to_report(row)

    async def get_by_session(self, session_id: str) -> Optional[Report]:
        row = await self._pool.fetchrow("SELECT * FROM reports WHERE session_id = $1", session_id)
        return _to_report(row) if row else None

    async def list_by_candidate(self, candidate_id: str) -> list[Report]:
        rows = await self._pool.fetch("SELECT * FROM reports WHERE candidate_id = $1 ORDER BY created_at DESC", candidate_id)
        return [_to_report(r) for r in rows]

    async def list_all(self) -> list[Report]:
        rows = await self._pool.fetch("SELECT * FROM reports ORDER BY created_at DESC")
        return [_to_report(r) for r in rows]

    async def aggregate_by_candidate(self) -> list[dict[str, Any]]:
        """(Stage 7) The inner query reduces each report's `competency_scores`
        JSONB array to that report's own mean; the outer one averages those
        per candidate. The nesting is the point — `AVG` over every score
        pooled together would weight a session that scored six competencies
        more heavily than one that scored three, which is not what "average
        score per interview" means. The in-memory driver computes the
        identical mean-of-means."""
        rows = await self._pool.fetch(
            """SELECT candidate_id,
                      COUNT(*)                      AS interviews_completed,
                      AVG(report_mean)               AS average_score,
                      MAX(created_at)                AS last_interview_at
                 FROM (
                   SELECT r.candidate_id,
                          r.created_at,
                          (SELECT AVG((c->>'score')::numeric)
                             FROM jsonb_array_elements(r.competency_scores) AS c) AS report_mean
                     FROM reports r
                 ) per_report
                GROUP BY candidate_id"""
        )
        return [
            {
                "candidate_id": str(r["candidate_id"]),
                "interviews_completed": r["interviews_completed"],
                "average_score": float(r["average_score"]) if r["average_score"] is not None else None,
                "last_interview_at": _iso(r["last_interview_at"]) if r["last_interview_at"] else None,
            }
            for r in rows
        ]

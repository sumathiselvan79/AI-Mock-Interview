"""Storage ports specific to the gateway — ~ apps/gateway/src/storage/types.ts.

Distinct from `app.shared_types.ports`, which holds the ports agents depend
on directly. These are gateway-only concerns: users, reset tokens, and live
(Redis-backed in production) session/timer state.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional, Protocol

from app.shared_types import (
    AnswerStore,
    EvaluationStore,
    FileStore,
    OAuthProfileStore,
    PasscodeResetToken,
    QuestionStore,
    ReportStore,
    Role,
    ScheduledInterviewStore,
    Session,
    SessionArchiveStore,
    SessionStore,
    TelemetrySink,
    User,
    UserProfile,
)


class UserStore(Protocol):
    async def create(
        self,
        *,
        email: str,
        role: Role,
        passcode_hash: str,
        cross_session_memory_opt_in: bool = False,
        profile: Optional[UserProfile] = None,
    ) -> User: ...

    async def update_profile(self, user_id: str, profile: UserProfile) -> User: ...
    async def find_by_email(self, email: str) -> Optional[User]: ...
    async def find_by_id(self, user_id: str) -> Optional[User]: ...
    async def update_passcode_hash(self, user_id: str, passcode_hash: str) -> None: ...

    async def upsert_identity(
        self, *, email: str, role: Role, unusable_passcode_hash: str
    ) -> User:
        """Find-or-create for identity paths that never collect a passcode
        (dev-login, Google OAuth). The caller has verified the email; on an
        existing row `role` is synced and `passcode_hash` is replaced with
        `unusable_passcode_hash`, because `/auth/register` does not verify
        email ownership and a passcode set before this login may belong to
        whoever registered the address first (audit P0-1). A passcode set
        AFTER it, through the reset flow, is the owner's, but the next
        identity login replaces it too; the store keeps no record of which
        is which (see deploy/aws/notes/impl-security.md)."""
        ...

    async def raw_row(self, user_id: str) -> Optional[dict[str, Any]]: ...
    async def list_by_role(self, role: Role) -> list[User]: ...


class ResetTokenStore(Protocol):
    async def create(self, user_id: str, token_hash: str, expires_at: str) -> PasscodeResetToken: ...
    async def find_valid_by_hash(self, token_hash: str, now) -> Optional[PasscodeResetToken]: ...
    async def mark_used(self, reset_id: str, at: str) -> None: ...


@dataclass
class DeviceCheckResult:
    passed: bool
    mic_ok: bool
    speaker_ok: bool
    at: str


@dataclass
class TimerState:
    """A segment timer as stored. Pause is accumulated, so elapsed excludes
    paused time."""

    segment_id: str
    budget_ms: int
    started_at: int  # epoch ms
    paused_at: Optional[int]  # epoch ms, set while paused
    paused_ms: int  # total ms spent paused so far


class LiveSessionStore(Protocol):
    """Live session state and timers — Redis in production (INSTRUCTIONS.md
    §5.3, §9). Everything here is ephemeral and reconstructable; durable
    records live in Postgres."""

    async def set_device_check(self, session_id: str, result: DeviceCheckResult) -> None: ...
    async def get_device_check(self, session_id: str) -> Optional[DeviceCheckResult]: ...

    async def set_session_token(self, session_id: str, token: str) -> None: ...
    async def get_session_token(self, session_id: str) -> Optional[str]: ...

    async def set_session_scratch(self, session_id: str, key: str, value: Any) -> None: ...
    async def get_session_scratch(self, session_id: str, key: str) -> Any: ...
    async def clear_session_scratch(self, session_id: str) -> None: ...

    async def save_timer(self, state: TimerState) -> None: ...
    async def load_timer(self, segment_id: str) -> Optional[TimerState]: ...
    async def clear_timer(self, segment_id: str) -> None: ...

    async def increment_rate_counter(self, key: str, window_ms: int) -> int: ...

    async def close(self) -> None: ...


class Storage(Protocol):
    users: UserStore
    sessions: SessionStore
    resets: ResetTokenStore
    telemetry: TelemetrySink
    live: LiveSessionStore
    files: FileStore
    questions: QuestionStore
    answers: AnswerStore
    evaluations: EvaluationStore
    reports: ReportStore
    scheduled: ScheduledInterviewStore
    archives: Optional[SessionArchiveStore]
    oauth_profiles: Optional[OAuthProfileStore]

    async def close(self) -> None: ...


__all__ = [
    "UserStore",
    "ResetTokenStore",
    "DeviceCheckResult",
    "TimerState",
    "LiveSessionStore",
    "Storage",
    "Session",
]

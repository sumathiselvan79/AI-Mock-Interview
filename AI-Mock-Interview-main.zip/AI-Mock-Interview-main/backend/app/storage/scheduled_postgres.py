"""(Stage 7) Postgres scheduled-interview store. Same port as the in-memory
driver in `memory.py`, backed by `scheduled_interviews` from migration 006.
~ apps/gateway/src/storage/scheduled-postgres.ts.

In the PRIMARY database, not the Supabase archive instance: this is live
operational data a student's home page reads on every load, not an export
copy (`ADMIN_FEATURE_PROMPT.md` §non-goals).
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Optional

import asyncpg

from app.shared_types import ScheduledInterview

_SELECT_COLUMNS = """id, candidate_id, department, role, job_description, interview_type,
  difficulty, duration_minutes, scheduled_for, deadline, recurring, coding_round_enabled,
  notes, notify_via, status, session_id, created_by, created_at, updated_at"""


def _iso(value: Any) -> Optional[str]:
    return value.isoformat() if isinstance(value, datetime) else value


def _parse_dt(value: Optional[str]) -> Optional[datetime]:
    if value is None:
        return None
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)


def _to_scheduled(row: asyncpg.Record) -> ScheduledInterview:
    return ScheduledInterview(
        id=str(row["id"]),
        candidate_id=str(row["candidate_id"]),
        department=row["department"],
        role=row["role"],
        job_description=row["job_description"],
        interview_type=row["interview_type"],
        difficulty=row["difficulty"],
        duration_minutes=row["duration_minutes"],
        scheduled_for=_iso(row["scheduled_for"]),
        deadline=_iso(row["deadline"]),
        recurring=row["recurring"],
        coding_round_enabled=row["coding_round_enabled"],
        notes=row["notes"],
        notify_via=row["notify_via"],
        status=row["status"],
        session_id=str(row["session_id"]) if row["session_id"] else None,
        created_by=str(row["created_by"]),
        created_at=_iso(row["created_at"]),
        updated_at=_iso(row["updated_at"]),
    )


class PostgresScheduledInterviewStore:
    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool

    async def create_many(self, rows: list[ScheduledInterview]) -> list[ScheduledInterview]:
        """One statement per row, inside a transaction: scheduling twelve
        candidates either assigns all twelve or none. A partially-applied
        batch would leave an Admin with no way to tell who was actually
        assigned."""
        if not rows:
            return []

        created: list[ScheduledInterview] = []
        async with self._pool.acquire() as conn:
            async with conn.transaction():
                for row in rows:
                    inserted = await conn.fetchrow(
                        f"""INSERT INTO scheduled_interviews
                              (id, candidate_id, department, role, job_description, interview_type, difficulty,
                               duration_minutes, scheduled_for, deadline, recurring, coding_round_enabled,
                               notes, notify_via, status, session_id, created_by, created_at, updated_at)
                            VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19)
                            RETURNING {_SELECT_COLUMNS}""",
                        row.id,
                        row.candidate_id,
                        row.department,
                        row.role,
                        row.job_description,
                        row.interview_type,
                        row.difficulty,
                        row.duration_minutes,
                        _parse_dt(row.scheduled_for),
                        _parse_dt(row.deadline),
                        row.recurring,
                        row.coding_round_enabled,
                        row.notes,
                        list(row.notify_via),
                        row.status,
                        row.session_id,
                        row.created_by,
                        _parse_dt(row.created_at),
                        _parse_dt(row.updated_at),
                    )
                    created.append(_to_scheduled(inserted))
        return created

    async def get(self, schedule_id: str) -> Optional[ScheduledInterview]:
        row = await self._pool.fetchrow(f"SELECT {_SELECT_COLUMNS} FROM scheduled_interviews WHERE id = $1", schedule_id)
        return _to_scheduled(row) if row else None

    async def list(self) -> list[ScheduledInterview]:
        rows = await self._pool.fetch(f"SELECT {_SELECT_COLUMNS} FROM scheduled_interviews ORDER BY scheduled_for DESC")
        return [_to_scheduled(r) for r in rows]

    async def list_by_candidate(self, candidate_id: str) -> list[ScheduledInterview]:
        rows = await self._pool.fetch(
            f"SELECT {_SELECT_COLUMNS} FROM scheduled_interviews WHERE candidate_id = $1 ORDER BY scheduled_for DESC",
            candidate_id,
        )
        return [_to_scheduled(r) for r in rows]

    async def candidates_with_open_schedules(self) -> list[str]:
        # Stored status, not the clock-derived one — see the in-memory
        # driver's note: an assignment whose deadline lapsed is still one an
        # Admin made.
        rows = await self._pool.fetch(
            "SELECT DISTINCT candidate_id FROM scheduled_interviews WHERE status IN ('pending', 'started')"
        )
        return [str(r["candidate_id"]) for r in rows]

    async def update(self, schedule_id: str, patch: dict[str, Any]) -> Optional[ScheduledInterview]:
        sets: list[str] = []
        values: list[Any] = [schedule_id]

        def push(column: str, value: Any) -> None:
            values.append(value)
            sets.append(f"{column} = ${len(values)}")

        if "status" in patch:
            push("status", patch["status"])
        if "session_id" in patch:
            push("session_id", patch["session_id"])
        if "scheduled_for" in patch:
            push("scheduled_for", _parse_dt(patch["scheduled_for"]))
        if "deadline" in patch:
            push("deadline", _parse_dt(patch["deadline"]))

        if not sets:
            return await self.get(schedule_id)

        row = await self._pool.fetchrow(
            f"UPDATE scheduled_interviews SET {', '.join(sets)}, updated_at = now() WHERE id = $1 RETURNING {_SELECT_COLUMNS}",
            *values,
        )
        return _to_scheduled(row) if row else None

"""Redis-backed live session state and timers (INSTRUCTIONS.md §5.3, §9).
~ apps/gateway/src/storage/redis.ts.

Everything here is ephemeral: device-check results, session MCP tokens,
segment timers, and rate-limit counters. Losing it costs a session its live
pacing, never a durable record.

Named `redis_store.py` rather than `redis.py` so this module doesn't shadow
the `redis` package it imports.
"""

from __future__ import annotations

import json
from dataclasses import asdict
from typing import Any, Optional

import redis.asyncio as redis

from app.storage.types import DeviceCheckResult, TimerState

_DEVICE_CHECK_TTL_S = 60 * 60 * 6
_SESSION_TOKEN_TTL_S = 60 * 60 * 6
_TIMER_TTL_S = 60 * 60 * 6
# (Stage 5) The Memory Agent's session-scoped working memory (§4.7). Given its
# own TTL because a reference answer is the one thing here that must not
# outlive its session by design, not merely by convenience — soul.md §5
# forbids it ever reaching the candidate or the transcript, so a stale key
# surviving a crashed session is a privacy question, not a cache question.
_SCRATCH_TTL_S = 60 * 60 * 6


def _device_check_key(session_id: str) -> str:
    return f"mia:session:{session_id}:device-check"


def _session_token_key(session_id: str) -> str:
    return f"mia:session:{session_id}:mcp-token"


def _timer_key(segment_id: str) -> str:
    return f"mia:timer:{segment_id}"


def _rate_key(k: str) -> str:
    return f"mia:rate:{k}"


def _scratch_key(session_id: str) -> str:
    return f"mia:session:{session_id}:scratch"


class RedisLiveSessionStore:
    def __init__(self, client: "redis.Redis") -> None:
        self._client = client

    @classmethod
    async def connect(cls, url: str) -> "RedisLiveSessionStore":
        client = redis.from_url(url, decode_responses=True)
        await client.ping()
        return cls(client)

    async def set_device_check(self, session_id: str, result: DeviceCheckResult) -> None:
        await self._client.set(_device_check_key(session_id), json.dumps(asdict(result)), ex=_DEVICE_CHECK_TTL_S)

    async def get_device_check(self, session_id: str) -> Optional[DeviceCheckResult]:
        raw = await self._client.get(_device_check_key(session_id))
        return DeviceCheckResult(**json.loads(raw)) if raw else None

    async def set_session_token(self, session_id: str, token: str) -> None:
        await self._client.set(_session_token_key(session_id), token, ex=_SESSION_TOKEN_TTL_S)

    async def get_session_token(self, session_id: str) -> Optional[str]:
        return await self._client.get(_session_token_key(session_id))

    async def set_session_scratch(self, session_id: str, key: str, value: Any) -> None:
        """One hash per session, so `clear_session_scratch` is a single DEL."""
        redis_key = _scratch_key(session_id)
        await self._client.hset(redis_key, key, json.dumps(value))
        await self._client.expire(redis_key, _SCRATCH_TTL_S)

    async def get_session_scratch(self, session_id: str, key: str) -> Any:
        raw = await self._client.hget(_scratch_key(session_id), key)
        return json.loads(raw) if raw else None

    async def clear_session_scratch(self, session_id: str) -> None:
        await self._client.delete(_scratch_key(session_id))

    async def save_timer(self, state: TimerState) -> None:
        await self._client.set(_timer_key(state.segment_id), json.dumps(asdict(state)), ex=_TIMER_TTL_S)

    async def load_timer(self, segment_id: str) -> Optional[TimerState]:
        raw = await self._client.get(_timer_key(segment_id))
        return TimerState(**json.loads(raw)) if raw else None

    async def clear_timer(self, segment_id: str) -> None:
        await self._client.delete(_timer_key(segment_id))

    async def increment_rate_counter(self, key: str, window_ms: int) -> int:
        """INCR + first-write PEXPIRE: a fixed window, atomic enough for rate limiting."""
        redis_key = _rate_key(key)
        count = await self._client.incr(redis_key)
        if count == 1:
            await self._client.pexpire(redis_key, window_ms)
        return count

    async def close(self) -> None:
        await self._client.aclose()

"""Migration runner: applies every .sql file in a migrations directory in
filename order, once each, tracked in `schema_migrations`.
~ apps/gateway/src/storage/migrate.ts.

There are two directories and two commands on purpose (§11.4, §11.6):
 - the default directory -> `backend/migrations`, the primary application Postgres;
 - `--archive` -> `backend/migrations/supabase`, the separate Supabase-hosted
   archive instance.

Keeping them apart means no single command can create the archive table in
the primary database, or the application schema in the archive — and this
only picks up files directly inside the given directory, so the `supabase/`
subdirectory can never be swept into the primary run by accident.
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path
from typing import Optional

import asyncpg

from app.paths import REPO_ROOT
from app.storage.postgres import create_pool

MIGRATIONS_DIR = REPO_ROOT / "backend" / "migrations"
ARCHIVE_MIGRATIONS_DIR = MIGRATIONS_DIR / "supabase"


async def migrate(database_url: str, directory: Path = MIGRATIONS_DIR, pool: Optional[asyncpg.Pool] = None) -> list[str]:
    owns_pool = pool is None
    pool = pool or await create_pool(database_url)
    applied: list[str] = []
    try:
        await pool.execute(
            """CREATE TABLE IF NOT EXISTS schema_migrations (
                 name TEXT PRIMARY KEY,
                 applied_at TIMESTAMPTZ NOT NULL DEFAULT now()
               )"""
        )
        files = sorted(p.name for p in directory.iterdir() if p.is_file() and p.suffix == ".sql")
        for name in files:
            already = await pool.fetchval("SELECT 1 FROM schema_migrations WHERE name = $1", name)
            if already:
                continue

            sql = (directory / name).read_text(encoding="utf-8")
            async with pool.acquire() as conn:
                async with conn.transaction():
                    try:
                        await conn.execute(sql)
                        await conn.execute("INSERT INTO schema_migrations (name) VALUES ($1)", name)
                    except Exception as err:  # noqa: BLE001
                        raise RuntimeError(f"migration {name} failed: {err}") from err
            applied.append(name)
        return applied
    finally:
        if owns_pool:
            await pool.close()


async def migrate_archive(connection_string: str) -> list[str]:
    """(Stage 5, §11.6) The Supabase archive instance. Its own pool because
    Supabase terminates TLS with a chain the default trust store does not
    carry, and its own connection string because it must never be the
    primary database."""
    pool = await asyncpg.create_pool(dsn=connection_string, ssl="require", max_size=2)
    return await migrate(connection_string, ARCHIVE_MIGRATIONS_DIR, pool)


async def _main() -> int:
    from app.paths import load_dot_env
    from app.config import load_config

    # DATABASE_URL and SUPABASE_DB_URL live in the repo-root `.env`; without
    # this the CLI would migrate whatever the compiled-in defaults point at.
    load_dot_env()
    config = load_config()
    archive_only = "--archive" in sys.argv

    if archive_only and not config.supabase_db_url:
        sys.stderr.write("SUPABASE_DB_URL is not set; nothing to migrate on the archive instance\n")
        return 1

    try:
        applied = await (migrate_archive(config.supabase_db_url) if archive_only else migrate(config.database_url))
    except Exception as err:  # noqa: BLE001
        sys.stderr.write(f"{err}\n")
        return 1

    sys.stdout.write(f"applied: {', '.join(applied)}\n" if applied else "no pending migrations\n")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(_main()))

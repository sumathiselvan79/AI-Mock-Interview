"""Postgres storage driver. Mirrors `memory.py` port-for-port, including the
Harness-Agent-only state write — enforced here in application code *and*
again by the CHECK constraint on `session_state_transitions.actor`.
~ apps/gateway/src/storage/postgres.ts.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any, Optional

import asyncpg

from app.shared_types import (
    DEFAULT_CONSENT,
    DEFAULT_QUESTION_BUDGET,
    PasscodeResetToken,
    Role,
    Session,
    SessionState,
    SessionStateTransition,
    StateWriteGrant,
    TelemetryEvent,
    TelemetryEventType,
    TelemetryPayload,
    TopicPlanEntry,
    User,
    UserProfile,
)
from app.storage.memory import StateWriteForbidden, sanitize_telemetry_payload


async def _init_connection(conn: asyncpg.Connection) -> None:
    """asyncpg does not decode json/jsonb columns by default (unlike node-pg,
    which does and is why the TS driver never calls `JSON.parse`) — this codec
    makes the two behave the same way, so the row-mapping code below can read
    `row["jd_fit"]` as a dict rather than a JSON string everywhere it appears.
    """
    await conn.set_type_codec("jsonb", encoder=json.dumps, decoder=json.loads, schema="pg_catalog")
    await conn.set_type_codec("json", encoder=json.dumps, decoder=json.loads, schema="pg_catalog")


def create_pool(database_url: str) -> Any:
    """A ready-to-`await` asyncpg pool builder, for callers that own their
    own event loop start-to-finish (`storage/migrate.py`'s CLI, a script run
    via `asyncio.run`). `pool = await create_pool(url)` connects immediately.

    NOT what `storage/create_storage` uses — see `LazyPool` below for why.
    """
    return asyncpg.create_pool(dsn=database_url, init=_init_connection, min_size=1, max_size=10)


class LazyPool:
    """A pool that can be *constructed* before any event loop exists and
    *connected* later, inside whichever loop will actually run queries.

    `asyncpg.Pool.__init__` calls `asyncio.get_event_loop()` and stores the
    result as `self._loop` — eagerly, at construction, not at connect time.
    Building the real pool at `create_app()`-time (before uvicorn's loop
    exists, or inside a *different* loop than the one a test client's portal
    thread uses) permanently binds it to the wrong loop; every query then
    fails with `InterfaceError: cannot perform operation: another operation
    is in progress` or `Future ... attached to a different loop`. This class
    defers the real `asyncpg.create_pool(...)` call to `connect()`, called
    from a FastAPI startup hook that runs inside the serving loop, while
    still giving every `Postgres*Store` a single stable object to hold onto
    from `create_storage()` before that loop exists.
    """

    def __init__(self, database_url: str) -> None:
        self._database_url = database_url
        self._pool: Optional[asyncpg.Pool] = None

    async def connect(self) -> None:
        self._pool = await asyncpg.create_pool(dsn=self._database_url, init=_init_connection, min_size=1, max_size=10)

    def _require(self) -> asyncpg.Pool:
        if self._pool is None:
            raise RuntimeError("storage pool used before `await storage.connect()` — is the FastAPI startup hook wired up?")
        return self._pool

    async def fetchrow(self, *args: Any, **kwargs: Any) -> Any:
        return await self._require().fetchrow(*args, **kwargs)

    async def fetch(self, *args: Any, **kwargs: Any) -> Any:
        return await self._require().fetch(*args, **kwargs)

    async def fetchval(self, *args: Any, **kwargs: Any) -> Any:
        return await self._require().fetchval(*args, **kwargs)

    async def execute(self, *args: Any, **kwargs: Any) -> Any:
        return await self._require().execute(*args, **kwargs)

    def acquire(self, *args: Any, **kwargs: Any) -> Any:
        return self._require().acquire(*args, **kwargs)

    async def close(self) -> None:
        if self._pool is not None:
            await self._pool.close()


def _blank_to_null(value: Optional[str]) -> Optional[str]:
    """A whitespace-only profile field is not a value; it must not overwrite one."""
    return value.strip() if value and value.strip() else None


def _iso(value: Any) -> str:
    return value.isoformat() if isinstance(value, datetime) else value


def _parse_dt(value: str) -> datetime:
    """asyncpg binds a TIMESTAMPTZ parameter against a `datetime`, not a raw
    ISO string (unlike node-pg, which accepts either) — every caller in this
    file that receives an ISO string destined for a timestamptz column parses
    it here first rather than relying on an implicit cast."""
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)


def _normalize_focus_events(raw: Any) -> list[dict[str, Any]]:
    if not raw:
        return []
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except Exception:
            return []
    if not isinstance(raw, list):
        return []
    out: list[dict[str, Any]] = []
    for item in raw:
        if isinstance(item, str):
            try:
                parsed = json.loads(item)
                if isinstance(parsed, list):
                    for sub in parsed:
                        if isinstance(sub, dict):
                            out.append(sub)
                elif isinstance(parsed, dict):
                    out.append(parsed)
            except Exception:
                continue
        elif isinstance(item, dict):
            out.append(item)
    return out


def _parse_json_dict(raw: Any) -> dict[str, Any]:
    if not raw:
        return {}
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
            return parsed if isinstance(parsed, dict) else {}
        except Exception:
            return {}
    if isinstance(raw, dict):
        return raw
    return {}


def _parse_json_opt(raw: Any) -> Any:
    if not raw:
        return None
    if isinstance(raw, str):
        try:
            return json.loads(raw)
        except Exception:
            return None
    return raw


def _to_user(row: asyncpg.Record) -> User:
    return User(
        id=str(row["id"]),
        email=row["email"],
        role=row["role"],
        passcode_hash=row["passcode_hash"],
        cross_session_memory_opt_in=row["cross_session_memory_opt_in"],
        full_name=row["full_name"] or None,
        department=row["department"] or None,
        program_year=row["program_year"] or None,
        created_at=_iso(row["created_at"]),
    )


class PostgresUserStore:
    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool

    async def create(
        self,
        *,
        email: str,
        role: Role,
        passcode_hash: str,
        cross_session_memory_opt_in: bool = False,
        profile: Optional[UserProfile] = None,
    ) -> User:
        normalized = email.strip().lower()
        try:
            row = await self._pool.fetchrow(
                """INSERT INTO users (email, role, passcode_hash, cross_session_memory_opt_in, full_name, department, program_year)
                   VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *""",
                normalized,
                role,
                passcode_hash,
                cross_session_memory_opt_in,
                _blank_to_null(profile.full_name if profile else None),
                _blank_to_null(profile.department if profile else None),
                _blank_to_null(profile.program_year if profile else None),
            )
        except asyncpg.UniqueViolationError as err:
            # `MemoryUserStore.create` raises the same `ValueError` shape —
            # `http/routes/auth.py`'s register handler pattern-matches on it
            # (`_ALREADY_EXISTS`) to return 409 rather than a raw 500. The
            # in-memory driver never needed a try/except for this because a
            # plain Python dict has no unique constraint of its own to
            # violate; Postgres does, so the two drivers only agree here if
            # the constraint violation is translated to the same exception.
            raise ValueError(f"user already exists: {normalized}") from err
        return _to_user(row)

    async def update_profile(self, user_id: str, profile: UserProfile) -> User:
        """COALESCE so an absent key keeps whatever is stored — a partial
        profile update must not blank a field the candidate already gave."""
        row = await self._pool.fetchrow(
            """UPDATE users
                  SET full_name    = COALESCE($2, full_name),
                      department   = COALESCE($3, department),
                      program_year = COALESCE($4, program_year)
                WHERE id = $1
              RETURNING *""",
            user_id,
            _blank_to_null(profile.full_name),
            _blank_to_null(profile.department),
            _blank_to_null(profile.program_year),
        )
        if not row:
            raise ValueError(f"unknown user {user_id}")
        return _to_user(row)

    async def find_by_email(self, email: str) -> Optional[User]:
        row = await self._pool.fetchrow("SELECT * FROM users WHERE email = $1", email.strip().lower())
        return _to_user(row) if row else None

    async def find_by_id(self, user_id: str) -> Optional[User]:
        row = await self._pool.fetchrow("SELECT * FROM users WHERE id = $1", user_id)
        return _to_user(row) if row else None

    async def update_passcode_hash(self, user_id: str, passcode_hash: str) -> None:
        await self._pool.execute("UPDATE users SET passcode_hash = $2 WHERE id = $1", user_id, passcode_hash)

    async def upsert_identity(self, *, email: str, role: Role, unusable_passcode_hash: str) -> User:
        """`ON CONFLICT` syncs `role` AND replaces `passcode_hash` with the
        unusable one. `/auth/register` never proves the registrant owns the
        address, so a passcode on a row that predates the first verified
        identity login may be an attacker's: audit P0-1 registered an
        allowlisted admin email, waited for the admin's Google login to raise
        the row to `admin`, then logged in with the passcode it had chosen.
        The verified login is the first proof of ownership, so whatever
        passcode came before it is discarded. The owner can set a new one
        through the reset flow, which proves the mailbox."""
        row = await self._pool.fetchrow(
            """INSERT INTO users (email, role, passcode_hash)
               VALUES ($1, $2, $3)
               ON CONFLICT (email) DO UPDATE
                 SET role = EXCLUDED.role,
                     passcode_hash = EXCLUDED.passcode_hash
               RETURNING *""",
            email.strip().lower(),
            role,
            unusable_passcode_hash,
        )
        return _to_user(row)

    async def raw_row(self, user_id: str) -> Optional[dict[str, Any]]:
        row = await self._pool.fetchrow("SELECT * FROM users WHERE id = $1", user_id)
        return dict(row) if row else None

    async def list_by_role(self, role: Role) -> list[User]:
        rows = await self._pool.fetch("SELECT * FROM users WHERE role = $1 ORDER BY created_at", role)
        return [_to_user(r) for r in rows]


class PostgresResetTokenStore:
    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool

    async def create(self, user_id: str, token_hash: str, expires_at: str) -> PasscodeResetToken:
        async with self._pool.acquire() as conn:
            await conn.execute(
                "UPDATE passcode_reset_tokens SET used_at = now() WHERE user_id = $1 AND used_at IS NULL",
                user_id,
            )
            row = await conn.fetchrow(
                """INSERT INTO passcode_reset_tokens (user_id, token_hash, expires_at)
                   VALUES ($1, $2, $3) RETURNING id, user_id, token_hash, expires_at, used_at""",
                user_id,
                token_hash,
                _parse_dt(expires_at),
            )
        return PasscodeResetToken(
            id=str(row["id"]),
            user_id=str(row["user_id"]),
            token_hash=row["token_hash"],
            expires_at=_iso(row["expires_at"]),
            used_at=_iso(row["used_at"]) if row["used_at"] else None,
        )

    async def find_valid_by_hash(self, token_hash: str, now: datetime) -> Optional[PasscodeResetToken]:
        row = await self._pool.fetchrow(
            """SELECT id, user_id, token_hash, expires_at, used_at FROM passcode_reset_tokens
               WHERE token_hash = $1 AND used_at IS NULL AND expires_at > $2""",
            token_hash,
            now,
        )
        if not row:
            return None
        return PasscodeResetToken(
            id=str(row["id"]), user_id=str(row["user_id"]), token_hash=row["token_hash"], expires_at=_iso(row["expires_at"]), used_at=None
        )

    async def mark_used(self, reset_id: str, at: str) -> None:
        await self._pool.execute("UPDATE passcode_reset_tokens SET used_at = $2 WHERE id = $1", reset_id, _parse_dt(at))


class PostgresSessionStore:
    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool
        self._grant: Optional[StateWriteGrant] = None

    def register_state_writer(self, grant: StateWriteGrant) -> None:
        if self._grant is not None and self._grant.token is not grant.token:
            raise StateWriteForbidden("a state writer is already registered for this store")
        if grant.actor != "harness-agent":
            raise StateWriteForbidden(f"state writer must be harness-agent, got {grant.actor}")
        self._grant = grant

    async def _hydrate(self, row: asyncpg.Record, conn: Optional[Any] = None) -> Session:
        executor = conn or self._pool
        plan_rows = await executor.fetch(
            "SELECT topic, max_questions, source FROM topic_plan_entries WHERE session_id = $1 ORDER BY topic",
            row["id"],
        )
        # Both sides merged in the same (camelCase, wire-alias) casing that
        # `consent` is actually stored in — mixing `model_dump()`'s snake_case
        # keys into a dict that also carries the row's camelCase keys would
        # leave two spellings of the same field sitting in one dict instead
        # of one overriding the other.
        raw_consent = _parse_json_dict(row["consent"])
        consent = {**DEFAULT_CONSENT.model_dump(by_alias=True), **raw_consent}
        return Session(
            id=str(row["id"]),
            candidate_id=str(row["candidate_id"]),
            role=row["role"],
            job_description=row["job_description"],
            jd_fit=_parse_json_opt(row["jd_fit"]),
            state=row["state"],
            # Merge onto DEFAULT_CONSENT so a row written before
            # `focus_loss_monitoring` existed hydrates as `false` for it
            # rather than being absent.
            consent=consent,
            question_budget=row["question_budget"],
            topic_plan=[
                TopicPlanEntry(topic=p["topic"], max_questions=p["max_questions"], source=p["source"]) for p in plan_rows
            ],
            resume_ref=row["resume_ref"],
            candidate_profile=_parse_json_opt(row["candidate_profile"]),
            jd_gap_topics=_parse_json_opt(row["jd_gap_topics"]) or [],
            jd_fit_fingerprint=row["jd_fit_fingerprint"],
            focus_events=_normalize_focus_events(row["focus_events"]),
            created_at=_iso(row["created_at"]),
            updated_at=_iso(row["updated_at"]),
        )

    async def create(
        self, *, candidate_id: str, role: str, job_description: str, question_budget: Optional[int] = None
    ) -> Session:
        row = await self._pool.fetchrow(
            """INSERT INTO sessions (candidate_id, role, job_description, question_budget)
               VALUES ($1, $2, $3, $4) RETURNING *""",
            candidate_id,
            role,
            job_description,
            question_budget if question_budget is not None else DEFAULT_QUESTION_BUDGET,
        )
        return await self._hydrate(row)

    async def get(self, session_id: str) -> Optional[Session]:
        row = await self._pool.fetchrow("SELECT * FROM sessions WHERE id = $1", session_id)
        return await self._hydrate(row) if row else None

    async def list_by_candidate(self, candidate_id: str) -> list[Session]:
        rows = await self._pool.fetch("SELECT * FROM sessions WHERE candidate_id = $1 ORDER BY created_at DESC", candidate_id)
        return [await self._hydrate(r) for r in rows]

    async def set_state(self, session_id: str, to_state: SessionState, grant: StateWriteGrant, reason: str) -> Session:
        if self._grant is None or grant is None or grant.token is not self._grant.token or grant.actor != "harness-agent":
            raise StateWriteForbidden("Session.state may only be written by the Harness Agent (INSTRUCTIONS.md §3)")

        async with self._pool.acquire() as conn:
            async with conn.transaction():
                current = await conn.fetchrow("SELECT * FROM sessions WHERE id = $1 FOR UPDATE", session_id)
                if not current:
                    raise ValueError(f"unknown session {session_id}")

                await conn.execute(
                    """INSERT INTO session_state_transitions (session_id, from_state, to_state, actor, reason)
                       VALUES ($1, $2, $3, $4, $5)""",
                    session_id,
                    current["state"],
                    to_state,
                    grant.actor,
                    reason,
                )
                updated = await conn.fetchrow(
                    "UPDATE sessions SET state = $2, updated_at = now() WHERE id = $1 RETURNING *", session_id, to_state
                )
                return await self._hydrate(updated, conn)

    async def transitions(self, session_id: str) -> list[SessionStateTransition]:
        rows = await self._pool.fetch(
            """SELECT id, session_id, from_state, to_state, actor, reason, at
               FROM session_state_transitions WHERE session_id = $1 ORDER BY at""",
            session_id,
        )
        return [
            SessionStateTransition(
                id=str(r["id"]),
                session_id=str(r["session_id"]),
                from_state=r["from_state"],
                to_state=r["to_state"],
                actor=r["actor"],
                reason=r["reason"],
                at=_iso(r["at"]),
            )
            for r in rows
        ]

    async def patch(self, session_id: str, patch: dict[str, Any]) -> Session:
        sets: list[str] = []
        values: list[Any] = [session_id]

        def push(fragment: str, value: Any) -> None:
            values.append(value)
            sets.append(f"{fragment} = ${len(values)}")

        if "consent" in patch:
            consent = patch["consent"]
            push("consent", consent.model_dump(by_alias=True) if hasattr(consent, "model_dump") else consent)
        if "resume_ref" in patch:
            push("resume_ref", patch["resume_ref"])
        if "jd_fit" in patch:
            jd_fit = patch["jd_fit"]
            push("jd_fit", jd_fit.model_dump(by_alias=True) if hasattr(jd_fit, "model_dump") else jd_fit)
        if "question_budget" in patch:
            push("question_budget", patch["question_budget"])
        if "candidate_profile" in patch:
            profile = patch["candidate_profile"]
            push("candidate_profile", profile.model_dump(by_alias=True) if hasattr(profile, "model_dump") else profile)
        if "jd_gap_topics" in patch:
            push("jd_gap_topics", patch["jd_gap_topics"])
        if "jd_fit_fingerprint" in patch:
            push("jd_fit_fingerprint", patch["jd_fit_fingerprint"])
        if "focus_events" in patch:
            events = patch["focus_events"]
            push("focus_events", [e.model_dump(by_alias=True) if hasattr(e, "model_dump") else e for e in events])

        if sets:
            await self._pool.execute(f"UPDATE sessions SET {', '.join(sets)}, updated_at = now() WHERE id = $1", *values)

        if "topic_plan" in patch:
            async with self._pool.acquire() as conn:
                async with conn.transaction():
                    await conn.execute("DELETE FROM topic_plan_entries WHERE session_id = $1", session_id)
                    for entry in patch["topic_plan"]:
                        topic = entry.topic if hasattr(entry, "topic") else entry["topic"]
                        max_q = entry.max_questions if hasattr(entry, "max_questions") else entry["max_questions"]
                        source = entry.source if hasattr(entry, "source") else entry["source"]
                        await conn.execute(
                            "INSERT INTO topic_plan_entries (session_id, topic, max_questions, source) VALUES ($1, $2, $3, $4)",
                            session_id,
                            topic,
                            max_q,
                            source,
                        )

        session = await self.get(session_id)
        if not session:
            raise ValueError(f"unknown session {session_id}")
        return session

    async def append_focus_event(self, session_id: str, timestamp: str) -> dict[str, int]:
        """One `UPDATE ... focus_events = focus_events || $2` rather than this
        class's own `get()` then `patch()` — Postgres applies that append and
        recomputes the row atomically per statement, so two exits recorded in
        the same instant still both land instead of the second write
        clobbering the first's read-before-write."""
        row = await self._pool.fetchrow(
            """UPDATE sessions
               SET focus_events = focus_events || $2::jsonb, updated_at = now()
               WHERE id = $1
               RETURNING jsonb_array_length(focus_events) AS exit_count""",
            session_id,
            [{"timestamp": timestamp}],
        )
        if not row:
            raise ValueError(f"unknown session {session_id}")
        return {"exit_count": row["exit_count"]}

    async def counts_by_candidate(self) -> dict[str, int]:
        rows = await self._pool.fetch("SELECT candidate_id, COUNT(*) AS count FROM sessions GROUP BY candidate_id")
        return {str(r["candidate_id"]): r["count"] for r in rows}


class PostgresTelemetrySink:
    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool

    async def emit(self, event_type: TelemetryEventType, session_id: Optional[str], payload: TelemetryPayload) -> TelemetryEvent:
        safe = sanitize_telemetry_payload(payload)
        row = await self._pool.fetchrow(
            "INSERT INTO telemetry_events (event_type, session_id, payload) VALUES ($1, $2, $3) RETURNING id, emitted_at",
            event_type,
            session_id,
            safe,
        )
        return TelemetryEvent(id=str(row["id"]), event_type=event_type, session_id=session_id, payload=safe, emitted_at=_iso(row["emitted_at"]))

    async def recent(self, limit: int = 100) -> list[TelemetryEvent]:
        rows = await self._pool.fetch(
            "SELECT id, event_type, session_id, payload, emitted_at FROM telemetry_events ORDER BY emitted_at DESC LIMIT $1",
            limit,
        )
        events = [
            TelemetryEvent(
                id=str(r["id"]),
                event_type=r["event_type"],
                session_id=str(r["session_id"]) if r["session_id"] else None,
                payload=r["payload"],
                emitted_at=_iso(r["emitted_at"]),
            )
            for r in rows
        ]
        return list(reversed(events))

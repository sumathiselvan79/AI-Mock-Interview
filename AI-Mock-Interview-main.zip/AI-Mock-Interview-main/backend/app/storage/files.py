"""Blob storage for uploaded resumes (audio follows in a later stage) — ~ apps/gateway/src/storage/files.ts.

`delete` is a hard delete in both drivers — the bytes are removed, not
unlinked from an index (INSTRUCTIONS.md §8). `exists` reads the backing store
directly so a deletion test can check the real thing rather than a cache.
"""

from __future__ import annotations

import json
import re
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from app.shared_types.base import CamelModel

_SAFE_CHARS = re.compile(r"[^\w.\-]+")


class StoredFileMeta(CamelModel):
    ref: str
    session_id: str
    filename: str
    content_type: str
    size_bytes: int
    uploaded_at: str


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _new_ref(session_id: str, filename: str) -> str:
    safe = _SAFE_CHARS.sub("_", filename)[-80:]
    return f"{session_id}/{uuid.uuid4()}-{safe}"


class MemoryFileStore:
    def __init__(self) -> None:
        self._files: dict[str, tuple[StoredFileMeta, bytes]] = {}

    async def put(self, *, session_id: str, filename: str, content_type: str, data: bytes) -> StoredFileMeta:
        meta = StoredFileMeta(
            ref=_new_ref(session_id, filename),
            session_id=session_id,
            filename=filename,
            content_type=content_type,
            size_bytes=len(data),
            uploaded_at=_now(),
        )
        self._files[meta.ref] = (meta, bytes(data))
        return meta

    async def get(self, ref: str) -> Optional[tuple[StoredFileMeta, bytes]]:
        found = self._files.get(ref)
        return (found[0], found[1]) if found else None

    async def stat(self, ref: str) -> Optional[StoredFileMeta]:
        found = self._files.get(ref)
        return found[0] if found else None

    async def exists(self, ref: str) -> bool:
        return ref in self._files

    async def delete(self, ref: str) -> bool:
        return self._files.pop(ref, None) is not None

    async def list_by_session(self, session_id: str) -> list[StoredFileMeta]:
        return [meta for meta, _ in self._files.values() if meta.session_id == session_id]


class DiskFileStore:
    """Disk-backed store. Metadata sits beside each blob as `<name>.meta.json`."""

    def __init__(self, root: str) -> None:
        self._root = Path(root).resolve()

    def _path(self, ref: str) -> Path:
        full = (self._root / ref).resolve()
        # Refs are generated internally, but a path-traversal check costs
        # nothing and this function takes a value that has crossed a process
        # boundary.
        if self._root not in full.parents and full != self._root:
            raise ValueError("invalid file ref")
        return full

    async def put(self, *, session_id: str, filename: str, content_type: str, data: bytes) -> StoredFileMeta:
        meta = StoredFileMeta(
            ref=_new_ref(session_id, filename),
            session_id=session_id,
            filename=filename,
            content_type=content_type,
            size_bytes=len(data),
            uploaded_at=_now(),
        )
        target = self._path(meta.ref)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        target.with_name(target.name + ".meta.json").write_text(
            meta.model_dump_json(by_alias=True), encoding="utf-8"
        )
        return meta

    async def get(self, ref: str) -> Optional[tuple[StoredFileMeta, bytes]]:
        meta = await self.stat(ref)
        if not meta:
            return None
        return meta, self._path(ref).read_bytes()

    async def stat(self, ref: str) -> Optional[StoredFileMeta]:
        meta_path = self._path(ref).with_name(self._path(ref).name + ".meta.json")
        if not meta_path.exists():
            return None
        return StoredFileMeta.model_validate_json(meta_path.read_text(encoding="utf-8"))

    async def exists(self, ref: str) -> bool:
        return self._path(ref).exists()

    async def delete(self, ref: str) -> bool:
        target = self._path(ref)
        if not target.exists():
            return False
        target.unlink(missing_ok=True)
        target.with_name(target.name + ".meta.json").unlink(missing_ok=True)
        return True

    async def list_by_session(self, session_id: str) -> list[StoredFileMeta]:
        directory = self._root / session_id
        if not directory.exists():
            return []
        metas: list[StoredFileMeta] = []
        for entry in directory.iterdir():
            if entry.name.endswith(".meta.json") and entry.is_file():
                metas.append(StoredFileMeta.model_validate_json(entry.read_text(encoding="utf-8")))
        return metas

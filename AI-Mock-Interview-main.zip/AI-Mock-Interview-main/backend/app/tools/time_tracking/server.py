"""Time Tracking Tool — ~ mcp-servers/tool-time-tracking/src/index.ts. INSTRUCTIONS.md §5.3.

Redis-backed segment timers (via `LiveSessionStore`). No agent runs its own
timers (CLAUDE.md §10); they all come here, so a session's pacing is one
clock rather than seven.

`get_elapsed` reports `nudge` before `expired` so the harness always has a
heads-up state to act on — a segment is never silently cut off (§4.6).
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Callable, Literal, Optional

from app.shared_types import McpCallContext, McpHandlerError
from app.storage.types import TimerState

SERVER_NAME = "tool-time-tracking"
METHODS = ("start_timer", "pause_timer", "resume_timer", "get_elapsed")

SegmentState = Literal["on_track", "nudge", "expired"]

# Warn once a segment is inside the last 20% of its budget, or its last 30s.
NUDGE_FRACTION = 0.2
NUDGE_FLOOR_MS = 30_000


@dataclass
class TimeTrackingDeps:
    timers: Any  # LiveSessionStore (satisfies save_timer/load_timer/clear_timer)
    now: Callable[[], float] = lambda: time.time() * 1000  # injectable so tests can advance time without sleeping


def elapsed_ms(timer: TimerState, now: float) -> float:
    """Paused time never counts against the candidate's budget."""
    frozen = 0 if timer.paused_at is None else now - timer.paused_at
    return max(0, now - timer.started_at - timer.paused_ms - frozen)


def segment_state_for(remaining_ms: float, budget_ms: float) -> SegmentState:
    if remaining_ms <= 0:
        return "expired"
    threshold = max(budget_ms * NUDGE_FRACTION, min(NUDGE_FLOOR_MS, budget_ms))
    return "nudge" if remaining_ms <= threshold else "on_track"


class ToolTimeTrackingServer:
    name = SERVER_NAME

    def __init__(self, deps: TimeTrackingDeps) -> None:
        self._deps = deps

    async def _load(self, segment_id: str) -> TimerState:
        timer = await self._deps.timers.load_timer(segment_id)
        if not timer:
            raise McpHandlerError("unknown_segment", f"no timer for segment {segment_id}")
        return timer

    async def call(self, method: str, params: Any, ctx: McpCallContext) -> Any:
        p = params or {}
        segment_id = p.get("segment_id")
        now = self._deps.now()

        if method == "start_timer":
            state = TimerState(segment_id=segment_id, budget_ms=p["budget_ms"], started_at=now, paused_at=None, paused_ms=0)
            await self._deps.timers.save_timer(state)
            return {"segment_id": state.segment_id, "started_at": _iso(state.started_at)}

        if method == "pause_timer":
            timer = await self._load(segment_id)
            if timer.paused_at is None:
                timer.paused_at = now
                await self._deps.timers.save_timer(timer)
            return {"paused": True, "elapsed_ms": int(elapsed_ms(timer, now))}

        if method == "resume_timer":
            timer = await self._load(segment_id)
            if timer.paused_at is not None:
                timer.paused_ms += now - timer.paused_at
                timer.paused_at = None
                await self._deps.timers.save_timer(timer)
            return {"resumed": True, "elapsed_ms": int(elapsed_ms(timer, now))}

        if method == "get_elapsed":
            timer = await self._load(segment_id)
            elapsed = elapsed_ms(timer, now)
            remaining = timer.budget_ms - elapsed
            return {
                "elapsed_ms": int(elapsed),
                "remaining_ms": int(remaining),
                "segment_state": segment_state_for(remaining, timer.budget_ms),
            }

        raise McpHandlerError("unknown_method", f"{SERVER_NAME} has no method {method}")


def _iso(epoch_ms: float) -> str:
    return datetime.fromtimestamp(epoch_ms / 1000, tz=timezone.utc).isoformat()


def create_tool_time_tracking_server(deps: TimeTrackingDeps) -> ToolTimeTrackingServer:
    return ToolTimeTrackingServer(deps)

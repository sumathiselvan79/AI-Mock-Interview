"""Sound-source recognition — did this audio come in through the candidate's
**microphone**, or is it the **speaker** playing our own voice back at us?

The failure this prevents is specific and quietly serious. The interview speaks
its question aloud. If the candidate is on open speakers rather than a headset,
the microphone hears that question. If they then start recording — or if the
recording overlaps the tail of the question — the audio submitted as their
answer contains the interviewer's words. Whisper transcribes them accurately,
the Follow-up Agent probes them, and the Eval Tool scores the candidate on a
sentence the system said itself.

Nothing downstream can catch that. The transcript is fluent, on-topic and
confidently transcribed; it looks exactly like a good answer. It has to be
caught at the point the audio arrives, which is here.

Two independent signals, combined by `classify`:

 - **What the browser says the device is** (`device_hint`). The client knows
   things the audio cannot tell us: which device the track came from, whether
   echo cancellation is on, and whether the device is a loopback ("Stereo Mix",
   "What U Hear", "CABLE Output"). A loopback device is not evidence of an echo
   problem — it *is* one, by definition, and is treated as conclusive.
 - **What the audio actually says** (`spoken_recently`). The strongest possible
   evidence that a recording is our own voice is that it says what we just
   said. Comparing the transcript against the last line the Speech Service
   synthesised catches the real case regardless of what the browser reported,
   including on browsers that report nothing useful.

**A hint is a hint.** The client half is candidate-controlled and therefore
never trusted on its own to *clear* audio — it can raise suspicion but a
`microphone` claim does not suppress the transcript check. The transcript
check, by contrast, is evidence the server derived itself.

**Uncertainty is `unknown`, never a guess.** `unknown` means "carry on and
score this normally", which is the pre-existing behaviour and the right default:
wrongly rejecting a real answer costs the candidate a turn they cannot redo,
and this classifier is not confident enough to be given that power on a hunch.
Only a conclusive signal returns `speaker`.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Literal, Optional, Sequence

SoundSource = Literal["microphone", "speaker", "unknown"]

#: Device labels that ARE a loopback of system output. Matched case-insensitively
#: as substrings of the label the browser reports for the capture device.
_LOOPBACK_LABELS = (
    "stereo mix",
    "what u hear",
    "wave out",
    "loopback",
    "cable output",
    "voicemeeter out",
    "blackhole",
    "soundflower",
    "monitor of ",  # PulseAudio/PipeWire name for an output monitor source
)

# How echo is recognised, and why it is a RUN of words rather than a bag of them.
#
# The obvious test is "how much vocabulary does the transcript share with what
# we just said". It is the wrong test, and dangerously so: a candidate
# answering "we shipped the billing feature under deadline pressure" shares
# most of its content words with "tell me about a time you shipped something
# under deadline pressure", because answering a question in its own terms is
# what answering a question looks like. Rejecting that answer costs the
# candidate a turn they cannot redo.
#
# An echo is not a paraphrase, it is a *recording of the same sentence*, so it
# reproduces word order. A run of consecutive words is therefore the signal
# that separates the two cleanly — a candidate will reuse a question's
# vocabulary and will not reproduce six of its words in sequence.

#: Consecutive words shared with a spoken line before it counts as echo. Six is
#: past the length of any phrase two people would land on independently.
ECHO_RUN_WORDS = 6

#: …or this share of the shorter line, for a spoken line too short to contain
#: six words in the first place ("Let's move to something different.").
ECHO_RUN_RATIO = 0.7

#: Below this many words there is nothing to match a run against.
MIN_WORDS_FOR_ECHO = 5

#: Dropped before the run comparison. Only recogniser noise — the sounds one
#: pass transcribes and another does not — so that a genuine echo is not broken
#: into two short runs by a stray "um".
_FILLERS = frozenset("um uh er erm mm hmm ah oh".split())

# Content-free words carry no evidence of echo — a transcript and a question
# both containing "the" says nothing about either. Used only by
# `_content_words`, which is the coarse pre-filter, not the decision.
_STOPWORDS = frozenset(
    """a an and are as at be been but by can could did do does for from had has have how i if in is it
    its me my of on or our so than that the their them then there these they this to us was we were what
    when where which who why will with would you your""".split()
)

_WORD_RE = re.compile(r"[a-z0-9']+")


@dataclass(frozen=True)
class SourceVerdict:
    source: SoundSource
    #: Why, in words a human reading telemetry can act on. Never a bare code:
    #: "this was rejected as speaker echo" is only useful alongside which of the
    #: two signals fired.
    reason: str
    #: True when the audio must not be scored as an answer. Only ever set for
    #: `speaker` — see the module docstring on why `unknown` proceeds.
    reject: bool = False
    #: Calibrated confidence in echo detection (0.0 to 1.0)
    echo_confidence: float = 0.0
    #: Graduated classification: normal, possible_echo, likely_echo
    status: str = "normal"


def classify(
    *,
    transcript: str = "",
    device_hint: Optional[str] = None,
    device_label: Optional[str] = None,
    spoken_recently: Sequence[str] = (),
    tts_playing_at: Optional[float] = None,
    recording_started_at: Optional[float] = None,
) -> SourceVerdict:
    """Where this audio came from.

    `device_hint` is the client's own classification (`microphone` / `speaker`
    / `unknown`); `device_label` is the raw device name it read from
    `MediaStreamTrack.getSettings()`, checked here rather than trusted from the
    client so the loopback list has one home. `spoken_recently` is the last few
    lines the Speech Service synthesised for this session.
    `tts_playing_at` and `recording_started_at` allow timing-aware overlap detection.
    """
    label = (device_label or "").strip().lower()
    if label and any(marker in label for marker in _LOOPBACK_LABELS):
        return SourceVerdict(
            "speaker",
            f"the capture device ({device_label!r}) is a loopback of system output, so this audio is playback, not a voice",
            reject=True,
            echo_confidence=1.0,
            status="likely_echo",
        )

    echoed = _echoed_line(transcript, spoken_recently)
    if echoed is not None:
        return SourceVerdict(
            "speaker",
            "the recording repeats the line the interview just spoke, so the microphone picked up the speakers rather than an answer",
            reject=True,
            echo_confidence=0.95,
            status="likely_echo",
        )

    # Check temporal overlap with TTS playback if timestamps are supplied
    tts_overlap = False
    if tts_playing_at is not None and recording_started_at is not None:
        # If recording started while TTS was still active or within 1.5s of it
        if abs(recording_started_at - tts_playing_at) < 2.0:
            tts_overlap = True

    if (device_hint or "").lower() == "speaker":
        # The client believes it is capturing output but the transcript does not
        # corroborate it. Reported, not rejected: acting on the hint alone would
        # let a mislabelled device silently swallow real answers.
        return SourceVerdict(
            "speaker",
            "the browser reported a system-output capture device, but the transcript does not match anything recently spoken",
            reject=False,
            echo_confidence=0.5,
            status="possible_echo",
        )

    if tts_overlap:
        return SourceVerdict(
            "unknown",
            "recording timing coincided with system audio playback, possible speaker bleed",
            reject=False,
            echo_confidence=0.4,
            status="possible_echo",
        )

    if (device_hint or "").lower() == "microphone":
        return SourceVerdict(
            "microphone",
            "captured from a microphone input",
            reject=False,
            echo_confidence=0.0,
            status="normal",
        )

    return SourceVerdict(
        "unknown",
        "no usable device information and nothing matching what was recently spoken",
        reject=False,
        echo_confidence=0.0,
        status="normal",
    )


def _echoed_line(transcript: str, spoken_recently: Sequence[str]) -> Optional[str]:
    """The recently spoken line this transcript is a recording of, if any."""
    heard = _words(transcript)
    if len(heard) < MIN_WORDS_FOR_ECHO:
        return None

    for line in spoken_recently:
        said = _words(line)
        if len(said) < MIN_WORDS_FOR_ECHO:
            continue
        run = _longest_common_run(heard, said)
        # Measured against the SHORTER side, so a recording that caught only
        # the tail of a long question — the common case, when the candidate
        # starts recording before the question has finished playing — still
        # reads as echo.
        if run >= ECHO_RUN_WORDS or run / min(len(heard), len(said)) >= ECHO_RUN_RATIO:
            return line
    return None


def _longest_common_run(a: list[str], b: list[str]) -> int:
    """Length of the longest run of consecutive words the two share.

    The classic DP, over word lists that are at most a sentence or two — this
    runs once per transcription, on audio that already cost a Whisper decode.
    """
    if not a or not b:
        return 0
    previous = [0] * (len(b) + 1)
    best = 0
    for i in range(1, len(a) + 1):
        current = [0] * (len(b) + 1)
        for j in range(1, len(b) + 1):
            if a[i - 1] == b[j - 1]:
                current[j] = previous[j - 1] + 1
                if current[j] > best:
                    best = current[j]
        previous = current
    return best


def _words(text: str) -> list[str]:
    """Word sequence, filler removed but ORDER PRESERVED — order is the signal.

    Only the fillers a speech recogniser sprinkles differently between two
    passes of the same audio are dropped, so a transcript of our own question
    still matches the question. Content words are all kept: dropping "the" and
    "of" would let two sentences with different structure share a run.
    """
    return [w for w in _WORD_RE.findall((text or "").lower()) if w not in _FILLERS]


def _content_words(text: str) -> frozenset[str]:
    return frozenset(w for w in _WORD_RE.findall((text or "").lower()) if w not in _STOPWORDS and len(w) > 1)

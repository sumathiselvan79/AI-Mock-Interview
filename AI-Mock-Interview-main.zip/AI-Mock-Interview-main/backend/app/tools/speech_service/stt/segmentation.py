"""Audio segmentation using VAD activity and hysteresis state machine.

Divides speech into coherent utterances by bridging brief conversational pauses
(hangover) while splitting on sustained silence (min_silence_ms). Applies safety
padding to preserve low-energy boundary consonants.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto
from typing import Optional

import numpy as np

from app.tools.speech_service.stt.config import STTPipelineConfig
from app.tools.speech_service.vad import (
    ABSOLUTE_SILENCE_DBFS,
    FRAME_MS,
    VoiceActivity,
    _drop_short_runs,
    frame_levels,
    noise_floor_percentile,
)


class VADState(Enum):
    SILENCE = auto()
    SPEECH_START = auto()
    SPEECH = auto()
    POSSIBLE_SILENCE = auto()


@dataclass(frozen=True)
class SpeechSegment:
    """A bounded segment of voiced speech suitable for transcription."""

    start_ms: float
    end_ms: float
    duration_ms: float
    samples: np.ndarray


def segment_audio(
    samples: np.ndarray,
    sample_rate: int,
    config: Optional[STTPipelineConfig] = None,
    activity: Optional[VoiceActivity] = None,
) -> list[SpeechSegment]:
    """Partitions `samples` into coherent speech segments using VAD and hangover logic.

    Adjacent speech regions separated by pauses shorter than `vad_min_silence_ms`
    are bridged into a continuous utterance. Trailing and leading margins (`vad_padding_ms`)
    are added to preserve weak fricatives and plosives.
    """
    cfg = config or STTPipelineConfig()
    if len(samples) == 0 or sample_rate <= 0:
        return []

    frame_len = max(1, int(sample_rate * cfg.vad_frame_ms / 1000))
    usable = (len(samples) // frame_len) * frame_len
    if usable < frame_len:
        return []

    levels = frame_levels(samples, frame_len)
    if activity is not None:
        noise_floor = activity.noise_floor_dbfs
        threshold = activity.threshold_dbfs
    else:
        noise_floor = noise_floor_percentile(levels)
        threshold = max(ABSOLUTE_SILENCE_DBFS, noise_floor + cfg.noise_margin_db)

    voiced = levels > threshold
    min_speech_frames = max(1, int(cfg.vad_min_speech_ms / cfg.vad_frame_ms))
    voiced = _drop_short_runs(voiced, min_frames=min_speech_frames)

    if not voiced.any():
        return []

    ms_per_frame = frame_len / sample_rate * 1000.0
    min_silence_frames = max(1, int(cfg.vad_min_silence_ms / cfg.vad_frame_ms))
    pad_samples = int(sample_rate * (cfg.vad_padding_ms / 1000.0))

    # Run hysteresis state machine across frames
    raw_spans: list[tuple[int, int]] = []
    state = VADState.SILENCE
    start_frame = 0
    silence_frames_count = 0

    for i, is_v in enumerate(voiced):
        if state == VADState.SILENCE:
            if is_v:
                state = VADState.SPEECH_START
                start_frame = i
        elif state == VADState.SPEECH_START:
            if is_v:
                state = VADState.SPEECH
            else:
                state = VADState.SILENCE
        elif state == VADState.SPEECH:
            if not is_v:
                state = VADState.POSSIBLE_SILENCE
                silence_frames_count = 1
        elif state == VADState.POSSIBLE_SILENCE:
            if is_v:
                state = VADState.SPEECH
                silence_frames_count = 0
            else:
                silence_frames_count += 1
                if silence_frames_count >= min_silence_frames:
                    end_frame = i - silence_frames_count + 1
                    raw_spans.append((start_frame, end_frame))
                    state = VADState.SILENCE
                    silence_frames_count = 0

    if state in (VADState.SPEECH, VADState.POSSIBLE_SILENCE, VADState.SPEECH_START):
        end_frame = len(voiced) - silence_frames_count
        if end_frame > start_frame:
            raw_spans.append((start_frame, end_frame))

    if not raw_spans:
        return []

    segments: list[SpeechSegment] = []
    total_samples = len(samples)

    for sf, ef in raw_spans:
        start_sample = max(0, sf * frame_len - pad_samples)
        end_sample = min(total_samples, ef * frame_len + pad_samples)
        if end_sample <= start_sample:
            continue

        seg_samples = samples[start_sample:end_sample]
        start_ms = round(start_sample / sample_rate * 1000.0, 1)
        end_ms = round(end_sample / sample_rate * 1000.0, 1)
        duration_ms = round(end_ms - start_ms, 1)

        segments.append(
            SpeechSegment(
                start_ms=start_ms,
                end_ms=end_ms,
                duration_ms=duration_ms,
                samples=seg_samples,
            )
        )

    return segments

"""Deterministic hallucination detection for Whisper transcriptions.

Examines transcripts and segment metadata for hallmark failure modes of
small encoder-decoder ASR models:
- Repetitive looping phrases or tokens
- High text output despite low/absent voiced speech
- Compression ratio anomalies
- Unrealistic word production rates (>7-8 words/sec)
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Sequence

from app.tools.speech_service.stt.models import WhisperSegmentInfo
from app.tools.speech_service.vad import VoiceActivity

_WORD_RE = re.compile(r"[A-Za-z0-9']+")


@dataclass(frozen=True)
class HallucinationReport:
    """Findings from hallucination checks."""

    is_suspicious: bool
    repetition_detected: bool = False
    density_anomaly_detected: bool = False
    compression_anomaly_detected: bool = False
    speech_absence_detected: bool = False
    repetition_score: float = 0.0
    flags: list[str] = field(default_factory=list)


def detect_hallucinations(
    text: str,
    segments: Sequence[WhisperSegmentInfo],
    activity: VoiceActivity,
) -> HallucinationReport:
    """Runs deterministic heuristic checks to identify hallucinated transcriptions."""
    flags: list[str] = []
    clean_text = text.strip()
    words = [w.lower() for w in _WORD_RE.findall(clean_text)]
    total_words = len(words)

    if total_words == 0:
        return HallucinationReport(is_suspicious=False, flags=[])

    # 1. Repetition Analysis (word, bigram, trigram loops)
    repetition_detected = False
    repetition_score = 0.0

    if total_words >= 4:
        # Check single-word loops (e.g. "thank you thank you thank you thank you")
        unique_words = set(words)
        unique_ratio = len(unique_words) / total_words
        if total_words >= 6 and unique_ratio < 0.35:
            repetition_detected = True
            flags.append(f"low unique word ratio ({unique_ratio:.2f})")

        # Check for consecutive repeating word sequences (e.g. "you know you know you know")
        for n in (1, 2, 3):
            if total_words >= n * 3:
                ngrams = [tuple(words[i : i + n]) for i in range(len(words) - n + 1)]
                consecutive_repeats = 0
                max_consecutive = 0
                for i in range(len(ngrams) - n):
                    if ngrams[i] == ngrams[i + n]:
                        consecutive_repeats += 1
                        max_consecutive = max(max_consecutive, consecutive_repeats)
                    else:
                        consecutive_repeats = 0
                if max_consecutive >= 2:
                    repetition_detected = True
                    flags.append(f"repeated {n}-gram loop detected ({max_consecutive + 1} repeats)")
                    break

        repetition_score = round(1.0 - (len(unique_words) / total_words), 3)

    # 2. Impossible Word Density
    density_anomaly = False
    speech_sec = max(0.2, activity.speech_ms / 1000.0)
    words_per_sec = total_words / speech_sec
    if words_per_sec > 7.5:
        density_anomaly = True
        flags.append(f"impossible speech density ({words_per_sec:.1f} words/sec on {activity.speech_ms:.0f}ms speech)")

    # 3. Compression Ratio Anomaly
    compression_anomaly = False
    if segments:
        avg_comp = sum(s.compression_ratio for s in segments) / len(segments)
        max_comp = max(s.compression_ratio for s in segments)
        if avg_comp > 2.4 or max_comp > 2.8 or avg_comp < 0.5:
            compression_anomaly = True
            flags.append(f"anomalous compression ratio (avg {avg_comp:.2f}, max {max_comp:.2f})")

    # 4. Speech Absence / VAD Disagreement
    speech_absence = False
    if not activity.has_speech and total_words > 0:
        speech_absence = True
        flags.append("transcript produced but VAD detected zero speech")
    elif activity.speech_ratio < 0.08 and total_words >= 5:
        speech_absence = True
        flags.append(f"high word count ({total_words}) on low speech ratio ({activity.speech_ratio:.1%})")

    is_suspicious = (
        repetition_detected
        or density_anomaly
        or compression_anomaly
        or speech_absence
    )

    return HallucinationReport(
        is_suspicious=is_suspicious,
        repetition_detected=repetition_detected,
        density_anomaly_detected=density_anomaly,
        compression_anomaly_detected=compression_anomaly,
        speech_absence_detected=speech_absence,
        repetition_score=repetition_score,
        flags=flags,
    )

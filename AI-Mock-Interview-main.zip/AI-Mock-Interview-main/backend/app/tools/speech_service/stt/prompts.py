
"""Interview-aware Whisper initial prompt construction.

Supplies the Whisper decoder with domain-specific vocabulary hints based on
the active interview topic and question. Kept deliberately brief (<50 tokens)
to condition token priors on technical terminology without biasing grammar
or prompting hallucinations.

Two prompt strategies:

 - **Technical vocabulary** (default): terms from the active topic and the
   question text, e.g. ``"Technical interview vocabulary: HashMap, O(1)."``
 - **Introduction entity roster** (Option B): proper nouns from the
   candidate's profile — name, role, companies, institutions, degrees — so
   Whisper's decoder does not mishear *"Varun"* as *"Baron"* or *"Infosys"*
   as *"Info 6"*. Activated when the current question is the introduction
   opener and a `CandidateContext` is provided.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional, Sequence

_WORD_RE = re.compile(r"[A-Za-z0-9+#.-]+")
MAX_PROMPT_TERMS = 8

# Patterns that identify the introduction opener. Checked case-insensitively
# against `question_text`. Deliberately broad — a false positive only means
# the entity roster is used instead of the technical vocabulary, and the
# roster is a strict subset of what Whisper would have to guess at anyway.
_INTRODUCTION_PATTERNS = (
    "tell me about yourself",
    "introduce yourself",
    "walk me through your background",
    "brief introduction",
    "about yourself",
)


@dataclass
class CandidateContext:
    """Proper-noun vocabulary the candidate is likely to say during the
    introduction. Built from ``Session.candidate_profile`` and ``User``."""

    full_name: Optional[str] = None
    role: Optional[str] = None
    recent_companies: list[str] = field(default_factory=list)
    institutions: list[str] = field(default_factory=list)
    degrees: list[str] = field(default_factory=list)
    keywords: list[str] = field(default_factory=list)


def _is_introduction_question(question_text: Optional[str]) -> bool:
    """True when `question_text` looks like the introduction opener."""
    if not question_text:
        return False
    q_lower = question_text.lower()
    return any(pat in q_lower for pat in _INTRODUCTION_PATTERNS)


def build_introduction_prompt(context: CandidateContext) -> Optional[str]:
    """Formats the entity roster for Whisper's ``initial_prompt``.

    Returns ``None`` when the context carries no usable proper nouns —
    the caller falls back to ``None`` (no prompt), exactly as before.

    Budget: kept under ~50 tokens — name + role + ≤1 company + ≤1
    institution + ≤1 degree + exclusive keywords.
    """
    parts: list[str] = []
    if context.full_name and context.full_name.strip():
        parts.append(context.full_name.strip())
    if context.role and context.role.strip():
        parts.append(context.role.strip())
    for company in context.recent_companies[:1]:
        if company and company.strip():
            parts.append(company.strip())
    for institution in context.institutions[:1]:
        if institution and institution.strip():
            parts.append(institution.strip())
    for degree in context.degrees[:1]:
        if degree and degree.strip():
            parts.append(degree.strip())

    seen = {p.lower() for p in parts}
    for kw in context.keywords:
        if kw and kw.strip():
            cleaned = kw.strip()
            if cleaned.lower() not in seen:
                parts.append(cleaned)
                seen.add(cleaned.lower())
                # Cap to at most 8-10 items to comfortably remain under the 50 token budget
                if len(parts) >= 8:
                    break

    if not parts:
        return None

    return f"Candidate introduction: {', '.join(parts)}."


def build_initial_prompt(
    question_text: Optional[str] = None,
    topic_terms: Optional[Sequence[str]] = None,
    *,
    candidate_context: Optional[CandidateContext] = None,
    max_terms: int = MAX_PROMPT_TERMS,
) -> Optional[str]:
    """Builds a concise technical vocabulary prompt for Whisper's `initial_prompt`.

    Returns None if no relevant domain terms can be derived.

    When the current question is the introduction opener and a
    ``candidate_context`` is provided, dispatches to
    ``build_introduction_prompt`` instead — the entity roster primes Whisper
    for proper nouns rather than technical terms.
    """
    # Introduction path: proper-noun priming
    if _is_introduction_question(question_text) and candidate_context is not None:
        intro_prompt = build_introduction_prompt(candidate_context)
        if intro_prompt is not None:
            return intro_prompt
        # Fall through to the technical-vocabulary path if the context was
        # empty — graceful degradation, exactly the pre-addition behaviour.

    selected_terms: list[str] = []
    seen = set()

    # 1. Use explicitly provided topic terms if available
    if topic_terms:
        for t in topic_terms:
            clean = t.strip()
            if clean and clean.lower() not in seen:
                seen.add(clean.lower())
                selected_terms.append(clean)
            if len(selected_terms) >= max_terms:
                break

    # 2. If space remains and question_text is provided, scan for topic terms in the question
    if len(selected_terms) < max_terms and question_text:
        try:
            from app.interview_domain.topics import TOPICS

            q_lower = question_text.lower()
            for topic in TOPICS:
                for term in topic.terms:
                    t_clean = term.strip()
                    if t_clean.lower() in q_lower and t_clean.lower() not in seen:
                        seen.add(t_clean.lower())
                        selected_terms.append(t_clean)
                        if len(selected_terms) >= max_terms:
                            break
                if len(selected_terms) >= max_terms:
                    break
        except Exception:
            pass

    if not selected_terms:
        return None

    # E.g. "Technical interview vocabulary: HashMap, Java, hash function, O(1), collision"
    terms_joined = ", ".join(selected_terms[:max_terms])
    return f"Technical interview vocabulary: {terms_joined}."

"""Data models for the production-grade STT pipeline.

Defines typed dataclasses for pre-model acoustic quality, segment-level Whisper
metadata, multi-signal transcription quality analysis, and the unified pipeline result.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal, Optional

QualityClass = Literal["GOOD", "UNCERTAIN", "BAD"]


@dataclass(frozen=True)
class AudioQuality:
    """Acoustic characteristics of the input recording before running any model."""

    duration_ms: float
    rms_dbfs: float
    peak_dbfs: float
    noise_floor_dbfs: float
    snr_estimate_db: float
    silence_ratio: float
    speech_ratio: float
    clipping_ratio: float
    is_usable: bool
    rejection_reason: Optional[str] = None


@dataclass(frozen=True)
class WhisperSegmentInfo:
    """Metadata from a single segment emitted by faster-whisper."""

    text: str
    start: float
    end: float
    avg_logprob: float
    no_speech_prob: float
    compression_ratio: float


@dataclass(frozen=True)
class TranscriptionQuality:
    """Multi-signal evaluation of transcription reliability and hallucination risk."""

    avg_logprob: float
    no_speech_prob: float
    compression_ratio: float
    repetition_score: float
    word_density: float
    vad_agreement: float
    quality_score: float
    quality_class: QualityClass
    hallucination_flags: list[str] = field(default_factory=list)


@dataclass
class STTResult:
    """Unified final output of the STT pipeline."""

    transcript: str
    confidence: float
    quality_score: float
    quality_class: QualityClass
    used_retry: bool = False
    echo_detected: bool = False
    speech_detected: bool = True
    duration_ms: float = 0.0
    language: str = "en"
    activity: Optional[Any] = None
    metrics: dict[str, Any] = field(default_factory=dict)
    segments: list[WhisperSegmentInfo] = field(default_factory=list)
    audio_quality: Optional[AudioQuality] = None
    transcription_quality: Optional[TranscriptionQuality] = None
    raw_transcripts: list[str] = field(default_factory=list)

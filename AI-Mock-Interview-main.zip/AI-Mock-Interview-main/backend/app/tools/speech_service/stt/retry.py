"""Single-retry logic for uncertain or anomalous transcriptions.

Executes a second pass with perturbed decoding parameters (e.g. non-zero temperature,
strictly disabled condition_on_previous_text) when the primary pass yields an
uncertain score or flags a potential hallucination.
"""

from __future__ import annotations

from typing import Any, Optional, Tuple

import numpy as np

from app.tools.speech_service.stt.config import STTPipelineConfig
from app.tools.speech_service.stt.models import (
    TranscriptionQuality,
    WhisperSegmentInfo,
)
from app.tools.speech_service.stt.whisper_decode import decode_audio_with_metadata


def should_retry(
    quality: TranscriptionQuality,
    config: Optional[STTPipelineConfig] = None,
    attempt_count: int = 1,
) -> bool:
    """Determines whether a second decoding pass should be attempted."""
    cfg = config or STTPipelineConfig()
    if not cfg.quality_retry_enabled:
        return False
    if attempt_count > cfg.quality_max_retries:
        return False

    # Retry if uncertain or hallucination flags are present
    if quality.quality_class == "UNCERTAIN":
        return True
    if quality.hallucination_flags:
        return True

    return False


def execute_retry_decode(
    model: Any,
    samples: np.ndarray,
    config: Optional[STTPipelineConfig] = None,
    *,
    initial_prompt: Optional[str] = None,
) -> Tuple[str, list[WhisperSegmentInfo]]:
    """Executes a second decoding pass with temperature fallback and independent segments."""
    cfg = config or STTPipelineConfig()
    retry_temperature = cfg.temperatures[1] if len(cfg.temperatures) > 1 else 0.2

    return decode_audio_with_metadata(
        model,
        samples,
        config=cfg,
        temperature=retry_temperature,
        condition_on_previous_text=False,
        initial_prompt=initial_prompt,
    )

"""Consensus engine for comparing multi-pass Whisper transcriptions.

When retry is triggered, evaluates lexical agreement between pass 1 and pass 2
using difflib SequenceMatcher on normalized token sequences. Determines whether
the passes agree or diverge, and selects the most reliable transcript.
"""

from __future__ import annotations

import difflib
import re
from dataclasses import dataclass
from typing import Optional

from app.tools.speech_service.stt.models import TranscriptionQuality

_PUNCT_RE = re.compile(r"[^\w\s]")


def _normalize_tokens(text: str) -> list[str]:
    cleaned = _PUNCT_RE.sub(" ", text.lower())
    return [t for t in cleaned.split() if t]


@dataclass(frozen=True)
class ConsensusResult:
    """Outcome of comparing two transcription passes."""

    chosen_transcript: str
    similarity: float
    chosen_pass: int
    is_consensus: bool
    combined_flags: list[str]


def resolve_consensus(
    transcript1: str,
    quality1: TranscriptionQuality,
    transcript2: str,
    quality2: TranscriptionQuality,
) -> ConsensusResult:
    """Compares two candidate transcripts and selects the superior or agreed-upon output."""
    tokens1 = _normalize_tokens(transcript1)
    tokens2 = _normalize_tokens(transcript2)

    # Empty edge cases
    if not tokens1 and not tokens2:
        return ConsensusResult("", 1.0, 1, True, [])
    if not tokens1:
        return ConsensusResult(transcript2, 0.0, 2, False, ["pass 1 empty"])
    if not tokens2:
        return ConsensusResult(transcript1, 0.0, 1, False, ["pass 2 empty"])

    # Compute sequence similarity
    matcher = difflib.SequenceMatcher(None, tokens1, tokens2)
    similarity = round(float(matcher.ratio()), 3)

    combined_flags: list[str] = []
    if quality1.hallucination_flags:
        combined_flags.extend(f"pass1: {f}" for f in quality1.hallucination_flags)
    if quality2.hallucination_flags:
        combined_flags.extend(f"pass2: {f}" for f in quality2.hallucination_flags)

    # High agreement (> 0.85): both models heard essentially the same words
    if similarity >= 0.85:
        chosen = 1 if quality1.quality_score >= quality2.quality_score else 2
        return ConsensusResult(
            chosen_transcript=transcript1 if chosen == 1 else transcript2,
            similarity=similarity,
            chosen_pass=chosen,
            is_consensus=True,
            combined_flags=combined_flags,
        )

    # Low agreement (< 0.60): significant discrepancy between passes
    if similarity < 0.60:
        combined_flags.append(f"multi-pass disagreement (similarity {similarity:.2f})")
        # Strongly prefer whichever has fewer hallucination flags or higher score
        if quality2.quality_score > quality1.quality_score + 0.15:
            chosen = 2
        elif quality1.quality_score > quality2.quality_score + 0.15:
            chosen = 1
        else:
            # If scores are close, pick the one with better logprob / less repetition
            chosen = 1 if quality1.repetition_score <= quality2.repetition_score else 2

        return ConsensusResult(
            chosen_transcript=transcript1 if chosen == 1 else transcript2,
            similarity=similarity,
            chosen_pass=chosen,
            is_consensus=False,
            combined_flags=combined_flags,
        )

    # Moderate agreement (0.60 - 0.85): prefer higher quality pass
    chosen = 1 if quality1.quality_score >= quality2.quality_score else 2
    return ConsensusResult(
        chosen_transcript=transcript1 if chosen == 1 else transcript2,
        similarity=similarity,
        chosen_pass=chosen,
        is_consensus=True,
        combined_flags=combined_flags,
    )

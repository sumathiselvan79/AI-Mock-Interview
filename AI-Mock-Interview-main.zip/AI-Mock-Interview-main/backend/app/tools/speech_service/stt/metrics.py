"""In-memory observability metrics for the STT pipeline.

Maintains process-scoped counters, rates, and latency statistics without
persisting candidate audio or transcripts (privacy compliant with INSTRUCTIONS.md §8).
"""

from __future__ import annotations

import threading
from typing import Any, Optional


class STTMetricsTracker:
    """Thread-safe collector of STT performance and quality statistics."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self.reset()

    def reset(self) -> None:
        with getattr(self, "_lock", threading.Lock()):
            self.total_transcriptions: int = 0
            self.successful: int = 0
            self.no_speech_count: int = 0
            self.retries: int = 0
            self.echo_rejections: int = 0
            self.low_confidence_count: int = 0
            self.hallucinations_flagged: int = 0

            # Quality classes
            self.quality_good: int = 0
            self.quality_uncertain: int = 0
            self.quality_bad: int = 0

            # Latency (ms)
            self.total_decode_ms: float = 0.0
            self.min_decode_ms: float = float("inf")
            self.max_decode_ms: float = 0.0

    def record(
        self,
        *,
        success: bool,
        decode_ms: float = 0.0,
        no_speech: bool = False,
        used_retry: bool = False,
        echo_rejected: bool = False,
        low_confidence: bool = False,
        quality_class: Optional[str] = None,
        has_hallucinations: bool = False,
    ) -> None:
        with self._lock:
            self.total_transcriptions += 1
            if success:
                self.successful += 1
            if no_speech:
                self.no_speech_count += 1
            if used_retry:
                self.retries += 1
            if echo_rejected:
                self.echo_rejections += 1
            if low_confidence:
                self.low_confidence_count += 1
            if has_hallucinations:
                self.hallucinations_flagged += 1

            if quality_class == "GOOD":
                self.quality_good += 1
            elif quality_class == "UNCERTAIN":
                self.quality_uncertain += 1
            elif quality_class == "BAD":
                self.quality_bad += 1

            if decode_ms > 0:
                self.total_decode_ms += decode_ms
                if decode_ms < self.min_decode_ms:
                    self.min_decode_ms = decode_ms
                if decode_ms > self.max_decode_ms:
                    self.max_decode_ms = decode_ms

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            total = self.total_transcriptions
            avg_decode = (self.total_decode_ms / self.successful) if self.successful > 0 else 0.0
            min_decode = self.min_decode_ms if self.min_decode_ms != float("inf") else 0.0

            return {
                "total_transcriptions": total,
                "successful": self.successful,
                "success_rate": round(self.successful / total, 3) if total > 0 else 1.0,
                "no_speech_rate": round(self.no_speech_count / total, 3) if total > 0 else 0.0,
                "retry_rate": round(self.retries / total, 3) if total > 0 else 0.0,
                "echo_rejection_rate": round(self.echo_rejections / total, 3) if total > 0 else 0.0,
                "low_confidence_rate": round(self.low_confidence_count / total, 3) if total > 0 else 0.0,
                "hallucination_rate": round(self.hallucinations_flagged / total, 3) if total > 0 else 0.0,
                "quality_distribution": {
                    "good": self.quality_good,
                    "uncertain": self.quality_uncertain,
                    "bad": self.quality_bad,
                },
                "latency_ms": {
                    "avg_decode": round(avg_decode, 1),
                    "min_decode": round(min_decode, 1),
                    "max_decode": round(self.max_decode_ms, 1),
                },
            }


# Global singleton instance
GLOBAL_METRICS = STTMetricsTracker()


def get_stt_metrics() -> dict[str, Any]:
    """Returns a snapshot dictionary of process-scoped STT performance metrics."""
    return GLOBAL_METRICS.snapshot()

"""Production-grade STT pipeline package for faster-whisper.

Centralizes audio quality analysis, adaptive noise gating, segmentation,
interview-aware initial prompting, multi-signal quality scoring, deterministic
hallucination detection, conditional retry, consensus, and technical vocabulary
normalization.
"""

from __future__ import annotations

from app.tools.speech_service.stt.config import STTPipelineConfig, load_stt_config
from app.tools.speech_service.stt.models import (
    AudioQuality,
    STTResult,
    TranscriptionQuality,
    WhisperSegmentInfo,
)

__all__ = [
    "AudioQuality",
    "STTPipelineConfig",
    "STTResult",
    "TranscriptionQuality",
    "WhisperSegmentInfo",
    "load_stt_config",
]

"""Technical vocabulary dictionary for canonicalization and speech normalization.

Defines spoken phonetic aliases and abbreviations for common technical, software,
hardware, systems, and interview terminology, ensuring that Whisper's colloquial
or phonetic transcriptions (e.g. "sequel", "hash map", "oh one") are normalized
to standard canonical representations ("SQL", "HashMap", "O(1)") without altering meaning.
"""

from __future__ import annotations

from typing import Mapping

# Common spoken aliases to canonical representation
EXACT_ALIASES: dict[str, str] = {
    # Data Structures & Algorithms
    "hash map": "HashMap",
    "hashmap": "HashMap",
    "hash table": "HashTable",
    "hashtable": "HashTable",
    "linked list": "LinkedList",
    "array list": "ArrayList",
    "tree map": "TreeMap",
    "hash set": "HashSet",
    "binary search tree": "Binary Search Tree",
    "bst": "BST",
    "bfs": "BFS",
    "dfs": "DFS",
    "lru cache": "LRU Cache",
    "lru": "LRU",
    # Complexity Notation
    "big o": "Big-O",
    "oh one": "O(1)",
    "o of one": "O(1)",
    "o 1": "O(1)",
    "oh n": "O(n)",
    "o of n": "O(n)",
    "o n": "O(n)",
    "oh log n": "O(log n)",
    "o of log n": "O(log n)",
    "oh n log n": "O(n log n)",
    "o of n log n": "O(n log n)",
    "oh n squared": "O(n^2)",
    "o of n squared": "O(n^2)",
    # Databases & Storage
    "sequel": "SQL",
    "my sequel": "MySQL",
    "mysql": "MySQL",
    "postgres": "PostgreSQL",
    "post gres": "PostgreSQL",
    "postgresql": "PostgreSQL",
    "no sequel": "NoSQL",
    "nosql": "NoSQL",
    "mongo db": "MongoDB",
    "mongodb": "MongoDB",
    "redis": "Redis",
    "sqlite": "SQLite",
    "dynamo db": "DynamoDB",
    "cassandra": "Cassandra",
    "acid": "ACID",
    "sharding": "sharding",
    # Networking & Protocols
    "rest api": "REST API",
    "restful": "RESTful",
    "rest apis": "REST APIs",
    "graph ql": "GraphQL",
    "graphql": "GraphQL",
    "g rpc": "gRPC",
    "grpc": "gRPC",
    "tcp ip": "TCP/IP",
    "tcp": "TCP",
    "udp": "UDP",
    "http": "HTTP",
    "https": "HTTPS",
    "http two": "HTTP/2",
    "http three": "HTTP/3",
    "web socket": "WebSocket",
    "websockets": "WebSockets",
    "websocket": "WebSocket",
    "dns": "DNS",
    "tls": "TLS",
    "ssl": "SSL",
    # Data Formats & Auth
    "jay son": "JSON",
    "json": "JSON",
    "yaml": "YAML",
    "xml": "XML",
    "jwt": "JWT",
    "j w t": "JWT",
    "oauth": "OAuth",
    "oauth two": "OAuth 2.0",
    "oauth 2": "OAuth 2.0",
    "saml": "SAML",
    "csrf": "CSRF",
    "cors": "CORS",
    "xss": "XSS",
    # Languages & Runtimes
    "c plus plus": "C++",
    "c sharp": "C#",
    "node js": "Node.js",
    "nodejs": "Node.js",
    "next js": "Next.js",
    "nextjs": "Next.js",
    "react js": "React",
    "reactjs": "React",
    "vue js": "Vue",
    "typescript": "TypeScript",
    "javascript": "JavaScript",
    "golang": "Go",
    "python": "Python",
    # Cloud, DevOps & Infrastructure
    "ci cd": "CI/CD",
    "ci / cd": "CI/CD",
    "k eight s": "K8s",
    "k8s": "K8s",
    "kubernetes": "Kubernetes",
    "docker": "Docker",
    "aws": "AWS",
    "gcp": "GCP",
    "azure": "Azure",
    "ec two": "EC2",
    "ec2": "EC2",
    "s three": "S3",
    "s3": "S3",
    "lambda": "Lambda",
    "kafka": "Kafka",
    "rabbitmq": "RabbitMQ",
    "terraform": "Terraform",
    # Hardware & Embedded
    "cpu": "CPU",
    "gpu": "GPU",
    "fpga": "FPGA",
    "asic": "ASIC",
    "ram": "RAM",
    "rom": "ROM",
    "pcb": "PCB",
    "cad": "CAD",
    "pwm": "PWM",
    "i squared c": "I2C",
    "i two c": "I2C",
    "i2c": "I2C",
    "spi": "SPI",
    "uart": "UART",
    "gpio": "GPIO",
    "dma": "DMA",
    "rtos": "RTOS",
    "soc": "SoC",
    "alu": "ALU",
    "mmu": "MMU",
    "can bus": "CAN bus",
    "canbus": "CAN bus",
    "cmos": "CMOS",
    "mosfet": "MOSFET",
}


def get_all_vocabulary() -> set[str]:
    """Returns all canonical vocabulary terms including topics from interview_domain."""
    terms = set(EXACT_ALIASES.values())
    try:
        from app.interview_domain.topics import TOPICS

        for topic in TOPICS:
            for term in topic.terms:
                t = term.strip()
                if t:
                    terms.add(t)
    except Exception:
        pass
    return terms

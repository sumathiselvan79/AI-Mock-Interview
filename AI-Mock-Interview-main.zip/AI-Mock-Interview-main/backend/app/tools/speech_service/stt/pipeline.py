"""Production-grade STT pipeline orchestrator.

Coordinates:
1. Audio decoding and resampling to 16 kHz mono.
2. Pre-model acoustic quality analysis & VAD gating.
3. Adaptive noise estimation and boundary padding.
4. Interview-aware domain prompting.
5. Faster-Whisper decoding with segment metadata capture.
6. Multi-signal quality scoring and deterministic hallucination detection.
7. Conditional temperature retry and consensus resolution.
8. Domain vocabulary normalization.
9. Observability and metrics recording.
"""

from __future__ import annotations

import asyncio
import time
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Optional, Sequence

import numpy as np

from app.tools.speech_service.provider import (
    TranscriptionFailed,
    decode_wav,
    rms,
)
from app.tools.speech_service.source import classify
from app.tools.speech_service.stt.audio_quality import analyse_audio_quality
from app.tools.speech_service.stt.config import STTPipelineConfig
from app.tools.speech_service.stt.consensus import resolve_consensus
from app.tools.speech_service.stt.metrics import GLOBAL_METRICS
from app.tools.speech_service.stt.models import (
    AudioQuality,
    STTResult,
    TranscriptionQuality,
    WhisperSegmentInfo,
)
from app.tools.speech_service.stt.normalizer import normalize_transcript
from app.tools.speech_service.stt.prompts import CandidateContext, build_initial_prompt
from app.tools.speech_service.stt.quality_scoring import score_transcription_quality
from app.tools.speech_service.stt.retry import execute_retry_decode, should_retry
from app.tools.speech_service.stt.segmentation import segment_audio
from app.tools.speech_service.stt.whisper_decode import decode_audio_with_metadata
from app.tools.speech_service.vad import VoiceActivity, trim

WHISPER_SAMPLE_RATE = 16_000


def _to_whisper_rate(samples: np.ndarray, sample_rate: int) -> np.ndarray:
    """Resamples audio to 16 kHz mono via linear interpolation."""
    if sample_rate == WHISPER_SAMPLE_RATE or sample_rate <= 0 or samples.size == 0:
        return samples.astype(np.float32, copy=False)
    duration = samples.size / sample_rate
    target_len = max(1, int(duration * WHISPER_SAMPLE_RATE))
    source_x = np.linspace(0.0, duration, num=samples.size, endpoint=False)
    target_x = np.linspace(0.0, duration, num=target_len, endpoint=False)
    return np.interp(target_x, source_x, samples).astype(np.float32)


async def run_stt_pipeline(
    audio: bytes,
    config: STTPipelineConfig,
    model: Any,
    executor: ThreadPoolExecutor,
    *,
    question_text: Optional[str] = None,
    topic_terms: Optional[Sequence[str]] = None,
    spoken_recently: Optional[Sequence[str]] = None,
    tts_playing_at: Optional[float] = None,
    recording_started_at: Optional[float] = None,
    device_hint: Optional[str] = None,
    device_label: Optional[str] = None,
    candidate_context: Optional[CandidateContext] = None,
) -> STTResult:
    """Executes the full end-to-end production STT pipeline."""
    if not model:
        raise TranscriptionFailed("no Whisper model loaded")

    loop = asyncio.get_running_loop()
    start_time = time.monotonic()

    # Stage 1: Audio decode & resample
    try:
        decoded = decode_wav(audio)
        samples = _to_whisper_rate(decoded.samples, decoded.sample_rate)
    except Exception as err:
        GLOBAL_METRICS.record(success=False)
        raise TranscriptionFailed(f"corrupted or unsupported WAV audio: {err}") from err

    # Stage 2: Acoustic analysis & VAD gate
    audio_quality, activity = analyse_audio_quality(samples, WHISPER_SAMPLE_RATE, config)
    if not audio_quality.is_usable:
        GLOBAL_METRICS.record(
            success=False,
            no_speech=True,
            quality_class="BAD",
        )
        raise TranscriptionFailed(audio_quality.rejection_reason or "audio unusable")

    # Stage 3: Silence trimming
    trimmed = trim(samples, activity, pad_ms=float(config.vad_padding_ms))
    trimmed_ms = round(len(trimmed) / WHISPER_SAMPLE_RATE * 1000.0, 1)

    # Stage 4: Interview-aware prompting
    initial_prompt = build_initial_prompt(question_text, topic_terms, candidate_context=candidate_context)

    # Stage 5: Primary decode under wall-clock cap
    decode_start = time.monotonic()
    try:
        raw_text_1, segments_1 = await asyncio.wait_for(
            loop.run_in_executor(
                executor,
                decode_audio_with_metadata,
                model,
                trimmed,
                config,
                0.0,  # temperature
                None,  # condition_on_previous_text default
                initial_prompt,
                config.beam_size,
            ),
            timeout=config.timeout_seconds,
        )
    except asyncio.TimeoutError as err:
        GLOBAL_METRICS.record(success=False, decode_ms=(time.monotonic() - decode_start) * 1000.0)
        raise TranscriptionFailed(
            f"transcription exceeded the {config.timeout_seconds:g}s limit; "
            "the recording could not be transcribed in time"
        ) from err
    except Exception as err:
        GLOBAL_METRICS.record(success=False)
        raise TranscriptionFailed(f"whisper transcription failed: {err}") from err

    # Stage 6: Quality scoring & hallucination detection (Pass 1)
    quality_1 = score_transcription_quality(
        raw_text_1,
        segments_1,
        activity,
        rms_val=rms(trimmed),
    )

    chosen_text = raw_text_1
    chosen_segments = segments_1
    final_quality = quality_1
    used_retry = False
    raw_transcripts = [raw_text_1]

    # Stage 7: Conditional Retry & Consensus
    if should_retry(quality_1, config, attempt_count=1):
        used_retry = True
        try:
            raw_text_2, segments_2 = await asyncio.wait_for(
                loop.run_in_executor(
                    executor,
                    execute_retry_decode,
                    model,
                    trimmed,
                    config,
                    initial_prompt,
                ),
                timeout=max(3.0, config.timeout_seconds - (time.monotonic() - decode_start)),
            )
            raw_transcripts.append(raw_text_2)
            quality_2 = score_transcription_quality(
                raw_text_2,
                segments_2,
                activity,
                rms_val=rms(trimmed),
            )

            if config.transcript_consensus_enabled:
                consensus = resolve_consensus(raw_text_1, quality_1, raw_text_2, quality_2)
                chosen_text = consensus.chosen_transcript
                chosen_segments = segments_1 if consensus.chosen_pass == 1 else segments_2
                final_quality = quality_1 if consensus.chosen_pass == 1 else quality_2
            else:
                if quality_2.quality_score > quality_1.quality_score:
                    chosen_text = raw_text_2
                    chosen_segments = segments_2
                    final_quality = quality_2
        except Exception:
            # If retry fails or times out, safely fall back to pass 1
            pass

    decode_elapsed_ms = round((time.monotonic() - decode_start) * 1000.0, 1)

    # Stage 8: Technical Vocabulary Normalization
    normalized_text = normalize_transcript(
        chosen_text,
        topic_terms=topic_terms,
        enabled=config.technical_normalization_enabled,
    )

    # Stage 9: Echo classification check
    echo_verdict = classify(
        transcript=normalized_text,
        device_hint=device_hint,
        device_label=device_label,
        spoken_recently=spoken_recently or [],
        tts_playing_at=tts_playing_at,
        recording_started_at=recording_started_at,
    )

    # Record telemetry metrics
    GLOBAL_METRICS.record(
        success=True,
        decode_ms=decode_elapsed_ms,
        used_retry=used_retry,
        echo_rejected=echo_verdict.reject,
        low_confidence=final_quality.quality_score < config.min_confidence_threshold,
        quality_class=final_quality.quality_class,
        has_hallucinations=bool(final_quality.hallucination_flags),
    )

    result_metrics = {
        "decode_ms": decode_elapsed_ms,
        "trimmed_ms": trimmed_ms,
        "total_pipeline_ms": round((time.monotonic() - start_time) * 1000.0, 1),
        "snr_db": audio_quality.snr_estimate_db,
        "clipping_ratio": audio_quality.clipping_ratio,
        "echo_status": echo_verdict.status,
        "echo_confidence": echo_verdict.echo_confidence,
    }

    return STTResult(
        transcript=normalized_text,
        confidence=final_quality.quality_score,
        quality_score=final_quality.quality_score,
        quality_class=final_quality.quality_class,
        used_retry=used_retry,
        echo_detected=echo_verdict.reject,
        speech_detected=True,
        duration_ms=audio_quality.duration_ms,
        language=config.language,
        activity=activity,
        metrics=result_metrics,
        segments=chosen_segments,
        audio_quality=audio_quality,
        transcription_quality=final_quality,
        raw_transcripts=raw_transcripts,
    )

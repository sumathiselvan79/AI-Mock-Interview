"""Whisper decode execution with segment-level metadata capture.

Wraps faster-whisper's `model.transcribe` to capture per-segment confidence
and probability diagnostics (avg_logprob, no_speech_prob, compression_ratio),
allowing fine-grained downstream quality analysis and hallucination detection.
"""

from __future__ import annotations

from typing import Any, Optional, Tuple

import numpy as np

from app.tools.speech_service.stt.config import STTPipelineConfig
from app.tools.speech_service.stt.models import WhisperSegmentInfo


def decode_audio_with_metadata(
    model: Any,
    samples: np.ndarray,
    config: Optional[STTPipelineConfig] = None,
    temperature: float = 0.0,
    condition_on_previous_text: Optional[bool] = None,
    initial_prompt: Optional[str] = None,
    beam_size: Optional[int] = None,
) -> Tuple[str, list[WhisperSegmentInfo]]:
    """Runs faster-whisper model decode and returns both concatenated text and segment metadata.

    This function is synchronous and intended to be run in a worker thread pool.
    """
    from faster_whisper.vad import VadOptions

    cfg = config or STTPipelineConfig()
    actual_beam = beam_size if beam_size is not None else cfg.beam_size
    actual_cond = (
        condition_on_previous_text
        if condition_on_previous_text is not None
        else cfg.condition_on_previous_text
    )

    vad_params = VadOptions(min_silence_duration_ms=cfg.vad_min_silence_ms) if cfg.vad_filter else None

    # Run model transcribe
    segments_iter, _info = model.transcribe(
        samples,
        language=cfg.language,
        beam_size=actual_beam,
        temperature=temperature,
        vad_filter=cfg.vad_filter,
        vad_parameters=vad_params,
        condition_on_previous_text=actual_cond,
        initial_prompt=initial_prompt,
    )

    segment_infos: list[WhisperSegmentInfo] = []
    text_chunks: list[str] = []

    for seg in segments_iter:
        seg_text = seg.text.strip()
        if seg_text:
            text_chunks.append(seg_text)
        segment_infos.append(
            WhisperSegmentInfo(
                text=seg_text,
                start=round(float(seg.start), 2),
                end=round(float(seg.end), 2),
                avg_logprob=round(float(getattr(seg, "avg_logprob", 0.0)), 3),
                no_speech_prob=round(float(getattr(seg, "no_speech_prob", 0.0)), 3),
                compression_ratio=round(float(getattr(seg, "compression_ratio", 1.0)), 3),
            )
        )

    full_text = " ".join(text_chunks).strip()
    return full_text, segment_infos

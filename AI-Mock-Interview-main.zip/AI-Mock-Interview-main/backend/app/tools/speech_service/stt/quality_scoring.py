"""Multi-signal transcription quality scoring.

Combines decoder probabilities (logprob, no-speech probability), acoustic metrics
(energy, speech ratio), speech density, and hallucination heuristics into a
calibrated quality score (0.0 - 1.0) and classification (GOOD, UNCERTAIN, BAD).
"""

from __future__ import annotations

from typing import Optional, Sequence

from app.tools.speech_service.stt.hallucination import detect_hallucinations
from app.tools.speech_service.stt.models import (
    QualityClass,
    TranscriptionQuality,
    WhisperSegmentInfo,
)
from app.tools.speech_service.vad import VoiceActivity


def score_transcription_quality(
    text: str,
    segments: Sequence[WhisperSegmentInfo],
    activity: VoiceActivity,
    *,
    rms_val: Optional[float] = None,
) -> TranscriptionQuality:
    """Evaluates transcription confidence across multiple independent signals."""
    words = [w for w in text.split() if w]
    word_count = len(words)

    if word_count == 0:
        return TranscriptionQuality(
            avg_logprob=-2.0,
            no_speech_prob=1.0,
            compression_ratio=1.0,
            repetition_score=0.0,
            word_density=0.0,
            vad_agreement=0.0,
            quality_score=0.0,
            quality_class="BAD",
            hallucination_flags=["empty transcript"],
        )

    # 1. Segment-level metrics aggregation
    if segments:
        avg_logprob = float(sum(s.avg_logprob for s in segments) / len(segments))
        no_speech_prob = float(max(s.no_speech_prob for s in segments))
        avg_comp = float(sum(s.compression_ratio for s in segments) / len(segments))
    else:
        avg_logprob = -0.4
        no_speech_prob = 0.05
        avg_comp = 1.2

    # 2. Logprob score: 0.0 dB is 1.0, -1.0 dB is 0.4, -2.0 is 0.0
    # Whisper logprobs are typically in [-1.5, 0.0]
    logprob_score = max(0.0, min(1.0, (avg_logprob + 1.5) / 1.5))

    # 3. No-speech penalty
    no_speech_score = max(0.0, 1.0 - no_speech_prob)

    # 4. Word density score
    speech_sec = max(0.5, activity.speech_ms / 1000.0)
    density = word_count / speech_sec
    if density < 0.5:
        density_score = max(0.0, density / 0.5)
    elif density > 6.0:
        density_score = max(0.0, 1.0 - (density - 6.0) / 4.0)
    else:
        density_score = 1.0

    # 5. Voicing agreement score
    # Normal conversation is ~30-50% speech. Full marks at 35%.
    voiced_score = min(1.0, activity.speech_ratio / 0.35)

    # 6. Hallucination detection
    hallucination_report = detect_hallucinations(text, segments, activity)
    repetition_penalty = 1.0 - min(0.8, hallucination_report.repetition_score)

    # 7. Acoustic level score
    level_score = 1.0
    if rms_val is not None:
        level_score = min(1.0, rms_val / 0.04)

    # 8. Blended quality score
    # Weights prioritize decoder certainty, acoustic voicing, and density
    base_score = (
        logprob_score * 0.30
        + no_speech_score * 0.15
        + density_score * 0.20
        + voiced_score * 0.20
        + level_score * 0.15
    )

    final_score = base_score * repetition_penalty

    # Heavy penalty if suspicious hallucination patterns detected
    if hallucination_report.is_suspicious:
        final_score *= 0.5

    quality_score = round(max(0.0, min(1.0, final_score)), 2)

    # Classification
    if quality_score >= 0.70 and not hallucination_report.is_suspicious:
        quality_class: QualityClass = "GOOD"
    elif quality_score >= 0.45 and not (hallucination_report.repetition_detected or hallucination_report.speech_absence_detected):
        quality_class = "UNCERTAIN"
    else:
        quality_class = "BAD"

    return TranscriptionQuality(
        avg_logprob=round(avg_logprob, 3),
        no_speech_prob=round(no_speech_prob, 3),
        compression_ratio=round(avg_comp, 3),
        repetition_score=hallucination_report.repetition_score,
        word_density=round(density, 2),
        vad_agreement=round(voiced_score, 2),
        quality_score=quality_score,
        quality_class=quality_class,
        hallucination_flags=hallucination_report.flags,
    )

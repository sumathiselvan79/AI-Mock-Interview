"""Fuzzy string and phonetic matching using SequenceMatcher and Metaphone.

Provides string distance and phonetic representation without third-party C-extensions,
enabling robust candidate matching against technical vocabulary aliases.
"""

from __future__ import annotations

import difflib
import re

_ALPHA_RE = re.compile(r"[^A-Z]")


def simplified_metaphone(word: str) -> str:
    """Computes a simplified Metaphone phonetic key for an English word.

    Transforms words into phonetic consonant codes (e.g. 'SQL' -> 'SKL', 'hash' -> 'HX').
    """
    w = _ALPHA_RE.sub("", word.upper())
    if not w:
        return ""

    # Initial transforms
    if len(w) >= 2 and w[:2] in ("KN", "GN", "PN", "AE", "WR"):
        w = w[1:]
    elif w.startswith("X"):
        w = "S" + w[1:]
    elif w.startswith("WH"):
        w = "W" + w[2:]

    result: list[str] = []
    # Retain starting vowel if first character is a vowel
    if w[0] in "AEIOU":
        result.append(w[0])

    i = 0
    n = len(w)
    while i < n and len(result) < 6:
        ch = w[i]
        # Ignore duplicate adjacent letters (except C)
        if i > 0 and ch == w[i - 1] and ch != "C":
            i += 1
            continue

        next_ch = w[i + 1] if i + 1 < n else ""
        next_2 = w[i + 2] if i + 2 < n else ""

        if ch in "AEIOU":
            # vowels after start are skipped
            i += 1
            continue
        elif ch == "B":
            if not (i == n - 1 and i > 0 and w[i - 1] == "M"):
                result.append("B")
        elif ch == "C":
            if next_ch == "I" and next_2 == "A":
                result.append("X")
                i += 2
            elif next_ch == "H":
                result.append("X")
                i += 1
            elif next_ch in ("I", "E", "Y"):
                result.append("S")
            else:
                result.append("K")
        elif ch == "D":
            if next_ch == "G" and next_2 in ("E", "Y", "I"):
                result.append("J")
                i += 2
            else:
                result.append("T")
        elif ch == "F":
            result.append("F")
        elif ch == "G":
            if next_ch == "H" and (i + 2 == n or (i + 2 < n and w[i + 2] not in "AEIOU")):
                i += 1
            elif next_ch in ("I", "E", "Y"):
                result.append("J")
            else:
                result.append("K")
        elif ch == "H":
            if i == 0 or next_ch in "AEIOU":
                result.append("H")
        elif ch in ("J", "K"):
            result.append(ch)
        elif ch == "L":
            result.append("L")
        elif ch == "M":
            result.append("M")
        elif ch == "N":
            result.append("N")
        elif ch == "P":
            if next_ch == "H":
                result.append("F")
                i += 1
            else:
                result.append("P")
        elif ch == "Q":
            result.append("K")
        elif ch == "R":
            result.append("R")
        elif ch == "S":
            if next_ch == "H" or (next_ch == "I" and next_2 in ("O", "A")):
                result.append("X")
                i += 1
            else:
                result.append("S")
        elif ch == "T":
            if next_ch == "I" and next_2 in ("A", "O"):
                result.append("X")
                i += 1
            elif next_ch == "H":
                result.append("0")
                i += 1
            elif not (next_ch == "C" and next_2 == "H"):
                result.append("T")
        elif ch == "V":
            result.append("F")
        elif ch == "W":
            if next_ch in "AEIOU":
                result.append("W")
        elif ch == "X":
            result.append("KS")
        elif ch == "Y":
            if next_ch in "AEIOU":
                result.append("Y")
        elif ch == "Z":
            result.append("S")

        i += 1

    return "".join(result)


def phonetic_similarity(a: str, b: str) -> float:
    """Computes phonetic alignment between two words (0.0 - 1.0)."""
    m1 = simplified_metaphone(a)
    m2 = simplified_metaphone(b)
    if not m1 or not m2:
        return 0.0
    if m1 == m2:
        return 1.0
    if m1.startswith(m2) or m2.startswith(m1):
        return 0.75
    return 0.0


def fuzzy_match_score(term_a: str, term_b: str) -> float:
    """Combines character sequence similarity with phonetic alignment."""
    s1 = term_a.lower().strip()
    s2 = term_b.lower().strip()
    if s1 == s2:
        return 1.0

    seq_ratio = difflib.SequenceMatcher(None, s1, s2).ratio()
    phone_ratio = phonetic_similarity(s1, s2)

    return round(0.6 * seq_ratio + 0.4 * phone_ratio, 3)

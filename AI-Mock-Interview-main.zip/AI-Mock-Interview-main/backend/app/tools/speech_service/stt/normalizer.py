"""Domain-aware technical transcript normalization.

Applies high-confidence lexical canonicalization to raw Whisper transcripts:
1. Exact whole-word / phrase substitution using curated alias maps (sorted longest-first).
2. Context-constrained fuzzy & phonetic alignment against interview topic terms.

Preserves transcript semantics and candidate intent strictly: never changes
algorithmic claims or meaning (e.g. "O of log n" stays O(log n), never O(1)).
"""

from __future__ import annotations

import re
from typing import Optional, Sequence

from app.tools.speech_service.stt.fuzzy_match import fuzzy_match_score
from app.tools.speech_service.stt.vocabulary import EXACT_ALIASES

# Pre-compile exact regex patterns sorted by descending length to prevent subphrase hijacking
_SORTED_ALIASES = sorted(EXACT_ALIASES.items(), key=lambda kv: len(kv[0]), reverse=True)


def _build_alias_regex(alias: str) -> re.Pattern:
    escaped = re.escape(alias)
    # Ensure word boundaries around alphanumeric terms; handle punctuation-friendly boundaries
    return re.compile(rf"(?<![A-Za-z0-9]){escaped}(?![A-Za-z0-9])", re.IGNORECASE)


_COMPILED_PATTERNS = [(_build_alias_regex(k), v) for k, v in _SORTED_ALIASES]


def normalize_transcript(
    transcript: str,
    *,
    topic_terms: Optional[Sequence[str]] = None,
    enabled: bool = True,
) -> str:
    """Normalizes technical vocabulary, casing, and spoken aliases in a transcript."""
    if not enabled or not transcript or not transcript.strip():
        return transcript

    result = transcript

    # Step 1: Exact multi-word & single-word alias replacement
    for pattern, canonical in _COMPILED_PATTERNS:
        result = pattern.sub(canonical, result)

    # Step 2: Context-aware fuzzy/phonetic replacement
    # Only attempted if topic_terms are provided and word is close
    if topic_terms:
        active_terms = [t.strip() for t in topic_terms if t.strip()]
        if active_terms:
            words = result.split()
            modified = False
            for idx, word in enumerate(words):
                # Clean punctuation for matching
                clean_w = re.sub(r"[^\w]", "", word)
                if len(clean_w) < 4:
                    continue
                # Do not modify if already capitalized or canonical
                if word[0].isupper():
                    continue

                for target_term in active_terms:
                    # Only consider single-word targets here
                    if " " in target_term:
                        continue
                    score = fuzzy_match_score(clean_w, target_term)
                    if score >= 0.85:
                        # Retain punctuation
                        leading_punct = word[: len(word) - len(word.lstrip(".,?!;:'\""))]
                        trailing_punct = word[len(word.rstrip(".,?!;:'\"")) :]
                        words[idx] = f"{leading_punct}{target_term}{trailing_punct}"
                        modified = True
                        break

            if modified:
                result = " ".join(words)

    # Clean up duplicate whitespace
    result = re.sub(r"[ \t]+", " ", result).strip()
    return result

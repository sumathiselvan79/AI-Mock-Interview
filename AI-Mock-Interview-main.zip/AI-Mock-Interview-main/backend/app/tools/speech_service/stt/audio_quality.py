"""Pre-model acoustic quality analysis.

Measures RMS energy, peak level, clipping, noise floor, SNR, and speech activity
before invoking Whisper. Fast, model-free, deterministic gating that guards against
silent, clipped, corrupt, or unusable audio inputs.
"""

from __future__ import annotations

from typing import Optional, Tuple

import numpy as np

from app.tools.speech_service.stt.config import STTPipelineConfig
from app.tools.speech_service.stt.models import AudioQuality
from app.tools.speech_service.vad import (
    VoiceActivity,
    analyse,
    frame_levels,
    noise_floor_percentile,
)

_EPSILON = 1e-10
CLIPPING_THRESHOLD = 0.99
MIN_DURATION_MS = 200.0


def estimate_adaptive_noise_floor(
    samples: np.ndarray,
    sample_rate: int,
    noise_estimation_ms: int = 500,
    frame_ms: int = 30,
) -> float:
    """Estimates the background noise floor (dBFS).

    If the recording begins with a quiet period (first `noise_estimation_ms`),
    uses the 20th percentile of those initial frames. If the initial frames
    are voiced or the recording is too short, falls back to the 10th percentile
    across the entire recording.
    """
    if len(samples) == 0 or sample_rate <= 0:
        return -60.0

    frame_len = max(1, int(sample_rate * frame_ms / 1000))
    all_levels = frame_levels(samples, frame_len)
    if len(all_levels) == 0:
        return -60.0

    num_initial_frames = max(1, int(sample_rate * (noise_estimation_ms / 1000) / frame_len))
    if len(all_levels) > num_initial_frames:
        initial_levels = all_levels[:num_initial_frames]
        # If the start doesn't look like loud speech (e.g. median < -25dBFS),
        # initial room tone is a very accurate indicator.
        if float(np.median(initial_levels)) < -25.0:
            return float(np.percentile(initial_levels, 20))

    return noise_floor_percentile(all_levels)


def analyse_audio_quality(
    samples: np.ndarray,
    sample_rate: int,
    config: Optional[STTPipelineConfig] = None,
) -> Tuple[AudioQuality, VoiceActivity]:
    """Analyzes raw float32 audio samples and returns pre-model quality metrics and VAD activity.

    Handles empty or malformed arrays gracefully without throwing exceptions.
    """
    cfg = config or STTPipelineConfig()
    total_ms = (len(samples) / sample_rate * 1000.0) if sample_rate > 0 else 0.0

    if len(samples) == 0 or sample_rate <= 0:
        empty_vad = analyse(samples, sample_rate)
        return (
            AudioQuality(
                duration_ms=0.0,
                rms_dbfs=-100.0,
                peak_dbfs=-100.0,
                noise_floor_dbfs=-100.0,
                snr_estimate_db=0.0,
                silence_ratio=1.0,
                speech_ratio=0.0,
                clipping_ratio=0.0,
                is_usable=False,
                rejection_reason="empty audio buffer",
            ),
            empty_vad,
        )

    # 1. Clipping detection
    clipping_count = int(np.sum(np.abs(samples) >= CLIPPING_THRESHOLD))
    clipping_ratio = round(float(clipping_count / len(samples)), 4)

    # 2. RMS & Peak
    rms_val = float(np.sqrt(np.mean(np.square(samples.astype(np.float64)))))
    rms_dbfs = round(float(20.0 * np.log10(max(rms_val, _EPSILON))), 1)
    peak_val = float(np.max(np.abs(samples)))
    peak_dbfs = round(float(20.0 * np.log10(max(peak_val, _EPSILON))), 1)

    # 3. Adaptive noise floor
    if cfg.adaptive_noise_enabled:
        noise_floor_dbfs = round(
            estimate_adaptive_noise_floor(
                samples,
                sample_rate,
                noise_estimation_ms=cfg.noise_estimation_ms,
                frame_ms=cfg.vad_frame_ms,
            ),
            1,
        )
    else:
        frame_len = max(1, int(sample_rate * cfg.vad_frame_ms / 1000))
        levels = frame_levels(samples, frame_len)
        noise_floor_dbfs = round(noise_floor_percentile(levels), 1)

    # 4. SNR estimate
    snr_estimate_db = round(max(0.0, peak_dbfs - noise_floor_dbfs), 1)

    # 5. VAD analysis with adaptive noise floor override
    vad_activity = analyse(
        samples,
        sample_rate,
        min_speech_ms=cfg.vad_min_speech_ms,
        noise_margin_db=cfg.noise_margin_db,
        noise_floor_override=noise_floor_dbfs if cfg.adaptive_noise_enabled else None,
    )

    silence_ratio = round(max(0.0, 1.0 - vad_activity.speech_ratio), 3)

    # 6. Usability gate
    is_usable = True
    rejection_reason: Optional[str] = None

    if total_ms < MIN_DURATION_MS:
        is_usable = False
        rejection_reason = f"no speech detected: recording too short ({total_ms:.0f}ms < {MIN_DURATION_MS:.0f}ms)"
    elif peak_dbfs < -55.0 or rms_dbfs < -60.0:
        is_usable = False
        rejection_reason = (
            f"no speech detected in {total_ms:.0f}ms of audio "
            f"(peak {peak_dbfs:.0f}dBFS, {vad_activity.speech_ratio:.0%} voiced)"
        )
    elif clipping_ratio > 0.30:
        is_usable = False
        rejection_reason = f"severe audio clipping ({clipping_ratio:.1%} of samples clipped)"
    elif (
        not vad_activity.has_speech
        or vad_activity.speech_ratio < cfg.min_speech_ratio
        or vad_activity.speech_ms < cfg.vad_min_speech_ms
    ):
        is_usable = False
        rejection_reason = (
            f"no speech detected in {total_ms:.0f}ms of audio "
            f"(peak {peak_dbfs:.0f}dBFS, {vad_activity.speech_ratio:.0%} voiced)"
        )

    quality = AudioQuality(
        duration_ms=round(total_ms, 1),
        rms_dbfs=rms_dbfs,
        peak_dbfs=peak_dbfs,
        noise_floor_dbfs=noise_floor_dbfs,
        snr_estimate_db=snr_estimate_db,
        silence_ratio=silence_ratio,
        speech_ratio=vad_activity.speech_ratio,
        clipping_ratio=clipping_ratio,
        is_usable=is_usable,
        rejection_reason=rejection_reason,
    )

    return quality, vad_activity

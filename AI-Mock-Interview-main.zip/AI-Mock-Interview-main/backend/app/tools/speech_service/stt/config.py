"""Centralized configuration for the production-grade STT pipeline.

Consolidates Whisper decode parameters, VAD thresholds, adaptive noise settings,
quality scoring thresholds, retry parameters, and vocabulary normalization options.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any, Mapping, Optional


def _int(val: Any, default: int) -> int:
    if val is None:
        return default
    try:
        return int(str(val).strip())
    except (ValueError, TypeError):
        return default


def _float(val: Any, default: float) -> float:
    if val is None:
        return default
    try:
        return float(str(val).strip())
    except (ValueError, TypeError):
        return default


def _bool(val: Any, default: bool) -> bool:
    if val is None:
        return default
    s = str(val).strip().lower()
    if s in ("true", "1", "yes", "on"):
        return True
    if s in ("false", "0", "no", "off"):
        return False
    return default


@dataclass(frozen=True)
class STTPipelineConfig:
    """Settings controlling the entire STT audio processing and decode pipeline."""

    # Whisper model & runtime
    model_size: str = "tiny.en"
    compute_type: str = "int8"
    device: str = "cpu"
    num_threads: int = 4
    model_dir: Optional[str] = None
    beam_size: int = 5
    temperatures: tuple[float, ...] = (0.0, 0.2, 0.4)
    condition_on_previous_text: bool = False
    timeout_seconds: float =20.0
    max_concurrent_decodes: int = 2
    language: str = "en"

    # Pre-model VAD & energy gate
    vad_filter: bool = True
    vad_frame_ms: int = 30
    vad_min_speech_ms: int = 250
    vad_min_silence_ms: int = 500
    vad_padding_ms: int = 150
    min_speech_ratio: float = 0.04

    # Adaptive noise estimation
    adaptive_noise_enabled: bool = True
    noise_estimation_ms: int = 500
    noise_margin_db: float = 8.0

    # Quality scoring & retry
    quality_retry_enabled: bool = True
    quality_max_retries: int = 1
    min_confidence_threshold: float = 0.55

    # Post-processing & normalization
    technical_normalization_enabled: bool = True
    transcript_consensus_enabled: bool = True
    echo_detection_enabled: bool = True


def load_stt_config(
    gateway_config: Optional[Any] = None,
    env: Optional[Mapping[str, str]] = None,
) -> STTPipelineConfig:
    """Loads an STTPipelineConfig from a GatewayConfig instance, falling back to environment variables."""
    source_env = env if env is not None else os.environ

    # Base values from gateway_config if present
    model_size = getattr(gateway_config, "stt_model", None) or source_env.get("STT_MODEL", "tiny.en")
    compute_type = getattr(gateway_config, "stt_compute_type", None) or source_env.get("STT_COMPUTE_TYPE", "int8")
    model_dir = getattr(gateway_config, "stt_model_dir", None) or source_env.get("STT_MODEL_DIR") or None
    timeout_seconds = _float(
        getattr(gateway_config, "stt_timeout_seconds", None) or source_env.get("STT_TIMEOUT_SECONDS"),
        15.0,
    )
    vad_filter = _bool(
        getattr(gateway_config, "stt_vad_filter", None)
        if getattr(gateway_config, "stt_vad_filter", None) is not None
        else source_env.get("STT_VAD_FILTER"),
        True,
    )

    beam_size = _int(source_env.get("WHISPER_BEAM_SIZE"), 5)
    vad_min_silence_ms = _int(source_env.get("VAD_MIN_SILENCE_MS"), 500)
    vad_padding_ms = _int(source_env.get("VAD_PADDING_MS"), 150)
    noise_estimation_ms = _int(source_env.get("NOISE_ESTIMATION_MS"), 500)
    noise_margin_db = _float(source_env.get("NOISE_MARGIN_DB"), 8.0)
    quality_retry_enabled = _bool(source_env.get("QUALITY_RETRY_ENABLED"), True)
    quality_max_retries = _int(source_env.get("QUALITY_MAX_RETRIES"), 1)
    technical_normalization_enabled = _bool(source_env.get("TECHNICAL_NORMALIZATION_ENABLED"), True)
    transcript_consensus_enabled = _bool(source_env.get("TRANSCRIPT_CONSENSUS_ENABLED"), True)
    echo_detection_enabled = _bool(source_env.get("ECHO_DETECTION_ENABLED"), True)

    return STTPipelineConfig(
        model_size=model_size,
        compute_type=compute_type,
        model_dir=model_dir if model_dir else None,
        timeout_seconds=timeout_seconds,
        vad_filter=vad_filter,
        beam_size=beam_size,
        vad_min_silence_ms=vad_min_silence_ms,
        vad_padding_ms=vad_padding_ms,
        noise_estimation_ms=noise_estimation_ms,
        noise_margin_db=noise_margin_db,
        quality_retry_enabled=quality_retry_enabled,
        quality_max_retries=quality_max_retries,
        technical_normalization_enabled=technical_normalization_enabled,
        transcript_consensus_enabled=transcript_consensus_enabled,
        echo_detection_enabled=echo_detection_enabled,
    )

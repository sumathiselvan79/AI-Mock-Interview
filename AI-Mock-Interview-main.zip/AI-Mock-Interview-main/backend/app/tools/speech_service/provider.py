"""The speech provider seam — ~ mcp-servers/tool-speech-service/src/provider.ts.

`sherpa-onnx` (the official Python package, `INSTRUCTIONS.md §5.6`) is the
real implementation: self-hosted TTS and STT via ONNX Runtime, in-process,
no cloud API. It needs model files on disk (`SPEECH_MODEL_DIR`), too large
to vendor.

The fixture provider exists so the rest of the voice pipeline — audio
storage, refs, latency budgets, confidence thresholds, the low-confidence
fallback, consent gating — is exercised in CI/dev on a machine with no
models present. It produces real WAV bytes and carries its transcript
inside the file, so everything around the acoustic model is genuinely
tested; only the acoustic model itself is stubbed.
"""

from __future__ import annotations

import struct
from dataclasses import dataclass
from typing import Any, Optional, Protocol

import numpy as np


class SynthesisFailed(Exception):
    code = "synthesis_failed"


class TranscriptionFailed(Exception):
    code = "transcription_failed"


@dataclass
class SynthesisResult:
    audio: bytes  # 16-bit PCM WAV
    duration_ms: float
    sample_rate: int


@dataclass
class TranscriptionResult:
    transcript: str
    confidence: float  # 0-1. Below the Speech Service's threshold the harness must not score it.


class SpeechProvider(Protocol):
    name: str

    async def synthesize(self, text: str, voice: Optional[str] = None) -> SynthesisResult: ...
    async def transcribe(self, audio: bytes, **kwargs: Any) -> TranscriptionResult: ...
    def close(self) -> None: ...


class CompositeSpeechProvider:
    """One `SpeechProvider` made of two independent halves.

    The Speech Service exposes a single provider because its two methods happen
    to be adjacent in the MCP contract, not because one engine has to do both
    jobs. Since the STT swap they genuinely are different engines — sherpa's
    VITS voice synthesises, faster-whisper transcribes — and this is what keeps
    that an implementation detail rather than a change every caller sees.

    It also means either half can be missing. A machine with the TTS voice but
    no Whisper model gets a working question voice and a transcription error,
    which is a far better failure than no speech at all: the candidate hears
    the interview and types their answers.
    """

    def __init__(self, *, tts: Optional[Any] = None, asr: Optional[Any] = None) -> None:
        self._tts = tts
        self._asr = asr
        self.name = f"{getattr(tts, 'name', 'none')}+{getattr(asr, 'name', 'none')}"

    @property
    def asr(self) -> Optional[Any]:
        """The transcriber, for the caller that needs more than the protocol's
        `TranscriptionResult` — `server.py` reads its `last_detail` for the VAD
        statistics behind a decision it has to explain."""
        return self._asr

    async def synthesize(self, text: str, voice: Optional[str] = None) -> SynthesisResult:
        if not self._tts:
            raise SynthesisFailed("no TTS provider is configured")
        return await self._tts.synthesize(text, voice)

    async def transcribe(self, audio: bytes, **kwargs: Any) -> TranscriptionResult:
        if not self._asr:
            raise TranscriptionFailed("no STT provider is configured")
        return await self._asr.transcribe(audio, **kwargs)

    def close(self) -> None:
        for half in (self._tts, self._asr):
            if half:
                half.close()


# ------------------------------------------------------------------ WAV codec

_WAV_HEADER_BYTES = 44


def encode_wav(samples: np.ndarray, sample_rate: int) -> bytes:
    """Minimal 16-bit mono PCM WAV writer. `samples` is int16."""
    data = samples.astype("<i2").tobytes()
    header = struct.pack(
        "<4sI4s4sIHHIIHH4sI",
        b"RIFF",
        36 + len(data),
        b"WAVE",
        b"fmt ",
        16,  # PCM chunk size
        1,  # format: PCM
        1,  # channels: mono
        sample_rate,
        sample_rate * 2,  # byte rate
        2,  # block align
        16,  # bits per sample
        b"data",
        len(data),
    )
    return header + data


@dataclass
class DecodedWav:
    samples: np.ndarray  # float32, normalized to [-1, 1]
    sample_rate: int
    duration_ms: float


def decode_wav(data: bytes) -> DecodedWav:
    if len(data) < _WAV_HEADER_BYTES or data[0:4] != b"RIFF":
        raise TranscriptionFailed("audio is not a RIFF/WAV file")

    # Both `fmt ` and `data` are located by walking the chunk list — reading
    # them at fixed offsets only works when `fmt ` happens to come first,
    # and writers legitimately put LIST/fact chunks ahead of it.
    offset = 12
    sample_rate = 0
    bits_per_sample = 0
    data_start = -1
    data_length = 0

    while offset + 8 <= len(data):
        chunk_id = data[offset : offset + 4]
        size = struct.unpack_from("<I", data, offset + 4)[0]
        body = offset + 8

        if chunk_id == b"fmt " and body + 16 <= len(data):
            sample_rate = struct.unpack_from("<I", data, body + 4)[0]
            bits_per_sample = struct.unpack_from("<H", data, body + 14)[0]
        elif chunk_id == b"data":
            data_start = body
            data_length = min(size, len(data) - data_start)
            break
        offset += 8 + size + (size % 2)

    if sample_rate == 0:
        raise TranscriptionFailed("WAV file has no fmt chunk")
    if bits_per_sample != 16:
        raise TranscriptionFailed(f"expected 16-bit PCM, got {bits_per_sample}")
    if data_start < 0:
        raise TranscriptionFailed("WAV file has no data chunk")

    sample_count = data_length // 2
    raw = np.frombuffer(data, dtype="<i2", count=sample_count, offset=data_start)
    samples = raw.astype(np.float32) / 32768.0
    duration_ms = round((sample_count / sample_rate) * 1000) if sample_rate else 0
    return DecodedWav(samples=samples, sample_rate=sample_rate, duration_ms=duration_ms)


def rms(samples: np.ndarray) -> float:
    """Root-mean-square amplitude — the signal-quality proxy used for confidence."""
    if samples.size == 0:
        return 0.0
    return float(np.sqrt(np.mean(np.square(samples))))

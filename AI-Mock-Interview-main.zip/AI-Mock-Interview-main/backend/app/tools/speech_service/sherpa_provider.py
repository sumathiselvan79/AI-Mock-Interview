"""`sherpa-onnx` speech provider — the real TTS/STT implementation
(`CLAUDE.md §6`, `INSTRUCTIONS.md §5.6`). ~ mcp-servers/tool-speech-service/src/sherpa-provider.ts.

Self-hosted, in-process, no Python sidecar and no cloud API — this port
uses the official `sherpa-onnx` PyPI package directly (no bridge needed;
the TS side needed `sherpa-onnx-node` precisely because Node has no native
ONNX Runtime bindings of its own).

Models are not vendored — they are hundreds of megabytes. Point
`SPEECH_MODEL_DIR` at a directory laid out the way the TS `speech:models`
script downloads them. Without them the Speech Service falls back to the
fixture provider and says so.

**Warm-up matters.** The first synthesis after loading the VITS model is
far slower than every one after it. The 1.5s budget in `INSTRUCTIONS.md §9`
is about what a candidate waits for mid-interview, so the model is warmed
at construction and never on the candidate's clock.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import numpy as np

from app.tools.speech_service.provider import (
    SynthesisFailed,
    SynthesisResult,
    TranscriptionFailed,
    TranscriptionResult,
    decode_wav,
    encode_wav,
    rms,
)

# Default layout produced by the model-download step.
TTS_MODEL_SUBDIR = "vits-piper-en_US-amy-low"
ASR_MODEL_SUBDIR = "sherpa-onnx-whisper-tiny.en"


@dataclass
class SherpaPaths:
    tts_model: str
    tts_tokens: str
    tts_data_dir: str
    asr_encoder: str
    asr_decoder: str
    asr_tokens: str


def resolve_model_paths(model_dir: str) -> SherpaPaths:
    tts = Path(model_dir) / TTS_MODEL_SUBDIR
    asr = Path(model_dir) / ASR_MODEL_SUBDIR
    return SherpaPaths(
        tts_model=str(tts / "en_US-amy-low.onnx"),
        tts_tokens=str(tts / "tokens.txt"),
        tts_data_dir=str(tts / "espeak-ng-data"),
        asr_encoder=str(asr / "tiny.en-encoder.int8.onnx"),
        asr_decoder=str(asr / "tiny.en-decoder.int8.onnx"),
        asr_tokens=str(asr / "tiny.en-tokens.txt"),
    )


@dataclass
class ModelAvailability:
    tts: bool
    asr: bool
    missing: list[str] = field(default_factory=list)


def check_models(model_dir: str) -> ModelAvailability:
    paths = resolve_model_paths(model_dir)
    missing: list[str] = []

    def present(path: str) -> bool:
        if Path(path).exists():
            return True
        missing.append(path)
        return False

    tts = all([present(paths.tts_model), present(paths.tts_tokens), present(paths.tts_data_dir)])
    asr = all([present(paths.asr_encoder), present(paths.asr_decoder), present(paths.asr_tokens)])
    return ModelAvailability(tts=tts, asr=asr, missing=missing)


class SherpaSpeechProvider:
    name = "sherpa-onnx"

    def __init__(self, paths: SherpaPaths, availability: ModelAvailability, num_threads: int) -> None:
        self._paths = paths
        self._availability = availability
        self._num_threads = num_threads
        self._tts = None
        self._recognizer = None

    @staticmethod
    def create(*, model_dir: str, num_threads: int = 4, skip_warmup: bool = False) -> Optional["SherpaSpeechProvider"]:
        """Returns None when the models are not on disk, so the caller can fall back."""
        availability = check_models(model_dir)
        if not availability.tts and not availability.asr:
            return None

        provider = SherpaSpeechProvider(resolve_model_paths(model_dir), availability, num_threads)
        provider._load()
        if not skip_warmup:
            provider._warm_up()
        return provider

    def _load(self) -> None:
        # Imported lazily: the native extension should not load at module
        # import time on a machine that has no models and will never use it.
        import sherpa_onnx

        if self._availability.tts:
            self._tts = sherpa_onnx.OfflineTts(
                sherpa_onnx.OfflineTtsConfig(
                    model=sherpa_onnx.OfflineTtsModelConfig(
                        vits=sherpa_onnx.OfflineTtsVitsModelConfig(
                            model=self._paths.tts_model, tokens=self._paths.tts_tokens, data_dir=self._paths.tts_data_dir
                        ),
                        num_threads=self._num_threads,
                        debug=False,
                        provider="cpu",
                    ),
                    max_num_sentences=1,
                )
            )

        if self._availability.asr:
            self._recognizer = sherpa_onnx.OfflineRecognizer.from_whisper(
                encoder=self._paths.asr_encoder,
                decoder=self._paths.asr_decoder,
                tokens=self._paths.asr_tokens,
                num_threads=self._num_threads,
                debug=False,
                provider="cpu",
            )

    def _warm_up(self) -> None:
        """Pays the one-off ONNX graph cost at startup rather than mid-interview.

        A failed warm-up does not stop the gateway booting (degraded speech is
        not down), but it is no longer swallowed: it is recorded on
        `warmup_error`, which `select_speech_provider` turns into a `degraded`
        TTS status that `/health` reports and the gateway logs as an error.
        sherpa-onnx 2.x with this repo's Piper layout returns zero samples at
        `sample_rate=0` rather than raising, so an empty result counts as a
        failure here exactly as it does in `synthesize`."""
        if not self._tts:
            return
        try:
            generated = self._tts.generate("Ready.", 0, 1.0)
            _check_generated(generated)
        except Exception as err:  # noqa: BLE001 - recorded, not fatal
            self.warmup_error = f"{type(err).__name__}: {err}"

    warmup_error: Optional[str] = None

    async def synthesize(self, text: str, voice: Optional[str] = None) -> SynthesisResult:
        if not self._tts:
            raise SynthesisFailed("no TTS model loaded")
        if text.strip() == "":
            raise SynthesisFailed("cannot synthesise empty text")

        try:
            generated = self._tts.generate(text, 0, 1.0)
        except Exception as err:  # noqa: BLE001
            raise SynthesisFailed(f"sherpa-onnx synthesis failed: {err}") from err
        _check_generated(generated)

        samples = np.clip(np.asarray(generated.samples, dtype=np.float32), -1.0, 1.0)
        pcm = np.round(samples * 32767).astype(np.int16)

        return SynthesisResult(
            audio=encode_wav(pcm, generated.sample_rate),
            duration_ms=round((len(generated.samples) / generated.sample_rate) * 1000),
            sample_rate=generated.sample_rate,
        )

    async def transcribe(self, audio: bytes, **_kwargs: Any) -> TranscriptionResult:
        if not self._recognizer:
            raise TranscriptionFailed("no ASR model loaded")

        decoded = decode_wav(audio)
        try:
            stream = self._recognizer.create_stream()
            stream.accept_waveform(decoded.sample_rate, decoded.samples)
            self._recognizer.decode_stream(stream)
            text = stream.result.text or ""
        except Exception as err:  # noqa: BLE001
            raise TranscriptionFailed(f"sherpa-onnx transcription failed: {err}") from err

        text = text.strip()
        return TranscriptionResult(transcript=text, confidence=derive_confidence(text, decoded.samples, decoded.duration_ms))

    def close(self) -> None:
        self._tts = None
        self._recognizer = None


def _check_generated(generated: Any) -> None:
    """A synthesis that produced nothing is a typed `SynthesisFailed`, never a
    `ZeroDivisionError` from the duration arithmetic below it. sherpa-onnx
    2.x does exactly this with the Piper/espeak config (no frontend, zero
    samples, `sample_rate=0`), and the old code divided by it."""
    sample_rate = int(getattr(generated, "sample_rate", 0) or 0)
    samples = getattr(generated, "samples", None)
    count = 0 if samples is None else len(samples)
    if sample_rate <= 0 or count == 0:
        raise SynthesisFailed(
            f"sherpa-onnx returned no audio (samples={count}, sample_rate={sample_rate}); "
            "check the sherpa-onnx version against the model layout"
        )


def derive_confidence(text: str, samples: np.ndarray, duration_ms: float) -> float:
    """Whisper via sherpa-onnx returns text with no confidence score, so the
    tool derives one from two observable signals: signal level (too quiet to
    hear is the commonest real cause of a bad transcript) and word density
    (words/second far outside natural speech means the decoder produced very
    little for the audio it was given, or hallucinated filler into
    silence). Deliberately pessimistic (soul.md §5)."""
    words = len([w for w in text.split() if w])
    if words == 0:
        return 0.0

    level = rms(samples)
    # Below about -40dBFS a recording is too quiet to trust.
    level_score = min(1.0, level / 0.05)

    seconds = max(0.5, duration_ms / 1000)
    words_per_second = words / seconds
    # Natural speech sits around 2-3 words/second; score falls off either side.
    if words_per_second < 0.5:
        density_score = words_per_second / 0.5
    elif words_per_second > 6:
        density_score = max(0.0, 1 - (words_per_second - 6) / 6)
    else:
        density_score = 1.0

    return round(min(1.0, level_score * 0.5 + density_score * 0.5) * 100) / 100

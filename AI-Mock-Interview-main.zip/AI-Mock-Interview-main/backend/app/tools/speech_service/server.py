"""Speech Service Tool — ~ mcp-servers/tool-speech-service/src/index.ts. INSTRUCTIONS.md §5.6.

`synthesize_speech` turns an agent's question into audio; `transcribe_speech`
turns a candidate's recording into text. Callable by the Harness Agent only
— the gateway enforces that via `ALLOWED_CALLERS` (audio is a property of
the live frontend connection rather than any one agent's job).

Four rules this tool owns rather than delegates:

 - **Low confidence is an error, not a value.** Below `MIN_CONFIDENCE` the
   tool raises `transcription_low_confidence` instead of handing back a
   transcript, so nothing downstream can score it by accident (soul.md §5).
   The transcript still travels *on the error* so the harness can offer it
   as a suggestion for the typed fallback.
 - **Silence is never transcribed.** The VAD gate in `vad.py` runs before the
   model, because Whisper answers silence with a confident invented word rather
   than an empty string, and downstream that is indistinguishable from a real
   one-word answer. `no_speech_detected` is its own error code so the harness
   can say "there was nothing in that recording" rather than "that failed".
 - **Audio that is our own voice coming back is refused, not scored**
   (`source.py`). An open-speaker setup lets the microphone hear the question,
   and a transcript of our own question is fluent, on-topic and completely
   wrong to score. `audio_source_rejected`.
 - **Raw audio is retained only as long as it takes to produce a transcript**
   (§8), unless the candidate opted into keeping recordings. This tool
   deletes it in `transcribe_speech` itself rather than trusting a caller to
   remember — including on every refusal path above.

The engines behind those two methods are independent and composed rather than
one object doing both (`CompositeSpeechProvider`): TTS is sherpa-onnx's VITS
voice, STT is faster-whisper (`whisper_provider.py`). Either can be missing
without taking the other down.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Optional

from app.interview_domain.transitions import split_leading_cue
from app.shared_types import McpCallContext, McpHandlerError
from app.tools.speech_service.fixture_provider import FixtureSpeechProvider
from app.tools.speech_service.pacing import synthesize_paced
from app.tools.speech_service.provider import CompositeSpeechProvider, SpeechProvider, SynthesisFailed, TranscriptionFailed
from app.tools.speech_service.sherpa_provider import SherpaSpeechProvider, check_models
from app.tools.speech_service.source import classify
from app.tools.speech_service.whisper_provider import WhisperSettings, WhisperTranscriber

SERVER_NAME = "tool-speech-service"
METHODS = ("synthesize_speech", "transcribe_speech")

# Below this, a transcript must not reach the Follow-up Agent or the Eval
# Tool. Matches the Eval Tool's own floor so the two cannot drift apart.
MIN_CONFIDENCE = 0.6


@dataclass
class SpeechServiceDeps:
    files: Any  # FileStore
    provider: SpeechProvider
    audio_retention_opt_in: Optional[Callable[[str], Awaitable[bool]]] = None


@dataclass
class ProviderChoice:
    provider: SpeechProvider
    reason: str
    # Per-half health, for `/health` and the startup log. `available` means a
    # real engine loaded (and, for TTS, its warm-up produced audio);
    # `degraded` means that half is missing, failed to load, or failed its
    # warm-up, so the interview runs as text for it. A pinned test choice
    # (`ProviderChoice(FixtureSpeechProvider(), ...)`) is a deliberate stand-in,
    # not a fault, so the default is `available`.
    tts: str = "available"
    stt: str = "available"
    tts_note: Optional[str] = None
    stt_note: Optional[str] = None

    @property
    def degraded(self) -> bool:
        return self.tts != "available" or self.stt != "available"


# Loading the ONNX graphs costs seconds and hundreds of megabytes, so the
# choice is made once per process per model directory.
_provider_cache: dict[str, ProviderChoice] = {}


def select_speech_provider(model_dir: str, settings: Optional[WhisperSettings] = None) -> ProviderChoice:
    """Picks the real provider when models are present and the fixture
    otherwise. Never raises: a missing model must degrade the voice
    pipeline, not stop the gateway from booting."""
    cached = _provider_cache.get(model_dir)
    if cached:
        return cached
    choice = _load_speech_provider(model_dir, settings or WhisperSettings())
    _provider_cache[model_dir] = choice
    return choice


def _load_speech_provider(model_dir: str, settings: WhisperSettings) -> ProviderChoice:
    """Composes the two halves independently.

    TTS is still sherpa-onnx's VITS voice; STT is faster-whisper. They are
    loaded and reported separately because they now fail separately — a machine
    with the voice but no Whisper model should speak its questions and refuse
    transcription, not fall back to a test tone for both.
    """
    tts, tts_note, tts_ok = _load_tts(model_dir)
    asr, asr_note = _load_asr(settings)
    status = dict(
        tts="available" if tts_ok else "degraded",
        stt="available" if asr else "degraded",
        tts_note=None if tts_ok else tts_note,
        stt_note=None if asr else asr_note,
    )

    if not tts and not asr:
        return ProviderChoice(FixtureSpeechProvider(), f"no speech models available ({tts_note}; {asr_note}); using the fixture provider", **status)
    return ProviderChoice(CompositeSpeechProvider(tts=tts or FixtureSpeechProvider(), asr=asr or FixtureSpeechProvider()), f"{tts_note}; {asr_note}", **status)


def _load_tts(model_dir: str) -> tuple[Optional[Any], str, bool]:
    """Returns (provider, note, healthy). A voice whose warm-up produced no
    audio is still returned — every synthesis then raises a typed
    `SynthesisFailed` and the question is shown as text, which is better than
    swapping in the fixture's test tone — but it is reported unhealthy."""
    try:
        availability = check_models(model_dir)
        if not availability.tts:
            return None, f"no VITS voice in {model_dir} (set SPEECH_MODEL_DIR)", False
        provider = SherpaSpeechProvider.create(model_dir=model_dir)
        if not provider:
            return None, f"VITS voice in {model_dir} could not be loaded", False
        if provider.warmup_error:
            return provider, f"tts: sherpa-onnx VITS from {model_dir} failed its warm-up ({provider.warmup_error})", False
        return provider, f"tts: sherpa-onnx VITS from {model_dir}", True
    except Exception as err:  # noqa: BLE001
        return None, f"tts unavailable ({err})", False


def _load_asr(settings: WhisperSettings) -> tuple[Optional[Any], str]:
    transcriber = WhisperTranscriber.create(settings)
    if not transcriber:
        return None, f"stt: faster-whisper {settings.model_size} unavailable (is `faster-whisper` installed?)"
    source = settings.model_dir or f"{settings.model_size} (HuggingFace cache)"
    return transcriber, f"stt: faster-whisper {source} [{settings.compute_type}, {settings.timeout_seconds:.0f}s timeout, vad={settings.vad_filter}]"


class ToolSpeechServiceServer:
    name = SERVER_NAME

    def __init__(self, deps: SpeechServiceDeps) -> None:
        self._deps = deps

    async def call(self, method: str, params: Any, ctx: McpCallContext) -> Any:
        p = params or {}
        if method == "synthesize_speech":
            return await _synthesize(self._deps, p)
        if method == "transcribe_speech":
            return await _transcribe(self._deps, p)
        raise McpHandlerError("unknown_method", f"{SERVER_NAME} has no method {method}")


async def _synthesize(deps: SpeechServiceDeps, params: dict[str, Any]) -> dict[str, Any]:
    text = params["text"]
    voice = params.get("voice")
    try:
        # (§6) A line that opens with a conversational cue gets a real pause
        # between the cue and the question. `split_leading_cue` returns None
        # for everything else — which is most lines — and `synthesize_paced`
        # returns None on any trouble, so both fall through to the single-clip
        # path below unchanged.
        paced = None
        split = split_leading_cue(text)
        if split:
            paced = await synthesize_paced(deps.provider, split[0], split[1], voice)

        audio, duration_ms = (paced.audio, paced.duration_ms) if paced else await _one_clip(deps, text, voice)

        stored = await deps.files.put(
            session_id=params.get("session_id") or "shared", filename=f"question-{int(time.time() * 1000)}.wav", content_type="audio/wav", data=audio
        )
        return {"audio_url": f"/audio/{stored.ref}", "duration_ms": duration_ms}
    except Exception as err:  # noqa: BLE001 - the harness falls back to text-only (§5.6)
        message = str(err) if isinstance(err, SynthesisFailed) else f"synthesis failed: {err}"
        raise McpHandlerError("synthesis_failed", message) from err


async def _one_clip(deps: SpeechServiceDeps, text: str, voice: Optional[str]) -> tuple[bytes, float]:
    result = await deps.provider.synthesize(text, voice)
    return result.audio, result.duration_ms


async def _transcribe(deps: SpeechServiceDeps, params: dict[str, Any]) -> dict[str, Any]:
    ref = params["audio_ref"]
    if ref.startswith("/audio/"):
        ref = ref[len("/audio/") :]
    stored = await deps.files.get(ref)
    if not stored:
        raise McpHandlerError("transcription_failed", f"no stored audio for ref {params['audio_ref']}")
    _meta, data = stored

    device = params.get("input_device") or {}

    # The loopback-device check runs BEFORE the model. A capture device that is
    # a monitor of system output is conclusively not a voice, so decoding it
    # would spend 15 seconds of budget to transcribe our own question back at
    # ourselves (`source.py`).
    device_verdict = classify(device_hint=device.get("hint"), device_label=device.get("label"))
    if device_verdict.reject:
        await _discard_audio(deps, ref, params.get("session_id"))
        raise McpHandlerError("audio_source_rejected", json.dumps({"message": device_verdict.reason, "source": device_verdict.source}))

    try:
        result = await deps.provider.transcribe(
            data,
            question_text=params.get("question_text") or params.get("question_context"),
            topic_terms=params.get("topic_terms"),
            spoken_recently=params.get("spoken_recently") or [],
            tts_playing_at=params.get("tts_playing_at"),
            recording_started_at=params.get("recording_started_at"),
            device_hint=device.get("hint"),
            device_label=device.get("label"),
            candidate_context=params.get("candidate_context"),
        )
    except Exception as err:  # noqa: BLE001
        await _discard_audio(deps, ref, params.get("session_id"))
        message = str(err) if isinstance(err, TranscriptionFailed) else f"transcription failed: {err}"
        # "There was nothing in that recording" is a different thing to tell a
        # candidate than "that failed to transcribe", and the VAD gate knows
        # which it was. Distinguished by code so the harness can say so.
        code = "no_speech_detected" if "no speech detected" in message else "transcription_failed"
        raise McpHandlerError(code, message) from err

    # Raw audio has served its purpose the moment a transcript exists (§8).
    await _discard_audio(deps, ref, params.get("session_id"))

    detail = _vad_detail(deps.provider)

    # The transcript check. This is the half that catches real speaker bleed,
    # and it needs the words, so it can only run now — a device that reports
    # itself as a microphone is still capable of hearing one.
    verdict = classify(
        transcript=result.transcript,
        device_hint=device.get("hint"),
        device_label=device.get("label"),
        spoken_recently=params.get("spoken_recently") or [],
        tts_playing_at=params.get("tts_playing_at"),
        recording_started_at=params.get("recording_started_at"),
    )
    if verdict.reject:
        raise McpHandlerError("audio_source_rejected", json.dumps({"message": verdict.reason, "source": verdict.source, "draft_transcript": result.transcript}))

    if result.confidence < MIN_CONFIDENCE:
        raise McpHandlerError(
            "transcription_low_confidence",
            json.dumps(
                {
                    "message": f"transcription confidence {result.confidence} is below {MIN_CONFIDENCE}; re-prompt the candidate or offer the typed-text fallback",
                    "confidence": result.confidence,
                    # Carried so the harness can pre-fill the typed fallback
                    # for the candidate to correct. It must never be scored as-is.
                    "draft_transcript": result.transcript,
                    **({"speech": detail} if detail else {}),
                }
            ),
        )

    out: dict[str, Any] = {"transcript": result.transcript, "confidence": result.confidence, "source": verdict.source}
    if detail:
        out["speech"] = detail
    return out


def _vad_detail(provider: Any) -> Optional[dict[str, Any]]:
    """The VAD statistics behind the transcript, when the provider is one that
    measures them (the fixture provider is not).

    Durations only — never any part of the audio or the transcript, so this is
    safe to put on the wire and into a telemetry span under §8.
    """
    asr = getattr(provider, "asr", None)
    detail = getattr(asr, "last_detail", None)
    if not detail:
        return None
    activity = detail.activity
    return {
        "total_ms": getattr(activity, "total_ms", 0.0),
        "speech_ms": getattr(activity, "speech_ms", 0.0),
        "silence_ms": getattr(activity, "silence_ms", 0.0),
        "leading_silence_ms": getattr(activity, "leading_silence_ms", 0.0),
        "trailing_silence_ms": getattr(activity, "trailing_silence_ms", 0.0),
        "speech_ratio": getattr(activity, "speech_ratio", 0.0),
        "peak_dbfs": getattr(activity, "peak_dbfs", -100.0),
        "trimmed_ms": getattr(detail, "trimmed_ms", 0.0),
        "decode_ms": getattr(detail, "decode_ms", 0.0),
    }


async def _discard_audio(deps: SpeechServiceDeps, ref: str, session_id: Optional[str]) -> None:
    if session_id and deps.audio_retention_opt_in and await deps.audio_retention_opt_in(session_id):
        return
    await deps.files.delete(ref)


def create_tool_speech_service_server(deps: SpeechServiceDeps) -> ToolSpeechServiceServer:
    return ToolSpeechServiceServer(deps)

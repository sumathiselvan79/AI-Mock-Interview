"""Voice activity detection, silence measurement and trimming — the pass a
recording goes through before Whisper ever sees it (INSTRUCTIONS.md §5.6).

**Why this exists at all.** Whisper does not politely return an empty string
for audio with nothing in it. Handed two seconds of silence, `tiny.en` returns
`" You"` — a confident, plausible, entirely invented word. That is not a
transcription bug to work around later; it is the exact failure soul.md
§"No fabrication" is about, and once it reaches the harness it is
indistinguishable from a real one-word answer. The only reliable fix is not to
ask the model about silence in the first place.

So this module answers three questions, all before the model runs:

 1. **Is there speech here at all?** If not, the caller refuses rather than
    transcribes (`server.py`), and the candidate is told the recording was
    empty rather than shown a word they never said.
 2. **Where does the speech start and end?** Leading and trailing silence is
    trimmed off. Whisper's cost is per second of audio, and silence at the
    edges is both the most common padding and the most likely to hallucinate
    into.
 3. **How much of the recording was silence?** Carried out as a statistic, so
    the confidence score and the mic-vs-speaker classifier can both use it and
    a human reading telemetry can see why a turn went the way it did.

**Deliberately energy-based and model-free.** faster-whisper bundles Silero
VAD and `server.py` turns it on for the decode itself — that is the right tool
for "which spans inside this audio are speech". It is the wrong tool for the
three questions above: it costs an ONNX session, it cannot run before the
model is loaded, and it gives no silence *statistics*. The two are
complementary and the split is intentional — this pass is a cheap gate, Silero
is a precise filter.

**The threshold adapts.** A fixed dBFS floor mislabels a quiet headset as
silence and a noisy room as speech. The floor here is the recording's own
noise level plus a margin, clamped so a recording that is *all* speech or *all*
hum cannot pull its own threshold to a useless place.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np

#: Frame length for the energy scan. 30ms is the usual VAD frame — long enough
#: for a stable RMS, short enough to place a word boundary within a syllable.
FRAME_MS = 30

#: Absolute floor. Nothing below this counts as speech however quiet the rest
#: of the recording is; roughly the level of a muted or unplugged microphone.
ABSOLUTE_SILENCE_DBFS = -55.0

#: How far above the recording's own noise floor a frame must sit to count as
#: speech. Speech typically runs 20-40dB over room tone, so 12dB is permissive
#: on purpose — this is a gate against silence, not a transcription decision.
NOISE_MARGIN_DB = 10.0

#: Shorter than this and it is a click, a breath or a chair, not an answer.
MIN_SPEECH_MS = 200

#: Kept either side of the detected speech when trimming. Consonants at the
#: very start of an utterance are low-energy and easy to cut off; losing the
#: "s" from "scaled" changes the word, so the trim errs on the side of keeping
#: audio the model can ignore for free.
TRIM_PAD_MS = 120

_EPSILON = 1e-10


@dataclass(frozen=True)
class VoiceActivity:
    """What the energy scan found. All durations in milliseconds."""

    sample_rate: int
    total_ms: float
    speech_ms: float
    silence_ms: float
    leading_silence_ms: float
    trailing_silence_ms: float
    #: Fraction of the recording that was speech, 0..1. The single most useful
    #: number here: a genuine answer sits well above 0.3, and a recording that
    #: is 95% silence with one blip is almost always a mis-click.
    speech_ratio: float
    peak_dbfs: float
    #: Estimated room tone, in dBFS. Also the input to the adaptive threshold.
    noise_floor_dbfs: float
    threshold_dbfs: float
    has_speech: bool
    #: Sample offsets of the first and last speech frame. Both 0 when there is
    #: no speech at all.
    speech_start: int
    speech_end: int


def analyse(
    samples: np.ndarray,
    sample_rate: int,
    *,
    min_speech_ms: float = MIN_SPEECH_MS,
    noise_margin_db: float = NOISE_MARGIN_DB,
    noise_floor_override: Optional[float] = None,
) -> VoiceActivity:
    """Scans `samples` (float32 in [-1, 1]) frame by frame and reports what it found.

    Never raises on odd input — an empty array, a single sample, pure silence
    and pure clipping all produce a well-formed result with `has_speech` set
    correctly. This runs on candidate-supplied audio on the answer path, so a
    malformed recording must degrade to "no speech detected", never to a 500.
    """
    total_ms = (len(samples) / sample_rate * 1000) if sample_rate else 0.0

    frame_len = max(1, int(sample_rate * FRAME_MS / 1000))
    if len(samples) < frame_len or sample_rate <= 0:
        return _empty(sample_rate, total_ms)

    frame_dbfs = _frame_levels(samples, frame_len)
    noise_floor = noise_floor_override if noise_floor_override is not None else _noise_floor(frame_dbfs)
    threshold = max(ABSOLUTE_SILENCE_DBFS, noise_floor + noise_margin_db)

    voiced = frame_dbfs > threshold
    # A frame is only speech if it belongs to a run long enough to be one. This
    # is what stops a single door slam from reading as an answer.
    voiced = _drop_short_runs(voiced, min_frames=max(1, int(min_speech_ms / FRAME_MS)))

    speech_frames = int(voiced.sum())
    ms_per_frame = frame_len / sample_rate * 1000

    if speech_frames == 0:
        return _empty(sample_rate, total_ms, noise_floor=noise_floor, threshold=threshold, peak=_peak_dbfs(samples))

    indices = np.flatnonzero(voiced)
    first, last = int(indices[0]), int(indices[-1])

    speech_start = first * frame_len
    speech_end = min(len(samples), (last + 1) * frame_len)

    return VoiceActivity(
        sample_rate=sample_rate,
        total_ms=round(total_ms, 1),
        speech_ms=round(speech_frames * ms_per_frame, 1),
        silence_ms=round(max(0.0, total_ms - speech_frames * ms_per_frame), 1),
        leading_silence_ms=round(first * ms_per_frame, 1),
        trailing_silence_ms=round((len(frame_dbfs) - 1 - last) * ms_per_frame, 1),
        speech_ratio=round(speech_frames / len(frame_dbfs), 3),
        peak_dbfs=_peak_dbfs(samples),
        noise_floor_dbfs=round(noise_floor, 1),
        threshold_dbfs=round(threshold, 1),
        has_speech=True,
        speech_start=speech_start,
        speech_end=speech_end,
    )


def trim(samples: np.ndarray, activity: VoiceActivity, *, pad_ms: float = TRIM_PAD_MS) -> np.ndarray:
    """The speech, with the silence either side removed and a little padding kept.

    Returns the input unchanged when there is no speech to centre on — the
    caller decides what to do about that, and silently returning an empty array
    here would turn "nothing was said" into "the recording was corrupted".
    """
    if not activity.has_speech or activity.sample_rate <= 0:
        return samples
    pad = int(activity.sample_rate * pad_ms / 1000)
    start = max(0, activity.speech_start - pad)
    end = min(len(samples), activity.speech_end + pad)
    return samples[start:end] if end > start else samples


def _frame_levels(samples: np.ndarray, frame_len: int) -> np.ndarray:
    """Per-frame RMS in dBFS. The trailing partial frame is dropped rather than
    zero-padded: padding would invent silence that is not in the recording and
    then measure it."""
    usable = (len(samples) // frame_len) * frame_len
    frames = samples[:usable].reshape(-1, frame_len).astype(np.float64)
    rms = np.sqrt(np.mean(np.square(frames), axis=1))
    return 20.0 * np.log10(np.maximum(rms, _EPSILON))


def _noise_floor(frame_dbfs: np.ndarray) -> float:
    """Room tone, taken as the 10th percentile of frame levels.

    A percentile rather than the minimum: one anomalously dead frame (a dropped
    buffer, a codec gap) would otherwise drag the floor to -100dB and take the
    threshold with it, so every subsequent frame would read as speech.
    """
    return float(np.percentile(frame_dbfs, 10))


def _drop_short_runs(voiced: np.ndarray, *, min_frames: int) -> np.ndarray:
    """Zeroes runs of `True` shorter than `min_frames`."""
    if min_frames <= 1 or not voiced.any():
        return voiced
    out = voiced.copy()
    start: Optional[int] = None
    for i, is_voiced in enumerate([*voiced, False]):
        if is_voiced and start is None:
            start = i
        elif not is_voiced and start is not None:
            if i - start < min_frames:
                out[start:i] = False
            start = None
    return out


def _peak_dbfs(samples: np.ndarray) -> float:
    peak = float(np.max(np.abs(samples))) if samples.size else 0.0
    return round(20.0 * np.log10(max(peak, _EPSILON)), 1)


def _empty(
    sample_rate: int,
    total_ms: float,
    *,
    noise_floor: float = ABSOLUTE_SILENCE_DBFS,
    threshold: float = ABSOLUTE_SILENCE_DBFS,
    peak: float = -100.0,
) -> VoiceActivity:
    return VoiceActivity(
        sample_rate=sample_rate,
        total_ms=round(total_ms, 1),
        speech_ms=0.0,
        silence_ms=round(total_ms, 1),
        leading_silence_ms=round(total_ms, 1),
        trailing_silence_ms=round(total_ms, 1),
        speech_ratio=0.0,
        peak_dbfs=peak,
        noise_floor_dbfs=round(noise_floor, 1),
        threshold_dbfs=round(threshold, 1),
        has_speech=False,
        speech_start=0,
        speech_end=0,
    )


#: Public exports for audio quality analysis
frame_levels = _frame_levels
noise_floor_percentile = _noise_floor

"""Audio pacing — `HUMAN_INTERACTION_FLOW.md` §6.

Stage 9 solved the text side: question reveal is synced word-by-word to TTS
boundaries, so the words appear as they are heard. What was still missing is
pacing *within* the audio. A line like "Staying with that — how do you decide
when an index costs more than it saves?" was synthesised as one clip and
delivered at one clip's pace, so the cue ran straight into the question. A
person delivering the same sentence pauses at the dash. The cue is the part
that says "I heard you"; the question is a new thought.

This inserts that pause. Not filler audio and not a spoken "um" — silence,
which is what a real pause is.

**Why the two clips are stitched here rather than on the client.** The design
note offered either SSML breaks or two clips stitched client-side. sherpa-onnx
takes plain text and has no SSML, so breaks are out. Stitching server-side
instead of client-side keeps `audio_url` a single ref, which means the
frontend's playback path, the reveal timing that hangs off it, the audio
retention rules in §8 and the `/audio/{ref}` route all stay exactly as they
are — a paced line is just a longer clip. A second ref would have needed all
four of those to learn about pairs.

The cost is one extra synthesis call, and only on lines that actually open
with a cue. Every failure path falls back to the single unpaced clip, because
a question the candidate can hear beats a pause they cannot.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np

from app.tools.speech_service.provider import SpeechProvider, decode_wav, encode_wav

#: Long enough to read as a beat rather than a glitch, short enough not to feel
#: like the connection dropped. Roughly the gap a person leaves between
#: acknowledging an answer and asking the next thing.
PAUSE_MS = 350


@dataclass
class PacedSynthesis:
    audio: bytes
    duration_ms: float


async def synthesize_paced(
    provider: SpeechProvider, cue: str, question: str, voice: Optional[str] = None
) -> Optional[PacedSynthesis]:
    """Synthesises `cue`, then `PAUSE_MS` of silence, then `question`.

    `None` on any problem at all — a provider failure on either half, a sample
    rate mismatch between them, an undecodable clip. The caller then synthesises
    the whole line the way it always did. Returning `None` rather than raising
    is deliberate: nothing here is important enough to cost a candidate their
    question.
    """
    try:
        first = await provider.synthesize(cue, voice)
        second = await provider.synthesize(question, voice)

        # A provider that changes rate between two calls in the same breath
        # would need resampling to join; that is a lot of machinery for a
        # 350ms pause, and no provider in this repo does it.
        if first.sample_rate != second.sample_rate:
            return None

        head = decode_wav(first.audio)
        tail = decode_wav(second.audio)
        silence = np.zeros(int(first.sample_rate * PAUSE_MS / 1000), dtype=np.float32)
        joined = np.concatenate([head.samples, silence, tail.samples])

        # Back to the int16 the WAV writer wants. Clipped rather than
        # normalised: the two halves came from the same voice at the same
        # level, so there is nothing to rescale, and rescaling would make the
        # paced version quieter than the unpaced one for no reason.
        samples = np.clip(joined * 32768.0, -32768, 32767).astype(np.int16)
        return PacedSynthesis(
            audio=encode_wav(samples, first.sample_rate),
            duration_ms=first.duration_ms + PAUSE_MS + second.duration_ms,
        )
    except Exception:  # noqa: BLE001 - see the docstring; pacing is never worth a failure
        return None

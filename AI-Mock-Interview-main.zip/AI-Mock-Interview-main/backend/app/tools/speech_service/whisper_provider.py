"""Whisper STT via `faster-whisper` — the ASR half of the Speech Service
(INSTRUCTIONS.md §5.6).

Replaces the sherpa-onnx ASR path. Same model family as before (`whisper
tiny.en`), different runtime: CTranslate2 rather than sherpa's ONNX wrapper.
Three reasons that is worth the swap, beyond the instruction to make it:

 - **No sherpa dependency for transcription.** TTS still uses sherpa's VITS
   voice (`sherpa_provider.py`), so the two halves of the Speech Service now
   have independent runtimes and one can be replaced without touching the
   other. `select_speech_provider` composes them.
 - **Real VAD, bundled and offline.** faster-whisper ships Silero VAD as an
   ONNX asset inside the package, so `vad_filter` costs no download and no
   extra service. `vad.py` handles the cheap pre-model gate; this handles the
   precise in-decode filter. Both, deliberately — see `vad.py`'s docstring.
 - **The model resolves itself.** `tiny.en` is fetched from the HuggingFace
   cache on first use and pinned there. `WHISPER_MODEL_DIR` overrides it with
   a vendored directory for a deployment that cannot reach the network at all.

**The 15-second timeout is enforced here and is not advisory.** Whisper's
decode time is a function of audio length and of how confusing the audio is,
and the pathological case is not slow, it is *unbounded*: fed noise, the
decoder can loop emitting repeated tokens until it hits its own limits. A
candidate mid-interview cannot wait that out, so the call runs in a worker
thread under a hard wall clock and raises `TranscriptionFailed` on expiry. The
harness already routes a transcription failure to the typed fallback, so a
timeout costs the candidate a retype, never the answer.
"""

from __future__ import annotations

import asyncio
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional, Sequence

import numpy as np

from app.tools.speech_service.provider import (
    SynthesisFailed,
    SynthesisResult,
    TranscriptionFailed,
    TranscriptionResult,
    decode_wav,
    rms,
)
from app.tools.speech_service.stt.config import STTPipelineConfig
from app.tools.speech_service.stt.pipeline import run_stt_pipeline
from app.tools.speech_service.vad import VoiceActivity, analyse, trim

#: Whisper is trained on 16kHz mono. Anything else is resampled before decode.
WHISPER_SAMPLE_RATE = 16_000

#: Hard wall-clock cap on one transcription, in seconds. See the module
#: docstring — this bounds an unbounded failure mode, it is not a performance
#: target. Overridable per deployment via `STT_TIMEOUT_SECONDS`.
DEFAULT_TIMEOUT_SECONDS = 15.0

#: A recording with less than this share of speech is refused without being
#: decoded at all. `tiny.en` answers silence with a confident invented word
#: ("You"), and that word is indistinguishable downstream from a real one-word
#: answer (`vad.py`, soul.md §"No fabrication").
MIN_SPEECH_RATIO = 0.04
MIN_SPEECH_MS = 250


@dataclass
class WhisperSettings:
    model_size: str = "tiny.en"
    #: int8 on CPU: ~4x faster than float32 for a loss that does not show at
    #: tiny's accuracy in the first place.
    compute_type: str = "int8"
    device: str = "cpu"
    num_threads: int = 4
    #: A vendored model directory, or None to use the HuggingFace cache.
    model_dir: Optional[str] = None
    timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS
    #: How many decodes may run at once. Also the ceiling on how many
    #: timed-out, uncancellable decodes can be in flight — see `transcribe`.
    max_concurrent_decodes: int = 2
    #: Silero VAD inside the decode, on top of the energy gate before it.
    vad_filter: bool = True
    #: How long a silence has to be before Silero splits the audio there.
    vad_min_silence_ms: int = 500
    language: str = "en"
    beam_size: int = 5
    vad_padding_ms: int = 150
    noise_estimation_ms: int = 500
    noise_margin_db: float = 8.0
    quality_retry_enabled: bool = True
    quality_max_retries: int = 1
    technical_normalization_enabled: bool = True
    transcript_consensus_enabled: bool = True
    echo_detection_enabled: bool = True


@dataclass
class TranscriptionDetail:
    """Everything the Speech Service learned about a recording besides the words.

    Returned alongside the transcript rather than folded into it so the caller
    can report *why* a recording was refused — "there was no speech in that"
    and "that was your speakers" need different things said to the candidate.
    """

    activity: VoiceActivity
    trimmed_ms: float
    decode_ms: float
    quality_score: float = 1.0
    quality_class: str = "GOOD"
    used_retry: bool = False
    hallucination_flags: list[str] = field(default_factory=list)
    metrics: dict[str, Any] = field(default_factory=dict)


class WhisperTranscriber:
    """The ASR half of the Speech Service. Transcription only — `synthesize`
    raises, because composing this with a TTS provider is `select_speech_provider`'s
    job and a silent no-op here would be a voice that never speaks."""

    name = "faster-whisper"

    def __init__(self, settings: WhisperSettings) -> None:
        self._settings = settings
        self._model: Any = None
        self._last_detail: Optional[TranscriptionDetail] = None
        # Small and dedicated. Sized for the orphan problem described in
        # `transcribe`, not for throughput: a `WhisperModel` is not safe to
        # drive from many threads at once anyway, so the ceiling on useful
        # concurrency here is low regardless.
        self._executor = ThreadPoolExecutor(max_workers=settings.max_concurrent_decodes, thread_name_prefix="whisper")

    @staticmethod
    def create(settings: Optional[WhisperSettings] = None, *, skip_warmup: bool = False) -> Optional["WhisperTranscriber"]:
        """Returns None when faster-whisper or its model is unavailable, so the
        caller falls back to the fixture provider rather than failing to boot."""
        settings = settings or WhisperSettings()
        try:
            transcriber = WhisperTranscriber(settings)
            transcriber._load()
            if not skip_warmup:
                transcriber._warm_up()
            return transcriber
        except Exception:  # noqa: BLE001 - a missing model degrades voice, it does not stop the gateway
            return None

    def _load(self) -> None:
        # Imported lazily: CTranslate2 loads native libraries, and a deployment
        # with no speech configured should not pay that at import time.
        from faster_whisper import WhisperModel

        source = self._settings.model_dir or self._settings.model_size
        if self._settings.model_dir and not Path(self._settings.model_dir).exists():
            raise FileNotFoundError(f"WHISPER_MODEL_DIR {self._settings.model_dir} does not exist")

        self._model = WhisperModel(
            source,
            device=self._settings.device,
            compute_type=self._settings.compute_type,
            cpu_threads=self._settings.num_threads,
        )

    def _warm_up(self) -> None:
        """Pays the first-decode cost at startup rather than on a candidate's
        clock (§9's latency budget is about what someone waits for mid-interview)."""
        try:
            self._decode(np.zeros(WHISPER_SAMPLE_RATE // 2, dtype=np.float32))
        except Exception:  # noqa: BLE001 - a failed warm-up is not fatal
            pass

    @property
    def last_detail(self) -> Optional[TranscriptionDetail]:
        """VAD and timing detail for the most recent `transcribe`.

        A property rather than a second return value because `TranscriptionResult`
        is the shape the `SpeechProvider` protocol fixes, and widening that
        would ripple through the fixture provider and every caller for the
        benefit of one. `server.py` reads it immediately after awaiting, on the
        same task.
        """
        return self._last_detail

    async def synthesize(self, text: str, voice: Optional[str] = None) -> SynthesisResult:
        raise SynthesisFailed("faster-whisper is a transcriber; compose it with a TTS provider")

    async def transcribe(
        self,
        audio: bytes,
        *,
        question_text: Optional[str] = None,
        topic_terms: Optional[Sequence[str]] = None,
        spoken_recently: Optional[Sequence[str]] = None,
        tts_playing_at: Optional[float] = None,
        recording_started_at: Optional[float] = None,
        device_hint: Optional[str] = None,
        device_label: Optional[str] = None,
        candidate_context: Optional[dict] = None,
    ) -> TranscriptionResult:
        if not self._model:
            raise TranscriptionFailed("no Whisper model loaded")

        # If a subclass overrides _decode (e.g. test stubs), preserve direct decode invocation
        if type(self)._decode != WhisperTranscriber._decode:
            decoded = decode_wav(audio)
            samples = _to_whisper_rate(decoded.samples, decoded.sample_rate)
            activity = analyse(samples, WHISPER_SAMPLE_RATE, min_speech_ms=MIN_SPEECH_MS)
            if not activity.has_speech or activity.speech_ratio < MIN_SPEECH_RATIO or activity.speech_ms < MIN_SPEECH_MS:
                self._last_detail = TranscriptionDetail(activity=activity, trimmed_ms=0.0, decode_ms=0.0)
                raise TranscriptionFailed(
                    f"no speech detected in {activity.total_ms:.0f}ms of audio "
                    f"(peak {activity.peak_dbfs:.0f}dBFS, {activity.speech_ratio:.0%} voiced)"
                )
            trimmed = trim(samples, activity)
            trimmed_ms = round(len(trimmed) / WHISPER_SAMPLE_RATE * 1000, 1)
            loop = asyncio.get_running_loop()
            started = loop.time()
            try:
                text = await asyncio.wait_for(
                    loop.run_in_executor(self._executor, self._decode, trimmed),
                    timeout=self._settings.timeout_seconds,
                )
            except asyncio.TimeoutError as err:
                raise TranscriptionFailed(
                    f"transcription exceeded the {self._settings.timeout_seconds:g}s limit; "
                    "the recording could not be transcribed in time"
                ) from err
            except Exception as err:  # noqa: BLE001
                raise TranscriptionFailed(f"whisper transcription failed: {err}") from err
            decode_ms = round((loop.time() - started) * 1000, 1)
            self._last_detail = TranscriptionDetail(activity=activity, trimmed_ms=trimmed_ms, decode_ms=decode_ms)
            text = (text or "").strip()
            return TranscriptionResult(transcript=text, confidence=derive_confidence(text, trimmed, activity))

        # Standard production path: delegate to unified STT pipeline
        pipeline_cfg = STTPipelineConfig(
            model_size=self._settings.model_size,
            compute_type=self._settings.compute_type,
            device=self._settings.device,
            num_threads=self._settings.num_threads,
            model_dir=self._settings.model_dir,
            beam_size=getattr(self._settings, "beam_size", 5),
            timeout_seconds=self._settings.timeout_seconds,
            max_concurrent_decodes=self._settings.max_concurrent_decodes,
            language=self._settings.language,
            vad_filter=self._settings.vad_filter,
            vad_min_silence_ms=self._settings.vad_min_silence_ms,
            vad_padding_ms=getattr(self._settings, "vad_padding_ms", 150),
            adaptive_noise_enabled=True,
            noise_estimation_ms=getattr(self._settings, "noise_estimation_ms", 500),
            noise_margin_db=getattr(self._settings, "noise_margin_db", 8.0),
            quality_retry_enabled=getattr(self._settings, "quality_retry_enabled", True),
            quality_max_retries=getattr(self._settings, "quality_max_retries", 1),
            technical_normalization_enabled=getattr(self._settings, "technical_normalization_enabled", True),
            transcript_consensus_enabled=getattr(self._settings, "transcript_consensus_enabled", True),
            echo_detection_enabled=getattr(self._settings, "echo_detection_enabled", True),
        )

        # Build the CandidateContext from the dict, if provided
        from app.tools.speech_service.stt.prompts import CandidateContext
        ctx = None
        if candidate_context:
            ctx = CandidateContext(
                full_name=candidate_context.get("full_name"),
                role=candidate_context.get("role"),
                recent_companies=candidate_context.get("recent_companies") or [],
                institutions=candidate_context.get("institutions") or [],
                degrees=candidate_context.get("degrees") or [],
                keywords=candidate_context.get("keywords") or [],
            )

        result = await run_stt_pipeline(
            audio,
            pipeline_cfg,
            self._model,
            self._executor,
            question_text=question_text,
            topic_terms=topic_terms,
            spoken_recently=spoken_recently,
            tts_playing_at=tts_playing_at,
            recording_started_at=recording_started_at,
            device_hint=device_hint,
            device_label=device_label,
            candidate_context=ctx,
        )

        activity = result.activity if result.activity is not None else analyse(np.zeros(0, dtype=np.float32), WHISPER_SAMPLE_RATE)
        self._last_detail = TranscriptionDetail(
            activity=activity,
            trimmed_ms=float(result.metrics.get("trimmed_ms", 0.0)),
            decode_ms=float(result.metrics.get("decode_ms", 0.0)),
            quality_score=result.quality_score,
            quality_class=result.quality_class,
            used_retry=result.used_retry,
            hallucination_flags=result.transcription_quality.hallucination_flags if result.transcription_quality else [],
            metrics=result.metrics,
        )

        return TranscriptionResult(transcript=result.transcript, confidence=result.confidence)

    def _decode(self, samples: np.ndarray) -> str:
        from faster_whisper.vad import VadOptions

        segments, _info = self._model.transcribe(
            samples,
            language=self._settings.language,
            beam_size=5,  # greedy: tiny gains little from a beam and pays for it in latency
            vad_filter=self._settings.vad_filter,
            vad_parameters=VadOptions(min_silence_duration_ms=self._settings.vad_min_silence_ms),
            # Without this the decoder can carry a hallucinated phrase from one
            # segment into the next and repeat it down the whole recording.
            condition_on_previous_text=False,
        )
        return " ".join(segment.text.strip() for segment in segments).strip()

    def close(self) -> None:
        self._model = None
        # Not `wait=True`: a decode that has already outlived its timeout must
        # not also hold up shutdown.
        self._executor.shutdown(wait=False, cancel_futures=True)


def _to_whisper_rate(samples: np.ndarray, sample_rate: int) -> np.ndarray:
    """Resamples to 16kHz. Linear interpolation, which is crude for audio in
    general and entirely adequate here: Whisper's own front end is a mel
    spectrogram that discards everything this would get wrong."""
    if sample_rate == WHISPER_SAMPLE_RATE or sample_rate <= 0 or samples.size == 0:
        return samples.astype(np.float32, copy=False)
    duration = samples.size / sample_rate
    target_len = max(1, int(duration * WHISPER_SAMPLE_RATE))
    source_x = np.linspace(0.0, duration, num=samples.size, endpoint=False)
    target_x = np.linspace(0.0, duration, num=target_len, endpoint=False)
    return np.interp(target_x, source_x, samples).astype(np.float32)


def derive_confidence(text: str, samples: np.ndarray, activity: VoiceActivity) -> float:
    """Whisper returns no usable per-utterance confidence, so the tool derives
    one from three observable signals and takes the pessimistic view (soul.md §5).

    Carried over from the sherpa path, with the VAD's speech ratio added — the
    signal that was missing before. An answer that is 90% silence scored the
    same as a clean one under the old two-signal version, and it is exactly the
    recording most likely to have lost words.
    """
    words = len([w for w in text.split() if w])
    if words == 0:
        return 0.0

    # Level: below about -40dBFS a recording is too quiet to trust.
    level_score = min(1.0, rms(samples) / 0.05)

    # Density: natural speech is 2-3 words/second. Far outside that means the
    # decoder produced very little for the audio, or filled silence with filler.
    seconds = max(0.5, activity.speech_ms / 1000)
    words_per_second = words / seconds
    if words_per_second < 0.5:
        density_score = words_per_second / 0.5
    elif words_per_second > 6:
        density_score = max(0.0, 1 - (words_per_second - 6) / 6)
    else:
        density_score = 1.0

    # Voicing: how much of the recording was actually speech. Ramped to full
    # marks at 40% voiced — a normal answer has pauses in it, and penalising
    # someone for thinking mid-sentence would be its own kind of wrong.
    voiced_score = min(1.0, activity.speech_ratio / 0.4)

    blended = level_score * 0.35 + density_score * 0.4 + voiced_score * 0.25
    return round(min(1.0, blended) * 100) / 100

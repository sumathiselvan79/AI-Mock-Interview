"""Deterministic speech provider for CI and for local dev before models are
downloaded — ~ mcp-servers/tool-speech-service/src/fixture-provider.ts.

It is a real audio codec, not a mock object: `synthesize` emits a genuine
16-bit PCM WAV whose length tracks the text, and `transcribe` decodes a
real WAV and derives confidence from the actual signal amplitude. The
transcript rides in a standard `LIST/INFO` comment chunk, which is why a
round trip works without an acoustic model.

What this does NOT do is recognise arbitrary speech — audio it did not
produce transcribes as a failure, loudly, rather than as a plausible guess.
"""

from __future__ import annotations

import math
import re
import struct

import numpy as np

from app.tools.speech_service.provider import (
    SynthesisResult,
    TranscriptionFailed,
    TranscriptionResult,
    decode_wav,
    encode_wav,
    rms,
)

_SAMPLE_RATE = 16_000
# Roughly natural speaking pace, so durations are believable in the UI.
_WORDS_PER_MINUTE = 150
_MIN_DURATION_MS = 400

# Amplitude the fixture writes for clean audio. A caller can scale a clip
# down to simulate a bad microphone, which is exactly how the
# low-confidence path gets exercised.
_CLEAN_AMPLITUDE = 0.35

# RMS of a clean clip, which is what `transcribe` compares an incoming clip
# against. It is NOT `_CLEAN_AMPLITUDE`: that is a peak, and the fixture
# writes a carrier sine under a half-period sine envelope, each of which
# contributes a 1/sqrt(2) factor — so a clean clip's RMS is half its peak.
_CLEAN_RMS = _CLEAN_AMPLITUDE * 0.5

_INFO_CHUNK_ID = b"LIST"
_COMMENT_TAG = b"ICMT"


class FixtureSpeechProvider:
    name = "fixture"

    async def synthesize(self, text: str, voice: str | None = None) -> SynthesisResult:
        words = len([w for w in text.split() if w])
        duration_ms = max(_MIN_DURATION_MS, round((words / _WORDS_PER_MINUTE) * 60_000))
        sample_count = round((duration_ms / 1000) * _SAMPLE_RATE)

        # A quiet tone rather than digital silence, so amplitude-based
        # confidence behaves the way it would on real speech.
        i = np.arange(sample_count)
        envelope = np.sin((np.pi * i) / max(sample_count, 1))
        carrier = np.sin((2 * np.pi * 140 * i) / _SAMPLE_RATE)
        samples = np.round(carrier * envelope * _CLEAN_AMPLITUDE * 32767).astype(np.int16)

        return SynthesisResult(audio=_with_transcript(encode_wav(samples, _SAMPLE_RATE), text), duration_ms=duration_ms, sample_rate=_SAMPLE_RATE)

    async def transcribe(self, audio: bytes, **kwargs: Any) -> TranscriptionResult:
        decoded = decode_wav(audio)
        transcript = read_transcript(audio)

        if transcript is None:
            # Honest failure: this provider cannot recognise speech it did
            # not synthesise, and guessing would be fabrication (soul.md §6).
            raise TranscriptionFailed(
                "the fixture speech provider cannot transcribe external audio — provide sherpa-onnx models "
                "(SPEECH_MODEL_DIR) to transcribe real recordings"
            )

        # Confidence from signal level: quiet or clipped audio is the
        # real-world reason a transcript should not be trusted.
        level = rms(decoded.samples)
        confidence = max(0.0, min(1.0, round((level / _CLEAN_RMS) * 100) / 100))

        return TranscriptionResult(transcript=transcript, confidence=confidence)

    def close(self) -> None:
        pass


def _with_transcript(wav: bytes, text: str) -> bytes:
    """Appends a LIST/INFO chunk carrying the transcript, before the data chunk."""
    comment = text.encode("utf-8") + b"\x00"
    padded = comment if len(comment) % 2 == 0 else comment + b"\x00"

    list_payload = b"INFO" + _COMMENT_TAG + struct.pack("<I", len(padded)) + padded
    list_chunk = _INFO_CHUNK_ID + struct.pack("<I", len(list_payload)) + list_payload

    # Splice the chunk in after "WAVE" and before the fmt chunk, then fix RIFF size.
    head, tail = wav[:12], wav[12:]
    out = bytearray(head + list_chunk + tail)
    struct.pack_into("<I", out, 4, len(out) - 8)
    return bytes(out)


def read_transcript(wav: bytes) -> str | None:
    offset = 12
    while offset + 8 <= len(wav):
        chunk_id = wav[offset : offset + 4]
        size = struct.unpack_from("<I", wav, offset + 4)[0]
        if chunk_id == _INFO_CHUNK_ID:
            payload = wav[offset + 8 : offset + 8 + size]
            tag_index = payload.find(_COMMENT_TAG, 4)
            if tag_index >= 0:
                length = struct.unpack_from("<I", payload, tag_index + 4)[0]
                raw = payload[tag_index + 8 : tag_index + 8 + length]
                return re.sub(r"\x00+$", "", raw.decode("utf-8"))
        offset += 8 + size + (size % 2)
    return None


def attenuate(wav: bytes, factor: float) -> bytes:
    """Scales a clip's amplitude. Used by tests to reproduce the "bad
    microphone" case that must trigger the typed-text fallback."""
    out = bytearray(wav)
    offset = 12
    while offset + 8 <= len(out):
        chunk_id = bytes(out[offset : offset + 4])
        size = struct.unpack_from("<I", out, offset + 4)[0]
        if chunk_id == b"data":
            start = offset + 8
            end = min(start + size, len(out))
            for i in range(start, end - 1, 2):
                value = struct.unpack_from("<h", out, i)[0]
                scaled = max(-32768, min(32767, round(value * factor)))
                struct.pack_into("<h", out, i, scaled)
            break
        offset += 8 + size + (size % 2)
    return bytes(out)

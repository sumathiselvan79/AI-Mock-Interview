"""Clipboard Monitor — ~ mcp-servers/tool-clipboard-monitor/src/index.ts. INSTRUCTIONS.md §5.5, soul.md §5.

Two hard requirements, both enforced here rather than upstream:

 1. **`start_monitor` rejects a call without a valid `consent_token`.** Not a
    warning, not a default-off flag someone can flip — the tool refuses.
 2. **Only a boolean and a timestamp are ever recorded.** The pasted
    content is not stored, not logged, and not accepted as a parameter —
    there is no field on `paste_event_detected` that could carry it.

The monitor itself is a browser-side listener: the frontend reports that a
paste happened, and this server decides whether that report is allowed to
be recorded at all.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Awaitable, Callable, Optional

from app.shared_types import McpCallContext, McpHandlerError

SERVER_NAME = "tool-clipboard-monitor"
METHODS = ("start_monitor", "stop_monitor", "paste_event_detected")


class ClipboardMonitorState:
    def __init__(self) -> None:
        self._active: set[str] = set()

    def start(self, session_id: str) -> None:
        self._active.add(session_id)

    def stop(self, session_id: str) -> None:
        self._active.discard(session_id)

    def is_active(self, session_id: str) -> bool:
        return session_id in self._active


@dataclass
class ClipboardMonitorDeps:
    verify_consent: Callable[[str, Optional[str]], Any]  # -> ConsentVerdict
    record_paste: Callable[[dict[str, Any]], Awaitable[None]]


class ToolClipboardMonitorServer:
    name = SERVER_NAME

    def __init__(self, deps: ClipboardMonitorDeps, state: Optional[ClipboardMonitorState] = None) -> None:
        self._deps = deps
        self._state = state or ClipboardMonitorState()

    async def call(self, method: str, params: Any, ctx: McpCallContext) -> Any:
        p = params or {}
        session_id = p["session_id"]

        if method == "start_monitor":
            verdict = self._deps.verify_consent(session_id, p.get("consent_token"))
            if not verdict.ok:
                # The reason is named so an operator can tell a missing
                # token from a forged one, without the rejection ever being negotiable.
                raise McpHandlerError(
                    "consent_missing" if verdict.reason == "missing" else "consent_invalid",
                    f"clipboard monitoring refused: consent token {verdict.reason} for session {session_id}",
                )
            self._state.start(session_id)
            return {"monitoring": True, "started_at": datetime.now(timezone.utc).isoformat()}

        if method == "stop_monitor":
            self._state.stop(session_id)
            return {"monitoring": False}

        if method == "paste_event_detected":
            # Monitoring that was never consented to cannot record anything,
            # even if the frontend reports an event.
            if not self._state.is_active(session_id):
                raise McpHandlerError("consent_missing", f"no active consented monitor for session {session_id}; the event was discarded")
            await self._deps.record_paste({"session_id": session_id, "detected": True, "timestamp": p.get("timestamp") or datetime.now(timezone.utc).isoformat()})
            return {"recorded": True}

        raise McpHandlerError("unknown_method", f"{SERVER_NAME} has no method {method}")


def create_tool_clipboard_monitor_server(deps: ClipboardMonitorDeps, state: Optional[ClipboardMonitorState] = None) -> ToolClipboardMonitorServer:
    return ToolClipboardMonitorServer(deps, state)

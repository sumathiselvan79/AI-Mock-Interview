"""Focus Monitor — fullscreen-exit tracking during the active interview.

~ mcp-servers/tool-focus-monitor/src/index.ts. INSTRUCTIONS.md §5.5-adjacent,
soul.md §5 "Consent-first monitoring". Same two hard requirements as the
Clipboard Monitor: `start_monitor` refuses without a valid consent token,
and only a timestamp is ever recorded.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Awaitable, Callable, Optional

from app.shared_types import McpCallContext, McpHandlerError

SERVER_NAME = "tool-focus-monitor"
METHODS = ("start_monitor", "stop_monitor", "focus_event_detected")


class FocusMonitorState:
    def __init__(self) -> None:
        self._active: set[str] = set()

    def start(self, session_id: str) -> None:
        self._active.add(session_id)

    def stop(self, session_id: str) -> None:
        self._active.discard(session_id)

    def is_active(self, session_id: str) -> bool:
        return session_id in self._active


@dataclass
class FocusMonitorDeps:
    verify_consent: Callable[[str, Optional[str]], Any]  # -> ConsentVerdict
    record_focus_loss: Callable[[dict[str, Any]], Awaitable[dict[str, int]]]


class ToolFocusMonitorServer:
    name = SERVER_NAME

    def __init__(self, deps: FocusMonitorDeps, state: Optional[FocusMonitorState] = None) -> None:
        self._deps = deps
        self._state = state or FocusMonitorState()

    async def call(self, method: str, params: Any, ctx: McpCallContext) -> Any:
        p = params or {}
        session_id = p["session_id"]

        if method == "start_monitor":
            verdict = self._deps.verify_consent(session_id, p.get("consent_token"))
            if not verdict.ok:
                raise McpHandlerError(
                    "consent_missing" if verdict.reason == "missing" else "consent_invalid",
                    f"focus monitoring refused: consent token {verdict.reason} for session {session_id}",
                )
            self._state.start(session_id)
            return {"monitoring": True, "started_at": datetime.now(timezone.utc).isoformat()}

        if method == "stop_monitor":
            self._state.stop(session_id)
            return {"monitoring": False}

        if method == "focus_event_detected":
            if not self._state.is_active(session_id):
                raise McpHandlerError("consent_missing", f"no active consented monitor for session {session_id}; the event was discarded")
            result = await self._deps.record_focus_loss({"session_id": session_id, "detected": True, "timestamp": p.get("timestamp") or datetime.now(timezone.utc).isoformat()})
            return {"recorded": True, "exit_count": result["exit_count"]}

        raise McpHandlerError("unknown_method", f"{SERVER_NAME} has no method {method}")


def create_tool_focus_monitor_server(deps: FocusMonitorDeps, state: Optional[FocusMonitorState] = None) -> ToolFocusMonitorServer:
    return ToolFocusMonitorServer(deps, state)

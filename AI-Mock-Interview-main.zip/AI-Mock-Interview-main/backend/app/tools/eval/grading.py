"""Grade bands — the one place a 0-5 rubric score becomes a letter grade.

This lives in the Eval Tool for exactly the reason the rubrics do (CLAUDE.md
§8): a grade is an interpretation of a rubric score, and an interpretation
that two services each own is an interpretation that will eventually
disagree with itself. The Question Agent, the Report Agent, the live channel
and the Admin dashboard all read a band from here or they do not report one
at all.

Three rules come straight from `soul.md` and are load-bearing, not stylistic:

 - **No score, no grade.** `grade_for(None)` is `None`, never the bottom
   band. A candidate who was never scored has not failed — the same rule
   `formatScore` enforces on the frontend (`—`, never `0`).
 - **The bottom band is not a punishment.** Every band's `descriptor` says
   what the *next* band would need, because soul.md §4 asks even a weak
   performance to be framed constructively. There is no "F", and no band is
   named after the candidate rather than the answer.
 - **A grade is derived, never asserted.** `aggregate` only ever averages
   scores that were themselves evidenced; it has no path to invent one, and
   it refuses (returns `None`) rather than grading an empty set.

The scale is versioned like a rubric is. A stored grade means nothing later
unless the version that produced it still identifies the same thresholds, so
bumping a boundary means bumping `GRADE_SCALE_VERSION`, not editing a number
in place.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Sequence

GRADE_SCALE_VERSION = "grade-scale/v1"

# (Dynamic evaluation addition) Versioned the same way the grade scale is:
# a stored `role_fit_grade` means nothing later unless the version that
# produced it still identifies the same weights.
ROLE_FIT_WEIGHT_VERSION = "role-fit-weight/v1"

# How much a topic counts toward `role_fit_grade`, by why it was on the plan
# at all (`shared_types.session.TopicSource`). This is a DIFFERENT axis from
# the question-count weighting `aggregate()` deliberately avoids below: it
# never touches how many questions were asked on a topic, only how much a
# topic that the job description actually called out should count once it
# was asked about. `introduction` is excluded — it was never a scored
# competency, so it never reaches `weighted_aggregate` in the first place.
TOPIC_SOURCE_WEIGHT: dict[str, float] = {
    "jd_gap": 1.5,
    "role_requirement": 1.25,
    "resume": 1.0,
}


@dataclass(frozen=True)
class GradeBand:
    letter: str
    label: str
    # Inclusive lower bound on the 0-5 rubric scale.
    min_score: float
    # What this band means, and what the next one up would take. Shown to the
    # candidate verbatim, so it is written in the report voice (soul.md §4).
    descriptor: str


# Ordered high to low; `band_for` takes the first band the score clears.
GRADE_BANDS: tuple[GradeBand, ...] = (
    GradeBand(
        letter="A",
        label="Excellent",
        min_score=4.3,
        descriptor="Consistently specific: a real situation, your own actions, how it turned out, and why you chose it that way.",
    ),
    GradeBand(
        letter="B",
        label="Strong",
        min_score=3.5,
        descriptor="Well evidenced overall. The step up is reasoning — say what the alternative was and why you ruled it out.",
    ),
    GradeBand(
        letter="C",
        label="Competent",
        min_score=2.5,
        descriptor="The substance is there but stays general. Anchoring each point in one concrete instance would lift this.",
    ),
    GradeBand(
        letter="D",
        label="Developing",
        min_score=1.5,
        descriptor="Parts of the answer landed. Naming what you personally did, and what changed afterwards, is the biggest single gain here.",
    ),
    GradeBand(
        letter="E",
        label="Early",
        min_score=0.0,
        descriptor="Not much of this was evidenced yet. Start from one specific occasion and walk through it end to end.",
    ),
)

# A band at or above this is reported as a strength rather than a focus area.
# "Strength" means "graded B or better", defined once, here.
STRENGTH_LETTERS = frozenset({"A", "B"})

# The same boundary as a raw 0-5 number, derived from the bands rather than
# written out again. For callers holding a bare score with no grade attached —
# a report persisted before grading existed, most of all. Callers that DO have
# a grade should read its `is_strength` flag instead of re-comparing here.
STRENGTH_THRESHOLD = min(b.min_score for b in GRADE_BANDS if b.letter in STRENGTH_LETTERS)


def band_for(score: float) -> GradeBand:
    for band in GRADE_BANDS:
        if score >= band.min_score:
            return band
    return GRADE_BANDS[-1]


def grade_for(score: Optional[float]) -> Optional[dict[str, object]]:
    """The wire form of one score's grade, or `None` for an unscored subject.

    Returning `None` rather than the bottom band is the whole point: an
    absent grade and a low grade are different findings, and collapsing them
    would report a judgement the system never made (soul.md §"No fabrication").
    """
    if score is None:
        return None
    band = band_for(score)
    return {
        "letter": band.letter,
        "label": band.label,
        "score": round(score * 10) / 10,
        "descriptor": band.descriptor,
        # Carried on the grade itself so no caller has to re-derive "is this
        # good?" from the letter. The Report Agent partitions strengths from
        # focus areas on this flag and holds no copy of the boundary.
        "is_strength": band.letter in STRENGTH_LETTERS,
        "scale_version": GRADE_SCALE_VERSION,
    }


def weighted_aggregate(scored: Sequence[tuple[float, float]]) -> Optional[dict[str, object]]:
    """The JD/role-aware sibling of `aggregate()`: a weighted mean instead of
    a plain one, banded the same way.

    Each item is `(score, weight)` — one already-evidenced competency score
    and how much this role's job description/requirements say that topic
    should count (`TOPIC_SOURCE_WEIGHT`). This does not reintroduce the
    problem `aggregate()`'s docstring warns about: it never weights by how
    many questions were asked, only by how critical the topic already was
    known to be before any of them were asked. `aggregate()` itself is
    untouched and remains what `overall_grade` means everywhere it already
    means that today.

    Returns `None` on an empty or all-zero-weight input, for the same reason
    `aggregate()` does: nothing scoreable happened, so there is nothing to
    band — never a fabricated bottom grade.
    """
    pairs = [(s, w) for s, w in scored if s is not None and w is not None]
    total_weight = sum(w for _, w in pairs)
    if not pairs or total_weight <= 0:
        return None
    weighted_sum = sum(s * w for s, w in pairs)
    return grade_for(weighted_sum / total_weight)


def aggregate(scores: Sequence[float]) -> Optional[dict[str, object]]:
    """The session-level grade: the unweighted mean of every topic that was
    actually scored, banded.

    Unweighted on purpose. Weighting by question count would let a topic with
    three questions outvote one with a single strong answer, which turns a
    quota decision made at CALIBRATION into a scoring decision made
    afterwards — the candidate never chose either.

    Topics that could not be scored are simply not in `scores`; they are
    reported as focus areas by name instead of being folded in as zeros.
    """
    values = [s for s in scores if s is not None]
    if not values:
        return None
    return grade_for(sum(values) / len(values))


def grade_scale() -> list[dict[str, object]]:
    """The published scale, so a caller can render the whole ladder (a legend,
    an admin key) without hardcoding a second copy of the thresholds."""
    return [
        {"letter": b.letter, "label": b.label, "min_score": b.min_score, "descriptor": b.descriptor}
        for b in GRADE_BANDS
    ]

"""Versioned scoring rubrics — ~ mcp-servers/tool-eval/src/rubrics.ts.

These live in the Eval Tool and nowhere else, so the Question Agent, Coding
Agent and Report Agent all score the same way (CLAUDE.md §8). A rubric is a
set of *signals*; a signal only counts when it can point at the span of
transcript that produced it, which is what makes `evidence_spans` real
rather than decorative (soul.md §"No fabrication").

Fairness constraints baked into the signal set (soul.md §3, §5):
 - no signal rewards vocabulary, fluency, accent, or phrasing;
 - every signal is about the substance of what was described;
 - communication style is never blended into a technical or behavioural score.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Literal, Optional

AppliesTo = Literal["behavioral", "technical", "coding"]


@dataclass(frozen=True)
class RubricSignal:
    id: str
    label: str
    patterns: tuple[re.Pattern[str], ...]
    weight: float
    # (Dynamic evaluation addition) When true, `score_against_rubric` builds
    # this signal's pattern set from the QUESTION's OWN topic vocabulary
    # (`interview_domain.topics`) instead of using `patterns` verbatim.
    # `patterns` still supplies the fallback when no topic is known, so the
    # signal is never silently empty.
    topic_terms: bool = False


@dataclass(frozen=True)
class Rubric:
    id: str
    version: int
    applies_to: AppliesTo
    min_words: int
    signals: tuple[RubricSignal, ...]


def _p(pattern: str) -> re.Pattern[str]:
    return re.compile(pattern, re.IGNORECASE)


# "What did *you* actually do": first person followed by a past-tense verb.
# `\w+ed` carries the regular cases so the signal is not hostage to a
# hand-written verb list.
ACTION_VERBS = _p(
    r"\b(?:i|we)\s+(?:\w+ed|built|wrote|led|ran|chose|took|made|set|got|found|split|rewrote|sent|"
    r"brought|kept|drove|shipped|spent|went|began|broke|caught|dealt|held|left|lost|met|paid|put|"
    r"read|sold|taught|told|thought|understood|won|dug|rebuilt|undid)\b"
)

OUTCOME = _p(
    r"\b(as a result|which (?:meant|led|resulted)|the (?:result|outcome|impact) was|ended up|"
    r"after (?:that|which)|since then|we went from|dropped (?:from|to)|went from|reduced|increased|"
    r"improved|cut|saved|eliminated)\b"
)

METRIC = _p(
    r"\b\d+(?:\.\d+)?\s?(?:%|percent|x|ms|s\b|seconds|minutes|hours|days|weeks|months|k\b|m\b|users|"
    r"requests|rps|qps|gb|tb|dollars|\$)"
)

SITUATION = _p(
    r"\b(at (?:my|the) (?:last|previous|current)|when i (?:was|joined)|the (?:context|situation|problem) was|"
    r"we had a|our team (?:was|had)|on a project|last (?:year|quarter|month)|in \d{4})\b"
)

TRADEOFF = _p(
    r"\b(tradeoff|trade-off|the (?:downside|drawback|cost) (?:was|is)|on the other hand|instead of|"
    r"rather than|we (?:chose|picked|decided) .{0,40}\bbecause\b|the alternative|we considered|"
    r"we ruled out|at the expense of)\b"
)

REASONING = _p(
    r"\b(because|the reason|so that|which meant|in order to|this let us|the risk was|we assumed|"
    r"it depends on|first .{0,60}then)\b"
)

SPECIFIC_TECH = _p(
    r"\b(postgres|mysql|redis|kafka|rabbitmq|kubernetes|docker|terraform|aws|gcp|azure|react|"
    r"typescript|python|java|go\b|rust|node|grpc|graphql|s3|dynamodb|spark|airflow|prometheus|"
    r"grafana|datadog|nginx|elasticsearch)\b"
)

SELF_CORRECTION = _p(
    r"\b(what i'd do differently|in hindsight|looking back|i got that wrong|i was wrong|"
    r"the mistake (?:i|we) made|i should have|next time i)\b"
)

BIG_O = re.compile(r"O\(.{1,10}\)")

EDGE_CASES = _p(r"\b(edge case|empty|null|overflow|off by one|boundary|invalid input|what if)\b")

RUBRICS: tuple[Rubric, ...] = (
    Rubric(
        id="behavioral_v1",
        version=1,
        applies_to="behavioral",
        min_words=25,
        signals=(
            RubricSignal("situation", "sets out a specific situation rather than a general habit", (SITUATION,), 1),
            RubricSignal("actions", "describes what they personally did", (ACTION_VERBS,), 1.5),
            RubricSignal("outcome", "states how it turned out", (OUTCOME,), 1),
            RubricSignal("specifics", "grounds the answer in concrete numbers or named systems", (METRIC, SPECIFIC_TECH), 0.75),
            RubricSignal("reflection", "reflects on the decision or what they'd change", (SELF_CORRECTION, TRADEOFF), 0.75),
        ),
    ),
    Rubric(
        id="technical_v1",
        version=1,
        applies_to="technical",
        min_words=25,
        signals=(
            RubricSignal("reasoning", "explains why, not just what", (REASONING,), 1.5),
            RubricSignal("tradeoffs", "weighs at least one alternative", (TRADEOFF,), 1.5),
            RubricSignal("specifics", "names concrete systems, numbers, or mechanisms", (SPECIFIC_TECH, METRIC), 1),
            RubricSignal("experience", "draws on something they actually did", (ACTION_VERBS, SITUATION), 1),
        ),
    ),
    Rubric(
        id="technical_v2",
        version=1,
        applies_to="technical",
        min_words=25,
        # Same signals and weights as technical_v1 — only "specifics" changes,
        # from a hardcoded software vocabulary to the question's own topic
        # vocabulary (`interview_domain/topics.py`), looked up dynamically in
        # `score_against_rubric`. technical_v1 is left untouched and still
        # resolvable, the same discipline this codebase uses for prompt
        # versions: never edit a shipped rubric's behavior in place.
        signals=(
            RubricSignal("reasoning", "explains why, not just what", (REASONING,), 1.5),
            RubricSignal("tradeoffs", "weighs at least one alternative", (TRADEOFF,), 1.5),
            RubricSignal(
                "specifics",
                "names concrete systems, numbers, or mechanisms from this topic",
                (SPECIFIC_TECH, METRIC),
                1,
                topic_terms=True,
            ),
            RubricSignal("experience", "draws on something they actually did", (ACTION_VERBS, SITUATION), 1),
        ),
    ),
    Rubric(
        id="coding_round_v1",
        version=1,
        applies_to="coding",
        min_words=10,
        signals=(
            RubricSignal("reasoning", "explains the approach before or while coding", (REASONING,), 1.5),
            RubricSignal("tradeoffs", "considers complexity or an alternative approach", (TRADEOFF, BIG_O), 1.5),
            RubricSignal("edge_cases", "raises edge cases or failure modes", (EDGE_CASES,), 1),
        ),
    ),
)

_BY_ID = {r.id: r for r in RUBRICS}


def get_rubric(rubric_id: str) -> Optional[Rubric]:
    return _BY_ID.get(rubric_id)


def rubric_ids() -> list[str]:
    return [r.id for r in RUBRICS]

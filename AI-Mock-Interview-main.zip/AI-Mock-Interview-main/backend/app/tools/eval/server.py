"""Eval Tool — ~ mcp-servers/tool-eval/src/index.ts. INSTRUCTIONS.md §5.2.

Scores an answer against a versioned rubric and persists an `Evaluation`
record, so scores survive a dropped session and are what the Report Agent
and Admin dashboard read from later.

Two refusals are deliberate, and both come from soul.md:
 - too little to go on → `insufficient_transcript`, not a low score. A thin
   answer is not the same as a bad one, and guessing would be fabrication.
 - a low-confidence speech-to-text transcript is never scored silently
   (soul.md §5); the caller must resolve it first.

The scorer is deterministic and evidence-first: every point comes from a
span of the transcript it can point at.
"""

from __future__ import annotations

import re
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Optional

from app.shared_types import McpCallContext, McpHandlerError
from app.interview_domain.topics import get_topic, is_known_topic, term_pattern
from app.tools.eval.grading import GRADE_SCALE_VERSION, aggregate, grade_for, grade_scale, weighted_aggregate
from app.tools.eval.rubrics import METRIC, Rubric, get_rubric

SERVER_NAME = "tool-eval"
METHODS = ("evaluate_answer", "verify_concepts", "grade_scores")

# (Stage 6, §4.4) A concept counts as demonstrated when at least half its
# label's distinctive terms show up in the transcript, or the label appears
# near-verbatim.
CONCEPT_VERIFIED_THRESHOLD = 0.5

# Below this, a transcript is treated as unreliable and must not be scored.
MIN_SCOREABLE_CONFIDENCE = 0.6


@dataclass
class EvalDeps:
    evaluations: Any  # EvaluationStore


@dataclass
class Span:
    start: int
    end: int


@dataclass
class ScoreResult:
    score: float
    rationale: str
    evidence_spans: list[Span]
    matched_signals: list[str]
    missing_signals: list[str]


@dataclass
class ConceptVerificationResult:
    verified_concept_ids: list[str]
    unverified_concept_ids: list[str]


class ToolEvalServer:
    name = SERVER_NAME

    def __init__(self, deps: EvalDeps) -> None:
        self._deps = deps

    async def call(self, method: str, params: Any, ctx: McpCallContext) -> Any:
        params = params or {}
        if method == "evaluate_answer":
            return await _evaluate_answer(self._deps, params)
        if method == "verify_concepts":
            result = verify_concepts(params.get("answer_transcript", ""), params.get("concepts", []))
            return {
                "verified_concept_ids": result.verified_concept_ids,
                "unverified_concept_ids": result.unverified_concept_ids,
            }
        if method == "grade_scores":
            return _grade_scores(params)
        raise McpHandlerError("unknown_method", f"{SERVER_NAME} has no method {method}")


def _grade_scores(params: dict[str, Any]) -> dict[str, Any]:
    """Bands a set of already-evidenced scores (grading.py).

    This tool does not score anything here — it interprets numbers it is
    handed. Every one of them came from an `evaluate_answer` call that had to
    point at a transcript span first, so the grade inherits that provenance
    rather than manufacturing its own.

    (Dynamic evaluation addition) `weights` is optional and additive: when a
    caller supplies it, `role_fit_grade` is also computed and returned,
    weighted by JD/role criticality (`grading.weighted_aggregate`). When it
    is absent — every caller before this addition, and any caller that
    simply doesn't have role-fit weights to give — behavior is byte-for-byte
    unchanged and no `role_fit_grade` key appears at all.
    """
    subjects = params.get("subjects") or []
    graded = [
        {"id": s["id"], "score": s["score"], "grade": grade_for(s["score"])}
        for s in subjects
    ]
    overall = aggregate([s["score"] for s in subjects])
    result: dict[str, Any] = {"graded": graded, "scale_version": GRADE_SCALE_VERSION}
    # Absent, not a bottom band: nothing scoreable happened, and saying "E"
    # would be a verdict on a candidate who was never actually assessed.
    if overall:
        result["overall_grade"] = overall

    weights = params.get("weights")
    if weights:
        role_fit = weighted_aggregate([(s["score"], weights.get(s["id"], 1.0)) for s in subjects])
        if role_fit:
            result["role_fit_grade"] = role_fit

    if params.get("include_scale"):
        result["scale"] = grade_scale()
    return result


def verify_concepts(transcript: str, concepts: list[dict[str, str]]) -> ConceptVerificationResult:
    """Deterministic, evidence-first like every other judgement in this tool:
    a concept is "verified" only because specific words from its label
    actually appear in the transcript, never because a model said so with no
    pointer back to the text (soul.md §"No fabrication")."""
    verified: list[str] = []
    unverified: list[str] = []

    for concept in concepts:
        coverage = term_coverage(transcript, concept["label"])
        near_verbatim = concept["label"].lower() in transcript.lower()
        if coverage >= CONCEPT_VERIFIED_THRESHOLD or near_verbatim:
            verified.append(concept["id"])
        else:
            unverified.append(concept["id"])

    return ConceptVerificationResult(verified, unverified)


async def _evaluate_answer(deps: EvalDeps, params: dict[str, Any]) -> dict[str, Any]:
    rubric = get_rubric(params["rubric_id"])
    if not rubric:
        raise McpHandlerError("unknown_rubric_id", f"no rubric {params['rubric_id']} in this tool")

    confidence = params.get("transcript_confidence")
    if confidence is not None and confidence < MIN_SCOREABLE_CONFIDENCE:
        raise McpHandlerError(
            "insufficient_transcript",
            f"transcript confidence {confidence} is below {MIN_SCOREABLE_CONFIDENCE}; "
            "re-prompt or take typed text rather than scoring a guess",
        )

    transcript = params.get("answer_transcript") or ""
    word_count = len([w for w in transcript.split() if w])
    if word_count < rubric.min_words:
        raise McpHandlerError(
            "insufficient_transcript",
            f"{word_count} words is too little to score against {rubric.id} (needs {rubric.min_words})",
        )

    extra = params.get("extra") or {}
    result = score_against_rubric(
        rubric, transcript, extra.get("test_results"), params.get("reference_answer"), params.get("topic")
    )

    answer_id = params.get("answer_id")
    if answer_id:
        from app.shared_types import Evaluation, EvidenceSpan

        reference_answer = params.get("reference_answer")
        prompt_version = params.get("prompt_version")
        await deps.evaluations.append(
            Evaluation(
                id=str(uuid.uuid4()),
                answer_id=answer_id,
                rubric_id=rubric.id,
                score=result.score,
                rationale=result.rationale,
                evidence_spans=[EvidenceSpan(start=s.start, end=s.end) for s in result.evidence_spans],
                # Only stamped when a generated reference answer actually
                # informed the score — a rubric-only score is not an
                # LLM-backed one (§6).
                prompt_version=prompt_version if (reference_answer and prompt_version) else None,
                created_at=datetime.now(timezone.utc).isoformat(),
            )
        )

    return {
        "score": result.score,
        "rationale": result.rationale,
        "evidence_spans": [{"start": s.start, "end": s.end} for s in result.evidence_spans],
        # The band for this one answer, banded here rather than by whoever
        # displays it — see grading.py's header. Never null on this path: a
        # score exists by the time we get here, or we raised instead.
        "grade": grade_for(result.score),
    }


def score_against_rubric(
    rubric: Rubric,
    transcript: str,
    test_results: Optional[list[dict[str, Any]]] = None,
    reference_answer: Optional[str] = None,
    topic: Optional[str] = None,
) -> ScoreResult:
    """Scores 0-5. Each rubric signal contributes its weight only when it
    matches the transcript, and each match contributes the span that
    produced it — so a score can always be traced back to specific words the
    candidate said."""
    spans: list[Span] = []
    matched: list[str] = []
    missing: list[str] = []
    earned = 0.0
    total = sum(s.weight for s in rubric.signals)

    for signal in rubric.signals:
        # (Dynamic evaluation addition) A `topic_terms` signal is scored
        # against the QUESTION's OWN topic vocabulary when one is known —
        # e.g. "digital logic design" pulls in verilog/vhdl/flip-flop/rtl
        # instead of the software-only SPECIFIC_TECH list. Falls back to the
        # signal's static patterns (which already include SPECIFIC_TECH and
        # METRIC) when no topic is supplied or the topic is unrecognized, so
        # the signal is never silently unscoreable.
        patterns = signal.patterns
        if signal.topic_terms and topic and is_known_topic(topic):
            topic_def = get_topic(topic)
            patterns = tuple(term_pattern(t) for t in topic_def.terms) + (METRIC,)
        hit = False
        for pattern in patterns:
            match = pattern.search(transcript)
            if match:
                hit = True
                spans.append(Span(match.start(), match.end()))
                break
        if hit:
            earned += signal.weight
            matched.append(signal.label)
        else:
            missing.append(signal.label)

    ratio = earned / total if total else 0.0

    # For coding, executed tests are harder evidence than anything in the
    # talk-through, so they move the score directly.
    if test_results:
        pass_rate = len([t for t in test_results if t.get("passed")]) / len(test_results)
        ratio = ratio * 0.4 + pass_rate * 0.6

    # (Stage 5, §4.4) The Question Agent's reference answer, when there is
    # one, can only ever RAISE a score — never lower it. That asymmetry is
    # the whole point (soul.md §"A reference answer is a comparison aid").
    reference_coverage: Optional[float] = None
    if reference_answer:
        reference_coverage = term_coverage(transcript, reference_answer)
        ratio = max(ratio, ratio * 0.8 + reference_coverage * 0.2)

    score = round(ratio * 5 * 10) / 10

    rationale_parts: list[str] = []
    if matched:
        rationale_parts.append(f"Present: {'; '.join(matched)}.")
    if missing:
        rationale_parts.append(f"Not evidenced: {'; '.join(missing)}.")
    if test_results:
        passed = len([t for t in test_results if t.get("passed")])
        rationale_parts.append(f"{passed} of {len(test_results)} test cases passed.")
    if reference_coverage is not None:
        rationale_parts.append(f"Covers {round(reference_coverage * 100)}% of the points a reference answer would make.")

    return ScoreResult(
        score=score,
        rationale=" ".join(rationale_parts),
        # Never empty: the schema requires at least one span, and a score
        # with no evidence must not exist.
        evidence_spans=_dedupe_spans(spans) if spans else [Span(0, min(120, len(transcript)))],
        matched_signals=matched,
        missing_signals=missing,
    )


_TERM_SPLIT_RE = re.compile(r"[^a-z0-9+#.]+")

_STOPWORDS = {
    "about", "after", "also", "answer", "because", "been", "before", "being", "both", "candidate",
    "could", "different", "does", "each", "even", "every", "from", "have", "here", "into", "just",
    "like", "made", "make", "many", "more", "most", "much", "must", "name", "names", "only", "over",
    "reference", "same", "should", "some", "strong", "such", "than", "that", "their", "them", "then",
    "there", "these", "they", "thing", "this", "those", "through", "under", "very", "well", "were",
    "what", "when", "where", "which", "while", "with", "would", "your",
}


def _terms(text: str) -> set[str]:
    return {w for w in _TERM_SPLIT_RE.split(text.lower()) if len(w) > 3 and w not in _STOPWORDS}


def term_coverage(transcript: str, reference_answer: str) -> float:
    """Fraction of the reference answer's distinctive terms that the
    transcript also uses. Stopwords are dropped so the measure tracks
    substance rather than grammar."""
    wanted = _terms(reference_answer)
    if not wanted:
        return 0.0
    said = _terms(transcript)
    hits = len(wanted & said)
    return hits / len(wanted)


def _dedupe_spans(spans: list[Span]) -> list[Span]:
    sorted_spans = sorted(spans, key=lambda s: s.start)
    out: list[Span] = []
    for span in sorted_spans:
        if out and span.start <= out[-1].end:
            out[-1].end = max(out[-1].end, span.end)
        else:
            out.append(Span(span.start, span.end))
    return out


def create_tool_eval_server(deps: EvalDeps) -> ToolEvalServer:
    return ToolEvalServer(deps)

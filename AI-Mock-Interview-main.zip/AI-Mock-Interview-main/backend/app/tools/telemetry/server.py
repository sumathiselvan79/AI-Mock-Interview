"""ToolTelemetry — INSTRUCTIONS.md §5.4.
~ mcp-servers/tool-telemetry/src/index.ts.

Fire-and-forget event sink. Payloads carry IDs and timings only. Calls no
tools directly.

Registered but deliberately unimplemented, exactly as on the TS side: every
MCP call in this system already emits a telemetry span automatically at the
gateway (CLAUDE.md §5, `mcp/gateway.py`), so nothing needs a second,
hand-rolled emit path — and CLAUDE.md §8 says not to add one. The server is
registered anyway so the harness's routing table and the schema registry are
complete, and so the day an agent genuinely needs to emit its own event there
is a named place for it rather than a new direct write to the sink.
"""

from __future__ import annotations

from typing import Any

from app.shared_types import McpCallContext, McpHandlerError

SERVER_NAME = "tool-telemetry"
IMPLEMENTED_IN_STAGE = 1
METHODS = ("emit_event",)


class ToolTelemetryServer:
    name = SERVER_NAME

    async def call(self, method: str, params: Any, ctx: McpCallContext) -> Any:
        if method not in METHODS:
            raise McpHandlerError("unknown_method", f"{SERVER_NAME} has no method {method}")
        raise McpHandlerError(
            "not_implemented", f"{SERVER_NAME}.{method} is scheduled for Stage {IMPLEMENTED_IN_STAGE}"
        )


def create_tool_telemetry_server() -> ToolTelemetryServer:
    return ToolTelemetryServer()

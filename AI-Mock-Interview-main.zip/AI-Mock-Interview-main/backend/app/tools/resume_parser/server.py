"""Resume Parser Tool — ~ mcp-servers/tool-resume-parser/src/index.ts. INSTRUCTIONS.md §5.1.

Takes a file reference, never inline bytes, so the raw resume never crosses
the MCP call log. Returns structured fields plus the normalised source lines
the Resume Service Agent quotes as evidence — it may only claim what is
literally in the document.

`delete_resume` hard-deletes and then *verifies* the bytes are gone (§8):
"it is never just unlinked or hidden."

(F10) When a `tool_client_factory` is supplied (the gateway composition root
wires the real one — see `gateway.py`), the parser tries LLM-powered
extraction first and falls back to the deterministic regex parser on any
failure — same pattern as the TS source. A provider genuinely being
unavailable and a real bug in this fallback both used to look identical (a
silent regex-only result); an exception that is not one of the recognised
"provider declined to help" outcomes now emits `resume_llm_parse_fallback`
telemetry with the exception's type, so a regression here is visible instead
of just quietly degrading forever.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

from app.shared_types import McpCallContext, McpHandlerError
from app.storage.types import Storage
from app.tools.resume_parser.extract import (
    ParseFailedError,
    UnsupportedFormatError,
    assert_readable,
    extract_text,
    to_lines,
)
from app.tools.resume_parser.parse import ParsedResume, parse_resume_text, parse_resume_text_nlp

SERVER_NAME = "tool-resume-parser"
METHODS = ("parse_resume", "delete_resume")


@dataclass
class ResumeParserDeps:
    files: Any  # FileStore
    tool_client_factory: Optional[Any] = None
    telemetry: Optional[Any] = None


class ToolResumeParserServer:
    name = SERVER_NAME

    def __init__(self, deps: ResumeParserDeps) -> None:
        self._deps = deps

    async def call(self, method: str, params: Any, ctx: McpCallContext) -> Any:
        if method == "parse_resume":
            return await self._parse_resume(params or {})
        if method == "delete_resume":
            return await self._delete_resume(params or {})
        raise McpHandlerError("unknown_method", f"{SERVER_NAME} has no method {method}")

    async def _parse_resume(self, params: dict[str, Any]) -> dict[str, Any]:
        stored = await self._deps.files.get(params["file_ref"])
        if not stored:
            raise McpHandlerError("parse_failed", f"no stored file for ref {params['file_ref']}")
        meta, data = stored

        try:
            text = await extract_text(data, meta.filename, meta.content_type)
            assert_readable(text)
        except (UnsupportedFormatError, ParseFailedError) as err:
            raise McpHandlerError(err.code, str(err)) from err

        lines = to_lines(text)

        session_id = params.get("session_id")
        if self._deps.tool_client_factory and session_id:
            parsed = await _parse_with_llm_fallback(
                self._deps.tool_client_factory(session_id, SERVER_NAME),
                lines,
                telemetry=self._deps.telemetry,
                session_id=session_id,
            )
        else:
            # Try the upgraded NLP parser first (spaCy NER + 350+ skill
            # database). Falls back to the deterministic regex parser
            # internally if spaCy is unavailable.
            parsed = parse_resume_text_nlp(lines)

        return _wire(parsed)

    async def _delete_resume(self, params: dict[str, Any]) -> dict[str, Any]:
        deleted = await self._deps.files.delete(params["file_ref"])
        # Read the backing store again rather than trusting the delete's return value.
        verified_absent = not await self._deps.files.exists(params["file_ref"])
        return {"deleted": deleted, "verified_absent": verified_absent}


def _wire(parsed: ParsedResume) -> dict[str, Any]:
    return {
        "skills": parsed.skills,
        # (highlights fix) `highlights` is populated only by the LLM path and
        # is `[]` from the deterministic parser — carried through either way
        # so the Resume Service Agent (and, downstream, question generation)
        # can see named project/achievement detail when it's available.
        "experience": [
            {"title": e.title, "company": e.company, "years": e.years, "highlights": e.highlights}
            for e in parsed.experience
        ],
        "education": [{"degree": e.degree, "institution": e.institution} for e in parsed.education],
        "keywords": parsed.keywords,
        "lines": parsed.lines,
    }


async def _parse_with_llm_fallback(
    tools: Any, lines: list[str], *, telemetry: Optional[Any] = None, session_id: Optional[str] = None
) -> ParsedResume:
    """Tries LLM-powered structured extraction (F10). Two different failure
    classes are deliberately handled differently:

    - The provider call itself failing (unavailable, rate-limited, schema
      validation rejected the model's own output, timed out) is a normal,
      expected outcome — every other LLM-backed agent in this codebase
      degrades the same way, silently. No telemetry for this branch.
    - The provider succeeding but this function's own code failing to turn
      that output into a `ParsedResume` (a field name mismatch, a shape this
      code did not expect) is a bug, not a degrade — it means an assumption
      this code makes about the output no longer holds. That one is worth
      knowing about, so it emits `resume_llm_parse_fallback` telemetry before
      falling back. (This is exactly the class of bug that used to make this
      whole codepath silently no-op: see the highlights-fix history.)
    """
    from app.llm_client.tools import RESUME_PARSE_TOOL

    try:
        result = await tools.call(
            "tool-llm-provider",
            "generate_structured",
            {
                "session_id": "resume-parse",
                "tool_name": RESUME_PARSE_TOOL["name"],
                "prompt_version": RESUME_PARSE_TOOL["prompt_version"],
                "schema_ref": RESUME_PARSE_TOOL["schema_ref"],
                "input": {"resume_lines": lines},
            },
        )
    except Exception:  # noqa: BLE001 - provider_unavailable / schema_validation_failed / timeout / etc.
        return parse_resume_text_nlp(lines)

    output = result.get("output") if isinstance(result, dict) else None
    if not output:
        return parse_resume_text_nlp(lines)

    try:
        from app.tools.resume_parser.parse import EducationEntry, ExperienceEntry

        return ParsedResume(
            skills=output["skills"],
            experience=[ExperienceEntry(**e) for e in output["experience"]],
            education=[EducationEntry(**e) for e in output["education"]],
            keywords=output["keywords"],
            lines=lines,
        )
    except Exception as err:  # noqa: BLE001 - a shape mismatch here is a bug, not a degrade
        if telemetry is not None:
            try:
                await telemetry.emit(
                    "resume_llm_parse_fallback",
                    session_id,
                    {"error_type": type(err).__name__, "error": str(err)},
                )
            except Exception:  # noqa: BLE001 - telemetry itself must never be the reason parsing fails
                pass
        return parse_resume_text_nlp(lines)


def create_tool_resume_parser_server(deps: ResumeParserDeps) -> ToolResumeParserServer:
    return ToolResumeParserServer(deps)

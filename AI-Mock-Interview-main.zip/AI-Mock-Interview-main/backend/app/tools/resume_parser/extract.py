"""Text extraction per format — ~ mcp-servers/tool-resume-parser/src/extract.ts.

Kept separate from parsing so an unreadable file fails as `unsupported_format`
/ `parse_failed` rather than silently producing an empty profile —
INSTRUCTIONS.md §5.1: "agent must surface these plainly, never guess at content."

Deviation from the TS source, recorded per FASTAPI_MIGRATION.md convention:
the TS side reconstructs PDF layout itself (`pdf-layout.ts`, column-aware
positional text reconstruction). This port uses `pypdf`'s standard text
extraction instead — plain, well-maintained, and sufficient for the
line-based regex matching every downstream rule in `parse.py` does. Revisit
only if PDF extraction quality turns out to matter for a specific resume
layout `pypdf` handles poorly.
"""

from __future__ import annotations

import io
import re

SupportedFormat = str  # "txt" | "md" | "pdf" | "docx"


class UnsupportedFormatError(Exception):
    code = "unsupported_format"


class ParseFailedError(Exception):
    code = "parse_failed"


_EXTENSION_FORMATS = {
    "txt": "txt",
    "text": "txt",
    "md": "md",
    "markdown": "md",
    "pdf": "pdf",
    "docx": "docx",
}

_CONTENT_TYPE_FORMATS = {
    "text/plain": "txt",
    "text/markdown": "md",
    "application/pdf": "pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "docx",
}


def detect_format(filename: str, content_type: str) -> SupportedFormat:
    extension = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    by_extension = _EXTENSION_FORMATS.get(extension)
    if by_extension:
        return by_extension

    by_content_type = _CONTENT_TYPE_FORMATS.get(content_type.split(";")[0].strip().lower())
    if by_content_type:
        return by_content_type

    raise UnsupportedFormatError(
        f"unsupported resume format: {filename or content_type or 'unknown'}; accepted: pdf, docx, txt, md"
    )


def assert_not_legacy_doc(filename: str) -> None:
    """`.doc` is a common upload and is *not* supported — say so specifically."""
    if filename.lower().endswith(".doc"):
        raise UnsupportedFormatError("legacy .doc files are not supported; export as .docx or .pdf")


async def extract_text(data: bytes, filename: str, content_type: str) -> str:
    assert_not_legacy_doc(filename)
    fmt = detect_format(filename, content_type)

    try:
        if fmt in ("txt", "md"):
            return data.decode("utf-8")
        if fmt == "docx":
            import docx

            document = docx.Document(io.BytesIO(data))
            return "\n".join(p.text for p in document.paragraphs)
        if fmt == "pdf":
            from pypdf import PdfReader

            reader = PdfReader(io.BytesIO(data))
            raw_pdf_text = "\n".join(page.extract_text() or "" for page in reader.pages)
            # Normalize fragmented text (pypdf sometimes returns one word per
            # line). Imported lazily so a missing spacy does not block basic
            # extraction — the normalizer is pure regex, no NLP needed.
            try:
                from app.tools.resume_parser.nlp_extractor import normalize_fragmented_text
                return normalize_fragmented_text(raw_pdf_text)
            except Exception:  # noqa: BLE001
                return raw_pdf_text
        raise ParseFailedError(f"unhandled format {fmt}")
    except (UnsupportedFormatError, ParseFailedError):
        raise
    except Exception as err:  # noqa: BLE001 - any extraction failure becomes a typed error
        raise ParseFailedError(f"could not read the {fmt} file: {err}") from err


def assert_readable(text: str) -> None:
    """A scanned resume yields a file that opens fine and contains almost no
    text. That is a parse failure, not an empty candidate."""
    word_count = len([w for w in re.split(r"\s+", text) if w])
    if word_count < 20:
        raise ParseFailedError(
            f"only {word_count} words of text could be read — if this is a scanned resume, "
            "upload a text-based PDF or a .docx"
        )


_LEADING_BULLET_RE = re.compile(r"^[\s•·▪◦*\-–]+")


def to_lines(text: str) -> list[str]:
    """Normalised, non-empty lines. This is what every downstream rule matches against."""
    normalized = (
        text.replace("\r\n", "\n")
        .replace("\r", "\n")
        .replace("‘", "'")
        .replace("’", "'")
        .replace("“", '"')
        .replace("”", '"')
        .replace("–", "-")
        .replace("—", "-")
    )
    lines = []
    for raw_line in normalized.split("\n"):
        stripped = _LEADING_BULLET_RE.sub("", raw_line).strip()
        if stripped:
            lines.append(stripped)
    return lines

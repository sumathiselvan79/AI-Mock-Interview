"""Structured extraction from resume text — ~ mcp-servers/tool-resume-parser/src/parse.ts.

Every field this produces is a literal slice of the source, never a
paraphrase or an inference from a job title — the Resume Service Agent's
evidence requirement (INSTRUCTIONS.md §4.2, soul.md §"No fabrication") is
only as good as this layer's refusal to invent.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

SectionName = str  # "skills" | "experience" | "education" | "summary" | "projects" | "other"

_SECTION_HEADINGS: list[tuple[SectionName, re.Pattern[str]]] = [
    ("skills", re.compile(r"^(technical\s+)?(skills|technologies|tech\s+stack|competencies)\b", re.IGNORECASE)),
    (
        "experience",
        re.compile(r"^(work\s+|professional\s+|employment\s+)?(experience|history|positions)\b", re.IGNORECASE),
    ),
    ("education", re.compile(r"^(education|academics|qualifications)\b", re.IGNORECASE)),
    ("summary", re.compile(r"^(summary|profile|objective|about)\b", re.IGNORECASE)),
    ("projects", re.compile(r"^(projects|open\s+source|publications)\b", re.IGNORECASE)),
]

_HEADING_STRIP_RE = re.compile(r"[:•\-–]+$")


def _heading_for(line: str) -> Optional[SectionName]:
    """A heading is a short line that matches a known section name."""
    if len(line) > 40:
        return None
    stripped = _HEADING_STRIP_RE.sub("", line).strip()
    for name, pattern in _SECTION_HEADINGS:
        if pattern.search(stripped):
            return name
    return None


def split_sections(lines: list[str]) -> dict[SectionName, list[str]]:
    sections: dict[SectionName, list[str]] = {}
    current: SectionName = "other"
    for line in lines:
        heading = _heading_for(line)
        if heading:
            current = heading
            sections.setdefault(current, [])
            continue
        sections.setdefault(current, []).append(line)
    return sections


_SKILL_SPLIT_RE = re.compile(r"[,;|•·]|\s{3,}")


def _looks_like_skill_list(line: str) -> bool:
    parts = [p.strip() for p in _SKILL_SPLIT_RE.split(line) if p.strip()]
    if len(parts) < 2:
        return False
    # Skill lists are short items; prose split on commas is not.
    return all(len(p.split()) <= 4 for p in parts) and len(parts) <= 30


_SKILL_LABEL_RE = re.compile(r"^[A-Za-z /&+]{0,30}:\s*")


def extract_skills(sections: dict[SectionName, list[str]]) -> list[str]:
    skills: dict[str, None] = {}  # ordered set
    for line in sections.get("skills", []):
        without_label = _SKILL_LABEL_RE.sub("", line, count=1)
        for part in _SKILL_SPLIT_RE.split(without_label):
            skill = part.strip().rstrip(".")
            # Keep it a skill, not a sentence.
            if 2 <= len(skill) <= 40 and len(skill.split()) <= 4:
                skills[skill] = None
    return list(skills.keys())


_YEAR = r"(19|20)\d{2}"
_DATE_RANGE_RE = re.compile(rf"({_YEAR})\s*(?:-|to|–|until)\s*({_YEAR}|present|current|now)", re.IGNORECASE)


def _years_from_range(line: str) -> Optional[int]:
    match = _DATE_RANGE_RE.search(line)
    if not match:
        return None
    start = int(match.group(1))
    end_raw = match.group(3).lower()
    end = int(end_raw) if re.match(r"^\d{4}$", end_raw) else datetime.now(timezone.utc).year
    years = end - start
    return years if 0 <= years < 60 else None


_TITLE_COMPANY_RE = re.compile(
    r"^(?P<title>[A-Z][\w+/&.\- ]{2,50}?)\s*(?:,|\bat\b|@|\||-)\s*"
    r"(?P<company>[A-Z][\w+/&.,'\- ]{1,60}?)\s*(?:[|,(–-]|$)"
)


@dataclass
class ExperienceEntry:
    title: str
    company: str
    years: int
    # (highlights fix) Verbatim achievement/project bullets, populated only by
    # the LLM-powered extraction path (resume-parser/v1) — the deterministic
    # regex path below has no way to pull these out reliably, so it leaves
    # this empty rather than guessing. Optional/defaulted so every existing
    # construction site of this dataclass keeps working unchanged.
    highlights: list[str] = field(default_factory=list)
    # (highlights fix) The LLM output schema (`ResumeExperienceGeneration`)
    # also carries `start_year`/`end_year`; this dataclass previously had no
    # field for either, so `ExperienceEntry(**e)` in
    # `_parse_with_llm_fallback` raised `TypeError: unexpected keyword
    # argument 'start_year'` on every single LLM-parsed resume, which is what
    # made the whole LLM path silently no-op via the blanket exception
    # handler around it. Not otherwise used downstream today.
    start_year: Optional[int] = None
    end_year: Optional[int] = None


def extract_experience(sections: dict[SectionName, list[str]]) -> list[ExperienceEntry]:
    out: list[ExperienceEntry] = []
    seen: set[str] = set()
    lines = sections.get("experience", [])

    for i, line in enumerate(lines):
        match = _TITLE_COMPANY_RE.search(line)
        if not match:
            continue
        title = (match.group("title") or "").strip()
        company = re.sub(r"[,\-–|]+$", "", (match.group("company") or "").strip())
        if not title or not company:
            continue
        # Dates often sit on the same line or the one after it.
        next_line = lines[i + 1] if i + 1 < len(lines) else ""
        years = _years_from_range(line)
        if years is None:
            years = _years_from_range(next_line)
        if years is None:
            years = 0
        key = f"{title.lower()}@{company.lower()}"
        if key not in seen:
            seen.add(key)
            out.append(ExperienceEntry(title=title, company=company, years=years))
    return out


_DEGREE_RE = re.compile(
    r"\b(b\.?sc|b\.?s|b\.?a|b\.?tech|m\.?sc|m\.?s|m\.?tech|mba|ph\.?d|bachelor|master|doctorate|diploma)\b",
    re.IGNORECASE,
)
_EDU_SPLIT_RE = re.compile(r"\s*(?:,|\bat\b|\bfrom\b|\||-)\s*", re.IGNORECASE)
_TRAILING_YEAR_RE = re.compile(r"\s*\(?\d{4}.*$")
_LEADING_DIGIT_RE = re.compile(r"^\(?\d")
_ALPHA4_RE = re.compile(r"[A-Za-z]{4,}")


@dataclass
class EducationEntry:
    degree: str
    institution: str
    # (highlights fix) Same reasoning as ExperienceEntry.highlights above: only
    # the LLM path can populate a graduation year with any confidence, so it's
    # optional and defaulted rather than required.
    year: Optional[int] = None


def extract_education(sections: dict[SectionName, list[str]]) -> list[EducationEntry]:
    out: list[EducationEntry] = []
    lines = sections.get("education", [])

    for i, line in enumerate(lines):
        if not _DEGREE_RE.search(line):
            continue

        parts = [p.strip() for p in _EDU_SPLIT_RE.split(line) if p.strip()]
        degree = next((p for p in parts if _DEGREE_RE.search(p)), line)
        next_line = lines[i + 1] if i + 1 < len(lines) else None
        institution = next(
            (p for p in parts if p != degree and _ALPHA4_RE.search(p) and not _LEADING_DIGIT_RE.match(p)),
            next_line if next_line and not _DEGREE_RE.search(next_line) else "",
        )

        out.append(
            EducationEntry(
                degree=_TRAILING_YEAR_RE.sub("", degree).strip(),
                institution=_TRAILING_YEAR_RE.sub("", institution).strip(),
            )
        )
    return out


_STOPWORDS = {
    "the", "and", "for", "with", "from", "that", "this", "were", "was", "are", "our", "their", "its",
    "into", "over", "using", "used", "use", "across", "within", "while", "after", "before", "than",
    "then", "them", "they", "have", "has", "had", "not", "but", "all", "any", "can", "will", "would",
    "should", "could", "also", "more", "most", "other", "such", "which", "who", "whom", "how", "what",
    "when", "where", "why", "his", "her", "him", "she", "hers", "you", "your", "yours", "about",
    "team", "teams", "work", "worked", "working", "years", "year", "new", "including", "well",
}

_TOKEN_SPLIT_RE = re.compile(r"[^a-z0-9+#./-]+")
_TOKEN_TRIM_RE = re.compile(r"^[.\-/]+|[.\-/]+$")
_DIGITS_ONLY_RE = re.compile(r"^\d+$")


def extract_keywords(lines: list[str], limit: int = 40) -> list[str]:
    """Frequency-ranked content words. Used for keyword matching, never shown as a claim."""
    counts: dict[str, int] = {}
    for line in lines:
        for raw in _TOKEN_SPLIT_RE.split(line.lower()):
            token = _TOKEN_TRIM_RE.sub("", raw)
            if len(token) < 3 or len(token) > 30:
                continue
            if token in _STOPWORDS:
                continue
            if _DIGITS_ONLY_RE.match(token):
                continue
            counts[token] = counts.get(token, 0) + 1
    ranked = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return [token for token, _count in ranked[:limit]]


@dataclass
class ParsedResume:
    skills: list[str]
    experience: list[ExperienceEntry]
    education: list[EducationEntry]
    keywords: list[str]
    lines: list[str] = field(default_factory=list)


def parse_resume_text(lines: list[str]) -> ParsedResume:
    sections = split_sections(lines)

    # A resume with no recognised headings still has to parse: fall back to
    # treating the whole document as the experience section rather than
    # returning nothing.
    if "experience" not in sections and "skills" not in sections:
        sections["experience"] = lines
        sections["skills"] = [line for line in lines if _looks_like_skill_list(line)]

    return ParsedResume(
        skills=extract_skills(sections),
        experience=extract_experience(sections),
        education=extract_education(sections),
        keywords=extract_keywords(lines),
        lines=lines,
    )


def parse_resume_text_nlp(lines: list[str]) -> ParsedResume:
    """NLP-powered resume parsing using spaCy NER + enhanced rule-based extraction.

    Tries the upgraded NLP extractor first and maps the richer results into
    the standard ``ParsedResume`` format. Falls back to the deterministic
    regex parser (``parse_resume_text``) on ANY failure — spaCy not installed,
    model missing, extraction error, etc. — so the system never breaks.
    """
    try:
        from app.tools.resume_parser.nlp_extractor import (
            NlpUnavailableError,
            extract_resume_info_nlp,
        )

        full_text = "\n".join(lines)
        nlp_result = extract_resume_info_nlp(full_text)

        # Map NLP experience entries → ExperienceEntry
        experience = []
        for exp in nlp_result.experience:
            experience.append(ExperienceEntry(
                title=exp.title,
                company=exp.company,
                years=exp.years,
            ))

        # Map NLP education entries → EducationEntry
        education = []
        for edu in nlp_result.education:
            education.append(EducationEntry(
                degree=edu.degree,
                institution=edu.institution,
            ))

        # Use the NLP-extracted skills (much richer — ~350+ skill database
        # vs the regex parser's section-only approach)
        skills = nlp_result.skills

        # Keywords: use the NLP-extracted keywords (boosted by skill matching)
        keywords = nlp_result.keywords if nlp_result.keywords else extract_keywords(lines)

        return ParsedResume(
            skills=skills,
            experience=experience,
            education=education,
            keywords=keywords,
            lines=lines,
        )
    except Exception:  # noqa: BLE001 — any failure → silent fallback
        return parse_resume_text(lines)


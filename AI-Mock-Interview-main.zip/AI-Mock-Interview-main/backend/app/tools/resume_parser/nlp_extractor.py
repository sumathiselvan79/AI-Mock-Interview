"""Upgraded NLP Resume Extractor — spaCy-powered structured extraction.

Built from the `resume parsing/core/extractor.py` module and significantly
enhanced with:
  - Smarter PDF text normalization (handles fragmented pypdf output)
  - Multi-strategy name extraction (NER + heuristics + fallback)
  - Expanded skill database (~350+ skills with better matching)
  - Richer experience parsing (internship detection, date formats, separators)
  - Robust education parsing (GPA, degree+institution splitting)
  - Project extraction with technology inference
  - Contact extraction (email, phone, LinkedIn, GitHub, portfolio)

Graceful degradation: if spaCy or its model isn't installed, every public
function raises `NlpUnavailableError` so the caller can fall back to the
deterministic regex parser. The app never breaks.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple


# ---------------------------------------------------------------------------
# Error raised when spaCy or its model isn't available
# ---------------------------------------------------------------------------

class NlpUnavailableError(Exception):
    """Raised when the NLP backend (spaCy) cannot be loaded."""


# ---------------------------------------------------------------------------
# Lazy-load spaCy model
# ---------------------------------------------------------------------------
_nlp = None
_nlp_load_attempted = False


def _get_nlp():
    global _nlp, _nlp_load_attempted
    if _nlp is not None:
        return _nlp
    if _nlp_load_attempted:
        raise NlpUnavailableError("spaCy model failed to load on a previous attempt")

    _nlp_load_attempted = True
    try:
        import spacy
    except ImportError as err:
        raise NlpUnavailableError("spacy is not installed") from err

    try:
        _nlp = spacy.load("en_core_web_sm")
    except OSError:
        try:
            from spacy.cli import download
            download("en_core_web_sm")
            _nlp = spacy.load("en_core_web_sm")
        except Exception as err:
            raise NlpUnavailableError(f"could not download en_core_web_sm: {err}") from err
    return _nlp


# ---------------------------------------------------------------------------
# Result dataclasses
# ---------------------------------------------------------------------------

@dataclass
class NlpContactDetails:
    email: Optional[str] = None
    phone: Optional[str] = None
    linkedin: Optional[str] = None
    github: Optional[str] = None
    portfolio: Optional[str] = None


@dataclass
class NlpEducation:
    institution: str = "Unknown"
    degree: str = "Unknown"
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    gpa: Optional[str] = None


@dataclass
class NlpExperience:
    company: str = "Unknown"
    title: str = "Unknown"
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    description: List[str] = field(default_factory=list)
    is_internship: bool = False
    years: int = 0


@dataclass
class NlpProject:
    name: str = ""
    description: List[str] = field(default_factory=list)
    technologies: List[str] = field(default_factory=list)
    link: Optional[str] = None


@dataclass
class NlpResumeResult:
    name: str = "Unknown"
    contact: NlpContactDetails = field(default_factory=NlpContactDetails)
    summary: Optional[str] = None
    education: List[NlpEducation] = field(default_factory=list)
    experience: List[NlpExperience] = field(default_factory=list)
    projects: List[NlpProject] = field(default_factory=list)
    skills: List[str] = field(default_factory=list)
    keywords: List[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# PDF text normalization (from resume parsing project, enhanced)
# ---------------------------------------------------------------------------

_SECTION_KEYWORDS = {
    "experience", "work experience", "professional experience",
    "employment history", "work history", "career history",
    "education", "academic background", "academic qualifications",
    "qualifications", "academic details", "educational background",
    "skills", "technical skills", "core competencies",
    "technologies", "tools & technologies", "tools and technologies",
    "tech stack", "competencies", "proficiencies", "areas of expertise",
    "projects", "personal projects", "academic projects",
    "summary", "professional summary", "objective",
    "career objective", "about me", "profile",
    "certifications", "certificates", "licenses",
    "internships", "internship experience",
    "accomplishments", "achievements", "awards",
    "courses", "publications", "interests", "hobbies",
    "references", "languages",
}


def _is_section_header_norm(text: str) -> bool:
    stripped = text.strip()
    lower = stripped.lower().rstrip(":")
    if lower in _SECTION_KEYWORDS:
        return True
    cleaned = re.sub(r"[^a-z\s]", "", lower).strip()
    if cleaned in _SECTION_KEYWORDS:
        return True
    if stripped.isupper() and 2 < len(stripped) <= 40 and len(stripped.split()) <= 5:
        clean_lower = re.sub(r"[^a-z\s]", "", stripped.lower()).strip()
        if clean_lower in _SECTION_KEYWORDS:
            return True
    return False


def normalize_fragmented_text(raw_text: str) -> str:
    """Fix fragmented PDF text where pypdf returns one word per line.

    Enhanced version: also handles mid-word line breaks and recombines
    hyphenated words split across lines.
    """
    lines = raw_text.splitlines()
    non_empty = [l for l in lines if l.strip()]

    if not non_empty:
        return raw_text

    # Detect fragmentation
    single_word_lines = sum(1 for l in non_empty if len(l.split()) <= 2)
    if single_word_lines < 40:
        # Fix hyphenated line breaks even in non-fragmented text
        result = []
        i = 0
        while i < len(lines):
            line = lines[i]
            if line.rstrip().endswith("-") and i + 1 < len(lines):
                next_line = lines[i + 1].strip()
                if next_line and next_line[0].islower():
                    result.append(line.rstrip()[:-1] + next_line)
                    i += 2
                    continue
            result.append(line)
            i += 1
        return "\n".join(result)

    # Phase 1: Join everything into section blobs
    sections: list = []
    current_header = None
    current_words: list = []

    def _flush():
        nonlocal current_header
        if current_words:
            blob = " ".join(current_words)
            blob = re.sub(r"\s{2,}", " ", blob).strip()
            sections.append((current_header, blob))
            current_words.clear()
        elif current_header:
            sections.append((current_header, ""))
        current_header = None

    for line in lines:
        stripped = line.strip()
        if not stripped:
            _flush()
            sections.append((None, ""))
            continue
        if _is_section_header_norm(stripped):
            _flush()
            current_header = stripped
            continue
        current_words.append(stripped)

    _flush()

    # Phase 2: Re-split into logical lines using date ranges
    _date_range_pat = re.compile(
        r"(?:(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?"
        r"|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)"
        r"[\s,]*\d{4}|\d{4})"
        r"\s*(?:[\-\u2013\u2014]|to)\s*"
        r"(?:(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?"
        r"|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)"
        r"[\s,]*\d{0,4}|Present|Current|Now|\d{4})",
        re.I
    )

    result_lines: list = []
    for header, blob in sections:
        if header:
            result_lines.append(header)
        if not blob:
            if header is None:
                result_lines.append("")
            continue

        date_matches = list(_date_range_pat.finditer(blob))
        if not date_matches:
            result_lines.append(blob)
            continue

        entry_lines = []
        prev_end = 0
        for i, m in enumerate(date_matches):
            if i == 0:
                continue
            region_start = date_matches[i - 1].end()
            region_end = m.start()
            region = blob[region_start:region_end]
            split_offset = None
            for sp_match in re.finditer(r"\.\s+(?=[A-Z])", region):
                split_offset = region_start + sp_match.start() + 1
            if split_offset and split_offset > prev_end + 10:
                entry = blob[prev_end:split_offset].strip()
                if entry:
                    entry_lines.append(entry)
                prev_end = split_offset

        last = blob[prev_end:].strip()
        if last:
            entry_lines.append(last)
        result_lines.extend(entry_lines)

    return "\n".join(result_lines)


# ---------------------------------------------------------------------------
# Technical Skills Database (~350+ skills, upgraded)
# ---------------------------------------------------------------------------

TECHNICAL_SKILLS: set = {
    # Programming Languages
    "python", "java", "javascript", "typescript", "c", "c++", "c#", "go",
    "golang", "rust", "ruby", "php", "swift", "kotlin", "scala", "perl",
    "r", "matlab", "dart", "lua", "haskell", "elixir", "clojure",
    "objective-c", "assembly", "fortran", "cobol", "visual basic", "vba",
    "groovy", "julia", "erlang", "f#", "ocaml", "solidity", "zig",
    "powershell", "bash", "shell",

    # Web Frontend
    "html", "html5", "css", "css3", "sass", "scss", "less", "tailwind",
    "tailwindcss", "bootstrap", "react", "reactjs", "react.js", "angular",
    "angularjs", "vue", "vuejs", "vue.js", "svelte", "next.js", "nextjs",
    "nuxt.js", "nuxtjs", "gatsby", "remix", "astro", "jquery", "webpack",
    "vite", "babel", "eslint", "prettier", "storybook", "material ui",
    "chakra ui", "ant design", "redux", "zustand", "mobx", "rxjs",
    "three.js", "d3.js", "chart.js", "highcharts", "framer motion",

    # Web Backend
    "node.js", "nodejs", "express", "express.js", "nestjs", "fastify",
    "django", "flask", "fastapi", "spring", "spring boot", "springboot",
    "rails", "ruby on rails", "laravel", "symfony", "asp.net", ".net",
    "dotnet", ".net core", "gin", "echo", "fiber", "actix", "rocket",
    "hono", "bun",

    # Mobile
    "react native", "flutter", "swiftui", "uikit", "jetpack compose",
    "android", "ios", "xamarin", "ionic", "cordova", "capacitor",
    "expo",

    # Databases
    "sql", "mysql", "postgresql", "postgres", "sqlite", "oracle",
    "sql server", "mssql", "mongodb", "dynamodb", "cassandra", "redis",
    "elasticsearch", "neo4j", "couchdb", "firebase", "firestore",
    "supabase", "cockroachdb", "mariadb", "memcached", "influxdb",
    "timescaledb", "qdrant", "pinecone", "weaviate", "chromadb",
    "milvus", "prisma", "drizzle", "sequelize", "typeorm",
    "mongoose", "sqlalchemy",

    # Cloud & DevOps
    "aws", "amazon web services", "azure", "gcp", "google cloud",
    "google cloud platform", "heroku", "vercel", "netlify", "digitalocean",
    "docker", "kubernetes", "k8s", "terraform", "ansible", "puppet",
    "chef", "vagrant", "jenkins", "github actions", "gitlab ci",
    "circleci", "travis ci", "argo cd", "helm", "istio", "envoy",
    "nginx", "apache", "caddy", "cloudflare", "aws lambda", "ec2",
    "s3", "rds", "ecs", "eks", "fargate", "cloudformation", "cdk",
    "pulumi", "fly.io", "railway",

    # Data & ML
    "pandas", "numpy", "scipy", "scikit-learn", "sklearn", "tensorflow",
    "pytorch", "keras", "xgboost", "lightgbm", "catboost", "opencv",
    "nltk", "spacy", "hugging face", "transformers", "langchain",
    "llm", "gpt", "bert", "rag", "fine-tuning", "mlflow", "kubeflow",
    "airflow", "apache spark", "spark", "hadoop", "hive", "kafka",
    "flink", "dbt", "snowflake", "databricks", "bigquery", "redshift",
    "tableau", "power bi", "looker", "metabase", "grafana",
    "machine learning", "deep learning", "neural networks",
    "natural language processing", "nlp", "computer vision",
    "reinforcement learning", "data science", "data engineering",
    "data analysis", "data visualization", "statistics",
    "feature engineering", "model deployment",
    "generative ai", "stable diffusion", "midjourney",
    "openai", "anthropic", "claude", "gemini", "llama",
    "vector database", "embedding", "prompt engineering",
    "llamaindex",

    # Testing
    "jest", "mocha", "chai", "pytest", "unittest", "junit", "testng",
    "selenium", "cypress", "playwright", "puppeteer", "postman",
    "swagger", "soapui", "locust", "jmeter", "k6", "vitest",
    "testing library", "enzyme",

    # Version Control & Collaboration
    "git", "github", "gitlab", "bitbucket", "svn", "mercurial",

    # Tools & Platforms
    "linux", "unix", "vim", "vs code", "visual studio", "intellij",
    "pycharm", "eclipse", "xcode", "android studio", "figma", "sketch",
    "adobe xd", "photoshop", "illustrator", "jira", "confluence",
    "trello", "asana", "notion", "slack", "insomnia",
    "streamlit", "gradio",

    # Concepts & Methodologies
    "rest", "rest api", "restful", "graphql", "grpc", "websocket",
    "websockets", "microservices", "monolith", "serverless",
    "event-driven", "message queue", "rabbitmq", "celery",
    "api design", "system design", "design patterns", "solid",
    "oop", "object-oriented programming", "functional programming",
    "tdd", "bdd", "ci/cd", "ci cd", "continuous integration",
    "continuous deployment", "agile", "scrum", "kanban", "devops",
    "sre", "site reliability engineering", "infrastructure as code",
    "monitoring", "logging", "observability", "prometheus",
    "datadog", "new relic", "splunk", "elk stack",
    "clean architecture", "domain-driven design", "ddd",
    "cqrs", "event sourcing",

    # Security
    "oauth", "oauth2", "jwt", "saml", "openid", "ldap",
    "encryption", "ssl", "tls", "https", "penetration testing",
    "vulnerability assessment", "owasp", "cybersecurity",
    "information security", "soc", "siem",

    # Blockchain
    "blockchain", "ethereum", "smart contracts", "web3", "web3.js",
    "ethers.js", "hardhat", "truffle", "defi", "nft",

    # Other
    "xml", "json", "yaml", "toml", "csv", "protobuf", "avro",
    "regex", "cron", "makefile", "cmake",
}

# ---------------------------------------------------------------------------
# Section header classification
# ---------------------------------------------------------------------------

SECTION_HEADERS: Dict[str, List[str]] = {
    "experience": [
        "experience", "work experience", "professional experience",
        "employment history", "work history", "career history",
        "professional background",
    ],
    "education": [
        "education", "academic background", "academic qualifications",
        "qualifications", "academic details", "educational background",
    ],
    "skills": [
        "skills", "technical skills", "core competencies",
        "technologies", "tools & technologies", "tools and technologies",
        "tech stack", "competencies", "proficiencies", "areas of expertise",
    ],
    "projects": [
        "projects", "personal projects", "academic projects",
        "side projects", "key projects", "notable projects",
    ],
    "summary": [
        "summary", "professional summary", "objective",
        "career objective", "about me", "profile", "about",
        "career summary",
    ],
    "certifications": [
        "certifications", "certificates", "licenses",
        "professional certifications",
    ],
    "internships": [
        "internships", "internship experience",
    ],
}


# ---------------------------------------------------------------------------
# Regex helpers (enhanced)
# ---------------------------------------------------------------------------

EMAIL_RE = re.compile(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}")
PHONE_RE = re.compile(
    r"(?:\+?\d{1,3}[\s\-]?)?"
    r"(?:\(?\d{2,4}\)?[\s\-]?)?"
    r"\d{3,5}[\s\-]?\d{3,5}"
)
LINKEDIN_RE = re.compile(r"(?:https?://)?(?:www\.)?linkedin\.com/in/[\w\-]+/?", re.I)
GITHUB_RE = re.compile(r"(?:https?://)?(?:www\.)?github\.com/[\w\-]+/?", re.I)
URL_RE = re.compile(r"https?://[^\s,)]+", re.I)

_MONTH_PATTERN = (
    r"(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?"
    r"|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)"
)
_DATE_COMPONENT = (
    rf"(?:{_MONTH_PATTERN}"
    r"[\s,]*\d{4}|\d{4}|\d{1,2}/\d{4})"
)
DATE_RANGE_RE = re.compile(
    rf"({_DATE_COMPONENT})"
    r"\s*[\-\u2013\u2014to]+\s*"
    rf"({_DATE_COMPONENT}|[Pp]resent|[Cc]urrent|[Nn]ow)",
    re.I,
)
GPA_RE = re.compile(
    r"(?:GPA|CGPA|C\.G\.P\.A|Grade|Percentage)[:\s]*"
    r"(\d+\.?\d*(?:\s*/\s*\d+\.?\d*)?%?)",
    re.I,
)
YEAR_RE = re.compile(r"\b((?:19|20)\d{2})\b")


# ---------------------------------------------------------------------------
# Contact extraction
# ---------------------------------------------------------------------------

def _extract_contact(text: str) -> NlpContactDetails:
    email_match = EMAIL_RE.search(text)
    phone_match = PHONE_RE.search(text)
    linkedin_match = LINKEDIN_RE.search(text)
    github_match = GITHUB_RE.search(text)

    portfolio = None
    for url_match in URL_RE.finditer(text[:2000]):
        url = url_match.group()
        if "linkedin.com" not in url and "github.com" not in url and "mailto:" not in url:
            portfolio = url
            break

    return NlpContactDetails(
        email=email_match.group() if email_match else None,
        phone=phone_match.group().strip() if phone_match else None,
        linkedin=linkedin_match.group() if linkedin_match else None,
        github=github_match.group() if github_match else None,
        portfolio=portfolio,
    )


# ---------------------------------------------------------------------------
# Name extraction — multi-strategy (upgraded)
# ---------------------------------------------------------------------------

def _extract_name(text: str, nlp) -> str:
    """Extract candidate name using multiple strategies:
    1. spaCy NER on the first few lines
    2. First non-empty line heuristic (common format)
    3. Look for lines that are title-case and short
    """
    first_lines = "\n".join(text.strip().splitlines()[:7])
    doc = nlp(first_lines)

    # Strategy 1: spaCy NER
    person_entities = []
    for ent in doc.ents:
        if ent.label_ == "PERSON":
            name = ent.text.strip()
            # Filter out common false positives
            if name.lower() not in {"resume", "cv", "curriculum vitae", "summary", "profile"}:
                person_entities.append(name)

    if person_entities:
        # Prefer the longest person name (likely the full name)
        return max(person_entities, key=len)

    # Strategy 2: First non-empty line that looks like a name
    for line in text.strip().splitlines()[:5]:
        cleaned = line.strip()
        if not cleaned:
            continue
        if EMAIL_RE.search(cleaned) or PHONE_RE.search(cleaned) or URL_RE.search(cleaned):
            continue
        # Check if it looks like a name (mostly alpha, short, title-case or all-caps)
        words = cleaned.split()
        if 1 <= len(words) <= 5:
            all_name_chars = all(
                c.isalpha() or c in (" ", ".", "-", "'") for c in cleaned
            )
            if all_name_chars:
                return cleaned
        break

    return "Unknown"


# ---------------------------------------------------------------------------
# Section segmentation (enhanced)
# ---------------------------------------------------------------------------

def _segment_sections(text: str) -> Dict[str, str]:
    lines = text.splitlines()
    sections: Dict[str, list] = {}
    current_section = "header"
    sections[current_section] = []

    keyword_to_section: Dict[str, str] = {}
    for section_name, keywords in SECTION_HEADERS.items():
        for kw in keywords:
            keyword_to_section[kw] = section_name

    for line in lines:
        stripped = line.strip()
        lower = stripped.lower().rstrip(":")

        matched_section = None
        if stripped and len(stripped.split()) <= 6:
            if lower in keyword_to_section:
                matched_section = keyword_to_section[lower]
            else:
                cleaned = re.sub(r"[^a-z\s]", "", lower).strip()
                if cleaned in keyword_to_section:
                    matched_section = keyword_to_section[cleaned]
                # Also check all-caps headers: "EXPERIENCE", "SKILLS"
                elif stripped.isupper():
                    upper_cleaned = re.sub(r"[^a-z\s]", "", stripped.lower()).strip()
                    if upper_cleaned in keyword_to_section:
                        matched_section = keyword_to_section[upper_cleaned]

        if matched_section:
            current_section = matched_section
            if current_section not in sections:
                sections[current_section] = []
        else:
            if current_section not in sections:
                sections[current_section] = []
            sections[current_section].append(line)

    return {k: "\n".join(v).strip() for k, v in sections.items() if v}


# ---------------------------------------------------------------------------
# Skills extraction (enhanced matching)
# ---------------------------------------------------------------------------

def _extract_skills(text: str) -> List[str]:
    text_lower = text.lower()
    found: List[str] = []
    for skill in sorted(TECHNICAL_SKILLS):
        if len(skill) <= 2:
            pattern = r"(?<![a-zA-Z])" + re.escape(skill) + r"(?![a-zA-Z])"
            if re.search(pattern, text_lower):
                found.append(skill.upper() if len(skill) <= 3 else skill.title())
        else:
            pattern = r"\b" + re.escape(skill) + r"\b"
            if re.search(pattern, text_lower, re.I):
                found.append(skill.title() if " " in skill or skill.islower() else skill)
    return found


# ---------------------------------------------------------------------------
# Date range helpers
# ---------------------------------------------------------------------------

def _parse_date_range(text: str) -> Tuple[Optional[str], Optional[str]]:
    match = DATE_RANGE_RE.search(text)
    if match:
        return match.group(1).strip(), match.group(2).strip()
    years = YEAR_RE.findall(text)
    if len(years) >= 2:
        return years[0], years[1]
    elif len(years) == 1:
        return years[0], None
    return None, None


def _compute_years(start: Optional[str], end: Optional[str]) -> int:
    """Estimate years of experience from a date range."""
    if not start:
        return 0
    try:
        start_year = int(re.search(r"\d{4}", start).group())
    except (AttributeError, ValueError):
        return 0

    if not end or end.lower() in ("present", "current", "now"):
        from datetime import datetime, timezone
        end_year = datetime.now(timezone.utc).year
    else:
        try:
            end_year = int(re.search(r"\d{4}", end).group())
        except (AttributeError, ValueError):
            return 0

    years = end_year - start_year
    return years if 0 <= years < 60 else 0


def _is_internship_text(text: str) -> bool:
    lower = text.lower()
    return any(kw in lower for kw in ("intern ", "intern,", "internship", "trainee"))


# ---------------------------------------------------------------------------
# Title / Company splitting (enhanced)
# ---------------------------------------------------------------------------

def _split_title_company(text: str, nlp) -> Tuple[str, str]:
    """Split heading into (title, company) using multiple strategies."""
    for separator in [" at ", " @ "]:
        if separator in text.lower():
            idx = text.lower().index(separator)
            return text[:idx].strip(), text[idx + len(separator):].strip()

    if " | " in text:
        parts = text.split(" | ", 1)
        return parts[0].strip(), parts[1].strip()

    if ", " in text:
        parts = [p.strip() for p in text.split(", ")]
        if len(parts) >= 2:
            return parts[0], parts[1]

    if " - " in text:
        parts = text.split(" - ", 1)
        if len(parts[0].split()) <= 6 and len(parts[1].split()) <= 6:
            return parts[0].strip(), parts[1].strip()

    # Fallback: use NER to find the ORG
    doc = nlp(text)
    orgs = [e.text for e in doc.ents if e.label_ == "ORG"]
    if orgs:
        company = orgs[0]
        title = text.replace(company, "").strip(" ,-|\u2013\u2014")
        return title if title else "Unknown", company

    return text.strip(), "Unknown"


# ---------------------------------------------------------------------------
# Experience parsing (enhanced)
# ---------------------------------------------------------------------------

def _extract_experience(section_text: str, nlp, is_internship_section: bool = False) -> List[NlpExperience]:
    if not section_text.strip():
        return []

    entries: List[NlpExperience] = []
    lines = section_text.splitlines()
    current_entry: dict = {}
    current_bullets: list = []

    def _flush():
        if current_entry.get("title") or current_entry.get("company"):
            start = current_entry.get("start_date")
            end = current_entry.get("end_date")
            entries.append(NlpExperience(
                company=current_entry.get("company", "Unknown"),
                title=current_entry.get("title", "Unknown"),
                start_date=start,
                end_date=end,
                description=current_bullets[:],
                is_internship=is_internship_section or current_entry.get("is_internship", False),
                years=_compute_years(start, end),
            ))

    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue

        has_date = bool(DATE_RANGE_RE.search(stripped))
        is_bullet = bool(re.match(r"^[\-\u2022\*\u25E6\u25AA\u25B8\u27A4\u27A2\u2756\u2713\u2192]\s", stripped)) or bool(re.match(r"^\d+[\.)]\s", stripped))

        is_heading = False
        if has_date and not is_bullet:
            is_heading = True
        elif not is_bullet and not has_date and len(stripped.split()) <= 12:
            has_title_keyword = bool(re.search(
                r"\b(?:engineer|developer|intern|analyst|manager|lead|architect|designer|"
                r"scientist|consultant|associate|trainee|fellow|researcher|specialist|"
                r"coordinator|administrator|director|officer|head|vp|vice president)\b",
                stripped, re.I
            ))
            if has_title_keyword and (len(current_bullets) > 0 or not current_entry):
                is_heading = True

        if is_heading:
            _flush()
            current_entry = {}
            current_bullets = []

            start, end = _parse_date_range(stripped)
            current_entry["start_date"] = start
            current_entry["end_date"] = end
            current_entry["is_internship"] = _is_internship_text(stripped)

            date_match = DATE_RANGE_RE.search(stripped)
            if date_match:
                before_date = stripped[:date_match.start()].strip()
            else:
                before_date = stripped
                before_date = YEAR_RE.sub("", before_date)

            before_date = re.sub(r"[\(\)\|,\-\u2013\u2014]+$", "", before_date).strip()
            before_date = re.sub(r"^[\(\)\|,\-\u2013\u2014]+", "", before_date).strip()
            before_date = re.sub(r"\s{2,}", " ", before_date).strip()

            if before_date:
                title, company = _split_title_company(before_date, nlp)
                current_entry["title"] = title
                current_entry["company"] = company
        else:
            cleaned = re.sub(r"^[\-\u2022\*\u25E6\u25AA\u25B8\u27A4\u27A2\u2756\u2713\u2192]\s*", "", stripped)
            cleaned = re.sub(r"^\d+[\.)]\s+", "", cleaned)
            if cleaned:
                if _is_internship_text(cleaned):
                    current_entry["is_internship"] = True
                current_bullets.append(cleaned)

    _flush()
    return entries


# ---------------------------------------------------------------------------
# Education parsing (enhanced)
# ---------------------------------------------------------------------------

def _extract_education(section_text: str, nlp) -> List[NlpEducation]:
    if not section_text.strip():
        return []

    entries: List[NlpEducation] = []
    lines = section_text.splitlines()
    current: dict = {}
    buffer_lines: list = []

    degree_keywords = [
        "bachelor", "master", "b.s.", "b.a.", "m.s.", "m.a.", "ph.d", "phd",
        "b.tech", "m.tech", "b.e.", "m.e.", "bsc", "msc", "mba", "diploma",
        "associate", "bca", "mca", "b.com", "m.com", "bba", "b.sc", "m.sc",
        "doctor", "postgraduate", "undergraduate",
    ]

    _edu_false_orgs = {"gpa", "cgpa", "c.g.p.a", "grade", "percentage"}

    def _flush():
        if current.get("institution") or current.get("degree"):
            all_text = "\n".join(buffer_lines)
            gpa_match = GPA_RE.search(all_text)
            if not current.get("gpa") and gpa_match:
                current["gpa"] = gpa_match.group(1).strip()
            entries.append(NlpEducation(
                institution=current.get("institution", "Unknown"),
                degree=current.get("degree", "Unknown"),
                start_date=current.get("start_date"),
                end_date=current.get("end_date"),
                gpa=current.get("gpa"),
            ))

    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue

        has_date = bool(DATE_RANGE_RE.search(stripped) or YEAR_RE.search(stripped))

        if has_date and (current.get("institution") or current.get("degree")):
            _flush()
            current = {}
            buffer_lines = []

        buffer_lines.append(stripped)

        line_doc = nlp(stripped)
        orgs = [
            e.text for e in line_doc.ents
            if e.label_ in ("ORG", "FAC") and e.text.lower() not in _edu_false_orgs
        ]

        if orgs and not current.get("institution"):
            current["institution"] = orgs[0]

        start, end = _parse_date_range(stripped)
        if start and not current.get("start_date"):
            current["start_date"] = start
            current["end_date"] = end

        gpa_match = GPA_RE.search(stripped)
        if gpa_match and not current.get("gpa"):
            current["gpa"] = gpa_match.group(1).strip()

        degree_str = stripped
        if current.get("institution"):
            degree_str = degree_str.replace(current["institution"], "")
        if current.get("gpa"):
            degree_str = GPA_RE.sub("", degree_str)
        degree_str = DATE_RANGE_RE.sub("", degree_str)
        degree_str = YEAR_RE.sub("", degree_str)
        degree_str = re.sub(r"\b(?:to)\b", "", degree_str, flags=re.I)
        degree_str = re.sub(r"[\(\)\|,\-\u2013\u2014]+$", "", degree_str).strip()
        degree_str = re.sub(r"^[\(\)\|,\-\u2013\u2014]+", "", degree_str).strip()
        degree_str = re.sub(r"\s{2,}", " ", degree_str).strip()

        if not degree_str and current.get("institution"):
            inst_lower = current["institution"].lower()
            for dw in degree_keywords:
                if re.search(r"\b" + re.escape(dw) + r"\b", inst_lower):
                    match = re.search(r"\b" + re.escape(dw) + r"\b", current["institution"], flags=re.I)
                    if match:
                        idx = match.start()
                        degree_str = current["institution"][idx:].strip()
                        current["institution"] = current["institution"][:idx].strip()
                    break

        lower = degree_str.lower()
        has_degree = any(dw in lower for dw in degree_keywords)

        if has_degree and not current.get("degree"):
            current["degree"] = degree_str
        elif degree_str and not current.get("degree") and not current.get("institution"):
            current["degree"] = degree_str

    _flush()
    return entries


# ---------------------------------------------------------------------------
# Project parsing (enhanced)
# ---------------------------------------------------------------------------

def _extract_projects(section_text: str, all_skills: List[str]) -> List[NlpProject]:
    if not section_text.strip():
        return []

    projects: List[NlpProject] = []
    lines = section_text.splitlines()
    current_name = None
    current_bullets: list = []
    current_link = None
    current_techs: list = []

    def _flush():
        if current_name:
            all_text = current_name + "\n" + "\n".join(current_bullets)
            matched_techs = [s for s in all_skills if re.search(
                r"\b" + re.escape(s.lower()) + r"\b", all_text.lower()
            )]
            for t in current_techs:
                if t not in matched_techs:
                    matched_techs.append(t)
            projects.append(NlpProject(
                name=current_name,
                description=current_bullets[:],
                technologies=matched_techs,
                link=current_link,
            ))

    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue

        is_bullet = bool(re.match(r"^[\-\u2022\*\u25E6\u25AA\u25B8\u27A4\u27A2\u2756\u2713\u2192]\s", stripped)) or bool(re.match(r"^\d+[\.)]\s", stripped))
        has_pipe = " | " in stripped
        has_date = bool(DATE_RANGE_RE.search(stripped))

        is_project_heading = (
            not is_bullet
            and (has_pipe or has_date
                 or (len(stripped.split()) <= 8 and len(current_bullets) > 0)
                 or (current_name is None and len(stripped.split()) <= 12))
        )

        if is_project_heading:
            _flush()
            current_bullets = []
            current_link = None
            current_techs = []

            after_date = ""
            working = stripped
            date_match = DATE_RANGE_RE.search(working)
            if date_match:
                after_date = working[date_match.end():].strip()
                working = working[:date_match.start()].strip()

            name_part = working
            if has_pipe and " | " in working:
                pipe_parts = working.split(" | ", 1)
                name_part = pipe_parts[0].strip()
                tech_part = pipe_parts[1].strip()
                tech_part = YEAR_RE.sub("", tech_part)
                tech_part = re.sub(r"\b(?:to)\b", "", tech_part, flags=re.I)
                tech_part = tech_part.strip().strip(",").strip()
                for t in re.split(r"[,;]\s*", tech_part):
                    t = t.strip().rstrip(".")
                    if t and len(t) < 40:
                        current_techs.append(t)
            else:
                name_part = YEAR_RE.sub("", name_part)
                name_part = re.sub(r"\b(?:to)\b", "", name_part, flags=re.I)
                name_part = re.sub(r"[\(\)\|,\-\u2013\u2014]+$", "", name_part).strip()

            current_name = re.sub(r"^[\-\u2022\*]\s*", "", name_part).strip()
            if not current_name:
                current_name = stripped[:60]

            url_match = URL_RE.search(stripped)
            current_link = url_match.group() if url_match else None

            if after_date:
                current_bullets.append(after_date)
            continue

        cleaned = re.sub(r"^[\-\u2022\*\u25E6\u25AA\u25B8\u27A4\u27A2\u2756\u2713\u2192]\s*", "", stripped)
        cleaned = re.sub(r"^\d+[\.)]\s+", "", cleaned)
        if cleaned:
            if not current_link:
                url_match = URL_RE.search(cleaned)
                if url_match:
                    current_link = url_match.group()
            current_bullets.append(cleaned)

    _flush()
    return projects


# ---------------------------------------------------------------------------
# Keyword extraction (enhanced — frequency + skill-weighted)
# ---------------------------------------------------------------------------

_STOPWORDS = {
    "the", "and", "for", "with", "from", "that", "this", "were", "was", "are",
    "our", "their", "its", "into", "over", "using", "used", "use", "across",
    "within", "while", "after", "before", "than", "then", "them", "they",
    "have", "has", "had", "not", "but", "all", "any", "can", "will", "would",
    "should", "could", "also", "more", "most", "other", "such", "which", "who",
    "whom", "how", "what", "when", "where", "why", "his", "her", "him", "she",
    "hers", "you", "your", "yours", "about", "team", "teams", "work", "worked",
    "working", "years", "year", "new", "including", "well", "based", "various",
    "multiple", "developed", "implemented", "designed", "created", "built",
    "managed", "led", "responsible",
}

_TOKEN_SPLIT_RE = re.compile(r"[^a-z0-9+#./-]+")
_TOKEN_TRIM_RE = re.compile(r"^[.\-/]+|[.\-/]+$")
_DIGITS_ONLY_RE = re.compile(r"^\d+$")


def _extract_keywords(text: str, limit: int = 40) -> List[str]:
    lines = text.splitlines()
    counts: dict[str, int] = {}
    for line in lines:
        for raw in _TOKEN_SPLIT_RE.split(line.lower()):
            token = _TOKEN_TRIM_RE.sub("", raw)
            if len(token) < 3 or len(token) > 30:
                continue
            if token in _STOPWORDS:
                continue
            if _DIGITS_ONLY_RE.match(token):
                continue
            counts[token] = counts.get(token, 0) + 1

    # Boost tokens that match known skills
    for token in list(counts.keys()):
        if token in TECHNICAL_SKILLS:
            counts[token] = counts[token] * 3

    ranked = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return [token for token, _count in ranked[:limit]]


# ---------------------------------------------------------------------------
# Main extraction function (public interface)
# ---------------------------------------------------------------------------

def extract_resume_info_nlp(resume_text: str) -> NlpResumeResult:
    """Extract structured resume information using spaCy NER and rule-based parsing.

    Raises NlpUnavailableError if spaCy/model is not available.
    """
    nlp = _get_nlp()

    contact = _extract_contact(resume_text)
    name = _extract_name(resume_text, nlp)
    sections = _segment_sections(resume_text)

    # Summary
    summary = sections.get("summary")
    if summary:
        summary = summary.strip()
        if len(summary) > 500:
            summary = summary[:500] + "..."

    # Skills
    skills = _extract_skills(resume_text)

    # Experience
    exp_text = sections.get("experience", "")
    experience = _extract_experience(exp_text, nlp)

    intern_text = sections.get("internships", "")
    if intern_text:
        internships = _extract_experience(intern_text, nlp, is_internship_section=True)
        experience.extend(internships)

    # Education
    edu_text = sections.get("education", "")
    education = _extract_education(edu_text, nlp)

    # Projects
    proj_text = sections.get("projects", "")
    projects = _extract_projects(proj_text, skills)

    # Keywords
    keywords = _extract_keywords(resume_text)

    return NlpResumeResult(
        name=name,
        contact=contact,
        summary=summary,
        education=education,
        experience=experience,
        projects=projects,
        skills=skills,
        keywords=keywords,
    )

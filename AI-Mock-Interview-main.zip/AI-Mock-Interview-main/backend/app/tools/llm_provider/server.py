"""LLM Provider Tool — INSTRUCTIONS.md §5.7. ~ mcp-servers/tool-llm-provider/src/index.ts.

The thin server side of `app.llm_client`. Routing and config only: no prompt
text and no interviewing judgement live here, which is what keeps the
Bedrock/OpenRouter/Groq/Ollama choice a deployment concern rather than
something baked into agent code (§11.5).

It exists as an MCP tool rather than an in-process import so that every
generation call gets the same treatment as every other tool call — session
auth, per-session rate limiting, schema validation on both sides, and one
auto-emitted `tool_called` span (CLAUDE.md §5). Sending resume, job
description and transcript text to a third party is exactly the kind of call
that should be counted and timed like any other, not made quietly in-process.

What it never does: call another agent or another tool (§5.7). The grounding
check runs inside `app.llm_client`, in-process, because it is an agent
validating its own generation rather than a cross-service interaction (§11.3).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

from app.llm_client.prompt_registry import PromptRegistry, UnknownPromptVersion
from app.llm_client.schemas import get_llm_schema
from app.llm_client.structured_call import StructuredCallOptions, structured_call
from app.llm_client.provider import resolve_provider
from app.llm_client.types import ProviderName, ProviderUnavailableError, StructuredCallError, StructuredChatModel, ToolDefinition
from app.shared_types import McpCallContext, McpHandlerError

SERVER_NAME = "tool-llm-provider"
METHODS = ("generate_structured",)


@dataclass
class LlmProviderDeps:
    # Pins the provider. Left unset, it is resolved from the environment on
    # every call — deliberately per-call rather than cached at construction,
    # so this server holds no state of its own (§11.1).
    provider: Optional[ProviderName] = None
    # Substitutes the chat model. Used by tests to force a malformed or
    # ungrounded response.
    model: Optional[StructuredChatModel] = None
    env: Optional[dict[str, str]] = None


class ToolLlmProviderServer:
    name = SERVER_NAME

    def __init__(self, deps: LlmProviderDeps) -> None:
        self._deps = deps

    async def call(self, method: str, params: Any, ctx: McpCallContext) -> Any:
        if method not in METHODS:
            raise McpHandlerError("unknown_method", f"{SERVER_NAME} has no method {method}")
        return await _generate_structured(self._deps, params)


def create_tool_llm_provider_server(deps: Optional[LlmProviderDeps] = None) -> ToolLlmProviderServer:
    return ToolLlmProviderServer(deps or LlmProviderDeps())


async def _generate_structured(deps: LlmProviderDeps, params: dict[str, Any]) -> dict[str, Any]:
    schema_ref = params["schema_ref"]
    entry = get_llm_schema(schema_ref)
    if not entry:
        raise McpHandlerError("unknown_schema_ref", f"no LLM schema registered as {schema_ref} in app.llm_client.schemas")

    prompt_version = params["prompt_version"]
    try:
        PromptRegistry.get(prompt_version)
    except UnknownPromptVersion as err:
        raise McpHandlerError("unknown_prompt_version", str(err)) from err

    tool_name = params["tool_name"]
    tool = ToolDefinition(
        name=tool_name,
        description=tool_name,
        schema=entry.schema,
        prompt_version=prompt_version,
        schema_ref=schema_ref,
        required_grounded_paths=entry.required_grounded_paths,
    )

    env = deps.env or None
    provider = (deps.model.provider if deps.model else None) or deps.provider or resolve_provider(env, tool_name).provider

    try:
        result = await structured_call(
            tool,
            params.get("input"),
            StructuredCallOptions(
                provider=provider,
                model=deps.model,
                env=env,
                source_documents=params.get("source_documents") or [],
                llm_grounding_fallback=bool(params.get("llm_grounding_fallback")),
                # (Stage 13) Per-call constraints for the schema's own
                # validators. Still routing and config only — this server
                # does not read them, it hands them to the one schema that
                # declares what to do with them.
                validation_context=params.get("validation_context") or None,
                **({"retries": int(params["retries"])} if params.get("retries") is not None else {}),
            ),
        )
    except ProviderUnavailableError as err:
        # Both of these mean the same thing to the calling agent — take the
        # deterministic Stage-2 path — but they are reported apart because
        # only one of them says anything is wrong with the deployment (§5.7).
        raise McpHandlerError("provider_unavailable", str(err)) from err
    except StructuredCallError as err:
        raise McpHandlerError("schema_validation_failed", str(err)) from err

    return {
        "output": result.output,
        "grounded": result.grounded,
        "insufficient_signal": result.insufficient_signal,
        "prompt_version": result.prompt_version,
        "provider": result.provider,
    }

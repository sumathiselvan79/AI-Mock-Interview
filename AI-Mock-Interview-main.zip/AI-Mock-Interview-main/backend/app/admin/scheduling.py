"""(Stage 7) Validation and projection for admin-scheduled interviews.
~ apps/gateway/src/admin/scheduling.ts.

Split out from the route so the rules are testable without HTTP, and so the
two projections — what an Admin sees and what a student sees — sit next to
each other where the difference between them is obvious.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Iterable, Optional, Sequence

from app.shared_types import ScheduledInterview, User
from app.shared_types.scheduling import (
    INTERVIEW_TYPES,
    MAX_SCHEDULE_DURATION_MINUTES,
    MIN_SCHEDULE_DURATION_MINUTES,
    NOTIFY_CHANNELS,
    RECURRENCES,
    SCHEDULE_DIFFICULTIES,
    effective_status,
    runs_coding_round,
)


class ScheduleInvalid(Exception):
    """A scheduling request the validator could not read exactly."""


def _iso_instant(value: Any, field: str) -> str:
    """An ISO instant, or throw. Rejects garbage that would otherwise become
    an Invalid Date. Normalised to UTC on the way in, so two admins in
    different timezones who pick "the same" moment store the same instant."""
    if not isinstance(value, str) or value.strip() == "":
        raise ScheduleInvalid(f"{field} is required and must be an ISO 8601 timestamp")
    try:
        parsed = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    except ValueError as err:
        raise ScheduleInvalid(f"{field} is not a valid ISO 8601 timestamp") from err
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _one_of(value: Any, allowed: Sequence[str], field: str) -> str:
    if not isinstance(value, str) or value not in allowed:
        raise ScheduleInvalid(f"{field} must be one of: {', '.join(allowed)}")
    return value


def _dedupe(values: Iterable[str]) -> list[str]:
    """Order-preserving unique — the TS side's `[...new Set(x)]`."""
    seen: set[str] = set()
    out: list[str] = []
    for value in values:
        if value not in seen:
            seen.add(value)
            out.append(value)
    return out


@dataclass
class ValidatedDraft:
    candidate_ids: list[str]
    role: str
    job_description: str
    interview_type: str
    difficulty: str
    duration_minutes: int
    scheduled_for: str
    deadline: Optional[str]
    recurring: str
    coding_round_enabled: bool
    notes: Optional[str]
    notify_via: list[str]


def validate_draft(body: dict[str, Any]) -> ValidatedDraft:
    """Validates an admin's scheduling request.

    Deliberately rejects rather than coerces. Scheduling creates a real
    obligation for a named student, so a request this function cannot read
    exactly is one an Admin should be shown an error for, not one that
    silently becomes something slightly different.
    """
    body = body or {}
    candidate_ids = body.get("candidate_ids")
    if not isinstance(candidate_ids, list) or len(candidate_ids) == 0:
        raise ScheduleInvalid("candidate_ids must be a non-empty array of student ids")
    if not all(isinstance(cid, str) and cid.strip() != "" for cid in candidate_ids):
        raise ScheduleInvalid("every entry in candidate_ids must be a non-empty string")
    # De-duplicated so selecting a student twice — easy in a bulk UI that
    # offers both "select rows" and "select department" — does not assign
    # them twice.
    unique_ids = _dedupe(candidate_ids)

    role = body.get("role")
    if not isinstance(role, str) or role.strip() == "":
        raise ScheduleInvalid("role is required")

    duration = body.get("duration_minutes")
    if (
        not isinstance(duration, int)
        or isinstance(duration, bool)
        or duration < MIN_SCHEDULE_DURATION_MINUTES
        or duration > MAX_SCHEDULE_DURATION_MINUTES
    ):
        raise ScheduleInvalid(
            f"duration_minutes must be a whole number between {MIN_SCHEDULE_DURATION_MINUTES} and {MAX_SCHEDULE_DURATION_MINUTES}"
        )

    scheduled_for = _iso_instant(body.get("scheduled_for"), "scheduled_for")
    deadline = (
        None
        if body.get("deadline") is None
        else _iso_instant(body.get("deadline"), "deadline")
    )
    if deadline and deadline <= scheduled_for:
        # Not a tight schedule — one that can never be started.
        raise ScheduleInvalid("deadline must be after scheduled_for")

    notify_via = ["in_app"] if "notify_via" not in body else body.get("notify_via")
    if not isinstance(notify_via, list) or len(notify_via) == 0:
        raise ScheduleInvalid(f"notify_via must be a non-empty array of: {', '.join(NOTIFY_CHANNELS)}")
    channels = [_one_of(c, NOTIFY_CHANNELS, "notify_via") for c in notify_via]

    # Rejected explicitly rather than ignored. An Admin who sent this believes
    # they answered consent for the candidate, and silently dropping it would
    # leave them believing it (soul.md §"Consent-first monitoring").
    if "consent_defaults" in body or "consent" in body:
        raise ScheduleInvalid(
            "consent cannot be set on a schedule — the candidate gives it themselves on the Telemetry Check page"
        )

    notes = body.get("notes")
    return ValidatedDraft(
        candidate_ids=unique_ids,
        role=role.strip(),
        job_description=body["job_description"] if isinstance(body.get("job_description"), str) else "",
        interview_type=_one_of(body.get("interview_type"), INTERVIEW_TYPES, "interview_type"),
        difficulty=_one_of(body.get("difficulty"), SCHEDULE_DIFFICULTIES, "difficulty"),
        duration_minutes=duration,
        scheduled_for=scheduled_for,
        deadline=deadline,
        recurring="none" if "recurring" not in body else _one_of(body.get("recurring"), RECURRENCES, "recurring"),
        coding_round_enabled=body.get("coding_round_enabled") is True,
        notes=notes if isinstance(notes, str) and notes.strip() != "" else None,
        notify_via=_dedupe(channels),
    )


def draft_to_rows(
    draft: ValidatedDraft,
    candidates: Sequence[User],
    created_by: str,
    now: Optional[datetime] = None,
) -> list[ScheduledInterview]:
    """Expands a validated draft into one row per candidate."""
    at = (now or datetime.now(timezone.utc)).isoformat().replace("+00:00", "Z")
    by_id = {c.id: c for c in candidates}

    return [
        ScheduledInterview(
            id=str(uuid.uuid4()),
            candidate_id=candidate_id,
            # Snapshot, so a batch scheduled "for Engineering" still reads
            # correctly after the candidate edits their own profile.
            department=by_id[candidate_id].department if candidate_id in by_id else None,
            role=draft.role,
            job_description=draft.job_description,
            interview_type=draft.interview_type,
            difficulty=draft.difficulty,
            duration_minutes=draft.duration_minutes,
            scheduled_for=draft.scheduled_for,
            deadline=draft.deadline,
            recurring=draft.recurring,
            coding_round_enabled=draft.coding_round_enabled,
            notes=draft.notes,
            notify_via=draft.notify_via,
            status="pending",
            session_id=None,
            created_by=created_by,
            created_at=at,
            updated_at=at,
        )
        for candidate_id in draft.candidate_ids
    ]


def to_admin_wire(schedule: ScheduledInterview, now: Optional[datetime] = None) -> dict[str, Any]:
    """Admin-facing wire shape. Carries `notes`, because notes are for admins."""
    now = now or datetime.now(timezone.utc)
    return {
        "id": schedule.id,
        "candidate_id": schedule.candidate_id,
        "department": schedule.department,
        "role": schedule.role,
        "job_description": schedule.job_description,
        "interview_type": schedule.interview_type,
        "difficulty": schedule.difficulty,
        "duration_minutes": schedule.duration_minutes,
        "scheduled_for": schedule.scheduled_for,
        "deadline": schedule.deadline,
        "recurring": schedule.recurring,
        "coding_round_enabled": schedule.coding_round_enabled,
        "notes": schedule.notes,
        "notify_via": schedule.notify_via,
        "status": effective_status(schedule.status, schedule.scheduled_for, schedule.deadline, now),
        "stored_status": schedule.status,
        "session_id": schedule.session_id,
        "created_by": schedule.created_by,
        "created_at": schedule.created_at,
    }


def to_student_wire(schedule: ScheduledInterview, now: Optional[datetime] = None) -> dict[str, Any]:
    """Student-facing wire shape. Deliberately narrower than `to_admin_wire`:
    no `notes` or `created_by` KEY at all, so an admin-internal field can
    never reach a candidate through a key someone forgot to strip."""
    now = now or datetime.now(timezone.utc)
    return {
        "id": schedule.id,
        "role": schedule.role,
        "job_description": schedule.job_description,
        "interview_type": schedule.interview_type,
        "difficulty": schedule.difficulty,
        "duration_minutes": schedule.duration_minutes,
        "scheduled_for": schedule.scheduled_for,
        "deadline": schedule.deadline,
        "runs_coding_round": runs_coding_round(schedule.interview_type, schedule.coding_round_enabled),
        "status": effective_status(schedule.status, schedule.scheduled_for, schedule.deadline, now),
        "session_id": schedule.session_id,
        # Said plainly on every assignment: being scheduled does not
        # pre-answer anything the candidate would otherwise be asked (soul.md §5).
        "consent_note": "You will still be asked for consent, and to upload your resume, before this interview starts.",
    }

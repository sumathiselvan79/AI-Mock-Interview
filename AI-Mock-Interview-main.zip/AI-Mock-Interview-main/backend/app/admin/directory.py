"""(Stage 7) Admin user directory — search, filter, sort, paginate.
~ apps/gateway/src/admin/directory.ts.

A pure function over already-fetched inputs, deliberately: the filters span
three stores (accounts, report aggregates, open schedules) and a candidate's
average score is not a column on any single one of them, so this cannot be a
`WHERE`/`ORDER BY`/`LIMIT` in one query without denormalising a score onto
`users` and keeping it correct forever. Fetching three bounded sets and
combining them here costs three queries TOTAL for the page — which is the
thing `ADMIN_FEATURE_PROMPT.md` Part 1 actually rules out ("aggregate stats
should come from a summary query, not N+1 report fetches"), and it keeps the
ordering rules in one readable place instead of spread across SQL.

Nothing here reads a resume, an audio ref, or a transcript. `DirectoryRow`
has no field that could carry one (soul.md §"Admin role").
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Optional

from app.shared_types import User
from app.shared_types.scheduling import (
    DEFAULT_DIRECTORY_PAGE_SIZE,
    MAX_DIRECTORY_PAGE_SIZE,
    DirectoryPage,
    DirectoryRow,
)


@dataclass
class DirectoryInputs:
    """`students` is student accounts only — an Admin is not a candidate
    (INSTRUCTIONS.md §3.2)."""

    students: list[User]
    # Rows as `ReportStore.aggregate_by_candidate` returns them: dicts keyed
    # candidate_id / interviews_completed / average_score / last_interview_at.
    report_stats: list[dict[str, Any]]
    # Candidate ids with at least one open assignment.
    scheduled_candidate_ids: list[str]
    # Session count per candidate — distinguishes "started nothing" from
    # "finished nothing".
    session_counts: dict[str, int]
    # Avatar URL per candidate id, for accounts that signed in with Google.
    avatars: dict[str, str] = field(default_factory=dict)


def _status_for(
    user_id: str, interviews_completed: int, session_count: int, scheduled: set[str]
) -> str:
    """`interview_scheduled` wins over `active` because it is the state an
    Admin is looking for when they filter — a candidate who has done ten
    interviews and has an eleventh assigned is, for this screen, a scheduled
    one."""
    if user_id in scheduled:
        return "interview_scheduled"
    if interviews_completed > 0 or session_count > 0:
        return "active"
    return "no_activity"


def build_rows(inputs: DirectoryInputs) -> list[DirectoryRow]:
    """Builds every row, unfiltered. Reused by the profile page for the same shape."""
    stats_by_candidate = {s["candidate_id"]: s for s in inputs.report_stats}
    scheduled = set(inputs.scheduled_candidate_ids)

    rows: list[DirectoryRow] = []
    for user in inputs.students:
        stats = stats_by_candidate.get(user.id)
        interviews_completed = int(stats["interviews_completed"]) if stats else 0
        rows.append(
            DirectoryRow(
                user_id=user.id,
                email=user.email,
                full_name=user.full_name,
                department=user.department,
                avatar_url=inputs.avatars.get(user.id),
                interviews_completed=interviews_completed,
                average_score=stats.get("average_score") if stats else None,
                last_interview_at=stats.get("last_interview_at") if stats else None,
                created_at=user.created_at,
                status=_status_for(
                    user.id, interviews_completed, inputs.session_counts.get(user.id, 0), scheduled
                ),
            )
        )
    return rows


# Sort keys are camelCase on the wire (they name `DirectoryRow` fields as the
# TS side spells them); this maps each to the Python attribute it sorts on.
_SORT_ATTR = {
    "fullName": "full_name",
    "email": "email",
    "department": "department",
    "interviewsCompleted": "interviews_completed",
    "averageScore": "average_score",
    "lastInterviewAt": "last_interview_at",
    "createdAt": "created_at",
}


def _sort_key(row: DirectoryRow, key: str, direction: str):
    """Sort key for one row.

    Null always sorts last regardless of direction — a candidate with no score
    yet is missing data, not the worst performer, and flipping to ascending
    should not fill the top of the screen with blanks. Expressed here as a
    (is_null, value) tuple with the value negated/reversed for descending, so
    the null flag is never affected by the direction.
    """
    value = getattr(row, _SORT_ATTR[key])
    if value is None:
        # The 1 sorts every null after every non-null in both directions.
        # Tuple comparison short-circuits on that first element, so the 0
        # here is only ever compared against another null's 0 — nulls tie
        # with each other and fall through to the user-id tie-break.
        return (1, 0)
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return (0, -value if direction == "desc" else value)
    # `localeCompare(..., { sensitivity: "base" })` on the TS side — a
    # case-insensitive comparison, which casefold() is the Python spelling of.
    return (0, _ReversibleStr(str(value).casefold(), direction == "desc"))


class _ReversibleStr:
    """A string that compares backwards when `reverse` is set, so descending
    sorts can share one key function with ascending ones without a second pass
    that would break the null-last rule."""

    __slots__ = ("value", "reverse")

    def __init__(self, value: str, reverse: bool) -> None:
        self.value = value
        self.reverse = reverse

    def __lt__(self, other: "_ReversibleStr") -> bool:
        return other.value < self.value if self.reverse else self.value < other.value

    def __eq__(self, other: object) -> bool:
        return isinstance(other, _ReversibleStr) and self.value == other.value


def _matches_search(row: DirectoryRow, search: str) -> bool:
    needle = (search or "").strip().lower()
    if needle == "":
        return True
    return needle in row.email.lower() or needle in (row.full_name or "").lower()


def build_directory_page(
    inputs: DirectoryInputs, query: Optional[dict[str, Any]] = None
) -> DirectoryPage:
    """Applies the query and returns one page.

    `total` is the count AFTER filtering and before paging, so the UI can
    render "showing 25 of 312 matching" rather than a page count that ignores
    filters.
    """
    query = query or {}
    page_size = min(
        max(1, math.floor(query.get("page_size") or DEFAULT_DIRECTORY_PAGE_SIZE)),
        MAX_DIRECTORY_PAGE_SIZE,
    )
    page = max(1, math.floor(query.get("page") or 1))

    min_score = query.get("min_score")
    max_score = query.get("max_score")
    from_ = query.get("from")
    to = query.get("to")

    filtered: list[DirectoryRow] = []
    for row in build_rows(inputs):
        if not _matches_search(row, query.get("search") or ""):
            continue
        if query.get("department") and row.department != query["department"]:
            continue
        if query.get("status") and row.status != query["status"]:
            continue

        # A score filter is a statement about scores. A candidate with none
        # has not scored below the floor — they are outside the question, so
        # they are excluded rather than silently counted as zero.
        if min_score is not None and (row.average_score is None or row.average_score < min_score):
            continue
        if max_score is not None and (row.average_score is None or row.average_score > max_score):
            continue

        # The date range is about interview activity, so it filters
        # `last_interview_at` — same reasoning: never interviewed is not
        # "interviewed outside the range".
        if from_ and (row.last_interview_at is None or row.last_interview_at < from_):
            continue
        if to and (row.last_interview_at is None or row.last_interview_at > to):
            continue

        filtered.append(row)

    sort_key = query.get("sort") or "createdAt"
    direction = query.get("direction") or ("asc" if query.get("sort") else "desc")

    # Tie-break on user id so paging is stable: without it two candidates with
    # equal scores can swap places between page 1 and page 2 and one of them
    # never appears.
    sorted_rows = sorted(filtered, key=lambda r: (_sort_key(r, sort_key, direction), r.user_id))

    start = (page - 1) * page_size
    return DirectoryPage(
        rows=sorted_rows[start : start + page_size],
        total=len(sorted_rows),
        page=page,
        page_size=page_size,
    )

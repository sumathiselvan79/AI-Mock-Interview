"""The in-memory routing tracker — one `InterviewSession` snapshot per live
session, in a plain dict, for ultra-fast access on the hot path.

**Why this is in `app/http` and not in an agent.** CLAUDE.md §10 (Stage 5) is
unambiguous: no agent holds module-level mutable state and no agent keeps an
in-memory per-session cache, because an agent that remembers things between
calls stops being reproducible from its inputs. That rule is not bent here.
What this file holds is a gateway-owned cache of a value that is *derived*
from persisted rows — `topic_counts` from the Memory Agent, `topic_scores`
from the Evaluation store, the caps from `Session.topic_plan`. Every entry
can be thrown away at any moment and rebuilt exactly (`routing.rebuilt_from`),
and `snapshot()` below does precisely that on a miss. So:

 - nothing is *stored* here that is not stored durably somewhere else;
 - a restart, a second worker, or a session resumed on another process
   produces the same routing decision as the one that was lost;
 - the agents downstream stay stateless reducers over what they are handed.

If you ever find yourself putting something in this dict that cannot be
rebuilt from the stores, that is the moment this becomes real state and the
Memory Agent is where it belongs instead (INSTRUCTIONS.md §4.7).

The dict is deliberately unbounded in the same way the live-session store
is: entries are dropped when a session leaves QUESTION_LOOP (`drop`), and a
snapshot is a few hundred bytes.
"""

from __future__ import annotations

from typing import Optional, Sequence

from app.interview_domain.routing import InterviewSession, record_score, rebuilt_from

#: session_id -> snapshot. A plain dict on purpose: the read happens on every
#: turn of a live interview, between the candidate finishing an answer and the
#: next question being spoken, and it is a pure cache (see the module
#: docstring), so a round trip to Redis or Postgres for it would buy nothing.
active_sessions: dict[str, InterviewSession] = {}


class SessionTracker:
    """Thin, injectable accessor over `active_sessions`.

    An instance rather than bare functions so tests (and a second gateway in
    one process) can hold an isolated store — `SessionTracker(store={})` — and
    so the harness receives it as a dependency like everything else it uses,
    rather than importing a global halfway down a call stack.
    """

    def __init__(self, store: Optional[dict[str, InterviewSession]] = None) -> None:
        self._store = active_sessions if store is None else store

    def get(self, session_id: str) -> Optional[InterviewSession]:
        return self._store.get(session_id)

    def snapshot(
        self,
        session_id: str,
        *,
        topic_counts: dict[str, int],
        topic_caps: dict[str, int],
        topic_scores: dict[str, list[float]],
        topic_tier: dict[str, int],
        current_topic: Optional[str] = None,
        recent_scores: Optional[Sequence[float]] = None,
    ) -> InterviewSession:
        """The snapshot for this session, reconciled against persisted state.

        The cached entry keeps `rolling_score`/`last_score`/`answers_scored`
        — the EMA is a running value and replaying it from a score list is
        only a fallback, not the normal path. Everything else is refreshed
        from what the caller just read out of the stores, so a cap spent or a
        tier moved by another process cannot go unnoticed here.
        """
        cached = self._store.get(session_id)
        rebuilt = rebuilt_from(
            session_id=session_id,
            topic_counts=topic_counts,
            topic_caps=topic_caps,
            topic_scores=topic_scores,
            topic_tier=topic_tier,
            current_topic=current_topic if current_topic is not None else (cached.current_topic if cached else None),
            recent_scores=None if cached else recent_scores,
        )
        if cached:
            rebuilt = rebuilt.model_copy(
                update={
                    "rolling_score": cached.rolling_score,
                    "last_score": cached.last_score,
                    "answers_scored": cached.answers_scored,
                }
            )
        self._store[session_id] = rebuilt
        return rebuilt

    def record_answer_score(
        self, session_id: str, *, score: float, topic: Optional[str] = None, tier: Optional[int] = None
    ) -> InterviewSession:
        """Folds one scored answer into the snapshot. Creates it if the
        session is not tracked yet — a first answer is a perfectly ordinary
        way for a session to appear here."""
        current = self._store.get(session_id) or InterviewSession(session_id=session_id)
        updated = record_score(current, score=score, topic=topic, tier=tier)
        self._store[session_id] = updated
        return updated

    def drop(self, session_id: str) -> None:
        """Forgets a session. Called when it leaves QUESTION_LOOP; safe to
        call for a session that was never tracked."""
        self._store.pop(session_id, None)

    def tracked(self) -> list[str]:
        return sorted(self._store)


#: The process-wide tracker the gateway wires into the harness. Tests build
#: their own with an isolated store rather than reaching for this one.
default_tracker = SessionTracker()

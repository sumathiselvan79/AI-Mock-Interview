"""WebSocket live channel — `/sessions/{id}/live` (INSTRUCTIONS.md §7).

~ apps/gateway/src/http/live-channel.ts.

Server -> client: `question` (with `audio_url`), `acknowledgment`,
`continuer`, `clarification`, `follow_up`, `timer_tick`, `coding_problem`,
`paste_detected`, `focus_recorded`, `transcript_draft`,
`transcript_rejected`, `session_complete`, `notice` (one-shot, non-error:
e.g. `speech_degraded` once per connection when TTS is down).

`acknowledgment`, `continuer` and `clarification` are the three events that do
NOT advance the interview (`HUMAN_INTERACTION_FLOW.md` §1, §3, §8): the first
is the micro-ack spoken while the real response is still being computed, the
second is a line spoken to hold the conversation open while it still is, and
the third is the interviewer answering "can you repeat that?" with the same
question still on the table. None carries an `answered` flag and none should
be treated as a turn.

`continuer` is the only server event with no request behind it — it is pushed
mid-handler, while the client is still waiting on the reply to the message it
sent. That is the whole point of it (§8): the candidate hears the interview is
still thinking instead of watching a spinner. It carries a `kind`
(`opening` | `holding` | `selection` | `follow_up_receipt`) because the four
are said at different moments and only the first is not a "still working" signal.
Client -> server: `transcribe_audio`, `submit_answer_audio`,
`submit_answer_text`, `submit_code`, `paste_detected`, `focus_lost`, `pause`,
`end_session`.

The socket is a transport, not an authority: every message is routed
straight to the Harness Agent, which owns the state machine. Nothing here
decides what happens next, and the connection is authenticated with the
same role-scoped token as every REST route — a socket is not a way around
RBAC.

Unlike the TS `ws`-library version, FastAPI's `WebSocket.receive_text()` is
pull-based: the ASGI server buffers frames at the transport level until the
application asks for one, so there is no equivalent of the TS file's
"queued before ready" race — nothing is listening with an event emitter
that could miss an early message.
"""

from __future__ import annotations

import asyncio
import json
import time
from datetime import datetime, timezone
from typing import Any

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from starlette.websockets import WebSocketState

from app.agents.harness.harness import HarnessAgent
from app.agents.harness.interview import MetaUtteranceResult
from app.auth.tokens import verify_token
from app.config import GatewayConfig
from app.logging_ import Logger
from app.storage.types import Storage

# How often the timer state is pushed while a session is live.
TIMER_TICK_MS = 1_000


async def _send(ws: WebSocket, event_type: str, payload: dict[str, Any]) -> None:
    if ws.client_state == WebSocketState.CONNECTED:
        await ws.send_text(json.dumps({"type": event_type, **payload}))


def attach_live_channel(app: FastAPI, *, harness: HarnessAgent, storage: Storage, config: GatewayConfig, logger: Logger) -> None:
    # The same audio cap the REST route enforces.
    max_audio_base64 = -(-config.max_audio_bytes * 4 // 3)  # ceil(bytes * 4/3)

    async def _decode_audio(ws: WebSocket, value: Any) -> Any:
        """Decodes a client-supplied base64 audio field, refusing anything
        over the configured cap. Returns None after telling the client why."""
        import base64
        import binascii

        text = str(value or "")
        if len(text) > max_audio_base64:
            await _send(ws, "error", {"code": "file_too_large", "message": f"recording exceeds {config.max_audio_bytes} bytes"})
            return None
        try:
            data = base64.b64decode(text, validate=True)
        except (binascii.Error, ValueError):
            await _send(ws, "error", {"code": "bad_message", "message": "audio_base64 is not valid base64"})
            return None
        if len(data) == 0:
            await _send(ws, "error", {"code": "bad_message", "message": "audio_base64 decoded to zero bytes"})
            return None
        if len(data) > config.max_audio_bytes:
            await _send(ws, "error", {"code": "file_too_large", "message": f"recording exceeds {config.max_audio_bytes} bytes"})
            return None
        return data

    def _input_device(message: dict[str, Any]) -> Any:
        """(STT addition) The client's capture-device hint, if it sent one.

        Whitelisted field by field rather than forwarded wholesale: this is
        candidate-controlled input on its way into a schema-validated MCP call,
        and an unexpected key would be a validation failure rather than a
        harmless extra. `label` is capped because it reaches a telemetry span.
        """
        device = message.get("input_device")
        if not isinstance(device, dict):
            return None
        out: dict[str, Any] = {}
        if device.get("hint") in ("microphone", "speaker", "unknown"):
            out["hint"] = device["hint"]
        if isinstance(device.get("label"), str) and device["label"].strip():
            out["label"] = device["label"][:200]
        if isinstance(device.get("echo_cancellation"), bool):
            out["echo_cancellation"] = device["echo_cancellation"]
        return out or None

    async def _push_timer(ws: WebSocket, session_id: str) -> None:
        timer = await storage.live.load_timer(f"{session_id}:session")
        if not timer:
            return
        elapsed = time.time() * 1000 - timer.started_at - timer.paused_ms
        await _send(ws, "timer_tick", {"elapsed_ms": max(0, elapsed), "remaining_ms": timer.budget_ms - elapsed})

    async def _timer_loop(ws: WebSocket, session_id: str) -> None:
        try:
            while True:
                await asyncio.sleep(TIMER_TICK_MS / 1000)
                await _push_timer(ws, session_id)
        except asyncio.CancelledError:
            pass
        except Exception:  # noqa: BLE001 - a broken timer push must not kill the socket
            pass

    def _acknowledger(ws: WebSocket):
        """(§1) The two-stage response, on the wire.

        The orchestrator calls this the moment the micro-acknowledgment has
        been spoken — before the score, the follow-up decision and the next
        turn exist, all of which cost provider round trips. That gap is the
        whole point: the candidate hears "Mm-hm." while the interview is still
        thinking, instead of silence followed by a fully-formed reply.
        """

        async def send_acknowledgment(spoken: Any) -> None:
            await _send(ws, "acknowledgment", {"text": spoken.text, "audio_url": spoken.audio_url})

        return send_acknowledgment

    def _continuer_sender(ws: WebSocket):
        """(§8) Continuers, on the wire.

        Fires from inside a handler that has not returned yet — the reply to
        the client's own message is still being computed when this goes out.
        Nothing downstream may treat it as that reply: it has no `answered`
        flag, no ids, and `replyTo` on the client side deliberately returns
        null for it.
        """

        async def send_continuer(continuer: Any) -> None:
            await _send(ws, "continuer", {"kind": continuer.kind, "text": continuer.spoken.text, "audio_url": continuer.spoken.audio_url})

        return send_continuer

    def _send_answer_result(ws: WebSocket, result: Any):
        # (§3) The candidate asked about the question rather than answering it.
        # Nothing was written and nothing was scored, so this is emphatically
        # NOT an `answered: true` — the same question is still on the table and
        # the frontend must leave the candidate able to answer it.
        if isinstance(result, MetaUtteranceResult):
            return _send(ws, "clarification", {"kind": result.kind, "question_id": result.question_id, "text": result.text, "audio_url": result.audio_url})
        if result.follow_up:
            return _send(ws, "follow_up", {"answer_id": result.answer.id, "text": result.follow_up.text, "reason": result.follow_up.reason, "audio_url": result.follow_up.audio_url})
        payload: dict[str, Any] = {"answered": True, "answer_id": result.answer.id, "evaluation": result.evaluation}
        if result.evaluation_note:
            payload["evaluation_note"] = result.evaluation_note
        return _send(ws, "question", payload)

    async def _handle_message(ws: WebSocket, session_id: str, raw: str, notices_sent: set[str]) -> None:
        try:
            message = json.loads(raw)
        except json.JSONDecodeError:
            await _send(ws, "error", {"code": "bad_message", "message": "expected JSON"})
            return

        message_type = message.get("type")
        try:
            if message_type == "begin_interview":
                started = await harness.begin_interview(session_id)
                await _send(ws, "connected", {"session_id": session_id, "state": started.state})
                # (§8) The hello, after the session is genuinely in
                # QUESTION_LOOP and before the client asks for the first
                # question. Best-effort: greeting the candidate is not worth
                # failing a started interview over.
                try:
                    await harness.opening_line(session_id, _continuer_sender(ws))
                except Exception:  # noqa: BLE001
                    pass
                return

            if message_type == "next_question":
                # `advance: true` (the Skip control) explicitly abandons a
                # pending, unanswered question and generates the next one.
                result = await harness.next_question(session_id, advance=message.get("advance") is True, on_continuer=_continuer_sender(ws))
                if result.done:
                    await _send(ws, "session_complete", {"note": result.note})
                else:
                    q = result.question
                    payload: dict[str, Any] = {"id": q.id, "text": q.text, "topic": q.topic, "question_type": q.type, "difficulty": q.difficulty, "audio_url": q.audio_url}
                    # (C3) Degraded TTS is a property of the question, not a
                    # failure of the request: it rides on the `question` frame
                    # as `speech_note`. It used to be a separate `error` frame
                    # after every question, which put error chrome on a working
                    # interview and arrived where a client expected the reply
                    # to its next message.
                    if result.speech_note:
                        payload["speech_note"] = result.speech_note
                    await _send(ws, "question", payload)
                    # Said once per connection, as a non-error `notice` (a type
                    # `replyTo` returns null for and the room ignores unless it
                    # chooses to show it), not on every question.
                    if result.speech_note and "speech_degraded" not in notices_sent:
                        notices_sent.add("speech_degraded")
                        await _send(ws, "notice", {"code": "speech_degraded", "message": result.speech_note})
                return

            if message_type == "transcribe_audio":
                audio = await _decode_audio(ws, message.get("audio_base64"))
                if audio is None:
                    return
                stored = await storage.files.put(session_id=session_id, filename=f"answer-draft-{int(time.time() * 1000)}.wav", content_type="audio/wav", data=audio)
                outcome = await harness.transcribe_audio(session_id=session_id, audio_ref=stored.ref, input_device=_input_device(message))

                if not outcome.accepted:
                    await _send(ws, "transcript_rejected", {"reason": outcome.reason, "code": outcome.code, "confidence": outcome.confidence, "draft_transcript": outcome.draft_transcript, "action": "retry_or_type"})
                    return

                await _send(
                    ws,
                    "transcript_draft",
                    {
                        "transcript": outcome.transcript,
                        "confidence": outcome.confidence,
                        "question_id": message.get("question_id"),
                        "answer_id": message.get("answer_id"),
                    },
                )
                return

            if message_type == "submit_answer_audio":
                audio = await _decode_audio(ws, message.get("audio_base64"))
                if audio is None:
                    return
                stored = await storage.files.put(session_id=session_id, filename=f"answer-{int(time.time() * 1000)}.wav", content_type="audio/wav", data=audio)
                outcome = await harness.submit_audio_answer(
                    session_id=session_id,
                    question_id=str(message.get("question_id") or ""),
                    audio_ref=stored.ref,
                    on_acknowledgment=_acknowledger(ws),
                    on_continuer=_continuer_sender(ws),
                    input_device=_input_device(message),
                )

                if not outcome["accepted"]:
                    retry = outcome["retry"]
                    await _send(ws, "transcript_rejected", {"reason": retry.reason, "code": retry.code, "confidence": retry.confidence, "draft_transcript": retry.draft_transcript, "action": "retry_or_type"})
                    return
                await _send_answer_result(ws, outcome["result"])
                return

            if message_type == "submit_answer_text":
                result = await harness.submit_answer(
                    session_id=session_id,
                    question_id=str(message.get("question_id") or ""),
                    transcript=str(message.get("transcript") or ""),
                    on_acknowledgment=_acknowledger(ws),
                    on_continuer=_continuer_sender(ws),
                )
                await _send_answer_result(ws, result)
                return

            if message_type == "submit_follow_up_audio":
                audio = await _decode_audio(ws, message.get("audio_base64"))
                if audio is None:
                    return
                stored = await storage.files.put(session_id=session_id, filename=f"answer-followup-{int(time.time() * 1000)}.wav", content_type="audio/wav", data=audio)
                transcription = await harness.orchestrator().transcribe(session_id, stored.ref, _input_device(message))
                if not transcription.accepted:
                    await _send(ws, "transcript_rejected", {"reason": transcription.reason, "code": transcription.code, "confidence": transcription.confidence, "draft_transcript": transcription.draft_transcript, "action": "retry_or_type"})
                    return
                result = await harness.submit_follow_up_answer(
                    session_id=session_id,
                    answer_id=str(message.get("answer_id") or ""),
                    follow_up_text=str(message.get("follow_up_text") or ""),
                    transcript=transcription.transcript,
                    on_continuer=_continuer_sender(ws),
                )
                await _send(ws, "question", {"answered": True, "answer_id": result.id})
                return

            if message_type == "submit_follow_up_text":
                result = await harness.submit_follow_up_answer(
                    session_id=session_id,
                    answer_id=str(message.get("answer_id") or ""),
                    follow_up_text=str(message.get("follow_up_text") or ""),
                    transcript=str(message.get("transcript") or ""),
                    on_continuer=_continuer_sender(ws),
                )
                await _send(ws, "question", {"answered": True, "answer_id": result.id})
                return

            if message_type == "submit_code":
                if not config.coding_round_enabled:
                    # Same refusal as the REST route (`coding_round_disabled`
                    # in routes/voice.py): no candidate code runs here.
                    await _send(ws, "error", {"code": "coding_round_disabled", "message": "the coding round is not available on this deployment"})
                    return
                talk_through = message.get("talk_through") if isinstance(message.get("talk_through"), str) else None
                result = await harness.submit_code(session_id=session_id, code=str(message.get("code") or ""), talk_through=talk_through)  # type: ignore[attr-defined]
                await _send(ws, "coding_problem", {"submission": result})
                return

            if message_type == "paste_detected":
                # Only a timestamp crosses the wire; there is no content field.
                timestamp = message.get("timestamp") if isinstance(message.get("timestamp"), str) else datetime.now(timezone.utc).isoformat()
                recorded = await harness.record_paste_event(session_id, timestamp)
                await _send(ws, "paste_detected", {"recorded": recorded})
                return

            if message_type == "focus_lost":
                timestamp = message.get("timestamp") if isinstance(message.get("timestamp"), str) else datetime.now(timezone.utc).isoformat()
                outcome = await harness.record_focus_event(session_id, timestamp)
                await _send(ws, "focus_recorded", {"recorded": outcome["recorded"], "exit_count": outcome["exit_count"], "concluded": outcome["concluded"]})
                # More than MAX_FOCUS_EXITS exits: the harness has already
                # wrapped the session up. Tell the frontend the same way
                # `end_session` does.
                if outcome.get("concluded") and outcome.get("wrap_up"):
                    wrap_up = outcome["wrap_up"]
                    await _send(ws, "session_complete", {"state": wrap_up["session"].state, "message": wrap_up["spoken"].text, "audio_url": wrap_up["spoken"].audio_url, "reason": "focus_exit_limit"})
                return

            if message_type == "end_session":
                result = await harness.wrap_up(session_id)
                await _send(ws, "session_complete", {"state": result["session"].state, "message": result["spoken"].text, "audio_url": result["spoken"].audio_url})
                return

            await _send(ws, "error", {"code": "unknown_type", "message": f"unsupported message: {message_type}"})
        except Exception as err:  # noqa: BLE001
            code = getattr(err, "code", "failed")
            logger.warn("live_message_failed", {"session_id": session_id, "type": message_type, "code": code})
            await _send(ws, "error", {"code": code, "message": str(err)})

    @app.websocket("/sessions/{session_id}/live")
    async def live_channel(websocket: WebSocket, session_id: str) -> None:
        await websocket.accept()

        # The browser WebSocket API cannot set headers, so the token arrives
        # as a query parameter. It is still the same signed, role-scoped
        # token, and it is verified before the socket does anything.
        token = websocket.query_params.get("token", "")
        verdict = verify_token(token, config.auth_token_secret)
        if not verdict.ok:
            await websocket.close(code=4401, reason="unauthorized")
            return

        session = await storage.sessions.get(session_id)
        # Ownership is checked here exactly as `assert_owns_or_admin` does for REST.
        if not session or (verdict.claims.role != "admin" and session.candidate_id != verdict.claims.sub):
            await _send(websocket, "error", {"code": "forbidden", "message": "this session is not yours"})
            await websocket.close()
            return

        await _send(websocket, "connected", {"session_id": session_id, "state": session.state})

        ticker = asyncio.create_task(_timer_loop(websocket, session_id))
        # Per-connection memory of one-shot notices (C3). Held on the socket's
        # own stack, not in a module-level dict: it dies with the connection.
        notices_sent: set[str] = set()
        try:
            while True:
                raw = await websocket.receive_text()
                await _handle_message(websocket, session_id, raw, notices_sent)
        except WebSocketDisconnect:
            pass
        except Exception as err:  # noqa: BLE001
            logger.warn("live_socket_error", {"session_id": session_id, "message": str(err)})
        finally:
            ticker.cancel()

"""Fixed-window rate limits for the unauthenticated /auth routes (audit P1 #9,
deploy/aws/notes/PATCH_PLAN.md A5).

Counters live in `storage.live.increment_rate_counter`, the same primitive the
MCP Gateway's per-session limit uses: Redis INCR + PEXPIRE under the postgres
driver, an in-process dict under the memory driver. So the limits are shared
across restarts and (if there were ever more than one) processes in
production, and need no Redis in tests.

Two keys per request, both checked:
 - per client IP, which stops one host spraying passcodes across many
   accounts, or mass-registering;
 - per email, which stops a distributed guess against one account. The
   address is hashed before it becomes a key, so no email lands in Redis or
   in a log line (CLAUDE.md §8).

The per-email limit is also a lockout lever: anyone can spend a victim's
login budget for 15 minutes. That is the accepted cost of having one at all;
the budget is generous enough that a real user retyping a passcode never
meets it, and Google sign-in does not go through it.
"""

from __future__ import annotations

import hashlib
import ipaddress
from dataclasses import dataclass
from typing import Any, Optional, Sequence

from fastapi import Request

from app.http.errors import HttpError

_MINUTE_MS = 60_000


@dataclass(frozen=True)
class Limit:
    max_requests: int
    window_ms: int


@dataclass(frozen=True)
class RoutePolicy:
    per_ip: Optional[Limit]
    per_email: Optional[Limit]


# Sized against the attack, not the UI: an 8-character passcode cannot be
# brute-forced at 10 guesses a minute, and nobody types theirs wrong ten times
# in a quarter hour.
POLICIES: dict[str, RoutePolicy] = {
    "login": RoutePolicy(per_ip=Limit(10, _MINUTE_MS), per_email=Limit(10, 15 * _MINUTE_MS)),
    # Generous per IP because a classroom or campus NAT can put a whole cohort
    # behind one address on signup day.
    "register": RoutePolicy(per_ip=Limit(20, 60 * _MINUTE_MS), per_email=None),
    # Each request mints a token and (eventually) sends an email.
    "reset_request": RoutePolicy(per_ip=Limit(10, 60 * _MINUTE_MS), per_email=Limit(5, 60 * _MINUTE_MS)),
    # Tokens are 256-bit, so this is not guarding against guessing so much as
    # keeping an unauthenticated scrypt call from being free to repeat.
    "reset_confirm": RoutePolicy(per_ip=Limit(10, 15 * _MINUTE_MS), per_email=None),
}


def _parse_ip(value: str) -> Optional[ipaddress.IPv4Address | ipaddress.IPv6Address]:
    try:
        return ipaddress.ip_address(value.strip())
    except ValueError:
        return None


def _is_trusted(ip: ipaddress.IPv4Address | ipaddress.IPv6Address, networks: Sequence[Any]) -> bool:
    return any(ip.version == net.version and ip in net for net in networks)


def client_ip(request: Any, trusted_proxy_cidrs: Sequence[str]) -> str:
    """The address the limit applies to.

    The TCP peer, unless the peer is a trusted proxy (Caddy, on the compose
    network). Then X-Forwarded-For is read right to left and the first hop that
    is not itself a trusted proxy is the client. Right to left matters: the
    left end is whatever the client chose to send, and only the entries our
    own proxies appended are believable. A peer outside the trusted set gets
    its header ignored entirely, so a direct caller cannot pick its own key.
    """
    peer = request.client.host if request.client is not None else None
    if not peer:
        return "unknown"
    peer_ip = _parse_ip(peer)
    networks = [ipaddress.ip_network(c, strict=False) for c in trusted_proxy_cidrs]
    if peer_ip is None or not _is_trusted(peer_ip, networks):
        return peer

    header = request.headers.get("x-forwarded-for") or ""
    for hop in reversed(header.split(",")):
        hop_ip = _parse_ip(hop)
        if hop_ip is None:
            # A malformed hop means the chain cannot be read past this point.
            break
        if not _is_trusted(hop_ip, networks):
            return str(hop_ip)
    return peer


def _email_key(email: str) -> str:
    normalized = email.strip().lower()
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:32]


async def enforce_auth_rate_limit(request: Request, action: str, email: Optional[str] = None) -> None:
    """Raises 429 `rate_limited` (the app's usual error shape) when either
    budget for `action` is spent. A no-op when the config turns limits off,
    which production cannot do.

    Fails open if the counter store errors: with Redis down every interview
    is already broken, and refusing every sign-in on top of that turns an
    outage into a lockout. The failure is logged (no email, no IP)."""
    config = request.app.state.config
    if not config.auth_rate_limit_enabled:
        return
    policy = POLICIES[action]
    live = request.app.state.storage.live

    checks: list[tuple[str, Limit]] = []
    if policy.per_ip is not None:
        checks.append((f"auth:{action}:ip:{client_ip(request, config.trusted_proxy_cidrs)}", policy.per_ip))
    if policy.per_email is not None and email:
        checks.append((f"auth:{action}:email:{_email_key(email)}", policy.per_email))

    for key, limit in checks:
        try:
            count = await live.increment_rate_counter(key, limit.window_ms)
        except Exception as err:  # noqa: BLE001 - see docstring
            request.app.state.logger.warn("auth_rate_limit_unavailable", {"action": action, "error": type(err).__name__})
            return
        if count > limit.max_requests:
            scope = "ip" if ":ip:" in key else "email"
            request.app.state.logger.warn("auth_rate_limited", {"action": action, "scope": scope})
            minutes = max(1, limit.window_ms // _MINUTE_MS)
            raise HttpError(429, "rate_limited", f"too many attempts; try again in up to {minutes} minute{'s' if minutes != 1 else ''}")

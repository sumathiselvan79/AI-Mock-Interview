"""Interview Config routes — ~ apps/gateway/src/http/routes/interview.ts. INSTRUCTIONS.md §7.

These handlers do three things and nothing more: check the caller owns the
session, hand off to the Harness Agent, and shape the reply. No interview
logic lives here, and nothing here writes `Session.state`.

Resume upload takes base64 JSON rather than multipart, same reasoning as the
TS source: it keeps the raw bytes inside a single validated body, avoids a
streaming-upload dependency in the gateway, and makes the size cap trivially
enforceable before anything is written to disk.

F5 scope: resume upload/delete + jd-fit read. The question-loop routes
(`/begin`, `/questions/next`, `/answers`, ...) land in F6+.
"""

from __future__ import annotations

import base64
import binascii
import re
from typing import Any

from fastapi import APIRouter, Depends, Request

from app.agents.harness.harness import HarnessAgent, TransitionRejected
from app.agents.harness.interview import MetaUtteranceResult
from app.config import GatewayConfig
from app.http.errors import HttpError, bad_request, not_found
from app.http.middleware.auth import assert_owns_or_admin, get_auth_claims, require_role
from app.shared_types import AuthTokenClaims, JdFit, McpHandlerError
from app.storage.types import Storage

_ACCEPTED_RESUME_TYPES = {
    "application/pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "text/plain",
    "text/markdown",
}
_RESUME_EXTENSION_RE = re.compile(r"\.(pdf|docx|txt|md)$", re.IGNORECASE)


def _jd_fit_to_wire(jd_fit: JdFit) -> dict[str, Any]:
    """(Stage 5) One wire shape for `JdFit`, used by both the upload response
    and the config page's read, so the two cannot drift."""
    out: dict[str, Any] = {"fit_score": jd_fit.fit_score, "matched_requirements": jd_fit.matched_requirements, "gaps": jd_fit.gaps}
    if jd_fit.rationale is not None:
        out["rationale"] = jd_fit.rationale
    if jd_fit.topic_relevance is not None:
        out["topic_relevance"] = [
            {"topic": t.topic, "relevance_score": t.relevance_score, "evidence": t.evidence} for t in jd_fit.topic_relevance
        ]
    if jd_fit.prompt_version is not None:
        out["prompt_version"] = jd_fit.prompt_version
    if jd_fit.insufficient_signal:
        out["insufficient_signal"] = jd_fit.insufficient_signal
    if jd_fit.role_level is not None:
        out["role_level"] = jd_fit.role_level
    if jd_fit.key_technologies is not None:
        out["key_technologies"] = jd_fit.key_technologies
    return out


def _to_http_error(err: Exception) -> HttpError:
    """Maps an agent's MCP error onto an HTTP status the frontend can act on."""
    if isinstance(err, McpHandlerError):
        if err.code in ("unsupported_format", "parse_failed", "insufficient_transcript"):
            return HttpError(422, err.code, err.message)
        if err.code == "no_questions_available":
            return HttpError(409, err.code, err.message)
        if err.code == "rate_limited":
            return HttpError(429, err.code, err.message)
        return HttpError(502, err.code, err.message)
    if isinstance(err, TransitionRejected):
        return HttpError(409, "illegal_transition", str(err))
    if isinstance(err, HttpError):
        return err
    raise err


def interview_routes(*, storage: Storage, harness: HarnessAgent, config: GatewayConfig) -> APIRouter:
    router = APIRouter()

    async def _load_owned_session(session_id: str, claims: AuthTokenClaims):
        session = await storage.sessions.get(session_id)
        if not session:
            raise not_found("unknown session")
        assert_owns_or_admin(claims, session.candidate_id)
        return session

    @router.post("/{session_id}/resume", status_code=201)
    async def upload_resume(
        session_id: str, request: Request, claims: AuthTokenClaims = Depends(require_role("student"))
    ):
        """Upload; triggers parsing + the JD-fit check."""
        try:
            session = await _load_owned_session(session_id, claims)
            body = await request.json()

            filename = body.get("filename")
            if not isinstance(filename, str) or filename.strip() == "":
                raise bad_request("invalid_request", "filename is required")
            data_b64 = body.get("data_base64")
            if not isinstance(data_b64, str) or data_b64 == "":
                raise bad_request("invalid_request", "data_base64 is required")
            content_type = body.get("content_type") if isinstance(body.get("content_type"), str) else "application/octet-stream"
            if content_type not in _ACCEPTED_RESUME_TYPES and not _RESUME_EXTENSION_RE.search(filename):
                raise HttpError(415, "unsupported_format", f"{content_type} is not an accepted resume format; upload a pdf, docx, txt or md file")

            try:
                data = base64.b64decode(data_b64, validate=True)
            except (binascii.Error, ValueError) as err:
                raise bad_request("invalid_request", "data_base64 is not valid base64") from err
            if len(data) == 0:
                raise bad_request("invalid_request", "data_base64 decoded to zero bytes")
            if len(data) > config.max_resume_bytes:
                raise HttpError(413, "file_too_large", f"resume is {len(data)} bytes; the limit is {config.max_resume_bytes}")

            # Replacing a resume hard-deletes the previous one rather than
            # orphaning it in storage (§8).
            if session.resume_ref:
                await storage.files.delete(session.resume_ref)

            stored = await storage.files.put(session_id=session.id, filename=filename, content_type=content_type, data=data)
            await storage.sessions.patch(session.id, {"resume_ref": stored.ref})

            profiled = await harness.profile_resume(session.id)

            return {
                "resume": {"filename": stored.filename, "size_bytes": stored.size_bytes, "uploaded_at": stored.uploaded_at},
                "jd_fit": profiled["jd_fit"],
                "topic_relevance": profiled["topic_relevance"],
            }
        except Exception as err:  # noqa: BLE001
            raise _to_http_error(err)

    @router.delete("/{session_id}/resume")
    async def delete_resume(session_id: str, claims: AuthTokenClaims = Depends(require_role("student"))):
        """Hard-deletes the stored file (§8). The structured profile
        survives, so a configured session still works."""
        try:
            session = await _load_owned_session(session_id, claims)
            if not session.resume_ref:
                raise not_found("no resume uploaded for this session")
            deleted = await harness.delete_resume(session.id)
            return {"deleted": deleted}
        except Exception as err:  # noqa: BLE001
            raise _to_http_error(err)

    @router.get("/{session_id}/jd-fit")
    async def get_jd_fit(session_id: str, claims: AuthTokenClaims = Depends(get_auth_claims)):
        """For the Interview Config page. Informational: it never gates
        starting the interview (soul.md §3)."""
        try:
            session = await _load_owned_session(session_id, claims)
            profile = session.candidate_profile
            return {
                "jd_fit": _jd_fit_to_wire(session.jd_fit) if session.jd_fit else None,
                "topic_relevance": [
                    {"topic": t.topic, "relevance_score": t.relevance_score, "evidence": t.evidence}
                    for t in (profile.topic_relevance if profile else [])
                ],
                "seniority_estimate": profile.seniority_estimate if profile else None,
                "note": "This shows what the interview will focus on. A low score means expect more questions in the gap areas — it is not a judgement on whether to apply.",
                "blocks_start": False,
            }
        except Exception as err:  # noqa: BLE001
            raise _to_http_error(err)

    @router.post("/{session_id}/begin")
    async def begin(session_id: str, claims: AuthTokenClaims = Depends(require_role("student"))):
        """CALIBRATION (build the topic plan) then QUESTION_LOOP. The
        device-check gate is enforced inside the harness."""
        try:
            session = await _load_owned_session(session_id, claims)
            started = await harness.begin_interview(session.id)
            return {"state": started.state, "topic_plan": started.topic_plan}
        except Exception as err:  # noqa: BLE001
            raise _to_http_error(err)

    @router.get("/{session_id}/questions/next")
    async def next_question(session_id: str, claims: AuthTokenClaims = Depends(require_role("student"))):
        """One turn of the loop."""
        try:
            session = await _load_owned_session(session_id, claims)
            result = await harness.next_question(session.id)

            if result.done:
                return {"done": True, "note": result.note, "asked_count": result.asked_count, "question_budget": result.question_budget}

            q = result.question
            body: dict[str, Any] = {
                "done": False,
                "question": {
                    "id": q.id,
                    "text": q.text,
                    "topic": q.topic,
                    "type": q.type,
                    "difficulty": q.difficulty,
                    # Set by the Harness Agent via the Speech Service before
                    # the question reaches the frontend (§4.1); null when
                    # synthesis failed and the candidate reads it instead.
                    "audio_url": q.audio_url,
                },
                "asked_count": result.asked_count,
                "question_budget": result.question_budget,
            }
            if q.tier is not None:
                body["question"]["tier"] = q.tier
            if result.speech_note:
                body["speech_note"] = result.speech_note
            return body
        except Exception as err:  # noqa: BLE001
            raise _to_http_error(err)

    @router.post("/{session_id}/answers", status_code=201)
    async def submit_answer(session_id: str, request: Request, claims: AuthTokenClaims = Depends(require_role("student"))):
        """Typed answers. F7 adds the audio path; this stays as the fallback
        when transcription confidence is low."""
        try:
            session = await _load_owned_session(session_id, claims)
            body = await request.json()
            question_id = body.get("question_id")
            transcript = body.get("transcript")
            if not isinstance(question_id, str):
                raise bad_request("invalid_request", "question_id is required")
            if not isinstance(transcript, str):
                raise bad_request("invalid_request", "transcript is required")

            confidence = body.get("transcript_confidence")
            result = await harness.submit_answer(
                session_id=session.id, question_id=question_id, transcript=transcript, transcript_confidence=confidence if isinstance(confidence, (int, float)) else None
            )

            # (§3) A request to repeat or clarify. No `Answer` was written and
            # nothing was scored, so this cannot be shaped like an answer
            # response — `answered: false` and the same `question_id` say the
            # turn has not moved, and there is deliberately no `answer_id` for
            # a caller to hang a follow-up off.
            if isinstance(result, MetaUtteranceResult):
                return {
                    "answered": False,
                    "clarification": {"kind": result.kind, "question_id": result.question_id, "text": result.text, "audio_url": result.audio_url},
                    **({"speech_note": result.speech_note} if result.speech_note else {}),
                }

            response: dict[str, Any] = {
                "answered": True,
                "answer_id": result.answer.id,
                # Null when the Eval Tool refused to score; `evaluation_note`
                # says why, rather than a low score being invented.
                "evaluation": result.evaluation,
                "follow_up": ({"text": result.follow_up.text, "reason": result.follow_up.reason, "audio_url": result.follow_up.audio_url} if result.follow_up else None),
            }
            if result.evaluation_note:
                response["evaluation_note"] = result.evaluation_note
            # (§1) On this route the acknowledgment arrives with everything
            # else — there is no socket to push it down ahead of the rest. The
            # live channel is where the two-stage timing actually happens.
            if result.acknowledgment:
                response["acknowledgment"] = {"text": result.acknowledgment.text, "audio_url": result.acknowledgment.audio_url}
            if result.struggle_signal:
                response["struggle_signal"] = result.struggle_signal
            if result.extraction:
                response["anti_patterns_detected"] = result.extraction.anti_patterns_detected
                response["verified_concept_ids"] = result.extraction.verified_concept_ids
                response["unverified_concept_ids"] = result.extraction.unverified_concept_ids
            if result.next_action:
                response["next_action"] = result.next_action.system_directive
            if result.live_session_state:
                lss = result.live_session_state
                response["live_session_state"] = {
                    "session_id": lss.session_id,
                    "candidate_id": lss.candidate_id,
                    "active_topic_id": lss.active_topic_id,
                    "session_metrics": {
                        "elapsed_time_seconds": lss.session_metrics.elapsed_time_seconds,
                        "topic_competency_score": lss.session_metrics.topic_competency_score,
                        "current_demonstrated_tier": lss.session_metrics.current_demonstrated_tier,
                    },
                    "context_engine": {"active_resume_anchor": lss.context_engine.active_resume_anchor, "last_delivered_prompt": lss.context_engine.last_delivered_prompt},
                    "extraction_processor": {
                        "transcribed_input_chunk": lss.extraction_processor.transcribed_input_chunk,
                        "verified_concept_ids": lss.extraction_processor.verified_concept_ids,
                        "unverified_concept_ids": lss.extraction_processor.unverified_concept_ids,
                        "anti_patterns_detected": lss.extraction_processor.anti_patterns_detected,
                    },
                    "next_action_generator": {
                        "system_directive": lss.next_action_generator.system_directive,
                        "transition_style": lss.next_action_generator.transition_style,
                        "target_concept_id_for_next_prompt": lss.next_action_generator.target_concept_id_for_next_prompt,
                        "synthesized_framing_strategy": lss.next_action_generator.synthesized_framing_strategy,
                        "generated_follow_up_prompt": lss.next_action_generator.generated_follow_up_prompt,
                        # (Stage 13) Where the interview is going next, and the
                        # score band that decided it. Serialised alongside the
                        # directive rather than instead of it: the directive
                        # says WHAT kind of move, these say WHICH one.
                        "next_topic": lss.next_action_generator.next_topic,
                        "next_tier": lss.next_action_generator.next_tier,
                        "routing_rationale": lss.next_action_generator.routing_rationale,
                    },
                }
            return response
        except Exception as err:  # noqa: BLE001
            raise _to_http_error(err)

    @router.post("/{session_id}/answers/{answer_id}/follow-up", status_code=201)
    async def submit_follow_up(session_id: str, answer_id: str, request: Request, claims: AuthTokenClaims = Depends(require_role("student"))):
        """The reply to a probe."""
        try:
            session = await _load_owned_session(session_id, claims)
            body = await request.json()
            follow_up_text = body.get("follow_up_text")
            transcript = body.get("transcript")
            if not isinstance(follow_up_text, str) or not isinstance(transcript, str):
                raise bad_request("invalid_request", "follow_up_text and transcript are required")

            # Owning session `:id` is not the same as owning answer
            # `:answer_id`. An answer from another session is reported as
            # "unknown" rather than "forbidden", so this route cannot be
            # used to probe which answer ids exist.
            answer = await storage.answers.get(answer_id)
            question = await storage.questions.get(answer.question_id) if answer else None
            if not answer or not question or question.session_id != session.id:
                raise not_found("unknown answer")

            updated = await harness.submit_follow_up_answer(session_id=session.id, answer_id=answer.id, follow_up_text=follow_up_text, transcript=transcript)
            return {"follow_ups": len(updated.follow_ups)}
        except Exception as err:  # noqa: BLE001
            raise _to_http_error(err)

    @router.get("/{session_id}/transcript")
    async def get_transcript(session_id: str, claims: AuthTokenClaims = Depends(get_auth_claims)):
        """What was asked and answered, for the review screen. Owner or admin only."""
        try:
            session = await _load_owned_session(session_id, claims)
            questions = await storage.questions.list_by_session(session.id)
            transcript = []
            for question in questions:
                answer = await storage.answers.get_by_question(question.id)
                transcript.append(
                    {
                        "question": {"id": question.id, "text": question.text, "topic": question.topic, "type": question.type},
                        "answer": ({"transcript": answer.transcript, "follow_ups": answer.follow_ups, "submitted_at": answer.submitted_at} if answer else None),
                        "evaluations": (await storage.evaluations.list_by_answer(answer.id) if answer else []),
                    }
                )
            return {"state": session.state, "topic_plan": session.topic_plan, "transcript": transcript}
        except Exception as err:  # noqa: BLE001
            raise _to_http_error(err)

    return router

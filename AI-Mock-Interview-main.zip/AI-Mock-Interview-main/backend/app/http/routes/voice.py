"""Voice routes — ~ apps/gateway/src/http/routes/voice.ts.

The Stage 2 pattern holds: these handlers check ownership, hand off to the
Harness Agent, and shape the reply. The one thing they add is the
low-confidence contract: when transcription is not trusted, the response is
a `202` carrying a retry instruction and (when available) a draft for the
candidate to correct. Deliberately not `201` (nothing was accepted) and not
`4xx` (the candidate did nothing wrong).

F7 scope: spoken answers, serving synthesised audio, paste/focus events, and
wrap-up. Coding round + report routes land in F8/F9.
"""

from __future__ import annotations

import base64
import binascii
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, Depends, Request, Response

from app.agents.harness.harness import HarnessAgent, TransitionRejected
from app.agents.harness.interview import MetaUtteranceResult
from app.config import GatewayConfig
from app.http.errors import HttpError, bad_request, not_found
from app.http.middleware.auth import assert_owns_or_admin, get_auth_claims, require_role
from app.shared_types import AuthTokenClaims, McpHandlerError
from app.storage.types import Storage


def _to_http_error(err: Exception) -> HttpError:
    if isinstance(err, McpHandlerError):
        if err.code in ("consent_missing", "consent_invalid"):
            return HttpError(403, err.code, err.message)
        if err.code == "no_active_round":
            return HttpError(409, err.code, err.message)
        if err.code in ("unsupported_language", "insufficient_transcript", "insufficient_evidence"):
            return HttpError(422, err.code, err.message)
        return HttpError(502, err.code, err.message)
    if isinstance(err, TransitionRejected):
        return HttpError(409, "illegal_transition", str(err))
    if isinstance(err, HttpError):
        return err
    raise err


def coding_round_disabled() -> HttpError:
    """The coding round runs candidate code in a Node child inside the backend
    container (audit P0-2), so production keeps it off (`CODING_ROUND_ENABLED`)
    until the sandbox has its own container. A 404 with its own code, not a
    500: the route is simply not offered."""
    return HttpError(404, "coding_round_disabled", "the coding round is not available on this deployment")


def voice_routes(*, storage: Storage, harness: HarnessAgent, config: GatewayConfig) -> APIRouter:
    router = APIRouter()

    async def _load_owned_session(session_id: str, claims: AuthTokenClaims):
        session = await storage.sessions.get(session_id)
        if not session:
            raise not_found("unknown session")
        assert_owns_or_admin(claims, session.candidate_id)
        return session

    @router.post("/{session_id}/answers/audio", status_code=201)
    async def submit_audio_answer(session_id: str, request: Request, response: Response, claims: AuthTokenClaims = Depends(require_role("student"))):
        """A spoken answer."""
        try:
            session = await _load_owned_session(session_id, claims)
            body = await request.json()

            question_id = body.get("question_id")
            if not isinstance(question_id, str):
                raise bad_request("invalid_request", "question_id is required")
            audio_b64 = body.get("audio_base64")
            if not isinstance(audio_b64, str) or audio_b64 == "":
                raise bad_request("invalid_request", "audio_base64 is required")

            try:
                data = base64.b64decode(audio_b64, validate=True)
            except (binascii.Error, ValueError) as err:
                raise bad_request("invalid_request", "audio_base64 is not valid base64") from err
            if len(data) == 0:
                raise bad_request("invalid_request", "audio_base64 decoded to zero bytes")
            if len(data) > config.max_audio_bytes:
                raise HttpError(413, "file_too_large", f"recording exceeds {config.max_audio_bytes} bytes")

            content_type = body.get("content_type") if isinstance(body.get("content_type"), str) else "audio/wav"
            # Stored so the Speech Service can read it by reference; it
            # deletes the blob as soon as a transcript exists, unless the
            # candidate opted into keeping recordings (§8).
            stored = await storage.files.put(session_id=session.id, filename=f"answer-{int(datetime.now(timezone.utc).timestamp() * 1000)}.wav", content_type=content_type, data=data)

            # (STT addition) The client's capture-device hint, whitelisted field
            # by field — this is candidate-controlled input heading into a
            # schema-validated MCP call, and it is only ever a hint: the server
            # runs its own transcript check regardless of what it claims
            # (`tools/speech_service/source.py`).
            device = body.get("input_device")
            input_device: dict[str, Any] = {}
            if isinstance(device, dict):
                if device.get("hint") in ("microphone", "speaker", "unknown"):
                    input_device["hint"] = device["hint"]
                if isinstance(device.get("label"), str) and device["label"].strip():
                    input_device["label"] = device["label"][:200]
                if isinstance(device.get("echo_cancellation"), bool):
                    input_device["echo_cancellation"] = device["echo_cancellation"]

            outcome = await harness.submit_audio_answer(
                session_id=session.id, question_id=question_id, audio_ref=stored.ref, input_device=input_device or None
            )

            if not outcome["accepted"]:
                retry = outcome["retry"]
                response.status_code = 202
                return {
                    "accepted": False,
                    "action": "retry_or_type",
                    # Which of the four refusals this is. The client needs it:
                    # two of them must NOT fall back to the browser's own guess
                    # at what was said (`page.tsx`).
                    "code": retry.code,
                    "reason": retry.reason,
                    "confidence": retry.confidence,
                    # Shown to the candidate to correct. Never scored as-is.
                    "draft_transcript": retry.draft_transcript,
                    "message": "That recording was hard to make out. Say it again, or type what you meant — nothing has been scored yet.",
                }

            result = outcome["result"]

            # (§3) A spoken "sorry, can you repeat that?". The transcript was
            # good enough to act on — hence `accepted` — but it was not an
            # answer, so there is no `answer_id`, no transcript to settle into
            # the thread and nothing scored. `answered: false` is what tells
            # the room the same question is still waiting.
            if isinstance(result, MetaUtteranceResult):
                return {
                    "accepted": True,
                    "answered": False,
                    "clarification": {"kind": result.kind, "question_id": result.question_id, "text": result.text, "audio_url": result.audio_url},
                }

            body_out: dict[str, Any] = {
                "accepted": True,
                "answered": True,
                "answer_id": result.answer.id,
                "transcript": result.answer.transcript,
                "transcript_confidence": result.answer.transcript_confidence,
                "evaluation": result.evaluation,
                "follow_up": ({"text": result.follow_up.text, "reason": result.follow_up.reason, "audio_url": result.follow_up.audio_url} if result.follow_up else None),
            }
            if result.evaluation_note:
                body_out["evaluation_note"] = result.evaluation_note
            # (§1) Arrives with the rest here rather than ahead of it — this
            # route has no channel to push down. The live socket is where the
            # two-stage timing actually happens.
            if result.acknowledgment:
                body_out["acknowledgment"] = {"text": result.acknowledgment.text, "audio_url": result.acknowledgment.audio_url}
            return body_out
        except Exception as err:  # noqa: BLE001
            raise _to_http_error(err)

    @router.get("/{session_id}/audio/{ref:path}")
    async def get_audio(session_id: str, ref: str, claims: AuthTokenClaims = Depends(get_auth_claims)):
        """Serves synthesised question audio. A ref from another session
        must not be readable through this one."""
        try:
            session = await _load_owned_session(session_id, claims)
            stored = await storage.files.get(ref)
            if not stored:
                raise not_found("that audio is no longer available")
            meta, data = stored
            # A ref from another session must not be readable through this one.
            if meta.session_id != session.id:
                raise not_found("that audio is no longer available")

            return Response(content=data, media_type=meta.content_type, headers={"cache-control": "no-store"})
        except Exception as err:  # noqa: BLE001
            raise _to_http_error(err)

    @router.post("/{session_id}/paste-events")
    async def paste_event(session_id: str, request: Request, response: Response, claims: AuthTokenClaims = Depends(require_role("student"))):
        """The frontend reporting a paste. Body carries a timestamp and
        nothing else — there is no field for content (soul.md §5)."""
        try:
            session = await _load_owned_session(session_id, claims)
            body = await request.json() if await request.body() else {}
            timestamp = body.get("timestamp") if isinstance(body.get("timestamp"), str) else datetime.now(timezone.utc).isoformat()

            recorded = await harness.record_paste_event(session.id, timestamp)
            response.status_code = 201 if recorded else 200
            return {"recorded": recorded}
        except Exception as err:  # noqa: BLE001
            raise _to_http_error(err)

    @router.post("/{session_id}/focus-events")
    async def focus_event(session_id: str, request: Request, response: Response, claims: AuthTokenClaims = Depends(require_role("student"))):
        """The frontend reporting a fullscreen exit. Past MAX_FOCUS_EXITS the
        harness has already wrapped the session up by the time this responds."""
        try:
            session = await _load_owned_session(session_id, claims)
            body = await request.json() if await request.body() else {}
            timestamp = body.get("timestamp") if isinstance(body.get("timestamp"), str) else datetime.now(timezone.utc).isoformat()

            outcome = await harness.record_focus_event(session.id, timestamp)
            response.status_code = 201 if outcome["recorded"] else 200
            return {"recorded": outcome["recorded"], "exit_count": outcome["exit_count"], "concluded": outcome["concluded"]}
        except Exception as err:  # noqa: BLE001
            raise _to_http_error(err)

    @router.post("/{session_id}/coding-round", status_code=201)
    async def start_coding_round(session_id: str, claims: AuthTokenClaims = Depends(require_role("student"))):
        """QUESTION_LOOP -> CODING_ROUND."""
        if not config.coding_round_enabled:
            raise coding_round_disabled()
        try:
            session = await _load_owned_session(session_id, claims)
            started = await harness.start_coding_round(session.id)
            spoken = started["spoken"]
            body: dict[str, Any] = {"problem": started["problem"], "clipboard_monitoring": started["clipboard_monitoring"], "audio_url": spoken.audio_url}
            if spoken.speech_note:
                body["speech_note"] = spoken.speech_note
            return body
        except Exception as err:  # noqa: BLE001
            raise _to_http_error(err)

    @router.post("/{session_id}/coding-round/submissions", status_code=201)
    async def submit_code(session_id: str, request: Request, claims: AuthTokenClaims = Depends(require_role("student"))):
        if not config.coding_round_enabled:
            raise coding_round_disabled()
        try:
            session = await _load_owned_session(session_id, claims)
            body = await request.json()
            code = body.get("code")
            if not isinstance(code, str) or code.strip() == "":
                raise bad_request("invalid_request", "code is required")

            language = body.get("language") if isinstance(body.get("language"), str) else None
            talk_through = body.get("talk_through") if isinstance(body.get("talk_through"), str) else None
            return await harness.submit_code(session_id=session.id, code=code, language=language, talk_through=talk_through)
        except Exception as err:  # noqa: BLE001
            raise _to_http_error(err)

    @router.post("/{session_id}/wrap-up")
    async def wrap_up(session_id: str, claims: AuthTokenClaims = Depends(require_role("student"))):
        """The harness's closing message."""
        try:
            session = await _load_owned_session(session_id, claims)
            result = await harness.wrap_up(session.id)
            return {"state": result["session"].state, "message": result["spoken"].text, "audio_url": result["spoken"].audio_url}
        except Exception as err:  # noqa: BLE001
            raise _to_http_error(err)

    @router.post("/{session_id}/report")
    async def create_report(session_id: str, response: Response, claims: AuthTokenClaims = Depends(require_role("student"))):
        """WRAP_UP -> REPORT_GENERATION -> COMPLETED. Compiles and persists
        the report; idempotent, since a report already on file is just
        returned rather than regenerated."""
        try:
            session = await _load_owned_session(session_id, claims)
            existing = await storage.reports.get_by_session(session.id)
            if existing:
                return {"state": session.state, "report": existing}
            result = await harness.generate_report(session.id)
            response.status_code = 201
            return {"state": result["session"].state, "report": result["report"]}
        except Exception as err:  # noqa: BLE001
            raise _to_http_error(err)

    @router.get("/{session_id}/report")
    async def get_report(session_id: str, claims: AuthTokenClaims = Depends(get_auth_claims)):
        """INSTRUCTIONS.md §7: fetch the final report once COMPLETED. A
        plain read; it never triggers generation itself."""
        try:
            session = await _load_owned_session(session_id, claims)
            report = await storage.reports.get_by_session(session.id)
            if not report:
                raise not_found("no report for this session yet")
            return {"state": session.state, "report": report}
        except Exception as err:  # noqa: BLE001
            raise _to_http_error(err)

    return router

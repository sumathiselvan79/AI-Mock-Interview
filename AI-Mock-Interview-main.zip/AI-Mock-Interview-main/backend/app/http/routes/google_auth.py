"""GET /auth/google/start + GET /auth/google/callback (PKCE-based OAuth).
~ apps/gateway/src/http/routes/google-auth.ts.

This is an *identity* path only: it proves "this email belongs to whoever is
sitting at the browser" and then hands the verified email to
`AuthService.identity_login`, the exact same function `POST /auth/dev-login`
calls. Nothing here mints a token, decides a role, or touches RBAC — see
`auth/tokens.py` and `auth/roles.py`, which this route does not modify.
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse, RedirectResponse

from app.auth.google import (
    GoogleAuthClient,
    InvalidGoogleIdTokenError,
    OAuth2RequestError,
    extract_verified_google_profile,
    generate_code_verifier,
    generate_state,
)
from app.auth.service import AuthService, GoogleIdentity
from app.config import GatewayConfig

STATE_COOKIE = "mia_oauth_state"
VERIFIER_COOKIE = "mia_oauth_verifier"


def _set_oauth_cookie(response: Any, name: str, value: str, config: GatewayConfig) -> None:
    response.set_cookie(
        name,
        value,
        max_age=config.oauth_state_ttl_seconds,
        httponly=True,
        samesite="lax",
        secure=config.node_env == "production",
        path="/auth/google",
    )


def _clear_oauth_cookies(response: Any, config: GatewayConfig) -> None:
    for name in (STATE_COOKIE, VERIFIER_COOKIE):
        response.delete_cookie(name, path="/auth/google", secure=config.node_env == "production", samesite="lax")


def _states_match(a: str, b: str) -> bool:
    # Not the point here to be constant-time (the state isn't a secret an
    # attacker is brute-forcing character-by-character over this check);
    # what matters is that a request whose `state` query param doesn't match
    # the httpOnly cookie set at /start is rejected outright — the CSRF
    # defense.
    return a == b


def _error_response(status: int, code: str, message: str, config: GatewayConfig) -> JSONResponse:
    response = JSONResponse(status_code=status, content={"error": {"code": code, "message": message}})
    _clear_oauth_cookies(response, config)
    return response


def google_auth_routes(*, auth: AuthService, config: GatewayConfig, google: GoogleAuthClient) -> APIRouter:
    router = APIRouter()

    @router.get("/google/start")
    async def start():
        state = generate_state()
        code_verifier = generate_code_verifier()
        # "profile" in addition to the identity-only scopes Stage 1 used, so
        # the ID token carries `name`/`picture` for the OAuth profile
        # snapshot (`storage/oauth_profiles.py`). Identity and role
        # resolution never depend on these two claims — only on
        # `email`/`email_verified` — so their absence (a user who declines
        # the profile scope) cannot change login.
        url = google.create_authorization_url(state, code_verifier, ["openid", "email", "profile"])

        response = RedirectResponse(url, status_code=302)
        _set_oauth_cookie(response, STATE_COOKIE, state, config)
        _set_oauth_cookie(response, VERIFIER_COOKIE, code_verifier, config)
        return response

    @router.get("/google/callback")
    async def callback(request: Request):
        # One-shot: the state/verifier cookies are consumed on this request
        # whether it succeeds or fails, so a callback can never be replayed.
        raw_code = request.query_params.get("code")
        raw_state = request.query_params.get("state")
        expected_state = request.cookies.get(STATE_COOKIE)
        code_verifier = request.cookies.get(VERIFIER_COOKIE)

        if not raw_code or not raw_state:
            return _error_response(400, "invalid_oauth_request", "missing code or state", config)
        if not expected_state or not code_verifier:
            return _error_response(400, "invalid_oauth_request", "no OAuth flow in progress for this browser", config)
        if not _states_match(raw_state, expected_state):
            return _error_response(400, "invalid_oauth_state", "state did not match — possible CSRF, request rejected", config)

        try:
            tokens = await google.validate_authorization_code(raw_code, code_verifier)
            profile = extract_verified_google_profile(tokens.id_token, config.google.client_id)
        except OAuth2RequestError as err:
            return _error_response(400, "oauth_exchange_failed", str(err), config)
        except InvalidGoogleIdTokenError as err:
            return _error_response(400, "invalid_id_token", str(err), config)

        # Role is resolved inside identity_login() from the admin-email
        # allowlist — never from anything Google's ID token claims. The
        # `name`/`picture` claims flow through only as far as the OAuth
        # profile snapshot; they never touch identity or role.
        result = await auth.identity_login(
            profile.email,
            GoogleIdentity(provider="google", subject=profile.subject, name=profile.name, avatar_url=profile.picture),
        )

        # The browser lands here directly off Google's redirect, so a JSON
        # body would just be shown at the gateway's own origin — not useful
        # to a candidate. Hand the token to the SPA instead via a redirect
        # back to it, in the URL fragment rather than a query string:
        # fragments are never sent to a server (this one included) on that
        # next navigation, only read by the frontend's own JS
        # (apps/web/app/auth/callback).
        redirect_url = f"{config.frontend_url}/auth/callback#token={result['token']}&role={result['user'].role}"
        response = RedirectResponse(redirect_url, status_code=302)
        _clear_oauth_cookies(response, config)
        return response

    return router

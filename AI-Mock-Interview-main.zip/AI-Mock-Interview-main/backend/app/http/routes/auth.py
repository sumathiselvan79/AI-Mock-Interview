"""~ apps/gateway/src/http/routes/auth.ts."""

from __future__ import annotations

import re

from fastapi import APIRouter, Request, Response

from app.auth.passcode import WeakPasscodeError
from app.auth.service import AuthError, AuthService
from app.http.errors import HttpError
from app.http.rate_limit import enforce_auth_rate_limit
from app.http.routes.validate import optional_string, require_string
from app.shared_types import UserProfile

_ALREADY_EXISTS = re.compile(r"already exists", re.IGNORECASE)


def auth_routes(auth: AuthService) -> APIRouter:
    router = APIRouter()

    @router.post("/register", status_code=201)
    async def register(request: Request, response: Response):
        """Self-service signup (INSTRUCTIONS.md §7, Stage 3). The role is
        hardcoded to "student" and is never read from the request — there is
        no self-service path to `admin` (§3.2)."""
        body = await request.json()
        email = require_string(body, "email")
        passcode = require_string(body, "passcode")
        await enforce_auth_rate_limit(request, "register")

        # (Stage 5, §11.4) Profile fields collected here because archiving
        # refuses without `fullName`. Optional so an existing flow (or an
        # OAuth identity) is not broken; PATCH /me/profile is the catch-up path.
        try:
            profile = UserProfile(
                full_name=optional_string(body, "full_name"),
                department=optional_string(body, "department"),
                program_year=optional_string(body, "program_year"),
            )
            user = await auth.create_user(email=email, passcode=passcode, role="student", profile=profile)
        except WeakPasscodeError as err:
            raise HttpError(400, err.code, str(err)) from err
        except ValueError as err:
            if _ALREADY_EXISTS.search(str(err)):
                # Deliberately not "that email is taken" — that would confirm
                # which addresses have accounts to anyone who asks.
                raise HttpError(
                    409,
                    "registration_failed",
                    "could not create an account with those details; try signing in or resetting your passcode",
                ) from err
            raise

        result = await auth.login(email, passcode)
        return {"token": result["token"], "user": user}

    @router.post("/login")
    async def login(request: Request):
        """Returns a role-scoped token (INSTRUCTIONS.md §7)."""
        body = await request.json()
        email = require_string(body, "email")
        passcode = require_string(body, "passcode")
        # Before the scrypt verify, so a throttled guess costs nothing.
        await enforce_auth_rate_limit(request, "login", email)
        try:
            result = await auth.login(email, passcode)
        except AuthError as err:
            raise HttpError(401, err.code, str(err)) from err
        return {"token": result["token"], "user": result["user"]}

    @router.post("/reset-passcode/request", status_code=202)
    async def reset_request(request: Request):
        """Always 202, so it cannot be used to probe which email addresses have accounts."""
        body = await request.json()
        email = require_string(body, "email")
        await enforce_auth_rate_limit(request, "reset_request", email)
        await auth.request_passcode_reset(email)
        return {"status": "accepted", "message": "if an account exists for that address, a reset link has been sent"}

    @router.post("/reset-passcode/confirm")
    async def reset_confirm(request: Request):
        """Consumes the single-use token."""
        body = await request.json()
        token = require_string(body, "token")
        passcode = require_string(body, "passcode")
        await enforce_auth_rate_limit(request, "reset_confirm")
        try:
            await auth.confirm_passcode_reset(token, passcode)
        except WeakPasscodeError as err:
            raise HttpError(400, err.code, str(err)) from err
        except AuthError as err:
            raise HttpError(400, err.code, str(err)) from err
        return {"status": "ok"}

    return router


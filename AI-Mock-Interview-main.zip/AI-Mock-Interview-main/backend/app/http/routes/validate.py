"""~ apps/gateway/src/http/routes/validate.ts — request body helpers.

Operates on a plain parsed-JSON dict, the same shape `req.body` had on the
Express side, so route handlers read identically to their TS counterparts.
"""

from __future__ import annotations

from typing import Any, Optional

from app.http.errors import bad_request


def require_string(body: Any, field_name: str) -> str:
    value = (body or {}).get(field_name) if isinstance(body, dict) else None
    if not isinstance(value, str) or value.strip() == "":
        raise bad_request("invalid_request", f"{field_name} is required")
    return value


def optional_string(body: Any, field_name: str) -> Optional[str]:
    """A non-empty string if present, `None` if absent or blank. Rejects a
    non-string outright rather than coercing — a caller sending
    `{"full_name": 42}` has a bug, and silently storing "42" would hide it."""
    value = (body or {}).get(field_name) if isinstance(body, dict) else None
    if value is None:
        return None
    if not isinstance(value, str):
        raise bad_request("invalid_request", f"{field_name} must be a string")
    trimmed = value.strip()
    return trimmed if trimmed != "" else None

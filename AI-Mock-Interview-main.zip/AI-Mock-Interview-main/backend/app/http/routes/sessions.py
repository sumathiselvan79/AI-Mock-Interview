"""Session routes — ~ apps/gateway/src/http/routes/sessions.ts. INSTRUCTIONS.md §7.

Every route that changes `Session.state` goes through the Harness Agent; the
routes themselves never touch it. F4 exposes the transitions explicitly
(`POST /sessions/:id/advance`) exactly as TS Stage 1 did, because there is no
agent intelligence yet to decide them; later stages drive the same harness
method from agent results instead of from the client.

Resume upload / the question loop (~ interview.ts) mount under the same
`/sessions/{id}` prefix once Stage F5+ lands — see `sessions_router()`'s
`extra_routers` parameter.
"""

from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, Request

from app.agents.harness.harness import HarnessAgent, TransitionRejected
from app.agents.harness.state_machine import allowed_next_states
from app.auth.tokens import issue_session_token
from app.config import GatewayConfig
from app.http.errors import HttpError, bad_request, not_found
from app.http.middleware.auth import assert_owns_or_admin, get_auth_claims, require_role
from app.shared_types import (
    MAX_QUESTION_BUDGET,
    MIN_QUESTION_BUDGET,
    SESSION_STATES,
    AuthTokenClaims,
    SessionConsent,
    SessionState,
)
from app.shared_types.scheduling import effective_status, is_startable, runs_coding_round
from app.shared_types.session import is_valid_question_budget
from app.storage.types import Storage


def sessions_router(
    *, storage: Storage, harness: HarnessAgent, config: GatewayConfig, extra_routers: Optional[list[APIRouter]] = None
) -> APIRouter:
    router = APIRouter()

    @router.post("", status_code=201)
    async def create_session(request: Request, claims: AuthTokenClaims = Depends(require_role("student"))):
        """Students only. An Admin cannot start an interview as a candidate (INSTRUCTIONS.md §3.2)."""
        body = await request.json() if await request.body() else {}

        # (Stage 7) Starting an Admin-assigned interview. The schedule is
        # session-SEED data and nothing more.
        schedule = None
        scheduled_interview_id = body.get("scheduled_interview_id")
        if scheduled_interview_id is not None:
            if not isinstance(scheduled_interview_id, str):
                raise bad_request("invalid_request", "scheduled_interview_id must be a string")
            schedule = await storage.scheduled.get(scheduled_interview_id)
            # Reported as "unknown" rather than "forbidden" when it belongs to
            # someone else, so this cannot be used to enumerate assignment ids.
            if not schedule or schedule.candidate_id != claims.sub:
                raise not_found("unknown scheduled interview")
            if not is_startable(schedule.status, schedule.scheduled_for, schedule.deadline):
                status = effective_status(schedule.status, schedule.scheduled_for, schedule.deadline)
                raise HttpError(409, "not_startable", f"this interview is {status} — it cannot be started right now")

        role = body.get("role") if isinstance(body.get("role"), str) and body.get("role").strip() else None
        role = role or (schedule.role if schedule else None)
        if not isinstance(role, str) or role.strip() == "":
            raise bad_request("invalid_request", "role is required")

        question_budget = body.get("question_budget")
        if question_budget is not None and not is_valid_question_budget(question_budget):
            raise bad_request(
                "invalid_request",
                f"question_budget must be a whole number between {MIN_QUESTION_BUDGET} and {MAX_QUESTION_BUDGET}",
            )

        job_description = body.get("job_description")
        if not isinstance(job_description, str):
            job_description = schedule.job_description if schedule else ""

        session = await storage.sessions.create(
            candidate_id=claims.sub,
            role=role,
            job_description=job_description,
            question_budget=question_budget if is_valid_question_budget(question_budget) else None,
        )

        # Session-scoped token required on every MCP call for this session (§2).
        session_token = issue_session_token(session.id, config.auth_token_secret)
        await storage.live.set_session_token(session.id, session_token)

        await storage.telemetry.emit(
            "session_created",
            session.id,
            {"candidate_id": session.candidate_id, "role": session.role, "question_budget": session.question_budget},
        )

        # Claimed AFTER the session exists, so a failed create never leaves an
        # assignment marked started with nothing behind it.
        if schedule:
            await storage.scheduled.update(schedule.id, {"status": "started", "session_id": session.id})
            await storage.telemetry.emit(
                "scheduled_interview_started",
                session.id,
                {"candidate_id": session.candidate_id, "scheduled_interview_id": schedule.id},
            )

        result = {"session_id": session.id, "state": session.state, "session_token": session_token}
        if schedule:
            result["scheduled"] = {
                "id": schedule.id,
                "role": schedule.role,
                "job_description": schedule.job_description,
                "interview_type": schedule.interview_type,
                "difficulty": schedule.difficulty,
                "duration_minutes": schedule.duration_minutes,
                "runs_coding_round": runs_coding_round(schedule.interview_type, schedule.coding_round_enabled),
            }
        return result

    @router.get("/{session_id}")
    async def get_session(session_id: str, claims: AuthTokenClaims = Depends(get_auth_claims)):
        session = await storage.sessions.get(session_id)
        if not session:
            raise not_found("unknown session")
        assert_owns_or_admin(claims, session.candidate_id)
        return {"session": session, "allowed_next_states": allowed_next_states(session.state)}

    @router.get("/{session_id}/transitions")
    async def get_transitions(session_id: str, claims: AuthTokenClaims = Depends(get_auth_claims)):
        """The audit trail behind Stage 1 gate test 3: every row's actor is the harness."""
        session = await storage.sessions.get(session_id)
        if not session:
            raise not_found("unknown session")
        assert_owns_or_admin(claims, session.candidate_id)
        return {"transitions": await storage.sessions.transitions(session.id)}

    @router.post("/{session_id}/advance")
    async def advance(session_id: str, request: Request, claims: AuthTokenClaims = Depends(require_role("student"))):
        """Asks the Harness Agent to move the session. The handler has no
        authority of its own: an illegal move, or one gated behind an
        unpassed telemetry check, comes back as a 409 from the harness."""
        session = await storage.sessions.get(session_id)
        if not session:
            raise not_found("unknown session")
        assert_owns_or_admin(claims, session.candidate_id)

        body = await request.json()
        to_state = body.get("to")
        if not isinstance(to_state, str) or to_state not in SESSION_STATES:
            raise bad_request("invalid_request", f"to must be one of: {', '.join(SESSION_STATES)}")

        reason = body.get("reason") if isinstance(body.get("reason"), str) else "client_advance"
        try:
            updated = await harness.transition(session.id, to_state, reason)  # type: ignore[arg-type]
        except TransitionRejected as err:
            raise HttpError(409, "illegal_transition", str(err)) from err
        return {"session": updated, "allowed_next_states": allowed_next_states(updated.state)}

    @router.post("/{session_id}/telemetry-check")
    async def telemetry_check(
        session_id: str, request: Request, claims: AuthTokenClaims = Depends(require_role("student"))
    ):
        """Records the device check and the per-session consent flags.
        Nothing downstream may start until this passes (INSTRUCTIONS.md §3)."""
        session = await storage.sessions.get(session_id)
        if not session:
            raise not_found("unknown session")
        assert_owns_or_admin(claims, session.candidate_id)

        body = await request.json()
        mic_ok = body.get("mic_ok") is True
        speaker_ok = body.get("speaker_ok") is True
        passed = mic_ok and speaker_ok

        from datetime import datetime, timezone

        from app.storage.types import DeviceCheckResult

        await storage.live.set_device_check(
            session.id, DeviceCheckResult(passed=passed, mic_ok=mic_ok, speaker_ok=speaker_ok, at=datetime.now(timezone.utc).isoformat())
        )

        raw_consent = body.get("consent") or {}
        consent = SessionConsent(
            telemetry=raw_consent.get("telemetry") is True,
            clipboard_monitor=raw_consent.get("clipboard_monitor") is True,
            audio_recording=raw_consent.get("audio_recording") is True,
            cross_session_memory=raw_consent.get("cross_session_memory") is True,
            focus_loss_monitoring=raw_consent.get("focus_loss_monitoring") is True,
        )
        await storage.sessions.patch(session.id, {"consent": consent})

        await storage.telemetry.emit(
            "device_check_passed" if passed else "device_check_failed",
            session.id,
            {
                "mic_ok": mic_ok,
                "speaker_ok": speaker_ok,
                "consent_telemetry": consent.telemetry,
                "consent_clipboard_monitor": consent.clipboard_monitor,
                "consent_audio_recording": consent.audio_recording,
                "consent_focus_loss_monitoring": consent.focus_loss_monitoring,
            },
        )

        return {"passed": passed, "consent": consent}

    # Interview Config + QUESTION_LOOP (Stage F5+) live under the same prefix.
    for extra in extra_routers or []:
        router.include_router(extra)

    return router

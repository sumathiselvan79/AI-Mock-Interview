"""(Stage 7) Admin user directory, profile drill-down, report download, and
interview scheduling — `ADMIN_FEATURE_PROMPT.md`.
~ apps/gateway/src/http/routes/admin-users.ts.

Mounted under `/admin`, whose router already applies `require_role("admin")`
to every route beneath it. The role gate is therefore declared once, on the
parent router's dependencies, rather than repeated per handler; it is
asserted per handler by the RBAC test instead, which is the check that would
actually catch someone remounting this router somewhere less careful.

The data boundary, restated because this is the file most likely to erode
it: everything served here is either a candidate's own account metadata or
something already inside their `Report`. There is no handler that reads
`session.resume_ref`, `answers.transcript`, or a stored audio blob, and the
wire shapes have no field that could carry one (soul.md §"Admin role").
"""

from __future__ import annotations

import asyncio
import json
from typing import Any, Optional

from fastapi import APIRouter, Depends, Request
from fastapi.encoders import jsonable_encoder
from fastapi.responses import Response

from app.admin.directory import DirectoryInputs, build_directory_page
from app.admin.scheduling import (
    ScheduleInvalid,
    draft_to_rows,
    to_admin_wire,
    validate_draft,
)
from app.http.errors import bad_request, not_found
from app.http.middleware.auth import get_auth_claims
from app.http.session_summaries import session_summaries
from app.shared_types import AuthTokenClaims, User
from app.shared_types.scheduling import (
    DIRECTORY_SORT_KEYS,
    DIRECTORY_STATUSES,
    effective_status,
    mean_competency_score,
)
from app.storage.types import Storage


def _parse_number(value: Any) -> Optional[float]:
    if not isinstance(value, str) or value.strip() == "":
        return None
    try:
        parsed = float(value)
    except ValueError:
        return None
    return parsed if parsed == parsed and parsed not in (float("inf"), float("-inf")) else None


def _parse_query(raw: dict[str, Any]) -> dict[str, Any]:
    """Query-string -> directory query. Unrecognised sort keys and statuses are
    dropped rather than rejected — a stale bookmark should still render the
    directory, just with the default ordering."""
    query: dict[str, Any] = {}

    if isinstance(raw.get("search"), str):
        query["search"] = raw["search"]
    if isinstance(raw.get("department"), str) and raw["department"] != "":
        query["department"] = raw["department"]
    if raw.get("status") in DIRECTORY_STATUSES:
        query["status"] = raw["status"]
    if _parse_number(raw.get("min_score")) is not None:
        query["min_score"] = _parse_number(raw.get("min_score"))
    if _parse_number(raw.get("max_score")) is not None:
        query["max_score"] = _parse_number(raw.get("max_score"))
    if isinstance(raw.get("from"), str) and raw["from"] != "":
        query["from"] = raw["from"]
    if isinstance(raw.get("to"), str) and raw["to"] != "":
        query["to"] = raw["to"]
    if raw.get("sort") in DIRECTORY_SORT_KEYS:
        query["sort"] = raw["sort"]
    if raw.get("direction") in ("asc", "desc"):
        query["direction"] = raw["direction"]
    if _parse_number(raw.get("page")) is not None:
        query["page"] = int(_parse_number(raw.get("page")))
    if _parse_number(raw.get("page_size")) is not None:
        query["page_size"] = int(_parse_number(raw.get("page_size")))

    return query


def _attachment(payload: Any, filename: str) -> Response:
    """A JSON attachment, following the precedent set by the archive download
    rather than adding a PDF toolchain for one button.

    Encoded through `jsonable_encoder` rather than `json.dumps` on the raw
    model so the downloaded document is byte-for-byte what the equivalent GET
    would have returned — including the camelCase aliases (`competencyScores`,
    not `competency_scores`) `apps/web` already reads.
    """
    return Response(
        content=json.dumps(jsonable_encoder(payload), indent=2),
        media_type="application/json",
        headers={"content-disposition": f'attachment; filename="{filename}"'},
    )


def admin_user_routes(storage: Storage) -> APIRouter:
    router = APIRouter()

    async def _directory_inputs() -> DirectoryInputs:
        """Everything the directory needs, in a fixed number of queries
        regardless of how many candidates there are: accounts, report
        aggregates, open schedules, session counts. Avatars are the one
        per-user read, and only for the rows actually being returned — see the
        note at the call site."""
        students, report_stats, scheduled_ids, session_counts = await asyncio.gather(
            storage.users.list_by_role("student"),
            storage.reports.aggregate_by_candidate(),
            storage.scheduled.candidates_with_open_schedules(),
            storage.sessions.counts_by_candidate(),
        )
        return DirectoryInputs(
            students=students,
            report_stats=report_stats,
            scheduled_candidate_ids=scheduled_ids,
            session_counts=session_counts,
        )

    async def _avatars_for(user_ids: list[str]) -> dict[str, str]:
        """Avatars for a bounded set of user ids.

        `OAuthProfileStore` is keyed by user id with no bulk read, and it lives
        in the separate Supabase instance — so this is done for one PAGE of
        rows (25 by default), after filtering and paging, rather than for every
        account in the system. That keeps it off the N+1 path the spec rules
        out: the cost is bounded by page size, not by directory size.
        """
        if not storage.oauth_profiles:
            return {}
        profiles = await asyncio.gather(
            *(storage.oauth_profiles.get_by_user_id(uid) for uid in user_ids)
        )
        return {
            uid: profile.avatar_url
            for uid, profile in zip(user_ids, profiles)
            if profile is not None and profile.avatar_url
        }

    @router.get("/users")
    async def list_users(request: Request):
        """GET /admin/users — the directory. Search, filter, sort, server-side paging."""
        inputs = await _directory_inputs()
        query = _parse_query(dict(request.query_params))

        # Paged first, then avatars, so the avatar lookups are bounded by page
        # size rather than by the number of accounts.
        paged = build_directory_page(inputs, query)
        avatars = await _avatars_for([r.user_id for r in paged.rows])

        return {
            "rows": [
                {
                    "user_id": row.user_id,
                    "email": row.email,
                    "full_name": row.full_name,
                    "department": row.department,
                    "avatar_url": avatars.get(row.user_id),
                    "interviews_completed": row.interviews_completed,
                    "average_score": row.average_score,
                    "last_interview_at": row.last_interview_at,
                    "created_at": row.created_at,
                    "status": row.status,
                }
                for row in paged.rows
            ],
            "total": paged.total,
            "page": paged.page,
            "page_size": paged.page_size,
            # So the filter dropdown offers what candidates actually put in the
            # free-text column, not only the canonical list.
            "departments": sorted({s.department for s in inputs.students if s.department}),
        }

    @router.get("/users/{user_id}")
    async def get_user(user_id: str):
        """GET /admin/users/:userId — the profile drill-down."""
        user = await storage.users.find_by_id(user_id)
        # An Admin is not a candidate and has no interview history; treating
        # them as "not found" here keeps the directory and this page consistent.
        if not user or user.role != "student":
            raise not_found("unknown student")

        sessions, reports = await asyncio.gather(
            storage.sessions.list_by_candidate(user_id),
            storage.reports.list_by_candidate(user_id),
        )
        profile = await storage.oauth_profiles.get_by_user_id(user_id) if storage.oauth_profiles else None

        # Built by the shared helper, because the candidate's own Home page
        # lists the same history from `GET /me/sessions`.
        summaries = session_summaries(sessions, reports)

        # Oldest first: a trend line reads left to right.
        score_trend = []
        for report in sorted(reports, key=lambda r: r.created_at):
            score = mean_competency_score([c.score for c in report.competency_scores])
            if score is not None:
                score_trend.append({"at": report.created_at, "score": score})

        return {
            "profile": {
                "user_id": user.id,
                "email": user.email,
                "full_name": user.full_name,
                "department": user.department,
                "program_year": user.program_year,
                "avatar_url": profile.avatar_url if profile else None,
                "created_at": user.created_at,
                "interviews_completed": len(reports),
                "average_score": (
                    sum(p["score"] for p in score_trend) / len(score_trend) if score_trend else None
                ),
                # `list_by_candidate` returns newest first.
                "last_interview_at": reports[0].created_at if reports else None,
                "score_trend": score_trend,
            },
            "sessions": summaries,
            "scheduled": [to_admin_wire(s) for s in await storage.scheduled.list_by_candidate(user_id)],
        }

    @router.get("/users/{user_id}/reports/download")
    async def download_user_reports(user_id: str, claims: AuthTokenClaims = Depends(get_auth_claims)):
        """Every report this candidate has, as one JSON attachment.

        The payload is the stored `Report` objects verbatim — which is exactly
        the boundary, since a `Report` has no resume, audio or transcript field
        to leak.
        """
        user = await storage.users.find_by_id(user_id)
        if not user or user.role != "student":
            raise not_found("unknown student")

        reports = await storage.reports.list_by_candidate(user_id)
        if not reports:
            raise not_found("this candidate has no reports yet")

        await storage.telemetry.emit(
            "admin_reports_downloaded",
            None,
            {"admin_id": claims.sub, "candidate_id": user_id, "reports": len(reports)},
        )
        return _attachment({"candidate_id": user_id, "reports": reports}, f"reports-{user_id}.json")

    @router.get("/reports/{session_id}/download")
    async def download_report(session_id: str, claims: AuthTokenClaims = Depends(get_auth_claims)):
        """One report as an attachment."""
        report = await storage.reports.get_by_session(session_id)
        if not report:
            raise not_found("no report for that session")

        await storage.telemetry.emit(
            "admin_reports_downloaded",
            session_id,
            {"admin_id": claims.sub, "candidate_id": report.candidate_id, "reports": 1},
        )
        return _attachment(report, f"report-{session_id}.json")

    # ------------------------------------------------------------- scheduling

    @router.get("/scheduled-interviews")
    async def list_scheduled():
        """Everything, newest window first."""
        schedules = await storage.scheduled.list()
        students = await storage.users.list_by_role("student")
        by_id = {s.id: s for s in students}

        return {
            "scheduled": [
                {
                    **to_admin_wire(schedule),
                    # Denormalised for display so the list does not need a
                    # second call per row just to render a name.
                    "candidate_email": by_id[schedule.candidate_id].email if schedule.candidate_id in by_id else None,
                    "candidate_name": by_id[schedule.candidate_id].full_name if schedule.candidate_id in by_id else None,
                }
                for schedule in schedules
            ]
        }

    @router.post("/scheduled-interviews", status_code=201)
    async def create_scheduled(request: Request, claims: AuthTokenClaims = Depends(get_auth_claims)):
        """Assign one interview to one or many candidates. A batch writes one
        row per candidate, all or nothing."""
        try:
            draft = validate_draft(await _json_body(request))
        except ScheduleInvalid as err:
            raise bad_request("invalid_schedule", str(err)) from err

        # Every target must exist AND be a student. Scheduling an interview for
        # an Admin is not a thing (INSTRUCTIONS.md §3.2), and a typo'd id must
        # fail loudly rather than create an assignment nobody can ever start.
        candidates: list[User] = []
        for candidate_id in draft.candidate_ids:
            user = await storage.users.find_by_id(candidate_id)
            if not user or user.role != "student":
                raise bad_request("unknown_candidate", f"{candidate_id} is not a student account")
            candidates.append(user)

        created = await storage.scheduled.create_many(draft_to_rows(draft, candidates, claims.sub))

        await storage.telemetry.emit(
            "interviews_scheduled",
            None,
            {
                "admin_id": claims.sub,
                "candidates": len(created),
                "role": draft.role,
                "interview_type": draft.interview_type,
                "scheduled_for": draft.scheduled_for,
            },
        )
        return {"scheduled": [to_admin_wire(s) for s in created]}

    @router.post("/scheduled-interviews/{schedule_id}/cancel")
    async def cancel_scheduled(schedule_id: str, claims: AuthTokenClaims = Depends(get_auth_claims)):
        """Withdraw an assignment.

        Cancelling is terminal and never reverses a candidate's own progress:
        an assignment they already started stays `started`, because the session
        it seeded exists and its report will too.
        """
        existing = await storage.scheduled.get(schedule_id)
        if not existing:
            raise not_found("unknown scheduled interview")
        if existing.status in ("started", "completed"):
            raise bad_request(
                "already_started", "this interview has already been started and cannot be cancelled"
            )

        updated = await storage.scheduled.update(schedule_id, {"status": "cancelled"})
        await storage.telemetry.emit(
            "scheduled_interview_cancelled",
            None,
            {"admin_id": claims.sub, "candidate_id": existing.candidate_id},
        )
        return {"scheduled": to_admin_wire(updated)}

    @router.post("/scheduled-interviews/{schedule_id}/reschedule")
    async def reschedule(schedule_id: str, request: Request):
        """Move the window."""
        existing = await storage.scheduled.get(schedule_id)
        if not existing:
            raise not_found("unknown scheduled interview")
        current = effective_status(existing.status, existing.scheduled_for, existing.deadline)
        if current == "started" or existing.status == "completed":
            raise bad_request("already_started", "this interview has already been started")

        body = await _json_body(request)
        # Reuses the create validator's rules by validating a whole draft, so
        # "deadline must be after scheduled_for" cannot hold on create and be
        # skipped here.
        try:
            draft = validate_draft(
                {
                    "candidate_ids": [existing.candidate_id],
                    "role": existing.role,
                    "interview_type": existing.interview_type,
                    "difficulty": existing.difficulty,
                    "duration_minutes": existing.duration_minutes,
                    "scheduled_for": body.get("scheduled_for"),
                    "deadline": body.get("deadline"),
                }
            )
        except ScheduleInvalid as err:
            raise bad_request("invalid_schedule", str(err)) from err

        updated = await storage.scheduled.update(
            schedule_id,
            {"scheduled_for": draft.scheduled_for, "deadline": draft.deadline, "status": "pending"},
        )
        return {"scheduled": to_admin_wire(updated)}

    return router


async def _json_body(request: Request) -> dict[str, Any]:
    """A parsed JSON object, or `{}` for an absent body — matching Express's
    `req.body ?? {}` so a missing body reaches the validator as "nothing was
    supplied" rather than a parse error."""
    raw = await request.body()
    if not raw:
        return {}
    parsed = json.loads(raw)
    return parsed if isinstance(parsed, dict) else {}

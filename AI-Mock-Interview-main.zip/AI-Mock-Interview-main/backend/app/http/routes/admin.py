"""Admin-only routes (INSTRUCTIONS.md §7) — ~ apps/gateway/src/http/routes/admin.ts.

Admins read `Report` records across candidates and nothing more: no raw
resumes, audio, or transcripts beyond what a report already contains
(soul.md §5, §"Admin role"). A `Report` is exactly that boundary already —
it has no field for a resume, transcript, or audio ref — so serving the
stored record as-is satisfies the access rule without needing a separate
redaction step here.
"""

from __future__ import annotations

import json

from fastapi import APIRouter, Depends
from fastapi.encoders import jsonable_encoder
from fastapi.responses import Response

from app.http.errors import not_found
from app.http.middleware.auth import get_auth_claims, require_role
from app.http.routes.admin_users import admin_user_routes
from app.shared_types import AuthTokenClaims
from app.storage.types import Storage


def admin_routes(storage: Storage) -> APIRouter:
    # The role gate is declared once, on the router, so every route mounted
    # beneath it is admin-only by construction rather than by remembering
    # (~ `router.use(requireRole("admin"))` on the Express side).
    router = APIRouter(dependencies=[Depends(require_role("admin"))])

    # (Stage 7) User directory, profile drill-down, report download and
    # scheduling. Included INSIDE the role gate above (ADMIN_FEATURE_PROMPT.md).
    #
    # Registered BEFORE this router's own `/reports/{session_id}` so the more
    # specific `/reports/{session_id}/download` it declares is matched first —
    # Starlette resolves routes in registration order, and a `{session_id}`
    # path parameter would otherwise never match a two-segment tail anyway,
    # but the ordering also keeps `/users/...` unambiguous.
    router.include_router(admin_user_routes(storage))

    @router.get("/reports")
    async def list_reports():
        """The aggregated Admin Home dashboard (INSTRUCTIONS.md §3.1): every
        candidate's report, independent of whether their session is still
        connected (§4.8)."""
        return {"reports": await storage.reports.list_all()}

    @router.get("/reports/{session_id}")
    async def get_report(session_id: str):
        """One candidate's full report."""
        report = await storage.reports.get_by_session(session_id)
        if not report:
            raise not_found("no report for that session")
        return {"report": report}

    # ---------------------------------------------- (Stage 5) session archives
    #
    # The archive is the one place an Admin sees more than a `Report`, and it
    # is allowed to exist only because of what it is NOT: it is compiled after
    # the retention job, so a transcript the policy already redacted is
    # redacted here too (§11.4, soul.md §5). Access is audited on both routes —
    # a consolidated cross-table document is elevated access, so being
    # permitted is not enough, it must also be recorded (§8).
    #
    # Supabase itself is never exposed to any client: these two routes are the
    # only way in, and they read it server-side through a service-role
    # credential (§8 "Archive access boundary", §11.4).

    @router.get("/archives")
    async def list_archives():
        if not storage.archives:
            raise not_found("archiving is not configured for this deployment")
        return {"archives": await storage.archives.list()}

    @router.get("/archives/{session_id}")
    async def get_archive(session_id: str, claims: AuthTokenClaims = Depends(get_auth_claims)):
        """Metadata only — no `document` body, so the listing view cannot
        become an unaudited way to read transcripts (§7)."""
        if not storage.archives:
            raise not_found("archiving is not configured for this deployment")
        summary = await storage.archives.summary(session_id)
        if not summary:
            raise not_found("no archive for that session")

        await storage.telemetry.emit(
            "archive_viewed", session_id, {"admin_id": claims.sub, "candidate_id": summary.candidate_id}
        )
        return {"archive": summary}

    @router.get("/archives/{session_id}/download")
    async def download_archive(session_id: str, claims: AuthTokenClaims = Depends(get_auth_claims)):
        if not storage.archives:
            raise not_found("archiving is not configured for this deployment")
        archive = await storage.archives.get(session_id)
        if not archive:
            raise not_found("no archive for that session")

        # Emitted BEFORE the body is streamed, so a download that fails midway
        # is still recorded as having been requested. IDs and counts only — the
        # audit trail must not become a second copy of the document (§8).
        await storage.telemetry.emit(
            "archive_downloaded",
            session_id,
            {
                "admin_id": claims.sub,
                "candidate_id": archive.candidate_id,
                "questions": len(archive.document.questions),
                "answers": len(archive.document.answers),
                "archived_at": archive.archived_at,
            },
        )

        return Response(
            content=json.dumps(jsonable_encoder(archive.document), indent=2),
            media_type="application/json",
            headers={"content-disposition": f'attachment; filename="session-{session_id}.json"'},
        )

    return router

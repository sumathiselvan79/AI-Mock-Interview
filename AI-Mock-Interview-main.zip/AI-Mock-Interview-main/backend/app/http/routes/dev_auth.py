"""POST /auth/dev-login — local development convenience only.

~ apps/gateway/src/http/routes/dev-auth.ts.

Mounted by `app/gateway.py` only when `config.dev_auth_enabled` is true,
which itself requires `NODE_ENV != "production"` AND `ALLOW_DEV_AUTH=true`
(config.py). Do not weaken that gate here — this route skips every
credential check.
"""

from __future__ import annotations

from fastapi import APIRouter, Request

from app.auth.service import AuthService
from app.http.routes.validate import require_string


def dev_auth_routes(auth: AuthService) -> APIRouter:
    router = APIRouter()

    @router.post("/dev-login")
    async def dev_login(request: Request):
        body = await request.json()
        email = require_string(body, "email")
        # The request body may include a `role` for the developer's own
        # bookkeeping, but it is never read here. identity_login() resolves
        # the real role from the admin-email allowlist — the same rule every
        # other identity path goes through, so a typed-in "role": "admin"
        # cannot mint an admin token.
        result = await auth.identity_login(email)
        return {"token": result["token"], "user": result["user"]}

    return router

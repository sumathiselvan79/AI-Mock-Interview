"""Student-only routes — ~ apps/gateway/src/http/routes/me.ts.

An admin token is rejected here exactly as a student token is rejected on
/admin/* — the Home page is role-specific by design (INSTRUCTIONS.md §3.1, §3.2).
"""

from __future__ import annotations

import asyncio

from fastapi import APIRouter, Depends, Request

from app.admin.scheduling import to_student_wire
from app.tools.eval.grading import STRENGTH_THRESHOLD
from app.auth.service import AuthService
from app.http.errors import HttpError
from app.http.middleware.auth import require_role
from app.http.routes.validate import optional_string
from app.http.session_summaries import session_summaries
from app.shared_types import AuthTokenClaims, CandidateStats, UserProfile
from app.storage.types import Storage


def _round1(n: float) -> float:
    return round(n * 10) / 10


def me_routes(storage: Storage, auth: AuthService) -> APIRouter:
    router = APIRouter()

    @router.get("/profile")
    async def get_profile(claims: AuthTokenClaims = Depends(require_role("student"))):
        """(Stage 5, §11.4) Lets the frontend tell whether this candidate's
        profile is complete enough for their sessions to be archived."""
        user = await storage.users.find_by_id(claims.sub)
        if not user:
            raise HttpError(404, "unknown_user", "no such account")
        return {
            "profile": {
                "full_name": user.full_name,
                "department": user.department,
                "program_year": user.program_year,
            },
            # `full_name` is the only hard requirement: archiving refuses on
            # it rather than writing a candidate's archive with a blank name.
            "archive_ready": bool(user.full_name),
        }

    @router.patch("/profile")
    async def patch_profile(request: Request, claims: AuthTokenClaims = Depends(require_role("student"))):
        """The catch-up path for an account created before these fields
        existed, or one that skipped them at signup. Only the keys supplied
        are written, so this cannot blank a field the candidate already gave."""
        body = await request.json()
        full_name = optional_string(body, "full_name")
        department = optional_string(body, "department")
        program_year = optional_string(body, "program_year")

        if full_name is None and department is None and program_year is None:
            raise HttpError(400, "invalid_request", "supply at least one of full_name, department, program_year")

        user = await auth.update_profile(
            claims.sub,
            UserProfile(full_name=full_name, department=department, program_year=program_year),
        )
        return {"user": user, "archive_ready": bool(user.full_name)}

    @router.get("/stats")
    async def get_stats(claims: AuthTokenClaims = Depends(require_role("student"))):
        """The student Home page: past interview stats built from real reports
        (INSTRUCTIONS.md §3.1, §7)."""
        candidate_id = claims.sub
        sessions = await storage.sessions.list_by_candidate(candidate_id)
        completed = [s for s in sessions if s.state == "COMPLETED"]
        reports = await storage.reports.list_by_candidate(candidate_id)

        all_scores = [c.score for r in reports for c in r.competency_scores]
        average_score = _round1(sum(all_scores) / len(all_scores)) if all_scores else None

        # "Recurring" means named as a weak spot in more than one report — a
        # single off session is not a pattern worth surfacing back to the
        # candidate (soul.md §"Encouraging rigor").
        weak_counts: dict[str, int] = {}
        for report in reports:
            for competency in report.competency_scores:
                # Prefer the grade the Eval Tool actually assigned; the bare
                # threshold is the fallback for a report written before
                # grading existed, so old history keeps reading the same way.
                weak = not competency.grade.is_strength if competency.grade else competency.score < STRENGTH_THRESHOLD
                if weak:
                    weak_counts[competency.competency] = weak_counts.get(competency.competency, 0) + 1
        recurring_focus_areas = [
            topic for topic, _count in sorted(
                (item for item in weak_counts.items() if item[1] >= 2), key=lambda item: item[1], reverse=True
            )
        ]

        stats = CandidateStats(
            candidate_id=candidate_id,
            sessions_completed=len(completed),
            average_score=average_score,
            last_session_at=sessions[0].created_at if sessions else None,
            recurring_focus_areas=recurring_focus_areas,
        )
        return {"stats": stats, "sessions_started": len(sessions)}

    @router.get("/sessions")
    async def list_sessions(claims: AuthTokenClaims = Depends(require_role("student"))):
        """The candidate's own interview history, for the Home page list.

        Scoped to `claims.sub`, never to a path parameter — there is no
        candidate id on this route to tamper with, so a student cannot read
        another student's history through it.

        The rows are built by the same helper the Admin drill-down uses
        (`app/http/session_summaries.py`), so a candidate and an Admin looking
        at the same interview see the same date, duration and score. That is
        also why nothing is added here: a summary carries only what a `Report`
        already contains, and `has_report` is what gates the View/Download
        buttons rather than a second permission check in the browser.
        """
        candidate_id = claims.sub
        sessions, reports = await asyncio.gather(
            storage.sessions.list_by_candidate(candidate_id),
            storage.reports.list_by_candidate(candidate_id),
        )
        return {"sessions": session_summaries(sessions, reports)}

    @router.get("/scheduled-interviews")
    async def scheduled_interviews(claims: AuthTokenClaims = Depends(require_role("student"))):
        """(Stage 7) What an Admin has assigned to this candidate, for the
        Home page. Cancelled assignments are dropped entirely — an interview
        that was withdrawn is not something to show a candidate and explain."""
        schedules = await storage.scheduled.list_by_candidate(claims.sub)
        return {"scheduled": [to_student_wire(s) for s in schedules if s.status != "cancelled"]}

    return router

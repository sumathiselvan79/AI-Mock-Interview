"""Development-only passthrough to the MCP Gateway.
~ apps/gateway/src/http/routes/mcp.ts.

The frontend never speaks MCP (CLAUDE.md §5) — this route exists so a human
can fire a call by hand and watch the auth / rate-limit / schema / telemetry
path work, which is TRACKING.md Stage 1 gate test 4. It is not mounted in
production (see `create_app`).
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Request
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse

from app.http.errors import bad_request, not_found
from app.http.middleware.auth import assert_owns_or_admin, get_auth_claims
from app.mcp.gateway import McpGateway
from app.shared_types import AuthTokenClaims, McpCallContext
from app.storage.types import Storage


def mcp_routes(mcp: McpGateway, storage: Storage) -> APIRouter:
    router = APIRouter()

    @router.get("/servers")
    async def servers(_claims: AuthTokenClaims = Depends(get_auth_claims)):
        return {"servers": mcp.registered()}

    @router.post("/call")
    async def call(request: Request, claims: AuthTokenClaims = Depends(get_auth_claims)):
        body: Any = await request.json()
        body = body if isinstance(body, dict) else {}

        if not isinstance(body.get("session_id"), str):
            raise bad_request("invalid_request", "session_id is required")
        if not isinstance(body.get("server"), str):
            raise bad_request("invalid_request", "server is required")
        if not isinstance(body.get("method"), str):
            raise bad_request("invalid_request", "method is required")

        session = await storage.sessions.get(body["session_id"])
        if not session:
            raise not_found("unknown session")
        assert_owns_or_admin(claims, session.candidate_id)

        session_token = await storage.live.get_session_token(session.id) or ""
        result = await mcp.call(
            body["server"],
            body["method"],
            body.get("params") or {},
            McpCallContext(
                session_id=session.id,
                caller=body["caller"] if isinstance(body.get("caller"), str) else "harness-agent",
                session_token=session_token,
            ),
        )

        # `McpCallResult` is a `CamelModel`, so this emits the same camelCase
        # envelope (`latencyMs`) the TS gateway returned.
        return JSONResponse(status_code=200 if result.ok else 400, content=jsonable_encoder(result))

    return router

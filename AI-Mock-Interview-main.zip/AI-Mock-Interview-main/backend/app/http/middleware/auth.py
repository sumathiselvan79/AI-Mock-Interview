"""Authentication + role-based access, enforced at the gateway on every
request — not just in the frontend router (INSTRUCTIONS.md §8).

~ apps/gateway/src/http/middleware/auth.ts. FastAPI's dependency-injection
system is the natural home for what Express did via `req.auth` + middleware
chaining: `get_auth_claims` is the `requireAuth` equivalent, and
`require_role(...)` returns a dependency callable the same way the TS
version returns a `RequestHandler`.
"""

from __future__ import annotations

from typing import Callable

from fastapi import Depends, Request

from app.auth.tokens import verify_token
from app.http.errors import forbidden, unauthorized
from app.shared_types import AuthTokenClaims, Role


async def get_auth_claims(request: Request) -> AuthTokenClaims:
    header = request.headers.get("authorization") or ""
    scheme, _, token = header.partition(" ")
    if scheme.lower() != "bearer" or not token:
        raise unauthorized("missing bearer token")
    result = verify_token(token, request.app.state.config.auth_token_secret)
    if not result.ok:
        raise unauthorized(f"token {result.reason}")
    return result.claims


def require_role(*roles: Role) -> Callable[[AuthTokenClaims], AuthTokenClaims]:
    """Role gate. Deliberately symmetric: an admin token is rejected on
    student-only routes exactly as a student token is rejected on /admin/* —
    an Admin cannot start interviews as a candidate (INSTRUCTIONS.md §3.2)."""

    def _dependency(claims: AuthTokenClaims = Depends(get_auth_claims)) -> AuthTokenClaims:
        if claims.role not in roles:
            raise forbidden(f"this route requires role: {' or '.join(roles)}")
        return claims

    return _dependency


def assert_owns_or_admin(claims: AuthTokenClaims, candidate_id: str) -> None:
    """A student may only ever read their own sessions and reports (§8)."""
    if claims.role == "admin":
        return
    if claims.sub != candidate_id:
        raise forbidden("this session belongs to another candidate")

"""One candidate's interview history, as the wire shape both surfaces render.

Two places list a candidate's sessions with a date, a role, a duration, a score
and whether a report exists: the Admin profile drill-down
(`GET /admin/users/:userId`, Stage 7) and the candidate's own Home page
(`GET /me/sessions`). They are the same list read by two roles, so the rule
that shaped it — `duration_minutes` is None while a session is live, the sort
is newest-first tie-broken on id — lives here once rather than being copied
into the second caller and drifting from the first.

This is wire shaping only. It reads `Session` and `Report` records that the
caller has already fetched and authorised; it enforces no access rule of its
own, and it must never grow a field a `Report` does not already contain
(soul.md §"Admin role").
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

from app.shared_types import Report, Session
from app.shared_types.scheduling import mean_competency_score


def history_status(state: str) -> str:
    """`Session.state` collapsed to the three states the history list shows."""
    if state == "COMPLETED":
        return "completed"
    if state == "ABORTED":
        return "abandoned"
    return "in_progress"


def _parse_ts(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def duration_minutes(session: Session) -> Optional[int]:
    """Wall-clock minutes from session creation to its last write.

    None while the session is still running: `updated_at` on a live session is
    "when something last happened", not "when it ended", and reporting that as
    a duration would show a number that shrinks and grows as the page is
    reloaded.
    """
    if history_status(session.state) == "in_progress":
        return None
    ms = (_parse_ts(session.updated_at) - _parse_ts(session.created_at)).total_seconds() * 1000
    return round(ms / 60_000) if ms > 0 else 0


def session_summaries(sessions: list[Session], reports: list[Report]) -> list[dict[str, Any]]:
    """The history rows, newest first.

    The tie-break on id is not defensive padding: two sessions created in the
    same millisecond are not hypothetical — a seeded cohort or a fast script
    produces them — and without it their order changes between requests, which
    makes the history list appear to shuffle.
    """
    report_by_session = {r.session_id: r for r in reports}
    summaries = [
        {
            "session_id": session.id,
            "role": session.role,
            "state": session.state,
            "status": history_status(session.state),
            "started_at": session.created_at,
            "duration_minutes": duration_minutes(session),
            "overall_score": (
                mean_competency_score([c.score for c in report_by_session[session.id].competency_scores])
                if session.id in report_by_session
                else None
            ),
            "has_report": session.id in report_by_session,
        }
        for session in sessions
    ]
    summaries.sort(key=lambda s: (s["started_at"], s["session_id"]), reverse=True)
    return summaries

"""~ apps/gateway/src/http/errors.ts.

Terminal error handling. Never leaks internals or request bodies to the
client — see `install_error_handlers`.
"""

from __future__ import annotations

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from app.logging_ import Logger


class HttpError(Exception):
    def __init__(self, status: int, code: str, message: str) -> None:
        super().__init__(message)
        self.status = status
        self.code = code
        self.message = message


def bad_request(code: str, message: str) -> HttpError:
    return HttpError(400, code, message)


def unauthorized(message: str = "authentication required") -> HttpError:
    return HttpError(401, "unauthorized", message)


def forbidden(message: str = "insufficient role for this route") -> HttpError:
    return HttpError(403, "forbidden", message)


def not_found(message: str = "not found") -> HttpError:
    return HttpError(404, "not_found", message)


def conflict(code: str, message: str) -> HttpError:
    return HttpError(409, code, message)


def install_error_handlers(app: FastAPI, logger: Logger) -> None:
    @app.exception_handler(HttpError)
    async def _handle_http_error(_req: Request, err: HttpError) -> JSONResponse:
        return JSONResponse(
            status_code=err.status, content={"error": {"code": err.code, "message": err.message}}
        )

    @app.exception_handler(Exception)
    async def _handle_unexpected(req: Request, err: Exception) -> JSONResponse:
        logger.error("unhandled_error", {"path": req.url.path, "method": req.method, "message": str(err)})
        return JSONResponse(
            status_code=500, content={"error": {"code": "internal_error", "message": "internal error"}}
        )

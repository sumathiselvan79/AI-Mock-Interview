"""Gateway entrypoint — ~ apps/gateway/src/index.ts. Run with:

    uvicorn app.main:app --reload --port 4000

(from the `backend/` directory, with `.venv` active).
"""

from __future__ import annotations

from app.config import load_config
from app.gateway import create_app
from app.logging_ import create_logger
from app.paths import load_dot_env

# Must run before `load_config()` reads `os.environ`.
_env = load_dot_env()

_config = load_config()
_logger = create_logger(min_level="info" if _config.node_env == "production" else "debug")
_logger.info("env_file", {"loaded": _env["loaded"], "path": _env["path"]})

app = create_app()

_logger.info(
    "gateway_listening",
    {
        "port": _config.port,
        "env": _config.node_env,
        "storage": _config.storage_driver,
        "mcp_servers": len(app.state.mcp.registered()),
    },
)

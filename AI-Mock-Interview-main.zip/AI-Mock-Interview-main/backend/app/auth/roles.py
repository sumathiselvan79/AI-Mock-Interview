"""Role resolution — ~ apps/gateway/src/auth/roles.ts.

The single place that decides `admin` vs `student`. Every identity path that
authenticates via a third party or a typed-in email (dev-login, Google OAuth)
runs its email through this function rather than trusting a role the client
or the provider handed back. A new identity defaults to `student`; only an
email on the allowlist ever becomes `admin`.
"""

from __future__ import annotations

from typing import Optional

from app.shared_types import Role


def resolve_role(email: str, admin_email_allowlist: list[str]) -> Role:
    normalized = email.strip().lower()
    return "admin" if normalized in admin_email_allowlist else "student"


def parse_admin_email_allowlist(raw: Optional[str]) -> list[str]:
    """Parses `ADMIN_EMAIL_ALLOWLIST` (comma-separated) into normalized emails."""
    return [e.strip().lower() for e in (raw or "").split(",") if e.strip()]

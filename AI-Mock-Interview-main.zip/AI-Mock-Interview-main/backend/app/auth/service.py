"""Auth service — ~ apps/gateway/src/auth/service.ts. INSTRUCTIONS.md §7 (endpoints), §8 (storage rules).

Two deliberate choices worth keeping:
 - login and reset-request give the same answer whether or not the account
   exists, so neither becomes an account-enumeration oracle;
 - the reset token's plaintext exists only in the value handed to the mailer.
   Only its SHA-256 is stored, and it is single-use.
"""

from __future__ import annotations

import secrets
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Literal, Optional, Protocol

from app.auth.passcode import assert_passcode_acceptable, hash_passcode, verify_passcode
from app.auth.roles import resolve_role
from app.auth.tokens import generate_reset_token, hash_reset_token, mint_session_token
from app.config import GatewayConfig
from app.shared_types import OAuthProfileStore, PublicUser, Role, TelemetrySink, User, UserProfile
from app.shared_types.user import to_public_user
from app.storage.types import ResetTokenStore, UserStore


class ResetMailer(Protocol):
    async def deliver(self, email: str, token: str, expires_at: str) -> None: ...


@dataclass
class _Delivered:
    email: str
    token: str
    expires_at: str


class MemoryResetMailer:
    """Dev/test mailer: keeps the last token in memory so a manual run can complete the flow."""

    def __init__(self) -> None:
        self._delivered: list[_Delivered] = []

    async def deliver(self, email: str, token: str, expires_at: str) -> None:
        self._delivered.append(_Delivered(email, token, expires_at))

    def last_for(self, email: str) -> Optional[_Delivered]:
        normalized = email.strip().lower()
        for entry in reversed(self._delivered):
            if entry.email == normalized:
                return entry
        return None


class AuthError(Exception):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


@dataclass
class GoogleIdentity:
    """What a verified Google identity contributes to `identity_login`, beyond
    the email every identity path shares."""

    provider: Literal["google"]
    subject: str
    name: Optional[str] = None
    avatar_url: Optional[str] = None


# A well-formed hash of a value nobody knows, used to equalise the timing of a
# login against a non-existent account. Fixed, module-level, like the TS side.
DUMMY_HASH = "scrypt$16384$8$1$AAAAAAAAAAAAAAAAAAAAAA==$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="


@dataclass
class AuthService:
    users: UserStore
    resets: ResetTokenStore
    telemetry: TelemetrySink
    config: GatewayConfig
    logger: object  # app.logging_.Logger — kept loose to dodge an import cycle
    mailer: ResetMailer
    oauth_profiles: Optional[OAuthProfileStore] = None

    async def create_user(
        self,
        *,
        email: str,
        passcode: str,
        role: Role,
        cross_session_memory_opt_in: bool = False,
        profile: Optional[UserProfile] = None,
    ) -> PublicUser:
        """Account creation is an operator action in Stage 1 — role is fixed here (§3.2)."""
        assert_passcode_acceptable(passcode)
        user = await self.users.create(
            email=email,
            role=role,
            passcode_hash=await hash_passcode(passcode),
            cross_session_memory_opt_in=cross_session_memory_opt_in,
            profile=profile,
        )
        return to_public_user(user)

    async def update_profile(self, user_id: str, profile: UserProfile) -> PublicUser:
        """(Stage 5, §11.4) A candidate completing their own profile."""
        return to_public_user(await self.users.update_profile(user_id, profile))

    async def login(self, email: str, passcode: str) -> dict:
        user = await self.users.find_by_email(email)
        # Verify against a dummy hash when the user is missing so both
        # branches cost the same and the response time does not reveal which
        # one happened.
        stored = user.passcode_hash if user else DUMMY_HASH
        ok = await verify_passcode(passcode, stored)

        if not user or not ok:
            await self.telemetry.emit("auth_login_failed", None, {"reason": "invalid_credentials"})
            self.logger.warn("login_failed", {"email_domain": email.split("@")[-1] or "unknown"})  # type: ignore[attr-defined]
            raise AuthError("invalid_credentials", "invalid email or passcode")

        token, _claims = mint_session_token(
            user_id=user.id,
            email=user.email,
            role=user.role,
            ttl_seconds=self.config.auth_token_ttl_seconds,
            secret=self.config.auth_token_secret,
        )

        await self.telemetry.emit("auth_login_succeeded", None, {"user_id": user.id, "role": user.role})
        return {"token": token, "user": to_public_user(user)}

    async def identity_login(self, email: str, google_identity: Optional[GoogleIdentity] = None) -> dict:
        """Shared endpoint for every identity path that doesn't collect a
        passcode: dev-login today, Google OAuth once its callback validates
        an ID token. The caller hands over a *verified* email; role is never
        taken from the caller — it is always resolved from the admin-email
        allowlist, right here."""
        role = resolve_role(email, self.config.admin_email_allowlist)
        # A hash of a random value that is thrown away, so nobody can log in
        # with a passcode against it. Written on BOTH branches of the upsert:
        # an existing row's passcode was never proven to be the owner's, and
        # keeping it let an attacker who registered the address first log in
        # after the owner's Google login raised the row to admin (audit P0-1).
        unusable_passcode_hash = await hash_passcode(secrets.token_urlsafe(32))
        user = await self.users.upsert_identity(
            email=email, role=role, unusable_passcode_hash=unusable_passcode_hash
        )

        if google_identity and self.oauth_profiles:
            try:
                from app.shared_types import OAuthProfile

                await self.oauth_profiles.upsert(
                    OAuthProfile(
                        user_id=user.id,
                        provider=google_identity.provider,
                        provider_subject=google_identity.subject,
                        email=user.email,
                        name=google_identity.name,
                        avatar_url=google_identity.avatar_url,
                        linked_at=datetime.now(timezone.utc).isoformat(),
                    )
                )
            except Exception as err:  # noqa: BLE001 - never blocks the login itself
                self.logger.warn(  # type: ignore[attr-defined]
                    "oauth_profile_snapshot_failed", {"user_id": user.id, "error": str(err)}
                )

        token, _claims = mint_session_token(
            user_id=user.id,
            email=user.email,
            role=user.role,
            ttl_seconds=self.config.auth_token_ttl_seconds,
            secret=self.config.auth_token_secret,
        )

        await self.telemetry.emit("auth_login_succeeded", None, {"user_id": user.id, "role": user.role})
        return {"token": token, "user": to_public_user(user)}

    async def request_passcode_reset(self, email: str) -> None:
        """Always resolves the same way, whether or not the account exists."""
        user = await self.users.find_by_email(email)
        if not user:
            self.logger.info("reset_requested_unknown_account", {})  # type: ignore[attr-defined]
            return
        plaintext, token_hash = generate_reset_token()
        expires_at = datetime.fromtimestamp(
            datetime.now(timezone.utc).timestamp() + self.config.reset_token_ttl_seconds, tz=timezone.utc
        ).isoformat()
        await self.resets.create(user.id, token_hash, expires_at)
        await self.mailer.deliver(user.email, plaintext, expires_at)
        self.logger.info("reset_token_issued", {"user_id": user.id, "expires_at": expires_at})  # type: ignore[attr-defined]

    async def confirm_passcode_reset(self, token: str, new_passcode: str) -> None:
        assert_passcode_acceptable(new_passcode)
        record = await self.resets.find_valid_by_hash(hash_reset_token(token), datetime.now(timezone.utc))
        if not record:
            raise AuthError("invalid_reset_token", "reset token is invalid, expired, or already used")
        await self.users.update_passcode_hash(record.user_id, await hash_passcode(new_passcode))
        # Marked used only after the new passcode lands, so a failed write
        # cannot burn the token and lock the account out.
        await self.resets.mark_used(record.id, datetime.now(timezone.utc).isoformat())
        self.logger.info("passcode_reset_confirmed", {"user_id": record.user_id})  # type: ignore[attr-defined]

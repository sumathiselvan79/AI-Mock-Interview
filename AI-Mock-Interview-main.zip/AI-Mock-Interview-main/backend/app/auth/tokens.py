"""Role-scoped auth tokens and single-use reset tokens — ~ apps/gateway/src/auth/tokens.ts.

INSTRUCTIONS.md §7-8. HS256, hand-rolled on `hmac`/`hashlib` (same approach
the TS side takes on `node:crypto` rather than pulling in a JWT library) — the
token carries the role so the gateway can enforce RBAC on every request
without a database round trip, and is signed so the role cannot be edited
client-side.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
import time
from dataclasses import dataclass
from typing import Literal, Optional, Union

from app.shared_types import AuthTokenClaims, ConsentClaims, ConsentScope, ConsentVerdict, Role


def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64url_decode(data: str) -> bytes:
    padding = "=" * (-len(data) % 4)
    return base64.urlsafe_b64decode(data + padding)


def _sign(data: str, secret: str) -> str:
    digest = hmac.new(secret.encode("utf-8"), data.encode("utf-8"), hashlib.sha256).digest()
    return _b64url_encode(digest)


def mint_session_token(
    *, user_id: str, email: str, role: Role, ttl_seconds: int, secret: str, now_ms: Optional[int] = None
) -> tuple[str, AuthTokenClaims]:
    """The one place a session token gets signed. Every identity path —
    passcode login, dev-login, Google OAuth callback — ends here with a role
    that path has already resolved (never a role read off the request body
    or a provider's claims)."""
    iat = int((now_ms if now_ms is not None else time.time() * 1000) / 1000)
    claims = AuthTokenClaims(sub=user_id, email=email, role=role, iat=iat, exp=iat + ttl_seconds)
    header = _b64url_encode(json.dumps({"alg": "HS256", "typ": "JWT"}).encode())
    body = _b64url_encode(claims.model_dump_json(by_alias=True).encode())
    signature = _sign(f"{header}.{body}", secret)
    return f"{header}.{body}.{signature}", claims


TokenFailure = Literal["malformed", "bad_signature", "expired"]


@dataclass
class VerifyOk:
    ok: Literal[True]
    claims: AuthTokenClaims


@dataclass
class VerifyFail:
    ok: Literal[False]
    reason: TokenFailure


VerifyResult = Union[VerifyOk, VerifyFail]


def verify_token(token: str, secret: str, now_ms: Optional[float] = None) -> VerifyResult:
    now_ms = now_ms if now_ms is not None else time.time() * 1000
    parts = token.split(".")
    if len(parts) != 3:
        return VerifyFail(False, "malformed")
    header, body, signature = parts

    expected = _sign(f"{header}.{body}", secret)
    if not hmac.compare_digest(signature, expected):
        return VerifyFail(False, "bad_signature")

    try:
        claims = AuthTokenClaims.model_validate_json(_b64url_decode(body))
    except Exception:
        return VerifyFail(False, "malformed")

    if claims.exp * 1000 <= now_ms:
        return VerifyFail(False, "expired")
    if claims.role not in ("admin", "student"):
        return VerifyFail(False, "malformed")

    return VerifyOk(True, claims)


def generate_reset_token() -> tuple[str, str]:
    """The plaintext is emailed once and never stored. Only its SHA-256 is
    persisted, so a database read cannot be replayed as a credential."""
    plaintext = _b64url_encode(secrets.token_bytes(32))
    return plaintext, hash_reset_token(plaintext)


def hash_reset_token(plaintext: str) -> str:
    return hashlib.sha256(plaintext.encode("utf-8")).hexdigest()


def issue_session_token(session_id: str, secret: str) -> str:
    """Session-scoped token minted for a live session and required on every
    MCP call through the gateway (INSTRUCTIONS.md §2)."""
    nonce = _b64url_encode(secrets.token_bytes(12))
    return f"{session_id}.{nonce}.{_sign(f'{session_id}.{nonce}', secret)}"


def issue_consent_token(
    session_id: str, scope: ConsentScope, secret: str, now_ms: Optional[float] = None
) -> str:
    """One token per scope, bound to a session (soul.md §'Consent-first
    monitoring'). Signed rather than looked up so a tool can verify consent
    without a database round trip on a hot path."""
    now_ms = now_ms if now_ms is not None else time.time() * 1000
    claims = ConsentClaims(session_id=session_id, scope=scope, granted_at=int(now_ms / 1000))
    payload = _b64url_encode(claims.model_dump_json(by_alias=True).encode())
    return f"{payload}.{_sign(payload, secret)}"


def verify_consent_token(
    token: Optional[str], session_id: str, scope: ConsentScope, secret: str
) -> ConsentVerdict:
    from app.shared_types.consent import ConsentVerdictFail, ConsentVerdictOk

    if not token:
        return ConsentVerdictFail(reason="missing")

    parts = token.split(".")
    if len(parts) != 2:
        return ConsentVerdictFail(reason="malformed")
    payload, signature = parts

    expected = _sign(payload, secret)
    if not hmac.compare_digest(signature, expected):
        return ConsentVerdictFail(reason="bad_signature")

    try:
        claims = ConsentClaims.model_validate_json(_b64url_decode(payload))
    except Exception:
        return ConsentVerdictFail(reason="malformed")

    # Bound to one session and one scope: a token minted for another
    # candidate, or for a different kind of monitoring, is not consent here.
    if claims.session_id != session_id:
        return ConsentVerdictFail(reason="wrong_session")
    if claims.scope != scope:
        return ConsentVerdictFail(reason="wrong_scope")

    return ConsentVerdictOk(claims=claims)


def verify_session_token(token: str, session_id: str, secret: str) -> bool:
    parts = token.split(".")
    if len(parts) != 3:
        return False
    token_session_id, nonce, signature = parts
    if token_session_id != session_id:
        return False
    expected = _sign(f"{token_session_id}.{nonce}", secret)
    return hmac.compare_digest(signature, expected)

"""Google OAuth identity check — ~ apps/gateway/src/auth/google.ts.

The second identity path, added without touching `mint_session_token`, the
RBAC middleware, or role resolution (`auth/roles.py`). It ends at the same
place dev-login does: a verified email handed to `AuthService.identity_login`.

Deliberate deviation from the TS side: TS uses the `arctic` OAuth2/OIDC
library; this ports the same protocol steps directly against `httpx` (already
a dependency) and `PyJWT` (ditto) rather than adding a new dependency for
what is, underneath, three things — build an authorization URL with PKCE,
POST an authorization code to Google's token endpoint, and read the ID
token's claims. `decode_id_token` deliberately does not verify the JWT
signature, matching `arctic`'s `decodeIdToken` and for the same reason: this
token was fetched directly from Google's token endpoint over TLS (never
passed through the browser), so the channel itself is the trust anchor per
OIDC's code-flow guidance. What still has to be checked by hand is that it's
the token *we* asked for — issuer, audience, expiry — and that Google itself
verified the address.
"""

from __future__ import annotations

import base64
import hashlib
import secrets
import time
from dataclasses import dataclass
from typing import Optional, Protocol

import httpx
import jwt as pyjwt

from app.config import GatewayConfig

GOOGLE_AUTHORIZATION_ENDPOINT = "https://accounts.google.com/o/oauth2/v2/auth"
GOOGLE_TOKEN_ENDPOINT = "https://oauth2.googleapis.com/token"
VALID_ISSUERS = {"https://accounts.google.com", "accounts.google.com"}


class OAuth2RequestError(Exception):
    """The authorization-code exchange itself failed (bad code, bad verifier,
    revoked client, ...) — a Google-reported OAuth protocol error, distinct
    from an ID token that exchanged fine but doesn't check out."""


class InvalidGoogleIdTokenError(Exception):
    pass


@dataclass
class GoogleTokenResponse:
    id_token: str


class GoogleAuthClient(Protocol):
    """The slice of the OAuth2/OIDC code flow this module actually uses —
    kept as a narrow interface so tests can inject a fake instead of hitting
    Google's token endpoint over the network."""

    def create_authorization_url(self, state: str, code_verifier: str, scopes: list[str]) -> str: ...

    async def validate_authorization_code(self, code: str, code_verifier: str) -> GoogleTokenResponse: ...


class RealGoogleAuthClient:
    def __init__(self, client_id: str, client_secret: str, redirect_uri: str) -> None:
        self._client_id = client_id
        self._client_secret = client_secret
        self._redirect_uri = redirect_uri

    def create_authorization_url(self, state: str, code_verifier: str, scopes: list[str]) -> str:
        challenge = _code_challenge(code_verifier)
        params = {
            "response_type": "code",
            "client_id": self._client_id,
            "redirect_uri": self._redirect_uri,
            "state": state,
            "scope": " ".join(scopes),
            "code_challenge": challenge,
            "code_challenge_method": "S256",
            "access_type": "online",
        }
        return f"{GOOGLE_AUTHORIZATION_ENDPOINT}?{httpx.QueryParams(params)}"

    async def validate_authorization_code(self, code: str, code_verifier: str) -> GoogleTokenResponse:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.post(
                GOOGLE_TOKEN_ENDPOINT,
                data={
                    "grant_type": "authorization_code",
                    "code": code,
                    "redirect_uri": self._redirect_uri,
                    "client_id": self._client_id,
                    "client_secret": self._client_secret,
                    "code_verifier": code_verifier,
                },
                headers={"Accept": "application/json"},
            )
        if resp.status_code >= 400:
            raise OAuth2RequestError(f"Google token endpoint returned {resp.status_code}: {resp.text}")
        body = resp.json()
        id_token = body.get("id_token")
        if not isinstance(id_token, str) or not id_token:
            raise OAuth2RequestError("Google token response is missing id_token")
        return GoogleTokenResponse(id_token=id_token)


def create_google_auth_client(config: GatewayConfig) -> RealGoogleAuthClient:
    return RealGoogleAuthClient(config.google.client_id, config.google.client_secret, config.google.redirect_uri)


def generate_state() -> str:
    return secrets.token_urlsafe(32)


def generate_code_verifier() -> str:
    # RFC 7636 requires 43-128 chars from the unreserved charset;
    # `token_urlsafe(32)` produces 43 base64url characters, satisfying both
    # the minimum length and the charset in one call.
    return secrets.token_urlsafe(32)


def _code_challenge(code_verifier: str) -> str:
    digest = hashlib.sha256(code_verifier.encode("ascii")).digest()
    return base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")


@dataclass
class VerifiedGoogleProfile:
    """The identity facts this system actually trusts from a Google ID token."""

    email: str
    # Google's `sub` claim — stable per Google account, unlike email.
    subject: str
    # Present only when the `profile` scope was granted at /start.
    name: Optional[str] = None
    picture: Optional[str] = None


def extract_verified_google_profile(id_token: str, expected_audience: str) -> VerifiedGoogleProfile:
    try:
        claims = pyjwt.decode(id_token, options={"verify_signature": False})
    except Exception as err:  # noqa: BLE001
        raise InvalidGoogleIdTokenError("could not decode Google ID token") from err

    if not isinstance(claims.get("iss"), str) or claims["iss"] not in VALID_ISSUERS:
        raise InvalidGoogleIdTokenError("unexpected issuer")
    if claims.get("aud") != expected_audience:
        raise InvalidGoogleIdTokenError("unexpected audience")
    exp = claims.get("exp")
    if not isinstance(exp, (int, float)) or exp <= time.time():
        raise InvalidGoogleIdTokenError("ID token is expired")
    if claims.get("email_verified") is not True:
        raise InvalidGoogleIdTokenError("Google has not verified this email address")
    email = claims.get("email")
    if not isinstance(email, str) or "@" not in email:
        raise InvalidGoogleIdTokenError("ID token is missing an email claim")
    subject = claims.get("sub")
    if not isinstance(subject, str) or not subject:
        raise InvalidGoogleIdTokenError("ID token is missing a sub claim")

    name = claims.get("name")
    picture = claims.get("picture")
    return VerifiedGoogleProfile(
        email=email,
        subject=subject,
        name=name if isinstance(name, str) else None,
        picture=picture if isinstance(picture, str) else None,
    )

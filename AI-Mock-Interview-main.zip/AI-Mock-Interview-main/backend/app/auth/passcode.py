"""Passcode hashing — ~ apps/gateway/src/auth/passcode.ts.

INSTRUCTIONS.md §8: "passcodes are stored as salted hashes, never plaintext."

`hashlib.scrypt` (stdlib, OpenSSL-backed): memory-hard, no extra dependency,
and the parameters are encoded in the stored string so they can be raised
later without invalidating existing rows. Wire-compatible with the TS
implementation's stored format (`scrypt$N$r$p$saltB64$hashB64`) so a
Postgres-backed deployment's existing rows keep verifying after this port.
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import os

PARAMS = {"n": 16384, "r": 8, "p": 1, "keylen": 32}
MAXMEM = 64 * 1024 * 1024
SALT_BYTES = 16

MIN_PASSCODE_LENGTH = 8


class WeakPasscodeError(Exception):
    code = "weak_passcode"


def assert_passcode_acceptable(passcode: str) -> None:
    if len(passcode) < MIN_PASSCODE_LENGTH:
        raise WeakPasscodeError(f"passcode must be at least {MIN_PASSCODE_LENGTH} characters")


def _scrypt(password: str, salt: bytes, n: int, r: int, p: int, dklen: int) -> bytes:
    return hashlib.scrypt(
        password.encode("utf-8"), salt=salt, n=n, r=r, p=p, maxmem=MAXMEM, dklen=dklen
    )


async def hash_passcode(passcode: str) -> str:
    """Returns `scrypt$N$r$p$saltB64$hashB64`. The plaintext never leaves this function."""
    assert_passcode_acceptable(passcode)
    salt = os.urandom(SALT_BYTES)
    derived = await asyncio.to_thread(
        _scrypt, passcode, salt, PARAMS["n"], PARAMS["r"], PARAMS["p"], PARAMS["keylen"]
    )
    return "$".join(
        [
            "scrypt",
            str(PARAMS["n"]),
            str(PARAMS["r"]),
            str(PARAMS["p"]),
            base64.b64encode(salt).decode(),
            base64.b64encode(derived).decode(),
        ]
    )


async def verify_passcode(passcode: str, stored: str) -> bool:
    """Constant-time verification. Returns False on any malformed stored value rather than raising."""
    parts = stored.split("$")
    if len(parts) != 6 or parts[0] != "scrypt":
        return False

    _, n_raw, r_raw, p_raw, salt_b64, hash_b64 = parts
    try:
        n, r, p = int(n_raw), int(r_raw), int(p_raw)
    except ValueError:
        return False

    try:
        expected = base64.b64decode(hash_b64 or "")
    except Exception:
        return False
    if len(expected) == 0:
        return False

    try:
        salt = base64.b64decode(salt_b64 or "")
        derived = await asyncio.to_thread(_scrypt, passcode, salt, n, r, p, len(expected))
        return len(derived) == len(expected) and hmac.compare_digest(derived, expected)
    except Exception:
        return False

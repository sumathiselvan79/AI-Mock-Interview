"""Time Tracking Agent — ~ agents/time-tracking-agent/src/index.ts. INSTRUCTIONS.md §4.6.

Enforces and communicates per-segment time budgets. It never ends a segment
itself: it reports `nudge` before `expired` so the harness can warn the
candidate first (§4.6, soul.md §4 — "nudges, doesn't nag; a countdown should
inform pacing, not manufacture stress").

Segment ids are `{session_id}:{segment}`, so one session's clocks can never
collide with another's.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from app.shared_types import McpCallContext, McpHandlerError

SERVER_NAME = "time-tracking-agent"
METHODS = ("start_segment", "stop_segment", "get_segment_state")

# Default budgets in ms. A role or session may override them later.
SEGMENT_BUDGETS = {
    "question": 4 * 60_000,
    "follow_up": 2 * 60_000,
    "coding_round": 25 * 60_000,
    "session": 45 * 60_000,
}


def segment_id(session_id: str, segment: str) -> str:
    return f"{session_id}:{segment}"


@dataclass
class TimeTrackingAgentDeps:
    tool_client: Any  # ToolClientFactory


class TimeTrackingAgentServer:
    name = SERVER_NAME

    def __init__(self, deps: TimeTrackingAgentDeps) -> None:
        self._deps = deps

    async def call(self, method: str, params: Any, ctx: McpCallContext) -> Any:
        p = params or {}
        session_id = p["session_id"]
        segment = p["segment"]
        tools = self._deps.tool_client(session_id, SERVER_NAME)
        sid = segment_id(session_id, segment)

        if method == "start_segment":
            budget_ms = p.get("budget_ms") or SEGMENT_BUDGETS.get(segment, SEGMENT_BUDGETS["question"])
            result = await tools.call("tool-time-tracking", "start_timer", {"segment_id": sid, "budget_ms": budget_ms})
            return {"segment_id": result["segment_id"], "started_at": result["started_at"], "budget_ms": budget_ms}

        if method == "stop_segment":
            state = await tools.call("tool-time-tracking", "get_elapsed", {"segment_id": sid})
            return {"elapsed_ms": state["elapsed_ms"], "segment_state": state["segment_state"]}

        if method == "get_segment_state":
            return await tools.call("tool-time-tracking", "get_elapsed", {"segment_id": sid})

        raise McpHandlerError("unknown_method", f"{SERVER_NAME} has no method {method}")


def create_time_tracking_agent_server(deps: TimeTrackingAgentDeps) -> TimeTrackingAgentServer:
    return TimeTrackingAgentServer(deps)

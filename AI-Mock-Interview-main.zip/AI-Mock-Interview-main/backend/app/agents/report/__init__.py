"""~ agents/report-agent/src/index.ts — re-exports.

`STRENGTH_THRESHOLD` used to be re-exported from here. It now lives with the
grade bands it belongs to (`app.tools.eval.grading`) — the Eval Tool owns the
rubrics AND their interpretation (CLAUDE.md §8), and this agent no longer
carries its own copy of the boundary at all: it reads the `is_strength` flag
the tool returns on each grade.
"""

from app.agents.report.server import ReportAgentDeps, create_report_agent_server

__all__ = ["ReportAgentDeps", "create_report_agent_server"]

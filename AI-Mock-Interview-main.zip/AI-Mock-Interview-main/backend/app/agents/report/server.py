"""Report Agent — ~ agents/report-agent/src/index.ts. INSTRUCTIONS.md §4.8.

Compiles the final evidence-linked report: one competency score per topic,
evidence-linked strengths/focus areas, and the required disclaimer.

The Harness Agent assembles the full per-question transcript (question,
answer, and every persisted Evaluation) and hands it over as `params` —
this agent never reads storage directly. This agent has no storage
dependency at all, only a tool client for the holistic pass.

Voice (soul.md §4): "fair and evidence-based. Frames even a weak
performance constructively, always tied to specific moments in the
transcript." Every `evidence` string is a verbatim slice of an actual
answer transcript, and a topic with no scoreable answer gets no competency
score at all — it is named in `focus_areas` instead, never guessed at.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

from app.shared_types import McpCallContext, McpHandlerError
from app.tools.eval.grading import TOPIC_SOURCE_WEIGHT

SERVER_NAME = "report-agent"
METHODS = ("generate_report",)

# Whether a competency reads as a strength or as a focus area is decided by
# the Eval Tool, on the `is_strength` flag it returns with each grade — this
# agent does not carry its own copy of the boundary. Rubrics and their
# interpretation live in one place (CLAUDE.md §8), and a competency badged "B"
# but filed under "worth strengthening" is exactly the quiet disagreement that
# rule exists to prevent.
#
# The one case that has no grade to read: `tool-eval` being unreachable. That
# is a degraded report, not a wrong one — see `_partition` below.

# Same denomination the Harness Agent uses when scoring live answers.
_RUBRIC_FOR_TYPE = {"behavioral": "behavioral_v1", "technical": "technical_v2", "coding": "coding_round_v1"}


@dataclass
class ReportAgentDeps:
    tool_client: Any  # ToolClientFactory


class ReportAgentServer:
    name = SERVER_NAME

    def __init__(self, deps: ReportAgentDeps) -> None:
        self._deps = deps

    async def call(self, method: str, params: Any, ctx: McpCallContext) -> Any:
        if method not in METHODS:
            raise McpHandlerError("unknown_method", f"{SERVER_NAME} has no method {method}")
        return await _generate_report(self._deps, params or {})


def _slice_evidence(transcript: str, span: dict[str, int]) -> Optional[str]:
    text = transcript[span["start"] : min(span["end"], len(transcript))].strip()
    return text if text else None


def _dominant_type(entries: list[dict[str, Any]]) -> str:
    """A crude majority vote; ties resolve to whichever type appears first."""
    counts: dict[str, int] = {}
    for entry in entries:
        counts[entry["type"]] = counts.get(entry["type"], 0) + 1
    best = entries[0]["type"]
    best_count = 0
    for type_, count in counts.items():
        if count > best_count:
            best = type_
            best_count = count
    return best


def _round1(n: float) -> float:
    return round(n * 10) / 10


async def _score_topic(tools: Any, topic: str, entries: list[dict[str, Any]]) -> dict[str, Any]:
    """One topic's competency score: the average of every persisted
    per-answer score, refined by one additional holistic pass over the
    topic's answers combined — genuinely a fresh Eval Tool call, not a
    re-read of the old ones. If the combined transcript is too thin for
    that pass, the per-answer average stands alone rather than the call
    failing the whole report."""
    evaluated = [e for e in entries if e.get("answer") and e.get("evaluations")]
    if not evaluated:
        return {"competency": None, "insufficient_reason": f"Not enough was said on {topic} to score it — worth giving a fuller, more specific answer here next time."}

    per_answer_scores = [ev["score"] for e in evaluated for ev in e["evaluations"]]
    average_score = sum(per_answer_scores) / len(per_answer_scores)

    evidence: list[str] = []
    for entry in evaluated:
        spans = entry["evaluations"][0].get("evidence_spans") or []
        if not spans:
            continue
        quote = _slice_evidence(entry["answer"]["transcript"], spans[0])
        if quote and quote not in evidence:
            evidence.append(quote)
        if len(evidence) >= 2:
            break

    rubric_id = _RUBRIC_FOR_TYPE[_dominant_type(evaluated)]
    combined_transcript = " ".join(e["answer"]["transcript"] for e in evaluated)

    final_score = average_score
    try:
        holistic = await tools.call(
            "tool-eval",
            "evaluate_answer",
            {
                "rubric_id": rubric_id,
                "question": f"Overall performance across {len(evaluated)} question(s) on {topic}",
                "answer_transcript": combined_transcript,
                "topic": topic,
            },
        )
        final_score = _round1((average_score + holistic["score"]) / 2)
        if len(evidence) < 2:
            spans = holistic.get("evidence_spans") or []
            quote = _slice_evidence(combined_transcript, spans[0]) if spans else None
            if quote and quote not in evidence:
                evidence.append(quote)
    except McpHandlerError as err:
        # A thin combined transcript is not a report failure — the
        # per-answer average, already evidenced, stands on its own.
        if err.code != "insufficient_transcript":
            raise
        final_score = _round1(average_score)

    # Every competency must cite real evidence; if scoring somehow produced
    # none, this topic is reported as unscoreable rather than asserting an
    # unevidenced number.
    if not evidence:
        return {"competency": None, "insufficient_reason": f"{topic} was scored but no quotable evidence survived — treating it as unscoreable rather than reporting an unevidenced number."}

    return {"competency": {"competency": topic, "score": final_score, "evidence": evidence}}


async def _generate_report(deps: ReportAgentDeps, params: dict[str, Any]) -> dict[str, Any]:
    transcript = params.get("transcript", [])
    has_any_evidence = any(e.get("answer") and e.get("evaluations") for e in transcript)
    if not has_any_evidence:
        raise McpHandlerError("insufficient_evidence", "no answer in this session could be scored; refusing to guess at a report rather than inventing scores")

    tools = deps.tool_client(params["session_id"], SERVER_NAME)

    by_topic: dict[str, list[dict[str, Any]]] = {}
    for entry in transcript:
        by_topic.setdefault(entry["topic"], []).append(entry)

    competency_scores: list[dict[str, Any]] = []
    insufficient_notes: list[str] = []

    for topic, entries in by_topic.items():
        result = await _score_topic(tools, topic, entries)
        if result["competency"]:
            competency_scores.append(result["competency"])
        elif result.get("insufficient_reason"):
            insufficient_notes.append(result["insufficient_reason"])

    # (Dynamic evaluation addition) `topic_sources` maps a topic name to WHY
    # it was on the plan (`shared_types.session.TopicSource`) — the same
    # signal that already drives what gets asked, now also driving how much
    # each competency counts toward `role_fit_grade`. Restricted to topics
    # that actually produced a competency score: a topic with no score has
    # nothing to weight. Absent entirely when the harness doesn't supply it,
    # so `role_fit_grade` simply never appears — additive, not required.
    topic_sources = params.get("topic_sources") or {}
    weights = (
        {c["competency"]: TOPIC_SOURCE_WEIGHT.get(topic_sources[c["competency"]], 1.0) for c in competency_scores if c["competency"] in topic_sources}
        if topic_sources
        else None
    )

    overall_grade, role_fit_grade = await _grade(tools, competency_scores, weights)

    strong, developing = _partition(competency_scores)

    strengths = [f'Strong on {c["competency"]} — for example: "{c["evidence"][0]}"' for c in strong]
    focus_areas = [f'Worth strengthening: {c["competency"]} — the answer given was "{c["evidence"][0]}"' for c in developing] + insufficient_notes

    from app.shared_types.report import REPORT_DISCLAIMER

    result: dict[str, Any] = {"competency_scores": competency_scores, "strengths": strengths, "focus_areas": focus_areas, "disclaimer": REPORT_DISCLAIMER}
    # Omitted, never defaulted to a bottom band: a session whose competencies
    # could not be graded has not earned the worst grade (soul.md §"No
    # fabrication"). The frontend renders `—` for its absence, the same way it
    # already does for a null score.
    if overall_grade:
        result["overall_grade"] = overall_grade
    if role_fit_grade:
        result["role_fit_grade"] = role_fit_grade
    return result


async def _grade(
    tools: Any, competency_scores: list[dict[str, Any]], weights: Optional[dict[str, float]] = None
) -> tuple[Optional[dict[str, Any]], Optional[dict[str, Any]]]:
    """Bands every competency and the session as a whole, in ONE Eval Tool
    call — the tool that owns the rubrics owns their interpretation too
    (CLAUDE.md §8). Each competency dict is annotated in place with its
    `grade`.

    A tool failure degrades the report rather than failing it: the scores are
    already evidenced and already useful, and a missing grade badge is a
    smaller loss than a report the candidate never receives.

    (Dynamic evaluation addition) Returns `(overall_grade, role_fit_grade)`.
    `role_fit_grade` is the Eval Tool's weighted band when `weights` was
    supplied, `None` otherwise — additive alongside `overall_grade`, never a
    replacement for it."""
    if not competency_scores:
        return None, None
    try:
        grade_params: dict[str, Any] = {"subjects": [{"id": c["competency"], "score": c["score"]} for c in competency_scores]}
        if weights:
            grade_params["weights"] = weights
        graded = await tools.call("tool-eval", "grade_scores", grade_params)
    except Exception:  # noqa: BLE001
        return None, None

    by_id = {row["id"]: row["grade"] for row in graded.get("graded", [])}
    for competency in competency_scores:
        grade = by_id.get(competency["competency"])
        if grade:
            competency["grade"] = grade
    return graded.get("overall_grade"), graded.get("role_fit_grade")


def _partition(competency_scores: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Strengths (best first) and focus areas (weakest first).

    Split on the Eval Tool's own `is_strength` flag wherever a grade came
    back. When grading was unavailable everything falls to the second list —
    "worth strengthening" is the wrong-but-harmless direction to fail in;
    calling something a strength on no authority is not.
    """
    strong = [c for c in competency_scores if (c.get("grade") or {}).get("is_strength")]
    developing = [c for c in competency_scores if not (c.get("grade") or {}).get("is_strength")]
    return (
        sorted(strong, key=lambda c: c["score"], reverse=True),
        sorted(developing, key=lambda c: c["score"]),
    )


def create_report_agent_server(deps: ReportAgentDeps) -> ReportAgentServer:
    return ReportAgentServer(deps)

"""Memory Agent — ~ agents/memory-agent/src/index.ts. INSTRUCTIONS.md §4.7.

Session-scoped working memory: what has been asked, and the running
per-topic counts against the session's topic plan. The Harness Agent reads
`topic_counts` from here and passes it to the Question Agent on every
`get_next_question` call — the Question Agent never queries this agent
directly.

Counts are *derived* from the persisted questions rather than kept in a
separate counter. A counter can drift from what was actually asked; a
derivation cannot, and it survives a restart mid-session for free.

Cross-session recall is opt-in at the account level and returns only what a
candidate would expect it to remember — previously asked questions, so the
next session does not repeat them (soul.md §5).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Optional

from app.shared_types import McpCallContext, McpHandlerError

SERVER_NAME = "memory-agent"
METHODS = (
    "get_session_context",
    "record_question_asked",
    "get_prior_context",
    "remember_reference_answer",
    "get_reference_answer",
    "remember_jd_fit_draft",
    "get_jd_fit_draft",
    "remember_used_phrase",
    "get_used_phrases",
    "remember_callback_fact",
    "get_callback_facts",
    "forget_session",
)

# (Stage 5) Scratch keys. Namespaced so `forget_session` is one operation and
# nothing has to enumerate what a session might be holding.
_JD_FIT_DRAFT_KEY = "jd-fit-draft"
_CALLBACK_FACTS_KEY = "callback-facts"

# (Human-interaction addition, §5) How many high-signal moments travel forward
# for the whole session. Small on purpose: these ride along on every
# `get_next_question` call, so this is a per-turn token cost paid for the rest
# of the interview (§8 data minimisation). Three to five was the range the
# design called for; five is the ceiling, not a target.
MAX_CALLBACK_FACTS = 5

# One sentence each. A callback is a hook to refer back to ("the Kafka
# migration"), not a second copy of the answer — the trailing window in
# `interview.py` already carries recent answers in full excerpt.
MAX_CALLBACK_FACT_WORDS = 30

# (Human-interaction addition, §4) How much phrasing history is kept per kind.
# Bounded so a long session cannot grow the prompt without limit; comfortably
# larger than any of the phrase pools, so "which have I used?" stays exact for
# every pool it is asked about.
MAX_USED_PHRASES = 40


def _reference_answer_key(question_id: str) -> str:
    return f"reference-answer:{question_id}"


def _used_phrases_key(kind: str) -> str:
    return f"used-phrases:{kind}"


def _truncate_words(text: str, max_words: int) -> str:
    words = (text or "").split()
    return " ".join(words) if len(words) <= max_words else " ".join(words[:max_words]) + "…"


@dataclass
class SessionContext:
    asked_question_ids: list[str]
    topic_counts: dict[str, int]
    topic_tier: dict[str, int]
    questions_asked: int


@dataclass
class MemoryAgentDeps:
    questions: Any  # QuestionStore
    sessions: Any  # SessionStore
    cross_session_opt_in: Callable[[str], Awaitable[bool]]
    scratch: Optional[Any] = None  # SessionScratchStore — (Stage 5)


class MemoryAgentServer:
    name = SERVER_NAME

    def __init__(self, deps: MemoryAgentDeps) -> None:
        self._deps = deps

    def _scratch(self) -> Any:
        """(Stage 5) The scratch store, or a plain refusal. Silently
        no-opping would let a reference answer look remembered and come back
        empty at scoring time."""
        if not self._deps.scratch:
            raise McpHandlerError(
                "scratch_unavailable", f"{SERVER_NAME} was constructed without a session-scoped store; §4.7 working memory is unavailable"
            )
        return self._deps.scratch

    async def call(self, method: str, params: Any, ctx: McpCallContext) -> Any:
        p = params or {}

        if method == "get_session_context":
            context = await get_session_context(self._deps, p["session_id"])
            return {
                "session_context": {
                    "asked_question_ids": context.asked_question_ids,
                    "topic_counts": context.topic_counts,
                    "topic_tier": context.topic_tier,
                    "questions_asked": context.questions_asked,
                }
            }

        if method == "record_question_asked":
            # The question is persisted by the harness as it is asked, so the
            # count derives itself. This method stays in the contract as the
            # explicit signal (§4.7) and returns the freshly derived counts.
            context = await get_session_context(self._deps, p["session_id"])
            return {"recorded": True, "topic_counts": context.topic_counts}

        if method == "get_prior_context":
            return await get_prior_context(self._deps, p["candidate_id"])

        # ------------------------------------------- (Stage 5) working memory

        if method == "remember_reference_answer":
            await self._scratch().set_session_scratch(p["session_id"], _reference_answer_key(p["question_id"]), p["reference_answer"])
            return {"remembered": True}

        if method == "get_reference_answer":
            answer = await self._scratch().get_session_scratch(p["session_id"], _reference_answer_key(p["question_id"]))
            # Absent is a normal outcome, not an error: a question generated
            # on the deterministic bank path has no reference answer, and the
            # Follow-up Agent has to score without one (§4.3).
            return {"found": True, "reference_answer": answer} if answer is not None else {"found": False}

        if method == "remember_jd_fit_draft":
            await self._scratch().set_session_scratch(
                p["session_id"], _JD_FIT_DRAFT_KEY, {"resume_fingerprint": p["resume_fingerprint"], "jd_fit": p["jd_fit"]}
            )
            return {"remembered": True}

        if method == "get_jd_fit_draft":
            draft = await self._scratch().get_session_scratch(p["session_id"], _JD_FIT_DRAFT_KEY)
            # A draft for a *different* resume is not a hit. Returning it
            # would attach one resume's generated rationale to another's
            # parse, which is fabrication however cheap it is.
            if draft and draft.get("resume_fingerprint") == p["resume_fingerprint"]:
                return {"found": True, "jd_fit": draft["jd_fit"]}
            return {"found": False}

        # ------------------------------- (§4) conversational phrasing history

        if method == "remember_used_phrase":
            # Which cue the interview has already spent this session. Recorded
            # by the harness AFTER a question comes back, because the Question
            # Agent writes free text — what it chose can only be observed.
            key = _used_phrases_key(p["kind"])
            used = list(await self._scratch().get_session_scratch(p["session_id"], key) or [])
            phrase = p["phrase"]
            # Re-appended rather than deduplicated: the ORDER is the point.
            # `acknowledgments._least_recently_used` falls back to whichever
            # phrase was used longest ago once a pool is exhausted, and that
            # answer is wrong if a repeat does not move the phrase forward.
            used = [existing for existing in used if existing != phrase] + [phrase]
            await self._scratch().set_session_scratch(p["session_id"], key, used[-MAX_USED_PHRASES:])
            return {"remembered": True}

        if method == "get_used_phrases":
            used = await self._scratch().get_session_scratch(p["session_id"], _used_phrases_key(p["kind"]))
            return {"used_phrases": list(used or [])}

        # ------------------------------------------- (§5) callback facts

        if method == "remember_callback_fact":
            facts = list(await self._scratch().get_session_scratch(p["session_id"], _CALLBACK_FACTS_KEY) or [])
            fact = _truncate_words(p["fact"], MAX_CALLBACK_FACT_WORDS)
            if any(existing.get("fact") == fact for existing in facts):
                # The same notable moment reached twice is one moment.
                return {"remembered": False, "callback_facts": facts}
            entry: dict[str, Any] = {"topic": p["topic"], "fact": fact}
            if p.get("source_question_id"):
                entry["source_question_id"] = p["source_question_id"]
            # Oldest out first once the cap is reached. A session's later
            # moments are the ones a human interviewer would still have in
            # mind, and the trailing window covers the most recent turns
            # anyway, so nothing is lost twice.
            facts = (facts + [entry])[-MAX_CALLBACK_FACTS:]
            await self._scratch().set_session_scratch(p["session_id"], _CALLBACK_FACTS_KEY, facts)
            return {"remembered": True, "callback_facts": facts}

        if method == "get_callback_facts":
            facts = await self._scratch().get_session_scratch(p["session_id"], _CALLBACK_FACTS_KEY)
            return {"callback_facts": list(facts or [])}

        if method == "forget_session":
            await self._scratch().clear_session_scratch(p["session_id"])
            return {"forgotten": True}

        raise McpHandlerError("unknown_method", f"{SERVER_NAME} has no method {method}")


async def get_session_context(deps: MemoryAgentDeps, session_id: str) -> SessionContext:
    asked = await deps.questions.list_by_session(session_id)
    topic_counts: dict[str, int] = {}
    # (Stage 6, §4.3) Derived like `topic_counts`: the tier of the LAST
    # question asked in a topic, read straight off the persisted questions
    # rather than a separate counter that could drift.
    topic_tier: dict[str, int] = {}
    for question in asked:
        topic_counts[question.topic] = topic_counts.get(question.topic, 0) + 1
        if question.tier is not None:
            topic_tier[question.topic] = question.tier
    return SessionContext(
        asked_question_ids=[q.bank_id for q in asked],
        topic_counts=topic_counts,
        topic_tier=topic_tier,
        questions_asked=len(asked),
    )


async def get_prior_context(deps: MemoryAgentDeps, candidate_id: str) -> dict[str, Any]:
    """Opt-in only. Without consent this returns nothing at all — not a
    redacted shape, not an empty-but-present object with counts in it."""
    if not await deps.cross_session_opt_in(candidate_id):
        return {"opted_in": False}

    sessions = await deps.sessions.list_by_candidate(candidate_id)
    previously_asked: set[str] = set()
    for session in sessions:
        for question in await deps.questions.list_by_session(session.id):
            previously_asked.add(question.bank_id)

    return {"opted_in": True, "previously_asked_question_ids": list(previously_asked), "sessions_seen": len(sessions)}


def create_memory_agent_server(deps: MemoryAgentDeps) -> MemoryAgentServer:
    return MemoryAgentServer(deps)

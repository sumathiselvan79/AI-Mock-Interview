"""Question Agent — ~ agents/question-agent/src/index.ts. INSTRUCTIONS.md §4.3.

Owns CALIBRATION (building the topic plan) and question selection during
QUESTION_LOOP. Two rules do the real work here:

 - **Quota enforcement.** Before selecting, any topic already at
   `topic_plan[topic].max_questions` is excluded for the rest of the
   session. If *every* topic is capped while budget remains, the agent may
   exceed one cap as a last resort — flagged with `quota_override: true`.
 - **Progressive difficulty.** It opens below the target and works up
   (soul.md §4).

`topic_counts` always arrives from the harness (sourced from the Memory
Agent). This agent never queries the Memory Agent directly (§4.7).

**(Stage 13) Selection produces a SLOT, not a bank question.** Everything
above is unchanged — the cap, the ordering, the tier curve, the override
rule. What changed is what falls out of it: `select_next_question` now
returns a `QuestionSlot` (topic, tier, type, difficulty, and the signals a
strong answer has to demonstrate), and the bank is consulted for two things
only — as the source of those signals, and as the fallback text when no
scenario can be synthesized. A slot no longer requires a bank entry to
exist, which is what lets the interview ask a tier the bank never covered.

The order the question text is decided in, and none of it is a judgement
this agent makes:

 1. `question-agent/v6` writes the scenario from scratch against the slot's
    signals and the candidate's own project history (`_synthesize_question`);
 2. failing that, `question-agent/v5` sharpens the bank text for the slot
    (`_generate_question`) — the pre-Stage-13 path, unchanged;
 3. failing that, the bank text as written;
 4. failing all three — a bank-less slot with no provider — the topic is not
    askable and selection has already moved on.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Optional

from app.agents.question.topic_plan import build_topic_plan
from app.interview_domain.blueprint import evaluation_topic_blueprint, tier_spec
from app.interview_domain.introduction import (
    INTRODUCTION_QUESTION_BANK_ID,
    INTRODUCTION_QUESTION_TEXT,
    INTRODUCTION_TOPIC,
)
from app.interview_domain.question_bank import (
    QUESTION_BANK,
    BankQuestion,
    Tier,
    concept_id,
    label_from_concept_id,
    questions_for_topic,
    tier_of,
)
from app.interview_domain.roles import required_topics_for
from app.interview_domain.topics import get_topic
from app.shared_types import McpCallContext, McpHandlerError, Question, TopicPlanEntry, TopicRelevance

SERVER_NAME = "question-agent"
METHODS = ("build_topic_plan", "get_next_question")

#: How many signals a bank-less slot carries into the prompt. The same cap
#: `DynamicQuestionResponse.expected_signals` enforces on the way back, so a
#: slot cannot ask for more than the schema will accept.
_MAX_SIGNALS = 6


@dataclass
class QuestionAgentDeps:
    tool_client: Optional[Any] = None  # ToolClientFactory — optional; absent means the Stage-2-only agent.
    # (Stage 13) Whether the from-scratch synthesis path may run.
    #
    # Off by default, and the reason is the same one that shapes
    # `fixture_model.py`: with no real provider configured, the fixture stands
    # in for the model, and a fixture cannot write a scenario — it can only
    # assemble one from the signal list. That is strictly WORSE than the
    # reviewed bank question the same slot already has, and "running with no
    # API key behaves like Stage 2, not like a worse interviewer than Stage 2"
    # is a rule this stage does not get to break. The gateway turns it on when
    # the resolved provider is a real one; the gate tests turn it on explicitly
    # to exercise the path.
    synthesis_enabled: bool = False


@dataclass
class SelectQuestionInput:
    session_id: str
    topic_plan: list[TopicPlanEntry]
    topic_counts: dict[str, int]
    asked_question_ids: list[str]
    difficulty_target: float
    topic_tier: dict[str, int]
    topic_scores: dict[str, list[float]]
    # (Orchestration addition) The Follow-up Agent's directive for the answer
    # that just came in, routed here by the harness. `escalate`/`drill_down`
    # ask to STAY on that topic; `pivot` asks to move off it — which is what
    # the ordering below already did unconditionally.
    directive: Optional[str] = None
    directive_topic: Optional[str] = None
    # (Stage 13) The topic the routing controller named, when it named one.
    # It reorders selection exactly as far as `directive` does and no further
    # — see `_route_to_topic`.
    routed_topic: Optional[str] = None
    # (Stage 13) Whether a topic with no unasked bank question may still yield
    # a slot. False when no provider is configured: a bank-less slot with
    # nothing able to write its text is not a question, it is an empty string.
    allow_synthesis: bool = False


@dataclass
class QuestionSlot:
    """(Stage 13) What selection decides, before anything decides the wording.

    `bank_question` is the entry the slot was drawn from, when there was one.
    It is NOT the question — it is where the signals came from and what the
    text falls back to. A slot with `bank_question=None` is a topic and tier
    the bank does not cover, which before this stage simply could not be
    asked.
    """

    topic: str
    tier: Tier
    type: str
    difficulty: int
    expected_signals: tuple[str, ...]
    concept_ids: tuple[str, ...]
    bank_question: Optional[BankQuestion] = None


@dataclass
class SelectedQuestion:
    question: Question
    quota_override: bool
    override_reason: Optional[str] = None
    # Set when `directive` actually changed which topic was picked, so the
    # decision is inspectable in telemetry rather than an invisible reordering.
    followed_directive: Optional[str] = None
    slot: Optional[QuestionSlot] = None


class NoQuestionsLeft(McpHandlerError):
    def __init__(self, message: str) -> None:
        super().__init__("no_questions_available", message)


class QuestionAgentServer:
    name = SERVER_NAME

    def __init__(self, deps: QuestionAgentDeps) -> None:
        self._deps = deps

    async def call(self, method: str, params: Any, ctx: McpCallContext) -> Any:
        p = params or {}

        if method == "build_topic_plan":
            plan = build_topic_plan(
                topic_relevance=[
                    TopicRelevance(topic=t["topic"], relevance_score=t["relevance_score"], evidence=t["evidence"])
                    for t in p.get("topic_relevance", [])
                ],
                required_topics=required_topics_for(p["role"]),
                jd_gap_topics=p.get("jd_gap_topics", []),
                question_budget=p["question_budget"],
            )
            return {"topic_plan": [{"topic": e.topic, "max_questions": e.max_questions, "source": e.source} for e in plan]}

        if method == "get_next_question":
            topic_plan_raw = p["topic_plan"]
            intro_entry = next((e for e in topic_plan_raw if e["topic"] == INTRODUCTION_TOPIC), None)
            intro_asked = p.get("topic_counts", {}).get(INTRODUCTION_TOPIC, 0)
            if intro_entry and intro_asked < intro_entry["max_questions"]:
                # (self-intro addition, §4.3) Fixed opener, always first, never
                # bank-selected or LLM-rewritten — outside the difficulty/tier
                # machinery entirely, unlike every other question.
                return {"question": _introduction_question_wire(p["session_id"])}

            # The harness supplies the raw performance signal; deciding what
            # difficulty that implies is this agent's job (§4.3). Still
            # computed as the fallback for topics `topic_tier` has no entry
            # for yet.
            difficulty_target = p.get("difficulty_target")
            if difficulty_target is None:
                difficulty_target = difficulty_target_from(p.get("recent_scores", []))

            topic_plan = [TopicPlanEntry(topic=e["topic"], max_questions=e["max_questions"], source=e["source"]) for e in p["topic_plan"]]

            # (Orchestration addition) The directive applies to the topic of
            # the exchange it was produced from — the most recent one in the
            # window. Without that anchor "stay on the topic" has no referent.
            next_action = p.get("next_action") or {}
            recent_exchanges = p.get("recent_exchanges") or []
            directive_topic = recent_exchanges[-1]["topic"] if recent_exchanges else None

            selected = select_next_question(
                SelectQuestionInput(
                    session_id=p["session_id"],
                    topic_plan=topic_plan,
                    topic_counts=p.get("topic_counts", {}),
                    asked_question_ids=p.get("asked_question_ids", []),
                    difficulty_target=difficulty_target,
                    topic_tier=p.get("topic_tier", {}),
                    topic_scores=p.get("topic_scores", {}),
                    directive=next_action.get("system_directive"),
                    directive_topic=directive_topic,
                    routed_topic=next_action.get("next_topic"),
                    allow_synthesis=bool(self._deps.tool_client) and self._deps.synthesis_enabled,
                )
            )

            # (Stage 5/F10, reshaped in Stage 13) Selection above is
            # deterministic and stays that way. Generation only decides the
            # WORDING of the slot it was handed, and adds a reference answer.
            generated = None
            if self._deps.tool_client:
                tools = self._deps.tool_client(p["session_id"], SERVER_NAME)
                generated = await _synthesize_question(
                    tools,
                    session_id=p["session_id"],
                    role=p.get("role", ""),
                    topic_plan=topic_plan,
                    candidate_profile_lines=p.get("candidate_profile_lines", []),
                    slot=selected.slot if self._deps.synthesis_enabled else None,
                    next_action=next_action,
                    recent_exchanges=recent_exchanges,
                    session_callbacks=p.get("session_callbacks") or [],
                    used_transitions=p.get("used_transitions") or [],
                )
                if generated is None and selected.slot and selected.slot.bank_question:
                    # The bank-backed rewrite path, byte-for-byte what ran
                    # before this stage. Only reachable when there IS bank text
                    # to sharpen.
                    generated = await _generate_question(
                        tools,
                        session_id=p["session_id"],
                        role=p.get("role", ""),
                        topic_plan=topic_plan,
                        candidate_profile_lines=p.get("candidate_profile_lines", []),
                        selected=selected.question,
                        next_action=next_action,
                        recent_exchanges=recent_exchanges,
                        session_callbacks=p.get("session_callbacks") or [],
                        used_transitions=p.get("used_transitions") or [],
                    )

            if generated is None and not selected.question.text:
                # A bank-less slot whose scenario could not be written. There
                # is nothing to ask, and an empty question must never reach a
                # candidate — the same outcome as an exhausted bank, reported
                # the same way (§4.3).
                raise NoQuestionsLeft(
                    f"no scenario could be synthesized for {selected.question.topic} at tier {selected.question.tier}, "
                    "and the question bank has no unasked entry for that slot"
                )

            target_concept_ids = list(selected.question.target_concept_ids or [])
            if generated and generated.get("expected_signals"):
                # (Stage 13) Verify against what the question actually asks.
                # The slot's signals were the specification; the generated ones
                # are what the written scenario reaches, and those are what the
                # Follow-up Agent's concept check should run against.
                target_concept_ids = [
                    concept_id(selected.question.topic, selected.question.tier or 1, label)
                    for label in generated["expected_signals"]
                ]

            wire: dict[str, Any] = {
                "id": selected.question.id,
                "bank_id": selected.question.bank_id,
                "session_id": selected.question.session_id,
                "text": generated["text"] if generated else selected.question.text,
                "topic": selected.question.topic,
                "type": selected.question.type,
                "difficulty": selected.question.difficulty,
                "quota_override": selected.quota_override,
            }
            if selected.question.tier is not None:
                wire["tier"] = selected.question.tier
            if target_concept_ids:
                wire["target_concept_ids"] = target_concept_ids
            if generated and generated.get("prompt_version"):
                wire["prompt_version"] = generated["prompt_version"]

            result: dict[str, Any] = {"question": wire}
            # Deliberately a SIBLING of `question`, not a field on it (§4.3,
            # §6) — routed straight to the Memory Agent by the harness.
            if generated and generated.get("reference_answer"):
                result["reference_answer"] = generated["reference_answer"]
            if selected.override_reason:
                result["override_reason"] = selected.override_reason
            # (Orchestration addition) Present only when the directive actually
            # changed the pick. The harness emits it as telemetry, so "the
            # interview stayed on databases because the last answer covered
            # tier 2" is a readable fact afterwards rather than an inference
            # from the question sequence.
            if selected.followed_directive:
                result["followed_directive"] = selected.followed_directive
            # (Stage 13) Whether this question's text was written from scratch
            # or drawn from the bank. Reported rather than inferred: the two
            # are indistinguishable in the transcript and mean different things
            # when a question turns out to have been a bad one.
            if generated and generated.get("source"):
                result["question_source"] = generated["source"]
            return result

        raise McpHandlerError("unknown_method", f"{SERVER_NAME} has no method {method}")


# ------------------------------------------------------------- generation


async def _synthesize_question(
    tools: Any,
    *,
    session_id: str,
    role: str,
    topic_plan: list[TopicPlanEntry],
    candidate_profile_lines: list[str],
    slot: Optional[QuestionSlot],
    next_action: Optional[dict[str, Any]] = None,
    recent_exchanges: Optional[list[dict[str, Any]]] = None,
    session_callbacks: Optional[list[dict[str, Any]]] = None,
    used_transitions: Optional[list[str]] = None,
) -> Optional[dict[str, Any]]:
    """(Stage 13) Writes the slot's scenario from scratch.

    The whole input is one JSON payload: the routing constraints the slot
    resolved to, and the candidate's parsed resume detail. **No baseline
    question text is sent** — that is the change this stage exists for, and
    it is enforced by construction rather than by asking the prompt nicely:
    there is nowhere in `prompt_input` to put one.

    Returns `None` — "fall back" — on every failure path, exactly as
    `_generate_question` does. A constraint violation is not a failure path
    on the first attempt: `validation_context` turns "wrong topic" or "wrong
    tier" into an ordinary schema error, which `structured_call` retries once
    with the violation as the corrective message before giving up.
    """
    from app.llm_client.tools import DYNAMIC_QUESTION_TOOL

    if slot is None:
        return None

    prompt_input: dict[str, Any] = {
        "constraints": {
            "topic": slot.topic,
            "tier": slot.tier,
            "type": slot.type,
            "difficulty": slot.difficulty,
            "expected_signals": list(slot.expected_signals),
        },
        "candidate": {
            "role": role,
            "profile_lines": list(candidate_profile_lines),
            "topic_plan": [{"topic": e.topic, "source": e.source} for e in topic_plan],
        },
    }
    if recent_exchanges:
        prompt_input["recent_exchanges"] = recent_exchanges
    if session_callbacks:
        prompt_input["session_callbacks"] = session_callbacks
    if used_transitions:
        prompt_input["used_transitions"] = used_transitions
    if next_action:
        prompt_input["next_action"] = {
            "system_directive": next_action.get("system_directive"),
            "transition_style": next_action.get("transition_style"),
            "synthesized_framing_strategy": next_action.get("synthesized_framing_strategy"),
            "routing_rationale": next_action.get("routing_rationale"),
        }

    try:
        generated = await tools.call(
            "tool-llm-provider",
            "generate_structured",
            {
                "session_id": session_id,
                "tool_name": DYNAMIC_QUESTION_TOOL["name"],
                "prompt_version": DYNAMIC_QUESTION_TOOL["prompt_version"],
                "schema_ref": DYNAMIC_QUESTION_TOOL["schema_ref"],
                "input": prompt_input,
                "source_documents": _source_documents(
                    topic_plan, candidate_profile_lines, recent_exchanges, session_callbacks
                ),
                # The per-call constraints Pydantic enforces. The slot is not
                # the model's to change, and this is where that stops being a
                # sentence in a prompt and becomes something that fails.
                "validation_context": {"question_constraints": {"topic": slot.topic, "tier": slot.tier}},
                # Two, not the default one: a malformed response and a
                # constraint violation are different failures, and one retry
                # can only cover whichever happens first.
                "retries": 2,
            },
        )
    except Exception:  # noqa: BLE001
        return None

    output = generated.get("output") if isinstance(generated, dict) else None
    if not output:
        return None

    # Belt and braces on top of the schema validator. The context is only
    # applied where `structured_call` was actually given it, and a question on
    # the wrong topic is the one failure that would corrupt the plan's
    # bookkeeping rather than merely read badly.
    if output.get("topic", "").strip().lower() != slot.topic.strip().lower():
        return None

    return {
        "text": output["question_text"],
        "reference_answer": output["reference_answer"],
        "expected_signals": list(output.get("expected_signals") or []),
        "prompt_version": generated.get("prompt_version"),
        "source": "synthesized",
    }


async def _generate_question(
    tools: Any,
    *,
    session_id: str,
    role: str,
    topic_plan: list[TopicPlanEntry],
    candidate_profile_lines: list[str],
    selected: Question,
    next_action: Optional[dict[str, Any]] = None,
    recent_exchanges: Optional[list[dict[str, Any]]] = None,
    session_callbacks: Optional[list[dict[str, Any]]] = None,
    used_transitions: Optional[list[str]] = None,
) -> Optional[dict[str, Any]]:
    """(F10) Rewrites the selected slot's question text and produces its
    reference answer in the same call. Returns None — "keep the bank
    question, score without a reference answer" — on every failure path.

    (Orchestration addition) The slot is still chosen entirely above; what is
    new here is that the model is told what came IMMEDIATELY before it. A
    question written with no knowledge of the last exchange can only open
    cold, which is what made the interview read as a list being worked
    through rather than a conversation. It gets the trailing exchanges and the
    directive that produced this slot — and it still may not change the
    topic, type, difficulty or tier it was handed.

    (Stage 13) This is now the SECOND path tried, not the first. It is
    unchanged in every other respect, and it is the reason removing the
    baseline from `question-agent/v6` did not have to be a one-way door: a
    deployment where synthesis misbehaves still has the bank rewrite under it.
    """
    from app.llm_client.tools import QUESTION_TOOL

    bank_question = next((q for q in QUESTION_BANK if q.id == selected.bank_id), None)

    prompt_input: dict[str, Any] = {
        "role": role,
        "topic_plan": [{"topic": e.topic, "max_questions": e.max_questions, "source": e.source} for e in topic_plan],
        "candidate_profile_lines": candidate_profile_lines,
        "baseline": {
            "text": selected.text,
            "topic": selected.topic,
            # The bank has no `coding` entries; a coding exercise is the
            # Coding Agent's job, not this one's (§4.5).
            "type": "technical" if selected.type == "coding" else selected.type,
            "difficulty": selected.difficulty,
            **({"tier": selected.tier} if selected.tier is not None else {}),
            **({"expected_signals": list(bank_question.expected_signals)} if bank_question else {}),
        },
    }
    if recent_exchanges:
        prompt_input["recent_exchanges"] = recent_exchanges
    # (§5) The long-range half of continuity, distinct from the trailing window.
    if session_callbacks:
        prompt_input["session_callbacks"] = session_callbacks
    # (§4) Phrasing this session has already spent. Pure plumbing: nothing here
    # decides anything, it just stops the model reaching for the same cue twice.
    if used_transitions:
        prompt_input["used_transitions"] = used_transitions
    if next_action:
        prompt_input["next_action"] = {
            "system_directive": next_action.get("system_directive"),
            "transition_style": next_action.get("transition_style"),
            "synthesized_framing_strategy": next_action.get("synthesized_framing_strategy"),
            "target_concept_id_for_next_prompt": next_action.get("target_concept_id_for_next_prompt"),
        }

    try:
        generated = await tools.call(
            "tool-llm-provider",
            "generate_structured",
            {
                "session_id": session_id,
                "tool_name": QUESTION_TOOL["name"],
                "prompt_version": QUESTION_TOOL["prompt_version"],
                "schema_ref": QUESTION_TOOL["schema_ref"],
                "input": prompt_input,
                "source_documents": _source_documents(
                    topic_plan, candidate_profile_lines, recent_exchanges, session_callbacks
                ),
            },
        )
    except Exception:  # noqa: BLE001
        return None

    output = generated.get("output") if isinstance(generated, dict) else None
    if not output:
        return None

    on_plan = any(e.topic == output["question"]["topic"] for e in topic_plan)
    if not on_plan:
        return None

    return {
        "text": output["question"]["text"],
        "reference_answer": output["reference_answer"],
        "expected_signals": list(output["question"].get("expected_signals") or []),
        "prompt_version": generated.get("prompt_version"),
        "source": "bank_rewrite",
    }


def _source_documents(
    topic_plan: list[TopicPlanEntry],
    candidate_profile_lines: list[str],
    recent_exchanges: Optional[list[dict[str, Any]]],
    session_callbacks: Optional[list[dict[str, Any]]],
) -> list[str]:
    """What a generated `evidence` string has to be a verbatim slice of.

    The plan this session is running, and the profile it was built from —
    plus (orchestration addition) what the candidate actually said in the
    trailing window. A question that transitions from the previous answer has
    to be able to cite that answer; without it in the source set, the
    grounding check would reject exactly the continuity we just asked for.
    The candidate's own words were already an admissible source for the
    Follow-up Agent's probes (§4.4) — this is the same standard, not a weaker
    one.

    (§5) The callback facts are admissible on exactly the same basis and for
    exactly the same reason: they are verbatim slices of the candidate's own
    answers, kept because the trailing window is too short to reach back to
    them. Leaving them out of the source set while putting them in the prompt
    would invite the model to cite a fact and then have the grounding check
    reject it — the failure mode is not an ungrounded question, it is a
    silently discarded generation on every turn that uses a callback.

    (Stage 13) Shared by both generation paths, which is the point of pulling
    it out: a synthesized question is grounded against exactly the same
    documents a rewritten one is. A from-scratch scenario held to a looser
    evidence standard than an edited bank question would be the whole stage
    going wrong quietly.
    """
    plan_text = "\n".join(f"{e.topic} ({e.source})" for e in topic_plan)
    exchange_text = "\n".join(
        f"{x['question']}\n{x.get('answer_excerpt', '')}" for x in (recent_exchanges or [])
    )
    callback_text = "\n".join(f.get("fact", "") for f in (session_callbacks or []))
    return [
        plan_text,
        "\n".join(candidate_profile_lines),
        *([exchange_text] if exchange_text.strip() else []),
        *([callback_text] if callback_text.strip() else []),
    ]


# -------------------------------------------------------------- selection


def select_next_question(input_: SelectQuestionInput) -> SelectedQuestion:
    # `asked_question_ids` are bank ids, so the same question is never
    # repeated even though each asking gets its own `Question.id`.
    asked = set(input_.asked_question_ids)

    under_cap = [e for e in input_.topic_plan if input_.topic_counts.get(e.topic, 0) < e.max_questions]

    # (Orchestration addition; Stage 13 routing) An `escalate`/`drill_down`
    # directive asks to stay on the topic just discussed and go a level
    # deeper; a routing decision may instead name the topic to move TO. Try
    # either FIRST, and only within the cap — a directive gets to reorder the
    # plan, never to overrun a quota. A topic already at its cap, or out of
    # askable slots, simply falls through to the normal ordering below; that
    # is the quota rule winning, which is the correct outcome (§4.3).
    routed = _route_to_topic(under_cap, input_, asked)
    if routed:
        slot, followed = routed
        return SelectedQuestion(
            question=_to_question(slot, input_.session_id),
            quota_override=False,
            followed_directive=followed,
            slot=slot,
        )

    # Normal path: pick from topics still under their cap.
    from_under_cap = _pick_from(under_cap, input_, asked)
    if from_under_cap:
        return SelectedQuestion(
            question=_to_question(from_under_cap, input_.session_id), quota_override=False, slot=from_under_cap
        )

    # Last resort (§4.3): every topic is capped but the budget is not spent.
    # Go over one cap — explicitly flagged, never silently.
    from_override = _pick_from(input_.topic_plan, input_, asked)
    if from_override:
        question = _to_question(from_override, input_.session_id)
        question.quota_override = True
        return SelectedQuestion(
            question=question,
            quota_override=True,
            slot=from_override,
            override_reason=(
                "every topic in the plan reached its cap before the question budget was spent"
                if not under_cap
                else "no unasked question remained under any topic's cap"
            ),
        )

    raise NoQuestionsLeft("the question bank has no unasked question left for any topic in this plan")


#: Directives that mean "the next question belongs to the same topic". `pivot`
#: means the opposite and `conclude` is the Harness Agent's alone — neither
#: reaches this path as a request to stay put (INSTRUCTIONS.md §12).
#:
#: (Human-interaction addition, §2) `support` stays too, and it is worth being
#: explicit about why that is safe rather than a way to strand a struggling
#: candidate on a topic they cannot do. Everything that bounds the other stay
#: directives bounds this one identically: the topic's cap still binds, so a
#: three-question topic gets at most three questions however often `support`
#: fires; an asked question is still excluded; and the tier still comes from
#: `next_tier_for`, which walks a topic DOWN a tier when its recent scores are
#: at or below 2 — the same floor `detect_struggle` uses. So a supported topic
#: gets a lower tier and a gentler framing, never an extra turn and never a
#: harder question.
_STAY_DIRECTIVES = frozenset({"escalate", "drill_down", "support"})


def _route_to_topic(
    entries: list[TopicPlanEntry], input_: SelectQuestionInput, asked: set[str]
) -> Optional[tuple[QuestionSlot, str]]:
    """(Orchestration addition; Stage 13) The directive-honouring branch of
    selection, and the only thing a directive or a routing decision is allowed
    to do: bring ONE topic to the front of the queue.

    Everything that made selection trustworthy is untouched — the cap still
    binds, an already-asked question is still excluded, and the tier still
    comes from `next_tier_for`, so an `escalate` on a topic whose scores do
    not support escalation does not get a harder question just because a
    directive asked for one. The Stage 13 addition changes only WHICH topic is
    brought forward, never how far the reordering reaches: a routing
    controller that named `databases` gets `databases` moved to the front,
    under exactly the same conditions a `support` directive would have moved
    the topic it was produced from.
    """
    # Preference order, and the ordering is the whole rule. A STAY directive
    # is authoritative about staying: `escalate`/`drill_down`/`support` were
    # produced by a detector looking at the answer that was just given, and a
    # routing controller reading a score cannot know better than "there is a
    # specific gap in this answer worth probing". So the directive's own topic
    # is tried first whenever there is one, and the routed topic is what the
    # interview moves to when the directive is `pivot`, when there is no
    # directive at all, or when the directive's topic turns out to be capped.
    #
    # The reverse ordering was tried and is wrong: it lets a routing decision
    # quietly cancel a `drill_down`, which is the interview forgetting the gap
    # it had just found.
    wanted: list[str] = []
    if input_.directive in _STAY_DIRECTIVES and input_.directive_topic:
        wanted.append(input_.directive_topic)
    if input_.routed_topic and input_.routed_topic not in wanted:
        wanted.append(input_.routed_topic)

    for topic in wanted:
        entry = next((e for e in entries if e.topic == topic), None)
        if not entry:
            continue
        slot = _pick_from([entry], input_, asked)
        if not slot:
            continue
        return slot, (input_.directive or "route")
    return None


def _pick_from(entries: list[TopicPlanEntry], input_: SelectQuestionInput, asked: set[str]) -> Optional[QuestionSlot]:
    # Behavioral topics last. Then least-covered topic first, so coverage stays even.
    def sort_key(e: TopicPlanEntry) -> tuple:
        topic_def = get_topic(e.topic)
        behavioral = 1 if topic_def and topic_def.kind == "behavioral" else 0
        count = input_.topic_counts.get(e.topic, 0)
        return (behavioral, count, -e.max_questions, e.topic)

    ordered = sorted(entries, key=sort_key)

    # (Stage 13) Two passes, and the order matters. A bank-backed slot is
    # preferred wherever one exists, because it carries a reviewed signal list
    # and a fallback text; a bank-less slot is only reached when no topic on
    # the plan has an unasked entry left. That keeps this stage strictly
    # additive: every session that could be selected before still selects
    # identically, and synthesis only reaches topics that previously fell
    # through to "no questions available".
    for entry in ordered:
        candidates = [q for q in questions_for_topic(entry.topic) if q.id not in asked]
        if not candidates:
            continue
        tier = next_tier_for(entry.topic, input_.topic_counts.get(entry.topic, 0), input_)
        return _slot_from_bank(pick_by_tier(candidates, tier))

    if not input_.allow_synthesis:
        return None

    for entry in ordered:
        tier = next_tier_for(entry.topic, input_.topic_counts.get(entry.topic, 0), input_)
        slot = _bankless_slot(entry.topic, tier)
        if slot:
            return slot
    return None


def _slot_from_bank(bank_question: BankQuestion) -> QuestionSlot:
    return QuestionSlot(
        topic=bank_question.topic,
        tier=bank_question.tier,
        type=bank_question.type,
        difficulty=bank_question.difficulty,
        expected_signals=bank_question.expected_signals[:_MAX_SIGNALS],
        concept_ids=bank_question.concept_ids,
        bank_question=bank_question,
    )


def _bankless_slot(topic: str, tier: Tier) -> Optional[QuestionSlot]:
    """(Stage 13) A slot for a topic+tier the bank does not cover.

    The signals come from the blueprint's extraction matrix for the topic at
    the *nearest* tier that has any — the concept vocabulary for a topic is
    the same at every tier, it is the depth that differs, and the depth is
    carried by `tier` itself. Failing that, the topic's own terms: a thin
    signal list is still a specification, and an empty one would let the model
    write anything it liked and call it on-topic.
    """
    definition = get_topic(topic)
    signals: list[str] = []
    try:
        blueprint = evaluation_topic_blueprint(topic)
        for candidate_tier in (tier, 2, 1, 3):
            ids = tier_spec(blueprint, candidate_tier).target_concept_ids  # type: ignore[arg-type]
            if ids:
                signals = [label_from_concept_id(cid) for cid in ids[:_MAX_SIGNALS]]
                break
    except Exception:  # noqa: BLE001 - a topic outside the bank is a normal case, not an error
        signals = []

    if not signals and definition:
        signals = [f"working knowledge of {term}" for term in definition.terms[:3]]
    if not signals:
        return None

    kind = definition.kind if definition else "technical"
    return QuestionSlot(
        topic=topic,
        tier=tier,
        type=kind,
        # Kept in lockstep with the tier exactly as the bank's own entries are
        # (`tier_of`), so `difficulty` means the same thing whether the slot
        # came from the bank or not.
        difficulty=min(5, tier + 1),
        expected_signals=tuple(signals[:_MAX_SIGNALS]),
        concept_ids=tuple(concept_id(topic, tier, label) for label in signals[:_MAX_SIGNALS]),
        bank_question=None,
    )


def next_tier_for(topic: str, asked_in_topic: int, input_: SelectQuestionInput) -> Tier:
    """(Stage 6, §4.3) Per-topic tier escalation. A topic with no tier on
    record yet falls back to the pre-Stage-6 global difficulty curve, mapped
    onto a tier."""
    recorded = input_.topic_tier.get(topic)
    if recorded is not None:
        current = _clamp_tier(recorded)
        scores = input_.topic_scores.get(topic, [])
        if not scores:
            return current
        recent = scores[-2:]
        average = sum(recent) / len(recent)
        if average >= 4 and current < 3:
            return current + 1  # type: ignore[return-value]
        if average <= 2 and current > 1:
            return current - 1  # type: ignore[return-value]
        return current

    wanted = max(1, min(5, int(input_.difficulty_target) - 1 + asked_in_topic))
    return tier_of(wanted)


def _clamp_tier(tier: int) -> Tier:
    if tier < 1:
        return 1
    if tier > 3:
        return 3
    return tier  # type: ignore[return-value]


def pick_by_tier(candidates: list[BankQuestion], tier: Tier) -> BankQuestion:
    """Prefers an unasked question at exactly the wanted tier; falls back to
    the nearest tier that still has one."""
    return sorted(candidates, key=lambda q: (abs(q.tier - tier), q.tier, q.id))[0]


def _introduction_question_wire(session_id: str) -> dict[str, Any]:
    question = Question(
        id=str(uuid.uuid4()),
        bank_id=INTRODUCTION_QUESTION_BANK_ID,
        session_id=session_id,
        text=INTRODUCTION_QUESTION_TEXT,
        topic=INTRODUCTION_TOPIC,
        type="behavioral",
        difficulty=1,
        tier=1,
        target_concept_ids=[],
        asked_at=datetime.now(timezone.utc).isoformat(),
    )
    return {
        "id": question.id,
        "bank_id": question.bank_id,
        "session_id": question.session_id,
        "text": question.text,
        "topic": question.topic,
        "type": question.type,
        "difficulty": question.difficulty,
        "tier": question.tier,
        "quota_override": False,
    }


def _to_question(slot: QuestionSlot, session_id: str) -> Question:
    """The `Question` row for a slot.

    `text` is empty for a bank-less slot and is filled in by synthesis; a
    slot that reaches the wire still empty is refused by the caller rather
    than asked (see `get_next_question`). `bank_id` keeps the bank entry's own
    id when there is one, so the already-asked exclusion and the coverage
    ordering keep working exactly as they did; a synthesized slot gets a
    `synth:` id, which is unique by construction and therefore excludes
    nothing.
    """
    bank = slot.bank_question
    return Question(
        id=str(uuid.uuid4()),
        bank_id=bank.id if bank else f"synth:{slot.topic.replace(' ', '-')}.t{slot.tier}.{uuid.uuid4().hex[:8]}",
        session_id=session_id,
        text=bank.text if bank else "",
        topic=slot.topic,
        type=slot.type,
        difficulty=slot.difficulty,
        tier=slot.tier,
        target_concept_ids=list(slot.concept_ids),
        asked_at=datetime.now(timezone.utc).isoformat(),
    )


def difficulty_target_from(recent_scores: list[float], base: float = 3) -> float:
    """Difficulty target from the running performance signal: strong answers
    pull the next question up, weak ones pull it down, and it never leaves
    1-5. Calibration only — the Question Agent does not score (§4.3)."""
    if not recent_scores:
        return base
    recent = recent_scores[-3:]
    average = sum(recent) / len(recent)
    if average >= 4:
        return min(5, base + 1)
    if average <= 2:
        return max(1, base - 1)
    return base


def covered_topics() -> list[str]:
    """Every topic the bank can actually ask about — used to sanity-check a plan."""
    seen: dict[str, None] = {}
    for q in QUESTION_BANK:
        seen.setdefault(q.topic, None)
    return list(seen.keys())


def create_question_agent_server(deps: Optional[QuestionAgentDeps] = None) -> QuestionAgentServer:
    return QuestionAgentServer(deps or QuestionAgentDeps())

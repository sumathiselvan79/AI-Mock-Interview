"""Topic planning — ~ agents/question-agent/src/topic-plan.ts. INSTRUCTIONS.md §4.3, step by step:

 1. Start from the resume's `topic_relevance[]` and union it with the role's
    fixed `required_topics[]` plus any `jd_fit.gaps[]`.
 2. Distribute `question_budget` across that set, weighted by relevance, with
    a floor of 1 and a ceiling of 3 per topic. Every required topic gets at
    least one slot even at relevance 0.
 3. The result is `topic_plan[]`.

The floor and ceiling are what soul.md §"Balanced coverage" is asking for:
no single standout line on a resume gets to dominate a session, and a
role-critical topic is covered even when the resume is silent on it.

(self-intro addition) A fixed `introduction` entry (quota exactly 1) is
prepended ahead of that whole quota-capped set — it is asked outside
`question_budget`, not one of the topics competing for a share of it, so it
is added after the budget distribution above runs, never as a candidate
inside it.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from app.interview_domain import INTRODUCTION_TOPIC
from app.shared_types import TOPIC_QUESTION_CEILING, TOPIC_QUESTION_FLOOR, TopicPlanEntry, TopicRelevance


@dataclass
class Candidate:
    topic: str
    weight: float
    source: str  # "resume" | "role_requirement" | "jd_gap"


def build_topic_plan(
    *, topic_relevance: list[TopicRelevance], required_topics: list[str], question_budget: int, jd_gap_topics: Optional[list[str]] = None
) -> list[TopicPlanEntry]:
    jd_gap_topics = jd_gap_topics or []
    candidates: dict[str, Candidate] = {}

    # Resume-derived topics, strongest first.
    for entry in topic_relevance:
        if entry.relevance_score <= 0:
            continue
        candidates[entry.topic] = Candidate(topic=entry.topic, weight=entry.relevance_score, source="resume")

    # Role requirements and JD gaps. A topic already present keeps its resume
    # weight — the requirement only guarantees it a slot, it does not inflate it.
    for topic in jd_gap_topics:
        candidates.setdefault(topic, Candidate(topic=topic, weight=0, source="jd_gap"))
    for topic in required_topics:
        candidates.setdefault(topic, Candidate(topic=topic, weight=0, source="role_requirement"))

    if not candidates:
        return []

    guaranteed = set(required_topics) | set(jd_gap_topics)

    # Order: relevance first, then guaranteed topics, so that when the budget
    # is tighter than the topic set the interview still covers what the role demands.
    ordered = sorted(
        candidates.values(),
        key=lambda c: (-c.weight, 0 if c.topic in guaranteed else 1, c.topic),
    )

    # A budget smaller than the topic set cannot give everyone a slot.
    # Required topics keep theirs; the weakest resume-only topics drop out
    # entirely rather than every topic getting a fractional, unusable share.
    selected = _select_within_budget(ordered, guaranteed, question_budget)

    # Everyone starts at the floor, then leftover budget is handed out by
    # weight, never past the ceiling.
    plan: dict[str, int] = {c.topic: TOPIC_QUESTION_FLOOR for c in selected}
    remaining = question_budget - len(selected)

    total_weight = sum(c.weight for c in selected)
    if remaining > 0 and total_weight > 0:
        for candidate in selected:
            if remaining <= 0:
                break
            share = int((candidate.weight / total_weight) * (question_budget - len(selected)))
            grant = min(share, TOPIC_QUESTION_CEILING - TOPIC_QUESTION_FLOOR, remaining)
            if grant > 0:
                plan[candidate.topic] = plan.get(candidate.topic, 0) + grant
                remaining -= grant

    # Rounding leaves a remainder; give it to the strongest topics still
    # under the ceiling, in order.
    while remaining > 0:
        next_candidate = next((c for c in selected if plan.get(c.topic, 0) < TOPIC_QUESTION_CEILING), None)
        if not next_candidate:
            break
        plan[next_candidate.topic] = plan.get(next_candidate.topic, 0) + 1
        remaining -= 1
        # Re-sort so the extra slots spread rather than piling onto the first topic.
        selected.sort(key=lambda c: (plan.get(c.topic, 0), -c.weight))

    entries = [TopicPlanEntry(topic=c.topic, max_questions=plan.get(c.topic, TOPIC_QUESTION_FLOOR), source=c.source) for c in selected]
    return [TopicPlanEntry(topic=INTRODUCTION_TOPIC, max_questions=1, source="introduction"), *entries]


def _select_within_budget(ordered: list[Candidate], guaranteed: set[str], budget: int) -> list[Candidate]:
    if len(ordered) <= budget:
        return list(ordered)

    must_keep = [c for c in ordered if c.topic in guaranteed]
    optional = [c for c in ordered if c.topic not in guaranteed]
    room = max(0, budget - len(must_keep))

    # If the required topics alone exceed the budget, they all still get a
    # slot: covering what the role demands beats respecting the budget exactly.
    selected_topics = {c.topic for c in (*must_keep, *optional[:room])}
    return [c for c in ordered if c.topic in selected_topics]


def plan_capacity(plan: list[TopicPlanEntry]) -> int:
    """Total questions a plan accounts for. Should equal the budget when it fits."""
    return sum(entry.max_questions for entry in plan)

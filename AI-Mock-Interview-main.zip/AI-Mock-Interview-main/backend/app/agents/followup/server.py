"""Follow-up Question Agent — ~ agents/followup-agent/src/index.ts. INSTRUCTIONS.md §4.4.

Given an answer, decides whether to probe deeper and writes the probe.

Two constraints shape everything here:
 - **Never generic.** Every probe this agent produces quotes or names
   something the candidate actually said, and `reason` says which gap it is
   aimed at.
 - **Probing, not trapping.** soul.md §3: a good follow-up "makes a strong
   candidate demonstrate why they're strong, and gives a struggling
   candidate a fair chance to recover".

A low-confidence transcript is never probed (soul.md §5) — the harness must
re-prompt or take typed text first.

**(Stage 13) It also routes.** Until this stage the agent's whole output was
about the answer in front of it: probe this gap, or reframe for this
struggling candidate — always on the same topic. `next_action` could say
"escalate" or "pivot" but never *where to*, so "pivot" meant nothing more
than "let the plan's default ordering decide", and a candidate who had just
demonstrated real depth in one area and visible weakness in another got the
next question from a fixed list either way.

`next_action` now carries `next_topic`, `next_tier` and `routing_rationale`,
computed by `interview_domain.routing.determine_next_node` from the rolling
performance snapshot the harness supplies as `routing_context`. Three things
about that are deliberate:

 - **It is deterministic.** The routing decision is arithmetic over scores
   the Eval Tool produced, not a judgement an LLM makes. This agent's shape
   has always been detector -> directive -> narrow phrasing
   (`HUMAN_INTERACTION_FLOW.md`, CLAUDE.md §17), and routing is another
   detector, not an escape from that shape.
 - **It is a proposal.** The Question Agent still enforces the cap, the
   already-asked exclusion and the tier. A named topic reorders selection and
   does nothing else (CLAUDE.md §16).
 - **It never overrides the follow-up decision for THIS turn.** A struggling
   candidate still gets their supportive reframe now; routing only decides
   where the interview goes after it. The one thing it may change is the
   directive itself, and only in one direction: a candidate who has not
   recovered on a topic across two answers gets `pivot` to an adjacent topic
   instead of a third question on the one they are stuck on.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from app.interview_domain import INTRODUCTION_TOPIC
from app.interview_domain.question_bank import label_from_concept_id
from app.interview_domain.routing import InterviewSession, NextNode, determine_next_node
from app.interview_domain.signals import HEDGE_RE, METRIC_RE, SHORT_ANSWER_WORDS
from app.interview_domain.transitions import transition_style_for
from app.shared_types import McpCallContext, McpHandlerError

SERVER_NAME = "followup-agent"
METHODS = ("consider_follow_up", "score_follow_up_exchange")

# Below this, the transcript is not reliable enough to reason about.
MIN_CONFIDENCE = 0.6


@dataclass
class FollowupAgentDeps:
    tool_client: Optional[Any] = None  # ToolClientFactory


@dataclass
class AnswerScore:
    rubric_id: str
    value: float
    rationale: str
    evidence_spans: list[dict[str, int]]
    # (Grading addition) The band the Eval Tool put this score in. Carried, not
    # computed: this agent has no copy of the ladder, so the letter the
    # candidate sees mid-interview and the one in their report are the same
    # judgement rather than two that happen to agree.
    grade: Optional[dict[str, Any]] = None


@dataclass
class FollowUpDecision:
    should_follow_up: bool
    reason: str
    anti_patterns_detected: list[str]
    follow_up_text: Optional[str] = None


@dataclass
class ConceptVerification:
    verified: list[str]
    unverified: list[str]


@dataclass
class Gap:
    id: str
    reason: str
    probe: Callable[[str], str]


# "I <past-tense verb>". `\w+ed` covers the regular cases so the agent is
# not limited to a hand-written verb list; the alternation covers the irregulars.
_FIRST_PERSON_ACTION = re.compile(
    r"\b(?:i|we)\s+(?:\w+ed|built|wrote|led|ran|chose|took|made|set|got|found|split|rewrote|sent|brought|kept|"
    r"drove|shipped|spent|went|began|broke|caught|dealt|held|left|lost|met|paid|put|read|sold|taught|told|"
    r"thought|understood|won|dug|rebuilt|undid)\b",
    re.IGNORECASE,
)
_OUTCOME = re.compile(
    r"\b(?:as a result|which meant|the result was|the outcome|the impact|ended up|we went from|reduced|"
    r"increased|improved|cut|saved)\b",
    re.IGNORECASE,
)
_TRADEOFF = re.compile(
    r"\b(?:tradeoff|trade-off|instead of|rather than|the alternative|we considered|the downside|the drawback|because)\b",
    re.IGNORECASE,
)
# Shared with the harness's cross-turn struggle signals and callback picker
# (`interview_domain/signals.py`) — the same words, read over one answer here
# and over several there.
_HEDGE = HEDGE_RE
_METRIC = METRIC_RE
_TEAM_CREDIT = re.compile(r"\bwe\b", re.IGNORECASE)

# Ordered by what an interviewer would probe first: a claim with no owner,
# then a claim with no result, then a decision with no reasoning.
_GAPS: tuple[Gap, ...] = (
    Gap("no_personal_action", "the answer describes what happened but not what the candidate personally did",
        lambda anchor: f"You mentioned {anchor} — I'd like to understand your specific role there. What did you personally do, and what decisions did you make?"),
    Gap("team_without_self", "the answer is framed entirely as team work, so the candidate's own contribution is unclear",
        lambda anchor: f'When you said "{anchor}", what was the part that was distinctly yours? How would your teammates describe your contribution?'),
    Gap("no_outcome", "the answer describes actions but never says how it turned out",
        lambda anchor: f"That's helpful context on {anchor}. What happened as a result? Did it move the needle on anything you could observe?"),
    Gap("unquantified_claim", "the answer claims an improvement without any measure of it",
        lambda anchor: f"You mentioned {anchor} — can you give me a sense of the scale? Even a rough before-and-after would help me understand the impact."),
    Gap("no_reasoning", "the answer states a decision without the reasoning or the alternatives behind it",
        lambda anchor: f"I'm curious about the thinking behind {anchor}. What alternatives did you consider, and what made you go this direction?"),
    Gap("hedged_claim", "a key part of the answer is hedged, so it is unclear what the candidate actually knows",
        lambda anchor: f'You mentioned "{anchor}" — could you be more specific there? I\'d love to hear what you know for certain rather than a general impression.'),
)
_GAPS_BY_ID = {g.id: g for g in _GAPS}


# ---------------------------------------------------- struggle detection (§2)
#
# `_GAPS` above is built entirely around probing a CAPABLE candidate deeper —
# every entry assumes there is a claim on the table worth pushing on. It has no
# entry for "this candidate is stuck", so a candidate who is struggling fell
# into the generic `too_short_to_probe` branch, which offers a way in but reads
# exactly the same for someone being vague-but-confident as for someone who has
# run out of road. A human interviewer shifts tone at that point.
#
# This is the sibling detector (`HUMAN_INTERACTION_FLOW.md` §2), and it obeys
# the same rule as everything else here: it decides *that* support is warranted
# and supplies the deterministic baseline reframe. The model only phrases it.
#
# Two things it is careful NOT to do:
#  - It never lowers the bar. A reframe changes the way into a question, not
#    what a good answer to it has to contain — the rubric is the Eval Tool's
#    and this agent has no copy of it (CLAUDE.md §8).
#  - It never manufactures encouragement about content that was not
#    demonstrated (soul.md §3). Every baseline below talks about the question
#    or about what to try next, never about how the last answer went.

#: "I don't know" and its neighbours, as the WHOLE of a clause rather than
#: anywhere in the answer — "I wasn't sure whether to shard" is a candidate
#: reasoning out loud, not one who is stuck.
_EXPLICIT_UNKNOWN = re.compile(
    r"(?:^|[.!?;,]\s*)(?:i'?m\s+(?:really\s+|honestly\s+)?not\s+sure|i\s+(?:really\s+|honestly\s+)?(?:don'?t|do not)\s+know|"
    r"i\s+have\s+no\s+idea|no\s+idea|i'?ve\s+never\s+(?:done|used|worked\s+with|come\s+across)\s+\w+|"
    r"i\s+can'?t\s+(?:think\s+of|remember)\s+(?:one|any|anything)|i'?m\s+drawing\s+a\s+blank)"
    r"\s*(?:[.!?,]|$)",
    re.IGNORECASE,
)

#: A topic average at or below this reads as the candidate losing the thread on
#: it. Same number `next_tier_for` steps a topic's tier back down at, so the
#: supportive reframe and the easier tier arrive together rather than one
#: contradicting the other.
STRUGGLE_SCORE_FLOOR = 2.0

#: Two consecutive answers of either kind. One short answer or one hedged
#: sentence is a normal turn; the second in a row is the signal.
STRUGGLE_STREAK = 2


@dataclass(frozen=True)
class StruggleSignal:
    id: str
    reason: str
    #: The deterministic reframe. Handed to the model as the baseline, exactly
    #: as `Gap.probe` output is, so a provider outage degrades to this text
    #: rather than to no support at all.
    reframe: str


_STRUGGLE_SIGNALS: dict[str, StruggleSignal] = {
    signal.id: signal
    for signal in (
        StruggleSignal(
            "struggle_explicit_unknown",
            "the candidate said outright that they do not know this, so probing the answer would probe nothing",
            "Let's make that smaller. Think of any time you've been near this — even watching someone else handle it — and tell me what you saw happen.",
        ),
        StruggleSignal(
            "struggle_repeated_short_answer",
            "a second consecutive answer with almost nothing in it, which reads as stuck rather than as brief",
            "Let's try a more concrete way in: pick one specific occasion, and start with just the situation — what was going on, and who needed what.",
        ),
        StruggleSignal(
            "struggle_sustained_hedging",
            "the candidate has hedged across consecutive answers, so it is unclear what they are actually sure of",
            "Let's stay with what you're certain about. Name one part of this you've done yourself, and tell me what happened when you did.",
        ),
        StruggleSignal(
            "struggle_topic_score_drop",
            "this topic's recent scores have fallen far enough that another question at the same angle is unlikely to surface anything new",
            "Let's come at this from a different direction — start with whichever part of it you're most comfortable with, and we'll build out from there.",
        ),
    )
}


def detect_struggle(
    *,
    answer_transcript: str,
    consecutive_short_answers: int = 0,
    hedge_streak: int = 0,
    topic_recent_scores: Optional[list[float]] = None,
) -> Optional[StruggleSignal]:
    """The first struggle signal this turn shows, or `None`.

    Everything except the transcript arrives from the harness — this agent
    never queries the Memory Agent itself (§4.7), so a running hedge count or a
    per-topic score history is passed in the same way `topic_counts` is passed
    to the Question Agent.

    Ordered by how certain the signal is. An explicit "I don't know" needs no
    corroboration; a score trend is the weakest of the four and is checked
    last, because a low score can also mean a hard question answered honestly.
    """
    transcript = (answer_transcript or "").strip()

    if transcript and _EXPLICIT_UNKNOWN.search(transcript):
        return _STRUGGLE_SIGNALS["struggle_explicit_unknown"]

    if consecutive_short_answers >= STRUGGLE_STREAK:
        return _STRUGGLE_SIGNALS["struggle_repeated_short_answer"]

    # The streak counts PRIOR answers, so this turn has to hedge too — a
    # candidate who has just stopped hedging is not still struggling.
    if hedge_streak >= STRUGGLE_STREAK - 1 and _HEDGE.search(transcript):
        return _STRUGGLE_SIGNALS["struggle_sustained_hedging"]

    scores = topic_recent_scores or []
    if len(scores) >= STRUGGLE_STREAK:
        recent = scores[-2:]
        if sum(recent) / len(recent) <= STRUGGLE_SCORE_FLOOR:
            return _STRUGGLE_SIGNALS["struggle_topic_score_drop"]

    return None


class FollowupAgentServer:
    name = SERVER_NAME

    def __init__(self, deps: FollowupAgentDeps) -> None:
        self._deps = deps

    async def call(self, method: str, params: Any, ctx: McpCallContext) -> Any:
        p = params or {}
        if method == "consider_follow_up":
            return await _consider_follow_up_call(self._deps, p)
        if method == "score_follow_up_exchange":
            return await _score_follow_up_exchange(self._deps, p)
        raise McpHandlerError("unknown_method", f"{SERVER_NAME} has no method {method}")


async def _consider_follow_up_call(deps: FollowupAgentDeps, p: dict[str, Any]) -> dict[str, Any]:
    """(Stage 5, §4.4/§11.2) Score first, then decide. Scoring at follow-up
    time rather than at REPORT_GENERATION is what leaves a dropped session
    with scored answers on record. The score MAY inform the decision, but per
    soul.md a high score never suppresses a follow-up a specific gap warrants."""
    tools = deps.tool_client(p["session_id"], SERVER_NAME) if deps.tool_client and p.get("session_id") else None

    # 1. The deterministic gap detector. It decides *whether* there is
    #    something specific to probe; the model only gets to phrase it.
    decision = consider_follow_up(
        question=p["question"], answer_transcript=p["answer_transcript"], transcript_confidence=p.get("transcript_confidence"), topic=p.get("topic")
    )

    # 1b. (§2) The struggle detector, run alongside the gap detector on the
    #     same transcript. It does not replace the gap decision — it changes
    #     what a follow-up is FOR when one is warranted, from "push on this
    #     claim" to "offer a way back in", and it sets the directive that
    #     steers the next question either way.
    #
    #     Skipped entirely on a low-confidence transcript: `consider_follow_up`
    #     has already refused to reason about it, and "the candidate is
    #     struggling" is exactly the kind of conclusion soul.md §5 does not let
    #     us draw from words nobody confirmed they said.
    struggle_context = p.get("struggle_context") or {}
    struggle = (
        detect_struggle(
            answer_transcript=p["answer_transcript"],
            consecutive_short_answers=int(struggle_context.get("consecutive_short_answers") or 0),
            hedge_streak=int(struggle_context.get("hedge_streak") or 0),
            topic_recent_scores=struggle_context.get("topic_recent_scores"),
        )
        if "low_confidence_transcript" not in decision.anti_patterns_detected
        else None
    )
    if struggle:
        decision = _supportive_decision(decision, struggle)

    # 2. Score the triggering answer, persisted immediately as an
    #    `Evaluation` because `answer_id` is supplied.
    #
    #    Note the order: support is decided BEFORE the score arrives and does
    #    not consult it. A reframe is about the shape of the conversation, not
    #    about the mark — and the mark this answer gets is the same either way.
    scored = await _score_answer(tools, p) if tools else None
    score = scored[0] if scored else None

    # 3. Phrase the probe.
    generated = await _generate_probe(tools, p, decision, struggle) if (tools and decision.should_follow_up) else None

    # In support mode the model gets to phrase the reframe, not to withdraw it:
    # whether a stuck candidate is offered a way back in was decided by
    # `detect_struggle`, and letting a `should_follow_up: false` overturn that
    # would put interview logic back in the model's hands (§2's whole premise).
    # (C5) A generation that says "follow up" but supplies no `follow_up_text`
    # is not used at all. It used to be used halfway — the template's question
    # shipped next to the model's `reason`, so the two described different
    # gaps. Text and reason now always come from the same source.
    if generated and (generated.get("should_follow_up") or struggle) and not generated.get("follow_up_text"):
        generated = None
    should_follow_up = True if struggle else (generated["should_follow_up"] if generated else decision.should_follow_up)
    follow_up_text = (generated.get("follow_up_text") if generated else None) or decision.follow_up_text

    # 4. (Stage 6, §4.4) Concept verification, against this question's own
    #    target concepts.
    target_concept_ids = p.get("target_concept_ids") or []
    verification = await _verify_concepts(tools, p["answer_transcript"], target_concept_ids) if (tools and target_concept_ids) else None

    reason = (generated.get("reason") if generated else None) or decision.reason

    # (Stage 13) The routing decision, folded in AFTER the score exists —
    # `_score_answer` above has already run, so the harness's snapshot plus
    # this turn's score is the freshest signal available. A missing
    # `routing_context` (a caller that does not track one, every pre-Stage-13
    # test) produces no node and leaves `next_action` exactly as it was.
    node = _route(p, score)

    next_action = _compute_next_action(
        should_follow_up=should_follow_up,
        follow_up_text=follow_up_text,
        reason=reason,
        verification=verification,
        tier=p.get("tier"),
        struggle=struggle,
        node=node,
    )

    result: dict[str, Any] = {
        "should_follow_up": should_follow_up,
        "reason": reason,
        "anti_patterns_detected": decision.anti_patterns_detected,
        "next_action": next_action,
    }
    if should_follow_up and follow_up_text:
        result["follow_up_text"] = follow_up_text
    if verification:
        result["verified_concept_ids"] = verification.verified
        result["unverified_concept_ids"] = verification.unverified
    # (§2) Named so the harness can emit the span the cross-cutting notes
    # require — "why did the interview soften there?" has to be answerable
    # afterwards, and `support` alone does not say which signal fired.
    if struggle:
        result["struggle_signal"] = struggle.id
    if score:
        result["score"] = {
            "rubric_id": score.rubric_id,
            "value": score.value,
            "rationale": score.rationale,
            "evidence_spans": score.evidence_spans,
            **({"grade": score.grade} if score.grade else {}),
        }
    # The Eval Tool's own words, not a paraphrase of them (soul.md §6).
    if scored and scored[1]:
        result["score_note"] = scored[1]
    return result


def _supportive_decision(decision: FollowUpDecision, struggle: StruggleSignal) -> FollowUpDecision:
    """(§2) Turns a gap-shaped decision into a support-shaped one.

    A struggling candidate always gets a follow-up, including when the gap
    detector found nothing to probe: "no gap" on an "I don't know" means there
    was no claim in the answer, not that the answer was complete. Moving
    straight to the next question there is the mechanical behaviour this
    replaces.

    The detected gap ids are kept alongside the struggle id. They are still
    true — what changes is which one the interview acts on.
    """
    return FollowUpDecision(
        should_follow_up=True,
        follow_up_text=struggle.reframe,
        reason=struggle.reason,
        anti_patterns_detected=[struggle.id, *decision.anti_patterns_detected],
    )


def _route(p: dict[str, Any], score: Optional[AnswerScore]) -> Optional[NextNode]:
    """(Stage 13) The routing proposal for the NEXT question.

    `routing_context` arrives from the Harness Agent for the same reason
    `struggle_context` and `topic_counts` do: this agent never queries the
    Memory Agent or the stores itself (§4.7). Absent, or carrying no topics to
    choose between, there is nothing to route and `next_action` is exactly
    what it was before this stage.

    The snapshot is assembled here rather than sent whole so that THIS turn's
    score — which the caller has only just obtained, a few lines above — is
    part of the decision. Routing off a snapshot that stops one answer short
    would make every decision a turn late, which for a "real-time performance
    trajectory" is the one thing it must not be.
    """
    context = p.get("routing_context") or {}
    available = list(context.get("available_topics") or [])
    if not available:
        return None

    topic = p.get("topic")
    topic_scores = {name: list(scores) for name, scores in (context.get("topic_scores") or {}).items()}
    if score is not None and topic:
        # The Eval Tool has scored this answer but nothing has persisted it
        # into the harness's snapshot yet.
        topic_scores.setdefault(topic, []).append(score.value)

    session = InterviewSession(
        session_id=p.get("session_id") or "",
        current_topic=topic,
        current_tier=_clamp_routing_tier(p.get("tier") or context.get("current_tier") or 1),
        exhausted_topics=list(context.get("exhausted_topics") or []),
        rolling_score=context.get("rolling_score"),
        last_score=score.value if score is not None else context.get("last_score"),
        topic_scores=topic_scores,
        topic_tier={name: int(value) for name, value in (context.get("topic_tier") or {}).items()},
    )
    return determine_next_node(session, available_topics=available, topic_counts=context.get("topic_counts") or {})


def _clamp_routing_tier(tier: Any) -> int:
    try:
        return max(1, min(3, int(tier)))
    except (TypeError, ValueError):
        return 1


def _with_routing(action: dict[str, Any], node: Optional[NextNode]) -> dict[str, Any]:
    """(Stage 13) Folds a routing proposal into a computed directive.

    Two rules, and the asymmetry between them is the point:

     - Routing always ANNOTATES. `next_topic`/`next_tier`/`routing_rationale`
       are added whatever the directive says, because the Question Agent
       consults the named topic only where the directive leaves the choice
       open (see `_route_to_topic`) — an annotation cannot cancel a probe.

     - Routing may CHANGE the directive in exactly one case: the candidate has
       not recovered on this topic across `STUCK_STREAK` answers, so a third
       question on it is not support, it is an interview that has stopped
       listening. `support` becomes `pivot` and the framing follows. The
       supportive follow-up for THIS turn is untouched — `should_follow_up`
       and `follow_up_text` are decided above and not read here — so the
       candidate still gets their way back in before the interview moves on.
    """
    if node is None:
        return action

    routed = dict(action)
    if node.lateral_pivot and routed.get("system_directive") == "support" and node.topic:
        routed["system_directive"] = "pivot"
        routed["transition_style"] = transition_style_for("pivot")
        routed["synthesized_framing_strategy"] = (
            f"The candidate has not found a way into this topic across consecutive answers, so the interview "
            f"moves to {node.topic}, which is adjacent to it. Open the new topic cleanly on its own terms. Do "
            "not refer to the difficulty they had, do not apologise for the previous question, and do not "
            "comment on how the last answer went."
        )

    if node.topic:
        routed["next_topic"] = node.topic
        routed["next_tier"] = node.tier
    if node.rationale:
        routed["routing_rationale"] = node.rationale
    return routed


def _compute_next_action(
    *,
    should_follow_up: bool,
    follow_up_text: Optional[str],
    reason: str,
    verification: Optional[ConceptVerification],
    tier: Optional[int],
    struggle: Optional[StruggleSignal] = None,
    node: Optional[NextNode] = None,
) -> dict[str, Any]:
    """(Stage 6, §4.4) Deterministic, same as everything else this agent
    decides for itself — the LLM call only phrases the probe, never whether
    to escalate, pivot, drill down, or support.

    (Stage 13) `node` is the routing proposal. Every return below goes through
    `_with_routing`, which is what makes "the directive is computed here and
    routing only annotates it" true by construction rather than by four
    remembered call sites."""
    # (§2) Checked before the gap branch: when both a gap and a struggle are
    # present, the struggle is the one that should shape the next question.
    # Probing a stuck candidate harder is the behaviour soul.md §3 rules out.
    if struggle:
        return _with_routing({
            "system_directive": "support",
            "transition_style": transition_style_for("support"),
            "target_concept_id_for_next_prompt": (verification.unverified[0] if verification and verification.unverified else None),
            "synthesized_framing_strategy": (
                f"The candidate is struggling here ({struggle.reason}). Stay on this topic but offer a more concrete "
                "way in — a smaller scope, or a more familiar angle. Do not lower what a good answer has to contain, "
                "do not comment on how the last answer went, and do not offer reassurance about work they have not described."
            ),
            "generated_follow_up_prompt": follow_up_text,
        }, node)

    if should_follow_up:
        directive = "drill_down"
        return _with_routing({
            "system_directive": directive,
            "transition_style": transition_style_for(directive),
            "target_concept_id_for_next_prompt": (verification.unverified[0] if verification and verification.unverified else None),
            "synthesized_framing_strategy": f'Target the detected gap ({reason}) with a probe anchored in what the candidate actually said — never a generic "tell me more".',
            "generated_follow_up_prompt": follow_up_text,
        }, node)

    tier_covered = verification is not None and len(verification.verified) > 0 and len(verification.unverified) == 0

    if tier_covered and tier is not None and tier < 3:
        directive = "escalate"
        return _with_routing({
            "system_directive": directive,
            "transition_style": transition_style_for(directive),
            "target_concept_id_for_next_prompt": None,
            "synthesized_framing_strategy": f"This topic's tier {tier} concepts are covered; frame the topic's next question at tier {tier + 1}, anchored in a fresh resume or JD context rather than repeating what was just covered.",
            "generated_follow_up_prompt": None,
        }, node)

    directive = "pivot"
    return _with_routing({
        "system_directive": directive,
        "transition_style": transition_style_for(directive),
        "target_concept_id_for_next_prompt": (verification.unverified[0] if verification and verification.unverified else None),
        "synthesized_framing_strategy": "No specific gap to probe and nothing to escalate into right now; move to the next question in the plan.",
        "generated_follow_up_prompt": None,
    }, node)


async def _verify_concepts(tools: Any, transcript: str, concept_ids: list[str]) -> Optional[ConceptVerification]:
    """(Stage 6, §4.4) Concept ids carry no label of their own on the wire,
    so the Eval Tool's term-matching runs against the best-effort label
    reconstructed from the id."""
    try:
        result = await tools.call(
            "tool-eval", "verify_concepts", {"answer_transcript": transcript, "concepts": [{"id": cid, "label": label_from_concept_id(cid)} for cid in concept_ids]}
        )
        return ConceptVerification(verified=result["verified_concept_ids"], unverified=result["unverified_concept_ids"])
    except Exception:  # noqa: BLE001 - verification is an enrichment, not a gate
        return None


async def _score_follow_up_exchange(deps: FollowupAgentDeps, p: dict[str, Any]) -> dict[str, Any]:
    """(Stage 5, §4.4) Scores an answered follow-up. Deliberately does NOT
    create a second top-level `Evaluation`: a follow-up is a sub-unit of the
    answer it belongs to. The score is written onto `answers.follow_ups[i]`
    by the harness instead."""
    if not deps.tool_client:
        raise McpHandlerError("eval_unavailable", f"{SERVER_NAME} was constructed without a tool client; it cannot reach the Eval Tool")

    tools = deps.tool_client(p["session_id"], SERVER_NAME)
    rubric_id = p.get("rubric_id") or "behavioral_v1"
    try:
        scored = await tools.call(
            "tool-eval",
            "evaluate_answer",
            {
                "rubric_id": rubric_id,
                # No `answer_id`: passing one would persist a top-level
                # Evaluation, which §11.2 says not to do for a follow-up exchange.
                "question": p["follow_up_text"],
                "answer_transcript": p["follow_up_transcript"],
                **({"reference_answer": p["reference_answer"]} if p.get("reference_answer") else {}),
                **({"topic": p["topic"]} if p.get("topic") else {}),
            },
        )
        return {
            "scored": True,
            "score": {
                "rubric_id": rubric_id,
                "value": scored["score"],
                "rationale": scored["rationale"],
                "evidence_spans": scored["evidence_spans"],
                **({"grade": scored["grade"]} if scored.get("grade") else {}),
            },
        }
    except Exception as err:  # noqa: BLE001 - insufficient_transcript is a normal outcome
        return {"scored": False, "note": str(err)}


async def _score_answer(tools: Any, p: dict[str, Any]) -> Optional[tuple[Optional[AnswerScore], Optional[str]]]:
    """Returns the score, or the Eval Tool's own reason for refusing one.
    Both are normal outcomes."""
    if not p.get("answer_id"):
        return None
    rubric_id = p.get("rubric_id") or "behavioral_v1"
    try:
        scored = await tools.call(
            "tool-eval",
            "evaluate_answer",
            {
                "rubric_id": rubric_id,
                "answer_id": p["answer_id"],
                "question": p["question"],
                "answer_transcript": p["answer_transcript"],
                **({"transcript_confidence": p["transcript_confidence"]} if p.get("transcript_confidence") is not None else {}),
                **({"reference_answer": p["reference_answer"]} if p.get("reference_answer") else {}),
                **({"prompt_version": p["prompt_version"]} if p.get("prompt_version") else {}),
                **({"topic": p["topic"]} if p.get("topic") else {}),
            },
        )
        return (
            AnswerScore(
                rubric_id=rubric_id,
                value=scored["score"],
                rationale=scored["rationale"],
                evidence_spans=scored["evidence_spans"],
                grade=scored.get("grade"),
            ),
            None,
        )
    except Exception as err:  # noqa: BLE001
        return None, str(err)


async def _generate_probe(tools: Any, p: dict[str, Any], decision: FollowUpDecision, struggle: Optional[StruggleSignal] = None) -> Optional[dict[str, Any]]:
    from app.llm_client.tools import FOLLOW_UP_TOOL

    prompt_input = {
        "question": p["question"],
        "answer_transcript": p["answer_transcript"],
        "baseline": {
            "should_follow_up": decision.should_follow_up,
            **({"follow_up_text": decision.follow_up_text} if decision.follow_up_text else {}),
            "reason": decision.reason,
            # (§2) Which of followup-agent/v2's two jobs this is. The
            # deterministic detector has already decided; the flag only tells
            # the model which set of rules applies to the phrasing.
            **({"mode": "support"} if struggle else {}),
        },
    }
    try:
        generated = await tools.call(
            "tool-llm-provider",
            "generate_structured",
            {
                "session_id": p.get("session_id") or "",
                "tool_name": FOLLOW_UP_TOOL["name"],
                "prompt_version": FOLLOW_UP_TOOL["prompt_version"],
                "schema_ref": FOLLOW_UP_TOOL["schema_ref"],
                "input": prompt_input,
                # The answer itself is the only admissible source for a probe's target.
                "source_documents": [p["answer_transcript"]],
            },
        )
        return generated.get("output")
    except Exception:  # noqa: BLE001
        return None


def consider_follow_up(*, question: str, answer_transcript: str, transcript_confidence: Optional[float] = None, topic: Optional[str] = None) -> FollowUpDecision:
    transcript = (answer_transcript or "").strip()

    # Introduction answers ("Tell me about yourself") are self-introductions,
    # not behavioral claims. Probing them for personal actions, outcomes, or
    # reasoning produces nonsensical follow-ups like "You described Hello, I'm
    # Rahul — what was your own part in that?". Skip the gap detector entirely.
    if topic == INTRODUCTION_TOPIC:
        return FollowUpDecision(
            should_follow_up=False,
            reason="introduction answers are not behavioral claims; the gap detector does not apply",
            anti_patterns_detected=[],
        )

    if transcript_confidence is not None and transcript_confidence < MIN_CONFIDENCE:
        return FollowUpDecision(
            should_follow_up=False,
            reason=f"transcript confidence {transcript_confidence} is below {MIN_CONFIDENCE}; the harness should re-prompt or take typed text rather than probe a guess",
            anti_patterns_detected=["low_confidence_transcript"],
        )

    words = [w for w in transcript.split() if w]

    # A near-empty answer is not a gap to probe — it is a candidate who
    # needs a way in.
    if len(words) < SHORT_ANSWER_WORDS:
        return FollowUpDecision(
            should_follow_up=True,
            follow_up_text="Let's take that one from a specific angle: think of one time this came up for you, and start with what the situation was.",
            reason="answer too short to contain a claim to probe; offering a concrete way in instead",
            anti_patterns_detected=["too_short_to_probe"],
        )

    sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+", transcript) if s.strip()]

    has_action = bool(_FIRST_PERSON_ACTION.search(transcript))
    has_outcome = bool(_OUTCOME.search(transcript))
    has_metric = bool(_METRIC.search(transcript))
    has_reasoning = bool(_TRADEOFF.search(transcript))
    hedge_match = _HEDGE.search(transcript)

    detected: list[tuple[Gap, str]] = []

    if not has_action and _TEAM_CREDIT.search(transcript):
        detected.append((_GAPS_BY_ID["team_without_self"], _clause(sentences, _TEAM_CREDIT)))
    elif not has_action:
        detected.append((_GAPS_BY_ID["no_personal_action"], _subject_of(sentences[0] if sentences else transcript)))
    if has_action and not has_outcome:
        detected.append((_GAPS_BY_ID["no_outcome"], _subject_of(_clause(sentences, _FIRST_PERSON_ACTION))))
    if has_outcome and not has_metric:
        detected.append((_GAPS_BY_ID["unquantified_claim"], _subject_of(_clause(sentences, _OUTCOME))))
    if not has_reasoning:
        detected.append((_GAPS_BY_ID["no_reasoning"], _subject_of(sentences[0] if sentences else transcript)))
    if hedge_match:
        detected.append((_GAPS_BY_ID["hedged_claim"], _clause(sentences, _HEDGE)))

    if not detected:
        return FollowUpDecision(
            should_follow_up=False,
            reason="the answer already covers a specific situation, the candidate's own actions, the outcome and the reasoning — there is no gap worth probing",
            anti_patterns_detected=[],
        )

    first_gap, first_anchor = detected[0]
    return FollowUpDecision(
        should_follow_up=True,
        follow_up_text=first_gap.probe(first_anchor),
        reason=first_gap.reason,
        anti_patterns_detected=[g.id for g, _ in detected],
    )


def _clause(sentences: list[str], pattern: re.Pattern[str]) -> str:
    """The sentence a pattern matched in, trimmed to something quotable."""
    sentence = next((s for s in sentences if pattern.search(s)), sentences[0] if sentences else "")
    return _truncate(sentence, 90)


_LEADING_FILLER_RE = re.compile(r"^(so|well|basically|yeah|um|uh|okay|right)[,\s]+", re.IGNORECASE)
_LEADING_PRONOUN_RE = re.compile(r"^(i|we)\s+", re.IGNORECASE)
_TRAILING_PUNCT_RE = re.compile(r"[.!?]+$")
# Strip greeting prefixes that make anchors nonsensical ("Hello, I'm X, ...").
_GREETING_RE = re.compile(
    r"^(?:(?:hello|hi|hey|good\s+(?:morning|afternoon|evening)),?\s*"
    r"(?:(?:i(?:'m|\s+am)\s+\w+),?\s*)*)",
    re.IGNORECASE,
)


def _subject_of(sentence: str) -> str:
    """Turns a sentence into a phrase that reads naturally after "You mentioned …"."""
    cleaned = _GREETING_RE.sub("", sentence)
    cleaned = _TRAILING_PUNCT_RE.sub("", _LEADING_PRONOUN_RE.sub("", _LEADING_FILLER_RE.sub("", cleaned))).strip()
    return _truncate(cleaned or sentence, 90)


def _truncate(text: str, max_len: int) -> str:
    return text if len(text) <= max_len else f"{text[:max_len].rstrip()}…"


def create_followup_agent_server(deps: Optional[FollowupAgentDeps] = None) -> FollowupAgentServer:
    return FollowupAgentServer(deps or FollowupAgentDeps())

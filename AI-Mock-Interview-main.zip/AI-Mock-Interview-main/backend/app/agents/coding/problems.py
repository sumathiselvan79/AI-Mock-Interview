"""Coding problems — ~ agents/coding-agent/src/problems.ts.

Data, not prompts, for the same reason the question bank is: the set can be
reviewed by whoever owns interview subject-matter expertise rather than
being buried in agent code. Each problem carries visible examples the
candidate sees and hidden cases they do not.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass(frozen=True)
class TestCase:
    name: str
    args: tuple[Any, ...]
    expected: Any


@dataclass(frozen=True)
class Example:
    input: str
    output: str


@dataclass(frozen=True)
class CodingProblem:
    id: str
    title: str
    statement: str
    entry_point: str
    signature: str
    difficulty: int
    topics: tuple[str, ...]
    examples: tuple[Example, ...]
    visible_cases: tuple[TestCase, ...]
    hidden_cases: tuple[TestCase, ...]


CODING_PROBLEMS: tuple[CodingProblem, ...] = (
    CodingProblem(
        id="rate-limiter",
        title="Fixed-window rate limiter",
        statement=(
            "Implement `allow(events, limit, windowMs)`. `events` is an array of millisecond timestamps in "
            "ascending order, each a request from one user. Return an array of booleans: true if that request "
            "should be allowed, false if it exceeds `limit` requests within any fixed window of `windowMs` "
            "starting at the first allowed request of the window."
        ),
        entry_point="allow",
        signature="function allow(events, limit, windowMs) -> boolean[]",
        difficulty=3,
        topics=("system design", "reliability and operations"),
        examples=(Example("allow([0, 100, 200], 2, 1000)", "[true, true, false]"), Example("allow([0, 1500], 1, 1000)", "[true, true]")),
        visible_cases=(
            TestCase("under the limit", ([0, 100], 2, 1000), [True, True]),
            TestCase("third in window rejected", ([0, 100, 200], 2, 1000), [True, True, False]),
        ),
        hidden_cases=(
            TestCase("window resets", ([0, 1500], 1, 1000), [True, True]),
            TestCase("empty input", ([], 3, 1000), []),
            TestCase("boundary is exclusive", ([0, 1000], 1, 1000), [True, True]),
            TestCase("burst then quiet then burst", ([0, 10, 20, 5000, 5010, 5020], 2, 1000), [True, True, False, True, True, False]),
        ),
    ),
    CodingProblem(
        id="merge-intervals",
        title="Merge overlapping intervals",
        statement=(
            "Implement `merge(intervals)` where `intervals` is an array of `[start, end]` pairs in any order. "
            "Return the intervals merged so none overlap, sorted by start. Touching intervals ([1,3] and [3,5]) "
            "count as overlapping."
        ),
        entry_point="merge",
        signature="function merge(intervals) -> [start, end][]",
        difficulty=2,
        topics=("databases", "data engineering"),
        examples=(Example("merge([[1,3],[2,6],[8,10]])", "[[1,6],[8,10]]"), Example("merge([[1,4],[4,5]])", "[[1,5]]")),
        visible_cases=(
            TestCase("overlapping", ([[1, 3], [2, 6], [8, 10]],), [[1, 6], [8, 10]]),
            TestCase("touching", ([[1, 4], [4, 5]],), [[1, 5]]),
        ),
        hidden_cases=(
            TestCase("unsorted input", ([[8, 10], [1, 3], [2, 6]],), [[1, 6], [8, 10]]),
            TestCase("fully contained", ([[1, 10], [2, 3]],), [[1, 10]]),
            TestCase("empty", ([],), []),
            TestCase("single", ([[5, 7]],), [[5, 7]]),
        ),
    ),
    CodingProblem(
        id="retry-backoff",
        title="Retry schedule with capped backoff",
        statement=(
            "Implement `schedule(attempts, baseMs, capMs)`. Return the delay before each retry using exponential "
            "backoff — `baseMs * 2^n` for the nth retry, starting at n = 0 — capped at `capMs`. Return an array "
            "of length `attempts`."
        ),
        entry_point="schedule",
        signature="function schedule(attempts, baseMs, capMs) -> number[]",
        difficulty=2,
        topics=("reliability and operations", "apis and services"),
        examples=(Example("schedule(4, 100, 1000)", "[100, 200, 400, 800]"), Example("schedule(5, 100, 300)", "[100, 200, 300, 300, 300]")),
        visible_cases=(
            TestCase("uncapped", (4, 100, 1000), [100, 200, 400, 800]),
            TestCase("capped", (5, 100, 300), [100, 200, 300, 300, 300]),
        ),
        hidden_cases=(
            TestCase("zero attempts", (0, 100, 1000), []),
            TestCase("cap below base", (3, 500, 100), [100, 100, 100]),
            TestCase("single attempt", (1, 50, 5000), [50]),
        ),
    ),
    CodingProblem(
        id="dedupe-events",
        title="Deduplicate events by idempotency key",
        statement=(
            'Implement `dedupe(events)` where each event is `{ key, value }`. Return the values of the first '
            "event for each key, in the order those keys were first seen. Later events with a key already seen "
            "are dropped."
        ),
        entry_point="dedupe",
        signature="function dedupe(events) -> value[]",
        difficulty=1,
        topics=("distributed systems", "apis and services"),
        examples=(Example('dedupe([{key:"a",value:1},{key:"a",value:2},{key:"b",value:3}])', "[1, 3]"),),
        visible_cases=(TestCase("drops repeats", ([{"key": "a", "value": 1}, {"key": "a", "value": 2}, {"key": "b", "value": 3}],), [1, 3]),),
        hidden_cases=(
            TestCase("empty", ([],), []),
            TestCase("order preserved", ([{"key": "b", "value": 1}, {"key": "a", "value": 2}, {"key": "b", "value": 9}],), [1, 2]),
            TestCase("falsy values kept", ([{"key": "a", "value": 0}, {"key": "a", "value": 5}],), [0]),
        ),
    ),
)


def select_problem(*, difficulty_target: float, covered_topics: Optional[list[str]] = None, exclude_ids: Optional[list[str]] = None) -> CodingProblem:
    """Picks a problem near the candidate's difficulty target, preferring
    one whose topics the interview already covered so the coding round
    follows on from the conversation instead of arriving from nowhere."""
    covered = set(covered_topics or [])
    excluded = set(exclude_ids or [])

    candidates = [p for p in CODING_PROBLEMS if p.id not in excluded]
    pool = candidates if candidates else list(CODING_PROBLEMS)

    def sort_key(p: CodingProblem) -> tuple:
        overlap = 0 if any(t in covered for t in p.topics) else 1
        return (overlap, abs(p.difficulty - difficulty_target), p.id)

    return sorted(pool, key=sort_key)[0]


def get_problem(problem_id: str) -> Optional[CodingProblem]:
    return next((p for p in CODING_PROBLEMS if p.id == problem_id), None)

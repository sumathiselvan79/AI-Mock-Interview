"""Coding Agent — ~ agents/coding-agent/src/index.ts. INSTRUCTIONS.md §4.5.

Presents a problem, executes submissions in an isolated sandbox, and
evaluates correctness alongside the candidate's reasoning.

Voice (soul.md §4): "patient and exact. Evaluates correctness and the
candidate's reasoning process, not just whether the final output matched."
The Eval Tool scores the talk-through *and* the executed test results, so a
candidate who explains a sound approach but slips on an edge case is not
scored as though they understood nothing.

Execution never happens in this process — `runner.py` spawns a constrained
child (soul.md §5).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Awaitable, Callable, Optional

from app.agents.coding.problems import CodingProblem, get_problem, select_problem
from app.agents.coding.runner import CaseResult, run_in_sandbox
from app.shared_types import McpCallContext, McpHandlerError

SERVER_NAME = "coding-agent"
METHODS = ("start_coding_round", "submit_code", "get_round_result")


@dataclass
class CodingAgentDeps:
    tool_client: Any  # ToolClientFactory
    clipboard_consent_token: Optional[Callable[[str], Awaitable[Optional[str]]]] = None


@dataclass
class SubmissionResult:
    passed: int
    total: int
    results: list[CaseResult]
    logs: list[str]
    evaluation: Optional[dict[str, Any]] = None
    error: Optional[dict[str, str]] = None
    evaluation_note: Optional[str] = None


@dataclass
class RoundState:
    session_id: str
    problem_id: str
    started_at: str
    submissions: int = 0
    last_result: Optional[SubmissionResult] = None
    # The talk-through text the last scored submission was evaluated
    # against — kept so the Report Agent can quote it (§4.8), never
    # surfaced to the candidate as-is.
    last_talk_through: Optional[str] = None


class CodingRoundStore:
    """Rounds are in-memory: a coding round is live state, like a timer."""

    def __init__(self) -> None:
        self._rounds: dict[str, RoundState] = {}

    def start(self, state: RoundState) -> None:
        self._rounds[state.session_id] = state

    def get(self, session_id: str) -> Optional[RoundState]:
        return self._rounds.get(session_id)

    def update(self, session_id: str, **patch: Any) -> None:
        existing = self._rounds.get(session_id)
        if existing:
            for key, value in patch.items():
                setattr(existing, key, value)


class CodingAgentServer:
    name = SERVER_NAME

    def __init__(self, deps: CodingAgentDeps, rounds: Optional[CodingRoundStore] = None) -> None:
        self._deps = deps
        self._rounds = rounds or CodingRoundStore()

    async def call(self, method: str, params: Any, ctx: McpCallContext) -> Any:
        p = params or {}
        if method == "start_coding_round":
            return await _start_round(self._deps, self._rounds, p)
        if method == "submit_code":
            return await _submit_code(self._deps, self._rounds, p)
        if method == "get_round_result":
            session_id = p["session_id"]
            round_ = self._rounds.get(session_id)
            if not round_:
                raise McpHandlerError("no_active_round", f"no coding round for {session_id}")
            problem = get_problem(round_.problem_id)
            return {
                "problem_id": round_.problem_id,
                "problem": ({"title": problem.title, "statement": problem.statement, "topics": list(problem.topics)} if problem else None),
                "submissions": round_.submissions,
                "result": _to_wire(round_.last_result) if round_.last_result else None,
                "talk_through": round_.last_talk_through or "",
            }
        raise McpHandlerError("unknown_method", f"{SERVER_NAME} has no method {method}")


async def _start_round(deps: CodingAgentDeps, rounds: CodingRoundStore, params: dict[str, Any]) -> dict[str, Any]:
    problem = select_problem(difficulty_target=params.get("difficulty_target", 3), covered_topics=params.get("covered_topics"))

    rounds.start(RoundState(session_id=params["session_id"], problem_id=problem.id, started_at=datetime.now(timezone.utc).isoformat()))

    # Clipboard monitoring only starts if the candidate consented; without a
    # token the tool refuses, and the round continues unmonitored rather
    # than being blocked (soul.md §"Consent-first monitoring").
    consent_token = await deps.clipboard_consent_token(params["session_id"]) if deps.clipboard_consent_token else None
    monitoring = False
    if consent_token:
        try:
            await deps.tool_client(params["session_id"], SERVER_NAME).call("tool-clipboard-monitor", "start_monitor", {"session_id": params["session_id"], "consent_token": consent_token})
            monitoring = True
        except Exception:  # noqa: BLE001
            monitoring = False

    return {
        "problem": {
            "id": problem.id,
            "title": problem.title,
            "statement": problem.statement,
            "signature": problem.signature,
            "entry_point": problem.entry_point,
            "difficulty": problem.difficulty,
            "examples": [{"input": e.input, "output": e.output} for e in problem.examples],
        },
        "clipboard_monitoring": monitoring,
        "started_at": datetime.now(timezone.utc).isoformat(),
    }


async def _submit_code(deps: CodingAgentDeps, rounds: CodingRoundStore, params: dict[str, Any]) -> dict[str, Any]:
    round_ = rounds.get(params["session_id"])
    if not round_:
        raise McpHandlerError("no_active_round", f"no coding round for {params['session_id']}")

    problem = get_problem(round_.problem_id)
    if not problem:
        raise McpHandlerError("unknown_problem", f"problem {round_.problem_id} is gone")

    language = (params.get("language") or "javascript").lower()
    if language != "javascript":
        raise McpHandlerError("unsupported_language", f"only javascript runs in this sandbox; got {params.get('language')}")

    # Hidden cases run alongside the visible ones: passing the examples is
    # not the same as solving the problem.
    outcome = await run_in_sandbox(code=params["code"], entry_point=problem.entry_point, test_cases=[*problem.visible_cases, *problem.hidden_cases])

    passed = len([r for r in outcome.results if r.passed])

    result = SubmissionResult(passed=passed, total=len(outcome.results), results=outcome.results, logs=outcome.logs, error=outcome.error, evaluation=None)

    talk_through = params.get("talk_through") or ""
    # Score the reasoning and the tests together, through the Eval Tool —
    # the rubric lives there, never here (CLAUDE.md §8).
    try:
        scored = await deps.tool_client(params["session_id"], SERVER_NAME).call(
            "tool-eval",
            "evaluate_answer",
            {"rubric_id": "coding_round_v1", "question": problem.statement, "answer_transcript": talk_through, "extra": {"test_results": [{"case": r.case, "passed": r.passed} for r in outcome.results]}},
        )
        result.evaluation = {"score": scored["score"], "rationale": scored["rationale"], "evidence_spans": scored["evidence_spans"]}
    except Exception as err:  # noqa: BLE001 - a candidate who wrote code but said nothing cannot be scored on reasoning
        result.evaluation_note = str(err)

    rounds.update(params["session_id"], submissions=round_.submissions + 1, last_result=result, last_talk_through=talk_through)

    return _to_wire(result)


def _to_wire(result: SubmissionResult) -> dict[str, Any]:
    """What the candidate is shown. Hidden-case *names* are included so
    failures are actionable, but never their inputs."""
    out: dict[str, Any] = {
        "passed": result.passed,
        "total": result.total,
        "results": [{"case": r.case, "passed": r.passed, "duration_ms": r.duration_ms, **({"error": r.error} if r.error else {})} for r in result.results],
        "logs": result.logs[:50],
        "evaluation": result.evaluation,
    }
    if result.error:
        out["error"] = result.error
    if result.evaluation_note:
        out["evaluation_note"] = result.evaluation_note
    return out


def create_coding_agent_server(deps: CodingAgentDeps, rounds: Optional[CodingRoundStore] = None) -> CodingAgentServer:
    return CodingAgentServer(deps, rounds)

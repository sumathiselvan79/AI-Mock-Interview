"""Sandboxed execution runner — ~ agents/coding-agent/src/runner.ts.

Candidate code runs in a **separate process**, never in this Python process
(soul.md §5). Deviation from a line-for-line port, recorded per
FASTAPI_MIGRATION.md convention: rather than re-implementing a JavaScript
sandbox in Python, this shells out to the *same* `sandbox-bootstrap.cjs`
file the TS backend already ships (`agents/coding-agent/src/`), via Node
instead of duplicating a second security-critical sandbox implementation.
The coding round's problems are written in JavaScript (see `problems.py`),
so this is the faithful choice, not a shortcut — one bootstrap script stays
the single source of truth for the sandbox's threat model on both backends
during the migration window.

Threat model, stated plainly (unchanged from the TS side): this stops a
candidate's code from reading the filesystem, reaching the network,
spawning processes, or hanging the caller. It is not a defence against a
determined V8 escape — the production answer is one container or microVM
per execution (`INSTRUCTIONS.md §10`).
"""

from __future__ import annotations

import asyncio
import json
import os
import shutil
import time
from dataclasses import dataclass, field
from typing import Any, Optional

from app.agents.coding.problems import TestCase
from app.paths import from_repo_root

_BOOTSTRAP = from_repo_root("agents/coding-agent/src/sandbox-bootstrap.cjs")
_RESULT_SENTINEL = "__MIA_SANDBOX_RESULT__"

# Per INSTRUCTIONS.md §9: sandboxed code execution stays under 5s.
DEFAULT_TIMEOUT_MS = 5_000
DEFAULT_HEAP_MB = 128
MAX_CODE_BYTES = 64 * 1024


@dataclass
class CaseResult:
    case: str
    passed: bool
    duration_ms: float
    actual: Optional[str] = None
    error: Optional[dict[str, str]] = None


@dataclass
class RunOutcome:
    ok: bool
    results: list[CaseResult] = field(default_factory=list)
    logs: list[str] = field(default_factory=list)
    error: Optional[dict[str, str]] = None
    elapsed_ms: float = 0  # Wall-clock time for the whole run, including process start-up.


def _node_executable() -> str:
    node = shutil.which("node")
    if not node:
        raise RuntimeError("node executable not found on PATH; the coding round's sandbox requires Node.js")
    return node


def _sandbox_env() -> dict[str, str]:
    """No inherited environment: credentials and connection strings in this
    process's env must not be visible to candidate code. `SystemRoot` (and
    `windir`, its legacy alias) are the exception — Node/V8's own process
    initialization on Windows crashes without them (they locate
    kernel32/locale/threading facilities the CRT needs to start at all, not
    anything candidate code could read), so this is a platform requirement,
    not a widened trust boundary."""
    env = {"NODE_ENV": "sandbox"}
    for name in ("SystemRoot", "windir"):
        value = os.environ.get(name)
        if value:
            env[name] = value
    return env


async def run_in_sandbox(*, code: str, entry_point: str, test_cases: list[TestCase], timeout_ms: int = DEFAULT_TIMEOUT_MS, heap_mb: int = DEFAULT_HEAP_MB) -> RunOutcome:
    started_at = time.monotonic()

    if len(code.encode("utf-8")) > MAX_CODE_BYTES:
        return RunOutcome(ok=False, error={"type": "too_large", "message": f"submission exceeds {MAX_CODE_BYTES} bytes"}, elapsed_ms=(time.monotonic() - started_at) * 1000)

    request = {"code": code, "entryPoint": entry_point, "testCases": [{"name": tc.name, "args": list(tc.args), "expected": tc.expected} for tc in test_cases]}

    process = await asyncio.create_subprocess_exec(
        _node_executable(),
        # Node's permission model: with no --allow-* flags, child processes,
        # worker threads and native addons are denied by the runtime.
        "--permission",
        # Reading the bootstrap itself is the one filesystem grant needed to start.
        f"--allow-fs-read={_BOOTSTRAP}",
        f"--max-old-space-size={heap_mb}",
        "--no-warnings",
        _BOOTSTRAP,
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        env=_sandbox_env(),
        cwd=str(__import__("pathlib").Path(_BOOTSTRAP).parent),
    )

    timed_out = False

    async def _communicate() -> tuple[bytes, bytes]:
        return await process.communicate(json.dumps(request).encode("utf-8"))

    try:
        stdout_bytes, stderr_bytes = await asyncio.wait_for(_communicate(), timeout=timeout_ms / 1000)
    except asyncio.TimeoutError:
        timed_out = True
        process.kill()
        await process.wait()
        stdout_bytes, stderr_bytes = b"", b""

    elapsed_ms = (time.monotonic() - started_at) * 1000

    if timed_out:
        return RunOutcome(ok=False, error={"type": "timeout", "message": f"execution exceeded {timeout_ms}ms and the sandbox was terminated"}, elapsed_ms=elapsed_ms)

    stdout = stdout_bytes.decode("utf-8", errors="replace")
    stderr = stderr_bytes.decode("utf-8", errors="replace")
    # A runaway `console.log` loop must not exhaust the caller's memory either.
    if len(stdout) > 2 * 1024 * 1024:
        stdout = stdout[: 2 * 1024 * 1024]

    parsed = _parse_result(stdout)
    if parsed is None:
        exit_code = process.returncode
        return RunOutcome(
            ok=False,
            error={"type": "no_result" if exit_code == 0 else "crashed", "message": _first_line(stderr) or f"sandbox exited with code {exit_code} and produced no result"},
            elapsed_ms=elapsed_ms,
        )

    parsed.elapsed_ms = elapsed_ms
    return parsed


def _parse_result(stdout: str) -> Optional[RunOutcome]:
    index = stdout.rfind(_RESULT_SENTINEL)
    if index < 0:
        return None
    payload = stdout[index + len(_RESULT_SENTINEL) :].strip()
    try:
        parsed = json.loads(payload)
    except json.JSONDecodeError:
        return None
    results = [CaseResult(case=r["case"], passed=r["passed"], duration_ms=r["durationMs"], actual=r.get("actual"), error=r.get("error")) for r in parsed.get("results", [])]
    return RunOutcome(ok=parsed.get("ok", False), results=results, logs=parsed.get("logs", []), error=parsed.get("error"))


def _first_line(text: str) -> str:
    for line in text.split("\n"):
        if line.strip():
            return line.strip()
    return ""

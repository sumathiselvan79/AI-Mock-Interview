"""QUESTION_LOOP orchestration — the harness routing every step of a live
interview (INSTRUCTIONS.md §3, §4.1). ~ agents/harness-agent/src/interview.ts.

Everything here is routing and state, never interviewing: the harness
decides *what happens next*, and each specialized agent decides *what to
say*. The harness never speaks to the candidate (soul.md §2), and no agent
here talks to another — every hop goes out through the MCP Gateway.

F6 scope: `profile_resume` (F5) plus the full text-only QUESTION_LOOP
(`build_topic_plan`, `next_question`, `submit_answer`,
`submit_follow_up_answer`) — Stage 2 parity. Voice (`speak`/`transcribe`),
coding round, and report generation land in F7-F9; every call site that
reaches into those stages' tools already degrades gracefully (try/except
around an unregistered MCP server), matching the TS "absent dependency
degrades the feature, not the harness" contract, so wiring them here now
does not break anything before those stages land.
"""

from __future__ import annotations

import asyncio
import contextlib
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Awaitable, Callable, Optional

from app.agents.harness.callbacks import callback_fact_from
from app.agents.harness.meta_utterance import classify_meta_utterance, response_for
from app.agents.resume_service.relevance import merge_topic_relevance
from app.interview_domain import INTRODUCTION_TOPIC
from app.interview_domain.acknowledgments import PHRASE_KIND as ACK_PHRASE_KIND
from app.interview_domain.acknowledgments import acknowledgment_for
from app.interview_domain.continuers import (
    HOLDING_LINE_AFTER_MS,
    ContinuerKind,
    continuer_for,
    phrase_kind_for,
)
from app.interview_domain.routing import exhausted_from
from app.interview_domain.signals import HEDGE_RE, is_short_answer
from app.interview_domain.transitions import cues_used_in
from app.shared_types import (
    Answer,
    CandidateProfile,
    ExtractionProcessorResult,
    FollowUpScore,
    LiveSessionState,
    NextActionGenerator,
    Question,
    Session,
    TopicRelevance,
)

CALLER = "harness-agent"

# Which rubric the Eval Tool should apply to an answer of a given type.
RUBRIC_FOR_TYPE = {"behavioral": "behavioral_v1", "technical": "technical_v2", "coding": "coding_round_v1"}

# (Orchestration addition) How many answered exchanges travel forward with a
# `get_next_question` call. Enough for the next question to transition from
# what was just discussed; short enough that the whole transcript is not
# re-sent to a provider every turn (INSTRUCTIONS.md §8, data minimisation).
_CONTINUITY_WINDOW = 3
_EXCERPT_WORDS = 60

# (Human-interaction addition, §4) The kind under which transition cues are
# recorded in the Memory Agent. Acknowledgments use their own kind
# (`ACK_PHRASE_KIND`) so exhausting one pool never constrains the other.
_TRANSITION_PHRASE_KIND = "transition"


@dataclass
class InterviewDeps:
    sessions: Any
    questions: Any
    answers: Any
    evaluations: Any
    telemetry: Any
    tool_client: Callable[[str, str], Any]
    focus_consent_token: Optional[Callable[[str], Awaitable[Optional[str]]]] = None
    # (Stage 13) The routing snapshot cache. Injected rather than imported so
    # a test can hold an isolated store, and defaulted so every existing
    # construction of these deps keeps working. It is a cache over derived
    # values, not state — see `app/http/session_tracker.py` for why that
    # distinction is load-bearing against CLAUDE.md §10.
    tracker: Any = None
    users: Any = None


@dataclass
class SpokenText:
    text: str
    audio_url: Optional[str] = None
    duration_ms: Optional[float] = None
    speech_note: Optional[str] = None


@dataclass
class AcceptedTranscript:
    accepted: bool
    transcript: str
    confidence: float


@dataclass
class LowConfidenceTranscript:
    """A refusal. Named for the original reason there was one; there are four now.

    `code` is what tells them apart, and it matters to the caller rather than
    being decoration: a refusal with no `draft_transcript` could mean "the
    transcript is too doubtful to offer" or "there is nothing to offer", and
    only one of those should let the client fall back to its own guess at what
    was said (`page.tsx`).
    """

    accepted: bool
    reason: str
    confidence: Optional[float] = None
    draft_transcript: Optional[str] = None
    #: `transcription_low_confidence` | `no_speech_detected` |
    #: `audio_source_rejected` | `transcription_failed`.
    code: Optional[str] = None


@dataclass
class NextQuestionResult:
    done: bool
    asked_count: int
    question_budget: int
    question: Optional[Question] = None
    note: Optional[str] = None
    speech_note: Optional[str] = None


@dataclass
class Continuer:
    """(§8) A line spoken to hold the conversation open, not to advance it.

    Its own type rather than a bare `SpokenText` because the `kind` is what a
    caller acts on: an `opening` is said once at the top of the session, a
    `holding` or `selection` line means the interview is still working and the
    candidate's turn has not come back round, and a `follow_up_receipt` is the
    §1 acknowledgment beat applied to the other half of a probing turn. None of
    them ends a turn, and none of them may be treated as one.
    """

    kind: str
    spoken: SpokenText


#: How a continuer reaches a caller that can push. Same contract as §1's
#: `on_acknowledgment`: fired the moment the line is spoken, which for a
#: holding line is necessarily *before* the work it is covering has finished.
ContinuerHook = Callable[[Continuer], Awaitable[None]]


@dataclass
class FollowUpResult:
    text: str
    reason: str
    audio_url: Optional[str] = None


@dataclass
class AnswerResult:
    answer: Answer
    evaluation: Optional[dict[str, Any]]
    follow_up: Optional[FollowUpResult]
    evaluation_note: Optional[str] = None
    extraction: Optional[ExtractionProcessorResult] = None
    next_action: Optional[NextActionGenerator] = None
    live_session_state: Optional[LiveSessionState] = None
    # (§1) The micro-acknowledgment already spoken by the time the rest of this
    # result existed. Carried so a caller with no live socket — the REST route
    # — can still show it, and so a test can assert on it.
    acknowledgment: Optional[SpokenText] = None
    # (§2) Which struggle signal fired, when one did. `next_action` says the
    # interview softened; this says why.
    struggle_signal: Optional[str] = None


@dataclass
class MetaUtteranceResult:
    """(§3) The candidate asked about the question rather than answering it.

    A distinct type rather than an `AnswerResult` with empty fields, because
    the difference is not cosmetic: no `Answer` row was written, nothing was
    scored, the per-question clock was never stopped, and the session is still
    waiting for the same question to be answered. A caller that treats this as
    an answer would advance an interview that has not moved.
    """

    kind: str
    #: The question id still awaiting a real answer.
    question_id: str
    text: str
    audio_url: Optional[str] = None
    speech_note: Optional[str] = None


class InterviewOrchestrator:
    def __init__(self, deps: InterviewDeps) -> None:
        self._deps = deps

    def _tools(self, session_id: str) -> Any:
        return self._deps.tool_client(session_id, CALLER)

    # ------------------------------------------------------------- CONFIG

    async def profile_resume(self, session: Session) -> dict[str, Any]:
        """CONFIG: hands the uploaded resume to the Resume Service Agent,
        which parses it, scores topic relevance, and checks JD fit."""
        if not session.resume_ref:
            raise ValueError("session has no uploaded resume")
        tools = self._tools(session.id)

        draft = await self._jd_fit_draft(session.id, session.jd_fit_fingerprint)

        params: dict[str, Any] = {"session_id": session.id, "file_ref": session.resume_ref, "role": session.role}
        if session.job_description:
            params["job_description"] = session.job_description
        if draft:
            params["jd_fit_draft"] = draft

        result = await tools.call("resume-service-agent", "parse_and_profile", params)

        if result["jd_fit"].get("prompt_version"):
            jd_fit = result["jd_fit"]
            memory_patch: dict[str, Any] = {"prompt_version": jd_fit["prompt_version"]}
            for key in ("rationale", "topic_relevance", "role_level", "key_technologies"):
                if key in jd_fit:
                    memory_patch[key] = jd_fit[key]
            await tools.call(
                "memory-agent",
                "remember_jd_fit_draft",
                {"session_id": session.id, "resume_fingerprint": result["resume_fingerprint"], "jd_fit": memory_patch},
            )
            await self._deps.sessions.patch(session.id, {"jd_fit_fingerprint": result["resume_fingerprint"]})

        return {"topic_relevance": result["topic_relevance"], "jd_fit": result["jd_fit"]}

    async def _jd_fit_draft(self, session_id: str, fingerprint: Optional[str]) -> Optional[dict[str, Any]]:
        if not fingerprint:
            return None
        try:
            result = await self._tools(session_id).call(
                "memory-agent", "get_jd_fit_draft", {"session_id": session_id, "resume_fingerprint": fingerprint}
            )
            return result.get("jd_fit") if result.get("found") else None
        except Exception:  # noqa: BLE001
            return None

    # --------------------------------------------------------- CALIBRATION

    async def build_topic_plan(self, session: Session) -> Session:
        """Builds the session's topic plan from resume relevance, the role's
        required topics and any JD gaps, then persists it. Called once —
        `topic_plan` is set at CALIBRATION and read on every later call (§4.3)."""
        profile = session.candidate_profile
        jd_gap_topics = session.jd_gap_topics

        result = await self._tools(session.id).call(
            "question-agent",
            "build_topic_plan",
            {
                "session_id": session.id,
                "role": session.role,
                "question_budget": session.question_budget,
                "topic_relevance": [
                    {"topic": t.topic, "relevance_score": t.relevance_score, "evidence": t.evidence}
                    for t in (profile.topic_relevance if profile else [])
                ],
                "jd_gap_topics": jd_gap_topics,
            },
        )

        from app.shared_types import TopicPlanEntry

        plan = [TopicPlanEntry(topic=e["topic"], max_questions=e["max_questions"], source=e["source"]) for e in result["topic_plan"]]
        return await self._deps.sessions.patch(session.id, {"topic_plan": plan})

    async def _fuse_intro_into_topic_plan(self, session: Session, intro_transcript: str) -> Session:
        """(self-intro addition, §4.3) Unions the intro-derived topic_relevance
        into the session's before rebuilding the plan. Runs right after the
        introduction answer is captured and before any other question is
        served, so the fusion is safe to just overwrite `topic_plan` with —
        nothing downstream of the introduction slot has been asked yet.

        Extraction failure (provider down, nothing schema-valid) is an
        enrichment lost, not a session lost: the resume/role-only plan built
        at CALIBRATION stands untouched."""
        try:
            result = await self._tools(session.id).call(
                "resume-service-agent", "parse_self_intro", {"session_id": session.id, "role": session.role, "intro_transcript": intro_transcript}
            )
        except Exception:  # noqa: BLE001
            return session

        intro_topic_relevance = [
            TopicRelevance(topic=t["topic"], relevance_score=t["relevance_score"], evidence=t["evidence"])
            for t in result.get("topic_relevance", [])
        ]
        if not intro_topic_relevance:
            return session

        profile = session.candidate_profile
        resume_topic_relevance = profile.topic_relevance if profile else []
        fused = merge_topic_relevance(resume_topic_relevance, intro_topic_relevance)

        updated_profile = (
            profile.model_copy(update={"topic_relevance": fused})
            if profile
            else CandidateProfile(skills=[], experience=[], education=[], seniority_estimate="junior", keywords=[], topic_relevance=fused)
        )
        session = await self._deps.sessions.patch(session.id, {"candidate_profile": updated_profile})
        return await self.build_topic_plan(session)

    # ------------------------------------------------------------ QUESTION_LOOP

    async def next_question(
        self,
        session: Session,
        advance: bool = False,
        on_continuer: Optional[ContinuerHook] = None,
    ) -> NextQuestionResult:
        """One turn of QUESTION_LOOP. Resume-safe by default: if the most
        recently asked question has no answer yet, that same question is
        re-served rather than generating a replacement.

        (§8) `on_continuer` gets a "let me find a good place to go next" line
        if writing the question outruns `HOLDING_LINE_AFTER_MS`. Only the
        generation call is covered — the re-serve path above returns a question
        that already exists and never waits on a provider."""
        tools = self._tools(session.id)

        if not advance:
            asked = await self._deps.questions.list_by_session(session.id)
            pending = asked[-1] if asked else None
            if pending:
                answered = await self._deps.answers.get_by_question(pending.id)
                if not answered:
                    spoken = await self.speak(session.id, pending.text)
                    question = pending.model_copy(update={"audio_url": spoken.audio_url}) if spoken.audio_url else pending
                    content_asked = sum(1 for q in asked if q.topic != INTRODUCTION_TOPIC)
                    return NextQuestionResult(
                        done=False, question=question, speech_note=spoken.speech_note, asked_count=content_asked, question_budget=session.question_budget
                    )

        context = (await tools.call("memory-agent", "get_session_context", {"session_id": session.id}))["session_context"]

        # (self-intro addition, §4.3) The fixed opener is asked outside
        # `question_budget`, not one of the topics competing for a share of
        # it — so it is excluded from the count the budget is checked against.
        content_asked = context["questions_asked"] - context["topic_counts"].get(INTRODUCTION_TOPIC, 0)

        if content_asked >= session.question_budget:
            return NextQuestionResult(
                done=True, note=f"question budget of {session.question_budget} is spent", asked_count=content_asked, question_budget=session.question_budget
            )

        evaluations = await self._deps.evaluations.list_by_session(session.id)
        recent_scores = [e.score for e in evaluations]
        topic_scores = await self._topic_scores_by_topic(session.id, evaluations)

        # (Orchestration addition) What the Follow-up Agent decided about the
        # LAST answer, routed forward into the NEXT question.
        #
        # Before this, `next_action` was computed on every answer, persisted,
        # and pushed to the frontend — and then thrown away. The next question
        # was chosen purely from counts and tiers, so an `escalate` directive
        # ("this topic's tier is covered, go deeper") could not actually cause
        # an escalation: least-covered-topic-first ordering moved the
        # interview off that topic on the very next turn. The directive is a
        # decision one agent made about the interview; routing it to the agent
        # that acts on it is the harness's job (CLAUDE.md §5 — and it stays a
        # hop through the harness, never a shortcut between the two agents).
        continuity = await self._continuity(session.id)

        # (§4) Which conversational cues this session has already opened with.
        # Pure plumbing on top of what the Question Agent already writes: it
        # decides nothing, it only stops the same three transitions being used
        # over and over, which is its own way of sounding scripted.
        used_transitions = await self._used_phrases(session.id, _TRANSITION_PHRASE_KIND)

        result = await self._await_with_continuer(
            tools.call(
                "question-agent",
                "get_next_question",
                {
                    "session_id": session.id,
                    "role": session.role,
                    "topic_plan": [{"topic": e.topic, "max_questions": e.max_questions, "source": e.source} for e in session.topic_plan],
                    "topic_counts": context["topic_counts"],
                    "topic_tier": context["topic_tier"],
                    "topic_scores": topic_scores,
                    "asked_question_ids": context["asked_question_ids"],
                    "recent_scores": recent_scores,
                    "candidate_profile_lines": _profile_lines(session),
                    **({"used_transitions": used_transitions} if used_transitions else {}),
                    **continuity,
                },
            ),
            session_id=session.id,
            kind="selection",
            on_continuer=on_continuer,
        )

        q = result["question"]
        question = await self._deps.questions.append(
            Question(
                id=q["id"],
                bank_id=q["bank_id"],
                session_id=session.id,
                text=q["text"],
                topic=q["topic"],
                type=q["type"],
                difficulty=q["difficulty"],
                tier=q.get("tier"),
                target_concept_ids=q.get("target_concept_ids"),
                quota_override=q["quota_override"],
                prompt_version=q.get("prompt_version"),
                asked_at=datetime.now(timezone.utc).isoformat(),
            )
        )

        await tools.call("memory-agent", "record_question_asked", {"session_id": session.id, "question_id": question.id, "topic": question.topic})

        # (§4) Which cue the model actually reached for. It writes free text, so
        # this is observed from the question rather than assumed from the
        # directive — a `same_topic` directive does not guarantee a cue was used
        # at all, and recording one that was not used would forbid a phrase the
        # interview has never said.
        for cue in cues_used_in(question.text):
            await self._remember_phrase(session.id, _TRANSITION_PHRASE_KIND, cue)

        if result.get("reference_answer"):
            await tools.call(
                "memory-agent",
                "remember_reference_answer",
                {"session_id": session.id, "question_id": question.id, "reference_answer": result["reference_answer"]},
            )

        # Per-question clock. No agent runs its own timer (CLAUDE.md §10).
        await tools.call("time-tracking-agent", "start_segment", {"session_id": session.id, "segment": f"question:{question.id}"})

        await self._deps.telemetry.emit(
            "question_asked",
            session.id,
            {
                "question_id": question.id,
                "topic": question.topic,
                "type": question.type,
                "difficulty": question.difficulty,
                "quota_override": question.quota_override or False,
                # (Stage 13) Where the text came from: written from scratch,
                # a sharpened bank entry, or the bank entry as written. The
                # three are indistinguishable in the transcript and mean
                # different things when a question turns out to have been a
                # bad one.
                "source": result.get("question_source", "bank"),
            },
        )

        if q.get("quota_override"):
            await self._deps.telemetry.emit(
                "quota_override_used", session.id, {"question_id": question.id, "topic": question.topic, "reason": result.get("override_reason", "unspecified")}
            )

        # (Orchestration addition) Only emitted when the directive actually
        # moved the pick, so the span answers "why this topic again?" rather
        # than restating the directive on every turn.
        if result.get("followed_directive"):
            await self._deps.telemetry.emit(
                "directive_followed",
                session.id,
                {"question_id": question.id, "topic": question.topic, "directive": result["followed_directive"], "tier": question.tier},
            )

        spoken = await self.speak(session.id, question.text)
        if spoken.audio_url:
            question = question.model_copy(update={"audio_url": spoken.audio_url})

        # The just-served question itself only counts toward `asked_count`
        # when it is a real content question — the introduction opener never
        # advances the budget counter (§4.3 self-intro addition).
        reported_count = content_asked if question.topic == INTRODUCTION_TOPIC else content_asked + 1
        return NextQuestionResult(done=False, question=question, speech_note=spoken.speech_note, asked_count=reported_count, question_budget=session.question_budget)

    async def _continuity(self, session_id: str) -> dict[str, Any]:
        """(Orchestration addition) The conversational state one question needs
        in order to follow from the last one: the Follow-up Agent's directive
        for the last answered question, and a short trailing window of what was
        already asked and answered.

        Three distinct jobs, one walk over the same rows plus one memory read:

         - `next_action` steers SELECTION (escalate stays on the topic, pivot
           moves off it) — see `select_next_question`.
         - `recent_exchanges` steers PHRASING (the model can open with a real
           transition instead of a cold restart) — see question-agent/v5.
         - `session_callbacks` (§5) is the long-range half of that phrasing: a
           few notable things the candidate said further back than the window
           reaches, so an interview twenty minutes in can still refer to
           something from its opening. Kept separate from the window rather
           than lengthening it, because the two have opposite cost profiles —
           the window is re-sent whole every turn and so must stay short, while
           the callbacks are a handful of sentences chosen once.

        Best-effort by design. A session with nothing answered yet, or a store
        that cannot serve the window, produces `{}` and the Question Agent
        falls back to exactly its pre-orchestration behaviour. This must never
        be the reason a candidate gets no next question.
        """
        exchanges: list[dict[str, Any]] = []
        next_action: Optional[dict[str, Any]] = None

        try:
            questions = await self._deps.questions.list_by_session(session_id)

            # Newest first; the trailing window is short because its purpose is
            # a natural transition, not a second copy of the transcript. Sending
            # the whole session would also mean re-sending every answer verbatim
            # to the provider on every turn, which INSTRUCTIONS.md §8's data rule
            # rules out.
            for question in reversed(questions):
                if len(exchanges) >= _CONTINUITY_WINDOW:
                    break
                answer = await self._deps.answers.get_by_question(question.id)
                if not answer:
                    continue
                if next_action is None and answer.next_action is not None:
                    next_action = answer.next_action.model_dump(by_alias=False, exclude_none=True)

                # Trimmed: the phrasing only needs enough of the answer
                # to refer back to it, not the whole thing.
                answer_excerpt = _truncate_words(answer.transcript, _EXCERPT_WORDS)

                # (follow-up continuity fix) The most recent answered
                # follow-up, if any, is folded into the same exchange rather
                # than given its own window slot — it's a continuation of
                # this answer, not a separate turn, and probing past a vague
                # first answer is the Follow-up Agent's whole job, so it is
                # often where the specific, quotable detail actually is. Not
                # doing this meant the interview could dig into a gap and
                # then immediately forget what it found.
                if answer.follow_ups:
                    latest_follow_up = answer.follow_ups[-1]
                    answer_excerpt = (
                        f"{answer_excerpt}\n  follow-up asked: {latest_follow_up.text}"
                        f"\n  follow-up answered: {_truncate_words(latest_follow_up.transcript, _EXCERPT_WORDS)}"
                    )

                exchanges.append(
                    {
                        "topic": question.topic,
                        "question": question.text,
                        "answer_excerpt": answer_excerpt,
                    }
                )
        except Exception:  # noqa: BLE001 - the whole walk is an enrichment; see the docstring
            return {}

        out: dict[str, Any] = {}
        if next_action:
            out["next_action"] = next_action
        if exchanges:
            out["recent_exchanges"] = list(reversed(exchanges))

        # Read separately and last: a memory store that cannot serve callbacks
        # must not cost the window as well, and vice versa. Facts already in
        # the trailing window are dropped — sending the same sentence twice
        # under two headings makes it look like two moments.
        window_text = " ".join(x["answer_excerpt"] for x in exchanges)
        callbacks = [f for f in await self._callback_facts(session_id) if f.get("fact") and f["fact"] not in window_text]
        if callbacks:
            out["session_callbacks"] = callbacks
        return out

    async def _topic_scores_by_topic(self, session_id: str, evaluations: list[Any]) -> dict[str, list[float]]:
        """(Stage 6, §4.3) Groups this session's scores by the topic of the
        question they came from."""
        if not evaluations:
            return {}
        questions = await self._deps.questions.list_by_session(session_id)
        topic_by_question_id = {q.id: q.topic for q in questions}
        answers = [await self._deps.answers.get(e.answer_id) for e in evaluations]

        topic_scores: dict[str, list[float]] = {}
        for evaluation, answer in zip(evaluations, answers):
            topic = topic_by_question_id.get(answer.question_id) if answer else None
            if not topic:
                continue
            topic_scores.setdefault(topic, []).append(evaluation.score)
        return topic_scores

    async def submit_answer(
        self,
        *,
        session: Session,
        question_id: str,
        transcript: str,
        transcript_confidence: Optional[float] = None,
        on_acknowledgment: Optional[Callable[[SpokenText], Awaitable[None]]] = None,
        on_continuer: Optional[ContinuerHook] = None,
    ) -> Any:
        """Records an answer, scores it, and asks whether a follow-up is
        warranted. A transcript the Eval Tool refuses to score comes back as
        `evaluation_note` — never as a quietly invented low score.

        Returns a `MetaUtteranceResult` instead when the candidate asked about
        the question rather than answering it (§3) — see that type.

        `on_acknowledgment` is how §1's two-stage response reaches a caller
        that can push: it fires with the micro-acknowledgment as soon as that
        is spoken, which is well before the score and the follow-up exist. A
        caller without a live channel simply omits it and reads
        `AnswerResult.acknowledgment` at the end; the interview behaves the
        same either way, it just arrives all at once.

        (§8) `on_continuer` covers the silence *after* that acknowledgment. The
        ack costs no round trip; scoring the answer costs one, so on a slow
        provider the candidate hears "Okay." and then nothing for as long as
        the Follow-up Agent takes. Push-only, and deliberately: a holding line
        is a request to keep waiting, and there is nothing to ask of a REST
        caller that receives it alongside the thing it was waiting for.
        """
        question = await self._deps.questions.get(question_id)
        if not question or question.session_id != session.id:
            raise ValueError(f"question {question_id} does not belong to this session")

        tools = self._tools(session.id)

        # (§3) Before anything is written or scored: is this an answer at all?
        #
        # Placed ahead of `stop_segment` deliberately. Asking to hear a
        # question again is not a turn, so the per-question clock keeps running
        # — the candidate has not started answering yet, and stopping and
        # restarting the segment would credit them time they did not spend
        # thinking about it.
        meta = classify_meta_utterance(transcript)
        if meta:
            # Emitted on every match, per the cross-cutting notes: a false
            # positive here eats a real answer, so it must be visible after the
            # fact rather than inferable only from a suspiciously short session.
            await self._deps.telemetry.emit(
                "meta_utterance_detected",
                session.id,
                {"question_id": question.id, "kind": meta.kind, "matched": meta.matched},
            )
            reply = response_for(meta, question.text)
            spoken = await self.speak(session.id, reply)
            return MetaUtteranceResult(
                kind=meta.kind, question_id=question.id, text=reply, audio_url=spoken.audio_url, speech_note=spoken.speech_note
            )

        # (§1) The acknowledgment beat, before the pipeline that produces the
        # real response starts. Everything below this line takes provider round
        # trips; this takes none.
        acknowledgment = await self._acknowledge(session.id, transcript, transcript_confidence, on_acknowledgment)

        # (§8) Everything from here to the Follow-up Agent's verdict is silence
        # the candidate is sitting in, having just been acknowledged. The window
        # covers the WHOLE of it rather than the one MCP call at the end,
        # because the intro turn's topic-plan fusion is itself a provider round
        # trip and used to run outside it — see `_continuer_window`.
        async with self._continuer_window(session_id=session.id, kind="holding", on_continuer=on_continuer):
            # (§2) Built from PRIOR turns, before this answer is appended, so
            # "consecutive" and "streak" mean what they say. The Follow-up Agent
            # cannot gather this itself — it never queries the Memory Agent or the
            # stores directly (§4.7), so the harness passes it in the same way it
            # passes `topic_counts` to the Question Agent.
            struggle_context = await self._struggle_context(session.id, question.topic, transcript)

            # (Stage 13) The routing snapshot, gathered on exactly the same
            # basis and for exactly the same reason: the Follow-up Agent
            # computes the next-node proposal and cannot read the stores
            # itself (§4.7). Reconciled against persisted counts and caps on
            # every turn, so a cap spent elsewhere cannot go unnoticed here.
            routing_context = await self._routing_context(session, question)

            answer = await self._deps.answers.append(
                Answer(
                    id=str(uuid.uuid4()),
                    question_id=question.id,
                    transcript=transcript,
                    transcript_confidence=transcript_confidence,
                    follow_ups=[],
                    submitted_at=datetime.now(timezone.utc).isoformat(),
                )
            )

            segment = await tools.call("time-tracking-agent", "stop_segment", {"session_id": session.id, "segment": f"question:{question.id}"})

            # (self-intro addition, §4.3) "ask intro -> capture transcript -> run
            # self_intro_v1 extraction -> fuse into topic plan -> begin question
            # loop": the plan built at CALIBRATION was resume/role-only; this is
            # the one point where it is rebuilt fused with what the candidate
            # actually said, before any other question is served.
            if question.topic == INTRODUCTION_TOPIC:
                session = await self._fuse_intro_into_topic_plan(session, transcript)

            reference_answer = await self._reference_answer(session.id, question.id)

            follow_up_params: dict[str, Any] = {
                "session_id": session.id,
                "question": question.text,
                "answer_id": answer.id,
                "answer_transcript": answer.transcript,
                "rubric_id": RUBRIC_FOR_TYPE[question.type],
                "struggle_context": struggle_context,
                **({"routing_context": routing_context} if routing_context else {}),
                # (Dynamic evaluation addition) Lets the Eval Tool's "specifics"
                # signal score against this question's own topic vocabulary
                # instead of a software-only default (tools/eval/rubrics.py).
                "topic": question.topic,
            }
            if transcript_confidence is not None:
                follow_up_params["transcript_confidence"] = transcript_confidence
            if reference_answer:
                follow_up_params["reference_answer"] = reference_answer
                if question.prompt_version:
                    follow_up_params["prompt_version"] = question.prompt_version
            if question.tier is not None:
                follow_up_params["tier"] = question.tier
            if question.target_concept_ids:
                follow_up_params["target_concept_ids"] = question.target_concept_ids

            follow_up_response = await tools.call("followup-agent", "consider_follow_up", follow_up_params)


        evaluation = (
            {
                "score": follow_up_response["score"]["value"],
                "rationale": follow_up_response["score"]["rationale"],
                # (Grading addition) Passed straight through to whoever renders
                # this turn. The room shows the band the Eval Tool assigned, so
                # it cannot disagree with the one in the final report.
                **({"grade": follow_up_response["score"]["grade"]} if follow_up_response["score"].get("grade") else {}),
            }
            if follow_up_response.get("score")
            else None
        )
        evaluation_note = follow_up_response.get("score_note")

        # (Stage 13) Fold this answer's score into the rolling snapshot. Done
        # here, once, on the harness's own path — the Follow-up Agent computed
        # a proposal from it but is a stateless reducer and remembers nothing
        # (CLAUDE.md §10), and the Eval Tool scores without knowing there is a
        # session. A refused transcript records nothing rather than a zero: an
        # answer the tool would not score has not scored badly (soul.md §6).
        if evaluation and self._deps.tracker:
            try:
                self._deps.tracker.record_answer_score(
                    session.id, score=evaluation["score"], topic=question.topic, tier=question.tier
                )
            except Exception:  # noqa: BLE001 - a cache write must never cost an answer
                pass

        follow_up: Optional[FollowUpResult] = None
        if follow_up_response.get("should_follow_up") and follow_up_response.get("follow_up_text"):
            spoken = await self.speak(session.id, follow_up_response["follow_up_text"])
            follow_up = FollowUpResult(text=follow_up_response["follow_up_text"], reason=follow_up_response["reason"], audio_url=spoken.audio_url)

        if follow_up:
            await self._deps.telemetry.emit("follow_up_triggered", session.id, {"question_id": question.id, "answer_id": answer.id, "reason": follow_up.reason})

        # (§2) Why the interview softened. The directive alone says `support`;
        # this says which of the four signals produced it, which is what makes
        # "should that have fired?" answerable rather than a matter of opinion.
        struggle_signal = follow_up_response.get("struggle_signal")
        if struggle_signal:
            await self._deps.telemetry.emit(
                "struggle_detected",
                session.id,
                {"question_id": question.id, "answer_id": answer.id, "topic": question.topic, "signal": struggle_signal},
            )

        # (Stage 13) Why the interview is about to go where it goes. Emitted
        # only when routing actually produced a rationale, so the span answers
        # "why this topic next?" rather than restating the directive every
        # turn — the same rule `directive_followed` already follows.
        routing_wire = follow_up_response.get("next_action") or {}
        if routing_wire.get("routing_rationale"):
            await self._deps.telemetry.emit(
                "routing_decision",
                session.id,
                {
                    "question_id": question.id,
                    "answer_id": answer.id,
                    "from_topic": question.topic,
                    "next_topic": routing_wire.get("next_topic"),
                    "next_tier": routing_wire.get("next_tier"),
                    "directive": routing_wire.get("system_directive"),
                    "rationale": routing_wire["routing_rationale"],
                },
            )

        # (§5) A notable moment, kept for the rest of the session. Runs after
        # scoring because the score is half of what makes a moment notable.
        await self._record_callback_fact(
            session_id=session.id,
            question=question,
            transcript=answer.transcript,
            score=(follow_up_response.get("score") or {}).get("value"),
        )

        extraction: Optional[ExtractionProcessorResult] = None
        next_action: Optional[NextActionGenerator] = None
        live_session_state: Optional[LiveSessionState] = None
        next_action_wire = follow_up_response.get("next_action")
        if next_action_wire:
            extraction = ExtractionProcessorResult(
                transcribed_input_chunk=answer.transcript,
                verified_concept_ids=follow_up_response.get("verified_concept_ids", []),
                unverified_concept_ids=follow_up_response.get("unverified_concept_ids", []),
                anti_patterns_detected=follow_up_response.get("anti_patterns_detected", []),
            )
            next_action = NextActionGenerator(
                system_directive=next_action_wire["system_directive"],
                transition_style=next_action_wire["transition_style"],
                target_concept_id_for_next_prompt=next_action_wire["target_concept_id_for_next_prompt"],
                synthesized_framing_strategy=next_action_wire["synthesized_framing_strategy"],
                generated_follow_up_prompt=next_action_wire["generated_follow_up_prompt"],
                # (Stage 13) Persisted with the rest of the directive, which is
                # what lets `_continuity` route it into the next
                # `get_next_question` without a second lookup — the same path
                # the directive itself already travels.
                next_topic=next_action_wire.get("next_topic"),
                next_tier=next_action_wire.get("next_tier"),
                routing_rationale=next_action_wire.get("routing_rationale"),
            )
            try:
                # `transcribed_input_chunk` never gets a second,
                # redaction-blind copy at rest.
                persisted_extraction = extraction.model_copy(update={"transcribed_input_chunk": None})
                await self._deps.answers.record_extraction(answer.id, persisted_extraction, next_action)
            except Exception:  # noqa: BLE001 - the answer and its score are already durable
                pass

            live_session_state = _compose_live_session_state(
                session=session,
                question=question,
                extraction=extraction,
                next_action=next_action,
                score=follow_up_response.get("score", {}).get("value") if follow_up_response.get("score") else None,
                elapsed_ms=segment["elapsed_ms"],
            )

        return AnswerResult(
            answer=answer,
            evaluation=evaluation,
            evaluation_note=evaluation_note,
            follow_up=follow_up,
            extraction=extraction,
            next_action=next_action,
            live_session_state=live_session_state,
            acknowledgment=acknowledgment,
            struggle_signal=struggle_signal,
        )

    async def submit_follow_up_answer(
        self,
        *,
        session_id: str,
        answer_id: str,
        follow_up_text: str,
        transcript: str,
        on_continuer: Optional[ContinuerHook] = None,
    ) -> Answer:
        """(Stage 5, §4.4) Records an answered follow-up and scores that
        exchange. The score lands on this specific `follow_ups[]` entry, not
        in a new top-level `Evaluation`.

        (§8) `on_continuer` gets the receipt beat for this half of the turn.
        §1 gave the answer a "mm-hm" and gave the probe that came out of it
        nothing, so in a session where most turns are follow-ups most of what
        the candidate says lands in silence. Same rules as §1's: it fires
        before `score_follow_up_exchange` has returned, so it carries no
        verdict, and it is a courtesy — a failure here never costs the
        exchange."""
        existing = await self._deps.answers.get(answer_id)
        question = await self._deps.questions.get(existing.question_id) if existing else None
        if not existing or not question or question.session_id != session_id:
            raise ValueError(f"answer {answer_id} does not belong to this session")

        answer = await self._deps.answers.append_follow_up(answer_id, {"text": follow_up_text, "transcript": transcript})

        # After the row is durable and before the scoring round trip: the same
        # ordering §1 uses, so a receipt is only ever spoken for something the
        # interview has actually kept.
        if on_continuer and (transcript or "").strip():
            await self._continuer(session_id, "follow_up_receipt", on_continuer)

        try:
            scored = await self._tools(question.session_id).call(
                "followup-agent",
                "score_follow_up_exchange",
                {
                    "session_id": question.session_id,
                    "question": question.text,
                    "follow_up_text": follow_up_text,
                    "follow_up_transcript": transcript,
                    "rubric_id": RUBRIC_FOR_TYPE[question.type],
                    "topic": question.topic,
                },
            )
            if not scored.get("scored") or not scored.get("score"):
                return answer
            index = len(answer.follow_ups) - 1
            score = scored["score"]
            return await self._deps.answers.score_follow_up(
                answer_id, index, FollowUpScore(rubric_id=score["rubric_id"], value=score["value"], rationale=score["rationale"], evidence_spans=score["evidence_spans"])
            )
        except Exception:  # noqa: BLE001 - an unscoreable follow-up is a normal outcome
            return answer

    # ------------------------------------- (§1) the acknowledgment beat

    async def _acknowledge(
        self,
        session_id: str,
        transcript: str,
        transcript_confidence: Optional[float],
        on_acknowledgment: Optional[Callable[[SpokenText], Awaitable[None]]],
    ) -> Optional[SpokenText]:
        """Speaks the micro-acknowledgment, if there is one to speak.

        Best-effort from end to end. An acknowledgment is a courtesy; an answer
        submission that failed because the courtesy failed would be a strictly
        worse interview than one that never had it. So a memory hiccup costs
        variety (the same phrase twice), a synthesis failure costs the audio
        (`speak` already degrades to text), and neither costs the answer.
        """
        used = await self._used_phrases(session_id, ACK_PHRASE_KIND)
        line = acknowledgment_for(transcript=transcript, transcript_confidence=transcript_confidence, used_phrases=used)
        if not line:
            return None

        spoken = await self.speak(session_id, line)
        await self._remember_phrase(session_id, ACK_PHRASE_KIND, line)

        if on_acknowledgment:
            try:
                await on_acknowledgment(spoken)
            except Exception:  # noqa: BLE001 - a closed socket must not fail the submission
                pass
        return spoken

    async def _emit(self, event: str, session_id: str, payload: dict[str, Any]) -> None:
        """Telemetry that must never be the reason a turn fails.

        The continuer path is the one place in this file that speaks without
        being asked to, and every part of it degrades rather than raises
        (`_continuer`'s docstring has the reasoning). A span is not the
        exception to that.
        """
        try:
            if self._deps.telemetry:
                await self._deps.telemetry.emit(event, session_id, payload)
        except Exception:  # noqa: BLE001
            pass

    async def _used_phrases(self, session_id: str, kind: str) -> list[str]:
        try:
            result = await self._tools(session_id).call("memory-agent", "get_used_phrases", {"session_id": session_id, "kind": kind})
            return list(result.get("used_phrases") or [])
        except Exception:  # noqa: BLE001 - no history means no constraint, which is the safe default
            return []

    async def _remember_phrase(self, session_id: str, kind: str, phrase: str) -> None:
        try:
            await self._tools(session_id).call("memory-agent", "remember_used_phrase", {"session_id": session_id, "kind": kind, "phrase": phrase})
        except Exception:  # noqa: BLE001
            pass

    # ------------------------------------- (§8) conversational continuers

    async def opening_line(self, session_id: str, on_continuer: Optional[ContinuerHook] = None) -> Optional[Continuer]:
        """(§8) The session's hello, spoken before the introduction opener.

        Called by the harness once, at `begin_interview`, rather than prepended
        to the first question's text: a greeting is not part of a question, and
        folding it in would put it in the `Question.text` that gets persisted,
        re-served on a resume, and shown in the report's evidence.
        """
        return await self._continuer(session_id, "opening", on_continuer)

    async def _continuer(
        self,
        session_id: str,
        kind: ContinuerKind,
        on_continuer: Optional[ContinuerHook],
    ) -> Optional[Continuer]:
        """Speaks one continuer, records it as spent, and pushes it.

        Best-effort end to end, for the same reason §1's acknowledgment is: a
        continuer is a courtesy, and a turn that failed because the courtesy
        failed would be strictly worse than a turn that never had one. A memory
        hiccup costs variety, a synthesis failure costs the audio (`speak`
        already degrades to text), a closed socket costs the push — none of
        them costs the answer or the question this line was covering for.
        """
        phrase_kind = phrase_kind_for(kind)
        used = await self._used_phrases(session_id, phrase_kind) if phrase_kind else []
        line = continuer_for(kind, used_phrases=used)
        if not line:
            return None

        spoken = await self.speak(session_id, line)
        if phrase_kind:
            await self._remember_phrase(session_id, phrase_kind, line)

        result = Continuer(kind=kind, spoken=spoken)
        if on_continuer:
            try:
                await on_continuer(result)
            except Exception:  # noqa: BLE001 - a closed socket must not fail the turn
                pass
        return result

    @contextlib.asynccontextmanager
    async def _continuer_window(
        self,
        *,
        session_id: str,
        kind: ContinuerKind,
        on_continuer: Optional[ContinuerHook],
    ):
        """Speaks one continuer if the enclosed work runs long.

        A window rather than a wrapper around a single call, because the
        silence a candidate experiences is not bounded by any one round trip.
        Running the app made that concrete: the first version wrapped only
        `consider_follow_up`, and on the introduction turn the topic-plan
        fusion — an LLM call of its own — runs *before* it. The candidate got
        "Mm-hm." and then thirty-four seconds of nothing before the holding
        line the stage exists to provide. What the clock has to measure is the
        gap the candidate is sitting in, so the window opens the moment the
        acknowledgment lands and closes when the real reply is in hand.

        The wait, not the work, is what decides. Work that finishes inside
        `HOLDING_LINE_AFTER_MS` produces no continuer and no span at all,
        which is correct — there is no silence to fill, and a line spoken into
        a gap that short would collide with the reply it was covering for.

        Two things this deliberately does NOT do:

         - **It never delays the result.** The continuer runs as its own task
           and is cancelled the moment the window closes, so a slow synthesis
           cannot add latency to the very turn it was meant to make feel
           faster. A line already pushed by then is harmless: the room cancels
           whatever is playing when the real reply arrives.
         - **It fires at most once.** A second "bear with me" is not
           reassurance, it is an interview visibly stuck. One line, then
           silence, is the honest signal.

        Without a push channel there is nothing to do — a REST caller learns
        the interview was thinking at the same moment it learns what it
        decided, which is not a continuer, it is a log line. So `on_continuer`
        being `None` short-circuits to a plain pass-through.
        """
        if on_continuer is None:
            yield
            return

        started = time.monotonic()
        spoken: list[bool] = []

        async def _after_the_pause() -> None:
            await asyncio.sleep(HOLDING_LINE_AFTER_MS / 1000)
            spoken.append(await self._continuer(session_id, kind, on_continuer) is not None)

        timer = asyncio.ensure_future(_after_the_pause())
        try:
            yield
        finally:
            if not timer.done():
                timer.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await timer

            waited = round((time.monotonic() - started) * 1000)
            if waited >= HOLDING_LINE_AFTER_MS:
                # Per the cross-cutting rule, a detector that fires says so —
                # and this is emitted when the window CLOSES, not at the
                # threshold, because `waited_ms` would otherwise always report
                # the threshold and say nothing. That makes the span do two
                # jobs: it answers "why did it say 'one moment' there?", and
                # because this detector IS a clock, a run of them is the
                # plainest signal available that the interview has gone quiet
                # on a candidate — timed where they experience it rather than
                # inside the MCP client.
                #
                # In the `finally` so a wait that went long AND then failed is
                # still recorded; that is the case most worth seeing. `spoken`
                # is false when the reply won the race after the timer had
                # already started synthesising.
                await self._emit(
                    "continuer_spoken", session_id, {"kind": kind, "waited_ms": waited, "spoken": bool(spoken)}
                )

    async def _await_with_continuer(
        self,
        awaitable: Awaitable[Any],
        *,
        session_id: str,
        kind: ContinuerKind,
        on_continuer: Optional[ContinuerHook],
    ) -> Any:
        """`_continuer_window` around a single call — the shape that fits a
        call site whose whole wait *is* one round trip, like the Question
        Agent's."""
        async with self._continuer_window(session_id=session_id, kind=kind, on_continuer=on_continuer):
            return await awaitable

    async def _routing_context(self, session: Session, question: Question) -> dict[str, Any]:
        """(Stage 13) The rolling snapshot the Follow-up Agent routes against.

        Reconciled, not merely read. `topic_counts` and the caps come from the
        session's own plan and the Memory Agent's counts on every turn, so the
        cached snapshot cannot drift from what the Question Agent will
        actually enforce a moment later; only the EMA (`rolling_score`) is
        carried forward, because it is a running value rather than a
        recomputable one.

        Best-effort throughout. A tracker that is absent, or a store that
        cannot answer, produces `{}` — the Follow-up Agent then computes no
        routing proposal and `next_action` is exactly what it was before this
        stage. Routing must never be the reason a candidate's answer is not
        scored.
        """
        if not self._deps.tracker:
            return {}
        try:
            tools = self._tools(session.id)
            context = (await tools.call("memory-agent", "get_session_context", {"session_id": session.id}))["session_context"]
            evaluations = await self._deps.evaluations.list_by_session(session.id)
            topic_scores = await self._topic_scores_by_topic(session.id, evaluations)
        except Exception:  # noqa: BLE001 - see the docstring
            return {}

        topic_caps = {e.topic: e.max_questions for e in session.topic_plan}
        topic_counts = context.get("topic_counts", {})

        snapshot = self._deps.tracker.snapshot(
            session.id,
            topic_counts=topic_counts,
            topic_caps=topic_caps,
            topic_scores=topic_scores,
            topic_tier=context.get("topic_tier", {}),
            current_topic=question.topic,
            recent_scores=[e.score for e in evaluations],
        )

        # The introduction is not a topic the interview routes between — it is
        # the fixed opener, asked outside the budget and outside the tier
        # machinery entirely (§4.3). Proposing it as a "next topic" would be
        # proposing to re-introduce the candidate to themselves.
        available = [e.topic for e in session.topic_plan if e.topic != INTRODUCTION_TOPIC]

        return {
            "available_topics": available,
            "exhausted_topics": [t for t in exhausted_from(topic_counts, topic_caps) if t != INTRODUCTION_TOPIC],
            "topic_counts": topic_counts,
            "topic_scores": topic_scores,
            "topic_tier": context.get("topic_tier", {}),
            "current_tier": question.tier or snapshot.current_tier,
            "rolling_score": snapshot.rolling_score,
            "last_score": snapshot.last_score,
        }

    async def _struggle_context(self, session_id: str, topic: str, transcript: str) -> dict[str, Any]:
        """What the Follow-up Agent's struggle detector needs but cannot see:
        the turns before this one.

        Everything here is about PRIOR answers. The current transcript is the
        detector's own input and is deliberately not folded in — this call
        answers "what has been happening", and the detector combines that with
        "what just happened".
        """
        context: dict[str, Any] = {"consecutive_short_answers": 0, "hedge_streak": 0, "topic_recent_scores": []}
        try:
            questions = await self._deps.questions.list_by_session(session_id)
            evaluations = await self._deps.evaluations.list_by_session(session_id)
        except Exception:  # noqa: BLE001 - an unavailable history means no signal, never a wrong one
            return context

        # Walk backwards from the most recent answered question, stopping at
        # the first turn that breaks the run — a streak with a gap in it is not
        # a streak.
        short_run = 0
        hedge_run = 0
        short_open = True
        hedge_open = True
        for question in reversed(questions):
            if not (short_open or hedge_open):
                break
            try:
                answer = await self._deps.answers.get_by_question(question.id)
            except Exception:  # noqa: BLE001
                break
            if not answer:
                continue
            if short_open:
                if is_short_answer(answer.transcript):
                    short_run += 1
                else:
                    short_open = False
            if hedge_open:
                if HEDGE_RE.search(answer.transcript or ""):
                    hedge_run += 1
                else:
                    hedge_open = False

        # The current answer extends the short run only if it is itself short;
        # otherwise the run is broken and there is nothing to report.
        context["consecutive_short_answers"] = short_run + 1 if is_short_answer(transcript) else 0
        context["hedge_streak"] = hedge_run
        try:
            context["topic_recent_scores"] = (await self._topic_scores_by_topic(session_id, evaluations)).get(topic, [])
        except Exception:  # noqa: BLE001
            pass
        return context

    # -------------------------------------------------- (§5) callback facts

    async def _record_callback_fact(self, *, session_id: str, question: Question, transcript: str, score: Optional[float]) -> None:
        """Parks one notable moment in session memory, if this answer had one.

        Best-effort, like every other memory write on this path: a session that
        cannot remember a callback is a session with a shorter memory, not a
        broken one, and the trailing window still carries the last three turns
        regardless.
        """
        # The fixed opener is excluded. It is a warm-up asked outside the
        # question budget, and "earlier you mentioned..." pointing back at a
        # self-introduction is not a callback, it is small talk.
        if question.topic == INTRODUCTION_TOPIC:
            return
        fact = callback_fact_from(transcript, score)
        if not fact:
            return
        try:
            await self._tools(session_id).call(
                "memory-agent",
                "remember_callback_fact",
                {"session_id": session_id, "topic": question.topic, "fact": fact, "source_question_id": question.id},
            )
        except Exception:  # noqa: BLE001
            pass

    async def _callback_facts(self, session_id: str) -> list[dict[str, Any]]:
        try:
            result = await self._tools(session_id).call("memory-agent", "get_callback_facts", {"session_id": session_id})
            return list(result.get("callback_facts") or [])
        except Exception:  # noqa: BLE001
            return []

    async def _reference_answer(self, session_id: str, question_id: str) -> Optional[str]:
        try:
            result = await self._tools(session_id).call("memory-agent", "get_reference_answer", {"session_id": session_id, "question_id": question_id})
            return result.get("reference_answer") if result.get("found") else None
        except Exception:  # noqa: BLE001
            return None

    # ----------------------------------------------------------- coding round

    async def start_coding_round(self, session: Session) -> dict[str, Any]:
        """CODING_ROUND. The problem statement is spoken like any other
        prompt, and clipboard monitoring starts only if the candidate
        consented — the Coding Agent asks the tool, and the tool refuses
        without a valid token."""
        asked_topics = [q.topic for q in await self._deps.questions.list_by_session(session.id)]

        result = await self._tools(session.id).call("coding-agent", "start_coding_round", {"session_id": session.id, "covered_topics": list(dict.fromkeys(asked_topics))})

        await self._tools(session.id).call("time-tracking-agent", "start_segment", {"session_id": session.id, "segment": "coding_round"})

        problem = result["problem"]
        return {
            "problem": problem,
            "clipboard_monitoring": result["clipboard_monitoring"],
            "spoken": await self.speak(session.id, f"{problem['title']}. {problem['statement']}"),
        }

    async def submit_code(self, *, session: Session, code: str, language: Optional[str] = None, talk_through: Optional[str] = None) -> dict[str, Any]:
        params: dict[str, Any] = {"session_id": session.id, "code": code}
        if language:
            params["language"] = language
        if talk_through:
            params["talk_through"] = talk_through
        return await self._tools(session.id).call("coding-agent", "submit_code", params)

    # ------------------------------------------------------------------ voice

    async def speak(self, session_id: str, text: str) -> SpokenText:
        """Every question or follow-up an agent produces goes through here
        before it reaches the candidate (§4.1). Synthesis failure is not
        fatal: the candidate reads the question instead (§5.6)."""
        try:
            result = await self._tools(session_id).call("tool-speech-service", "synthesize_speech", {"text": text, "session_id": session_id})
            return SpokenText(text=text, audio_url=result["audio_url"], duration_ms=result["duration_ms"])
        except Exception as err:  # noqa: BLE001
            return SpokenText(text=text, speech_note=f"audio unavailable ({err}); showing the question as text")

    async def transcribe(self, session_id: str, audio_ref: str, input_device: Optional[dict[str, Any]] = None):
        """Transcribes a recorded answer. Anything short of a transcript the
        tool is willing to stand behind comes back as a refusal, never as a
        transcript with a caveat attached.

        There are now four ways to be refused, and the candidate needs a
        different sentence for each — "that was too quiet to make out", "there
        was nothing in that recording", "that was your speakers, not you", and
        "that could not be transcribed in time". They are distinguished by the
        tool's error code rather than by matching on message text.
        """
        params: dict[str, Any] = {"audio_ref": audio_ref, "session_id": session_id}
        if input_device:
            params["input_device"] = input_device

        # (STT addition) What this session has said out loud recently, so the
        # Speech Service can tell an answer from the microphone hearing our own
        # question through the candidate's speakers. Derived from persisted
        # rows rather than remembered — the harness has no more state for this
        # than `_continuity` does.
        spoken = await self._recently_spoken(session_id)
        if spoken:
            params["spoken_recently"] = spoken

        # (STT addition) Attach question_text and candidate_context so Whisper
        # can prime proper nouns (name, role, companies, institutions, degrees)
        # during the candidate's introduction answer.
        try:
            questions = await self._deps.questions.list_by_session(session_id)
            if questions:
                target_q = None
                for q in reversed(questions):
                    answered = await self._deps.answers.get_by_question(q.id)
                    if not answered:
                        target_q = q
                        break
                if target_q is None:
                    target_q = questions[-1]
                params["question_text"] = target_q.text

            session = await self._deps.sessions.get(session_id)
            if session:
                full_name: Optional[str] = None
                candidate_id = getattr(session, "candidate_id", None) or (session.get("candidate_id") if isinstance(session, dict) else None)
                if self._deps.users and candidate_id:
                    try:
                        user = None
                        if hasattr(self._deps.users, "find_by_id"):
                            user = await self._deps.users.find_by_id(candidate_id)
                        elif hasattr(self._deps.users, "get"):
                            user = await self._deps.users.get(candidate_id)
                        if user:
                            full_name = getattr(user, "full_name", None) or (user.get("full_name") if isinstance(user, dict) else None)
                    except Exception:  # noqa: BLE001
                        pass

                profile = getattr(session, "candidate_profile", None) or (session.get("candidate_profile") if isinstance(session, dict) else None)
                recent_companies: list[str] = []
                institutions: list[str] = []
                degrees: list[str] = []
                keywords: list[str] = []
                if profile:
                    exp = getattr(profile, "experience", None) or (profile.get("experience") if isinstance(profile, dict) else None) or []
                    for e in exp:
                        c = getattr(e, "company", None) or (e.get("company") if isinstance(e, dict) else None)
                        if c and str(c).strip():
                            recent_companies.append(str(c).strip())

                    edu = getattr(profile, "education", None) or (profile.get("education") if isinstance(profile, dict) else None) or []
                    for e in edu:
                        inst = getattr(e, "institution", None) or (e.get("institution") if isinstance(e, dict) else None)
                        deg = getattr(e, "degree", None) or (e.get("degree") if isinstance(e, dict) else None)
                        if inst and str(inst).strip():
                            institutions.append(str(inst).strip())
                        if deg and str(deg).strip():
                            degrees.append(str(deg).strip())

                    raw_kws = getattr(profile, "keywords", None) or (profile.get("keywords") if isinstance(profile, dict) else None) or []
                    raw_skills = getattr(profile, "skills", None) or (profile.get("skills") if isinstance(profile, dict) else None) or []
                    seen_kws: set[str] = set()
                    for item in list(raw_kws) + list(raw_skills):
                        if item and str(item).strip():
                            val = str(item).strip()
                            if val.lower() not in seen_kws:
                                seen_kws.add(val.lower())
                                keywords.append(val)

                params["candidate_context"] = {
                    "full_name": full_name,
                    "role": getattr(session, "role", None) or (session.get("role") if isinstance(session, dict) else None),
                    "recent_companies": recent_companies,
                    "institutions": institutions,
                    "degrees": degrees,
                    "keywords": keywords,
                }
        except Exception:  # noqa: BLE001
            pass

        try:
            result = await self._tools(session_id).call("tool-speech-service", "transcribe_speech", params)
        except Exception as err:  # noqa: BLE001
            return await self._transcription_refused(session_id, err)

        await self._emit_speech_span(session_id, result)
        return AcceptedTranscript(accepted=True, transcript=result["transcript"], confidence=result["confidence"])

    async def _transcription_refused(self, session_id: str, err: Exception) -> LowConfidenceTranscript:
        code = getattr(err, "code", None)
        message = str(err)

        if code == "transcription_low_confidence":
            detail = _parse_low_confidence(message)
            await self._deps.telemetry.emit("transcription_low_confidence", session_id, {"confidence": detail.get("confidence")})
            return LowConfidenceTranscript(
                accepted=False,
                reason=detail.get("message", message),
                confidence=detail.get("confidence"),
                draft_transcript=detail.get("draft_transcript"),
                code=code,
            )

        if code == "no_speech_detected":
            # No draft is offered. There is nothing to correct — the VAD found
            # no speech, so any text here would be invented (soul.md §5).
            await self._deps.telemetry.emit("transcription_no_speech", session_id, {"reason": _truncate_words(message, 20)})
            return LowConfidenceTranscript(
                accepted=False,
                reason="No speech was picked up in that recording — check your microphone is on, and try again.",
                code=code,
            )

        if code == "audio_source_rejected":
            detail = _parse_low_confidence(message)
            await self._deps.telemetry.emit("audio_source_rejected", session_id, {"source": detail.get("source", "speaker")})
            # Nor here, and for a stronger reason: the draft transcript IS our
            # own question. Pre-filling it would invite the candidate to submit
            # the interview's words as their answer.
            return LowConfidenceTranscript(
                accepted=False,
                reason="That recording picked up the interview's own voice rather than yours — use headphones, or start recording after the question finishes.",
                code=code,
            )

        return LowConfidenceTranscript(accepted=False, reason=message, code=code or "transcription_failed")

    async def _emit_speech_span(self, session_id: str, result: dict[str, Any]) -> None:
        """Durations and ratios only — never the transcript (INSTRUCTIONS.md §8)."""
        speech = result.get("speech")
        if not speech:
            return
        try:
            await self._deps.telemetry.emit(
                "transcription_completed",
                session_id,
                {
                    "source": result.get("source", "unknown"),
                    "total_ms": speech.get("total_ms"),
                    "speech_ratio": speech.get("speech_ratio"),
                    "trimmed_ms": speech.get("trimmed_ms"),
                    "decode_ms": speech.get("decode_ms"),
                },
            )
        except Exception:  # noqa: BLE001 - a span is never worth a turn
            pass

    async def _recently_spoken(self, session_id: str) -> list[str]:
        """The last couple of lines the interview said out loud.

        The most recent question, plus the newest follow-up asked against it —
        which between them are everything a microphone could realistically have
        overheard in the seconds before the candidate started recording.
        Best-effort: no history means no echo check, which is the pre-addition
        behaviour.
        """
        try:
            questions = await self._deps.questions.list_by_session(session_id)
            if not questions:
                return []
            latest = questions[-1]
            lines = [latest.text]
            answer = await self._deps.answers.get_by_question(latest.id)
            if answer and answer.follow_ups:
                lines.append(answer.follow_ups[-1].text)
            return [line for line in lines if line and line.strip()]
        except Exception:  # noqa: BLE001
            return []

    # ------------------------------------------------------------- monitoring

    async def start_focus_monitor(self, session_id: str) -> None:
        """Starts fullscreen-exit tracking for the whole active interview.
        Best-effort: no consent (or no dep at all) simply means the monitor
        never starts."""
        if not self._deps.focus_consent_token:
            return
        token = await self._deps.focus_consent_token(session_id)
        if not token:
            return
        try:
            await self._tools(session_id).call("tool-focus-monitor", "start_monitor", {"session_id": session_id, "consent_token": token})
        except Exception:  # noqa: BLE001
            pass

    async def record_paste_event(self, session_id: str, timestamp: str) -> bool:
        try:
            await self._tools(session_id).call("tool-clipboard-monitor", "paste_event_detected", {"session_id": session_id, "detected": True, "timestamp": timestamp})
            return True
        except Exception:  # noqa: BLE001 - no consent means no record
            return False

    async def record_focus_event(self, session_id: str, timestamp: str) -> dict[str, Any]:
        try:
            result = await self._tools(session_id).call("tool-focus-monitor", "focus_event_detected", {"session_id": session_id, "detected": True, "timestamp": timestamp})
            return {"recorded": result["recorded"], "exit_count": result["exit_count"]}
        except Exception:  # noqa: BLE001
            return {"recorded": False, "exit_count": 0}

    # ------------------------------------------------------------- reporting

    async def generate_report(self, session: Session) -> dict[str, Any]:
        """REPORT_GENERATION: gathers every question, its answer, and every
        persisted Evaluation into one transcript, folds in the coding
        round's result when one ran, and hands the whole thing to the
        Report Agent to compile. Nothing here scores anything itself; it
        only assembles what was already evidenced during the interview
        (soul.md §"No fabrication")."""
        from app.shared_types import McpHandlerError

        questions = await self._deps.questions.list_by_session(session.id)
        transcript: list[dict[str, Any]] = []

        for question in questions:
            answer = await self._deps.answers.get_by_question(question.id)
            evaluations = await self._deps.evaluations.list_by_answer(answer.id) if answer else []
            transcript.append(
                {
                    "question_id": question.id,
                    "topic": question.topic,
                    "type": question.type,
                    "text": question.text,
                    "answer": ({"id": answer.id, "transcript": answer.transcript, "submitted_at": answer.submitted_at} if answer else None),
                    "evaluations": [{"rubric_id": e.rubric_id, "score": e.score, "rationale": e.rationale, "evidence_spans": [{"start": s.start, "end": s.end} for s in e.evidence_spans]} for e in evaluations],
                }
            )

        try:
            round_ = await self._tools(session.id).call("coding-agent", "get_round_result", {"session_id": session.id})
            if round_.get("result") and round_["result"].get("evaluation") and round_.get("problem"):
                evaluation = round_["result"]["evaluation"]
                transcript.append(
                    {
                        # A fixed label, not one of the resume/role topics: mixing a
                        # coding score into a topic like "distributed systems"
                        # would blend two different rubrics' signals under one name.
                        "question_id": f"coding-round:{round_['problem_id']}",
                        "topic": "coding round",
                        "type": "coding",
                        "text": round_["problem"]["statement"],
                        "answer": {"id": f"coding-round:{round_['problem_id']}", "transcript": round_["talk_through"], "submitted_at": datetime.now(timezone.utc).isoformat()},
                        "evaluations": [{"rubric_id": "coding_round_v1", "score": evaluation["score"], "rationale": evaluation["rationale"], "evidence_spans": evaluation["evidence_spans"]}],
                    }
                )
        except McpHandlerError as err:
            # Most sessions never run a coding round at all (soul.md §3: it
            # branches per role) — that is not a report failure.
            if err.code != "no_active_round":
                raise

        # (Dynamic evaluation addition) `TopicPlanEntry.source` already
        # distinguishes JD-critical topics from resume-derived ones — it
        # drove what got asked; this is the same signal now also driving how
        # much each competency counts toward `role_fit_grade`
        # (`grading.TOPIC_SOURCE_WEIGHT`).
        topic_sources = {e.topic: e.source for e in session.topic_plan}

        result = await self._tools(session.id).call(
            "report-agent",
            "generate_report",
            {"session_id": session.id, "candidate_id": session.candidate_id, "transcript": transcript, "topic_sources": topic_sources},
        )

        from app.shared_types import MAX_FOCUS_EXITS
        from app.shared_types.report import BrowserActivitySummary, CompetencyScore, Grade, Report

        return Report(
            session_id=session.id,
            candidate_id=session.candidate_id,
            competency_scores=[
                CompetencyScore(
                    competency=c["competency"],
                    score=c["score"],
                    evidence=c["evidence"],
                    grade=Grade(**c["grade"]) if c.get("grade") else None,
                )
                for c in result["competency_scores"]
            ],
            # Copied through, never recomputed here. The Eval Tool banded it
            # once from the same evidenced scores; a second derivation on the
            # way past is how two numbers for one session start to disagree.
            overall_grade=Grade(**result["overall_grade"]) if result.get("overall_grade") else None,
            # (Dynamic evaluation addition) Additive alongside `overall_grade`,
            # never a replacement for it — weighted by how JD/role-critical
            # each topic was known to be before any of it was asked about.
            # Absent whenever the report agent had nothing to weight.
            role_fit_grade=Grade(**result["role_fit_grade"]) if result.get("role_fit_grade") else None,
            strengths=result["strengths"],
            focus_areas=result["focus_areas"],
            # A direct copy of `Session.focus_events` — never re-derived from
            # telemetry or guessed at (soul.md §"No fabrication" applied to
            # proctoring signals the same way it applies to scores).
            browser_activity=BrowserActivitySummary(exit_count=len(session.focus_events), events=session.focus_events, concluded_early=len(session.focus_events) > MAX_FOCUS_EXITS),
            disclaimer=result["disclaimer"],
            created_at=datetime.now(timezone.utc).isoformat(),
        )


def _truncate_words(text: str, max_words: int) -> str:
    words = (text or "").split()
    return " ".join(words) if len(words) <= max_words else " ".join(words[:max_words]) + "…"


def _parse_low_confidence(message: str) -> dict[str, Any]:
    """The Speech Service packs its detail into the error message as JSON so
    the confidence and the draft survive the MCP error boundary."""
    import json

    try:
        parsed = json.loads(message)
        return {"message": parsed.get("message", message), "confidence": parsed.get("confidence"), "draft_transcript": parsed.get("draft_transcript")}
    except Exception:  # noqa: BLE001
        return {"message": message}


def _resume_anchor_for(session: Session, topic: str) -> str:
    """Resolves `dynamicFraming.resumeContextIntegrationRule` for one
    candidate: the highest-relevance `topic_relevance` evidence line for
    this topic, falling back to a plain statement rather than inventing an anchor."""
    profile = session.candidate_profile
    if not profile:
        return f"no resume evidence on file for {topic}"
    matches = sorted((t for t in profile.topic_relevance if t.topic == topic), key=lambda t: t.relevance_score, reverse=True)
    return matches[0].evidence if matches else f"no resume evidence on file for {topic}"


def _profile_lines(session: Session) -> list[str]:
    profile = session.candidate_profile
    if not profile:
        return []
    lines = [
        *[t.evidence for t in profile.topic_relevance],
        *[f"{e.title} at {e.company}" for e in profile.experience],
        # (highlights fix) One line per resume highlight, attributed to the
        # role it came from. These are verbatim project/achievement bullets
        # (see `resume-parser/v1`) — the only source of NAMED project detail
        # in the candidate profile, as opposed to the generic topic evidence
        # and skills lines above. Empty when the LLM parse path didn't run
        # (or ran before this fix), so this is additive, never a regression.
        *[f"{e.title} at {e.company}: {highlight}" for e in profile.experience for highlight in e.highlights],
        *profile.skills,
    ]
    return [line for line in lines if line.strip()]


def _compose_live_session_state(*, session: Session, question: Question, extraction: ExtractionProcessorResult, next_action: NextActionGenerator, score: Optional[float], elapsed_ms: float) -> LiveSessionState:
    from app.shared_types.session import ContextEngine, SessionMetrics

    return LiveSessionState(
        session_id=session.id,
        candidate_id=session.candidate_id,
        active_topic_id=question.topic,
        session_metrics=SessionMetrics(
            elapsed_time_seconds=round(elapsed_ms / 1000),
            # This turn's score, not a running session-wide average. Rubric scores are 0-5.
            topic_competency_score=max(0.0, min(1.0, score / 5)) if score is not None else 0.0,
            current_demonstrated_tier=question.tier or 1,
        ),
        context_engine=ContextEngine(active_resume_anchor=_resume_anchor_for(session, question.topic), last_delivered_prompt=question.text),
        extraction_processor=extraction,
        next_action_generator=next_action,
    )

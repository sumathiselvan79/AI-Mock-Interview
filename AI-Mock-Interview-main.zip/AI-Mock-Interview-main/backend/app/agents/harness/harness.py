"""Harness Agent — MCP host, session state machine, sole interface to the frontend.

~ agents/harness-agent/src/index.ts.

F4 scope (mirrors TS Stage 1): the state machine is real and authoritative;
the interview loop (`InterviewOrchestrator` — question loop, follow-ups,
coding round, voice, reporting) is wired in as later stages land (F5-F9) add
their dependencies. A harness built without those deps can still do
everything Stage 1 needs: create/read sessions, drive `transition`, and
gate on the telemetry check. The harness never speaks to the candidate
(soul.md §2) and is the only component that may write `Session.state`.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Optional

from app.agents.harness.interview import InterviewDeps, InterviewOrchestrator
from app.agents.harness.state_machine import STATE_OWNER, can_transition, requires_telemetry_check
from app.http.session_tracker import default_tracker
from app.shared_types import McpHandlerError, Session, SessionState, StateWriteGrant

# The capability that authorizes a `Session.state` write. Constructed exactly
# once, at import time, so importing this module is the only way to obtain a
# grant with this identity — mirrors the TS module-private `unique symbol`.
HARNESS_GRANT = StateWriteGrant()


class TransitionRejected(Exception):
    def __init__(self, message: str, from_state: SessionState, to_state: SessionState) -> None:
        super().__init__(message)
        self.from_state = from_state
        self.to_state = to_state


@dataclass
class HarnessDeps:
    sessions: Any
    telemetry: Any
    telemetry_check_passed: Callable[[str], Awaitable[bool]]

    # Later stages: what the harness needs to run QUESTION_LOOP and beyond.
    # Optional so a state-machine-only harness can still be constructed (F4).
    questions: Optional[Any] = None
    answers: Optional[Any] = None
    evaluations: Optional[Any] = None
    tool_client: Optional[Callable[[str, str], Any]] = None
    reports: Optional[Any] = None
    archives: Optional[Any] = None
    users: Optional[Any] = None
    focus_consent_token: Optional[Callable[[str], Awaitable[Optional[str]]]] = None
    # (Stage 13) The routing snapshot cache. Optional, and defaulted to the
    # process-wide one at construction — a harness built without it simply
    # computes no routing proposals, which is the pre-Stage-13 interview.
    tracker: Optional[Any] = None


@dataclass
class StateResult:
    done: bool
    note: str


class HarnessAgent:
    def __init__(self, deps: HarnessDeps) -> None:
        self._deps = deps
        self._deps.sessions.register_state_writer(HARNESS_GRANT)
        self._interview: Optional[InterviewOrchestrator] = (
            InterviewOrchestrator(
                InterviewDeps(
                    sessions=deps.sessions,
                    questions=deps.questions,
                    answers=deps.answers,
                    evaluations=deps.evaluations,
                    telemetry=deps.telemetry,
                    tool_client=deps.tool_client,
                    focus_consent_token=deps.focus_consent_token,
                    tracker=deps.tracker if deps.tracker is not None else default_tracker,
                    users=deps.users,
                )
            )
            if deps.questions is not None and deps.answers is not None and deps.evaluations is not None and deps.tool_client is not None
            else None
        )

    async def get_session(self, session_id: str) -> Optional[Session]:
        return await self._deps.sessions.get(session_id)

    def orchestrator(self) -> InterviewOrchestrator:
        if self._interview is None:
            raise RuntimeError("this harness was built without the interview-loop dependencies")
        return self._interview

    async def _require_session(self, session_id: str) -> Session:
        session = await self._deps.sessions.get(session_id)
        if not session:
            raise ValueError(f"unknown session {session_id}")
        return session

    async def profile_resume(self, session_id: str) -> dict[str, Any]:
        """CONFIG: route the uploaded resume to the Resume Service Agent and
        return the JD-fit result for the Interview Config page. Informational
        only — a low fit score never blocks a candidate from starting
        (soul.md §3)."""
        return await self.orchestrator().profile_resume(await self._require_session(session_id))

    async def delete_resume(self, session_id: str) -> bool:
        """Routes a delete request to the Resume Service Agent, which
        hard-deletes the stored file and verifies it is gone before reporting
        success (INSTRUCTIONS.md §8)."""
        await self._require_session(session_id)
        if not self._deps.tool_client:
            raise McpHandlerError("not_implemented", "this harness was built without a tool client")
        result = await self._deps.tool_client(session_id, "harness-agent").call(
            "resume-service-agent", "delete_resume", {"session_id": session_id}
        )
        return result["deleted"]

    async def transition(
        self, session_id: str, to_state: SessionState, reason: str = "harness_decision"
    ) -> Session:
        """Move a session to `to`. Rejects illegal transitions and any
        transition past an unpassed telemetry check. Emits
        `session_state_changed` telemetry with IDs and states only — never
        any session content (INSTRUCTIONS.md §8)."""
        session = await self._deps.sessions.get(session_id)
        if not session:
            raise TransitionRejected(f"unknown session {session_id}", "CREATED", to_state)

        check = can_transition(session.state, to_state)
        if not check.allowed:
            raise TransitionRejected(check.reason or "illegal transition", session.state, to_state)

        if requires_telemetry_check(to_state) and not await self._deps.telemetry_check_passed(session_id):
            raise TransitionRejected(
                f"telemetry check has not passed; {to_state} is gated behind it", session.state, to_state
            )

        updated = await self._deps.sessions.set_state(session_id, to_state, HARNESS_GRANT, reason)

        await self._deps.telemetry.emit(
            "session_state_changed",
            session_id,
            {
                "from_state": session.state,
                "to_state": to_state,
                "owner": STATE_OWNER[to_state],
                "reason": reason,
            },
        )

        return updated

    async def abort(self, session_id: str, reason: str) -> Session:
        """Terminal abort. Always available so a partial report can still be handed back (§3)."""
        return await self.transition(session_id, "ABORTED", reason)

    async def begin_interview(self, session_id: str) -> Session:
        """Moves a configured session into the interview proper:
        TELEMETRY_CHECK -> CALIBRATION (build the topic plan) -> QUESTION_LOOP.
        The device-check gate is enforced by `transition`, not re-checked here."""
        session = await self._require_session(session_id)

        if session.state == "TELEMETRY_CHECK":
            session = await self.transition(session_id, "CALIBRATION", "telemetry_check_passed")
        if session.state != "CALIBRATION":
            raise TransitionRejected(f"begin_interview expects CALIBRATION, session is in {session.state}", session.state, "CALIBRATION")

        session = await self.orchestrator().build_topic_plan(session)

        if not session.topic_plan:
            raise TransitionRejected("no topic plan could be built — upload a resume or set a role with required topics first", session.state, "QUESTION_LOOP")

        # The overall session clock starts when questioning does, not at login.
        if self._deps.tool_client:
            await self._deps.tool_client(session_id, "harness-agent").call("time-tracking-agent", "start_segment", {"session_id": session_id, "segment": "session"})

        # Fullscreen-exit tracking starts here too. No-ops without consent.
        await self.orchestrator().start_focus_monitor(session_id)

        return await self.transition(session_id, "QUESTION_LOOP", "topic_plan_ready")

    async def opening_line(self, session_id: str, on_continuer: Optional[Callable[[Any], Awaitable[None]]] = None):
        """(§8) The session's hello, spoken once, before the introduction
        opener asks the candidate to talk about themselves.

        Its own call rather than something `begin_interview` returns, because
        `begin_interview` returns a `Session` that four callers already read
        and a greeting is not session state. A caller that skips it gets the
        interview exactly as it was before §8 existed.
        """
        await self._require_session(session_id)
        return await self.orchestrator().opening_line(session_id, on_continuer)

    async def next_question(self, session_id: str, advance: bool = False, on_continuer: Optional[Callable[[Any], Awaitable[None]]] = None):
        """One turn of the loop. When the budget is spent the harness — not
        the Question Agent — decides the interview is over and moves the
        session on.

        (§8) `on_continuer` is the push channel a "let me find a good place to
        go next" line goes out on when the Question Agent runs long."""
        session = await self._require_session(session_id)
        if session.state != "QUESTION_LOOP":
            raise TransitionRejected(f"questions are only served during QUESTION_LOOP; session is in {session.state}", session.state, "QUESTION_LOOP")

        result = await self.orchestrator().next_question(session, advance, on_continuer=on_continuer)
        if result.done:
            await self.transition(session_id, "WRAP_UP", "question_budget_spent")
        return result

    async def submit_answer(
        self,
        *,
        session_id: str,
        question_id: str,
        transcript: str,
        transcript_confidence: Optional[float] = None,
        on_acknowledgment: Optional[Callable[[Any], Awaitable[None]]] = None,
        on_continuer: Optional[Callable[[Any], Awaitable[None]]] = None,
    ):
        """Returns an `AnswerResult`, or a `MetaUtteranceResult` when the
        candidate asked about the question instead of answering it (§3)."""
        session = await self._require_session(session_id)
        return await self.orchestrator().submit_answer(
            session=session,
            question_id=question_id,
            transcript=transcript,
            transcript_confidence=transcript_confidence,
            on_acknowledgment=on_acknowledgment,
            on_continuer=on_continuer,
        )

    async def submit_follow_up_answer(
        self, *, session_id: str, answer_id: str, follow_up_text: str, transcript: str, on_continuer: Optional[Callable[[Any], Awaitable[None]]] = None
    ):
        """`session_id` is required, not inferred from the answer: it is
        what the orchestrator checks `answer_id` against, so a
        client-supplied answer id can only ever reach the session the caller
        was already authorized for."""
        await self._require_session(session_id)
        return await self.orchestrator().submit_follow_up_answer(
            session_id=session_id, answer_id=answer_id, follow_up_text=follow_up_text, transcript=transcript, on_continuer=on_continuer
        )

    async def speak(self, session_id: str, text: str):
        """Synthesises any text the candidate is about to hear (§4.1)."""
        return await self.orchestrator().speak(session_id, text)

    async def transcribe_audio(self, *, session_id: str, audio_ref: str, input_device: Optional[dict[str, Any]] = None):
        """Transcribes a recording and stops — nothing is scored, no state moves."""
        await self._require_session(session_id)
        return await self.orchestrator().transcribe(session_id, audio_ref, input_device)

    async def submit_audio_answer(
        self,
        *,
        session_id: str,
        question_id: str,
        audio_ref: str,
        on_acknowledgment: Optional[Callable[[Any], Awaitable[None]]] = None,
        on_continuer: Optional[Callable[[Any], Awaitable[None]]] = None,
        input_device: Optional[dict[str, Any]] = None,
    ):
        """A spoken answer. Transcription happens first, and any refusal —
        low confidence, no speech, or the candidate's own speakers — stops
        here with nothing written and nothing scored."""
        session = await self._require_session(session_id)
        transcription = await self.orchestrator().transcribe(session_id, audio_ref, input_device)

        if not transcription.accepted:
            return {"accepted": False, "retry": transcription}

        result = await self.orchestrator().submit_answer(
            session=session,
            question_id=question_id,
            transcript=transcription.transcript,
            transcript_confidence=transcription.confidence,
            on_acknowledgment=on_acknowledgment,
            on_continuer=on_continuer,
        )
        return {"accepted": True, "result": result}

    async def start_coding_round(self, session_id: str) -> dict[str, Any]:
        session = await self._require_session(session_id)

        if session.state == "QUESTION_LOOP":
            session = await self.transition(session_id, "CODING_ROUND", "question_loop_complete")
        if session.state != "CODING_ROUND":
            raise TransitionRejected(f"the coding round runs in CODING_ROUND; session is in {session.state}", session.state, "CODING_ROUND")

        started = await self.orchestrator().start_coding_round(session)
        await self._deps.telemetry.emit(
            "coding_round_started", session_id, {"problem_id": str(started["problem"].get("id", "unknown")), "clipboard_monitoring": started["clipboard_monitoring"]}
        )
        return started

    async def submit_code(self, *, session_id: str, code: str, language: Optional[str] = None, talk_through: Optional[str] = None) -> dict[str, Any]:
        session = await self._require_session(session_id)
        result = await self.orchestrator().submit_code(session=session, code=code, language=language, talk_through=talk_through)

        # Sizes and counts only — never the submitted code (INSTRUCTIONS.md §8).
        await self._deps.telemetry.emit("code_submitted", session_id, {"code_bytes": len(code), "passed": int(result.get("passed") or 0), "total": int(result.get("total") or 0)})
        return result

    async def record_paste_event(self, session_id: str, timestamp: str) -> bool:
        """A consented paste during the coding round. The Clipboard Monitor
        writes the telemetry itself."""
        return await self.orchestrator().record_paste_event(session_id, timestamp)

    async def record_focus_event(self, session_id: str, timestamp: str) -> dict[str, Any]:
        """A consented fullscreen exit. On the 4th recorded exit the session
        is wrapped up automatically."""
        from app.shared_types.session import MAX_FOCUS_EXITS

        result = await self.orchestrator().record_focus_event(session_id, timestamp)
        if not result["recorded"] or result["exit_count"] <= MAX_FOCUS_EXITS:
            return {**result, "concluded": False}

        await self._deps.telemetry.emit("interview_concluded_early", session_id, {"exit_count": result["exit_count"]})
        wrap_up = await self.wrap_up(session_id)
        return {**result, "concluded": True, "wrap_up": wrap_up}

    async def generate_report(self, session_id: str) -> dict[str, Any]:
        """WRAP_UP -> REPORT_GENERATION -> COMPLETED. Compiles and persists
        the report, then purges what INSTRUCTIONS.md §8 says is no longer needed once it
        exists: the raw resume (same hard-delete path as an explicit
        candidate delete, §4.2) and every answer's full transcript, unless
        the candidate opted into keeping their recordings for personal
        review (`consent.audio_recording`). Redaction happens after
        persistence, so the report's own evidence quotes are unaffected."""
        if not self._deps.reports:
            raise RuntimeError("this harness was built without a report store")

        session = await self._require_session(session_id)
        if session.state == "WRAP_UP":
            session = await self.transition(session_id, "REPORT_GENERATION", "wrap_up_complete")
        if session.state != "REPORT_GENERATION":
            raise TransitionRejected(f"report generation runs in REPORT_GENERATION; session is in {session.state}", session.state, "REPORT_GENERATION")

        report = await self.orchestrator().generate_report(session)
        await self._deps.reports.create(report)

        if session.resume_ref:
            await self.delete_resume(session_id)

        if not session.consent.audio_recording:
            for question in await self._deps.questions.list_by_session(session_id):
                answer = await self._deps.answers.get_by_question(question.id)
                if answer:
                    await self._deps.answers.redact(answer.id)

        completed = await self.transition(session_id, "COMPLETED", "report_generated")

        # (F12) Archiving runs HERE and nowhere earlier: strictly after the
        # retention/redaction above, so the archive can never be more
        # permissive than the primary record at the moment it is compiled.
        await self._archive_session(completed)

        # The reference answers and jd_fit working state this session was
        # holding have no purpose past COMPLETED (§4.7).
        await self._forget_session_memory(session_id)

        return {"session": completed, "report": report}

    async def _archive_session(self, session: Session) -> None:
        """(F12) Compiles and ships the session archive (§11.4). Not yet
        wired — archiving is added when F12 lands the Supabase-backed
        archive store; absent one, this is a no-op, matching the TS
        contract that a deployment without the archive database completes
        sessions exactly as before archiving existed."""
        if not self._deps.archives:
            return
        # F12 fills this in: compile_session_archive + archives.upsert +
        # session_archived/session_archive_failed telemetry.

    async def _forget_session_memory(self, session_id: str) -> None:
        try:
            if self._deps.tool_client:
                await self._deps.tool_client(session_id, "harness-agent").call("memory-agent", "forget_session", {"session_id": session_id})
        except Exception:  # noqa: BLE001 - working memory has a TTL of its own
            pass

    async def wrap_up(self, session_id: str) -> dict[str, Any]:
        """WRAP_UP: the harness's own closing message, then on to the report.

        (§7) The closing line names what this session actually covered rather
        than reading the same script every time. It is a tone layer over data
        already persisted — a list of topics and a count of answers — and it
        forms no judgement of its own: the report is minutes away and owns all
        of that (`session_arc.py` has the full reasoning).
        """
        session = await self._require_session(session_id)
        if session.state in ("QUESTION_LOOP", "CODING_ROUND"):
            session = await self.transition(session_id, "WRAP_UP", "interview_finished")
        spoken = await self.orchestrator().speak(session_id, await self._closing_line(session_id))
        return {"session": session, "spoken": spoken}

    async def _closing_line(self, session_id: str) -> str:
        """The arc-aware closing message, falling back to the fixed one.

        Best-effort: a store that cannot serve the walk gives the generic
        ending, which is exactly what every session got before this existed.
        An interview must not fail to end because it could not describe itself.
        """
        from app.agents.harness.session_arc import BASE_WRAP_UP, build_session_arc, wrap_up_line

        if self._deps.questions is None or self._deps.answers is None:
            return BASE_WRAP_UP
        try:
            questions = await self._deps.questions.list_by_session(session_id)
            pairs = [(q.topic, await self._deps.answers.get_by_question(q.id) is not None) for q in questions]
        except Exception:  # noqa: BLE001
            return BASE_WRAP_UP
        return wrap_up_line(build_session_arc(pairs))

    async def run_state(self, session_id: str) -> StateResult:
        """Per-state work. Stage 1: no-ops. Each later stage replaces one
        entry with a real MCP call to the owning agent — the routing shape
        stays identical."""
        session = await self._deps.sessions.get(session_id)
        if not session:
            return StateResult(False, f"unknown session {session_id}")
        return StateResult(
            True, f"no-op: {session.state} is owned by {STATE_OWNER[session.state]}, wired in a later stage"
        )

"""Session-level arc — `HUMAN_INTERACTION_FLOW.md` §7.

Every question in a session is chosen from topic/tier/quota/score state, but
none of that reached the closing message: `wrap_up()` read the same fixed
script whatever had happened, which is the one moment of a session where a
generic line is most obvious.

What this builds is a **tone layer over data that is already computed and
persisted**, and it is worth being precise about what that excludes:

 - It is not a second judgement. The Report Agent aggregates the evidenced
   scores and the Eval Tool bands them; nothing here scores, ranks, or grades
   anything, and no strongest/weakest topic is named. Two components each
   forming an opinion about how a session went is exactly how the report and
   the closing line start to disagree, and the report is the one with the
   evidence (soul.md §"No fabrication").
 - It is not an LLM re-summarisation per turn. It is a count and a list of
   names, derived from the persisted questions and answers.

So the arc states facts the candidate watched happen: which topics came up,
and how many questions they answered. That is enough for the ending to be
about their session rather than about sessions in general.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

from app.interview_domain.introduction import INTRODUCTION_TOPIC

#: Beyond this many topic names the closing line stops being a sentence and
#: starts being a list. Sessions are capped well below it in practice; this is
#: a floor under readability, not a policy.
_MAX_NAMED_TOPICS = 4


@dataclass(frozen=True)
class SessionArc:
    #: Topics with at least one ANSWERED question, in the order they came up.
    #: Asked-but-unanswered topics are left out: "we covered X" has to mean the
    #: candidate actually got to say something about X.
    covered_topics: list[str]
    answered_count: int


def build_session_arc(pairs: Sequence[tuple[str, bool]]) -> SessionArc:
    """Builds the arc from `(topic, was_answered)` in the order the questions
    were asked — which is all the harness has to walk to produce it.

    The introduction opener is excluded. It is asked outside `question_budget`
    and is not a domain topic (`interview_domain/introduction.py`), so counting
    it would inflate both numbers against everything else that reads them.
    """
    covered: list[str] = []
    answered = 0
    for topic, was_answered in pairs:
        if topic == INTRODUCTION_TOPIC or not was_answered:
            continue
        answered += 1
        if topic not in covered:
            covered.append(topic)
    return SessionArc(covered_topics=covered, answered_count=answered)


#: The pre-arc closing line, kept verbatim. It is the fallback for a session
#: with nothing answered — where there is genuinely nothing specific to say,
#: and inventing something would be worse than the generic version.
BASE_WRAP_UP = (
    "That's the end of the session. Your feedback is being put together now — it will point at "
    "specific moments from this conversation, so you can see exactly what to work on."
)


def wrap_up_line(arc: SessionArc) -> str:
    """The closing message, grounded in what actually happened.

    Note what is absent: no verdict, no score, no "you did well on X". The
    report is minutes away and owns all of that; this line's job is only to
    close a conversation the candidate was present for.
    """
    if not arc.covered_topics or arc.answered_count == 0:
        return BASE_WRAP_UP

    questions = "one question" if arc.answered_count == 1 else f"{arc.answered_count} questions"
    return (
        f"That's the end of the session — {questions} across {_join(arc.covered_topics)}. "
        "Your feedback is being put together now; it will point at specific moments from this "
        "conversation, so you can see exactly what to work on."
    )


def _join(topics: list[str]) -> str:
    named = topics[:_MAX_NAMED_TOPICS]
    overflow = len(topics) - len(named)

    if overflow > 0:
        others = "one other area" if overflow == 1 else f"{overflow} other areas"
        return f"{', '.join(named)} and {others}"
    if len(named) == 1:
        return named[0]
    return f"{', '.join(named[:-1])} and {named[-1]}"

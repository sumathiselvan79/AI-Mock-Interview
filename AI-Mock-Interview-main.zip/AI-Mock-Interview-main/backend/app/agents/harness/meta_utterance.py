"""Meta-utterance detection — `HUMAN_INTERACTION_FLOW.md` §3.

"Can you repeat that?" is not an answer, and before this it had nowhere to go
but into `submit_answer`, where it became an `Answer` row and got scored as a
very bad one. A human interviewer recognises a clarification request and just
answers it.

Harness-level on purpose. This is a new branch of the QUESTION_LOOP flow —
whether a turn is an answer at all — and "what happens next" is the harness's
decision, not any agent's (CLAUDE.md §5). It runs before the Follow-up Agent
is called, before the Eval Tool sees anything, and before an `Answer` is
written.

Deterministic-first, same shape as `followup/server.py`'s `_GAPS`: a regex
pass decides *that* this is a meta-utterance, and the response is assembled
from the question's own text. No model call, so there is nothing here that
could invent a clarification the question does not actually support.

**The failure mode this is written against is the false positive.** Swallowing
a real answer is much worse than scoring a "sorry, what?" — the candidate
loses work they will not get a second chance to give. So the match is
deliberately hard to trip:

 - only very short utterances are considered at all (`MAX_META_WORDS`),
 - the pattern must match the WHOLE utterance, not appear inside it, so an
   answer that opens "Sorry, um — so what we did was..." is untouched,
 - every match is emitted to telemetry by the caller, so a false positive is
   visible after the fact rather than silently eating an answer.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Literal, Optional

MetaUtteranceKind = Literal["repeat", "clarify"]

#: Longer than this and it is an answer, whatever it contains. A genuine
#: request to repeat a question is short; nobody asks for one in 20 words.
MAX_META_WORDS = 12

# Stripped before matching so "Sorry, could you repeat that?" and "Could you
# repeat that?" are the same utterance. Only leading conversational filler —
# never anything that carries content.
_LEADING_FILLER_RE = re.compile(r"^(?:(?:um|uh|er|erm|sorry|pardon|excuse me|hey|hi|okay|ok|so|well|yeah)[,\s]+)+", re.IGNORECASE)
_TRAILING_PUNCT_RE = re.compile(r"[\s.!?]+$")
_WHITESPACE_RE = re.compile(r"\s+")

# Every pattern is anchored at both ends: it has to BE the utterance.
_REPEAT_PATTERNS: tuple[re.Pattern[str], ...] = tuple(
    re.compile(p, re.IGNORECASE)
    for p in (
        r"(?:can|could|would) you (?:please )?(?:repeat|say) (?:that|it|the question)(?: again)?(?: please)?",
        r"(?:can|could|would) you (?:please )?repeat(?: please)?",
        r"(?:please )?repeat (?:that|it|the question)(?: again)?(?: please)?",
        r"(?:say|ask) (?:that|it) (?:one more time|again)",
        r"one more time(?: please)?",
        r"come again",
        r"what was the question(?: again)?",
        r"(?:i )?(?:didn'?t|did not|couldn'?t|could not) (?:quite )?(?:catch|hear) (?:that|it|the question)",
        r"(?:i )?missed (?:that|the question)",
        r"what was that",
    )
)

_CLARIFY_PATTERNS: tuple[re.Pattern[str], ...] = tuple(
    re.compile(p, re.IGNORECASE)
    for p in (
        r"what do you mean(?: by (?:that|this|the question))?",
        r"(?:can|could|would) you (?:please )?clarify(?: that| this| the question)?(?: please)?",
        r"(?:can|could|would) you (?:please )?rephrase(?: that| this| the question)?(?: please)?",
        r"(?:can|could|would) you (?:please )?(?:be more specific|put (?:that|it) another way)",
        r"(?:i'?m|i am) not (?:quite )?sure what (?:you mean|you'?re asking|the question is)",
        r"(?:i )?(?:don'?t|do not) (?:quite )?(?:understand|follow) (?:the question|that|you)",
        r"what exactly are you asking",
        r"(?:in )?what sense",
    )
)


@dataclass(frozen=True)
class MetaUtterance:
    kind: MetaUtteranceKind
    #: The normalised utterance that matched. Short by construction (it is
    #: under `MAX_META_WORDS`), so it is safe to put in a telemetry span —
    #: unlike an answer transcript, which §8 does not allow to be logged.
    matched: str


def classify_meta_utterance(transcript: str) -> Optional[MetaUtterance]:
    """`MetaUtterance` when this turn is a request about the question rather
    than an attempt to answer it; `None` — the overwhelmingly common case —
    otherwise.

    `None` means "score this normally", so every ambiguous case must return
    `None`. There is no third outcome and no confidence score: a maybe here
    would just move the decision somewhere with less information.
    """
    normalised = _normalise(transcript)
    if not normalised:
        return None
    if len(normalised.split()) > MAX_META_WORDS:
        return None

    for pattern in _REPEAT_PATTERNS:
        if pattern.fullmatch(normalised):
            return MetaUtterance(kind="repeat", matched=normalised)
    for pattern in _CLARIFY_PATTERNS:
        if pattern.fullmatch(normalised):
            return MetaUtterance(kind="clarify", matched=normalised)
    return None


def _normalise(transcript: str) -> str:
    body = _WHITESPACE_RE.sub(" ", (transcript or "").strip())
    body = _LEADING_FILLER_RE.sub("", body)
    return _TRAILING_PUNCT_RE.sub("", body).strip()


def response_for(utterance: MetaUtterance, question_text: str) -> str:
    """What the interviewer says back.

    The question is restated VERBATIM in both branches. For `repeat` that is
    the entire point. For `clarify` it is the honest answer too: this path has
    no model call and no rubric, so it has nothing with which to explain what a
    question is "really" asking without inventing a reading of it — and a
    question the candidate then answers against an invented reading would be
    scored against the real one.

    Neither branch says anything about how the candidate is doing. They have
    not answered yet, so there is nothing to say (soul.md §"No fabrication").
    """
    if utterance.kind == "repeat":
        return f"Of course. {question_text}"
    return f"Of course — here it is again, and answer it however you read it. {question_text}"

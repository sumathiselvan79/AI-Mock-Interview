"""Callback facts — `HUMAN_INTERACTION_FLOW.md` §5.

`_CONTINUITY_WINDOW = 3` in `interview.py` is deliberately short: the trailing
window is re-sent to a provider on every turn, so its length is a per-turn
token cost paid for the rest of the session (§8, data minimisation). The
consequence is that by question eight the interview cannot refer to anything
from question two, and "earlier you mentioned the Kafka migration — does that
connect to this?" is not a sentence it can say.

This is the other half: a small, durable set of high-signal moments that
travels the whole session rather than rolling off. Distinct from the window in
every dimension that matters — far fewer entries, far shorter each, chosen
rather than taken in order, and kept until the session ends.

**Verbatim, never paraphrased.** A callback fact is a slice of what the
candidate actually said, which is what lets it be handed to the Question
Agent's grounding check as a source document (§11.3). A summarised fact would
be a claim about the candidate with nothing behind it — precisely what
soul.md §"No fabrication" is about — and it would fail the check anyway.
"""

from __future__ import annotations

import re
from typing import Optional

from app.interview_domain.signals import METRIC_RE

#: An answer scoring at or above this is worth being able to refer back to. The
#: number is the Eval Tool's, read not re-derived: this file has no rubric and
#: makes no judgement of its own, it only asks "was this one of the good ones?"
NOTABLE_SCORE = 4.0

#: One sentence. The Memory Agent enforces the same ceiling on the way in
#: (`MAX_CALLBACK_FACT_WORDS`); this trims first so the sentence chosen is a
#: whole thought rather than whatever survives a hard cut.
MAX_FACT_WORDS = 30

_SENTENCE_SPLIT_RE = re.compile(r"(?<=[.!?])\s+")


def callback_fact_from(transcript: str, score: Optional[float]) -> Optional[str]:
    """The one sentence of this answer worth carrying forward, or `None`.

    Two ways in, both cheap and both deterministic — no model call, because
    there is no judgement here to make that the Eval Tool has not already made:

     - the answer scored well, so whatever it described is worth being able to
       return to, or
     - the answer names a concrete measure. A quantified claim is the most
       referable thing a candidate says, and it is quotable by construction.

    Everything else returns `None`. The cap is small (five for a whole
    session), so being selective here is not an optimisation — it is what stops
    the fifth genuinely notable moment from being pushed out by the first
    unremarkable one.
    """
    body = (transcript or "").strip()
    if not body:
        return None

    is_notable = (score is not None and score >= NOTABLE_SCORE) or bool(METRIC_RE.search(body))
    if not is_notable:
        return None

    return _best_sentence(body)


def _best_sentence(body: str) -> Optional[str]:
    """The sentence naming a measure, else the first one.

    Preferring the quantified sentence is the difference between remembering
    "we migrated the billing service" and "the nightly report went from 4
    minutes to 8 seconds" — the second is what a later question can actually
    hinge on.
    """
    sentences = [s.strip() for s in _SENTENCE_SPLIT_RE.split(body) if s.strip()]
    if not sentences:
        return None
    chosen = next((s for s in sentences if METRIC_RE.search(s)), sentences[0])
    return _truncate_words(chosen, MAX_FACT_WORDS)


def _truncate_words(text: str, max_words: int) -> str:
    words = text.split()
    return " ".join(words) if len(words) <= max_words else " ".join(words[:max_words]) + "…"

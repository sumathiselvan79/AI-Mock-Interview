"""Session state machine — ~ agents/harness-agent/src/state-machine.ts. INSTRUCTIONS.md §3.

Pure functions only: no I/O, no store access, so the legal-transition rules
can be unit tested on their own and reused by any future harness transport.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from app.shared_types.session import SESSION_TRANSITIONS, TERMINAL_STATES, SessionState


def allowed_next_states(from_state: SessionState) -> list[SessionState]:
    """Every non-terminal state may be aborted (candidate leaves, unrecoverable error)."""
    if from_state in TERMINAL_STATES:
        return []
    return [*SESSION_TRANSITIONS.get(from_state, ()), "ABORTED"]  # type: ignore[list-item]


@dataclass
class TransitionCheck:
    allowed: bool
    reason: Optional[str] = None


def can_transition(from_state: SessionState, to_state: SessionState) -> TransitionCheck:
    if from_state == to_state:
        return TransitionCheck(False, f"already in {from_state}")
    if from_state in TERMINAL_STATES:
        return TransitionCheck(False, f"{from_state} is terminal")
    legal = allowed_next_states(from_state)
    if to_state not in legal:
        return TransitionCheck(
            False, f"illegal transition {from_state} -> {to_state}; legal: {', '.join(legal)}"
        )
    return TransitionCheck(True)


# Which agent owns the work done in a given state. The harness routes to this
# agent on entry; the agent returns a result and a "done" signal, and the
# harness — never the agent — decides the next state.
STATE_OWNER: dict[SessionState, str] = {
    "CREATED": "harness-agent",
    "CONFIG": "resume-service-agent",
    "TELEMETRY_CHECK": "harness-agent",
    "CALIBRATION": "question-agent",
    "QUESTION_LOOP": "question-agent",
    "CODING_ROUND": "coding-agent",
    "WRAP_UP": "harness-agent",
    "REPORT_GENERATION": "report-agent",
    "COMPLETED": "harness-agent",
    "ABORTED": "harness-agent",
}

_GATED: tuple[SessionState, ...] = (
    "CALIBRATION",
    "QUESTION_LOOP",
    "CODING_ROUND",
    "WRAP_UP",
    "REPORT_GENERATION",
)


def requires_telemetry_check(to_state: SessionState) -> bool:
    """Nothing downstream of TELEMETRY_CHECK may start until it passes (INSTRUCTIONS.md §3)."""
    return to_state in _GATED

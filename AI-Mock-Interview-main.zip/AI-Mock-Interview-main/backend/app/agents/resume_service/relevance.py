"""Topic relevance and JD fit — ~ agents/resume-service-agent/src/relevance.ts.

The one rule that governs this whole file (INSTRUCTIONS.md §4.2, soul.md
§"No fabrication"): every score must be traceable to specific parsed text.
So `evidence` is always a verbatim line from the resume — never a summary,
never an inference from a job title. If no line supports a topic, the topic
gets no relevance entry at all, and the Question Agent picks it up as a role
requirement instead if the role demands it.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from app.interview_domain import TOPICS, TopicDefinition, term_pattern
from app.shared_types import JdFit, TopicRelevance
from app.tools.resume_parser.parse import ExperienceEntry


def _matches_for(topic: TopicDefinition, lines: list[str]) -> list[tuple[str, list[str]]]:
    """Lines mentioning a topic's terms, with the terms that matched."""
    out: list[tuple[str, list[str]]] = []
    for line in lines:
        terms = [term for term in topic.terms if term_pattern(term).search(line)]
        if terms:
            out.append((line, terms))
    return out


def _score_for(distinct_terms: int, matched_lines: int) -> float:
    """Relevance rises with how many distinct terms appear and across how
    many lines, and saturates — a resume that says "Kubernetes" nine times is
    not three times as relevant as one that says it three times."""
    term_component = min(1, distinct_terms / 4) * 0.6
    spread_component = min(1, matched_lines / 3) * 0.4
    return round((term_component + spread_component) * 100) / 100


_INTRO_SENTENCE_SPLIT_RE = re.compile(r"(?<=[.!?])\s+")


def compute_intro_topic_relevance(intro_transcript: str) -> list[TopicRelevance]:
    """The deterministic fallback for `self_intro_v1` (self-intro addition,
    INSTRUCTIONS.md §4.3): the SAME regex term-matching `compute_topic_relevance`
    runs over resume lines, run instead over the intro transcript split into
    sentences, so a claim still traces to one quotable evidence span rather
    than the whole transcript."""
    sentences = [s.strip() for s in _INTRO_SENTENCE_SPLIT_RE.split(intro_transcript) if s.strip()]
    return compute_topic_relevance(sentences)


def merge_topic_relevance(resume: list[TopicRelevance], intro: list[TopicRelevance]) -> list[TopicRelevance]:
    """Unions resume-derived and intro-derived topic_relevance into the same
    structure the Question Agent's topic-plan builder already consumes
    (self-intro addition, §4.3) — a merge, not a second parallel plan. A
    topic present in both keeps whichever entry scores higher; the loser's
    evidence is dropped rather than blended into a claim neither source
    actually made on its own."""
    merged: dict[str, TopicRelevance] = {t.topic: t for t in resume}
    for entry in intro:
        current = merged.get(entry.topic)
        if current is None or entry.relevance_score > current.relevance_score:
            merged[entry.topic] = entry
    return sorted(merged.values(), key=lambda t: t.relevance_score, reverse=True)


def compute_topic_relevance(lines: list[str]) -> list[TopicRelevance]:
    out: list[TopicRelevance] = []

    for topic in TOPICS:
        matches = _matches_for(topic, lines)
        if not matches:
            continue

        distinct_terms = len({term for _line, terms in matches for term in terms})
        # The evidence line is the one that matched the most terms — the
        # strongest single piece of support, quoted exactly as it appears.
        best = max(matches, key=lambda m: len(m[1]))

        out.append(
            TopicRelevance(
                topic=topic.topic,
                relevance_score=_score_for(distinct_terms, len(matches)),
                evidence=best[0],
            )
        )

    out.sort(key=lambda t: t.relevance_score, reverse=True)
    return out


_LEADING_BULLET_RE = re.compile(r"^[\s•·▪◦*\-–]+")
_SENTENCE_SPLIT_RE = re.compile(r"\n|(?<=[.;])\s+(?=[A-Z])")
_REQUIREMENT_RE = re.compile(
    r"\b(?:experience|proficien\w*|familiar\w*|knowledge|expertise|must have|should have|require\w*|"
    r"responsible for|you will|ability to|strong|deep|background in|own\w*|build\w*|design\w*|"
    r"maintain\w*|lead\w*|mentor\w*|plus\b)",
    re.IGNORECASE,
)


def extract_requirements(job_description: str) -> list[str]:
    """Splits a job description into requirement-shaped statements: bullets,
    or sentences that read like a demand ("must have", "experience with", "you will")."""
    normalized = job_description.replace("\r\n", "\n").replace("\r", "\n")
    raw_lines = _SENTENCE_SPLIT_RE.split(normalized)
    lines = [
        stripped
        for raw in raw_lines
        if 12 <= len(stripped := _LEADING_BULLET_RE.sub("", raw).strip()) <= 300
    ]

    seen: set[str] = set()
    out: list[str] = []
    for line in lines:
        if not _REQUIREMENT_RE.search(line):
            continue
        for item in _atomic_requirements(line):
            key = item.lower()
            if key in seen:
                continue
            seen.add(key)
            out.append(item)
    return out


# "Requirements: a, b, c, and d." / "Nice to have: x, y." — a list
# introducer, then the list.
_LIST_INTRO_RE = re.compile(
    r"^(?P<intro>[^:]{0,60}?(?:requirements?|must[- ]haves?|nice[- ]to[- ]haves?|qualifications|you(?:'ll| will) need|"
    r"we(?:'re| are) looking for|skills|including|such as))\s*:?\s*(?P<rest>.+)$",
    re.IGNORECASE,
)


def _atomic_requirements(line: str) -> list[str]:
    """Splits one requirement sentence that is really a LIST of demands into
    its items (impl-correctness.md C4).

    A JD that writes "Requirements: strong Python or Go, PostgreSQL schema
    design, caching with Redis, message queues (Kafka or SQS), observability"
    was one requirement to the matcher, matched as soon as ANY of it was
    supported — so a resume with no SQS and no observability evidence still
    scored `fit_score: 1.0` with `gaps: []`. Each item is its own demand and
    is matched (or reported as a gap) on its own.

    Conservative on purpose: a sentence is split only when it carries an
    explicit list introducer or at least two top-level commas, and only on
    separators outside parentheses ("Kafka or SQS" stays one item). Anything
    else is returned whole, exactly as before.
    """
    text = line.strip().rstrip(".")
    match = _LIST_INTRO_RE.match(text)
    body = match.group("rest") if match else text
    parts = _split_top_level(body)
    if len(parts) < 3 and not (match and len(parts) >= 2):
        return [line]
    items = []
    for part in parts:
        part = re.sub(r"^(?:and|or)\s+", "", part.strip(), flags=re.IGNORECASE).strip(" .")
        if len(part) >= 3:
            items.append(part)
    return items if len(items) >= 2 else [line]


def _split_top_level(text: str) -> list[str]:
    parts: list[str] = []
    depth = 0
    current: list[str] = []
    for ch in text:
        if ch in "([":
            depth += 1
        elif ch in ")]" and depth:
            depth -= 1
        if ch in ",;" and depth == 0:
            parts.append("".join(current))
            current = []
            continue
        current.append(ch)
    parts.append("".join(current))
    return [p for p in (p.strip() for p in parts) if p]


def compute_jd_fit(job_description: str, lines: list[str], topic_relevance: list[TopicRelevance]) -> JdFit:
    """A requirement counts as matched when the resume shows evidence for a
    topic the requirement is about, or repeats the requirement's own
    distinctive terms. Everything else is a gap — and gaps become interview
    topics rather than disqualifications (soul.md §"JD-fit is informational,
    not a gate")."""
    requirements = extract_requirements(job_description)
    if not requirements:
        return JdFit(fit_score=0, matched_requirements=[], gaps=[])

    supported_topics = {t.topic for t in topic_relevance if t.relevance_score >= 0.3}
    resume_text = "\n".join(lines)

    matched: list[str] = []
    gaps: list[str] = []

    for requirement in requirements:
        topics_in_requirement = [
            topic for topic in TOPICS if any(term_pattern(term).search(requirement) for term in topic.terms)
        ]
        topic_supported = any(t.topic in supported_topics for t in topics_in_requirement)

        # Fall back to the requirement's own content words when it maps to no
        # known topic — a JD can ask for something the topic vocabulary doesn't cover.
        content_words = [w for w in re.split(r"[^a-z0-9+#.]+", requirement.lower()) if len(w) >= 5]
        word_support = bool(content_words) and (
            sum(1 for w in content_words if term_pattern(w).search(resume_text)) / len(content_words) >= 0.5
        )

        if topic_supported or word_support:
            matched.append(requirement)
        else:
            gaps.append(requirement)

    return JdFit(
        fit_score=round((len(matched) / len(requirements)) * 100) / 100,
        matched_requirements=matched,
        gaps=gaps,
    )


def gap_topics(gaps: list[str], topic_relevance: list[TopicRelevance]) -> list[str]:
    """The topics a JD demands that the resume gives no evidence for. These
    become `required_topics` for the topic plan (§4.3) — "a thin resume in a
    required area is a reason to ask about it, not to skip it"."""
    supported = {t.topic for t in topic_relevance if t.relevance_score >= 0.3}
    out: dict[str, None] = {}
    for gap in gaps:
        for topic in TOPICS:
            if topic.topic in supported:
                continue
            if any(term_pattern(term).search(gap) for term in topic.terms):
                out[topic.topic] = None
    return list(out.keys())


_SENIOR_TITLE_RE = re.compile(r"\b(staff|principal|distinguished|head of|vp of) engineer|architect\b", re.IGNORECASE)
_SENIOR_KEYWORDS_RE = re.compile(r"\b(senior|sr\.?|lead|manager)\b", re.IGNORECASE)


def estimate_seniority(experience: list[ExperienceEntry], lines: list[str]) -> str:
    text = " ".join(lines).lower()
    if _SENIOR_TITLE_RE.search(text):
        return "staff+"

    total_years = sum(e.years for e in experience)
    titles = " ".join(e.title.lower() for e in experience)

    if _SENIOR_KEYWORDS_RE.search(titles) or total_years >= 7:
        return "senior"
    if total_years >= 3:
        return "mid"
    return "junior"

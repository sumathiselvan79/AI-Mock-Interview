"""Resume Service Agent — ~ agents/resume-service-agent/src/index.ts. INSTRUCTIONS.md §4.2.

Parses the uploaded resume into a structured profile including which topics
the resume actually supports, verifies resume-vs-JD fit, and handles delete
requests from the Interview Config page.

Voice (soul.md §4): "precise and literal. Treats the resume as ground truth;
tailors question selection to it but never edits, embellishes, or infers
unstated claims." Concretely, this agent never writes a sentence about the
candidate — every `evidence` string it emits is a line lifted verbatim from
the parsed resume.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Any, Optional

from app.agents.resume_service.relevance import (
    compute_intro_topic_relevance,
    compute_jd_fit,
    compute_topic_relevance,
    estimate_seniority,
    gap_topics,
)
from app.interview_domain import TOPICS
from app.shared_types import CandidateProfile, JdFit, McpCallContext, McpHandlerError, TopicRelevance

SERVER_NAME = "resume-service-agent"
METHODS = ("parse_and_profile", "delete_resume", "parse_self_intro")


@dataclass
class ResumeServiceDeps:
    sessions: Any  # SessionStore
    tool_client: Any  # ToolClientFactory


@dataclass
class ProfileResult:
    profile: CandidateProfile
    topic_relevance: list[TopicRelevance]
    jd_fit: JdFit
    jd_gap_topics: list[str]
    resume_fingerprint: str


def _jd_fit_wire(jd_fit: JdFit) -> dict[str, Any]:
    """Wire shape of a `JdFit`, with the Stage 5 fields present only when generated."""
    out: dict[str, Any] = {
        "fit_score": jd_fit.fit_score,
        "matched_requirements": jd_fit.matched_requirements,
        "gaps": jd_fit.gaps,
    }
    if jd_fit.rationale is not None:
        out["rationale"] = jd_fit.rationale
    if jd_fit.topic_relevance is not None:
        out["topic_relevance"] = [
            {"topic": t.topic, "relevance_score": t.relevance_score, "evidence": t.evidence}
            for t in jd_fit.topic_relevance
        ]
    if jd_fit.prompt_version is not None:
        out["prompt_version"] = jd_fit.prompt_version
    if jd_fit.insufficient_signal:
        out["insufficient_signal"] = jd_fit.insufficient_signal
    if jd_fit.role_level is not None:
        out["role_level"] = jd_fit.role_level
    if jd_fit.key_technologies is not None:
        out["key_technologies"] = jd_fit.key_technologies
    return out


class ResumeServiceAgentServer:
    name = SERVER_NAME

    def __init__(self, deps: ResumeServiceDeps) -> None:
        self._deps = deps

    async def call(self, method: str, params: Any, ctx: McpCallContext) -> Any:
        if method == "parse_and_profile":
            result = await profile_session(self._deps, params)
            return {
                # Plain dict, not the pydantic model — the MCP Gateway
                # validates this response against a raw JSON Schema via
                # `jsonschema`, which needs a `dict`, not a `CandidateProfile`.
                "profile": result.profile.model_dump(),
                "topic_relevance": [
                    {"topic": t.topic, "relevance_score": t.relevance_score, "evidence": t.evidence}
                    for t in result.topic_relevance
                ],
                "jd_fit": _jd_fit_wire(result.jd_fit),
                "jd_gap_topics": result.jd_gap_topics,
                "resume_fingerprint": result.resume_fingerprint,
            }
        if method == "delete_resume":
            return {"deleted": await delete_resume(self._deps, params["session_id"])}
        if method == "parse_self_intro":
            topic_relevance = await parse_self_intro(self._deps, params)
            return {
                "topic_relevance": [
                    {"topic": t.topic, "relevance_score": t.relevance_score, "evidence": t.evidence}
                    for t in topic_relevance
                ]
            }
        raise McpHandlerError("unknown_method", f"{SERVER_NAME} has no method {method}")


async def profile_session(deps: ResumeServiceDeps, input_: dict[str, Any]) -> ProfileResult:
    session_id = input_["session_id"]
    file_ref = input_["file_ref"]
    role = input_["role"]
    job_description: Optional[str] = input_.get("job_description")
    jd_fit_draft: Optional[dict[str, Any]] = input_.get("jd_fit_draft")

    tools = deps.tool_client(session_id, SERVER_NAME)

    # Parse errors (unsupported_format, parse_failed) propagate untouched —
    # the candidate is told plainly what went wrong rather than handed a
    # guessed profile (soul.md §6).
    parsed = await tools.call(
        "tool-resume-parser",
        "parse_resume",
        {"session_id": session_id, "file_ref": file_ref, **({"job_description": job_description} if job_description else {})},
    )

    topic_relevance = compute_topic_relevance(parsed["lines"])
    resume_fingerprint = fingerprint_resume(parsed["lines"], job_description or "")

    # The deterministic path runs FIRST and always. The LLM layers judgement
    # on top of the parser's structured output, never replaces it (§4.2) — so
    # a provider outage costs the explanation, not the JD-fit check.
    base_jd_fit = (
        compute_jd_fit(job_description, parsed["lines"], topic_relevance)
        if job_description
        else JdFit(fit_score=0, matched_requirements=[], gaps=[])
    )

    jd_fit = (
        await _enrich_jd_fit(
            tools,
            session_id=session_id,
            role=role,
            job_description=job_description,
            resume_lines=parsed["lines"],
            base_jd_fit=base_jd_fit,
            draft=jd_fit_draft,
        )
        if job_description
        else base_jd_fit
    )

    experience_entries = [_as_exp(e) for e in parsed["experience"]]
    profile = CandidateProfile(
        skills=parsed["skills"],
        experience=parsed["experience"],
        education=parsed["education"],
        seniority_estimate=estimate_seniority(experience_entries, parsed["lines"]),
        keywords=parsed["keywords"],
        topic_relevance=topic_relevance,
    )

    jd_gap = gap_topics(jd_fit.gaps, topic_relevance)
    await deps.sessions.patch(session_id, {"candidate_profile": profile, "jd_fit": jd_fit, "jd_gap_topics": jd_gap})

    return ProfileResult(
        profile=profile,
        topic_relevance=topic_relevance,
        jd_fit=jd_fit,
        jd_gap_topics=jd_gap,
        resume_fingerprint=resume_fingerprint,
    )


# The JD-fit fields only the LLM call produces. Everything else in a `JdFit`
# comes from the deterministic matcher and survives a provider failure.
_JD_FIT_GENERATED_FIELDS = ("rationale", "topic_relevance")


def _as_exp(e: dict[str, Any]):
    from app.tools.resume_parser.parse import ExperienceEntry

    return ExperienceEntry(title=e["title"], company=e["company"], years=e["years"])


async def _enrich_jd_fit(
    tools: Any,
    *,
    session_id: str,
    role: str,
    job_description: str,
    resume_lines: list[str],
    base_jd_fit: JdFit,
    draft: Optional[dict[str, Any]],
) -> JdFit:
    """(Stage 5/F10, §4.2) Adds `rationale`, the JD-anchored `topic_relevance`,
    and `role_level`/`key_technologies` to a jd_fit the deterministic path
    already computed. The two enrichment calls run independently — one
    failing must not cost the other. Every failure mode ends with the
    deterministic fields shipped untouched (soul.md §"JD-fit is
    informational, not a gate")."""
    # A draft for this exact resume was already generated once this session;
    # the candidate replacing a resume with the same content should not cost
    # a second provider round trip (§4.7).
    #
    # `model_validate` rather than `model_copy(update=...)`: the draft was
    # round-tripped through the MCP JSON boundary and memory storage, so its
    # nested fields (`topic_relevance`) arrive as plain dicts, not
    # `TopicRelevance` instances. `model_copy` sets fields directly without
    # coercing them, which leaves those dicts sitting inside a model whose
    # declared type says otherwise — harmless until something downstream
    # tries to serialize the model and expects a `TopicRelevance` attribute
    # access. `model_validate` re-parses the merged data properly.
    if draft:
        return JdFit.model_validate({**base_jd_fit.model_dump(), **draft})

    import asyncio

    fit_patch, requirements_patch = await asyncio.gather(
        _generate_jd_fit_patch(tools, session_id=session_id, role=role, job_description=job_description, resume_lines=resume_lines, base_jd_fit=base_jd_fit),
        _generate_jd_requirements_patch(tools, session_id=session_id, role=role, job_description=job_description),
    )
    return base_jd_fit.model_copy(update={**fit_patch, **requirements_patch})


async def _generate_jd_fit_patch(
    tools: Any, *, session_id: str, role: str, job_description: str, resume_lines: list[str], base_jd_fit: JdFit
) -> dict[str, Any]:
    """The `rationale` + JD-anchored `topic_relevance` half of the enrichment (§4.2)."""
    from app.llm_client.tools import JD_FIT_TOOL

    try:
        generated = await tools.call(
            "tool-llm-provider",
            "generate_structured",
            {
                "session_id": session_id,
                "tool_name": JD_FIT_TOOL["name"],
                "prompt_version": JD_FIT_TOOL["prompt_version"],
                "schema_ref": JD_FIT_TOOL["schema_ref"],
                "input": {
                    "role": role,
                    "job_description": job_description,
                    "resume_lines": resume_lines,
                    "matched_requirements": base_jd_fit.matched_requirements,
                    "gaps": base_jd_fit.gaps,
                    "candidate_topics": [t.topic for t in TOPICS],
                },
                # `rationale` must cite the resume or the JD; `topic_relevance`
                # evidence must trace to the JD specifically (§4.2).
                "source_documents": [job_description, "\n".join(resume_lines)],
            },
        )
    except Exception:  # noqa: BLE001 - provider_unavailable / schema_validation_failed
        # (C4) Distinguishable, not silent: the deterministic fields ship, and
        # the two generated ones are reported as having no signal rather than
        # simply missing. `prompt_version` stays absent, which is the wire
        # contract's own marker for "the LLM did not produce this". The
        # structured log line for the failure is written by `structured_call`.
        return {"insufficient_signal": list(_JD_FIT_GENERATED_FIELDS)}

    output = generated.get("output") if isinstance(generated, dict) else None
    if not output:
        return {"insufficient_signal": list(_JD_FIT_GENERATED_FIELDS)}

    patch: dict[str, Any] = {}
    rationale = output.get("rationale") or {}
    if isinstance(rationale.get("value"), str):
        patch["rationale"] = rationale["value"]
    patch["topic_relevance"] = [
        TopicRelevance(topic=t["topic"], relevance_score=t["relevance_score"], evidence=t["evidence"])
        for t in output.get("topic_relevance", [])
    ]
    patch["prompt_version"] = generated.get("prompt_version")
    insufficient = generated.get("insufficient_signal") or []
    if insufficient:
        patch["insufficient_signal"] = insufficient
    return patch


async def _generate_jd_requirements_patch(
    tools: Any, *, session_id: str, role: str, job_description: str
) -> dict[str, Any]:
    """(LLM-powered JD parser addition, F10.) The `role_level` +
    `key_technologies` half of the enrichment — structural extraction from
    the JD, not a claim about the candidate, so no grounding check applies."""
    from app.llm_client.tools import JD_REQUIREMENTS_TOOL

    try:
        generated = await tools.call(
            "tool-llm-provider",
            "generate_structured",
            {
                "session_id": session_id,
                "tool_name": JD_REQUIREMENTS_TOOL["name"],
                "prompt_version": JD_REQUIREMENTS_TOOL["prompt_version"],
                "schema_ref": JD_REQUIREMENTS_TOOL["schema_ref"],
                "input": {"role": role, "job_description": job_description},
                "source_documents": [job_description],
            },
        )
    except Exception:  # noqa: BLE001
        return {}

    output = generated.get("output") if isinstance(generated, dict) else None
    if not output:
        return {}

    return {"role_level": output.get("role_level"), "key_technologies": output.get("key_technologies")}


def fingerprint_resume(lines: list[str], job_description: str) -> str:
    """Identifies the parsed resume (and the JD it was scored against) so a
    cached jd_fit draft can never be reused for different content (§4.7)."""
    digest = hashlib.sha256()
    digest.update("\n".join(lines).encode("utf-8"))
    digest.update(b" ")
    digest.update(job_description.encode("utf-8"))
    return digest.hexdigest()[:32]


async def delete_resume(deps: ResumeServiceDeps, session_id: str) -> bool:
    """Hard-deletes the stored file and drops the session's reference to it.
    The structured profile survives, so an interview already in progress
    keeps working without the raw document being retained (§8)."""
    session = await deps.sessions.get(session_id)
    if not session or not session.resume_ref:
        return False

    tools = deps.tool_client(session_id, SERVER_NAME)
    result = await tools.call("tool-resume-parser", "delete_resume", {"file_ref": session.resume_ref})

    if not result["verified_absent"]:
        raise McpHandlerError(
            "delete_failed", "the stored resume file is still present after deletion; refusing to report it deleted"
        )

    await deps.sessions.patch(session_id, {"resume_ref": None})
    return result["deleted"]


async def parse_self_intro(deps: ResumeServiceDeps, input_: dict[str, Any]) -> list[TopicRelevance]:
    """(self-intro addition, §4.3) The extraction only — never fuses with the
    resume-derived topic_relevance and never touches the topic plan. The
    Harness owns the union + replan step (§4.3's "fuse before planning"),
    same separation of concerns as the resume/JD split already has: this
    agent produces topic_relevance, the Question Agent turns it into a plan."""
    session_id = input_["session_id"]
    role = input_.get("role", "")
    intro_transcript = input_["intro_transcript"]

    generated = await _generate_intro_topic_relevance(
        deps, session_id=session_id, role=role, intro_transcript=intro_transcript
    )
    return generated if generated is not None else compute_intro_topic_relevance(intro_transcript)


async def _generate_intro_topic_relevance(
    deps: ResumeServiceDeps, *, session_id: str, role: str, intro_transcript: str
) -> Optional[list[TopicRelevance]]:
    """The LLM enrichment on top of the deterministic term-matching pass.
    Every failure mode (provider unavailable, schema invalid, everything
    grounding-stripped) falls through to the deterministic path — same
    "runs first and always" contract as the resume/JD extractions (§11.5)."""
    from app.llm_client.tools import SELF_INTRO_TOOL

    tools = deps.tool_client(session_id, SERVER_NAME)
    try:
        generated = await tools.call(
            "tool-llm-provider",
            "generate_structured",
            {
                "session_id": session_id,
                "tool_name": SELF_INTRO_TOOL["name"],
                "prompt_version": SELF_INTRO_TOOL["prompt_version"],
                "schema_ref": SELF_INTRO_TOOL["schema_ref"],
                "input": {"role": role, "candidate_topics": [t.topic for t in TOPICS], "intro_transcript": intro_transcript},
                # `topic_relevance[].evidence` must be a verbatim slice of the
                # intro transcript specifically — nothing else is a valid source here.
                "source_documents": [intro_transcript],
            },
        )
    except Exception:  # noqa: BLE001 - provider_unavailable / schema_validation_failed
        return None

    output = generated.get("output") if isinstance(generated, dict) else None
    if not output:
        return None

    return [
        TopicRelevance(topic=t["topic"], relevance_score=t["relevance_score"], evidence=t["evidence"])
        for t in output.get("topic_relevance", [])
    ]


def create_resume_service_agent_server(deps: ResumeServiceDeps) -> ResumeServiceAgentServer:
    return ResumeServiceAgentServer(deps)

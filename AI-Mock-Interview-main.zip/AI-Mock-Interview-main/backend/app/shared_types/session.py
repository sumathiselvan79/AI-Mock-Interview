"""Session lifecycle types — ~ packages/shared-types/src/session.ts.

The state machine itself is specified in INSTRUCTIONS.md §3 and enforced by
the Harness Agent — no other component may write `Session.state`.
"""

from __future__ import annotations

from typing import Literal, Optional

from .base import CamelModel
from .interview import CandidateProfile, ExtractionProcessorResult, NextActionGenerator, TopicRelevance

SESSION_STATES: tuple[str, ...] = (
    "CREATED",
    "CONFIG",
    "TELEMETRY_CHECK",
    "CALIBRATION",
    "QUESTION_LOOP",
    "CODING_ROUND",
    "WRAP_UP",
    "REPORT_GENERATION",
    "COMPLETED",
    "ABORTED",
)

SessionState = Literal[
    "CREATED",
    "CONFIG",
    "TELEMETRY_CHECK",
    "CALIBRATION",
    "QUESTION_LOOP",
    "CODING_ROUND",
    "WRAP_UP",
    "REPORT_GENERATION",
    "COMPLETED",
    "ABORTED",
]

TERMINAL_STATES: tuple[SessionState, ...] = ("COMPLETED", "ABORTED")

# `CODING_ROUND` is optional and skipped for non-technical roles — decided
# during CALIBRATION — hence QUESTION_LOOP may go straight to WRAP_UP. Every
# non-terminal state may additionally transition to ABORTED; that edge is
# added at runtime (see is_legal_transition) rather than duplicated here.
SESSION_TRANSITIONS: dict[SessionState, tuple[SessionState, ...]] = {
    "CREATED": ("CONFIG",),
    "CONFIG": ("TELEMETRY_CHECK",),
    "TELEMETRY_CHECK": ("CALIBRATION",),
    "CALIBRATION": ("QUESTION_LOOP",),
    "QUESTION_LOOP": ("CODING_ROUND", "WRAP_UP"),
    "CODING_ROUND": ("WRAP_UP",),
    "WRAP_UP": ("REPORT_GENERATION",),
    "REPORT_GENERATION": ("COMPLETED",),
    "COMPLETED": (),
    "ABORTED": (),
}


def is_legal_transition(from_state: SessionState, to_state: SessionState) -> bool:
    if from_state in TERMINAL_STATES:
        return False
    if to_state == "ABORTED":
        return True
    return to_state in SESSION_TRANSITIONS.get(from_state, ())


class SessionConsent(CamelModel):
    telemetry: bool = False
    clipboard_monitor: bool = False
    audio_recording: bool = False
    cross_session_memory: bool = False
    focus_loss_monitoring: bool = False


DEFAULT_CONSENT = SessionConsent()


class FocusEvent(CamelModel):
    timestamp: str


MAX_FOCUS_EXITS = 3


RoleLevel = Literal["junior", "mid", "senior", "lead", "staff+"]


class JdFit(CamelModel):
    fit_score: float
    matched_requirements: list[str] = []
    gaps: list[str] = []

    rationale: Optional[str] = None
    topic_relevance: Optional[list[TopicRelevance]] = None
    prompt_version: Optional[str] = None
    insufficient_signal: Optional[list[str]] = None

    role_level: Optional[RoleLevel] = None
    key_technologies: Optional[list[str]] = None


TopicSource = Literal["resume", "role_requirement", "jd_gap", "introduction"]


class TopicPlanEntry(CamelModel):
    topic: str
    max_questions: int
    source: TopicSource


TOPIC_QUESTION_FLOOR = 1
TOPIC_QUESTION_CEILING = 3
DEFAULT_QUESTION_BUDGET = 8

MIN_QUESTION_BUDGET = 1
MAX_QUESTION_BUDGET = 20


def is_valid_question_budget(value: object) -> bool:
    return (
        isinstance(value, int)
        and not isinstance(value, bool)
        and MIN_QUESTION_BUDGET <= value <= MAX_QUESTION_BUDGET
    )


class Session(CamelModel):
    id: str
    candidate_id: str
    role: str
    job_description: str
    jd_fit: Optional[JdFit] = None
    state: SessionState
    consent: SessionConsent
    question_budget: int = DEFAULT_QUESTION_BUDGET
    topic_plan: list[TopicPlanEntry] = []
    resume_ref: Optional[str] = None
    candidate_profile: Optional[CandidateProfile] = None
    jd_gap_topics: list[str] = []
    jd_fit_fingerprint: Optional[str] = None
    focus_events: list[FocusEvent] = []
    created_at: str
    updated_at: str


class SessionStateTransition(CamelModel):
    id: str
    session_id: str
    from_state: SessionState
    to_state: SessionState
    actor: str = "harness-agent"
    reason: str = ""
    at: str


class StateWriteGrant:
    """Capability object required to write `Session.state`.

    Only `app.agents.harness` constructs one of these, and `SessionStore`
    implementations check identity (not just type) at runtime — so a stray
    agent or route handler cannot mutate session state even if it holds a
    reference to the store. `token` is a fresh, unforgeable sentinel per
    instance — the same role the TS version's `symbol` plays — so a forged
    object with the right `actor` string still fails an identity check.
    """

    actor: Literal["harness-agent"] = "harness-agent"

    def __init__(self) -> None:
        self.token = object()


class SessionMetrics(CamelModel):
    elapsed_time_seconds: float
    topic_competency_score: float
    current_demonstrated_tier: int


class ContextEngine(CamelModel):
    active_resume_anchor: str
    last_delivered_prompt: str


class LiveSessionState(CamelModel):
    """(Stage 6, §12.6) A read-only, ephemeral SNAPSHOT of one just-answered turn."""

    session_id: str
    candidate_id: str
    active_topic_id: str
    session_metrics: SessionMetrics
    context_engine: ContextEngine
    extraction_processor: ExtractionProcessorResult
    next_action_generator: NextActionGenerator

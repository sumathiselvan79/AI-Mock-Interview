"""Base model for every wire type — ~ packages/shared-types.

Every JSON payload in this system (REST, WebSocket, MCP call params/results)
is camelCase on the wire, because `apps/web` (unchanged by this migration,
per FASTAPI_MIGRATION.md) is a TypeScript client that was never touched.
`CamelModel` makes every subclass accept AND emit camelCase by default while
still letting Python code use snake_case attribute names.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict
from pydantic.alias_generators import to_camel


class CamelModel(BaseModel):
    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
        from_attributes=True,
    )

"""Storage ports — ~ packages/shared-types/src/ports.ts.

Defined here so agents can depend on the *shape* of a store without depending
on the gateway that implements it (Postgres/Redis/disk in production,
in-memory in tests). Python `Protocol` classes are the structural-typing
equivalent of the TS interfaces they mirror.
"""

from __future__ import annotations

from typing import Any, Optional, Protocol

from .interview import Answer, CandidateProfile, Evaluation, FollowUpScore, Question
from .report import Report
from .scheduling import ScheduledInterview
from .session import Session, SessionState, SessionStateTransition, StateWriteGrant
from .telemetry import TelemetryEvent, TelemetryEventType, TelemetryPayload


class SessionStore(Protocol):
    async def create(
        self, *, candidate_id: str, role: str, job_description: str, question_budget: Optional[int] = None
    ) -> Session: ...

    async def get(self, session_id: str) -> Optional[Session]: ...

    async def list_by_candidate(self, candidate_id: str) -> list[Session]: ...

    async def set_state(
        self, session_id: str, to_state: SessionState, grant: StateWriteGrant, reason: str
    ) -> Session:
        """The ONLY path that writes `Session.state`. Requires a grant that only
        the Harness Agent can construct (INSTRUCTIONS.md §3)."""
        ...

    def register_state_writer(self, grant: StateWriteGrant) -> None:
        """Called once at wiring time with the harness's grant; a second call raises."""
        ...

    async def transitions(self, session_id: str) -> list[SessionStateTransition]: ...

    async def patch(self, session_id: str, patch: dict[str, Any]) -> Session:
        """Non-state session fields may be written by their owning agent."""
        ...

    async def append_focus_event(self, session_id: str, timestamp: str) -> dict[str, int]:
        """Atomically appends one fullscreen-exit event and returns {"exit_count": n}."""
        ...

    async def counts_by_candidate(self) -> dict[str, int]: ...


class SessionScratchStore(Protocol):
    """(Stage 5) Ephemeral, session-scoped key/value working memory — the Memory
    Agent's store for data §4.7 says must NOT get a durable table."""

    async def set_session_scratch(self, session_id: str, key: str, value: Any) -> None: ...
    async def get_session_scratch(self, session_id: str, key: str) -> Any: ...
    async def clear_session_scratch(self, session_id: str) -> None: ...


class TelemetrySink(Protocol):
    async def emit(
        self, event_type: TelemetryEventType, session_id: Optional[str], payload: TelemetryPayload
    ) -> TelemetryEvent: ...

    async def recent(self, limit: int = 50) -> list[TelemetryEvent]: ...


class StoredFileMeta(Protocol):
    ref: str
    session_id: str
    filename: str
    content_type: str
    size_bytes: int
    uploaded_at: str


class FileStore(Protocol):
    async def put(
        self, *, session_id: str, filename: str, content_type: str, data: bytes
    ) -> Any: ...

    async def get(self, ref: str) -> Optional[tuple[Any, bytes]]: ...
    async def stat(self, ref: str) -> Optional[Any]: ...
    async def exists(self, ref: str) -> bool: ...
    async def delete(self, ref: str) -> bool: ...
    async def list_by_session(self, session_id: str) -> list[Any]: ...


class QuestionStore(Protocol):
    async def append(self, question: Question) -> Question: ...
    async def get(self, question_id: str) -> Optional[Question]: ...
    async def list_by_session(self, session_id: str) -> list[Question]: ...


class AnswerStore(Protocol):
    async def append(self, answer: Answer) -> Answer: ...
    async def get(self, answer_id: str) -> Optional[Answer]: ...
    async def get_by_question(self, question_id: str) -> Optional[Answer]: ...
    async def append_follow_up(self, answer_id: str, follow_up: dict[str, str]) -> Answer: ...
    async def score_follow_up(self, answer_id: str, index: int, score: FollowUpScore) -> Answer: ...
    async def record_extraction(self, answer_id: str, extraction: Any, next_action: Any) -> Answer: ...
    async def redact(self, answer_id: str) -> Answer: ...


class EvaluationStore(Protocol):
    async def append(self, evaluation: Evaluation) -> Evaluation: ...
    async def list_by_answer(self, answer_id: str) -> list[Evaluation]: ...
    async def list_by_session(self, session_id: str) -> list[Evaluation]: ...


class CandidateReportAggregate(Protocol):
    candidate_id: str
    interviews_completed: int
    average_score: Optional[float]
    last_interview_at: Optional[str]


class ReportStore(Protocol):
    async def create(self, report: Report) -> Report: ...
    async def get_by_session(self, session_id: str) -> Optional[Report]: ...
    async def list_by_candidate(self, candidate_id: str) -> list[Report]: ...
    async def list_all(self) -> list[Report]: ...
    async def aggregate_by_candidate(self) -> list[Any]: ...


class ScheduledInterviewStore(Protocol):
    async def create_many(self, rows: list[ScheduledInterview]) -> list[ScheduledInterview]: ...
    async def get(self, schedule_id: str) -> Optional[ScheduledInterview]: ...
    async def list(self) -> list[ScheduledInterview]: ...
    async def list_by_candidate(self, candidate_id: str) -> list[ScheduledInterview]: ...
    async def candidates_with_open_schedules(self) -> list[str]: ...
    async def update(self, schedule_id: str, patch: dict[str, Any]) -> Optional[ScheduledInterview]: ...


__all__ = [
    "SessionStore",
    "SessionScratchStore",
    "TelemetrySink",
    "StoredFileMeta",
    "FileStore",
    "QuestionStore",
    "AnswerStore",
    "EvaluationStore",
    "ReportStore",
    "CandidateReportAggregate",
    "ScheduledInterviewStore",
    "CandidateProfile",
]

"""Session archive types — ~ packages/shared-types/src/archive.ts, INSTRUCTIONS.md §6, §11.4.

One document per completed session, written to a SEPARATE Supabase-hosted
Postgres instance for Admin export. It is a copy, never a second source of
truth: nothing reads back from it into the interview.

The ordering constraint is not negotiable: the archive is compiled strictly
AFTER the Stage 4 retention/redaction job runs, so it can never contain more
than the primary record does at the moment it is built (soul.md §5).
"""

from __future__ import annotations

from typing import Optional, Protocol

from .base import CamelModel
from .interview import Answer, Evaluation, Question
from .report import Report
from .session import Session, TopicPlanEntry


class SessionArchiveDocument(CamelModel):
    session: Session
    topic_plan: list[TopicPlanEntry]
    questions: list[Question]
    answers: list[Answer]
    evaluations: list[Evaluation]
    report: Report


class SessionArchive(CamelModel):
    session_id: str
    candidate_id: str
    candidate_name: str
    department: Optional[str] = None
    program_year: Optional[str] = None
    archived_at: str
    document: SessionArchiveDocument


class SessionArchiveSummary(CamelModel):
    session_id: str
    candidate_id: str
    candidate_name: str
    department: Optional[str] = None
    program_year: Optional[str] = None
    archived_at: str


class SessionArchiveStore(Protocol):
    async def upsert(self, archive: SessionArchive) -> SessionArchive: ...
    async def get(self, session_id: str) -> Optional[SessionArchive]: ...
    async def summary(self, session_id: str) -> Optional[SessionArchiveSummary]: ...
    async def list(self) -> list[SessionArchiveSummary]: ...
    async def close(self) -> None: ...


class ArchiveRefused(Exception):
    """Raised when §11.4 step 2's hard stop applies: no candidate name, no archive."""

    code = "archive_refused"

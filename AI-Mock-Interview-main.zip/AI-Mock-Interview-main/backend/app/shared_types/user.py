"""User + auth types — ~ packages/shared-types/src/user.ts.

A passcode is NEVER represented in these types as plaintext. The only on-disk
representation is `User.passcode_hash`, produced by `app.auth.passcode`.
"""

from __future__ import annotations

from typing import Literal, Optional

from .base import CamelModel

Role = Literal["admin", "student"]


class User(CamelModel):
    id: str
    email: str
    role: Role
    passcode_hash: str
    cross_session_memory_opt_in: bool = False
    full_name: Optional[str] = None
    department: Optional[str] = None
    program_year: Optional[str] = None
    created_at: str


class PublicUser(CamelModel):
    """What a caller sees once authenticated. Deliberately has no hash field."""

    id: str
    email: str
    role: Role
    cross_session_memory_opt_in: bool
    full_name: Optional[str] = None
    department: Optional[str] = None
    program_year: Optional[str] = None


class UserProfile(CamelModel):
    """(Stage 5) The profile fields a candidate can set on themselves (§11.4)."""

    full_name: Optional[str] = None
    department: Optional[str] = None
    program_year: Optional[str] = None


class AuthTokenClaims(CamelModel):
    sub: str
    email: str
    role: Role
    iat: int
    exp: int


class PasscodeResetToken(CamelModel):
    id: str
    user_id: str
    token_hash: str
    expires_at: str
    used_at: Optional[str] = None


def to_public_user(user: User) -> PublicUser:
    return PublicUser(
        id=user.id,
        email=user.email,
        role=user.role,
        cross_session_memory_opt_in=user.cross_session_memory_opt_in,
        full_name=user.full_name or None,
        department=user.department or None,
        program_year=user.program_year or None,
    )

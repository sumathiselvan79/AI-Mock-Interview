"""Shapes for traffic crossing the MCP Gateway — ~ packages/shared-types/src/mcp.ts.

CLAUDE.md §5, INSTRUCTIONS.md §2. The gateway is the single choke point for
auth, per-session rate limiting and the auto-emitted `tool_called` span, so
every call carries a session-scoped context rather than an ambient one.
"""

from __future__ import annotations

from typing import Any, Awaitable, Callable, Literal, Optional, Protocol, TypeVar

from .base import CamelModel

# Registered MCP server names. One name = one deployable service (in-process
# handler today — see FASTAPI_MIGRATION.md's architectural decision).
MCP_AGENT_SERVERS: tuple[str, ...] = (
    "resume-service-agent",
    "question-agent",
    "followup-agent",
    "coding-agent",
    "time-tracking-agent",
    "memory-agent",
    "report-agent",
)

MCP_TOOL_SERVERS: tuple[str, ...] = (
    "tool-resume-parser",
    "tool-eval",
    "tool-time-tracking",
    "tool-telemetry",
    "tool-clipboard-monitor",
    "tool-speech-service",
    "tool-focus-monitor",
    "tool-llm-provider",
)

McpServerName = str


class McpCallContext(CamelModel):
    session_id: str
    caller: str
    session_token: str


T = TypeVar("T")


class McpError(CamelModel):
    code: str
    message: str


class McpCallResult(CamelModel):
    ok: bool
    data: Optional[Any] = None
    error: Optional[McpError] = None
    latency_ms: float


MCP_ERROR_CODES = {
    "UNAUTHORIZED": "unauthorized",
    "RATE_LIMITED": "rate_limited",
    "UNKNOWN_SERVER": "unknown_server",
    "UNKNOWN_METHOD": "unknown_method",
    "SCHEMA_INVALID_REQUEST": "schema_invalid_request",
    "SCHEMA_INVALID_RESPONSE": "schema_invalid_response",
    "NOT_IMPLEMENTED": "not_implemented",
    "UPSTREAM_ERROR": "upstream_error",
}

McpErrorCode = Literal[
    "unauthorized",
    "rate_limited",
    "unknown_server",
    "unknown_method",
    "schema_invalid_request",
    "schema_invalid_response",
    "not_implemented",
    "upstream_error",
]


class McpHandlerError(Exception):
    """Thrown by a server to return a typed MCP error rather than an opaque crash."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


class McpServerHandler(Protocol):
    """The seam every MCP server is reached through.

    Stage 1 (TS) registered in-process handlers so the gateway's
    auth/rate-limit/schema/telemetry path could be proven before any real
    agent existed; the Python port keeps the same shape for the same reason —
    swapping the transport for the official MCP SDK later touches nothing
    that calls through this interface.
    """

    name: str

    async def call(self, method: str, params: Any, ctx: McpCallContext) -> Any: ...


class ToolClient(Protocol):
    async def call(self, server: str, method: str, params: Any) -> Any: ...


ToolClientFactory = Callable[[str, str], ToolClient]

"""Consent tokens — ~ packages/shared-types/src/consent.ts.

soul.md §"Consent-first monitoring", INSTRUCTIONS.md §5.5, §8.

A consent token is a signed statement that *this* session's candidate agreed
to *this specific* kind of monitoring, at a known time. It exists so consent
is enforceable at the tool layer rather than only in the UI.

Design notes worth keeping:
 - one token per scope, so agreeing to telemetry never implies agreeing to
   clipboard monitoring;
 - the token is bound to a session id, so it cannot be replayed against
   another candidate's session;
 - it carries no personal data at all, only ids, a scope and a timestamp.
"""

from __future__ import annotations

from typing import Literal, Union

from .base import CamelModel

CONSENT_SCOPES: tuple[str, ...] = (
    "telemetry",
    "clipboard_monitor",
    "audio_recording",
    "cross_session_memory",
    "focus_monitoring",
)

ConsentScope = Literal[
    "telemetry",
    "clipboard_monitor",
    "audio_recording",
    "cross_session_memory",
    "focus_monitoring",
]


class ConsentClaims(CamelModel):
    session_id: str
    scope: ConsentScope
    granted_at: int  # epoch seconds


class ConsentGrant(CamelModel):
    scope: ConsentScope
    token: str


class ConsentVerdictOk(CamelModel):
    ok: Literal[True] = True
    claims: ConsentClaims


class ConsentVerdictFail(CamelModel):
    ok: Literal[False] = False
    reason: Literal["missing", "malformed", "bad_signature", "wrong_session", "wrong_scope"]


ConsentVerdict = Union[ConsentVerdictOk, ConsentVerdictFail]

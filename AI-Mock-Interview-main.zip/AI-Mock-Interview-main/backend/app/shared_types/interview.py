"""Interview content types — ~ packages/shared-types/src/interview.ts, INSTRUCTIONS.md §6."""

from __future__ import annotations

from typing import Literal, Optional

from .base import CamelModel

Tier = Literal[1, 2, 3]


class TierSpec(CamelModel):
    tier: Tier
    target_concept_ids: list[str]
    escalation_trigger_condition: Optional[str] = None


class DynamicFraming(CamelModel):
    resume_context_integration_rule: str
    jd_anchor_requirement: str


class ExtractionMatrix(CamelModel):
    tier_1_baseline: TierSpec
    tier_2_intermediate: TierSpec
    tier_3_advanced: TierSpec


class EvaluationTopicBlueprint(CamelModel):
    topic_id: str
    dynamic_framing: DynamicFraming
    extraction_matrix: ExtractionMatrix


class SystemBlueprint(CamelModel):
    """A role's static evaluation plan. Built once per role, not per session."""

    role_profile_id: str
    domain_focus: str
    evaluation_topics: list[EvaluationTopicBlueprint]


# (Human-interaction addition) `support` is the struggle detector's directive
# — see `HUMAN_INTERACTION_FLOW.md` §2. It is a sibling of `drill_down`, not a
# replacement: `drill_down` probes a capable candidate for depth, `support`
# reframes for one who is stuck. It changes the FRAMING of the next question
# on the same topic, never the bar it is scored against.
NextActionDirective = Literal["escalate", "pivot", "drill_down", "support", "conclude"]

# escalate/drill_down stay on the same topic, pivot moves to another one,
# support stays on the topic but asks for an easier way in, and conclude
# (Harness-only) has no next question to frame. Derived from
# `system_directive` by `app.interview_domain.transitions.transition_style_for`.
TransitionStyle = Literal["same_topic", "topic_shift", "supportive_reframe", "none"]


class ExtractionProcessorResult(CamelModel):
    """What the concept-verification pass found in one answer's transcript."""

    transcribed_input_chunk: Optional[str] = None
    verified_concept_ids: list[str] = []
    unverified_concept_ids: list[str] = []
    anti_patterns_detected: list[str] = []


class NextActionGenerator(CamelModel):
    system_directive: NextActionDirective
    transition_style: TransitionStyle
    target_concept_id_for_next_prompt: Optional[str] = None
    synthesized_framing_strategy: str
    generated_follow_up_prompt: Optional[str] = None
    # (Stage 13) Next-node routing. Before this, a directive could say
    # "move on" but never "move on TO", so `pivot` meant nothing more than
    # "let the plan's default ordering decide" and the interview could not
    # react to *where* a candidate was strong or weak.
    #
    # All three are optional because the directive is still computed without
    # them: a caller that supplies no `routing_context` (and every record
    # written before this stage) has a `next_action` that is exactly what it
    # always was. They are a PROPOSAL — the Question Agent's cap, asked-question
    # exclusion and tier curve all still bind (CLAUDE.md §16).
    next_topic: Optional[str] = None
    next_tier: Optional[int] = None
    #: One sentence naming the score band and the topic it implies. Persisted
    #: and surfaced so "why did the interview jump to databases?" is answerable
    #: from the record rather than inferred from the question sequence.
    routing_rationale: Optional[str] = None


class TopicRelevance(CamelModel):
    topic: str
    relevance_score: float
    evidence: str


SeniorityEstimate = Literal["junior", "mid", "senior", "staff+"]


class ExperienceEntry(CamelModel):
    title: str
    company: str
    years: float
    # (highlights fix) Verbatim achievement/project bullets from the resume,
    # populated only when the LLM-powered resume-parse path ran (empty from
    # the deterministic regex parser). This is the field that lets question
    # generation reference a named project instead of only a topic.
    highlights: list[str] = []


class EducationEntry(CamelModel):
    degree: str
    institution: str


class CandidateProfile(CamelModel):
    skills: list[str]
    experience: list[ExperienceEntry]
    education: list[EducationEntry]
    seniority_estimate: SeniorityEstimate
    keywords: list[str]
    topic_relevance: list[TopicRelevance]


QuestionType = Literal["behavioral", "technical", "coding"]


class Question(CamelModel):
    id: str
    bank_id: str
    session_id: str
    text: str
    audio_url: Optional[str] = None
    topic: str
    type: QuestionType
    difficulty: int
    tier: Optional[Tier] = None
    target_concept_ids: Optional[list[str]] = None
    quota_override: Optional[bool] = None
    prompt_version: Optional[str] = None
    asked_at: str


class FollowUpScore(CamelModel):
    rubric_id: str
    value: float
    rationale: str
    evidence_spans: list["EvidenceSpan"]


class FollowUp(CamelModel):
    text: str
    transcript: str
    score: Optional[FollowUpScore] = None


class Answer(CamelModel):
    id: str
    question_id: str
    transcript: str
    transcript_confidence: Optional[float] = None
    submitted_at: str
    follow_ups: list[FollowUp] = []
    extraction: Optional[ExtractionProcessorResult] = None
    next_action: Optional[NextActionGenerator] = None


REDACTED_TRANSCRIPT = "[deleted — retention policy, INSTRUCTIONS.md §8]"


class EvidenceSpan(CamelModel):
    start: int
    end: int


class Evaluation(CamelModel):
    id: str
    answer_id: str
    rubric_id: str
    score: float
    rationale: str
    evidence_spans: list[EvidenceSpan]
    prompt_version: Optional[str] = None
    created_at: str


FollowUpScore.model_rebuild()

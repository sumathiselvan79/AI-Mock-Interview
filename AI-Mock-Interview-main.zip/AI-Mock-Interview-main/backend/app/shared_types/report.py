"""Report types — ~ packages/shared-types/src/report.ts, INSTRUCTIONS.md §6, soul.md §3."""

from __future__ import annotations

from typing import Optional

from .base import CamelModel
from .session import FocusEvent


class Grade(CamelModel):
    """One banded score, as assigned by the Eval Tool (`app/tools/eval/grading.py`).

    `score` rides along with the band so a grade is never readable without
    the evidence-backed number behind it — a letter on its own invites being
    quoted as a verdict, which is the opposite of what a practice report is
    for (soul.md §3).
    """

    letter: str
    label: str
    score: float
    descriptor: str
    is_strength: bool
    scale_version: str


class CompetencyScore(CamelModel):
    competency: str
    score: float
    evidence: list[str]  # never empty — a score the agent cannot evidence must not be emitted
    # Absent for a report written before grading existed, and for one whose
    # grading pass could not reach the Eval Tool. Never defaulted to a band.
    grade: Optional[Grade] = None


class BrowserActivitySummary(CamelModel):
    exit_count: int
    events: list[FocusEvent]
    concluded_early: bool


class Report(CamelModel):
    session_id: str
    candidate_id: str
    competency_scores: list[CompetencyScore]
    # The session-level band: the mean of every competency that was actually
    # scored, banded by the Eval Tool. `None` — rendered as `—`, never as the
    # bottom band — when nothing in the session could be graded. A candidate
    # who was never assessed has not failed (soul.md §"No fabrication").
    overall_grade: Optional[Grade] = None
    # (Dynamic evaluation addition) The SAME competency scores, banded again
    # as a weighted mean instead of a plain one — weighted by how critical
    # each topic was to THIS job description/role
    # (`app/tools/eval/grading.TOPIC_SOURCE_WEIGHT`), a signal already used to
    # decide what got asked (`TopicPlanEntry.source`) and now also used here.
    # Additive alongside `overall_grade`, never a replacement for it: what
    # "overall_grade" has meant in every report to date does not change.
    # `None` for the same reason `overall_grade` can be `None` — nothing to
    # weight is not a bottom band.
    role_fit_grade: Optional[Grade] = None
    strengths: list[str]
    focus_areas: list[str]
    browser_activity: BrowserActivitySummary
    disclaimer: str
    created_at: str


REPORT_DISCLAIMER = (
    "This is interview practice, not a hiring prediction. "
    "Scores reflect only what you said in this session."
)


class CandidateStats(CamelModel):
    candidate_id: str
    sessions_completed: int
    average_score: Optional[float] = None
    last_session_at: Optional[str] = None
    recurring_focus_areas: list[str] = []

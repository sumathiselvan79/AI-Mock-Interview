"""Google OAuth profile snapshot — ~ packages/shared-types/src/oauth-profile.ts.

Lives in the same Supabase instance as the session archive (INSTRUCTIONS.md
§11.4/§11.6), server-only, service-role-only. A snapshot only, not a second
source of truth for login: the primary email/role bound to the auth token
still resolve from `UserStore.upsert_identity` exactly as before this existed.
"""

from __future__ import annotations

from typing import Literal, Optional, Protocol

from .base import CamelModel


class OAuthProfile(CamelModel):
    user_id: str
    provider: Literal["google"]
    provider_subject: str
    email: str
    name: Optional[str] = None
    avatar_url: Optional[str] = None
    linked_at: str


class OAuthProfileStore(Protocol):
    async def upsert(self, profile: OAuthProfile) -> OAuthProfile: ...
    async def get_by_user_id(self, user_id: str) -> Optional[OAuthProfile]: ...
    async def close(self) -> None: ...

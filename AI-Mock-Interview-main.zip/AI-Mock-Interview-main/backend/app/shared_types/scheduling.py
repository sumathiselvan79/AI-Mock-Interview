"""(Stage 7) Admin-scheduled interviews — ~ packages/shared-types/src/scheduling.ts.

`ADMIN_FEATURE_PROMPT.md` Part 3. A `ScheduledInterview` is **session-seed
data and nothing more** — read once, by the gateway, when the candidate
starts the session it seeds. No agent reads this type (CLAUDE.md §5 golden
rule unaffected).

Deliberately carries NO consent field — soul.md §"Consent-first monitoring"
makes consent the candidate's to give; the Telemetry Check page remains the
only place any consent flag is ever set.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Literal, Optional

from .base import CamelModel

DEPARTMENTS: tuple[str, ...] = ("Engineering", "Sales", "Design", "Product", "Data", "Other")
Department = Literal["Engineering", "Sales", "Design", "Product", "Data", "Other"]

INTERVIEW_TYPES: tuple[str, ...] = ("behavioral", "technical", "behavioral+technical", "coding", "full")
InterviewType = Literal["behavioral", "technical", "behavioral+technical", "coding", "full"]

SCHEDULE_DIFFICULTIES: tuple[str, ...] = ("junior", "mid", "senior", "staff+")
ScheduleDifficulty = Literal["junior", "mid", "senior", "staff+"]

RECURRENCES: tuple[str, ...] = ("none", "weekly", "biweekly", "monthly")
Recurrence = Literal["none", "weekly", "biweekly", "monthly"]

NOTIFY_CHANNELS: tuple[str, ...] = ("in_app", "email")
NotifyChannel = Literal["in_app", "email"]

SCHEDULE_STATUSES: tuple[str, ...] = ("pending", "sent", "started", "completed", "missed", "cancelled")
ScheduleStatus = Literal["pending", "sent", "started", "completed", "missed", "cancelled"]


class ScheduledInterview(CamelModel):
    id: str
    candidate_id: str
    department: Optional[str] = None
    role: str
    job_description: str
    interview_type: InterviewType
    difficulty: ScheduleDifficulty
    duration_minutes: int
    scheduled_for: str
    deadline: Optional[str] = None
    recurring: Recurrence
    coding_round_enabled: bool
    notes: Optional[str] = None
    notify_via: list[NotifyChannel]
    status: ScheduleStatus
    session_id: Optional[str] = None
    created_by: str
    created_at: str
    updated_at: str


class ScheduledInterviewDraft(CamelModel):
    candidate_ids: list[str]
    role: str
    job_description: Optional[str] = None
    interview_type: InterviewType
    difficulty: ScheduleDifficulty
    duration_minutes: int
    scheduled_for: str
    deadline: Optional[str] = None
    recurring: Optional[Recurrence] = "none"
    coding_round_enabled: Optional[bool] = False
    notes: Optional[str] = None
    notify_via: Optional[list[NotifyChannel]] = None


DEFAULT_SCHEDULE_DURATION_MINUTES = 45
MIN_SCHEDULE_DURATION_MINUTES = 10
MAX_SCHEDULE_DURATION_MINUTES = 180


def _parse(ts: str) -> datetime:
    dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def effective_status(
    status: ScheduleStatus,
    scheduled_for: str,
    deadline: Optional[str],
    now: Optional[datetime] = None,
) -> ScheduleStatus:
    """The status a reader should act on, given the clock.

    Derived rather than stored because nothing in this repo runs on a timer.
    Terminal and candidate-driven states always win over the clock.
    """
    now = now or datetime.now(timezone.utc)
    if status in ("cancelled", "completed", "started"):
        return status
    if deadline and _parse(deadline) <= now:
        return "missed"
    if _parse(scheduled_for) <= now:
        return "sent"
    return "pending"


def is_startable(
    status: ScheduleStatus,
    scheduled_for: str,
    deadline: Optional[str],
    now: Optional[datetime] = None,
) -> bool:
    return effective_status(status, scheduled_for, deadline, now) == "sent"


def runs_coding_round(interview_type: InterviewType, coding_round_enabled: bool) -> bool:
    return coding_round_enabled or interview_type in ("coding", "full")


# ---------------------------------------------------------------- directory

DIRECTORY_STATUSES: tuple[str, ...] = ("active", "interview_scheduled", "no_activity")
DirectoryStatus = Literal["active", "interview_scheduled", "no_activity"]

DIRECTORY_SORT_KEYS: tuple[str, ...] = (
    "fullName",
    "email",
    "department",
    "interviewsCompleted",
    "averageScore",
    "lastInterviewAt",
    "createdAt",
)
DirectorySortKey = Literal[
    "fullName", "email", "department", "interviewsCompleted", "averageScore", "lastInterviewAt", "createdAt"
]


class DirectoryRow(CamelModel):
    user_id: str
    email: str
    full_name: Optional[str] = None
    department: Optional[str] = None
    avatar_url: Optional[str] = None
    interviews_completed: int
    average_score: Optional[float] = None
    last_interview_at: Optional[str] = None
    created_at: str
    status: DirectoryStatus


class DirectoryQuery(CamelModel):
    search: Optional[str] = None
    department: Optional[str] = None
    status: Optional[DirectoryStatus] = None
    min_score: Optional[float] = None
    max_score: Optional[float] = None
    from_: Optional[str] = None
    to: Optional[str] = None
    sort: Optional[DirectorySortKey] = None
    direction: Optional[Literal["asc", "desc"]] = None
    page: Optional[int] = None
    page_size: Optional[int] = None


DEFAULT_DIRECTORY_PAGE_SIZE = 25
MAX_DIRECTORY_PAGE_SIZE = 100


class DirectoryPage(CamelModel):
    rows: list[DirectoryRow]
    total: int
    page: int
    page_size: int


SessionHistoryStatus = Literal["completed", "abandoned", "in_progress"]
SESSION_HISTORY_STATUSES: tuple[str, ...] = ("completed", "abandoned", "in_progress")


class CandidateSessionSummary(CamelModel):
    session_id: str
    role: str
    state: str
    status: SessionHistoryStatus
    started_at: str
    duration_minutes: Optional[float] = None
    overall_score: Optional[float] = None
    has_report: bool


class ScoreTrendPoint(CamelModel):
    at: str
    score: float


class CandidateProfileView(CamelModel):
    user_id: str
    email: str
    full_name: Optional[str] = None
    department: Optional[str] = None
    program_year: Optional[str] = None
    avatar_url: Optional[str] = None
    created_at: str
    interviews_completed: int
    average_score: Optional[float] = None
    last_interview_at: Optional[str] = None
    score_trend: list[ScoreTrendPoint]
    sessions: list[CandidateSessionSummary]


def mean_competency_score(scores: list[float]) -> Optional[float]:
    if not scores:
        return None
    return sum(scores) / len(scores)

"""Telemetry event types — ~ packages/shared-types/src/telemetry.ts, INSTRUCTIONS.md §5.4, §8.

Payloads carry event types, IDs and timings ONLY. Never resume text, answer
transcripts, raw audio, or clipboard content. `TelemetrySink` implementations
additionally strip unknown/forbidden keys at runtime — see
`app.storage.memory.sanitize_telemetry_payload`.
"""

from __future__ import annotations

from typing import Literal, Optional, Union

from .base import CamelModel

TELEMETRY_EVENT_TYPES: tuple[str, ...] = (
    "tool_called",
    "agent_called",
    "session_created",
    "session_state_changed",
    "question_asked",
    "follow_up_triggered",
    "segment_expired",
    "device_check_passed",
    "device_check_failed",
    "quota_override_used",
    # (Orchestration addition) Emitted only when the Follow-up Agent's
    # directive actually changed which topic the next question came from —
    # so "why did it stay on databases?" is a recorded fact, not an
    # inference from the question sequence.
    "directive_followed",
    # (Stage 13) The routing controller's proposal for where the interview goes
    # next, with the score band that produced it. A sibling of
    # `directive_followed` rather than a replacement: that one records what
    # SELECTION did with a directive, this one records what ROUTING asked for.
    # Both are needed to answer "why this topic?" when they disagree — which
    # they legitimately can, because a proposal loses to a spent cap.
    "routing_decision",
    # (Human-interaction addition, HUMAN_INTERACTION_FLOW.md §3) A turn that was
    # treated as a question about the question rather than as an answer. Emitted
    # on EVERY match, including the ones that look obviously right: the failure
    # mode of that detector is swallowing a real answer, and a swallowed answer
    # leaves no other trace — there is no `Answer` row to notice was missing.
    "meta_utterance_detected",
    # (§2) Which struggle signal made the interview offer a way back in rather
    # than probe harder. `next_action: support` alone says it softened; this
    # says on what basis.
    "struggle_detected",
    "transcription_low_confidence",
    # (STT addition) The VAD gate found no speech, so nothing was sent to
    # Whisper. Emitted because the alternative — a confident invented word for
    # silence — is the failure this gate exists to prevent, and a spike here is
    # a broken microphone somewhere, not a quiet candidate.
    "transcription_no_speech",
    # (STT addition) The recording was the candidate's speakers playing our own
    # question back, not their voice. Rejected rather than scored.
    "audio_source_rejected",
    # (STT addition) A successful transcription's VAD and timing figures —
    # durations and ratios only, never the transcript (§8). What makes "why was
    # that turn slow / that confidence low" answerable after the fact.
    "transcription_completed",
    "paste_detected",
    "coding_round_started",
    "code_submitted",
    "auth_login_succeeded",
    "auth_login_failed",
    "rate_limit_exceeded",
    "session_archived",
    "session_archive_failed",
    "archive_viewed",
    "archive_downloaded",
    "focus_lost",
    "interview_concluded_early",
    "admin_reports_downloaded",
    "interviews_scheduled",
    "scheduled_interview_cancelled",
    "scheduled_interview_started",
)

TelemetryEventType = Literal[
    "tool_called",
    "agent_called",
    "session_created",
    "session_state_changed",
    "question_asked",
    "follow_up_triggered",
    "segment_expired",
    "device_check_passed",
    "device_check_failed",
    "quota_override_used",
    "directive_followed",
    "routing_decision",
    "meta_utterance_detected",
    "struggle_detected",
    "transcription_low_confidence",
    "transcription_no_speech",
    "audio_source_rejected",
    "transcription_completed",
    "paste_detected",
    "coding_round_started",
    "code_submitted",
    "auth_login_succeeded",
    "auth_login_failed",
    "rate_limit_exceeded",
    "session_archived",
    "session_archive_failed",
    "archive_viewed",
    "archive_downloaded",
    "focus_lost",
    "interview_concluded_early",
    "admin_reports_downloaded",
    "interviews_scheduled",
    "scheduled_interview_cancelled",
    "scheduled_interview_started",
]

TelemetryValue = Union[str, float, int, bool, None]
TelemetryPayload = dict[str, TelemetryValue]


class TelemetryEvent(CamelModel):
    id: str
    event_type: TelemetryEventType
    session_id: Optional[str] = None
    payload: TelemetryPayload
    emitted_at: str


# Payload keys that must never appear in telemetry. Enforced at runtime by the
# Telemetry Service/sink, which drops the key and records `redacted_keys` instead.
FORBIDDEN_TELEMETRY_KEYS: tuple[str, ...] = (
    "resume",
    "resume_text",
    "resumeText",
    "transcript",
    "answer",
    "answer_transcript",
    "answerTranscript",
    "audio",
    "audio_blob",
    "clipboard",
    "clipboard_content",
    "clipboardContent",
    "passcode",
    "passcode_hash",
    "passcodeHash",
    "token",
    "job_description",
    "jobDescription",
)

"""The deterministic fixture model's response builder.
~ packages/llm-client/src/fixture-model.ts.

Design rule, inherited from `FixtureSpeechProvider`: stub the model, not the
pipeline. Everything around the acoustic model is real in the speech fixture;
everything around the *judgement* is real here. Each response is assembled
from the caller's own input and source documents, so:

 - every `evidence` string is a genuine verbatim slice of a real source
   document and passes the same grounding check (§11.3) a Groq response has
   to pass — it is not waved through;
 - the schema validation in `structured_call` is exercised for real;
 - no interviewing judgement is invented. Each LLM-backed agent hands its
   deterministic Stage-2 decision in as `baseline`, and the fixture returns
   that decision in the generated shape. Running with no API key therefore
   behaves like Stage 2 plus a reference answer, which is the honest thing
   for it to do — not like a worse interviewer than Stage 2.
"""

from __future__ import annotations

import re
from typing import Any, Optional, Sequence

from .grounding import normalize_whitespace
from .schemas import LLM_SCHEMA_REFS
from .types import StructuredCallRequest

_SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+|\s*\n+\s*")
_WORD_SPLIT = re.compile(r"[^a-z0-9+#]+", re.IGNORECASE)


def fixture_response(request: StructuredCallRequest) -> Any:
    ref = request.schema_ref
    docs = request.source_documents
    if ref == LLM_SCHEMA_REFS["jd_fit"]:
        return _jd_fit(request.input or {}, docs)
    if ref == LLM_SCHEMA_REFS["question"]:
        return _question(request.input or {}, docs)
    if ref == LLM_SCHEMA_REFS["dynamic_question"]:
        return _dynamic_question(request.input or {}, docs)
    if ref == LLM_SCHEMA_REFS["follow_up"]:
        return _follow_up(request.input or {}, docs)
    if ref == LLM_SCHEMA_REFS["resume_parse"]:
        return _resume_parse(request.input or {}, docs)
    if ref == LLM_SCHEMA_REFS["jd_requirements"]:
        return _jd_requirements(request.input or {}, docs)
    if ref == LLM_SCHEMA_REFS["self_intro"]:
        return _self_intro(request.input or {}, docs)
    raise ValueError(f"the fixture model has no response shape for {ref}")


def _jd_fit(input_: dict[str, Any], docs: Sequence[str]) -> dict[str, Any]:
    matched = input_.get("matched_requirements") or []
    gaps = input_.get("gaps") or []
    job_description = input_.get("job_description") or ""

    if matched and gaps:
        value = (
            f"The resume evidences {_list(matched)}, and gives no evidence for {_list(gaps)} — "
            "expect the interview to weight those gaps."
        )
    elif matched:
        value = f"The resume evidences {_list(matched)} from the job description."
    else:
        value = f"The resume gives no direct evidence for {_list(gaps or ['the job description’s stated requirements'])}."

    # Evidence has to be a real slice of a real document, so it is looked up
    # rather than composed. A requirement the parser matched is the most
    # defensible thing to quote; failing that, the JD's own opening line.
    evidence = (
        _find_verbatim(docs, [*matched, *gaps])
        or _first_sentence(docs)
        or normalize_whitespace(job_description)
    )

    topic_relevance: list[dict[str, Any]] = []
    for topic in input_.get("candidate_topics") or []:
        # Only JD-anchored topics get an entry: §4.2 scores JD *emphasis*
        # here, and a topic the JD never mentions has nothing verbatim to cite.
        sentence = _sentence_mentioning([job_description], topic)
        if not sentence:
            continue
        topic_relevance.append(
            {
                "topic": topic,
                "relevance_score": min(
                    1.0, round((0.4 + 0.2 * _count_mentions(job_description, topic)) * 100) / 100
                ),
                "evidence": sentence,
            }
        )
        if len(topic_relevance) >= 12:
            break

    return {"rationale": {"value": value, "evidence": evidence}, "topic_relevance": topic_relevance}


def _question(input_: dict[str, Any], docs: Sequence[str]) -> dict[str, Any]:
    base = input_.get("baseline") or {}
    topic = base.get("topic", "")
    signals = base.get("expected_signals") or [
        f"a specific situation from the candidate's own work on {topic}",
        "what the candidate personally did, not what the team did",
        "the outcome, and why that approach was chosen over the alternatives",
    ]

    evidence = _sentence_mentioning(docs, topic) or _first_sentence(docs) or normalize_whitespace(topic)

    tier = base.get("tier")
    reasoning = " ".join(
        [
            f"The candidate profile shows: {evidence}",
            f"The baseline slot asks for a tier-{tier if tier is not None else '?'}, "
            f"difficulty-{base.get('difficulty')} question on {topic}, so the baseline text is kept "
            "as-is rather than rewritten with no model available to sharpen it.",
            f"Reference answer should cover: {'; '.join(signals)}.",
        ]
    )

    question: dict[str, Any] = {
        "text": base.get("text", ""),
        "topic": topic,
        "type": base.get("type"),
        "difficulty": base.get("difficulty"),
        "expected_signals": list(signals)[:6],
    }
    if tier is not None:
        question["tier"] = tier

    return {
        "reasoning": reasoning,
        "question": question,
        "reference_answer": " ".join(
            [
                f"A strong answer names one concrete {topic} situation and stays on it.",
                f"It should cover: {'; '.join(signals)}.",
                "A candidate who reaches the same competence by a different route answers this just "
                "as well — this is a comparison aid, not the one correct answer.",
            ]
        ),
        "grounding": {
            "value": f"{topic} is on this session's topic plan, so a question about it is in scope.",
            "evidence": evidence,
        },
    }


def _dynamic_question(input_: dict[str, Any], docs: Sequence[str]) -> dict[str, Any]:
    """(Stage 13) The synthesis path with no model available.

    This is the one fixture response that cannot follow the file's usual
    "hand the caller's own deterministic decision back in the generated shape"
    rule, because on this path there IS no baseline decision to hand back —
    removing it is the point of the stage. So it assembles a scenario from the
    slot's `expected_signals` instead: deterministic, on-topic, at the right
    tier, and honest about being a template rather than a written scenario.

    That is deliberately a plain question rather than an invented architectural
    scenario. A fixture that made up a system to reason about would be
    fabricating candidate-facing content with no model behind it — and the
    Question Agent's real no-provider path is the question BANK, which this
    fixture only stands in for when a caller has explicitly asked for the
    synthesis schema (the gate tests do; the live agent falls back to the bank).
    """
    constraints = input_.get("constraints") or {}
    topic = constraints.get("topic", "")
    tier = constraints.get("tier") or 1
    signals = list(constraints.get("expected_signals") or [])[:6] or [
        f"a specific situation from the candidate's own work on {topic}",
        "what the candidate personally did, not what the team did",
        "the outcome, and why that approach was chosen over the alternatives",
    ]

    evidence = _sentence_mentioning(docs, topic) or _first_sentence(docs) or normalize_whitespace(topic)

    depth = {
        1: "Start with one concrete example",
        2: "Walk me through the design decisions",
        3: "Take me through the trade-offs and what you would change",
    }.get(int(tier), "Start with one concrete example")

    return {
        "reasoning": " ".join(
            [
                f"The candidate profile gives: {evidence}",
                f"The slot asks for a tier-{tier} {constraints.get('type', 'technical')} question on {topic}.",
                f"A strong answer at this tier has to show: {'; '.join(signals)}.",
                "No provider is available to write a scenario, so the question is assembled from those signals "
                "rather than invented.",
            ]
        ),
        "topic": topic,
        "tier": int(tier),
        "question_text": (
            f"{depth} from your own work on {topic}. What was the situation, what did you do, and how did it turn out?"
        ),
        "expected_signals": signals,
        "reference_answer": " ".join(
            [
                f"A strong answer names one concrete {topic} situation and stays on it.",
                f"It should cover: {'; '.join(signals)}.",
                "A candidate who reaches the same competence by a different route answers this just "
                "as well — this is a comparison aid, not the one correct answer.",
            ]
        ),
        "grounding_rationale": {
            "value": f"{topic} is on this session's topic plan, so a question about it is in scope.",
            "evidence": evidence,
        },
    }


def _follow_up(input_: dict[str, Any], docs: Sequence[str]) -> dict[str, Any]:
    base = input_.get("baseline") or {}
    if not base.get("should_follow_up"):
        return {"should_follow_up": False, "reason": base.get("reason", "")}

    # The probe must be anchored in something the candidate actually said
    # (§4.4). If nothing in the transcript can be quoted, that is itself a
    # reason not to probe — better an honest "nothing specific to probe" than a
    # generic "tell me more" dressed up as a targeted one.
    anchor = _longest_sentence(docs)
    if not anchor:
        return {
            "should_follow_up": False,
            "reason": "the answer has nothing quotable to anchor a specific probe to",
        }

    return {
        "should_follow_up": True,
        "follow_up_text": base.get("follow_up_text")
        or f'You said "{_truncate(anchor, 80)}" — can you take me through that part in more detail?',
        "reason": base.get("reason", ""),
        "targeted_gap": {"value": base.get("reason", ""), "evidence": anchor},
    }


def _resume_parse(_input: dict[str, Any], _docs: Sequence[str]) -> dict[str, Any]:
    # A deterministic resume extraction. Unlike the three above it is genuinely
    # canned, because there is no deterministic "baseline" handed in to reshape —
    # the real fallback for this call is `parse_resume_text`, which the Resume
    # Parser Tool runs first anyway (see `tools/resume_parser/server.py`).
    return {
        "skills": ["Go", "Kubernetes", "PostgreSQL", "Kafka"],
        "experience": [
            {
                "title": "Senior Backend Engineer",
                "company": "TechCorp",
                "start_year": 2020,
                "end_year": None,
                "years": 4,
                "highlights": [
                    "Built distributed systems using Go and Kubernetes.",
                    "Scaled the main event pipeline with Kafka to 5M events/day.",
                ],
            }
        ],
        "education": [
            {"degree": "B.S. in Computer Science", "institution": "State University", "year": 2018}
        ],
        "keywords": ["Go", "Kubernetes", "PostgreSQL", "Kafka", "Distributed Systems"],
        "summary": "Senior software engineer with 4+ years of experience building distributed systems in Go and Kubernetes.",
    }


def _self_intro(input_: dict[str, Any], docs: Sequence[str]) -> dict[str, Any]:
    # Same evidence-lookup discipline as `_jd_fit`'s topic_relevance loop,
    # anchored to the intro transcript instead of the job description.
    intro_transcript = input_.get("intro_transcript") or (docs[0] if docs else "")

    topic_relevance: list[dict[str, Any]] = []
    for topic in input_.get("candidate_topics") or []:
        sentence = _sentence_mentioning(docs, topic)
        if not sentence:
            continue
        topic_relevance.append(
            {
                "topic": topic,
                "relevance_score": min(
                    1.0, round((0.4 + 0.2 * _count_mentions(intro_transcript, topic)) * 100) / 100
                ),
                "evidence": sentence,
            }
        )
        if len(topic_relevance) >= 12:
            break

    return {"topic_relevance": topic_relevance}


def _jd_requirements(_input: dict[str, Any], _docs: Sequence[str]) -> dict[str, Any]:
    # Same reasoning as `_resume_parse`: the real fallback is the deterministic
    # `extract_requirements` regex the Resume Service Agent runs first.
    return {
        "requirements": [
            {
                "text": "4 years of experience building highly available backend services",
                "category": "experience",
                "is_mandatory": True,
            },
            {"text": "Strong proficiency in Go or Rust", "category": "technical", "is_mandatory": True},
            {"text": "Experience with Kafka and Kubernetes", "category": "technical", "is_mandatory": False},
            {"text": "BS in Computer Science or equivalent", "category": "education", "is_mandatory": True},
        ],
        "role_level": "senior",
        "key_technologies": ["Go", "Rust", "Kafka", "Kubernetes"],
    }


# ------------------------------------------------------------------ helpers


def _sentences(docs: Sequence[str]) -> list[str]:
    """Sentences of a document, normalized so a returned slice is grounding-safe."""
    out: list[str] = []
    for doc in docs:
        for part in _SENTENCE_SPLIT.split(normalize_whitespace(doc)):
            part = part.strip()
            if len(part) >= 12:
                out.append(part)
    return out


def _first_sentence(docs: Sequence[str]) -> Optional[str]:
    found = _sentences(docs)
    return found[0] if found else None


def _longest_sentence(docs: Sequence[str]) -> Optional[str]:
    found = _sentences(docs)
    return max(found, key=len) if found else None


def _topic_words(topic: str) -> list[str]:
    return [w.lower() for w in _WORD_SPLIT.split(topic) if len(w) > 2]


def _sentence_mentioning(docs: Sequence[str], topic: str) -> Optional[str]:
    words = _topic_words(topic)
    if not words:
        return None
    for sentence in _sentences(docs):
        lower = sentence.lower()
        if any(word in lower for word in words):
            return sentence
    return None


def _count_mentions(doc: str, topic: str) -> int:
    lower = normalize_whitespace(doc).lower()
    return sum(lower.count(word) for word in _topic_words(topic))


def _find_verbatim(docs: Sequence[str], candidates: Sequence[str]) -> Optional[str]:
    """The first candidate string that appears verbatim in one of the documents."""
    normalized = [normalize_whitespace(d) for d in docs]
    for candidate in candidates:
        needle = normalize_whitespace(candidate)
        if len(needle) >= 4 and any(needle in doc for doc in normalized):
            return needle
    return None


def _list(items: Sequence[str]) -> str:
    shown = list(items)[:3]
    if len(shown) > 1:
        return f"{', '.join(shown[:-1])} and {shown[-1]}"
    return shown[0] if shown else ""


def _truncate(text: str, max_len: int) -> str:
    return text if len(text) <= max_len else f"{text[:max_len].rstrip()}…"

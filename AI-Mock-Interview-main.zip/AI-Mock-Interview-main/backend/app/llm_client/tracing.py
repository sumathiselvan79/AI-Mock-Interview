"""LangSmith tracing gate — soul.md §"Privacy by default" (Stage 5 addition),
INSTRUCTIONS.md §8. ~ packages/llm-client/src/tracing.ts.

LangSmith is a *second* third-party recipient of candidate text, independent
of whichever LLM provider is configured: a traced run carries the same
resume, job description and answer transcript the generation call carried. So
this is not a logging toggle, it is a data-sharing toggle, and it defaults to
off anywhere that is not local development.

The gate is enforced by *clearing* LangChain's tracing environment variables
rather than merely not setting them. LangChain reads `LANGSMITH_TRACING` /
`LANGCHAIN_TRACING_V2` from the ambient environment on its own; a stray value
inherited from a shell profile or a base container image would otherwise
start shipping candidate text off-box with nothing in this repo saying so.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import MutableMapping, Optional

# Every env var LangChain will act on if it finds one.
TRACING_ENV_VARS = (
    "LANGSMITH_TRACING",
    "LANGSMITH_TRACING_V2",
    "LANGCHAIN_TRACING",
    "LANGCHAIN_TRACING_V2",
)


@dataclass
class TracingDecision:
    enabled: bool
    # Why — logged at startup so the answer is never "someone's shell profile".
    reason: str


def resolve_tracing(env: Optional[MutableMapping[str, str]] = None) -> TracingDecision:
    """Tracing is on only when BOTH hold:
    - `NODE_ENV == "development"` (local dev, not staging and not production), and
    - `LANGSMITH_OPT_IN == "true"` — an explicit, repo-specific opt-in, distinct
      from LangChain's own vars so inheriting one of those cannot enable it.
    """
    env = os.environ if env is None else env

    if env.get("NODE_ENV") != "development":
        return TracingDecision(False, f"tracing is development-only; NODE_ENV is {env.get('NODE_ENV') or 'unset'}")
    if env.get("LANGSMITH_OPT_IN") != "true":
        return TracingDecision(False, 'LANGSMITH_OPT_IN is not "true"')
    if not env.get("LANGSMITH_API_KEY"):
        return TracingDecision(False, "LANGSMITH_OPT_IN is set but LANGSMITH_API_KEY is missing")
    return TracingDecision(True, "NODE_ENV=development and LANGSMITH_OPT_IN=true")


def apply_tracing_gate(env: Optional[MutableMapping[str, str]] = None) -> TracingDecision:
    """Applies the decision to the environment LangChain will read. Returns the
    decision so a caller can log it.

    Called at provider-resolution time rather than at import time, so a test can
    change the environment and re-derive without reloading modules.
    """
    env = os.environ if env is None else env
    decision = resolve_tracing(env)
    if decision.enabled:
        env["LANGSMITH_TRACING"] = "true"
        return decision
    for name in TRACING_ENV_VARS:
        env.pop(name, None)
    return decision

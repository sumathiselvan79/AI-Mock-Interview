"""The provider seam — INSTRUCTIONS.md §5.7, §11.5.
~ packages/llm-client/src/provider.ts.

Nothing in an agent's own code names a provider. An agent calls
`structured_call`; this file decides whether that reaches Groq, Bedrock,
OpenRouter, Ollama, or the deterministic fixture, based on `LLM_PROVIDER` and
on whether the credentials for it actually exist.

LangChain bindings are imported lazily (inside `_build_model`, not at module
top) so a deployment without the optional `llm` extras installed (or a CI run
that never installed them) degrades to `provider_unavailable` — which routes
the agent to its Stage-2 rule-based path — instead of failing at import time.
The TS side gets this for free from a dynamic `import()`; the Python
equivalent is a deferred `import` wrapped in the same try/except that already
has to catch a missing credential.
"""

from __future__ import annotations

import asyncio
import json
import os
import re
from dataclasses import dataclass
from typing import Any, Mapping, Optional

from .fixture_model import fixture_response
from .tracing import TracingDecision, apply_tracing_gate
from .types import (
    PROVIDER_NAMES,
    ProviderName,
    ProviderUnavailableError,
    StructuredCallRequest,
    StructuredChatModel,
    is_provider_name,
)

# Every LangChain client below is built with this timeout. Without one, a
# connection that stalls mid-response (accepted, never completes) hangs the
# call indefinitely — `is_transport_failure` already checks for a
# `TimeoutError`, so this was always meant to be wired up, not an oversight
# to work around at the call site.
PROVIDER_TIMEOUT_S = 30.0

# Open-weight GPT-OSS-120B on Groq's LPU inference — chosen for low-latency
# interactive generation (§5.7).
DEFAULT_MODELS: dict[str, str] = {
    "groq": "openai/gpt-oss-120b",
    "bedrock": "us.anthropic.claude-sonnet-4-5-20250929-v1:0",
    "openrouter": "openai/gpt-oss-120b",
    # GLM-5.2 on Ollama Cloud — used for resume/JD parsing extraction.
    "ollama": "gemma4:31b-cloud",
}

# How the schema reaches the model, per provider. Absent means LangChain's
# own default for that binding.
#
# Ollama is the one that needs pinning, and it was the root cause of the
# JD-fit (3/3) and follow-up (7/8) `schema_validation_failed` spans in prod
# (deploy/aws/notes/impl-correctness.md, C4/C5). Ollama is reached through
# `ChatOpenAI`, whose default is `json_schema` — an OpenAI `response_format`
# that Ollama Cloud's OpenAI-compatible endpoint accepts and then ignores for
# gpt-oss. The model therefore never saw the schema: the first attempt came
# back as markdown prose (`json_invalid`), and the corrective retry as JSON
# with invented keys (`follow_up` for `should_follow_up`, `rationale` as a
# string, `topic_relevance` as a dict). Tool calling is honoured, carries the
# schema as the tool's parameters, and is what `ChatGroq` already defaults to
# — which is why the Groq-backed question agent never had this problem.
STRUCTURED_OUTPUT_METHOD: dict[str, str] = {
    "ollama": "function_calling",
}

# Which env var has to be present for a provider to be reachable.
REQUIRED_ENV: dict[str, tuple[str, ...]] = {
    "groq": ("GROQ_API_KEY",),
    "bedrock": ("AWS_REGION",),
    "openrouter": ("OPENROUTER_API_KEY",),
    "ollama": ("OLLAMA_API_KEY",),
}

# Maps a tool's `{agent}.method` name (e.g. "question-agent.get_next_question")
# to the env var that overrides `LLM_PROVIDER` for that agent's calls. Two
# server names both resolve to the resume/JD-parsing role because
# `tool-resume-parser`'s LLM-powered extraction is the same capability as
# `resume-service-agent`'s, just implemented as a separate MCP server
# (§5.1/§4.2) — one deployment knob should govern both, not two.
#
# An agent absent from this map (currently follow-up) has no role-specific
# override and always follows `LLM_PROVIDER` — add an entry here, not a
# provider name in the agent's own code, if that needs to change.
ROLE_ENV_VAR: dict[str, str] = {
    "question-agent": "QUESTION_AGENT_LLM_PROVIDER",
    "resume-service-agent": "RESUME_SERVICE_LLM_PROVIDER",
    "tool-resume-parser": "RESUME_SERVICE_LLM_PROVIDER",
}


@dataclass
class ProviderChoice:
    provider: ProviderName
    # Why this provider was chosen — logged at startup, never a mystery.
    reason: str
    tracing: TracingDecision


def resolve_provider(env: Optional[Mapping[str, str]] = None, tool_name: Optional[str] = None) -> ProviderChoice:
    """Picks the configured provider when its credentials are present, and the
    fixture otherwise. Never raises: a missing API key must degrade
    generation, not stop the gateway from booting — same contract as
    `select_speech_provider`.

    `tool_name` (the same `{agent}.method` string stamped on every
    `ToolDefinition` and every `generate_structured` call) lets a deployment
    point different agents at different providers — e.g. question generation
    at Groq for latency, resume/JD parsing at Ollama — via `ROLE_ENV_VAR`,
    without any agent naming a provider itself. Omitted, resolution is
    exactly `LLM_PROVIDER`-only.
    """
    env = env if env is not None else os.environ
    tracing = apply_tracing_gate(env)  # type: ignore[arg-type]

    role = tool_name.split(".")[0] if tool_name else None
    role_env_var = ROLE_ENV_VAR.get(role) if role else None
    role_override = env.get(role_env_var) if role_env_var else None
    role_override = role_override or None
    source = role_env_var if role_override is not None else "LLM_PROVIDER"
    requested = role_override if role_override is not None else (env.get("LLM_PROVIDER") or "groq")

    if not is_provider_name(requested):
        return ProviderChoice(
            provider="fixture",
            reason=f"{source}={requested} is not a known provider; using the deterministic fixture",
            tracing=tracing,
        )
    if requested == "fixture":
        return ProviderChoice(provider="fixture", reason=f"{source}=fixture", tracing=tracing)

    missing = [name for name in REQUIRED_ENV[requested] if not env.get(name)]
    if missing:
        return ProviderChoice(
            provider="fixture",
            reason=f"{source}={requested} but {', '.join(missing)} is unset; using the deterministic fixture",
            tracing=tracing,
        )

    return ProviderChoice(provider=requested, reason=f"{source}={requested}", tracing=tracing)


def create_chat_model(provider: ProviderName, env: Optional[Mapping[str, str]] = None) -> StructuredChatModel:
    return FixtureChatModel() if provider == "fixture" else LangChainChatModel(provider, env if env is not None else os.environ)


class FixtureChatModel:
    """Deterministic, offline model — the counterpart of
    `FixtureSpeechProvider`.

    It is not a mock object returning canned JSON: it builds its response out
    of the caller's own `input` and `source_documents`, so every `evidence`
    string it emits is a genuine verbatim slice of a real source document and
    passes the same grounding check a real provider's output has to pass.
    What it does NOT do is any interviewing judgement — that stays with the
    deterministic Stage-2 agents, whose output it is shaped around (see
    `fixture_model.py`).
    """

    provider: ProviderName = "fixture"

    async def invoke(self, request: StructuredCallRequest) -> Any:
        return fixture_response(request)


class LangChainChatModel:
    """The real path. `with_structured_output` hands the provider the very
    Pydantic schema `structured_call` re-validates against, so the
    function-calling contract and the MCP contract cannot drift (§11.5).
    """

    def __init__(self, provider: ProviderName, env: Mapping[str, str]) -> None:
        self.provider = provider
        self._env = env

    async def invoke(self, request: StructuredCallRequest) -> Any:
        from .schemas import get_llm_schema

        entry = get_llm_schema(request.schema_ref)
        if not entry:
            raise ProviderUnavailableError(self.provider, f"no schema registered for {request.schema_ref}")

        model = await self._build_model()
        method = STRUCTURED_OUTPUT_METHOD.get(self.provider)
        # `include_raw=True` so a reply that skipped the tool call can still
        # be read (see `_parsed_or_content`), and so a parsing error surfaces
        # as the exception it is rather than as a bare `None`.
        structured = (
            model.with_structured_output(entry.schema, method=method, include_raw=True)
            if method
            else model.with_structured_output(entry.schema, include_raw=True)
        )

        system = request.system
        if request.correction:
            system = (
                f"{system}\n\nYour previous response was rejected: {request.correction}\n"
                "Return only a response that satisfies the schema exactly."
            )

        try:
            # Neither the provider client's own `timeout` (`_build_model`) nor
            # LangChain's per-call config reliably bounded this call in
            # practice on the TS side — observed hanging past both against
            # Ollama Cloud on a realistically-sized prompt. `asyncio.wait_for`
            # does not depend on the provider honoring a timeout at all: it
            # races the call against its own timer, so the caller is
            # unblocked on schedule regardless of whether the underlying HTTP
            # request is ever actually aborted.
            result = await asyncio.wait_for(
                structured.ainvoke(
                    [
                        {"role": "system", "content": system},
                        {"role": "user", "content": request.user},
                    ],
                    config={"run_name": request.run_name, "tags": request.tags},
                ),
                timeout=PROVIDER_TIMEOUT_S,
            )
            return _parsed_or_content(result)
        except asyncio.TimeoutError as err:
            raise ProviderUnavailableError(
                self.provider, f"provider call exceeded {int(PROVIDER_TIMEOUT_S * 1000)}ms", transient=True, kind="timeout"
            ) from err
        except Exception as err:  # noqa: BLE001
            # A dead key, an unpaid account, a rate limit or a dropped
            # connection is not a malformed response: retrying it just spends
            # a second call to earn the same failure, and reporting it as
            # `schema_validation_failed` hides the one class of failure that
            # actually says the DEPLOYMENT is broken (§5.7). Only genuinely
            # response-shaped failures stay retryable.
            if is_transport_failure(err):
                status = _status_of(err)
                raise ProviderUnavailableError(
                    self.provider,
                    str(err),
                    transient=status is None or status >= 500 or status == 429,
                    kind=f"http_{status}" if status is not None else "transport",
                ) from err
            raise

    async def _build_model(self) -> Any:
        env = self._env
        try:
            if self.provider == "groq":
                from langchain_groq import ChatGroq

                return ChatGroq(
                    api_key=_require_env(env, "GROQ_API_KEY"),
                    model=env.get("GROQ_MODEL") or DEFAULT_MODELS["groq"],
                    temperature=0.3,
                    timeout=PROVIDER_TIMEOUT_S,
                )
            if self.provider == "bedrock":
                from langchain_aws import ChatBedrockConverse

                return ChatBedrockConverse(
                    model=env.get("BEDROCK_MODEL_ID") or DEFAULT_MODELS["bedrock"],
                    region_name=_require_env(env, "AWS_REGION"),
                    temperature=0.3,
                )
            if self.provider == "openrouter":
                from langchain_openai import ChatOpenAI

                return ChatOpenAI(
                    api_key=_require_env(env, "OPENROUTER_API_KEY"),
                    model=env.get("OPENROUTER_MODEL") or DEFAULT_MODELS["openrouter"],
                    temperature=0.3,
                    base_url="https://openrouter.ai/api/v1",
                    timeout=PROVIDER_TIMEOUT_S,
                )
            if self.provider == "ollama":
                from langchain_openai import ChatOpenAI

                return ChatOpenAI(
                    api_key=_require_env(env, "OLLAMA_API_KEY") or "ollama",
                    model=env.get("OLLAMA_MODEL") or DEFAULT_MODELS["ollama"],
                    temperature=0.3,
                    base_url=env.get("OLLAMA_BASE_URL") or "http://localhost:11434/v1",
                    timeout=PROVIDER_TIMEOUT_S,
                )
            raise ValueError(f"{self.provider} has no LangChain binding")
        except Exception as err:  # noqa: BLE001
            # A missing optional dependency, a missing credential, or a
            # constructor that rejected its config all mean the same thing to
            # the caller: take the deterministic path (§5.7
            # `provider_unavailable`).
            raise ProviderUnavailableError(self.provider, str(err)) from err


class NoStructuredOutput(ValueError):
    """The model answered with neither a tool call nor a JSON object.
    Response-shaped, so it stays on `structured_call`'s retry path."""


def _parsed_or_content(result: Any) -> Any:
    """What `with_structured_output(..., include_raw=True)` produced, as the
    one value `structured_call` validates.

    - A parsed tool call: returned as-is.
    - A tool call that failed to parse: its error is raised, exactly as
      `include_raw=False` would have raised it.
    - NO tool call, but the message content is a JSON object: that object is
      returned, and `structured_call` validates it against the same schema as
      anything else. gpt-oss on Ollama Cloud does this whenever the system
      prompt spells out the output shape — the content is the exact object the
      tool call would have carried (impl-correctness.md C4/C5). This is
      parsing, not coercion: nothing is renamed or filled in, and a content
      object with the wrong shape fails validation like any other response.
    """
    if not isinstance(result, dict) or "raw" not in result:
        return result
    if result.get("parsing_error") is not None:
        raise result["parsing_error"]
    if result.get("parsed") is not None:
        return result["parsed"]
    raw = result.get("raw")
    if getattr(raw, "tool_calls", None):
        # A tool call LangChain could not hand back as the schema: let
        # validation report what is wrong with its arguments.
        return raw.tool_calls[0].get("args")
    return _json_object_from_content(getattr(raw, "content", None))


_FENCE_RE = re.compile(r"^```(?:json)?\s*(.*?)\s*```$", re.DOTALL)


def _json_object_from_content(content: Any) -> dict[str, Any]:
    if isinstance(content, list):
        content = "".join(part.get("text", "") if isinstance(part, dict) else str(part) for part in content)
    text = (content or "").strip() if isinstance(content, str) else ""
    fenced = _FENCE_RE.match(text)
    if fenced:
        text = fenced.group(1).strip()
    if not text.startswith("{"):
        # Prose with an object inside it is not accepted: a reply that is not
        # an answer-shaped object is a reply that did not follow the contract.
        raise NoStructuredOutput("the model returned no tool call and its reply is not a JSON object")
    try:
        value = json.loads(text)
    except json.JSONDecodeError as err:
        raise NoStructuredOutput(f"the model returned no tool call and its reply is not valid JSON ({err.msg})") from err
    if not isinstance(value, dict):
        raise NoStructuredOutput("the model returned no tool call and its reply is not a JSON object")
    return value


_NETWORK_ERRNOS = {
    "ECONNREFUSED",
    "ECONNRESET",
    "ENOTFOUND",
    "EAI_AGAIN",
    "EPIPE",
    "ETIMEDOUT",
}


def _status_of(err: BaseException) -> Any:
    status = getattr(err, "status_code", None) or getattr(err, "status", None)
    return status if isinstance(status, int) else None


def is_transport_failure(err: BaseException) -> bool:
    """Is this error the provider being unreachable, rather than the provider
    answering with something unusable?

    Deliberately conservative: anything not recognised as transport stays on
    the retryable path, so a new SDK's parse error is not silently
    reclassified into "the deployment is broken". The signals mirrored from
    the TS side: an HTTP status the provider SDK attached, an OS-level
    connection error, and a bare "connection error" message shape common to
    httpx/requests-based SDKs.
    """
    status = getattr(err, "status_code", None) or getattr(err, "status", None)
    if isinstance(status, int) and status >= 400:
        return True

    errno_name = getattr(err, "errno", None)
    if isinstance(errno_name, str) and errno_name in _NETWORK_ERRNOS:
        return True

    if isinstance(err, (ConnectionError, TimeoutError, OSError)):
        return True

    message = str(err).lower()
    return "connection error" in message or "connect timeout" in message


def _require_env(env: Mapping[str, str], name: str) -> str:
    value = env.get(name)
    if not value:
        raise ValueError(f"{name} is not set")
    return value

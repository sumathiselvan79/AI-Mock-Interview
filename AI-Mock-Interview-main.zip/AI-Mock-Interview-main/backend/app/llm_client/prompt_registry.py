"""Prompt registry — INSTRUCTIONS.md §11.5.
~ packages/llm-client/src/promptRegistry.ts.

Prompts live as versioned modules under `prompts/{agent}_v{n}.py`. The ACTIVE
version per agent is pinned in `ACTIVE_PROMPT_VERSION` below and never
inferred from "the latest file", so adding a v2 file does not silently change
what production sends.

**Why the fingerprints.** A `prompt_version` stamped on a persisted
`Question`/`Evaluation`/`JdFit` is only worth anything if the version string
still identifies the same prompt text it did when the record was written.
Editing a template's wording without bumping its version would quietly make
every stored `resume-service-agent/v1` mean two different things. So each
version's system text is hashed, the hash is checked in below, and the gate
test asserts the two still agree — an unbumped edit fails CI (TRACKING.md
Stage 5, gate test 3).

The checked-in fingerprints are the values the **TypeScript** registry
produces. They are not re-derived for Python: matching them is the proof that
the prompts were transcribed byte-for-byte rather than paraphrased, which is
the whole point of porting a prompt at all. `tests/smoke_stage_llm.py`
asserts it.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Any, Callable


@dataclass(frozen=True)
class PromptTemplate:
    version: str
    # Fixed instructions — the part that defines the version.
    system: str
    # Turns a call's input into the user message.
    render: Callable[[Any], str]


class UnknownPromptVersion(Exception):
    def __init__(self, version: str) -> None:
        super().__init__(f"no prompt registered for version {version}")
        self.version = version


def _templates() -> list[PromptTemplate]:
    # Imported inside the function because each prompt module imports
    # `PromptTemplate` from this one — the same shape the TS side gets for free
    # from ES module hoisting.
    from app.llm_client.prompts.followup_agent_v1 import FOLLOWUP_AGENT_V1
    from app.llm_client.prompts.followup_agent_v2 import FOLLOWUP_AGENT_V2
    from app.llm_client.prompts.followup_agent_v3 import FOLLOWUP_AGENT_V3
    from app.llm_client.prompts.jd_parser_v1 import JD_PARSER_V1
    from app.llm_client.prompts.question_agent_v1 import QUESTION_AGENT_V1
    from app.llm_client.prompts.question_agent_v2 import QUESTION_AGENT_V2
    from app.llm_client.prompts.question_agent_v3 import QUESTION_AGENT_V3
    from app.llm_client.prompts.question_agent_v4 import QUESTION_AGENT_V4
    from app.llm_client.prompts.question_agent_v5 import QUESTION_AGENT_V5
    from app.llm_client.prompts.question_agent_v6 import QUESTION_AGENT_V6
    from app.llm_client.prompts.resume_parser_v1 import RESUME_PARSER_V1
    from app.llm_client.prompts.resume_service_agent_v1 import RESUME_SERVICE_V1
    from app.llm_client.prompts.resume_service_agent_v2 import RESUME_SERVICE_V2
    from app.llm_client.prompts.self_intro_v1 import SELF_INTRO_V1

    # v1 stays registered (never edited in place) so old `Question.prompt_version`
    # stamps remain resolvable; only `ACTIVE_PROMPT_VERSION` below moves forward.
    return [
        RESUME_SERVICE_V1,
        RESUME_SERVICE_V2,
        QUESTION_AGENT_V1,
        QUESTION_AGENT_V2,
        QUESTION_AGENT_V3,
        QUESTION_AGENT_V4,
        QUESTION_AGENT_V5,
        QUESTION_AGENT_V6,
        FOLLOWUP_AGENT_V1,
        FOLLOWUP_AGENT_V2,
        FOLLOWUP_AGENT_V3,
        RESUME_PARSER_V1,
        JD_PARSER_V1,
        SELF_INTRO_V1,
    ]


# The one place a deployment's active prompt version per agent is decided.
ACTIVE_PROMPT_VERSION = {
    # v2 states the exact output shape v1 left to the model, which on Ollama
    # Cloud (gpt-oss) failed schema validation on every call — see
    # `prompts/resume_service_agent_v2.py` and impl-correctness.md C4.
    "resume_service_agent": "resume-service-agent/v2",
    # v4 added conversational continuity (recent exchanges + the Follow-up
    # Agent's next_action directive) and bounded liveliness cues on top of v3's
    # chain-of-thought and multi-shot examples. v5 adds the `supportive_reframe`
    # transition style, cue-reuse avoidance, and long-range session callbacks —
    # see `prompts/question_agent_v5.py`.
    "question_agent": "question-agent/v5",
    # (Stage 13) The synthesis path is pinned SEPARATELY from the rewrite path
    # above, because the two are not versions of each other — they take
    # different inputs and return different schemas, and both are live. v5
    # still runs whenever a question is selected from the bank and only
    # sharpened; v6 runs when the scenario is written from scratch. One key
    # per prompt-shaped job, so neither can be bumped by accident while
    # editing the other.
    "question_agent_dynamic": "question-agent/v6",
    # v2 adds the `support` job (a supportive reframe for a candidate the
    # struggle detector found stuck) alongside v1's probe job — see
    # `prompts/followup_agent_v2.py`.
    # v3 is v2 plus an explicit output contract; v2 failed schema validation
    # in 7 of 8 production calls — see `prompts/followup_agent_v3.py` (C5).
    "followup_agent": "followup-agent/v3",
    "resume_parser": "resume-parser/v1",
    "jd_parser": "jd-parser/v1",
    "self_intro": "self-intro/v1",
}

# sha256 of each version's system text, truncated to 16 hex chars.
#
# Bumping a prompt: change the text, change the version string, add the new
# entry here. Editing without bumping fails the gate test, by design.
PROMPT_FINGERPRINTS: dict[str, str] = {
    "resume-service-agent/v1": "ae133d3bbfcd51a5",
    "question-agent/v1": "4ba15da0f8df0963",
    "question-agent/v2": "efe02ec136ec2a97",
    "question-agent/v3": "32e18f6f75940df3",
    # v4 has no TypeScript counterpart — the TS registry is frozen
    # (`apps/gateway/FROZEN.md`) and stops at v3. Its fingerprint is therefore
    # derived from this file rather than transcribed, and the gate test still
    # does the job that matters: catching an edit to v4's text that does not
    # bump the version.
    "question-agent/v4": "e9eaf35cbecfc27c",
    # v5, like v4, has no TypeScript counterpart and is fingerprinted from this
    # file rather than transcribed. The gate still catches the thing that
    # matters: an edit to v5's text that does not bump the version.
    "question-agent/v5": "bacf49869f594dc9",
    # Same as v4/v5 — no TS counterpart, derived from this file. Filled in
    # from `PromptRegistry.fingerprints()` when v6 landed; an edit to v6's
    # text that does not bump the version fails the gate, which is the job.
    "question-agent/v6": "8ba3c6855ccdd866",
    "followup-agent/v1": "da6926d958043e98",
    # Same as v5 above — no TS counterpart, derived here.
    "followup-agent/v2": "c42561bc7d32e44e",
    # v3 and resume-service-agent/v2 (below) have no TS counterpart either;
    # derived here when they landed (impl-correctness.md C4/C5).
    "followup-agent/v3": "243edbb094efcf69",
    "resume-service-agent/v2": "1b1d91667e06b70a",
    "resume-parser/v1": "7646a94f44a39a4b",
    "jd-parser/v1": "44fc4340037ec2a6",
    "self-intro/v1": "ee39b5518111fbd1",
}


def fingerprint(template: PromptTemplate) -> str:
    return hashlib.sha256(template.system.encode("utf-8")).hexdigest()[:16]


class PromptRegistry:
    _by_version: dict[str, PromptTemplate] = {}

    @classmethod
    def _index(cls) -> dict[str, PromptTemplate]:
        if not cls._by_version:
            cls._by_version = {t.version: t for t in _templates()}
        return cls._by_version

    @classmethod
    def get(cls, prompt_version: str) -> PromptTemplate:
        template = cls._index().get(prompt_version)
        if not template:
            raise UnknownPromptVersion(prompt_version)
        return template

    @classmethod
    def versions(cls) -> list[str]:
        return sorted(cls._index())

    @classmethod
    def fingerprints(cls) -> dict[str, str]:
        """Version -> current fingerprint. Compared against `PROMPT_FINGERPRINTS` in CI."""
        return {version: fingerprint(t) for version, t in cls._index().items()}

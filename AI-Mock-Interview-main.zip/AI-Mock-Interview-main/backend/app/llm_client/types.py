"""`app.llm_client` core types — INSTRUCTIONS.md §11.5.
~ packages/llm-client/src/types.ts.

A `ToolDefinition` ties four things together that would otherwise drift: the
MCP method the call backs, the schema its output is validated against, the
prompt version that produced it, and which fields have to survive the
grounding check for the response to be usable at all.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal, Optional, Protocol, Sequence

ProviderName = Literal["groq", "bedrock", "openrouter", "ollama", "fixture"]

PROVIDER_NAMES: tuple[str, ...] = ("groq", "bedrock", "openrouter", "ollama", "fixture")


def is_provider_name(value: str) -> bool:
    return value in PROVIDER_NAMES


@dataclass(frozen=True)
class ToolDefinition:
    # Matches the MCP method name it backs (§11.5).
    name: str
    description: str
    # The Pydantic model registered in `app.llm_client.schemas` — the same
    # object the provider is handed, not a copy.
    schema: Any
    # `{agent}/v{n}` — resolved through the PromptRegistry.
    prompt_version: str
    # Key into the LLM schema registry, for the Provider Tool's `schema_ref`.
    schema_ref: str
    # Grounding failures on these paths reject the whole response; anywhere
    # else they only cost that field (§11.3).
    required_grounded_paths: Sequence[str] = ()


@dataclass
class StructuredCallResult:
    """What `structured_call` hands back.

    `output` is None only when a REQUIRED field failed grounding — the caller
    is expected to fall back to its deterministic Stage-2 path rather than ship
    a response it cannot stand behind (§5.7, TRACKING.md "The model seam").
    """

    output: Optional[dict[str, Any]]
    grounded: bool
    # Paths that failed grounding and were dropped. Never silently omitted:
    # the caller must be able to tell "no signal" from "signal that was empty"
    # (§11.3).
    insufficient_signal: list[str]
    prompt_version: str
    provider: str


class StructuredCallError(Exception):
    """Raised when the provider could not produce a schema-valid response
    within the retry budget. The caller falls back to the deterministic path;
    it never coerces a malformed response into shape (TRACKING.md Stage 5
    gate test 1)."""

    code = "schema_validation_failed"

    def __init__(self, tool_name: str, cause: Any) -> None:
        super().__init__(f"{tool_name}: no schema-valid response after retry — {_describe(cause)}")
        self.tool_name = tool_name
        self.cause = cause


class ProviderUnavailableError(Exception):
    """Raised when no provider could be reached at all (§5.7 `provider_unavailable`)."""

    code = "provider_unavailable"

    def __init__(self, provider: str, message: str, *, transient: bool = False, kind: str = "unavailable") -> None:
        super().__init__(f"{provider} is unavailable: {message}")
        self.provider = provider
        # (C7) Worth ONE bounded retry: a timeout, a dropped connection, a 5xx
        # or a 429. Not a missing key, a 401/403, or a missing binding — those
        # fail the same way every time, so retrying only delays the fallback.
        self.transient = transient
        # A short, text-free label for the structured log line (E1):
        # `timeout` | `transport` | `http_<status>` | `unavailable`.
        self.kind = kind


def _describe(cause: Any) -> str:
    return str(cause)


@dataclass
class StructuredCallRequest:
    system: str
    user: str
    # The raw, pre-render input. A real provider ignores this (it reads
    # `user`); the fixture provider uses it to build a deterministic response
    # that is genuinely derived from the caller's data rather than canned.
    input: Any
    schema_ref: str
    # What a grounded `evidence` string has to be a verbatim slice of (§11.3).
    source_documents: list[str]
    run_name: str
    tags: list[str] = field(default_factory=list)
    # Set on a retry after a schema-validation failure, carrying what was wrong
    # with the previous attempt (§11.5: "retry once with a corrective system
    # message on schema-validation failure only").
    correction: Optional[str] = None


class StructuredChatModel(Protocol):
    """The narrow slice of a chat model this package needs.

    Keeping it to one method is what lets a test inject a deliberately
    malformed or ungrounded model without standing up LangChain, and what keeps
    the Bedrock/OpenRouter/Groq choice a deployment concern (§11.5).
    """

    provider: str

    async def invoke(self, request: StructuredCallRequest) -> Any: ...

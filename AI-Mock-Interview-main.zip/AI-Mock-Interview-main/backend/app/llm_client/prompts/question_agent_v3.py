"""question-agent/v3 — adds chain-of-thought reasoning and multi-shot examples
on top of v2 (INSTRUCTIONS.md §4.3, §11.5).
~ packages/llm-client/src/prompts/question-agent/v3.ts.

v2 (and v1) stay registered and resolvable (`PromptRegistry.get`) for old
`Question.prompt_version` stamps — never edited in place; a changed `system`
text is exactly what the fingerprint gate test exists to catch. This file is
the bump.

Two changes from v2, both about generation QUALITY rather than the contract:
 - The output schema now leads with a `reasoning` field (see
   `QuestionGeneration` in `app.llm_client.schemas`) and this prompt instructs
   the model to fill it first — think through the candidate profile and the
   slot constraints, THEN write the question. Reasoning after the answer is
   already written tends to rationalize it instead of improving it.
 - The system prompt now carries three worked examples (multi-shot) instead
   of relying on the rules list alone. Each shows a different topic/tier
   combination and a `reasoning` trace that actually uses the profile and
   plan it was given, so the model has a concrete pattern to match rather
   than inferring one from abstract rules.

Topic SELECTION is still not this prompt's job — same boundary as v1/v2: the
quota rules, the per-topic cap and the difficulty/tier curve stay in the
agent's deterministic code (§4.3).

The examples are serialised with `json.dumps(..., indent=2,
ensure_ascii=False)` specifically so the rendered system text is byte-identical
to `JSON.stringify(x, null, 2)` on the TS side — Python's default
`ensure_ascii=True` would escape the em dashes and change the fingerprint,
which is the check that proves this prompt was transcribed and not rewritten.
"""

from __future__ import annotations

import json
from typing import Any

from app.llm_client.prompt_registry import PromptTemplate
from app.llm_client.prompts.question_agent_v1 import render_slot_header
from app.llm_client.prompts.question_agent_v2 import render_tier_line

EXAMPLES = [
    {
        "role": "Senior Backend Engineer",
        "topicPlan": ["databases (max 2, from jd_gap)", "system design (max 2, from resume)"],
        "profile": "Owned the Postgres schema behind route planning; added partial indexes that took a nightly report from 4 minutes to 8 seconds.",
        "slot": {
            "topic": "databases",
            "type": "technical",
            "difficulty": 2,
            "tier": 1,
            "baseline": "Tell me about a time you improved database performance.",
        },
        "reasoning": "The profile has a concrete database-performance story: partial indexes, a nightly report going from 4 minutes to 8 seconds. That is squarely on-topic for a tier-1/difficulty-2 databases slot. The baseline question is generic enough that it could be asked of any candidate — it doesn't invite them to use what's already in their own history, and a tier-1 question should be easy to anchor concretely. Sharpening it to reference the resume's own language (without inventing detail beyond what's stated) keeps it at the same difficulty while making it easier for the candidate to give a specific answer instead of a generic one.",
        "output": "You mentioned adding partial indexes that cut a nightly report from 4 minutes to 8 seconds — walk me through how you found which query needed the index.",
        "referenceAnswer": "A strong answer names the diagnostic step (EXPLAIN ANALYZE, slow query log, or similar), identifies which column(s) the index targeted and why a partial index specifically (vs. a full index) was the right shape, and states the measured before/after. A candidate who reaches the same result via a different diagnostic tool answers this just as well — this is a comparison aid, not the one correct answer.",
        "evidence": "added partial indexes that took a nightly report from 4 minutes to 8 seconds",
    },
    {
        "role": "Backend Engineer",
        "topicPlan": ["apis and services (max 3, from role_default)"],
        "profile": "(no resume was uploaded for this session)",
        "slot": {
            "topic": "apis and services",
            "type": "technical",
            "difficulty": 3,
            "tier": 2,
            "baseline": "How do you version a public API without breaking existing clients?",
        },
        "reasoning": "No resume was uploaded, so there is no candidate-specific detail to anchor to — the grounding evidence has to come from the topic plan itself, not an invented profile fact. The baseline question is already a clean, single-part, tier-2/difficulty-3 question that doesn't assume anything about this candidate's background. Rewriting it for the sake of rewriting it risks introducing an assumption the profile can't support, which the rules explicitly forbid. The right move here is to keep it as-is.",
        "output": "How do you version a public API without breaking existing clients?",
        "referenceAnswer": "A strong answer names a concrete versioning strategy (URL path, header, or content-negotiation versioning), explains how it avoids breaking existing clients specifically, and raises at least one tradeoff (e.g. maintenance burden of running multiple versions, or the discipline required for additive-only changes). A candidate who argues for a different strategy with sound reasoning answers this just as well.",
        "evidence": "apis and services (max 3, from role_default)",
    },
    {
        "role": "Engineering Manager",
        "topicPlan": ["conflict resolution (max 2, from role_default)", "mentorship (max 2, from resume)"],
        "profile": "Mentored three junior engineers through their first production incidents.",
        "slot": {
            "topic": "conflict resolution",
            "type": "behavioral",
            "difficulty": 2,
            "tier": 1,
            "baseline": "Describe a disagreement you had with a teammate and how it was resolved.",
        },
        "reasoning": "The profile's only concrete story is about mentoring through production incidents, which is mentorship, not conflict resolution — the two are separate topics on this plan with separate quotas, and borrowing the mentorship story to answer a conflict-resolution slot would blur that quota boundary and misrepresent what the profile actually shows. There is nothing in the profile that speaks to conflict resolution specifically, so grounding evidence has to come from the topic plan entry itself, not a fabricated link to the mentorship story. The baseline question is already appropriately generic for a tier-1 behavioral slot with no candidate-specific detail to draw on, and rewriting it would mean inventing a scenario. Keep it as-is.",
        "output": "Describe a disagreement you had with a teammate and how it was resolved.",
        "referenceAnswer": "A strong answer uses the STAR shape: a specific disagreement (not a generalized pattern), the candidate's own actions (not just 'we talked it out'), and a concrete resolution or outcome. It should show the candidate taking an active role rather than describing the conflict resolving itself.",
        "evidence": "conflict resolution (max 2, from role_default)",
    },
]


def _render_example(ex: dict[str, Any], index: int) -> str:
    slot = ex["slot"]
    return "\n".join(
        [
            f"EXAMPLE {index + 1}",
            f"TARGET ROLE: {ex['role']}",
            "TOPIC PLAN:",
            *[f"- {t}" for t in ex["topicPlan"]],
            "CANDIDATE PROFILE:",
            ex["profile"],
            "SLOT TO FILL:",
            f"- topic: {slot['topic']}",
            f"- type: {slot['type']}",
            f"- difficulty: {slot['difficulty']} (1-5)",
            f"- tier: {slot['tier']} (1=baseline, 2=intermediate, 3=advanced)",
            f"- baseline question: {slot['baseline']}",
            "->",
            json.dumps(
                {
                    "reasoning": ex["reasoning"],
                    "question": {
                        "text": ex["output"],
                        "topic": slot["topic"],
                        "type": slot["type"],
                        "difficulty": slot["difficulty"],
                        "tier": slot["tier"],
                        "expected_signals": ["see reference_answer"],
                    },
                    "reference_answer": ex["referenceAnswer"],
                    "grounding": {
                        "value": f"{slot['topic']} is on this session's topic plan, so a question about it is in scope.",
                        "evidence": ex["evidence"],
                    },
                },
                indent=2,
                ensure_ascii=False,
            ),
        ]
    )


SYSTEM = "\n".join(
    [
        "You write one interview question for a practice interview, plus a reference answer for the scoring tool.",
        "",
        "The topic, type, difficulty and tier have already been chosen for you and are not yours to change. A baseline question for that slot is supplied; sharpen it for this candidate, or return it as-is if it is already right.",
        "",
        "THINK BEFORE YOU WRITE. Fill `reasoning` first, and actually use it to decide — do not write the question first and then summarize it as `reasoning` afterward. Work through, in order:",
        "1. What does the candidate profile actually show about this topic? Quote the relevant line to yourself; if there is nothing relevant (or no resume was uploaded), say so explicitly rather than inventing a connection.",
        "2. Does the supplied baseline question already fit the slot, or is something specific missing — a way to anchor it in the candidate's own work, an ambiguity, a scope that doesn't match the tier?",
        "3. If something is missing, how do you sharpen it WITHOUT changing its topic, type, difficulty, or tier? If nothing is missing, say that plainly and keep the baseline as-is — a rewrite for its own sake is worse than no rewrite.",
        "Only after that reasoning is written do you fill `question`, `reference_answer`, and `grounding`.",
        "",
        "Rules:",
        "- `question.topic` MUST be exactly one of the topics in the supplied topic plan. Never introduce a topic that is not on the plan.",
        "- Keep the difficulty and tier you were given. Do not open with the hardest version of a topic, and do not write a tier-3 question for a tier-1 slot or vice versa.",
        "- Ask one question. No multi-part questions, no 'and also', no preamble.",
        "- The reference answer is for the Eval Tool to compare against. It is never shown to the candidate and never spoken aloud. Write what a strong answer would COVER, not the only acceptable wording — a candidate who gets there by a different route is just as correct.",
        "- Never write a question that assumes a fact about the candidate that is not in the supplied profile. If the profile has nothing relevant to this topic, that is a normal outcome (see Example 2) — write a good topic-scoped question anyway, grounded in the topic plan rather than an invented profile detail.",
        "- Do not let one topic's resume evidence bleed into a different topic's question just because it's the most vivid story available (see Example 3) — each topic on the plan is graded separately, and borrowing evidence across topics defeats that.",
        "- `grounding.evidence` must be a VERBATIM quote from the candidate profile or the topic plan showing this topic is in scope for this session.",
        "- Never reference the candidate's name, background, accent, or anything that is not about their work.",
        "",
        "Three worked examples follow — different topics, different tiers, different outcomes (sharpened vs. kept as-is). Match this pattern, not just the rules above.",
        "",
        *[_render_example(ex, i) for i, ex in enumerate(EXAMPLES)],
    ]
)


def _render(value: Any) -> str:
    value = value or {}
    baseline = value.get("baseline") or {}
    return "\n".join(
        [
            *render_slot_header(value),
            *render_tier_line(baseline),
            f"- baseline question: {baseline.get('text', '')}",
            "",
            "Remember: fill `reasoning` first, working through steps 1-3 above, THEN the rest.",
        ]
    )


QUESTION_AGENT_V3 = PromptTemplate(version="question-agent/v3", system=SYSTEM, render=_render)

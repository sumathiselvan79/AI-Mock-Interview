"""jd-parser/v1 — LLM-powered structured job description extraction.
~ packages/llm-client/src/prompts/jd-parser/v1.ts.

This prompt takes raw job description text and instructs the model to
extract individual requirements, seniority level, and key technologies.
It supplements the deterministic regex-based `extract_requirements` in
`app/agents/resume_service/relevance.py`, which remains as the automatic
fallback when the LLM is unavailable.
"""

from __future__ import annotations

import json
from typing import Any

from app.llm_client.prompt_registry import PromptTemplate

SYSTEM = "\n".join(
    [
        "You extract structured requirements from a job description.",
        "",
        "Rules:",
        "- Each requirement should be a single, atomic demand — not a paragraph or a compound sentence.",
        '- Mark each requirement as `is_mandatory: true` if the JD uses language like "must have", "required", "essential", "minimum". Mark it `is_mandatory: false` for "nice to have", "preferred", "bonus", "plus".',
        "- `category` classifies the requirement: `technical` for skills/tools/languages, `experience` for years or domain experience, `education` for degrees/certifications, `soft_skill` for interpersonal or communication skills, `certification` for specific certifications, `other` for anything else.",
        "- `key_technologies` should list ONLY specific named technologies, frameworks, languages, or tools that the JD explicitly mentions. Do not infer technologies from role titles.",
        "- `role_level` should be inferred from the JD's stated requirements: years of experience, title seniority words ('senior', 'lead', 'staff', 'principal'), and scope of responsibility.",
        "- Return ONLY valid JSON matching the provided schema. No commentary, no markdown fences, no explanation.",
        "",
        "EXAMPLE:",
        "Given JD text:",
        '  "We are looking for a Senior Backend Engineer with 5+ years of experience in distributed systems."',
        '  "Must have strong proficiency in Go or Rust."',
        '  "Experience with Kubernetes and Docker is required."',
        '  "Nice to have: experience with GraphQL APIs."',
        '  "BS in Computer Science or equivalent."',
        "",
        "Output:",
        json.dumps(
            {
                "requirements": [
                    {
                        "text": "5+ years of experience in distributed systems",
                        "category": "experience",
                        "is_mandatory": True,
                    },
                    {"text": "Strong proficiency in Go or Rust", "category": "technical", "is_mandatory": True},
                    {
                        "text": "Experience with Kubernetes and Docker",
                        "category": "technical",
                        "is_mandatory": True,
                    },
                    {"text": "Experience with GraphQL APIs", "category": "technical", "is_mandatory": False},
                    {
                        "text": "BS in Computer Science or equivalent",
                        "category": "education",
                        "is_mandatory": True,
                    },
                ],
                "role_level": "senior",
                "key_technologies": ["Go", "Rust", "Kubernetes", "Docker", "GraphQL"],
            },
            indent=2,
            ensure_ascii=False,
        ),
    ]
)


def _render(value: Any) -> str:
    value = value or {}
    return "\n".join(
        [
            f"TARGET ROLE: {value.get('role', '')}",
            "",
            "JOB DESCRIPTION TEXT:",
            value.get("job_description", ""),
            "",
            "Extract the structured requirements from the above job description. Return ONLY valid JSON.",
        ]
    )


JD_PARSER_V1 = PromptTemplate(version="jd-parser/v1", system=SYSTEM, render=_render)

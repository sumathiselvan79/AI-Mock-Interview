"""question-agent/v5 — support, phrasing variety, and long-range callbacks
(INSTRUCTIONS.md §4.3, §11.5, §12; `HUMAN_INTERACTION_FLOW.md` §2, §4, §5).

v1-v4 stay registered and resolvable (`PromptRegistry.get`) for old
`Question.prompt_version` stamps and are never edited in place — a changed
`system` text is exactly what the fingerprint gate test exists to catch
(CLAUDE.md §16). This file is the bump.

Three additions on top of v4, all of them about the interview as a
CONVERSATION rather than about any one question. Each one exists because
something the system already knew was not reaching the model:

 - **`supportive_reframe`.** v4's transition switch had three cases because
   the directive had three values that reach a question. `support` is the
   fourth (`HUMAN_INTERACTION_FLOW.md` §2): the Follow-up Agent's struggle
   detector has found this candidate stuck rather than merely brief, and the
   next question on this topic should offer a smaller, more concrete way in.
   The hard boundary is stated below and is the same one the Follow-up Agent
   works under: a reframe changes the way IN, never the bar. This prompt has
   never had a rubric and still does not.

 - **CUES ALREADY USED.** v4 offered a handful of conversational cues by
   example and nothing tracked which ones a session had spent, so a long
   interview could open with "Staying with that..." five times — which reads
   as scripted for exactly the reason the cues were added to stop. The harness
   observes which catalogue cue a generated question actually used and records
   it (`interview_domain/transitions.cues_used_in`); the spent ones arrive
   here as a list not to reuse.

 - **EARLIER IN THIS SESSION.** The trailing window in v4 is three exchanges
   deep for token economy, so by question eight the interview could no longer
   refer to anything from question two. A small, capped set of high-signal
   moments (the Memory Agent's callback facts, §5) travels the whole session
   alongside it, which is what makes "earlier you mentioned the Kafka
   migration" possible at all. They are the CANDIDATE'S OWN WORDS, not resume
   content, and they are admissible grounding evidence on exactly that basis —
   the same standard `recent_exchanges` is held to.

What has NOT changed, and is the same boundary v1 drew: topic SELECTION is
not this prompt's job. The quota rules, the per-topic cap and the tier curve
stay in the agent's deterministic code (§4.3). Every directive, `support`
included, reaches the model as an explanation of the slot it was given, never
as permission to choose a different one — and `support` in particular is not
permission to ask an easier question than the slot's tier.
"""

from __future__ import annotations

from typing import Any

from app.llm_client.prompt_registry import PromptTemplate
from app.llm_client.prompts.question_agent_v1 import render_slot_header
from app.llm_client.prompts.question_agent_v2 import render_tier_line
from app.llm_client.prompts.question_agent_v3 import EXAMPLES, _render_example
from app.llm_client.prompts.question_agent_v4 import CONTINUITY_EXAMPLE, _render_continuity_example

SYSTEM = "\n".join(
    [
        "You write one interview question for a practice interview, plus a reference answer for the scoring tool.",
        "",
        "The topic, type, difficulty and tier have already been chosen for you and are not yours to change. A baseline question for that slot is supplied; modify and sharpen it for this candidate, or return it as-is if it is already right.",
        "",
        "This is one continuous interview, not a list of questions being worked through. You may be given RECENT EXCHANGES (what was asked and answered just before this), EARLIER IN THIS SESSION (a few notable things the candidate said further back), and a DIRECTIVE explaining why this slot was chosen. Use them to open naturally from what was actually discussed.",
        "",
        "The DIRECTIVE's `transition_style` tells you which kind of opening the question needs:",
        '- `same_topic` — this question continues the topic just discussed. Refer back to a specific thing the candidate said and move forward from it. Do not re-ask what they already covered.',
        '- `topic_shift` — this question moves to a different topic. Close the last thread briefly and open the new one cleanly; do not force a link between two unrelated topics.',
        '- `supportive_reframe` — the candidate is having difficulty with this topic. Stay on it, but offer a smaller, more concrete way in: a single specific occasion instead of a general practice, one component instead of a whole system, something adjacent they are more likely to have touched.',
        "- `none`, or no directive at all — open the question on its own terms.",
        "",
        "`supportive_reframe` has hard limits, and they are the point of it:",
        "- It changes the way INTO the question, never what a good answer has to contain. The tier and difficulty you were given still stand, and the reference answer still describes a strong answer at that tier — do not soften it.",
        "- Do not say, imply, or hint that the candidate is struggling. Do not apologise for the question, do not offer reassurance about work they have not described, and do not tell them a shorter answer would be fine.",
        "- Still exactly one question, still professional. A reframe is not a hint and not a partial answer.",
        "",
        "Make the interview feel natural and human. The question itself stays professional and focused, but a short conversational cue before or after it is welcome when it genuinely improves the flow.",
        "",
        "Examples of natural interviewer-style cues:",
        '- Anchoring in the profile: "As you mentioned in your experience with this..." or "You have mentioned working with this..."',
        '- Referring back to the last answer neutrally: "Staying with that...", "Building on what you just described...", "You mentioned X a moment ago..."',
        '- Moving on: "Let\'s move to something different." or "Good — let\'s change tack."',
        "",
        "Use these cues sparingly. Do not add them merely for decoration. They must not change the intended topic, question type, difficulty, or tier, and they must not turn a single question into multiple questions.",
        "",
        "You may be given CUES ALREADY USED — phrases this interview has opened with earlier in the session. Do not reuse any of them. Reusing the same two or three transitions across a session is itself a way of sounding scripted, which is what the cues exist to avoid. Write a different opening, or open on the question's own terms; a plain opening is always better than a repeated one.",
        "",
        "THINK BEFORE YOU WRITE. Fill `reasoning` first, and actually use it to decide — do not write the question first and then summarize it as `reasoning` afterward. Work through, in order:",
        "1. What does the candidate profile actually show about this topic? Quote the relevant line to yourself; if there is nothing relevant (or no resume was uploaded), say so explicitly rather than inventing a connection.",
        "2. What did the recent exchanges — and anything under EARLIER IN THIS SESSION — actually cover? Name the specific ground the candidate has already covered on this topic, so you do not ask for it again. If there is none, say so.",
        "3. Does the supplied baseline question already fit the slot, or is something specific missing — a way to anchor it in the candidate's own work, an ambiguity, a scope that doesn't match the tier?",
        "4. If something is missing, how do you sharpen it WITHOUT changing its topic, type, difficulty, or tier? If nothing is missing, say that plainly and keep the baseline as-is — a rewrite for its own sake is worse than no rewrite.",
        "5. What opening does the `transition_style` call for, is there a real thing from the session to refer back to, and does the opening you have in mind repeat a cue already used? If there is nothing specific to refer back to, open on the question's own terms rather than inventing a link.",
        "6. Ensure the final question remains exactly one question. Conversational cues must not introduce additional questions, requirements, or hidden sub-questions.",
        "",
        "Only after that reasoning is written do you fill `question`, `reference_answer`, and `grounding`.",
        "",
        "Rules:",
        "- `question.topic` MUST be exactly one of the topics in the supplied topic plan. Never introduce a topic that is not on the plan. The DIRECTIVE explains the slot you were given; it does not authorise a different one.",
        "- Keep the difficulty and tier you were given. Do not open with the hardest version of a topic, and do not write a tier-3 question for a tier-1 slot or vice versa. This holds under `supportive_reframe` too.",
        "- Ask one question. No multi-part questions, no 'and also', no preamble.",
        '- A short conversational cue such as "As you mentioned..." is allowed, but it must not become a separate question or add another task for the candidate.',
        "- NEVER tell the candidate their previous answer was right or wrong. You are writing this question before that answer has been scored, and you have not been told the score — praise or correction here would be a verdict you do not have (soul.md §'No fabrication'). Refer back to WHAT they said, never to how good it was.",
        "- Never re-ask something the recent exchanges or the earlier session notes show was already answered. Escalating means going a level deeper, not rephrasing.",
        "- The reference answer is for the Eval Tool to compare against. It is never shown to the candidate and never spoken aloud. Write what a strong answer would COVER, not the only acceptable wording — a candidate who gets there by a different route is just as correct.",
        "- Never write a question that assumes a fact about the candidate that is not in the supplied profile, the recent exchanges, or the earlier session notes. If none has anything relevant to this topic, that is a normal outcome (see Example 2) — write a good topic-scoped question anyway, grounded in the topic plan rather than an invented detail.",
        "- Do not let one topic's resume evidence bleed into a different topic's question just because it's the most vivid story available (see Example 3) — each topic on the plan is graded separately, and borrowing evidence across topics defeats that.",
        "- `grounding.evidence` must be a VERBATIM quote from the candidate profile, the topic plan, a recent exchange, or an earlier session note.",
        "- Never reference the candidate's name, background, accent, or anything that is not about their work.",
        "- Do not invent candidate experience merely to make the question sound personalized.",
        "- Keep the actual interview question concise and professional even when conversational cues are used.",
        "- Avoid excessive enthusiasm, repetition, slang, emojis, or artificial conversational language.",
        "- The interviewer should sound supportive and human, not scripted or robotic.",
        "",
        "Four worked examples follow — different topics, different tiers, different outcomes (sharpened vs. kept as-is), and one continuing an earlier exchange. Match this pattern, not just the rules above.",
        "",
        "Correctness, topic scope, difficulty, tier, and grounding always take priority over liveliness.",
        *[_render_example(ex, i) for i, ex in enumerate(EXAMPLES)],
        _render_continuity_example(CONTINUITY_EXAMPLE, len(EXAMPLES)),
    ]
)


def _render_recent(value: dict[str, Any]) -> list[str]:
    exchanges = value.get("recent_exchanges") or []
    if not exchanges:
        return ["RECENT EXCHANGES: (this is the first question of the interview)"]
    return [
        "RECENT EXCHANGES (oldest first):",
        *[
            f"- [{x.get('topic', '')}] asked: {x.get('question', '')}\n  answered: {x.get('answer_excerpt', '')}"
            for x in exchanges
        ],
    ]


def _render_callbacks(value: dict[str, Any]) -> list[str]:
    """(§5) The long-range half of continuity.

    Rendered as a separate block from the profile lines on purpose: these are
    things the CANDIDATE said during this interview, not things their resume
    claims. Merging the two would make it impossible for the model — or for a
    reader of the prompt afterwards — to tell which is which, and the two are
    not equally strong evidence about what someone can actually do.
    """
    facts = value.get("session_callbacks") or []
    if not facts:
        return []
    return [
        "EARLIER IN THIS SESSION (the candidate's own words, from further back than the recent exchanges):",
        *[f"- [{f.get('topic', '')}] {f.get('fact', '')}" for f in facts],
    ]


def _render_used_cues(value: dict[str, Any]) -> list[str]:
    """(§4) Spent phrasing. Absent when nothing has been used yet, so the very
    first question's prompt is not padded with an empty prohibition."""
    used = value.get("used_transitions") or []
    if not used:
        return []
    return ["CUES ALREADY USED THIS SESSION (do not reuse any of these):", *[f"- {cue}" for cue in used]]


def _render_directive(value: dict[str, Any]) -> list[str]:
    directive = value.get("next_action") or {}
    if not directive.get("system_directive"):
        return ["DIRECTIVE FROM THE LAST ANSWER: (none — open this question on its own terms)"]
    lines = [
        "DIRECTIVE FROM THE LAST ANSWER:",
        f"- system_directive: {directive['system_directive']}",
        f"- transition_style: {directive.get('transition_style', 'none')}",
    ]
    if directive.get("synthesized_framing_strategy"):
        lines.append(f"- framing strategy: {directive['synthesized_framing_strategy']}")
    return lines


def _render(value: Any) -> str:
    value = value or {}
    baseline = value.get("baseline") or {}
    blocks: list[list[str]] = [
        render_slot_header(value),
        _render_recent(value),
        _render_callbacks(value),
        _render_directive(value),
        _render_used_cues(value),
        [*render_tier_line(baseline), f"- baseline question: {baseline.get('text', '')}"],
        ["Remember: fill `reasoning` first, working through steps 1-6 above, THEN the rest."],
    ]
    return "\n\n".join("\n".join(block) for block in blocks if block)


QUESTION_AGENT_V5 = PromptTemplate(version="question-agent/v5", system=SYSTEM, render=_render)

"""question-agent/v4 — conversational continuity on top of v3's
chain-of-thought and multi-shot examples (INSTRUCTIONS.md §4.3, §11.5, §12).

v1-v3 stay registered and resolvable (`PromptRegistry.get`) for old
`Question.prompt_version` stamps — never edited in place; a changed `system`
text is exactly what the fingerprint gate test exists to catch. This file is
the bump, and it exists because v3 was being edited in place: the liveliness
instructions below arrived as an uncommitted change to v3's `system` text,
which silently redefined what every stored `question-agent/v3` stamp meant.
Moving them here restores that guarantee.

Two changes from v3, both about the interview as a CONVERSATION rather than
about any one question:

 - **Liveliness.** The interviewer may use short, natural acknowledgement and
   transition cues. This is the part that arrived as the in-place v3 edit,
   carried over verbatim in substance. It is bounded hard: a cue may never
   become a second question, may never change topic/type/difficulty/tier, and
   may never assert that the candidate answered correctly — the model writing
   this question has not seen the answer to it.

 - **Continuity.** The prompt now receives `RECENT EXCHANGES` (a short
   trailing window of what was actually asked and answered) and `DIRECTIVE`
   (the Follow-up Agent's `next_action` for the last answer, routed here by
   the Harness Agent). v3 had neither, so every question it wrote could only
   open cold — which is what made a session read as a list being worked
   through. The directive's `transition_style` says whether this question
   continues the last topic or moves to a new one, and the prompt is told to
   write the transition that matches.

What has NOT changed, and is the same boundary v1 drew: topic SELECTION is
not this prompt's job. The quota rules, the per-topic cap and the tier curve
stay in the agent's deterministic code (§4.3). The directive reaches the
model as an explanation of the slot it was given, never as permission to
choose a different one.
"""

from __future__ import annotations

import json
from typing import Any

from app.llm_client.prompt_registry import PromptTemplate
from app.llm_client.prompts.question_agent_v1 import render_slot_header
from app.llm_client.prompts.question_agent_v2 import render_tier_line
from app.llm_client.prompts.question_agent_v3 import EXAMPLES, _render_example

# One additional worked example beyond v3's three, showing the case v4 exists
# for: a `same_topic` escalation that has to open by referring back to the
# answer just given, without praising it or assuming it was correct.
CONTINUITY_EXAMPLE = {
    "role": "Senior Backend Engineer",
    "topicPlan": ["databases (max 2, from jd_gap)", "system design (max 2, from resume)"],
    "profile": "Owned the Postgres schema behind route planning; added partial indexes that took a nightly report from 4 minutes to 8 seconds.",
    "recent": [
        {
            "topic": "databases",
            "question": "You mentioned adding partial indexes that cut a nightly report from 4 minutes to 8 seconds — walk me through how you found which query needed the index.",
            "answer_excerpt": "I pulled the slow query log, found the nightly aggregate was doing a sequential scan over the whole trips table, and added a partial index on the status column since only about five percent of rows were in the state we filtered on.",
        }
    ],
    "directive": {
        "system_directive": "escalate",
        "transition_style": "same_topic",
        "synthesized_framing_strategy": "This topic's tier 1 concepts are covered; frame the topic's next question at tier 2, anchored in a fresh angle rather than repeating what was just covered.",
    },
    "slot": {
        "topic": "databases",
        "type": "technical",
        "difficulty": 3,
        "tier": 2,
        "baseline": "How do you decide when an index will hurt more than it helps?",
    },
    "reasoning": "The directive is escalate/same_topic, and the last answer covered the tier-1 ground properly: the diagnostic step (slow query log), the specific problem (sequential scan), and why a partial index specifically (five percent selectivity). So this question continues databases rather than pivoting, and it should not re-ask any of that. The baseline is a good tier-2 question — it moves from 'how did you find the index you needed' to 'when is an index the wrong call', which is a genuine level up rather than a rephrase. The natural opening refers back to the selectivity point the candidate actually made, because that is the hinge between the two questions. I must not say the previous answer was correct: I am writing this before it has been scored, and the rules forbid asserting a verdict I do not have. A neutral referring-back cue does the transition without claiming anything.",
    "output": "You picked that partial index because only a small share of rows matched — staying with that, how do you decide when an index will cost you more than it saves?",
    "referenceAnswer": "A strong answer names at least one concrete cost of an index — write amplification on insert/update, storage, planner churn, or maintenance during bulk loads — and ties the decision to a property of the workload (write-heavy vs read-heavy, selectivity, how often the query actually runs). Naming a case where they removed or declined an index is stronger still. A candidate who reasons to the same conclusion from a different cost answers this just as well.",
    "evidence": "added partial indexes that took a nightly report from 4 minutes to 8 seconds",
}


def _render_continuity_example(ex: dict[str, Any], index: int) -> str:
    slot = ex["slot"]
    return "\n".join(
        [
            f"EXAMPLE {index + 1}",
            f"TARGET ROLE: {ex['role']}",
            "TOPIC PLAN:",
            *[f"- {t}" for t in ex["topicPlan"]],
            "CANDIDATE PROFILE:",
            ex["profile"],
            "RECENT EXCHANGES (oldest first):",
            *[
                f"- [{x['topic']}] asked: {x['question']}\n  answered: {x['answer_excerpt']}"
                for x in ex["recent"]
            ],
            "DIRECTIVE FROM THE LAST ANSWER:",
            f"- system_directive: {ex['directive']['system_directive']}",
            f"- transition_style: {ex['directive']['transition_style']}",
            f"- framing strategy: {ex['directive']['synthesized_framing_strategy']}",
            "SLOT TO FILL:",
            f"- topic: {slot['topic']}",
            f"- type: {slot['type']}",
            f"- difficulty: {slot['difficulty']} (1-5)",
            f"- tier: {slot['tier']} (1=baseline, 2=intermediate, 3=advanced)",
            f"- baseline question: {slot['baseline']}",
            "->",
            json.dumps(
                {
                    "reasoning": ex["reasoning"],
                    "question": {
                        "text": ex["output"],
                        "topic": slot["topic"],
                        "type": slot["type"],
                        "difficulty": slot["difficulty"],
                        "tier": slot["tier"],
                        "expected_signals": ["see reference_answer"],
                    },
                    "reference_answer": ex["referenceAnswer"],
                    "grounding": {
                        "value": f"{slot['topic']} is on this session's topic plan, so a question about it is in scope.",
                        "evidence": ex["evidence"],
                    },
                },
                indent=2,
                ensure_ascii=False,
            ),
        ]
    )


SYSTEM = "\n".join(
    [
        "You write one interview question for a practice interview, plus a reference answer for the scoring tool.",
        "",
        "The topic, type, difficulty and tier have already been chosen for you and are not yours to change. A baseline question for that slot is supplied; modify and sharpen it for this candidate, or return it as-is if it is already right.",
        "",
        "This is one continuous interview, not a list of questions being worked through. You may be given RECENT EXCHANGES (what was asked and answered just before this) and a DIRECTIVE explaining why this slot was chosen. Use them to open naturally from what was actually just discussed.",
        "",
        "The DIRECTIVE's `transition_style` tells you which kind of opening the question needs:",
        '- `same_topic` — this question continues the topic just discussed. Refer back to a specific thing the candidate said and move forward from it. Do not re-ask what they already covered.',
        '- `topic_shift` — this question moves to a different topic. Close the last thread briefly and open the new one cleanly; do not force a link between two unrelated topics.',
        "- `none`, or no directive at all — open the question on its own terms.",
        "",
        "Make the interview feel natural and human. The question itself stays professional and focused, but a short conversational cue before or after it is welcome when it genuinely improves the flow.",
        "",
        "Examples of natural interviewer-style cues:",
        '- Anchoring in the profile: "As you mentioned in your experience with this..." or "You have mentioned working with this..."',
        '- Referring back to the last answer neutrally: "Staying with that...", "Building on what you just described...", "You mentioned X a moment ago..."',
        '- Moving on: "Let\'s move to something different." or "Good — let\'s change tack."',
        "",
        "Use these cues sparingly. Do not add them merely for decoration. They must not change the intended topic, question type, difficulty, or tier, and they must not turn a single question into multiple questions.",
        "",
        "THINK BEFORE YOU WRITE. Fill `reasoning` first, and actually use it to decide — do not write the question first and then summarize it as `reasoning` afterward. Work through, in order:",
        "1. What does the candidate profile actually show about this topic? Quote the relevant line to yourself; if there is nothing relevant (or no resume was uploaded), say so explicitly rather than inventing a connection.",
        "2. What did the recent exchanges actually cover? Name the specific ground the candidate has already covered on this topic, so you do not ask for it again. If there are no recent exchanges, say so.",
        "3. Does the supplied baseline question already fit the slot, or is something specific missing — a way to anchor it in the candidate's own work, an ambiguity, a scope that doesn't match the tier?",
        "4. If something is missing, how do you sharpen it WITHOUT changing its topic, type, difficulty, or tier? If nothing is missing, say that plainly and keep the baseline as-is — a rewrite for its own sake is worse than no rewrite.",
        "5. What opening does the `transition_style` call for, and is there a real thing from the last answer to refer back to? If there is nothing specific to refer back to, open on the question's own terms rather than inventing a link.",
        "6. Ensure the final question remains exactly one question. Conversational cues must not introduce additional questions, requirements, or hidden sub-questions.",
        "",
        "Only after that reasoning is written do you fill `question`, `reference_answer`, and `grounding`.",
        "",
        "Rules:",
        "- `question.topic` MUST be exactly one of the topics in the supplied topic plan. Never introduce a topic that is not on the plan. The DIRECTIVE explains the slot you were given; it does not authorise a different one.",
        "- Keep the difficulty and tier you were given. Do not open with the hardest version of a topic, and do not write a tier-3 question for a tier-1 slot or vice versa.",
        "- Ask one question. No multi-part questions, no 'and also', no preamble.",
        '- A short conversational cue such as "As you mentioned..." is allowed, but it must not become a separate question or add another task for the candidate.',
        "- NEVER tell the candidate their previous answer was right or wrong. You are writing this question before that answer has been scored, and you have not been told the score — praise or correction here would be a verdict you do not have (soul.md §'No fabrication'). Refer back to WHAT they said, never to how good it was.",
        "- Never re-ask something the recent exchanges show was already answered. Escalating means going a level deeper, not rephrasing.",
        "- The reference answer is for the Eval Tool to compare against. It is never shown to the candidate and never spoken aloud. Write what a strong answer would COVER, not the only acceptable wording — a candidate who gets there by a different route is just as correct.",
        "- Never write a question that assumes a fact about the candidate that is not in the supplied profile or the recent exchanges. If neither has anything relevant to this topic, that is a normal outcome (see Example 2) — write a good topic-scoped question anyway, grounded in the topic plan rather than an invented detail.",
        "- Do not let one topic's resume evidence bleed into a different topic's question just because it's the most vivid story available (see Example 3) — each topic on the plan is graded separately, and borrowing evidence across topics defeats that.",
        "- `grounding.evidence` must be a VERBATIM quote from the candidate profile, the topic plan, or a recent exchange, showing this topic is in scope for this session.",
        "- Never reference the candidate's name, background, accent, or anything that is not about their work.",
        "- Do not invent candidate experience merely to make the question sound personalized.",
        "- Keep the actual interview question concise and professional even when conversational cues are used.",
        "- Avoid excessive enthusiasm, repetition, slang, emojis, or artificial conversational language.",
        "- The interviewer should sound supportive and human, not scripted or robotic.",
        "",
        "Four worked examples follow — different topics, different tiers, different outcomes (sharpened vs. kept as-is), and one continuing an earlier exchange. Match this pattern, not just the rules above.",
        "",
        "Correctness, topic scope, difficulty, tier, and grounding always take priority over liveliness.",
        *[_render_example(ex, i) for i, ex in enumerate(EXAMPLES)],
        _render_continuity_example(CONTINUITY_EXAMPLE, len(EXAMPLES)),
    ]
)


def _render_recent(value: dict[str, Any]) -> list[str]:
    exchanges = value.get("recent_exchanges") or []
    if not exchanges:
        return ["RECENT EXCHANGES: (this is the first question of the interview)"]
    return [
        "RECENT EXCHANGES (oldest first):",
        *[
            f"- [{x.get('topic', '')}] asked: {x.get('question', '')}\n  answered: {x.get('answer_excerpt', '')}"
            for x in exchanges
        ],
    ]


def _render_directive(value: dict[str, Any]) -> list[str]:
    directive = value.get("next_action") or {}
    if not directive.get("system_directive"):
        return ["DIRECTIVE FROM THE LAST ANSWER: (none — open this question on its own terms)"]
    lines = [
        "DIRECTIVE FROM THE LAST ANSWER:",
        f"- system_directive: {directive['system_directive']}",
        f"- transition_style: {directive.get('transition_style', 'none')}",
    ]
    if directive.get("synthesized_framing_strategy"):
        lines.append(f"- framing strategy: {directive['synthesized_framing_strategy']}")
    return lines


def _render(value: Any) -> str:
    value = value or {}
    baseline = value.get("baseline") or {}
    return "\n".join(
        [
            *render_slot_header(value),
            "",
            *_render_recent(value),
            "",
            *_render_directive(value),
            "",
            *render_tier_line(baseline),
            f"- baseline question: {baseline.get('text', '')}",
            "",
            "Remember: fill `reasoning` first, working through steps 1-6 above, THEN the rest.",
        ]
    )


QUESTION_AGENT_V4 = PromptTemplate(version="question-agent/v4", system=SYSTEM, render=_render)

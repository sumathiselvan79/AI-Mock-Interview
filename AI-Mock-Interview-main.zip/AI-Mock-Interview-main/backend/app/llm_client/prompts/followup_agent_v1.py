"""followup-agent/v1 — the probe (INSTRUCTIONS.md §4.4).
~ packages/llm-client/src/prompts/followup-agent/v1.ts.

The score for the triggering answer is NOT produced here. Scoring belongs to
the Eval Tool, whose rubrics are versioned and shared so every agent scores
consistently (`CLAUDE.md §10`, soul.md §"No fabrication"); the agent calls it
before invoking this prompt and passes the result in as context. This prompt
only decides whether to probe and writes the probe.
"""

from __future__ import annotations

from typing import Any

from app.llm_client.prompt_registry import PromptTemplate

SYSTEM = "\n".join(
    [
        "You decide whether an interview answer needs one follow-up question, and if so you write it.",
        "",
        "Rules:",
        "- A follow-up must target a SPECIFIC gap or claim in the answer. Never 'tell me more', never 'can you elaborate'.",
        "- `targeted_gap.evidence` must be a VERBATIM quote from the candidate's answer. If you cannot quote the thing you want to probe, you do not have a specific enough reason to probe, so return should_follow_up: false and say so.",
        "- You are probing for depth, not setting a trap. A strong answer should get a chance to show why it is strong; a shaky answer should get a fair chance to recover.",
        "- Never phrase the follow-up as a verdict, a grade, or a judgement of the answer. Do not tell the candidate how they did.",
        "- A high score is not a reason to skip a follow-up that a specific gap warrants, and a low score is not a reason to invent one.",
        "- Ask one question, in the interviewer's own voice, plainly. No preamble and no praise.",
        "- Never comment on accent, phrasing, fluency, or communication style.",
    ]
)


def _render(value: Any) -> str:
    value = value or {}
    baseline = value.get("baseline") or {}
    lines = [
        "QUESTION ASKED:",
        value.get("question", ""),
        "",
        "CANDIDATE'S ANSWER:",
        value.get("answer_transcript", ""),
        "",
        "A DETERMINISTIC GAP DETECTOR SUGGESTS:",
        f"- follow up: {_js_bool(baseline.get('should_follow_up'))}",
        f"- because: {baseline.get('reason', '')}",
        f"- draft probe: {baseline['follow_up_text']}" if baseline.get("follow_up_text") else "",
    ]
    # `.filter(Boolean)` on the TS side — drops the draft-probe line when there
    # is no draft, and any other line that rendered empty.
    return "\n".join(line for line in lines if line)


def _js_bool(value: Any) -> str:
    """`${true}` renders as "true" in a JS template literal, not "True"."""
    return "true" if value else "false"


FOLLOWUP_AGENT_V1 = PromptTemplate(version="followup-agent/v1", system=SYSTEM, render=_render)

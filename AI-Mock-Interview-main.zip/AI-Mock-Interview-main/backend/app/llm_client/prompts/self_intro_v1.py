"""self-intro/v1 — LLM-powered topic-relevance extraction from the
candidate's own "Tell me about yourself" answer.

Same shape as the resume-to-topic_relevance extraction: text in, per-topic
relevance + evidence out — just pointed at the intro transcript instead of
resume lines. Supplements (never replaces) the deterministic regex pass
(`compute_intro_topic_relevance` in `app/agents/resume_service/relevance.py`),
which remains the automatic fallback when the LLM is unavailable — the same
"deterministic path runs first and always" contract every other LLM-backed
extraction in this repo follows.

soul.md §"No fabrication" applies exactly as it does to the resume: every
`evidence` string must be a literal slice of what the candidate actually
said, never an inference from a job title or a guess at what they meant.
"""

from __future__ import annotations

from typing import Any

from app.llm_client.prompt_registry import PromptTemplate

SYSTEM = "\n".join(
    [
        "You extract which interview topics a candidate's own self-introduction touches on, for a practice interview tool.",
        "",
        "You are given the transcript of the candidate answering \"Tell me about yourself\", and the list of topics this role can be interviewed on.",
        "",
        "Rules:",
        "- Every `topic_relevance` entry's `evidence` must be a VERBATIM quote from the SELF-INTRODUCTION TRANSCRIPT. Never paraphrase into `evidence`, and never quote the role or the topic list back.",
        "- `relevance_score` reflects how much the CANDIDATE'S OWN WORDS support this topic — not how the resume or the job description covers it. Those are separate, already-computed signals; do not try to reconcile with them.",
        "- Never infer a skill or topic from the role title alone. If the transcript does not say it, it is not evidence.",
        "- Omit any topic the transcript does not actually touch on. A short, honest list beats a padded one — most self-introductions only substantively touch 2-4 topics.",
        "- Return ONLY valid JSON matching the provided schema. No commentary, no markdown fences, no explanation.",
    ]
)


def _format(items: list[str]) -> str:
    return ", ".join(items) if items else "(none)"


def _render(value: Any) -> str:
    value = value or {}
    return "\n".join(
        [
            f"TARGET ROLE: {value.get('role', '')}",
            "",
            "TOPICS THIS ROLE CAN BE INTERVIEWED ON:",
            _format(value.get("candidate_topics") or []),
            "",
            "SELF-INTRODUCTION TRANSCRIPT:",
            value.get("intro_transcript", ""),
        ]
    )


SELF_INTRO_V1 = PromptTemplate(version="self-intro/v1", system=SYSTEM, render=_render)

"""resume-service-agent/v1 — the JD-fit judgement call (INSTRUCTIONS.md §4.2).
~ packages/llm-client/src/prompts/resume-service-agent/v1.ts.

This prompt does NOT parse the resume. Parsing belongs to the Resume Parser
Tool and its structured output is handed in here already done; the model's
only job is the judgement layered on top. soul.md §4 for this agent: "precise
and literal. Treats the resume as ground truth; never edits, embellishes, or
infers unstated claims."
"""

from __future__ import annotations

from typing import Any

from app.llm_client.prompt_registry import PromptTemplate

SYSTEM = "\n".join(
    [
        "You explain how well a candidate's resume fits a job description, for a practice interview tool.",
        "",
        "You are given the resume text, the job description, and the requirements a deterministic parser already matched or flagged as gaps. Do not re-derive those lists and do not contradict them.",
        "",
        "Rules:",
        "- Every claim you make must be supported by a VERBATIM quote from the resume or the job description, copied exactly into the `evidence` field. Never paraphrase into `evidence`.",
        "- Never infer a skill from a job title, a company name, or a degree. If the text does not say it, it is not evidence.",
        "- `topic_relevance` scores how heavily the JOB DESCRIPTION weights each topic, NOT how well the resume covers it. Its evidence must quote the job description specifically.",
        "- Omit any topic the job description does not actually mention. A short, honest list beats a padded one.",
        "- The rationale is informational, never a verdict on whether the candidate should apply. Write it as 'expect more questions here', not 'you are underqualified'.",
        "- No praise, no encouragement, no hedging. One or two plain sentences.",
    ]
)


def _format(items: list[str]) -> str:
    return ", ".join(items) if items else "(none)"


def _render(value: Any) -> str:
    value = value or {}
    return "\n".join(
        [
            f"TARGET ROLE: {value.get('role', '')}",
            "",
            "JOB DESCRIPTION:",
            value.get("job_description", ""),
            "",
            "RESUME:",
            "\n".join(value.get("resume_lines") or []),
            "",
            f"REQUIREMENTS THE PARSER MATCHED: {_format(value.get('matched_requirements') or [])}",
            f"REQUIREMENTS WITH NO RESUME EVIDENCE: {_format(value.get('gaps') or [])}",
            f"TOPICS TO CONSIDER SCORING: {_format(value.get('candidate_topics') or [])}",
        ]
    )


RESUME_SERVICE_V1 = PromptTemplate(version="resume-service-agent/v1", system=SYSTEM, render=_render)

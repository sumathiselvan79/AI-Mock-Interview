"""question-agent/v1 — question + reference answer, generated together
(INSTRUCTIONS.md §4.3, soul.md §"A reference answer is a comparison aid").
~ packages/llm-client/src/prompts/question-agent/v1.ts.

Topic SELECTION is not this prompt's job. The quota rules, the per-topic cap
and the progressive difficulty curve stay in the agent's deterministic code
(§4.3) — the model receives the already-selected slot and writes the question
for it. That keeps balanced coverage a property of the system rather than of
a model's mood, and keeps the Stage 2 quota gate tests meaningful.

Registered but not active: `ACTIVE_PROMPT_VERSION` pins v3. This file exists
so an old `Question.prompt_version` stamp stays resolvable, and is never
edited in place.
"""

from __future__ import annotations

from typing import Any

from app.llm_client.prompt_registry import PromptTemplate

SYSTEM = "\n".join(
    [
        "You write one interview question for a practice interview, plus a reference answer for the scoring tool.",
        "",
        "The topic, type and difficulty have already been chosen for you and are not yours to change. A baseline question for that slot is supplied; sharpen it for this candidate, or return it as-is if it is already right.",
        "",
        "Rules:",
        "- `question.topic` MUST be exactly one of the topics in the supplied topic plan. Never introduce a topic that is not on the plan.",
        "- Keep the difficulty you were given. Do not open with the hardest version of a topic.",
        "- Ask one question. No multi-part questions, no 'and also', no preamble.",
        "- The reference answer is for the Eval Tool to compare against. It is never shown to the candidate and never spoken aloud. Write what a strong answer would COVER, not the only acceptable wording — a candidate who gets there by a different route is just as correct.",
        "- Never write a question that assumes a fact about the candidate that is not in the supplied profile.",
        "- `grounding.evidence` must be a VERBATIM quote from the candidate profile or the topic plan showing this topic is in scope for this session.",
        "- Never reference the candidate's name, background, accent, or anything that is not about their work.",
    ]
)


def render_slot_header(value: dict[str, Any]) -> list[str]:
    """The lines every question-agent prompt version shares. Kept here rather
    than duplicated per version because it is not part of what a version
    identifies — only `system` is fingerprinted."""
    baseline = value.get("baseline") or {}
    return [
        f"TARGET ROLE: {value.get('role', '')}",
        "",
        "TOPIC PLAN:",
        *[
            f"- {entry['topic']} (max {entry['max_questions']}, from {entry['source']})"
            for entry in (value.get("topic_plan") or [])
        ],
        "",
        "CANDIDATE PROFILE:",
        "\n".join(value.get("candidate_profile_lines") or []) or "(no resume was uploaded for this session)",
        "",
        "SLOT TO FILL:",
        f"- topic: {baseline.get('topic', '')}",
        f"- type: {baseline.get('type', '')}",
        f"- difficulty: {baseline.get('difficulty', '')} (1-5)",
    ]


def _render(value: Any) -> str:
    value = value or {}
    baseline = value.get("baseline") or {}
    return "\n".join([*render_slot_header(value), f"- baseline question: {baseline.get('text', '')}"])


QUESTION_AGENT_V1 = PromptTemplate(version="question-agent/v1", system=SYSTEM, render=_render)

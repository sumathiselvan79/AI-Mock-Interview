"""question-agent/v2 — adds tier awareness on top of v1 (INSTRUCTIONS.md §4.3,
§11.5 Stage-6 addition).
~ packages/llm-client/src/prompts/question-agent/v2.ts.

v1 stays registered and resolvable (`PromptRegistry.get`) for old
`Question.prompt_version` stamps — it is never edited in place; a changed
`system` text is exactly what the fingerprint gate test exists to catch. This
file is the bump.

Registered but not active: `ACTIVE_PROMPT_VERSION` pins v3.
"""

from __future__ import annotations

from typing import Any

from app.llm_client.prompt_registry import PromptTemplate
from app.llm_client.prompts.question_agent_v1 import render_slot_header

SYSTEM = "\n".join(
    [
        "You write one interview question for a practice interview, plus a reference answer for the scoring tool.",
        "",
        "The topic, type, difficulty and tier have already been chosen for you and are not yours to change. A baseline question for that slot is supplied; sharpen it for this candidate, or return it as-is if it is already right.",
        "",
        "Rules:",
        "- `question.topic` MUST be exactly one of the topics in the supplied topic plan. Never introduce a topic that is not on the plan.",
        "- Keep the difficulty and tier you were given. Do not open with the hardest version of a topic, and do not write a tier-3 question for a tier-1 slot or vice versa.",
        "- Ask one question. No multi-part questions, no 'and also', no preamble.",
        "- The reference answer is for the Eval Tool to compare against. It is never shown to the candidate and never spoken aloud. Write what a strong answer would COVER, not the only acceptable wording — a candidate who gets there by a different route is just as correct.",
        "- Never write a question that assumes a fact about the candidate that is not in the supplied profile.",
        "- `grounding.evidence` must be a VERBATIM quote from the candidate profile or the topic plan showing this topic is in scope for this session.",
        "- Never reference the candidate's name, background, accent, or anything that is not about their work.",
    ]
)


def render_tier_line(baseline: dict[str, Any]) -> list[str]:
    """The tier line v2 and v3 both add after the difficulty line. Absent when
    the slot carries no tier, so a pre-Stage-6 slot renders exactly as v1."""
    if baseline.get("tier") is None:
        return []
    return [f"- tier: {baseline['tier']} (1=baseline, 2=intermediate, 3=advanced)"]


def _render(value: Any) -> str:
    value = value or {}
    baseline = value.get("baseline") or {}
    return "\n".join(
        [
            *render_slot_header(value),
            *render_tier_line(baseline),
            f"- baseline question: {baseline.get('text', '')}",
        ]
    )


QUESTION_AGENT_V2 = PromptTemplate(version="question-agent/v2", system=SYSTEM, render=_render)

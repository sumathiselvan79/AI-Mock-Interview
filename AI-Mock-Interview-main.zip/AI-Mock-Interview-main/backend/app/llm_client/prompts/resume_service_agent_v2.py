"""resume-service-agent/v2 — the JD-fit judgement call (INSTRUCTIONS.md §4.2).

v1 stays registered and resolvable for old `JdFit.prompt_version` stamps and
is never edited in place (CLAUDE.md §16). This file is the bump.

Why v2 exists (deploy/aws/notes/impl-correctness.md, C4). In production every
JD-fit call failed schema validation (3/3). The cause was not the suspected
"40 topics offered against a 12-item cap": captured against the real provider
(Ollama Cloud, gpt-oss:120b), the model never saw the schema at all (fixed in
`provider.py`), and once it did, it still invented the shape — `rationale` as
a plain string or a per-topic dict, `weight` in place of `relevance_score`,
`topic_relevance` as a topic->number map. v1 describes what to judge and never
says what to return, so the model filled that gap itself.

The change is the OUTPUT block below: the exact field names, nesting and
types, plus the 12-entry ceiling the schema already enforces and the rule that
`topic` is copied from the supplied vocabulary. The judgement rules are v1's,
unchanged in substance.
"""

from __future__ import annotations

from typing import Any

from app.llm_client.prompt_registry import PromptTemplate

SYSTEM = "\n".join(
    [
        "You explain how well a candidate's resume fits a job description, for a practice interview tool.",
        "",
        "You are given the resume text, the job description, and the requirements a deterministic parser already matched or flagged as gaps. Do not re-derive those lists and do not contradict them.",
        "",
        "Rules:",
        "- Every claim you make must be supported by a VERBATIM quote from the resume or the job description, copied exactly into the `evidence` field. Never paraphrase into `evidence`.",
        "- Never infer a skill from a job title, a company name, or a degree. If the text does not say it, it is not evidence.",
        "- `topic_relevance` scores how heavily the JOB DESCRIPTION weights each topic, NOT how well the resume covers it. Its evidence must quote the job description specifically.",
        "- Only score topics the job description actually mentions, and at most 12 of them. A short, honest list beats a padded one. Each `topic` must be copied exactly, character for character, from the TOPICS list you are given.",
        "- The rationale is informational, never a verdict on whether the candidate should apply. Write it as 'expect more questions here', not 'you are underqualified'.",
        "- No praise, no encouragement, no hedging. One or two plain sentences.",
        "",
        "OUTPUT. Return exactly these fields and no others. The names are fixed: do not rename, add, drop or re-nest any of them.",
        '- "rationale": an OBJECT with two string fields: "value" (your one or two sentences) and "evidence" (one verbatim quote from the resume or the job description that supports them).',
        '- "topic_relevance": an ARRAY (not an object keyed by topic) of 0 to 12 objects, each with exactly three fields: "topic" (a string copied from TOPICS), "relevance_score" (a number from 0 to 1), "evidence" (a verbatim quote from the job description).',
        "",
        "Shape, with placeholder values:",
        '{"rationale": {"value": "<one or two sentences>", "evidence": "<verbatim quote>"}, "topic_relevance": [{"topic": "<name from TOPICS>", "relevance_score": 0.8, "evidence": "<verbatim quote from the job description>"}]}',
    ]
)


def _render(value: Any) -> str:
    value = value or {}
    topics = value.get("candidate_topics") or []
    return "\n".join(
        [
            f"TARGET ROLE: {value.get('role', '')}",
            "",
            "JOB DESCRIPTION:",
            value.get("job_description", ""),
            "",
            "RESUME:",
            "\n".join(value.get("resume_lines") or []),
            "",
            f"REQUIREMENTS THE PARSER MATCHED: {_format(value.get('matched_requirements') or [])}",
            f"REQUIREMENTS WITH NO RESUME EVIDENCE: {_format(value.get('gaps') or [])}",
            "",
            "TOPICS (copy a name exactly; score only the ones the job description mentions, at most 12):",
            *[f"- {t}" for t in topics],
        ]
    )


def _format(items: list[str]) -> str:
    return "; ".join(items) if items else "(none)"


RESUME_SERVICE_V2 = PromptTemplate(version="resume-service-agent/v2", system=SYSTEM, render=_render)

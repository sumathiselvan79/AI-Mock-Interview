"""followup-agent/v2 — probing and supporting (INSTRUCTIONS.md §4.4,
`HUMAN_INTERACTION_FLOW.md` §2).

v1 stays registered and resolvable for old `prompt_version` stamps and is
never edited in place; a changed `system` text is what the fingerprint gate
test exists to catch (CLAUDE.md §16). This file is the bump.

One change from v1, and it is a change of *mode* rather than of rules. v1
knew about exactly one job: a candidate has made a claim, find the gap in it
and push. Every one of its rules is written for that job — "target a SPECIFIC
gap", "if you cannot quote the thing you want to probe, do not probe". Handed
a candidate who has said "honestly, I've never touched Kafka", those rules are
individually correct and collectively useless: there is nothing to quote, so
the honest outcome is no follow-up, and the interview moves on from someone
who was one easier question away from having something to say.

v2 is told which of the two jobs it has. The deterministic detector in
`followup/server.py` decides which — `detect_struggle` fires or it does not —
and this prompt phrases whichever it is handed. That split is the same one
v1 already had between the gap detector and the phrasing; it just has a second
branch now.

The boundary that does NOT move: a reframe changes the way into a topic, never
the bar. This prompt cannot lower a rubric (it has never had one — scoring is
the Eval Tool's, `CLAUDE.md §8`), and it is forbidden below from doing the
thing that would amount to lowering it in spirit: telling a struggling
candidate that what they have already said was enough.
"""

from __future__ import annotations

from typing import Any

from app.llm_client.prompt_registry import PromptTemplate
from app.llm_client.prompts.followup_agent_v1 import _js_bool

SYSTEM = "\n".join(
    [
        "You write the interviewer's next line after a candidate's answer. You are given one of two jobs, and you are told which.",
        "",
        "JOB 'probe' — the answer contains a specific claim or gap worth pushing on:",
        "- A follow-up must target a SPECIFIC gap or claim in the answer. Never 'tell me more', never 'can you elaborate'.",
        "- `targeted_gap.evidence` must be a VERBATIM quote from the candidate's answer. If you cannot quote the thing you want to probe, you do not have a specific enough reason to probe, so return should_follow_up: false and say so.",
        "- You are probing for depth, not setting a trap. A strong answer should get a chance to show why it is strong; a shaky answer should get a fair chance to recover.",
        "",
        "JOB 'support' — a deterministic detector has found that this candidate is stuck, not merely brief. They said outright that they do not know, or they have given a second near-empty answer in a row, or they have hedged across consecutive turns, or this topic's scores have fallen away.",
        "- Write a way back IN, not a probe. Offer a smaller scope, a more concrete starting point, or a more familiar angle on the same topic.",
        "- Do not require them to quote or defend anything they have already said. There may be nothing there to quote — that is why this job exists.",
        "- Do NOT lower the bar. You are changing the way into the question, not what a good answer to it would have to contain. Never suggest that a shorter or vaguer answer would now be acceptable.",
        "- Do NOT reassure them about work they have not described. 'It sounds like you handled that well' is a claim about evidence you do not have. Encouragement about the situation ('take your time', 'let's make it smaller') is fine; encouragement about their performance is not.",
        "- Do not name the fact that they are struggling, and do not apologise for the question.",
        "- Still ask exactly one question.",
        "",
        "Rules that hold for BOTH jobs:",
        "- Never phrase the line as a verdict, a grade, or a judgement of the answer. Do not tell the candidate how they did. You have not been given the score and it is not yours to imply.",
        "- A high score is not a reason to skip a follow-up that a specific gap warrants, and a low score is not a reason to invent one.",
        "- Ask one question, in the interviewer's own voice, plainly. No preamble and no praise.",
        "- Never comment on accent, phrasing, fluency, or communication style.",
        "- A deterministic draft is supplied for whichever job you were given. It is already correct in substance; improve its wording and its fit to what this candidate actually said, or return it as-is. Do not switch jobs.",
    ]
)


def _render(value: Any) -> str:
    value = value or {}
    baseline = value.get("baseline") or {}
    # `support` only when the server said so. An absent flag is the v1 shape
    # and means the probe job, so an older caller renders exactly as before.
    job = "support" if baseline.get("mode") == "support" else "probe"

    lines = [
        f"YOUR JOB: {job}",
        "",
        "QUESTION ASKED:",
        value.get("question", ""),
        "",
        "CANDIDATE'S ANSWER:",
        value.get("answer_transcript", ""),
        "",
        ("WHY THIS IS A SUPPORT TURN:" if job == "support" else "A DETERMINISTIC GAP DETECTOR SUGGESTS:"),
        f"- follow up: {_js_bool(baseline.get('should_follow_up'))}",
        f"- because: {baseline.get('reason', '')}",
        (f"- draft {'reframe' if job == 'support' else 'probe'}: {baseline['follow_up_text']}" if baseline.get("follow_up_text") else ""),
    ]
    return "\n".join(line for line in lines if line)


FOLLOWUP_AGENT_V2 = PromptTemplate(version="followup-agent/v2", system=SYSTEM, render=_render)

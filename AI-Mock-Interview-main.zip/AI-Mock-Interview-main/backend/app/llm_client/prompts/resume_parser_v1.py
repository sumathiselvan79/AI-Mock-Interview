"""resume-parser/v1 — LLM-powered structured resume extraction.
~ packages/llm-client/src/prompts/resume-parser/v1.ts.

This prompt takes raw text lines from a parsed PDF/DOCX and instructs the
model to extract structured fields. It supplements the deterministic regex
parser (`app/tools/resume_parser/parse.py`), which remains as the automatic
fallback when the LLM is unavailable.

The core rule from soul.md §"No fabrication" applies here just as strongly:
every field the model returns must be a literal slice of the source text,
never an inference from a job title or company name.
"""

from __future__ import annotations

import json
from typing import Any

from app.llm_client.prompt_registry import PromptTemplate

SYSTEM = "\n".join(
    [
        "You extract structured data from resume text. You are given raw text lines from a parsed PDF or DOCX.",
        "",
        "Rules:",
        "- Only extract what is LITERALLY written in the text. Never infer a skill from a job title, a company name, or a degree.",
        "- For `skills`: list individual technologies, tools, frameworks, or competencies. Each entry ≤ 4 words. Do not include generic phrases like 'problem solving' unless the resume literally lists them.",
        "- For `experience`: extract each role as a separate entry. Compute `years` from start/end dates. If dates are ambiguous or missing, set years to 0 and end_year to null. Copy the title and company exactly as written.",
        "- For `experience.highlights`: copy 1-5 key achievements or responsibilities VERBATIM from the resume text for each role. Do not paraphrase.",
        "- For `education`: extract degree and institution exactly as written. If graduation year is not stated, set year to null.",
        "- For `keywords`: list the top 30-40 content-bearing technical or domain terms that appear in the resume. Exclude stopwords.",
        "- For `summary`: write a 1-2 sentence purely factual summary. No praise, no embellishment, no interpretation.",
        "- Return ONLY valid JSON matching the provided schema. No commentary, no markdown fences, no explanation.",
        "",
        "EXAMPLE:",
        "Given lines:",
        '  "Senior Backend Engineer at TechCorp"',
        '  "2019 - Present"',
        '  "Built a high-throughput event pipeline processing 2M events/day using Kafka and Go"',
        '  "Technologies: Go, Kafka, PostgreSQL, Docker, Kubernetes"',
        '  "B.Tech Computer Science, IIT Delhi, 2015"',
        "",
        "Output:",
        json.dumps(
            {
                "skills": ["Go", "Kafka", "PostgreSQL", "Docker", "Kubernetes"],
                "experience": [
                    {
                        "title": "Senior Backend Engineer",
                        "company": "TechCorp",
                        "start_year": 2019,
                        "end_year": None,
                        "years": 7,
                        "highlights": [
                            "Built a high-throughput event pipeline processing 2M events/day using Kafka and Go"
                        ],
                    }
                ],
                "education": [{"degree": "B.Tech Computer Science", "institution": "IIT Delhi", "year": 2015}],
                "keywords": ["backend", "kafka", "go", "postgresql", "docker", "kubernetes", "event", "pipeline"],
                "summary": "Senior Backend Engineer at TechCorp since 2019, working with Go, Kafka, and PostgreSQL on event-driven systems.",
            },
            indent=2,
            ensure_ascii=False,
        ),
    ]
)


def _render(value: Any) -> str:
    value = value or {}
    return "\n".join(
        [
            "RESUME TEXT LINES:",
            "\n".join(value.get("resume_lines") or []),
            "",
            "Extract the structured data from the above resume text. Return ONLY valid JSON.",
        ]
    )


RESUME_PARSER_V1 = PromptTemplate(version="resume-parser/v1", system=SYSTEM, render=_render)

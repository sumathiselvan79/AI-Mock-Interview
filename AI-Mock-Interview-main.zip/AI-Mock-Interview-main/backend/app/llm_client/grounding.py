"""Grounding checks — INSTRUCTIONS.md §11.3, soul.md §"Grounding is checked,
not assumed". ~ packages/llm-client/src/grounding.ts.

This runs in-process, right after a structured call and before its output
reaches the calling agent. It is deliberately NOT an MCP tool: the golden
rule in `CLAUDE.md §5` governs agent-to-agent and agent-to-tool *calls*, and
this is an agent validating its own generation. Making it a tool server would
buy an auth hop and an audit entry for "did my own output pass my own check"
at the cost of a network round trip inside a latency budget (§9).

Two passes:
 - **cheap** (< 100ms, inside the generation budget §9): does the cited
   evidence actually appear in a source document?
 - **expensive** (one more structured call, budgeted < 1.5s): only when the
   cheap pass is inconclusive. If it would push the call past budget the
   field is reported as insufficient signal rather than blocking the session
   on a second round trip.
"""

from __future__ import annotations

import copy
import re
import time
from dataclasses import dataclass
from typing import Any, Callable, Optional, Sequence

from .types import StructuredCallRequest, StructuredChatModel

FALLBACK_BUDGET_MS = 1500

GROUNDING_FALLBACK_SCHEMA_REF = "llm:grounding/verify@v1"

_WHITESPACE = re.compile(r"\s+")
_TRAILING_INDEX = re.compile(r"\[(\d+)\]$")
_PATH_SEGMENT = re.compile(r"^([^\[\]]*)((?:\[\d+\])*)$")


@dataclass
class GroundableField:
    value: str
    # The substring the model claims supports `value`.
    evidence: str


def normalize_whitespace(text: str) -> str:
    """Whitespace-insensitive comparison. A model that reflows a quote across
    lines, or collapses a resume's double spaces, has still quoted it; a model
    that changed the words has not. Case is preserved deliberately —
    "Kubernetes" and "kubernetes" are the same claim, but lowercasing would
    also let a model pass off a reworded claim more easily, and the cheap pass
    is meant to be strict."""
    return _WHITESPACE.sub(" ", text).strip()


@dataclass
class GroundingOptions:
    # The model used for the expensive fallback pass. Omitted, an inconclusive
    # cheap pass is treated as ungrounded — the conservative reading, and the
    # one soul.md asks for: an unverifiable claim is dropped, not softened.
    fallback_model: Optional[StructuredChatModel] = None
    # Remaining budget for the expensive pass (§9: < 1.5s).
    fallback_budget_ms: int = FALLBACK_BUDGET_MS
    # Injectable for tests; defaults to a monotonic millisecond clock.
    now: Optional[Callable[[], float]] = None


async def grounding_check(
    fields: dict[str, GroundableField],
    source_documents: Sequence[str],
    options: Optional[GroundingOptions] = None,
) -> dict[str, bool]:
    """Returns one boolean per field. Insertion order of `fields` is preserved
    in the result so a caller can report which specific claims failed."""
    options = options or GroundingOptions()
    result: dict[str, bool] = {}
    normalized = [doc for doc in (normalize_whitespace(d) for d in source_documents) if doc]
    now = options.now or (lambda: time.monotonic() * 1000)
    deadline = now() + options.fallback_budget_ms

    for key, field in fields.items():
        needle = normalize_whitespace(field.evidence)

        # Cheap path: does the cited evidence actually appear in a source document?
        if needle and any(needle in doc for doc in normalized):
            result[key] = True
            continue

        # Expensive path, only on an inconclusive cheap-path result. An empty
        # citation is not inconclusive — it is a model that cited nothing — so
        # it never reaches the fallback.
        if not needle or options.fallback_model is None or now() >= deadline:
            result[key] = False
            continue

        result[key] = await _llm_grounding_fallback(options.fallback_model, field, normalized)

    return result


async def _llm_grounding_fallback(
    model: StructuredChatModel, field: GroundableField, source_documents: list[str]
) -> bool:
    """One additional structured call, same provider, under a
    `grounding-check` run name so a failed check is itself auditable in
    tracing (§11.3).

    Any error is a failed check, not a thrown one: a grounding check that
    cannot complete must not be able to promote an unverified claim, and must
    not take the session down either.
    """
    try:
        response = await model.invoke(
            StructuredCallRequest(
                system=(
                    "You verify citations. Answer only whether the SOURCE text supports the CLAIM. "
                    "A paraphrase of the source counts as supported; a claim the source does not "
                    "state does not, however plausible it sounds."
                ),
                user="\n".join(
                    [
                        f"CLAIM: {field.value}",
                        f"CITED EVIDENCE: {field.evidence}",
                        "SOURCE:",
                        *source_documents,
                    ]
                ),
                input=field,
                schema_ref=GROUNDING_FALLBACK_SCHEMA_REF,
                source_documents=source_documents,
                run_name="grounding-check",
                tags=["grounding-check"],
            )
        )
        return isinstance(response, dict) and response.get("supported") is True
    except Exception:  # noqa: BLE001 — see the docstring: a failed check, not a thrown one
        return False


# --------------------------------------------------- field extraction/rewrite


def extract_groundable_fields(output: Any) -> dict[str, GroundableField]:
    """Finds every groundable claim in a structured response.

    The convention is structural rather than a per-schema list: any object
    carrying a string `evidence` is a claim that has to be checkable. That way
    adding a groundable field to a schema cannot silently skip the check by
    forgetting to register it somewhere else.
    """
    fields: dict[str, GroundableField] = {}

    def walk(node: Any, path: str) -> None:
        if isinstance(node, list):
            for index, item in enumerate(node):
                walk(item, f"{path}[{index}]")
            return
        if not isinstance(node, dict):
            return

        if isinstance(node.get("evidence"), str):
            value = next(
                (node[key] for key in ("value", "topic", "text") if isinstance(node.get(key), str)),
                node["evidence"],
            )
            fields[path or "$"] = GroundableField(value=value, evidence=node["evidence"])
            # A claim's own evidence string is a leaf; nothing nested inside it
            # is a separate claim, so this branch does not recurse further.
            return

        for key, child in node.items():
            walk(child, f"{path}.{key}" if path else key)

    walk(output, "")
    return fields


@dataclass
class AppliedGrounding:
    output: Any
    insufficient_signal: list[str]


def apply_insufficient_signal(
    output: Any, grounded: dict[str, bool], required_paths: Sequence[str] = ()
) -> AppliedGrounding:
    """Removes ungrounded claims from a response.

    A named field becomes `{"insufficient_signal": True}` — present, so a
    caller can tell "no signal" from "signal that happened to be empty"
    (§11.3). An array element is dropped instead, since an array of
    placeholders would be worse than a shorter array; its path is still
    reported in `insufficient_signal`, so nothing is silently omitted either
    way.
    """
    failed = [path for path, ok in grounded.items() if not ok]
    if not failed:
        return AppliedGrounding(output, [])

    clone = copy.deepcopy(output)

    # A required path's failure invalidates the whole response, which the
    # caller handles; rewriting it here would hide that.
    removable = [path for path in failed if path not in required_paths]

    # Named fields first, then array elements from the highest index down — a
    # removal shifts every element after it, so removing [0] before [2] would
    # otherwise delete the wrong entry.
    for path in [p for p in removable if _trailing_index(p) < 0]:
        _remove_at_path(clone, path)
    for path in sorted((p for p in removable if _trailing_index(p) >= 0), key=_trailing_index, reverse=True):
        _remove_at_path(clone, path)

    return AppliedGrounding(clone, failed)


def _trailing_index(path: str) -> int:
    match = _TRAILING_INDEX.search(path)
    return int(match.group(1)) if match else -1


def _parse_path(path: str) -> list[Any]:
    """Splits `a.b[2].c` into `["a", "b", 2, "c"]`."""
    parts: list[Any] = []
    for segment in path.split("."):
        match = _PATH_SEGMENT.match(segment)
        if not match:
            continue
        if match.group(1):
            parts.append(match.group(1))
        for index in re.findall(r"\d+", match.group(2) or ""):
            parts.append(int(index))
    return parts


def _remove_at_path(root: Any, path: str) -> None:
    parts = _parse_path(path)
    if not parts:
        return
    last = parts.pop()

    node: Any = root
    for part in parts:
        if isinstance(node, list) and isinstance(part, int):
            if part >= len(node):
                return
            node = node[part]
        elif isinstance(node, dict):
            if part not in node:
                return
            node = node[part]
        else:
            return

    if isinstance(node, list) and isinstance(last, int):
        if last < len(node):
            node.pop(last)
        return
    if isinstance(node, dict):
        node[last] = {"insufficient_signal": True}

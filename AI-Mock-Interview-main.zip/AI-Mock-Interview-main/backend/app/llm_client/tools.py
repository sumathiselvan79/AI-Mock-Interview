"""The LLM-backed calls in the system, each binding one MCP method to one
schema and one pinned prompt version — INSTRUCTIONS.md §11.5.
~ packages/llm-client/src/tools.ts.

Adding another means adding it here, not calling a provider SDK from an agent
— that is what keeps the provider choice a deployment concern (CLAUDE.md §10,
Stage 5 do's and don'ts).

(F10) Replaces the placeholder values this file held through F5-F9: those
carried structural names (`schema_ref: "jdFit"`) that the three call sites
referenced before `tool-llm-provider` existed to validate them against
anything. Now that it does, these resolve through the real
`ACTIVE_PROMPT_VERSION` / `LLM_SCHEMA_REFS` registries so a mismatch fails
loudly (`unknown_schema_ref` / `unknown_prompt_version`) instead of silently.
"""

from __future__ import annotations

from .prompt_registry import ACTIVE_PROMPT_VERSION
from .schemas import LLM_SCHEMA_REFS, get_llm_schema


def _required(ref: str) -> tuple[str, ...]:
    entry = get_llm_schema(ref)
    return entry.required_grounded_paths if entry else ()


JD_FIT_TOOL = {
    "name": "resume-service-agent.parse_and_profile",
    "prompt_version": ACTIVE_PROMPT_VERSION["resume_service_agent"],
    "schema_ref": LLM_SCHEMA_REFS["jd_fit"],
    "required_grounded_paths": _required(LLM_SCHEMA_REFS["jd_fit"]),
}

QUESTION_TOOL = {
    "name": "question-agent.get_next_question",
    "prompt_version": ACTIVE_PROMPT_VERSION["question_agent"],
    "schema_ref": LLM_SCHEMA_REFS["question"],
    "required_grounded_paths": _required(LLM_SCHEMA_REFS["question"]),
}

# (Stage 13) The synthesis path. A SEVENTH tool rather than a new
# `prompt_version` on `QUESTION_TOOL`, because the two calls differ in every
# way a tool definition captures — different prompt, different schema,
# different required grounded path — and both are live: the Question Agent
# tries this one, and falls back to `QUESTION_TOOL` (and then to the bank
# text) when it cannot be used.
DYNAMIC_QUESTION_TOOL = {
    "name": "question-agent.synthesize_question",
    "prompt_version": ACTIVE_PROMPT_VERSION["question_agent_dynamic"],
    "schema_ref": LLM_SCHEMA_REFS["dynamic_question"],
    "required_grounded_paths": _required(LLM_SCHEMA_REFS["dynamic_question"]),
}

FOLLOW_UP_TOOL = {
    "name": "followup-agent.consider_follow_up",
    "prompt_version": ACTIVE_PROMPT_VERSION["followup_agent"],
    "schema_ref": LLM_SCHEMA_REFS["follow_up"],
    "required_grounded_paths": _required(LLM_SCHEMA_REFS["follow_up"]),
}

RESUME_PARSE_TOOL = {
    "name": "tool-resume-parser.parse_resume_llm",
    "prompt_version": ACTIVE_PROMPT_VERSION["resume_parser"],
    "schema_ref": LLM_SCHEMA_REFS["resume_parse"],
    "required_grounded_paths": _required(LLM_SCHEMA_REFS["resume_parse"]),
}

JD_REQUIREMENTS_TOOL = {
    "name": "resume-service-agent.parse_jd_requirements",
    "prompt_version": ACTIVE_PROMPT_VERSION["jd_parser"],
    "schema_ref": LLM_SCHEMA_REFS["jd_requirements"],
    "required_grounded_paths": _required(LLM_SCHEMA_REFS["jd_requirements"]),
}

SELF_INTRO_TOOL = {
    "name": "resume-service-agent.parse_self_intro",
    "prompt_version": ACTIVE_PROMPT_VERSION["self_intro"],
    "schema_ref": LLM_SCHEMA_REFS["self_intro"],
    "required_grounded_paths": _required(LLM_SCHEMA_REFS["self_intro"]),
}

LLM_TOOLS = (
    JD_FIT_TOOL,
    QUESTION_TOOL,
    DYNAMIC_QUESTION_TOOL,
    FOLLOW_UP_TOOL,
    RESUME_PARSE_TOOL,
    JD_REQUIREMENTS_TOOL,
    SELF_INTRO_TOOL,
)

"""Schemas for every LLM-backed generation in this repo — INSTRUCTIONS.md
§11.5, §5.7. ~ packages/mcp-schemas/src/llm-schemas.ts.

The point of this file is that there is exactly ONE definition per LLM call.
The Pydantic model here is what the provider is handed (as a derived JSON
Schema, via `llm_json_schema`), what `structured_call` re-validates the
response against, and what the Provider Tool resolves a `schema_ref` to.
§11.5 asks for "literally the same object, not two hand-synced copies";
deriving the JSON Schema instead of writing it out twice is how that is
actually true rather than merely intended.

Deliberate deviation from the TS side: these are Pydantic models rather than
Zod schemas, and they live in `app/llm_client` rather than a separate
`mcp_schemas` package. `backend/mcp_schemas/*.json` holds the hand-written
MCP method schemas copied verbatim from the TS repo, which are validated by
`jsonschema` at the gateway; these five are DERIVED, so keeping them next to
the code that derives them is what stops a copy from being made.
"""

from __future__ import annotations

from typing import Any, Literal, Optional

from pydantic import BaseModel, Field, ValidationInfo, model_validator


class GroundableClaim(BaseModel):
    """A claim the model asserts, paired with the source text it says supports it.

    Every LLM-generated statement that reads as a factual assertion about the
    candidate is shaped like this, because the grounding check (§11.3) needs
    something concrete to look for in the source documents. A model that cannot
    produce a verbatim `evidence` slice cannot get its claim past the check —
    which is the whole mechanism behind soul.md §"Grounding is checked, not
    assumed".
    """

    value: str = Field(min_length=1, description="The claim itself, in plain language.")
    evidence: str = Field(
        min_length=1,
        description=(
            "A short VERBATIM quote from the source document that supports the claim. "
            "Copy it exactly; do not paraphrase, summarise, or invent it."
        ),
    )


# ------------------------------------------------------------------- jd fit


class TopicRelevanceGeneration(BaseModel):
    topic: str = Field(min_length=1)
    relevance_score: float = Field(
        ge=0,
        le=1,
        description="How heavily the JOB DESCRIPTION weights this topic — not how well the resume covers it.",
    )
    evidence: str = Field(
        min_length=1,
        description="A verbatim quote from the JOB DESCRIPTION showing it asks for this topic.",
    )


class JdFitGeneration(BaseModel):
    """Resume Service Agent (§4.2 Stage 5 addition): the JD-fit judgement
    layered on top of the Resume Parser Tool's structured output. It never
    replaces parsing — `matched_requirements` and `gaps` still come from the
    deterministic path; this call adds the explanation and the JD-anchored
    weighting."""

    rationale: GroundableClaim = Field(
        description=(
            "Why the resume does or does not fit the job description. Evidence must be a "
            "verbatim quote from the resume or the job description."
        )
    )
    topic_relevance: list[TopicRelevanceGeneration] = Field(max_length=12)


# ------------------------------------------------------------------ question


class QuestionBody(BaseModel):
    text: str = Field(min_length=10)
    topic: str = Field(min_length=1, description="MUST be one of the topics in the supplied topic plan.")
    type: Literal["behavioral", "technical"]
    difficulty: int = Field(ge=1, le=5)
    tier: Optional[int] = Field(
        default=None,
        ge=1,
        le=3,
        description="MUST equal the supplied slot's tier. Mirrors difficulty (tier + 1) — not a separate choice.",
    )
    expected_signals: list[str] = Field(
        min_length=1,
        max_length=6,
        description="What a strong answer would demonstrate. Used for calibration, never shown to the candidate.",
    )


class QuestionGeneration(BaseModel):
    """Question Agent (§4.3 Stage 5 addition): the question and its reference
    answer are generated in ONE call, per soul.md §"A reference answer is a
    comparison aid". `reference_answer` is returned to the agent but never to
    the harness — it goes to the Memory Agent and nowhere else (§4.7).

    `reasoning` comes first in the model on purpose (question-agent/v3,
    INSTRUCTIONS.md §11.5): a chain-of-thought field ahead of the fields it
    informs gets the model to actually work through the candidate profile and
    the slot constraints before committing to `question`/`reference_answer`,
    rather than reasoning after the fact to justify an already-written answer.
    It is scratch work, not a claim about the candidate — never
    grounding-checked, never returned past the Question Agent (same treatment
    as `reference_answer`).
    """

    reasoning: str = Field(
        min_length=20,
        description=(
            "Chain-of-thought scratch work, not shown to the candidate. Work through: "
            "(1) what the candidate profile actually shows about this topic, (2) whether the "
            "baseline question already fits the slot or what specifically is missing, (3) how to "
            "sharpen it for tier/difficulty without changing its scope. Write this BEFORE the fields below."
        ),
    )
    question: QuestionBody
    reference_answer: str = Field(
        min_length=40,
        description=(
            "A model answer for the Eval Tool to compare against. NEVER shown to the candidate "
            "and never spoken aloud."
        ),
    )
    grounding: GroundableClaim = Field(
        description=(
            "Why this question suits this candidate. Evidence must be a verbatim quote from the "
            "candidate profile or the topic plan."
        )
    )


# --------------------------------------------------- dynamic question (Stage 13)


class DynamicQuestionResponse(BaseModel):
    """Question Agent, synthesis path (Stage 13, `question-agent/v6`).

    The difference from `QuestionGeneration` above is the whole point of the
    stage: there is **no baseline question text in the input**. The model is
    handed a slot (topic, tier, type, difficulty), the `expected_signals` a
    strong answer at that slot has to demonstrate, and the candidate's own
    project history — and writes the scenario from scratch. `QuestionGeneration`
    stays registered and is still what the bank-backed fallback path uses when
    no provider is configured, so nothing that ran before this stage changes
    shape.

    `topic` and `tier` are echoed back rather than assumed. They are the two
    constraints a from-scratch generation can silently drift off — a model
    asked for a tier-1 databases question can very plausibly return a tier-3
    distributed-systems one — and echoing them is what makes that drift
    something Pydantic can *catch* rather than something a reader of the
    transcript notices later. `_check_constraints` below rejects a mismatch,
    which puts `structured_call` into its ordinary retry-with-correction loop:
    the candidate never sees the discarded generation, and a second failure
    falls back to the bank exactly as every other generation failure does.

    `grounding_rationale` is a `GroundableClaim` rather than a bare string for
    the reason every other claim in this file is: a plain sentence cannot be
    grounding-checked, and soul.md §"Grounding is checked, not assumed" does
    not have an exception for the field that explains the grounding. Its
    `value` IS the rationale a caller renders; `evidence` is the verbatim
    slice that makes it checkable.
    """

    reasoning: str = Field(
        min_length=20,
        description=(
            "Chain-of-thought scratch work, not shown to the candidate. Work through: "
            "(1) what the candidate's own project history gives you to build a scenario on, "
            "(2) what a tier-appropriate scenario for this topic actually looks like, "
            "(3) which of the requested expected_signals the scenario forces the candidate to show. "
            "Write this BEFORE the fields below."
        ),
    )
    topic: str = Field(
        min_length=1,
        description="Echo the topic you were given, exactly. Never a different one, however related.",
    )
    tier: int = Field(ge=1, le=3, description="Echo the tier you were given, exactly.")
    question_text: str = Field(
        min_length=15,
        description=(
            "The interview question, ready to be spoken to the candidate. Exactly one question — "
            "no multi-part questions, no 'and also', no hidden sub-questions."
        ),
    )
    expected_signals: list[str] = Field(
        min_length=1,
        max_length=6,
        description=(
            "What a strong answer to THIS question would demonstrate. The grading rubric's signal list. "
            "Never shown to the candidate."
        ),
    )
    reference_answer: str = Field(
        min_length=40,
        description=(
            "A model answer for the Eval Tool to compare against. NEVER shown to the candidate "
            "and never spoken aloud."
        ),
    )
    grounding_rationale: GroundableClaim = Field(
        description=(
            "Why this scenario suits this candidate. Evidence must be a verbatim quote from the "
            "candidate profile, the topic plan, a recent exchange, or an earlier session note."
        )
    )

    @model_validator(mode="after")
    def _check_constraints(self, info: ValidationInfo) -> "DynamicQuestionResponse":
        """Rejects a generation that drifted off the slot it was given.

        The constraints arrive as validation context rather than as fields on
        the schema because they are per-call: the JSON Schema handed to the
        provider is one fixed document, and baking "topic must be databases"
        into it would mean a different registered schema per topic. Context
        keeps one schema and one definition (the whole premise of this file)
        while still failing loudly on a per-call violation.

        No context supplied means no constraint to check — that is how the
        grounding-fallback and any future unconstrained caller behave, not a
        silent skip of a check that was meant to run.
        """
        constraints = (info.context or {}).get("question_constraints") if info.context else None
        if not constraints:
            return self

        wanted_topic = constraints.get("topic")
        if wanted_topic and self.topic.strip().lower() != str(wanted_topic).strip().lower():
            raise ValueError(
                f"topic must be exactly {wanted_topic!r} — the slot was chosen deterministically and is not "
                f"yours to change; you returned {self.topic!r}"
            )

        wanted_tier = constraints.get("tier")
        if wanted_tier is not None and int(self.tier) != int(wanted_tier):
            raise ValueError(
                f"tier must be exactly {wanted_tier} — write the question at the depth you were asked for; "
                f"you returned {self.tier}"
            )

        # The "ask one question" rule, made structural. A cue may precede the
        # question ("Staying with that — ...") but a second question mark is a
        # second task for the candidate, which is the failure this catches.
        if self.question_text.count("?") > 1:
            raise ValueError(
                "question_text must contain exactly one question; a conversational cue is allowed but it must "
                "not add a second question mark"
            )

        return self


# ----------------------------------------------------------------- follow-up


class FollowUpGeneration(BaseModel):
    """Follow-up Question Agent (§4.4): `targeted_gap.evidence` must be a
    verbatim slice of the candidate's own answer. That is how "a follow-up must
    target a specific gap or claim in the answer, never a generic 'tell me
    more'" stops being a style note and becomes something the grounding check
    enforces."""

    should_follow_up: bool
    follow_up_text: Optional[str] = Field(default=None, min_length=1)
    reason: str = Field(min_length=1)
    targeted_gap: Optional[GroundableClaim] = Field(
        default=None,
        description=(
            "The specific gap or claim being probed. Evidence must be a verbatim quote from the "
            "candidate's answer transcript."
        ),
    )


# -------------------------------------------------------------- resume parse


class ResumeExperienceGeneration(BaseModel):
    title: str = Field(min_length=1, description="Job title exactly as written.")
    company: str = Field(min_length=1, description="Company name exactly as written.")
    start_year: int = Field(ge=1970, le=2030, description="Start year, e.g. 2019.")
    end_year: Optional[int] = Field(
        default=None, ge=1970, le=2030, description="End year, or null if currently employed."
    )
    years: float = Field(ge=0, le=50, description="Duration in years. 0 if dates are ambiguous.")
    highlights: list[str] = Field(
        max_length=5, description="Key achievements or responsibilities, verbatim from the resume."
    )


class ResumeEducationGeneration(BaseModel):
    degree: str = Field(min_length=1, description="Degree or qualification name.")
    institution: str = Field(min_length=1, description="University or institution name.")
    year: Optional[int] = Field(default=None, description="Graduation year, or null if not stated.")


class ResumeParseGeneration(BaseModel):
    """Resume Parser (LLM-powered extraction): the structured output the model
    must return when asked to extract skills, experience, and education from
    raw resume text. This supplements (never replaces) the deterministic regex
    parser — `parse_resume_text` stays as the automatic fallback."""

    skills: list[str] = Field(description="Individual skills or technologies. Each entry <= 4 words.")
    experience: list[ResumeExperienceGeneration] = Field(
        description="Work history entries, ordered by recency."
    )
    education: list[ResumeEducationGeneration] = Field(description="Academic qualifications.")
    keywords: list[str] = Field(
        max_length=40, description="Top content-bearing terms extracted from the resume."
    )
    summary: str = Field(
        min_length=10,
        max_length=300,
        description="A 1-2 sentence factual summary of the candidate. No embellishment.",
    )


# -------------------------------------------------------------- self intro


class IntroTopicRelevanceGeneration(BaseModel):
    topic: str = Field(min_length=1)
    relevance_score: float = Field(
        ge=0,
        le=1,
        description="How much the CANDIDATE'S SELF-INTRODUCTION supports this topic — not the resume or the job description.",
    )
    evidence: str = Field(
        min_length=1,
        description="A verbatim quote from the SELF-INTRODUCTION TRANSCRIPT showing the candidate raised this topic.",
    )


class SelfIntroGeneration(BaseModel):
    """Resume Service Agent (self_intro_v1, self-intro addition on top of
    §4.3): the same text-in/topic_relevance-out extraction the resume side
    already does, pointed at the candidate's own "tell me about yourself"
    transcript instead of resume lines. Purely descriptive of what the
    candidate said — no fit/seniority judgement layered on top, unlike
    `JdFitGeneration`."""

    topic_relevance: list[IntroTopicRelevanceGeneration] = Field(max_length=12)


# ----------------------------------------------------------- jd requirements


class JdRequirementGeneration(BaseModel):
    text: str = Field(min_length=1, description="The requirement as a single, atomic demand.")
    category: Literal["technical", "experience", "education", "soft_skill", "certification", "other"] = Field(
        description="What kind of requirement this is."
    )
    is_mandatory: bool = Field(
        description='true if the JD uses "must", "required"; false for "nice to have", "preferred".'
    )


class JdRequirementsGeneration(BaseModel):
    """JD Requirements Parser (LLM-powered extraction): the structured output
    the model must return when asked to extract requirements from a job
    description. Supplements (never replaces) the deterministic
    `extract_requirements` regex."""

    requirements: list[JdRequirementGeneration] = Field(
        description="Individual requirements extracted from the JD."
    )
    role_level: Literal["junior", "mid", "senior", "lead", "staff+"] = Field(
        description="Seniority level the JD targets."
    )
    key_technologies: list[str] = Field(
        max_length=20,
        description="Specific named technologies, frameworks, or tools the JD emphasizes.",
    )


# ------------------------------------------------------------------ registry

LLM_SCHEMA_REFS = {
    "jd_fit": "llm:resume-service-agent/jd_fit@v1",
    "question": "llm:question-agent/question@v1",
    # (Stage 13) The from-scratch synthesis path. A separate ref rather than a
    # v2 of `question` because the two coexist: `question` is the bank-backed
    # rewrite that still runs whenever synthesis is unavailable.
    "dynamic_question": "llm:question-agent/dynamic_question@v1",
    "follow_up": "llm:followup-agent/follow_up@v1",
    "resume_parse": "llm:resume-parser/parse@v1",
    "jd_requirements": "llm:jd-parser/requirements@v1",
    "self_intro": "llm:self-intro/topic_relevance@v1",
}


class LlmSchemaEntry:
    __slots__ = ("ref", "schema", "required_grounded_paths")

    def __init__(self, ref: str, schema: type[BaseModel], required_grounded_paths: tuple[str, ...]) -> None:
        self.ref = ref
        self.schema = schema
        # Paths whose grounding failure invalidates the WHOLE response rather
        # than just that field (§11.3: "only rejected if a required field
        # fails"). Paths are dot/bracket JSON paths as produced by
        # `extract_groundable_fields`.
        self.required_grounded_paths = required_grounded_paths


_ENTRIES = [
    LlmSchemaEntry(
        LLM_SCHEMA_REFS["jd_fit"],
        JdFitGeneration,
        # `rationale` is an optional enrichment on top of a jd_fit that the
        # deterministic path already produced, so losing it must not lose the
        # rest of the response (§11.3, §4.2).
        (),
    ),
    LlmSchemaEntry(
        LLM_SCHEMA_REFS["question"],
        QuestionGeneration,
        # A question we cannot tie back to the plan or the profile is exactly
        # the "inconsistent question" §4.3 says to fall back to the bank over.
        ("grounding",),
    ),
    LlmSchemaEntry(
        LLM_SCHEMA_REFS["dynamic_question"],
        DynamicQuestionResponse,
        # Same reasoning as `question` above, and stronger here: a synthesized
        # scenario has no bank text underneath it, so a generation we cannot
        # tie back to the plan or the profile is a question with no provenance
        # at all. Failing the required path is what sends the agent to the
        # bank fallback instead of asking it (soul.md §"No fabrication").
        ("grounding_rationale",),
    ),
    LlmSchemaEntry(
        LLM_SCHEMA_REFS["follow_up"],
        FollowUpGeneration,
        # A probe whose target is not in the transcript is a generic "tell me
        # more" wearing a specific-sounding sentence (§4.4).
        ("targeted_gap",),
    ),
    LlmSchemaEntry(
        LLM_SCHEMA_REFS["resume_parse"],
        ResumeParseGeneration,
        # Resume extraction is literal data copying, not a grounded claim about
        # the candidate — no grounding check needed.
        (),
    ),
    LlmSchemaEntry(
        LLM_SCHEMA_REFS["jd_requirements"],
        JdRequirementsGeneration,
        # JD requirement extraction is structural, not a claim — no grounding.
        (),
    ),
    LlmSchemaEntry(
        LLM_SCHEMA_REFS["self_intro"],
        SelfIntroGeneration,
        # Same treatment as jd_fit's topic_relevance: an ungrounded entry is
        # dropped on its own, it does not invalidate the whole extraction.
        (),
    ),
]

_BY_REF = {entry.ref: entry for entry in _ENTRIES}


def get_llm_schema(ref: str) -> Optional[LlmSchemaEntry]:
    return _BY_REF.get(ref)


def list_llm_schema_refs() -> list[str]:
    return sorted(_BY_REF)


def llm_json_schema(ref: str) -> Optional[dict[str, Any]]:
    """The derived JSON Schema, for handing to a provider's structured-output
    binding. Derived rather than hand-written, so the schema the provider is
    told to satisfy and the schema `structured_call` re-validates against
    cannot drift."""
    entry = _BY_REF.get(ref)
    return entry.schema.model_json_schema() if entry else None

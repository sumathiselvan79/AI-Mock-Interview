"""`structured_call` — INSTRUCTIONS.md §11.5. ~ packages/llm-client/src/structuredCall.ts.

The single entry point every LLM-backed agent uses. In order it: renders the
pinned prompt version, invokes the provider with the schema attached,
re-validates the response against that SAME schema (the one registered in
`app.llm_client.schemas`, not a copy), retries once with a corrective message
on a schema failure only, then runs the grounding check before anything
reaches the caller.

Three distinct outcomes, deliberately not collapsed into one:
 - schema-valid and grounded                 -> output set, grounded=True
 - schema-valid, an OPTIONAL claim ungrounded -> output set, grounded=False, insufficient_signal
 - schema-valid, a REQUIRED claim ungrounded  -> output=None, caller falls back
 - never schema-valid                         -> raises StructuredCallError, caller falls back

The caller falling back means its deterministic Stage-2 path (TRACKING.md
"The model seam"). No path here coerces a bad response into a usable shape.
"""

from __future__ import annotations

import asyncio
import collections
import os
import time
from dataclasses import dataclass, field
from typing import Any, Mapping, Optional

from pydantic import BaseModel, ValidationError

from app.logging_ import Logger, create_logger

from .grounding import apply_insufficient_signal, extract_groundable_fields, grounding_check
from .prompt_registry import PromptRegistry
from .provider import create_chat_model, resolve_provider
from .types import (
    ProviderName,
    ProviderUnavailableError,
    StructuredCallError,
    StructuredCallRequest,
    StructuredCallResult,
    StructuredChatModel,
    ToolDefinition,
)


@dataclass
class StructuredCallOptions:
    provider: Optional[ProviderName] = None
    # Injects a model directly — used by tests to force a malformed or
    # ungrounded response.
    model: Optional[StructuredChatModel] = None
    # What `evidence` strings must be verbatim slices of. Omitted, grounding
    # is skipped.
    source_documents: list[str] = field(default_factory=list)
    # §11.5 retries once by default; a schema failure is the only retryable one.
    retries: int = 1
    # (Stage 13) Per-call constraints handed to the schema's own validators as
    # Pydantic validation context. This is how a per-call rule ("this question
    # must be on `databases`, at tier 2") is enforced without minting a
    # different registered schema per call — one definition, one JSON Schema
    # sent to the provider, and a violation that surfaces as an ordinary
    # validation error and therefore takes the retry path below.
    validation_context: Optional[dict[str, Any]] = None
    # Enables the expensive grounding pass (§11.3). Off by default: it costs
    # a second call.
    llm_grounding_fallback: bool = False
    env: Optional[Mapping[str, str]] = None
    # (C7) Per-attempt timeout and whole-call budget, in seconds. None means
    # `LLM_CALL_TIMEOUT_S` / `LLM_CALL_BUDGET_S` from the environment, then
    # the defaults below. Tests set them directly.
    attempt_timeout_s: Optional[float] = None
    budget_s: Optional[float] = None
    # (E1) Where the failure/fallback lines go. None means this module's
    # default logger (stdout, bounded history).
    logger: Optional[Logger] = None


# (C7) A turn used to wait 30s on a hung provider before the caller even
# started its fallback, and a schema retry could wait another 30s on top.
# Now: each attempt is cut at ATTEMPT_TIMEOUT_S, a transient provider failure
# (timeout, connection, 5xx, 429) gets ONE retry, and nothing — schema retries
# included — runs past CALL_BUDGET_S for the whole call. The budget is what
# bounds a turn: a caller that chains two calls (question-agent v6 then v5)
# waits at most twice the budget, never an open-ended sum of timeouts.
#
# 12s per attempt sits above the slowest successful generation seen in
# production (Groq v6 synthesis, 2.8 / 8.6 avg / 19.4 s max over 8 calls; the
# 19.4 s one would now be retried) and well under the 30s that produced the
# 45s turn. Tune with the env vars, not by editing the numbers per caller.
ATTEMPT_TIMEOUT_S = 12.0
CALL_BUDGET_S = 20.0
# An attempt is not started with less than this left: it could only time out.
MIN_ATTEMPT_S = 2.0
TRANSIENT_RETRIES = 1


def _default_logger() -> Logger:
    logger = create_logger(write_to_console=os.environ.get("NODE_ENV") != "test")
    # Bounded: this logger lives for the process, and `Logger` keeps every
    # line it writes for the privacy tests.
    logger._lines = collections.deque(maxlen=500)  # type: ignore[assignment]
    return logger


_LOGGER = _default_logger()


def recent_llm_events() -> list[str]:
    """The default logger's recent lines (JSON strings), for tests."""
    return _LOGGER.history()


def _env_float(env: Mapping[str, str], name: str, default: float) -> float:
    try:
        value = float(env.get(name) or default)
    except (TypeError, ValueError):
        return default
    return value if value > 0 else default


def _error_fields(err: BaseException) -> dict[str, Any]:
    """(E1) What a failure was, with no text from the prompt or the response.

    A Pydantic error contributes its JSON paths and error types only — never
    its message, which quotes the model's output and therefore, often, the
    candidate's answer or resume (CLAUDE.md §8). Anything else contributes its
    class name, and for a provider failure its text-free `kind`."""
    fields: dict[str, Any] = {"error_class": type(err).__name__}
    if isinstance(err, ValidationError):
        details = err.errors(include_input=False, include_url=False, include_context=False)
        fields["error_count"] = len(details)
        fields["error_paths"] = [".".join(str(part) for part in d.get("loc", ())) or "<root>" for d in details[:10]]
        fields["error_types"] = sorted({str(d.get("type")) for d in details})
    if isinstance(err, ProviderUnavailableError):
        fields["provider_error"] = getattr(err, "kind", "unavailable")
    return fields


async def structured_call(
    tool: ToolDefinition, input_: Any, options: Optional[StructuredCallOptions] = None
) -> StructuredCallResult:
    options = options or StructuredCallOptions()
    env = options.env if options.env is not None else os.environ
    provider: ProviderName = (
        (options.model.provider if options.model else None)
        or options.provider
        or resolve_provider(env, tool.name).provider
    )
    model = options.model or create_chat_model(provider, env)
    prompt = PromptRegistry.get(tool.prompt_version)
    source_documents = options.source_documents

    request = StructuredCallRequest(
        system=prompt.system,
        user=prompt.render(input_),
        input=input_,
        schema_ref=tool.schema_ref,
        source_documents=source_documents,
        run_name=tool.name,
        # LangSmith run metadata. Whether it is actually shipped anywhere is
        # decided by the tracing gate, not here (§8, `tracing.py`).
        tags=[tool.prompt_version, provider],
    )

    logger = options.logger or _LOGGER
    attempt_timeout = options.attempt_timeout_s or _env_float(env, "LLM_CALL_TIMEOUT_S", ATTEMPT_TIMEOUT_S)
    budget = options.budget_s or _env_float(env, "LLM_CALL_BUDGET_S", CALL_BUDGET_S)
    started = time.monotonic()
    deadline = started + budget
    log_base = {"call": tool.name, "prompt_version": tool.prompt_version, "provider": provider}

    def elapsed_ms() -> int:
        return int((time.monotonic() - started) * 1000)

    def fallback(outcome: str, err: Optional[BaseException], attempts: int) -> None:
        logger.warn(
            "llm_call_fallback",
            {**log_base, "outcome": outcome, "attempts": attempts, "latency_ms": elapsed_ms(), **(_error_fields(err) if err else {})},
        )

    last_error: Any = None
    correction: Optional[str] = None
    schema_attempts_left = options.retries + 1
    transient_retries_left = TRANSIENT_RETRIES
    attempts = 0
    parsed: Any = None

    while schema_attempts_left > 0:
        remaining = deadline - time.monotonic()
        if attempts > 0 and remaining < MIN_ATTEMPT_S:
            break
        attempts += 1
        attempt_started = time.monotonic()
        try:
            call_request = request
            if correction is not None:
                call_request = StructuredCallRequest(**{**request.__dict__, "correction": correction})
            this_timeout = max(0.001, min(attempt_timeout, remaining))
            try:
                raw = await asyncio.wait_for(model.invoke(call_request), timeout=this_timeout)
            except asyncio.TimeoutError as err:
                raise ProviderUnavailableError(
                    provider, f"no response within {int(this_timeout * 1000)}ms", transient=True, kind="timeout"
                ) from err
            # Re-validated against the same schema the provider was given. A
            # provider that ignored its own structured-output contract does
            # not get to pass its response through on the strength of having
            # been asked nicely.
            parsed = _validate(tool.schema, raw, options.validation_context)
        except ProviderUnavailableError as err:
            last_error = err
            logger.warn(
                "llm_provider_failed",
                {**log_base, "attempt": attempts, "latency_ms": int((time.monotonic() - attempt_started) * 1000), **_error_fields(err)},
            )
            # A provider that cannot be reached at all is not a schema
            # problem (§5.7 `provider_unavailable`). A transient one gets one
            # bounded retry inside the budget; a permanent one (missing key,
            # 401) fails the same way every time and goes straight to the
            # caller's fallback.
            if getattr(err, "transient", False) and transient_retries_left > 0 and deadline - time.monotonic() >= MIN_ATTEMPT_S:
                transient_retries_left -= 1
                continue
            fallback("provider_unavailable", err, attempts)
            raise
        except Exception as err:  # noqa: BLE001
            last_error = err
            correction = str(err)
            schema_attempts_left -= 1
            logger.warn(
                "llm_validation_failed",
                {**log_base, "attempt": attempts, "latency_ms": int((time.monotonic() - attempt_started) * 1000), **_error_fields(err)},
            )
            continue
        break
    else:
        parsed = None

    if parsed is None:
        if isinstance(last_error, ProviderUnavailableError):
            fallback("provider_unavailable", last_error, attempts)
            raise last_error
        fallback("schema_validation_failed", last_error, attempts)
        raise StructuredCallError(tool.name, last_error)

    if not source_documents:
        return StructuredCallResult(
            output=parsed, grounded=True, insufficient_signal=[], prompt_version=tool.prompt_version, provider=provider
        )

    fields = extract_groundable_fields(parsed)
    grounded = await grounding_check(
        fields,
        source_documents,
        options=None if not options.llm_grounding_fallback else _fallback_options(model),
    )

    failed_required = [path for path in tool.required_grounded_paths if grounded.get(path) is False]
    if failed_required:
        # §11.3: the whole response is rejected only when a required
        # field fails.
        logger.warn(
            "llm_call_fallback",
            {**log_base, "outcome": "required_grounding_failed", "attempts": attempts, "latency_ms": elapsed_ms(), "error_paths": failed_required},
        )
        return StructuredCallResult(
            output=None,
            grounded=False,
            insufficient_signal=failed_required,
            prompt_version=tool.prompt_version,
            provider=provider,
        )

    applied = apply_insufficient_signal(parsed, grounded, tool.required_grounded_paths)
    return StructuredCallResult(
        output=applied.output,
        grounded=len(applied.insufficient_signal) == 0,
        insufficient_signal=applied.insufficient_signal,
        prompt_version=tool.prompt_version,
        provider=provider,
    )


def _fallback_options(model: StructuredChatModel):
    from .grounding import GroundingOptions

    return GroundingOptions(fallback_model=model)


def _validate(
    schema: type[BaseModel], raw: Any, validation_context: Optional[dict[str, Any]] = None
) -> dict[str, Any]:
    """Validates `raw` (a dict from the fixture provider, or a `schema`
    instance from a real LangChain structured-output call) against `schema`
    and returns a plain dict — everything downstream (grounding's field walk,
    the MCP JSON response) works on dicts, not Pydantic instances.

    An already-constructed instance is re-validated from its dump when there
    is a context to apply. LangChain builds that instance itself, so its
    construction never saw the context — skipping the second pass would mean
    the per-call constraints silently applied to the fixture provider and not
    to a real one, which is the worst possible place for a check to differ.
    """
    if isinstance(raw, schema):
        dumped = raw.model_dump(mode="json")
        if validation_context is None:
            return dumped
        raw = dumped
    return schema.model_validate(raw, context=validation_context).model_dump(mode="json")

"""JSON Schemas for every MCP call in this repo, plus the validator every
caller must use before a request leaves and after a response arrives —
~ packages/mcp-schemas/src/index.ts.

CLAUDE.md §8: "Every MCP tool input/output must be validated against its
JSON Schema in /packages/mcp-schemas before use." Schemas are plain JSON on
disk (`backend/mcp_schemas/*.json`, copied verbatim from
`packages/mcp-schemas/schemas`) so this port and the original TS side can
never drift on the contract itself — only the validator library differs
(`jsonschema` here, `ajv` there).
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from jsonschema import Draft7Validator
from jsonschema.exceptions import SchemaError

SCHEMA_DIR = Path(__file__).resolve().parents[2] / "mcp_schemas"


@dataclass
class SchemaViolation:
    path: str
    message: str


@dataclass
class ValidationResult:
    valid: bool
    violations: list[SchemaViolation] = field(default_factory=list)


# server name -> method name -> {"request": Validator, "response": Validator}
_registry: dict[str, dict[str, dict[str, Draft7Validator]]] = {}

# The Speech Service is the one tool not callable by whichever agent wants
# it — only the Harness Agent may call it (INSTRUCTIONS.md §5.6). A server
# absent from this map is callable by any authenticated agent.
ALLOWED_CALLERS: dict[str, tuple[str, ...]] = {
    "tool-speech-service": ("harness-agent",),
}


def _register(server: str, methods: dict[str, dict[str, Any]]) -> None:
    compiled: dict[str, dict[str, Draft7Validator]] = {}
    for method, schema in methods.items():
        compiled[method] = {
            "request": Draft7Validator(schema["request"]),
            "response": Draft7Validator(schema["response"]),
        }
    _registry[server] = compiled


def _load() -> None:
    for path in sorted(SCHEMA_DIR.glob("*.json")):
        parsed = json.loads(path.read_text(encoding="utf-8"))
        if "servers" in parsed:
            for server, definition in parsed["servers"].items():
                _register(server, definition["methods"])
        if "methods" in parsed:
            _register(path.stem, parsed["methods"])


_load()


def is_known_server(server: str) -> bool:
    return server in _registry


def is_known_method(server: str, method: str) -> bool:
    return method in _registry.get(server, {})


def list_servers() -> list[str]:
    return sorted(_registry.keys())


def list_methods(server: str) -> list[str]:
    return sorted(_registry.get(server, {}).keys())


def _run(validator: Optional[Draft7Validator], payload: Any, what: str) -> ValidationResult:
    if validator is None:
        return ValidationResult(False, [SchemaViolation("", f"no {what} schema registered")])
    errors = sorted(validator.iter_errors(payload), key=lambda e: list(e.path))
    if not errors:
        return ValidationResult(True, [])
    violations = [
        SchemaViolation("/" + "/".join(str(p) for p in e.path) if e.path else "/", e.message)
        for e in errors
    ]
    return ValidationResult(False, violations)


def validate_request(server: str, method: str, params: Any) -> ValidationResult:
    validator = _registry.get(server, {}).get(method, {}).get("request")
    return _run(validator, params, "request")


def validate_response(server: str, method: str, result: Any) -> ValidationResult:
    validator = _registry.get(server, {}).get(method, {}).get("response")
    return _run(validator, result, "response")


def describe_violations(violations: list[SchemaViolation]) -> str:
    """Human-readable summary of a failed validation, safe to log (paths only, no values)."""
    return "; ".join(f"{v.path} {v.message}" for v in violations)

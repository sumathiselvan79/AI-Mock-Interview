"""~ apps/gateway/src/mcp/types.ts — re-exports the MCP server seam from shared_types."""

from app.shared_types import McpHandlerError, McpServerHandler

__all__ = ["McpHandlerError", "McpServerHandler"]

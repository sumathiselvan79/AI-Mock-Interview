"""Dummy MCP server for TRACKING.md Stage 1, gate test 4 — ~ apps/gateway/src/mcp/dev-ping-server.ts.

"Fire one dummy MCP tool call through the gateway and confirm a `tool_called`
telemetry event lands with latency and status — before writing any real
tool, prove the instrumentation path works."

Registered in development and test only — never in production.
"""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from typing import Any

from app.shared_types import McpCallContext, McpHandlerError


class DevPingServer:
    name = "_dev"

    async def call(self, method: str, params: Any, ctx: McpCallContext) -> Any:
        if method != "ping":
            raise McpHandlerError("unknown_method", f"_dev has no method {method}")
        params = params or {}
        delay_ms = params.get("delay_ms")
        if delay_ms and delay_ms > 0:
            await asyncio.sleep(delay_ms / 1000)
        if params.get("fail"):
            raise McpHandlerError("upstream_error", "ping asked to fail")
        return {"pong": params.get("nonce"), "server_time": datetime.now(timezone.utc).isoformat()}


def create_dev_ping_server() -> DevPingServer:
    return DevPingServer()

"""MCP Gateway — ~ apps/gateway/src/mcp/gateway.ts. CLAUDE.md §5, INSTRUCTIONS.md §2.

Every MCP call in the system passes through `call()`. In order it: resolves
the server, authenticates the session token, enforces the caller allowlist,
applies the per-session rate limit, validates the request against its JSON
Schema, invokes the server, validates the response, and — on every path,
including every failure path — emits one `tool_called`/`agent_called`
telemetry span with latency and status. No agent instruments itself.
"""

from __future__ import annotations

import time
from typing import Any, Optional

from app.auth.tokens import verify_session_token
from app.config import GatewayConfig
from app.logging_ import Logger
from app.mcp.schemas import ALLOWED_CALLERS, describe_violations, is_known_method, is_known_server, validate_request, validate_response
from app.shared_types import MCP_AGENT_SERVERS, MCP_ERROR_CODES, McpCallContext, McpCallResult, McpError, McpHandlerError, McpServerHandler
from app.storage.types import LiveSessionStore

_AGENT_SERVER_NAMES = set(MCP_AGENT_SERVERS)


class McpGateway:
    def __init__(
        self, *, config: GatewayConfig, telemetry: Any, live: LiveSessionStore, logger: Logger
    ) -> None:
        self._config = config
        self._telemetry = telemetry
        self._live = live
        self._logger = logger
        self._handlers: dict[str, McpServerHandler] = {}

    def register(self, handler: McpServerHandler) -> None:
        self._handlers[handler.name] = handler
        self._logger.info("mcp_server_registered", {"server": handler.name})

    def registered(self) -> list[str]:
        return sorted(self._handlers.keys())

    async def call(
        self, server: str, method: str, params: Any, ctx: McpCallContext
    ) -> McpCallResult:
        started_at = time.perf_counter()
        error: Optional[McpError] = None
        data: Any = None

        try:
            data = await self._dispatch(server, method, params, ctx)
        except McpHandlerError as err:
            error = McpError(code=err.code, message=err.message)
        except Exception as err:  # noqa: BLE001 - upstream handler crash becomes a typed error
            error = McpError(code=MCP_ERROR_CODES["UPSTREAM_ERROR"], message=str(err))

        latency_ms = (time.perf_counter() - started_at) * 1000

        # The auto-emitted span. Fire-and-forget by contract (§5.4), but
        # awaited here so a dropped span can never race a test or a shutdown.
        await self._telemetry.emit(
            "agent_called" if server in _AGENT_SERVER_NAMES else "tool_called",
            ctx.session_id or None,
            {
                "server": server,
                "method": method,
                "caller": ctx.caller,
                "status": "error" if error else "ok",
                "latency_ms": round(latency_ms * 1000) / 1000,
                "error_code": error.code if error else None,
            },
        )

        if error:
            return McpCallResult(ok=False, error=error, latency_ms=latency_ms)
        return McpCallResult(ok=True, data=data, latency_ms=latency_ms)

    async def _dispatch(self, server: str, method: str, params: Any, ctx: McpCallContext) -> Any:
        handler = self._handlers.get(server)
        if not handler or not is_known_server(server):
            raise McpHandlerError(MCP_ERROR_CODES["UNKNOWN_SERVER"], f"unknown MCP server: {server}")
        if not is_known_method(server, method):
            raise McpHandlerError(
                MCP_ERROR_CODES["UNKNOWN_METHOD"],
                f"{server} has no method {method} in /packages/mcp-schemas",
            )

        if not verify_session_token(ctx.session_token or "", ctx.session_id or "", self._config.auth_token_secret):
            raise McpHandlerError(
                MCP_ERROR_CODES["UNAUTHORIZED"], "invalid or missing session token for this MCP call"
            )

        allowed = ALLOWED_CALLERS.get(server)
        if allowed and ctx.caller not in allowed:
            raise McpHandlerError(
                MCP_ERROR_CODES["UNAUTHORIZED"],
                f"{server} may only be called by {', '.join(allowed)}, not {ctx.caller}",
            )

        await self._enforce_rate_limit(ctx)

        request_check = validate_request(server, method, params)
        if not request_check.valid:
            raise McpHandlerError(
                MCP_ERROR_CODES["SCHEMA_INVALID_REQUEST"],
                f"{server}.{method} request failed schema: {describe_violations(request_check.violations)}",
            )

        result = await handler.call(method, params, ctx)

        response_check = validate_response(server, method, result)
        if not response_check.valid:
            raise McpHandlerError(
                MCP_ERROR_CODES["SCHEMA_INVALID_RESPONSE"],
                f"{server}.{method} response failed schema: {describe_violations(response_check.violations)}",
            )

        return result

    async def _enforce_rate_limit(self, ctx: McpCallContext) -> None:
        limit = self._config.mcp_rate_limit
        window_ms = self._config.mcp_rate_limit_window_ms
        count = await self._live.increment_rate_counter(f"mcp:{ctx.session_id}", window_ms)
        if count > limit:
            await self._telemetry.emit(
                "rate_limit_exceeded", ctx.session_id or None, {"caller": ctx.caller, "limit": limit, "window_ms": window_ms}
            )
            raise McpHandlerError(
                MCP_ERROR_CODES["RATE_LIMITED"], f"session exceeded {limit} MCP calls per {window_ms}ms"
            )

"""Shared answer-shape signals — ~ packages/interview-domain.

Three small facts about the surface of an answer that more than one component
now needs to agree on:

 - `SHORT_ANSWER_WORDS` — below this there is not enough in the answer to
   probe. The Follow-up Agent's `too_short_to_probe` branch, the harness's
   consecutive-short-answer struggle signal (`HUMAN_INTERACTION_FLOW.md` §2),
   and the acknowledgment beat's choice of pool (§1) are all the same
   judgement, and a session where they disagreed would acknowledge an answer
   as substantive and then treat it as empty two lines later.
 - `HEDGE_RE` — the hedging vocabulary. The Follow-up Agent probes a single
   hedged claim; the harness counts hedges ACROSS turns to spot a candidate
   who has stopped committing to anything. Same words, two time horizons.
 - `METRIC_RE` — a number with a unit attached. The Follow-up Agent uses its
   absence to ask for one; the harness uses its presence to mark an answer as
   worth remembering for a later callback (§5).

These lived as module-private constants in `followup/server.py` until a second
caller appeared. They are here rather than duplicated because two copies of a
regex are two regexes: the first time one is tuned and the other is not, the
interview starts asking for a metric it has already decided the answer has.
"""

from __future__ import annotations

import re

#: Fewer words than this and the answer has no claim in it to work with.
SHORT_ANSWER_WORDS = 15

HEDGE_RE = re.compile(
    r"\b(?:kind of|sort of|i guess|probably|maybe|i think|something like|or whatever|roughly)\b",
    re.IGNORECASE,
)

METRIC_RE = re.compile(
    r"\b\d+(?:\.\d+)?\s?(?:%|percent|x|ms|s\b|seconds|minutes|hours|days|weeks|months|k\b|m\b|users|requests|rps|qps)",
    re.IGNORECASE,
)


def is_short_answer(transcript: str) -> bool:
    return len([w for w in (transcript or "").split() if w]) < SHORT_ANSWER_WORDS

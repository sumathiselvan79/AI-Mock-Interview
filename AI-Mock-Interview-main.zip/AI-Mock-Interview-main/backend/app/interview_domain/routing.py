"""Adaptive routing — the in-session performance signal and the traffic cop
that turns it into "which topic, which tier, next?"

~ lives beside `topics.py`, `blueprint.py` and `transitions.py` for the same
reason they do: more than one agent needs the same answer, and two copies of
a threshold become two different thresholds the first time one is tuned.
The Follow-up Agent computes the routing decision (it is the agent that sees
a score the moment it exists); the Question Agent consumes the topic it
names; the Harness Agent keeps the snapshot these run against. None of them
owns a second copy of the arithmetic.

Three things live here:

 - `InterviewSession` — the rolling snapshot of how a session is going.
   Deliberately small: what the routing decision needs and nothing else. It
   is a DERIVED view, never a source of truth (see `rebuilt_from`) — every
   field can be recomputed from persisted questions/evaluations, which is
   what lets the in-memory tracker in `app/http/session_tracker.py` be a
   cache rather than state an agent is holding (CLAUDE.md §10, Stage 5).

 - `record_score` — the exponential moving average. A plain mean over a
   whole session is a lagging indicator: a candidate who opens badly and
   then finds their feet keeps a depressed average for the rest of the
   interview, and the interview keeps treating them as struggling. An EMA
   weights the most recent answers, which is what "real-time performance
   trajectory" actually means.

 - `determine_next_node` — the traffic cop. Strong answers step the tier up
   and move on; weak ones step it down and stay, or pivot laterally when the
   candidate is stuck on the topic rather than on one question.

**What this module is NOT allowed to do, and the reason it is worth stating
in the file rather than only in a design doc:** a `NextNode` is a PROPOSAL.
It never enforces anything. The per-topic cap, the exclusion of an
already-asked question, and the final tier all stay in the Question Agent's
deterministic selection (CLAUDE.md §16). So a routing decision can reorder
the plan and nothing more — it cannot buy a topic a fourth question, and it
cannot produce a harder question than the scores support, because
`next_tier_for` still runs after it. If you find yourself passing a
`NextNode` deeper than selection's ordering step, that is the line.

No rubric lives here either. Every number below is a threshold on a score the
Eval Tool already produced; nothing here decides what a score means
(CLAUDE.md §8).
"""

from __future__ import annotations

from typing import Optional, Sequence

from pydantic import Field

from app.interview_domain.topics import get_topic
from app.shared_types.base import CamelModel
from app.shared_types.interview import NextActionDirective

#: How heavily the newest answer weighs in `rolling_score`. 0.4 puts roughly
#: three-quarters of the weight on the last three answers, which is the same
#: window `difficulty_target_from` already reads — one judgement, one horizon.
ROLLING_SCORE_ALPHA = 0.4

#: Above this, the candidate is comfortably clearing the current tier: step up.
ESCALATE_ABOVE = 4.0

#: Below this, another question at the same angle is unlikely to surface
#: anything new: step down and reframe. Deliberately in step with the floor
#: `detect_struggle`/`next_tier_for` already use (2.0 there is the *average*
#: of the last two; 2.5 here is a single answer), so a supportive reframe and
#: an easier tier arrive together instead of contradicting each other.
SUPPORT_BELOW = 2.5

#: How many consecutive sub-`SUPPORT_BELOW` answers on the SAME topic mean the
#: candidate is stuck on the topic rather than on one question. One weak answer
#: is a question that landed badly; two in a row on one topic is the topic.
STUCK_STREAK = 2

MIN_TIER = 1
MAX_TIER = 3


class InterviewSession(CamelModel):
    """The rolling routing snapshot for one live session.

    Held in `app.http.session_tracker.active_sessions` for fast access and
    rebuilt from persisted rows whenever it is missing — see `rebuilt_from`.
    Nothing here is authoritative: `topic_counts` and `topic_scores` are the
    Memory Agent's and the Evaluation store's, and this is a copy kept close
    to the routing decision that reads them every turn.
    """

    session_id: str
    #: The topic of the question just answered. `None` before the first answer.
    current_topic: Optional[str] = None
    current_tier: int = Field(default=MIN_TIER, ge=MIN_TIER, le=MAX_TIER)
    #: Topics that have spent their `topic_plan` cap. Never re-proposed.
    exhausted_topics: list[str] = Field(default_factory=list)
    #: The EMA. `None` until the first answer is scored — an unscored session
    #: has not scored zero (`lib/format.ts`'s `—`-not-`0` rule, in numbers).
    rolling_score: Optional[float] = None
    #: The most recent single score, which is what the > 4.0 / < 2.5 bands are
    #: read against. The EMA is the trajectory; this is the last data point.
    last_score: Optional[float] = None
    answers_scored: int = 0
    #: Per-topic score history, oldest first — the same shape the Question
    #: Agent already receives as `topic_scores`.
    topic_scores: dict[str, list[float]] = Field(default_factory=dict)
    topic_tier: dict[str, int] = Field(default_factory=dict)


def rebuilt_from(
    *,
    session_id: str,
    topic_counts: dict[str, int],
    topic_caps: dict[str, int],
    topic_scores: dict[str, list[float]],
    topic_tier: dict[str, int],
    current_topic: Optional[str] = None,
    recent_scores: Optional[Sequence[float]] = None,
) -> InterviewSession:
    """Rebuilds the snapshot from persisted state.

    This is what makes the in-memory tracker a cache rather than state: a
    restarted process, a second worker, or a resumed session all land here and
    get the same snapshot the lost one held. `rolling_score` is replayed
    through the same EMA rather than averaged, so a rebuilt session and a
    live one cannot disagree.
    """
    session = InterviewSession(
        session_id=session_id,
        current_topic=current_topic,
        current_tier=_clamp_tier(topic_tier.get(current_topic or "", MIN_TIER)),
        exhausted_topics=exhausted_from(topic_counts, topic_caps),
        topic_scores={topic: list(scores) for topic, scores in topic_scores.items()},
        topic_tier=dict(topic_tier),
    )
    for score in recent_scores or []:
        session = _apply_rolling(session, score)
    return session


def exhausted_from(topic_counts: dict[str, int], topic_caps: dict[str, int]) -> list[str]:
    """Topics whose `topic_plan` cap is spent, in plan order."""
    return [topic for topic, cap in topic_caps.items() if topic_counts.get(topic, 0) >= cap]


def record_score(
    session: InterviewSession, *, score: float, topic: Optional[str] = None, tier: Optional[int] = None
) -> InterviewSession:
    """Folds one scored answer into the snapshot and returns the new one.

    Returns a copy rather than mutating in place: every agent in this system
    is a stateless reducer over its inputs (CLAUDE.md §10), and a routing
    snapshot that agents can mutate through a shared reference is exactly the
    hidden state that rule exists to prevent. The tracker stores the result;
    nothing else is allowed to change it.
    """
    updated = _apply_rolling(session, score)
    patch: dict[str, object] = {"answers_scored": session.answers_scored + 1}
    if topic:
        history = {name: list(scores) for name, scores in session.topic_scores.items()}
        history.setdefault(topic, []).append(score)
        patch["topic_scores"] = history
        patch["current_topic"] = topic
    if tier is not None:
        patch["current_tier"] = _clamp_tier(tier)
        if topic:
            patch["topic_tier"] = {**session.topic_tier, topic: _clamp_tier(tier)}
    return updated.model_copy(update=patch)


def _apply_rolling(session: InterviewSession, score: float) -> InterviewSession:
    previous = session.rolling_score
    rolling = score if previous is None else ROLLING_SCORE_ALPHA * score + (1 - ROLLING_SCORE_ALPHA) * previous
    return session.model_copy(update={"rolling_score": round(rolling, 4), "last_score": score})


class NextNode(CamelModel):
    """One routing proposal. See the module docstring for what a proposal is
    and is not allowed to do."""

    topic: Optional[str] = None
    tier: int = Field(default=MIN_TIER, ge=MIN_TIER, le=MAX_TIER)
    #: `None` in the middle band — routing has no opinion, and the Follow-up
    #: Agent's own gap/struggle detectors keep whatever directive they reached.
    #: Routing never invents a directive just to have one.
    directive: Optional[NextActionDirective] = None
    #: Why, in one sentence. Emitted as telemetry and carried on the wire, so
    #: "why did the interview jump to databases?" is answerable afterwards
    #: rather than inferred from the question sequence.
    rationale: str = ""
    #: True when the proposal moved OFF a topic the candidate is stuck on,
    #: rather than off one they finished. The two look identical in the
    #: question sequence and mean opposite things in a report.
    lateral_pivot: bool = False


def determine_next_node(
    session: InterviewSession, *, available_topics: Sequence[str], topic_counts: Optional[dict[str, int]] = None
) -> NextNode:
    """The traffic cop. Reads the last score and proposes the next slot.

    `available_topics` is the session's `topic_plan`, in plan order; exhausted
    topics are filtered out here so a proposal can never point at a topic that
    has spent its cap. `topic_counts` only orders the remaining candidates
    (least-covered first, matching the Question Agent's own ordering) — it
    grants nothing.
    """
    counts = topic_counts or {}
    exhausted = set(session.exhausted_topics)
    candidates = [topic for topic in available_topics if topic not in exhausted]

    if not candidates:
        return NextNode(
            topic=None,
            tier=session.current_tier,
            rationale="every topic on the plan has spent its cap; selection falls through to its own last-resort path",
        )

    score = session.last_score
    if score is None:
        return NextNode(
            topic=_least_covered(candidates, counts),
            tier=session.current_tier,
            rationale="no answer scored yet, so the opening slot is chosen by plan coverage rather than by performance",
        )

    if score > ESCALATE_ABOVE:
        return _escalate(session, candidates, counts, score)

    if score < SUPPORT_BELOW:
        return _support(session, candidates, counts, score)

    return NextNode(
        topic=session.current_topic if session.current_topic in candidates else _least_covered(candidates, counts),
        tier=session.current_tier,
        rationale=(
            f"the last answer scored {score:g}, between {SUPPORT_BELOW:g} and {ESCALATE_ABOVE:g} — "
            "routing has no opinion, so the tier holds and the follow-up decision stands as made"
        ),
    )


def _escalate(session: InterviewSession, candidates: list[str], counts: dict[str, int], score: float) -> NextNode:
    """Strong answer: step the tier up, then take an unexhausted topic.

    Least-covered-first is what makes the worked example work without any
    special case for it — a candidate who has just aced their second
    deployment question is moved onto the area they have not demonstrated yet,
    because that area has the lower count. Staying is still possible and is
    the right outcome when the current topic is the least covered one left.
    """
    tier = min(MAX_TIER, session.current_tier + 1)
    topic = _least_covered(candidates, counts)
    stays = topic == session.current_topic
    return NextNode(
        topic=topic,
        tier=tier,
        directive="escalate" if stays else "pivot",
        rationale=(
            f"the last answer scored {score:g} (> {ESCALATE_ABOVE:g}), so the next slot steps to tier {tier} "
            + (f"and stays on {topic}" if stays else f"and moves to {topic}, the least-covered topic left on the plan")
        ),
    )


def _support(session: InterviewSession, candidates: list[str], counts: dict[str, int], score: float) -> NextNode:
    """Weak answer: step the tier down. Stay on the topic — unless the
    candidate is stuck on the TOPIC rather than on this one question, in which
    case move sideways to something adjacent.

    "Entirely stuck" is a streak, never one answer, and that asymmetry is the
    point: pulling a candidate off a topic after a single weak answer denies
    them the recovery question the lower tier exists to give them, and a
    recovery question is the whole reason the tier steps down here.
    """
    tier = max(MIN_TIER, session.current_tier - 1)
    current = session.current_topic

    if current and current in candidates and not _stuck_on(session, current):
        return NextNode(
            topic=current,
            tier=tier,
            directive="support",
            rationale=(
                f"the last answer scored {score:g} (< {SUPPORT_BELOW:g}), so the next slot stays on {current} "
                f"at tier {tier} to offer a more concrete way in"
            ),
        )

    lateral = _lateral_topic(current, candidates, counts)
    return NextNode(
        topic=lateral,
        tier=tier,
        directive="pivot",
        lateral_pivot=True,
        rationale=(
            f"the last answer scored {score:g} and {current or 'this topic'} has not recovered across "
            f"{STUCK_STREAK} answers, so the next slot moves sideways to {lateral} at tier {tier} rather than "
            "asking a third question the candidate has no way into"
        ),
    )


def _stuck_on(session: InterviewSession, topic: str) -> bool:
    history = session.topic_scores.get(topic) or []
    if len(history) < STUCK_STREAK:
        return False
    return all(score < SUPPORT_BELOW for score in history[-STUCK_STREAK:])


def _least_covered(candidates: list[str], counts: dict[str, int]) -> str:
    """Behavioral topics last, then fewest questions asked, then plan order —
    the same ordering `_pick_from` applies, so a proposal and the selection
    that honours it cannot disagree about what "next" means."""
    order = {topic: index for index, topic in enumerate(candidates)}

    def key(topic: str) -> tuple[int, int, int]:
        definition = get_topic(topic)
        behavioral = 1 if definition and definition.kind == "behavioral" else 0
        return (behavioral, counts.get(topic, 0), order[topic])

    return sorted(candidates, key=key)[0]


def _lateral_topic(current: Optional[str], candidates: list[str], counts: dict[str, int]) -> str:
    """The nearest thing to `current` that the candidate has not been stuck on.

    "Lateral" means same kind first (a technical topic follows a technical
    one — moving a stuck candidate from a system-design question straight to
    "tell me about a conflict" reads as the interview giving up on them), then
    shared vocabulary, then plan coverage. It is deliberately a preference
    order over the plan, never a jump to a topic the plan does not contain:
    a topic outside `topic_plan` has no cap, no relevance evidence and no
    place in the report (INSTRUCTIONS.md §4.3).
    """
    if not current:
        return _least_covered(candidates, counts)

    # The topic being pivoted away from is not a candidate for the pivot.
    # Except when it is the only one left: a lateral move with nowhere to go
    # is still better served by the lower tier on the same topic than by
    # returning nothing and dropping the proposal entirely.
    elsewhere = [topic for topic in candidates if topic != current]
    if not elsewhere:
        return current
    candidates = elsewhere

    definition = get_topic(current)
    current_kind = definition.kind if definition else None
    current_terms = set(definition.terms) if definition else set()
    order = {topic: index for index, topic in enumerate(candidates)}

    def key(topic: str) -> tuple[int, int, int, int]:
        other = get_topic(topic)
        same_kind = 0 if other and current_kind and other.kind == current_kind else 1
        shared = len(current_terms & set(other.terms)) if other else 0
        return (same_kind, -shared, counts.get(topic, 0), order[topic])

    return sorted(candidates, key=key)[0]


def _clamp_tier(tier: int) -> int:
    return max(MIN_TIER, min(MAX_TIER, int(tier)))

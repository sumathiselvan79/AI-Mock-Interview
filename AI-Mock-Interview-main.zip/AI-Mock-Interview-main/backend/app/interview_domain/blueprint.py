"""The systemBlueprint — a role's static evaluation plan, per topic and tier.

~ packages/interview-domain/src/blueprint.ts. INSTRUCTIONS.md §4.3, §4.4
(Stage-6 addition). Answers "what could this role be asked, and what does a
strong answer demonstrate at each tier" — assembled per-role from
`question_bank.py` and `roles.py`. What a *session* actually asks is still
the Question Agent's job and is deliberately NOT decided here.

`dynamic_framing.resume_context_integration_rule` and `jd_anchor_requirement`
are both RULES, not resolved values — templates describing how to pick an
anchor, not the anchor itself. The resolved values are per-candidate and
per-session, built at question-generation time in `app.agents.question`.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from app.interview_domain.question_bank import Tier, questions_for_topic_and_tier, bank_topics
from app.interview_domain.roles import DEFAULT_ROLE_PROFILE, resolve_role_profile
from app.interview_domain.topics import get_topic


@dataclass(frozen=True)
class TierSpec:
    tier: Tier
    target_concept_ids: tuple[str, ...]
    escalation_trigger_condition: Optional[str]  # Null for tier 3.


@dataclass(frozen=True)
class DynamicFraming:
    resume_context_integration_rule: str
    jd_anchor_requirement: str


@dataclass(frozen=True)
class ExtractionMatrix:
    tier_1_baseline: TierSpec
    tier_2_intermediate: TierSpec
    tier_3_advanced: TierSpec


@dataclass(frozen=True)
class EvaluationTopicBlueprint:
    topic_id: str
    dynamic_framing: DynamicFraming
    extraction_matrix: ExtractionMatrix


@dataclass(frozen=True)
class SystemBlueprint:
    role_profile_id: str
    domain_focus: str
    evaluation_topics: tuple[EvaluationTopicBlueprint, ...]


# The condition the Question Agent's per-topic tier selection actually
# evaluates — written out here as data so the rule is documented next to the
# tiers it governs rather than buried in the selection code.
ESCALATION_CONDITION = "the average Eval Tool score across this topic's questions already asked at this tier is >= 4.0 / 5"


def _tier_spec_for(topic: str, tier: Tier) -> TierSpec:
    target_concept_ids: dict[str, None] = {}
    for q in questions_for_topic_and_tier(topic, tier):
        for cid in q.concept_ids:
            target_concept_ids.setdefault(cid, None)
    return TierSpec(
        tier=tier,
        target_concept_ids=tuple(target_concept_ids.keys()),
        escalation_trigger_condition=ESCALATION_CONDITION if tier < 3 else None,
    )


def evaluation_topic_blueprint(topic: str) -> EvaluationTopicBlueprint:
    definition = get_topic(topic)
    sample_terms = ", ".join(definition.terms[:5]) if definition else topic

    return EvaluationTopicBlueprint(
        topic_id=topic,
        dynamic_framing=DynamicFraming(
            resume_context_integration_rule=(
                f'Prefer the candidate profile\'s topic_relevance evidence line for "{topic}" with the highest '
                "relevance_score. If none exists, fall back to the most recent experience entry whose title or "
                f"company text matches one of this topic's terms (e.g. {sample_terms}). If nothing matches, frame "
                "the question generically against the role rather than inventing an anchor."
            ),
            jd_anchor_requirement=(
                f'Use the session\'s jd_fit.topic_relevance entry for "{topic}", if the job description produced '
                "one — its evidence line is the requirement this question should anchor to. If the JD is silent "
                "on this topic, that silence is not a gap to invent: fall back to the role's own default framing "
                "rather than fabricating a requirement the job description never stated."
            ),
        ),
        extraction_matrix=ExtractionMatrix(
            tier_1_baseline=_tier_spec_for(topic, 1),
            tier_2_intermediate=_tier_spec_for(topic, 2),
            tier_3_advanced=_tier_spec_for(topic, 3),
        ),
    )


def build_system_blueprint(role: str) -> SystemBlueprint:
    """The full menu for a role — every topic the bank can address, not just
    the ones a given session ends up asking. Narrowing to a session's actual
    `topic_plan[]` happens downstream in the Question Agent."""
    profile = resolve_role_profile(role) or DEFAULT_ROLE_PROFILE
    return SystemBlueprint(
        role_profile_id=profile.id,
        domain_focus=profile.label,
        evaluation_topics=tuple(evaluation_topic_blueprint(t) for t in bank_topics()),
    )


def blueprint_topic(blueprint: SystemBlueprint, topic_id: str) -> Optional[EvaluationTopicBlueprint]:
    return next((t for t in blueprint.evaluation_topics if t.topic_id == topic_id), None)


def tier_spec(topic: EvaluationTopicBlueprint, tier: Tier) -> TierSpec:
    if tier == 1:
        return topic.extraction_matrix.tier_1_baseline
    if tier == 2:
        return topic.extraction_matrix.tier_2_intermediate
    return topic.extraction_matrix.tier_3_advanced

"""Behavioral / cross-cutting domain questions — ~ packages/interview-domain/src/bank-behavioral.ts."""

from __future__ import annotations

from app.interview_domain.bank_types import RawBankQuestion


def _q(id: str, topic: str, difficulty: int, text: str, signals: list[str]) -> RawBankQuestion:
    return {"id": id, "topic": topic, "type": "behavioral", "difficulty": difficulty, "text": text, "expected_signals": signals}


BEHAVIORAL_QUESTIONS: tuple[RawBankQuestion, ...] = (
    # -- product sense --------------------------------------------------
    _q("prod-1", "product sense", 2, "Tell me about a time you pushed back on a requirement. What did you propose instead?",
       ["understood the underlying need", "concrete alternative", "outcome"]),
    _q("prod-3", "product sense", 4, "Describe something you built that didn't get used. What did you learn, and what would you check earlier next time?",
       ["honest post-hoc analysis", "validation step they skipped", "changed behaviour"]),

    # -- behavioral: leadership ------------------------------------------
    _q("lead-1", "behavioral: leadership", 2, "Tell me about a time you helped someone on your team get better at something. What did you actually do?",
       ["specific person and skill", "their own actions", "observable change"]),
    _q("lead-2", "behavioral: leadership", 3, "Describe a technical decision you owned that other people disagreed with. How did you handle the disagreement?",
       ["took the disagreement seriously", "decision process", "outcome and follow-through"]),
    _q("lead-3", "behavioral: leadership", 4, "Tell me about a time you had to deliver something through people you didn't manage. How did you get it done?",
       ["influence without authority", "specific obstacles", "result"]),

    # -- behavioral: collaboration ----------------------------------------
   #  _q("collab-1", "behavioral: collaboration", 2, "Tell me about a time you worked closely with someone outside engineering. What made it work, or not?",
   #     ["concrete collaboration", "communication adaptation", "outcome"]),
    _q("collab-2", "behavioral: collaboration", 3, "Describe a code review where you and the reviewer disagreed. How did it end?",
       ["specific technical disagreement", "how it resolved", "what they took from it"]),
    _q("collab-3", "behavioral: collaboration", 4, "Tell me about a time a project was blocked by another team. What did you do about it?",
       ["escalation judgement", "own actions vs waiting", "result"]),

    # -- behavioral: ownership ---------------------------------------------
    _q("own-1", "behavioral: ownership", 2, "Tell me about something you shipped end to end. What were you responsible for?",
       ["clear scope of their contribution", "decisions they made", "delivered outcome"]),
    _q("own-2", "behavioral: ownership", 3, "Describe a problem nobody asked you to fix that you fixed anyway. Why that one?",
       ["judgement about what mattered", "action taken", "impact"]),
    _q("own-3", "behavioral: ownership", 4, "Tell me about a commitment you made that you couldn't keep. What did you do?",
       ["early communication", "concrete recovery", "no blame-shifting"]),

    # -- behavioral: handling failure ---------------------------------------
    _q("fail-1", "behavioral: handling failure", 2, "Tell me about a bug you shipped. How did you find out, and what happened next?",
       ["owns the mistake", "detection path", "fix and follow-up"]),
    _q("fail-2", "behavioral: handling failure", 3, "Walk me through an incident you were part of, from the first alert to the follow-up actions.",
       ["timeline", "their specific role", "durable follow-up, not just a hotfix"]),
    _q("fail-3", "behavioral: handling failure", 4, "Describe a failure whose root cause turned out to be a decision you'd made months earlier. How did you handle that?",
       ["traces cause honestly", "systemic rather than personal framing", "what changed after"]),
)

"""Mechanical engineering domain questions — ~ packages/interview-domain/src/bank-mechanical.ts."""

from __future__ import annotations

from app.interview_domain.bank_types import RawBankQuestion


def _q(id: str, topic: str, difficulty: int, text: str, signals: list[str]) -> RawBankQuestion:
    return {"id": id, "topic": topic, "type": "technical", "difficulty": difficulty, "text": text, "expected_signals": signals}


MECHANICAL_QUESTIONS: tuple[RawBankQuestion, ...] = (
    # -- mechanics of materials ---------------------------------------------------
    _q("mom-1", "mechanics of materials", 2, "A beam is loaded in the center. How do you determine where it will fail first?",
       ["bending moment diagram", "stress concentration", "material yield point"]),
    _q("mom-2", "mechanics of materials", 3, "A component failed in fatigue after six months. How do you investigate and redesign?",
       ["S-N curve analysis", "stress raiser identification", "load cycle characterisation"]),
    _q("mom-3", "mechanics of materials", 4, "How would you design a pressure vessel to meet both static yield and fatigue life requirements?",
       ["combined stress state", "ASME code application", "weld joint efficiency"]),

    # -- thermodynamics ---------------------------------------------------
    _q("thermo-1", "thermodynamics", 2, "Explain the first and second laws of thermodynamics with a real-world example from your work.",
       ["energy conservation", "entropy increase", "practical application"]),
    _q("thermo-2", "thermodynamics", 3, "A heat exchanger is underperforming. What factors would you investigate?",
       ["fouling assessment", "flow rate verification", "LMTD analysis"]),
    _q("thermo-3", "thermodynamics", 4, "How would you optimise the thermal efficiency of a combined cycle power plant?",
       ["Brayton-Rankine interaction", "waste heat recovery", "pinch point analysis"]),

    # -- fluid mechanics ---------------------------------------------------
    _q("fluid-1", "fluid mechanics", 2, "Describe the difference between laminar and turbulent flow. How do you know which you have?",
       ["Reynolds number", "flow regime characteristics", "practical identification"]),
    _q("fluid-2", "fluid mechanics", 3, "A piping system has excessive pressure drop. Walk me through your troubleshooting.",
       ["friction factor calculation", "minor loss identification", "system curve analysis"]),
    _q("fluid-3", "fluid mechanics", 4, "How would you design the cooling channels for an injection mold to ensure uniform temperature?",
       ["CFD-guided layout", "heat flux matching", "flow balancing across channels"]),

    # -- machine design ---------------------------------------------------
    _q("mdes-1", "machine design", 2, "How do you select a bearing for a rotating shaft? What information do you need?",
       ["load type and magnitude", "speed and life requirements", "catalogue selection process"]),
    _q("mdes-2", "machine design", 3, "A gear train is generating excessive noise and wear. What's your diagnosis approach?",
       ["contact pattern analysis", "alignment verification", "lubrication check"]),
    _q("mdes-3", "machine design", 4, "Design a power transmission system for a 50kW application with high shock loads.",
       ["service factor application", "component sizing rationale", "redundancy considerations"]),

    # -- cad and 3d modeling ---------------------------------------------------
    _q("cad-1", "cad and 3d modeling", 2, "Walk me through how you create a parametric model. Why parametric rather than direct?",
       ["design intent capture", "feature tree reasoning", "revision flexibility"]),
    _q("cad-2", "cad and 3d modeling", 3, "An assembly of 500+ parts is slow to load and crashes often. How do you manage it?",
       ["simplified representations", "level of detail management", "assembly strategy"]),
    _q("cad-3", "cad and 3d modeling", 4, "How do you ensure that your CAD model is manufacture-ready? What checks do you perform?",
       ["DFM analysis", "draft angles and undercuts", "tolerance stack-up review"]),

    # -- manufacturing processes ---------------------------------------------------
    _q("mfg-1", "manufacturing processes", 2, "Compare CNC machining and 3D printing for producing a small batch of metal parts.",
       ["volume economics", "geometry complexity", "material properties"]),
    _q("mfg-2", "manufacturing processes", 3, "A CNC-machined part consistently fails dimensional inspection. How do you find the root cause?",
       ["tool wear analysis", "fixturing review", "thermal expansion effects"]),
    _q("mfg-3", "manufacturing processes", 4, "How would you transition a prototype from 3D-printed to injection-molded production at 100k units/year?",
       ["design for injection molding", "tooling cost amortisation", "material substitution"]),

    # -- finite element analysis ---------------------------------------------------
    _q("fea-1", "finite element analysis", 2, "You need to run an FEA on a bracket. Walk me through your setup from geometry to results.",
       ["mesh quality considerations", "boundary condition application", "results validation"]),
    _q("fea-2", "finite element analysis", 3, "Your FEA shows stress singularities at sharp corners. Are they real? How do you handle them?",
       ["mesh convergence study", "stress linearisation", "engineering judgement"]),
    _q("fea-3", "finite element analysis", 4, "How would you set up a nonlinear contact analysis for a bolted joint under dynamic loading?",
       ["contact formulation choice", "preload modeling", "convergence strategy"]),

    # -- materials science ---------------------------------------------------
    _q("mat-1", "materials science", 2, "How do you select a material for a new part? What properties do you prioritise?",
       ["load/environment requirements", "cost and availability", "Ashby chart or equivalent"]),
    _q("mat-2", "materials science", 3, "A steel part is corroding in service. How do you determine the mechanism and choose a fix?",
       ["corrosion type identification", "environment analysis", "protection strategy"]),
    _q("mat-3", "materials science", 4, "How would you design a composite layup for a structural panel that must resist bending and impact?",
       ["fiber orientation strategy", "interlaminar shear consideration", "testing protocol"]),

    # -- vibrations and dynamics ---------------------------------------------------
    _q("vib-1", "vibrations and dynamics", 2, "What is resonance, and how have you dealt with it in a real project?",
       ["natural frequency matching", "consequences of resonance", "practical mitigation"]),
    _q("vib-2", "vibrations and dynamics", 3, "A rotating machine has unacceptable vibration levels. How do you diagnose the source?",
       ["frequency spectrum analysis", "1x vs 2x signatures", "phase measurement"]),
    _q("vib-3", "vibrations and dynamics", 4, "How would you design a vibration isolation system for sensitive equipment on a factory floor?",
       ["transmissibility analysis", "isolator selection", "source characterisation"]),

    # -- control systems ---------------------------------------------------
    _q("ctrl-1", "control systems", 2, "Explain how a PID controller works. How do you tune one in practice?",
       ["proportional/integral/derivative roles", "tuning method", "stability awareness"]),
    _q("ctrl-2", "control systems", 3, "A control loop is oscillating. How do you determine whether it's the gains, the sensor, or the plant?",
       ["systematic isolation", "frequency response analysis", "sensor noise assessment"]),
    _q("ctrl-3", "control systems", 4, "How would you design a multi-axis motion controller for a CNC machine with sub-micron accuracy?",
       ["feedforward compensation", "servo bandwidth requirements", "disturbance rejection"]),

    # -- hvac and thermal systems ---------------------------------------------------
    _q("hvac-1", "hvac and thermal systems", 2, "Walk me through a basic refrigeration cycle. Where does energy enter and leave?",
       ["four main components", "phase change process", "energy balance"]),
    _q("hvac-2", "hvac and thermal systems", 3, "A building zone can't maintain temperature setpoint. What do you check?",
       ["load calculation review", "airflow measurement", "equipment capacity match"]),
    _q("hvac-3", "hvac and thermal systems", 4, "How would you design the thermal management system for a data centre with 10MW of IT load?",
       ["PUE optimisation", "free cooling strategy", "redundancy architecture"]),

    # -- robotics and mechatronics ---------------------------------------------------
    _q("robo-1", "robotics and mechatronics", 2, "Describe a robot or automated system you've worked on. What were the key subsystems?",
       ["mechanical/electrical/software breakdown", "sensor selection", "actuator choices"]),
    _q("robo-2", "robotics and mechatronics", 3, "Your robot arm overshoots its target position. How do you improve its accuracy?",
       ["controller tuning", "mechanical compliance", "encoder resolution"]),
    _q("robo-3", "robotics and mechatronics", 4, "How would you plan collision-free paths for a 6-DOF manipulator in a cluttered workspace?",
       ["configuration space planning", "real-time replanning", "safety constraints"]),

    # -- quality and metrology ---------------------------------------------------
    _q("qm-1", "quality and metrology", 2, "How do you verify that a machined part meets its dimensional tolerances?",
       ["measurement instrument selection", "datum reference", "go/no-go criteria"]),
    _q("qm-2", "quality and metrology", 3, "Your production line's Cpk has dropped below target. How do you investigate?",
       ["process variation sources", "measurement system analysis", "corrective action plan"]),
    _q("qm-3", "quality and metrology", 4, "How would you set up a tolerance stack-up analysis for a multi-part assembly?",
       ["worst-case vs statistical approach", "contributor identification", "sensitivity analysis"]),
)

"""Shared types for the question bank — ~ packages/interview-domain/src/bank-types.ts."""

from __future__ import annotations

from typing import Literal, TypedDict


class RawBankQuestion(TypedDict):
    id: str
    topic: str
    type: Literal["behavioral", "technical"]
    difficulty: int
    text: str
    expected_signals: list[str]

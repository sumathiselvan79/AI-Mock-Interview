"""The shared topic vocabulary — ~ packages/interview-domain/src/topics.ts.

The Resume Service Agent scores a resume against these topics, and the
Question Agent plans and selects against the same names. If the two used
different vocabularies, `topic_plan` and `topic_counts` could never line up
and the per-topic quotas in INSTRUCTIONS.md §4.3 would be unenforceable —
which is why this lives in a shared module rather than inside either agent.

Transcribed verbatim from the TS source — the term lists are the actual
matching vocabulary, not paraphrasable content.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Literal, Optional

TopicKind = Literal["technical", "behavioral"]


@dataclass(frozen=True)
class TopicDefinition:
    topic: str
    kind: TopicKind
    terms: tuple[str, ...]


TOPICS: tuple[TopicDefinition, ...] = (
    TopicDefinition("distributed systems", "technical", (
        "distributed", "microservice", "microservices", "sharding", "sharded", "replication",
        "consensus", "raft", "kafka", "event bus", "message queue", "rabbitmq", "pub/sub",
        "eventual consistency", "partition",
    )),
    TopicDefinition("system design", "technical", (
        "system design", "architecture", "architected", "scalability", "scalable", "load balancer",
        "caching", "cache", "throughput", "latency", "capacity planning", "high availability",
    )),
    TopicDefinition("databases", "technical", (
        "postgres", "postgresql", "mysql", "sql", "nosql", "mongodb", "dynamodb", "redis",
        "query optimization", "index", "indexing", "schema", "migration", "transactions",
    )),
    TopicDefinition("apis and services", "technical", (
        "rest", "restful", "graphql", "grpc", "api", "apis", "endpoint", "openapi", "webhook",
    )),
    TopicDefinition("cloud and infrastructure", "technical", (
        "aws", "gcp", "azure", "kubernetes", "k8s", "docker", "terraform", "serverless",
        "lambda", "ec2", "s3", "infrastructure", "ci/cd", "jenkins", "github actions",
    )),
    TopicDefinition("reliability and operations", "technical", (
        "reliability", "sre", "uptime", "sla", "slo", "on-call", "oncall", "incident",
        "postmortem", "monitoring", "observability", "alerting", "prometheus", "grafana", "datadog",
    )),
    TopicDefinition("testing and quality", "technical", (
        "testing", "unit test", "integration test", "test coverage", "tdd", "qa",
        "regression", "end-to-end", "e2e",
    )),
    TopicDefinition("security", "technical", (
        "security", "authentication", "authorization", "oauth", "encryption", "vulnerability",
        "penetration", "compliance", "gdpr", "soc2", "rbac",
    )),
    TopicDefinition("data engineering", "technical", (
        "etl", "data pipeline", "airflow", "spark", "hadoop", "warehouse", "snowflake",
        "batch processing", "streaming", "dbt",
    )),
    TopicDefinition("machine learning", "technical", (
        "machine learning", "ml", "model training", "pytorch", "tensorflow", "nlp",
        "inference", "embedding", "llm", "recommendation",
    )),
    TopicDefinition("frontend engineering", "technical", (
        "react", "next.js", "nextjs", "vue", "angular", "typescript", "css", "tailwind",
        "accessibility", "browser", "frontend", "ui",
    )),
    TopicDefinition("mobile engineering", "technical", (
        "ios", "android", "swift", "kotlin", "react native", "flutter", "mobile app",
    )),
    TopicDefinition("product sense", "behavioral", (
        "product", "roadmap", "user research", "stakeholder", "requirements", "prioritization",
        "customer", "user feedback", "a/b test",
    )),
    TopicDefinition("behavioral: leadership", "behavioral", (
        "led", "leading", "lead", "mentor", "mentored", "mentoring", "managed", "manager",
        "team lead", "coached", "hiring", "onboarded", "tech lead",
    )),
    TopicDefinition("behavioral: collaboration", "behavioral", (
        "collaborated", "cross-functional", "partnered", "pairing", "code review", "design review",
        "worked with", "stakeholders",
    )),
    TopicDefinition("behavioral: ownership", "behavioral", (
        "owned", "ownership", "drove", "delivered", "shipped", "launched", "end-to-end",
        "initiated", "founded",
    )),
    TopicDefinition("behavioral: handling failure", "behavioral", (
        "outage", "incident", "rollback", "regression", "postmortem", "root cause", "bug",
        "recovered", "mitigated",
    )),
    # -- additional software --------------------------------------------
    TopicDefinition("data structures and algorithms", "technical", (
        "algorithm", "data structure", "tree", "graph", "hash map", "linked list", "sorting",
        "dynamic programming", "binary search", "complexity", "big-o", "recursion", "stack", "queue",
    )),
    TopicDefinition("concurrency and parallelism", "technical", (
        "concurrency", "parallel", "thread", "mutex", "lock", "deadlock", "race condition",
        "async", "coroutine", "goroutine", "actor model", "semaphore", "thread pool",
    )),
    TopicDefinition("networking fundamentals", "technical", (
        "tcp", "udp", "http", "https", "tls", "ssl", "dns", "cdn", "proxy", "reverse proxy",
        "websocket", "socket", "ip", "routing", "firewall", "vpn", "nat",
    )),
    TopicDefinition("operating systems", "technical", (
        "operating system", "kernel", "process", "virtual memory", "paging", "file system",
        "syscall", "scheduler", "context switch", "ipc", "linux", "unix",
    )),
    TopicDefinition("devops and ci/cd", "technical", (
        "devops", "continuous integration", "continuous deployment", "pipeline", "build automation",
        "artifact registry", "canary deployment", "blue-green", "feature flag", "argocd", "flux",
    )),
    TopicDefinition("version control and collaboration", "technical", (
        "git", "branching", "merge", "pull request", "code review", "trunk-based", "monorepo",
        "git workflow", "rebase", "cherry-pick",
    )),
    # -- hardware engineering ---------------------------------------------
    TopicDefinition("digital logic design", "technical", (
        "digital logic", "verilog", "vhdl", "fpga", "asic", "rtl", "synthesis", "gate",
        "flip-flop", "combinational", "sequential", "state machine", "timing",
    )),
    TopicDefinition("computer architecture", "technical", (
        "cpu", "processor", "pipeline", "cache hierarchy", "branch prediction", "instruction set",
        "isa", "risc-v", "arm", "x86", "out-of-order", "superscalar", "memory hierarchy",
    )),
    TopicDefinition("embedded systems", "technical", (
        "embedded", "microcontroller", "mcu", "firmware", "rtos", "bare-metal", "bootloader",
        "interrupt", "isr", "watchdog", "stm32", "esp32", "arduino", "raspberry pi",
    )),
    TopicDefinition("pcb design and layout", "technical", (
        "pcb", "printed circuit board", "schematic", "layout", "trace", "pcb via", "impedance",
        "stackup", "gerber", "kicad", "altium", "eagle", "design rule check", "drc",
    )),
    TopicDefinition("hardware verification and testing", "technical", (
        "verification", "validation", "testbench", "simulation", "formal verification",
        "coverage", "uvm", "systemverilog", "assertion", "jtag", "boundary scan", "dft",
        "design for test", "bist",
    )),
    TopicDefinition("soc design", "technical", (
        "system on chip", "soc", "interconnect", "bus protocol", "axi", "apb", "ahb",
        "noc", "ip core", "memory controller", "dma", "peripheral",
    )),
    TopicDefinition("hardware-software interface", "technical", (
        "driver", "device driver", "hal", "bsp", "memory-mapped", "register", "mmio",
        "dts", "device tree", "ioctl", "spi", "i2c", "uart", "usb", "pcie",
    )),
    TopicDefinition("signal integrity and timing", "technical", (
        "signal integrity", "timing analysis", "setup time", "hold time", "clock domain",
        "metastability", "jitter", "eye diagram", "crosstalk", "reflection", "termination",
        "skew", "pll", "cdc",
    )),
    TopicDefinition("low power design", "technical", (
        "low power", "power gating", "clock gating", "voltage scaling", "dvfs", "leakage",
        "power domain", "retention", "power analysis", "dynamic power", "static power",
    )),
    TopicDefinition("semiconductor physics", "technical", (
        "mosfet", "transistor", "cmos", "process node", "fabrication", "lithography",
        "doping", "threshold voltage", "parasitic", "characterization", "spice",
    )),
    # -- mechanical engineering --------------------------------------------
    TopicDefinition("mechanics of materials", "technical", (
        "stress", "strain", "tensile", "compressive", "shear", "yield strength",
        "ultimate strength", "fatigue", "fracture", "elasticity", "plasticity",
        "mohr's circle", "beam bending", "torsion",
    )),
    TopicDefinition("thermodynamics", "technical", (
        "thermodynamics", "entropy", "enthalpy", "carnot", "heat transfer", "conduction",
        "convection", "radiation", "heat exchanger", "thermal efficiency", "first law",
        "second law", "specific heat", "phase change",
    )),
    TopicDefinition("fluid mechanics", "technical", (
        "fluid mechanics", "fluid dynamics", "bernoulli", "reynolds number", "laminar",
        "turbulent", "viscosity", "navier-stokes", "boundary layer", "drag", "lift",
        "pressure drop", "hydraulics", "pneumatics", "pump",
    )),
    TopicDefinition("machine design", "technical", (
        "gear", "bearing", "shaft", "coupling", "belt drive", "chain drive", "cam",
        "mechanism", "linkage", "tolerance", "fit", "gd&t", "factor of safety",
        "design for manufacturing", "dfm",
    )),
    TopicDefinition("cad and 3d modeling", "technical", (
        "cad", "solidworks", "catia", "creo", "fusion 360", "inventor", "parametric",
        "3d modeling", "assembly", "drawing", "bom", "surface modeling", "sheet metal",
    )),
    TopicDefinition("manufacturing processes", "technical", (
        "machining", "cnc", "milling", "turning", "drilling", "casting", "forging",
        "injection molding", "welding", "additive manufacturing", "3d printing",
        "sheet metal fabrication", "stamping", "edm",
    )),
    TopicDefinition("finite element analysis", "technical", (
        "fea", "fem", "finite element", "ansys", "abaqus", "mesh", "convergence",
        "boundary condition", "load case", "static analysis", "modal analysis",
        "nonlinear", "contact analysis", "simulation",
    )),
    TopicDefinition("materials science", "technical", (
        "material selection", "steel", "aluminum", "composite", "polymer", "ceramic",
        "alloy", "heat treatment", "hardness", "corrosion", "microstructure",
        "crystal structure", "phase diagram", "annealing",
    )),
    TopicDefinition("vibrations and dynamics", "technical", (
        "vibration", "natural frequency", "resonance", "damping", "modal analysis",
        "harmonic", "forced vibration", "free vibration", "dynamic response",
        "balancing", "whirling", "critical speed",
    )),
    TopicDefinition("control systems", "technical", (
        "pid", "control system", "feedback control", "transfer function", "bode plot",
        "root locus", "stability", "controller", "actuator", "sensor", "closed loop",
        "open loop", "state space", "servo",
    )),
    TopicDefinition("hvac and thermal systems", "technical", (
        "hvac", "refrigeration", "compressor", "condenser", "evaporator", "air handling",
        "duct", "thermal management", "cooling", "heating", "ventilation", "psychrometric",
    )),
    TopicDefinition("robotics and mechatronics", "technical", (
        "robot", "robotic", "kinematics", "dynamics", "end effector", "manipulator",
        "inverse kinematics", "trajectory planning", "ros", "actuator", "mechatronics",
        "sensor fusion", "degree of freedom", "dof",
    )),
    TopicDefinition("quality and metrology", "technical", (
        "quality control", "metrology", "inspection", "cmm", "tolerance stack",
        "statistical process control", "spc", "six sigma", "cpk", "gauge r&r",
        "measurement uncertainty", "calibration",
    )),
    # -- electrical engineering ---------------------------------------------
    TopicDefinition("circuit analysis", "technical", (
        "circuit", "kirchhoff", "ohm's law", "thevenin", "norton", "impedance",
        "reactance", "phasor", "ac analysis", "dc analysis", "superposition",
        "mesh analysis", "nodal analysis", "rlc",
    )),
    TopicDefinition("analog electronics", "technical", (
        "op-amp", "amplifier", "transistor", "bjt", "mosfet", "diode", "rectifier",
        "filter", "oscillator", "adc", "dac", "analog design", "gain", "bandwidth",
        "negative feedback", "biasing",
    )),
    TopicDefinition("power electronics", "technical", (
        "power electronics", "converter", "inverter", "rectifier", "buck", "boost",
        "switching regulator", "pwm", "igbt", "thyristor", "power factor", "efficiency",
        "dc-dc", "ac-dc",
    )),
    TopicDefinition("power systems", "technical", (
        "power grid", "transmission", "distribution", "power transformer", "generator",
        "load flow", "short circuit", "protection", "relay", "substation", "smart grid",
        "renewable integration", "power quality", "harmonics",
    )),
    TopicDefinition("electromagnetic theory", "technical", (
        "electromagnetic", "maxwell", "antenna", "rf", "microwave", "waveguide",
        "radiation pattern", "smith chart", "impedance matching", "transmission line",
        "emf", "magnetic field", "electric field",
    )),
    TopicDefinition("signal processing", "technical", (
        "dsp", "signal processing", "fourier transform", "fft", "filter design",
        "signal sampling", "nyquist", "aliasing", "convolution", "z-transform", "laplace",
        "modulation", "demodulation",
    )),
    TopicDefinition("communication systems", "technical", (
        "communication", "modulation", "demodulation", "ofdm", "mimo", "5g", "lte",
        "wireless", "channel", "ber", "snr", "encoding", "protocol stack",
        "baseband", "rf front-end",
    )),
    TopicDefinition("electric machines and drives", "technical", (
        "motor", "generator", "induction motor", "synchronous motor", "dc motor",
        "vfd", "variable frequency drive", "torque", "speed control", "brushless",
        "stepper", "servo motor", "winding",
    )),
    TopicDefinition("instrumentation and measurement", "technical", (
        "instrumentation", "measurement", "oscilloscope", "multimeter", "spectrum analyzer",
        "transducer", "strain gauge", "thermocouple", "data acquisition", "daq",
        "signal conditioning", "measurement noise", "measurement precision",
    )),
    TopicDefinition("renewable energy systems", "technical", (
        "solar", "photovoltaic", "wind energy", "battery", "energy storage",
        "inverter", "mppt", "grid-tied", "off-grid", "charge controller",
        "renewable", "microgrid", "power conversion",
    )),
    TopicDefinition("electrical safety and standards", "technical", (
        "nec", "iec", "grounding", "bonding", "arc flash", "lockout tagout", "loto",
        "overcurrent protection", "breaker", "fuse", "ul", "ce marking",
        "electrical safety", "insulation",
    )),
    TopicDefinition("plc and industrial automation", "technical", (
        "plc", "programmable logic controller", "scada", "hmi", "ladder logic",
        "industrial automation", "dcs", "modbus", "profibus", "ethernet/ip",
        "io module", "relay logic", "pid controller",
    )),
)

_BY_NAME: dict[str, TopicDefinition] = {t.topic: t for t in TOPICS}


def get_topic(topic: str) -> Optional[TopicDefinition]:
    return _BY_NAME.get(topic)


def is_known_topic(topic: str) -> bool:
    return topic in _BY_NAME


_METACHAR_RE = re.compile(r"[.*+?^${}()|\[\]\\]")


def term_pattern(term: str) -> re.Pattern[str]:
    """Word-boundary, case-insensitive matcher. Escapes regex metacharacters in terms."""
    escaped = _METACHAR_RE.sub(lambda m: "\\" + m.group(0), term)
    leading = r"\b" if re.match(r"^\w", term) else ""
    trailing = r"\b" if re.search(r"\w$", term) else ""
    return re.compile(f"{leading}{escaped}{trailing}", re.IGNORECASE)

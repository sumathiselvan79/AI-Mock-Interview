"""The fixed "Tell me about yourself" opener — self-intro addition on top of
Stage 6's `systemBlueprint`, INSTRUCTIONS.md §4.3.

Separate from `topics.py`'s `TOPICS`: introduction is not a domain topic a
resume or JD can be relevant to, and it never competes for a topic-plan slot
the Question Agent selects out of `question_budget` (`topic_plan.py`
prepends it, `next_question` excludes it from the budget count). It is a
fixed opener asked outside that budget, always first, exactly once — its
text is not bank-selected or LLM-generated, unlike every other question.
"""

from __future__ import annotations

INTRODUCTION_TOPIC = "introduction"

INTRODUCTION_QUESTION_TEXT = "Tell me about yourself — walk me through your background and what's brought you here today."

INTRODUCTION_QUESTION_BANK_ID = "introduction.opener"

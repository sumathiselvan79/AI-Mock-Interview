"""Transition style + phrasing for a `NextActionGenerator` directive.

~ packages/interview-domain (shared vocabulary, same place `topics.py` and
`blueprint.py` live). INSTRUCTIONS.md §4.4 (Stage 6 addition),
`HUMAN_INTERACTION_FLOW.md` §2/§4/§6 (human-interaction addition).

`transition_style_for` is a pure mapping from `system_directive` — it is not
a second decision, so it belongs next to the shared vocabulary rather than
inside the Follow-up Agent's own logic. The phrase pools are static and
deterministic on purpose: there is no factual claim in "let's shift gears",
so nothing here needs the grounding check soul.md requires of anything an
LLM asserts, and picking a pre-written phrase costs no model call.

Three things live here rather than in any one agent, because more than one
agent needs the same answer and two copies would drift:

 - `transition_style_for` — directive -> style (Stage 6).
 - `CUE_CATALOGUE` / `cues_used_in` — the closed set of conversational cues
   the interview is allowed to open with, and a detector for which of them a
   generated question actually used. That detection is what makes the
   "don't reuse a phrase already used this session" rule in §4 enforceable:
   the Question Agent writes free text, so the only way to know which cue it
   picked is to look for one.
 - `split_leading_cue` — the cue/question boundary the Speech Service pauses
   at (§6). Deliberately the same catalogue, so a cue that is tracked for
   variety is exactly a cue that gets the pause.
"""

from __future__ import annotations

import random
import re
from typing import Literal, Optional

from app.shared_types.interview import NextActionDirective

TransitionStyle = Literal["same_topic", "topic_shift", "supportive_reframe", "none"]

SAME_TOPIC_PHRASES: tuple[str, ...] = (
    "Building on that...",
    "Digging a bit deeper here...",
    "Following up on what you said...",
)

TOPIC_SHIFT_PHRASES: tuple[str, ...] = (
    "Let's shift gears and talk about...",
    "Switching topics — ...",
    "Now I'd like to move to...",
)

# (Human-interaction addition, §2) The opener for a `support` directive.
#
# Every line here is about the QUESTION or the situation, never about the
# answer that triggered it. "That's a big one" describes the question;
# "you got that wrong" would be a verdict this agent does not have and is
# exactly what soul.md §"No fabrication" rules out. Nothing here lowers the
# bar either — the reframe changes the way in, not what a good answer has to
# contain.
SUPPORTIVE_PHRASES: tuple[str, ...] = (
    "Let's come at that from a different angle...",
    "That one covers a lot of ground — let's take a smaller piece of it...",
    "Let's start somewhere more concrete...",
)


def transition_style_for(directive: NextActionDirective) -> TransitionStyle:
    """`escalate`/`drill_down` stay on the same topic; `pivot` moves to
    another one; `support` stays on the topic but asks for an easier way in;
    `conclude` (Harness-only) has no next question to frame."""
    if directive in ("escalate", "drill_down"):
        return "same_topic"
    if directive == "pivot":
        return "topic_shift"
    if directive == "support":
        return "supportive_reframe"
    return "none"


def transition_phrase_for(style: TransitionStyle, *, rng: Optional[random.Random] = None) -> Optional[str]:
    """One deterministic-pool filler phrase for the given style, or `None`
    for `"none"` — there is nothing to say before a directive only the
    Harness Agent's `conclude` sets."""
    chooser = rng or random
    if style == "same_topic":
        return chooser.choice(SAME_TOPIC_PHRASES)
    if style == "topic_shift":
        return chooser.choice(TOPIC_SHIFT_PHRASES)
    if style == "supportive_reframe":
        return chooser.choice(SUPPORTIVE_PHRASES)
    return None


# --------------------------------------------------------------- cue catalogue

#: (Human-interaction addition, §4) The closed set of conversational cues the
#: interview may open a question with. Every entry is either a phrase from the
#: pools above or one of the cues `question-agent/v4`'s prompt offers by
#: example — those are the only ones the model has been shown, so they are the
#: only ones worth tracking.
#:
#: Deliberately NOT a general "does this sound like a transition" detector.
#: Matching loosely would mean recording a cue that was never used and then
#: forbidding a phrase the interview has not actually said yet, which reads as
#: an interview avoiding perfectly natural language for no reason. A phrase
#: absent from this list is simply untracked, which is the safe default.
CUE_CATALOGUE: tuple[str, ...] = (
    # From the pools above.
    "Building on that",
    "Digging a bit deeper here",
    "Following up on what you said",
    "Let's shift gears",
    "Switching topics",
    "Now I'd like to move to",
    "Let's come at that from a different angle",
    "That one covers a lot of ground",
    "Let's start somewhere more concrete",
    # From question-agent/v4's worked examples of natural interviewer cues.
    "As you mentioned",
    "You have mentioned working with",
    "Staying with that",
    "Building on what you just described",
    "Let's move to something different",
    "Let's change tack",
)

# Cues are matched on a normalised form so trailing ellipses, an em dash, a
# comma or doubled whitespace cannot hide a phrase that was in fact used.
_NORMALISE_RE = re.compile(r"[^a-z0-9 ]+")
_WHITESPACE_RE = re.compile(r"\s+")


def _normalise(text: str) -> str:
    return _WHITESPACE_RE.sub(" ", _NORMALISE_RE.sub(" ", (text or "").lower())).strip()


def cues_used_in(text: str) -> list[str]:
    """Which catalogue cues appear in `text`, in catalogue order.

    Substring matching on the normalised form. Used by the harness after a
    question comes back from the Question Agent, so the phrase can be recorded
    as spent for this session (§4) — the agent writes free text, so what it
    actually chose can only be observed, never assumed from the directive.
    """
    haystack = _normalise(text)
    if not haystack:
        return []
    return [cue for cue in CUE_CATALOGUE if _normalise(cue) in haystack]


# ------------------------------------------------------------- cue/question split

# Where a leading conversational clause can end: a sentence boundary, an em
# dash, or an ellipsis. All three are what the prompt's own examples produce.
_BOUNDARY_RE = re.compile(r"(?<=[.!?])\s+|\s*—\s*|\.\.\.\s*|…\s*")

#: A leading clause longer than this is not a cue, it is part of the question.
_MAX_CUE_WORDS = 18


def split_leading_cue(text: str) -> Optional[tuple[str, str]]:
    """(Human-interaction addition, §6) Splits `text` into a leading
    conversational cue and the question proper, or `None` when there is no cue
    to split off.

    Narrow on purpose. A split only happens when all of these hold:

     - the leading segment contains a catalogue cue (so this is the same
       closed set §4 tracks, not a guess about what sounds conversational),
     - the leading segment is short and is not itself a question,
     - something non-empty is left over to be the actual question.

    Anything else returns `None` and the caller synthesises one clip exactly
    as it did before pausing existed. A wrong split would put a pause in the
    middle of a question, which is worse than no pause at all.
    """
    body = (text or "").strip()
    if not body:
        return None

    match = _BOUNDARY_RE.search(body)
    if not match:
        return None

    cue = body[: match.start()].strip()
    rest = body[match.end() :].strip()
    if not cue or not rest:
        return None
    if "?" in cue:
        return None
    if len(cue.split()) > _MAX_CUE_WORDS:
        return None
    if not cues_used_in(cue):
        return None
    return cue, rest

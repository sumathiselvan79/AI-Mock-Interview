"""Micro-acknowledgment vocabulary — `HUMAN_INTERACTION_FLOW.md` §1, §4.

~ packages/interview-domain (static shared vocabulary, same place
`transitions.py` lives).

The beat this fills: `InterviewOrchestrator.submit_answer` used to compute a
score, a follow-up decision and the next spoken turn in one continuous chain,
so the moment a candidate stopped talking a fully-formed response fired. Real
interviewers make a small noise first. That noise is the whole of what this
module decides.

Three properties, all of them deliberate:

 - **No model call.** An acknowledgment carries no claim about the answer, so
   there is nothing for a model to phrase and nothing for the grounding check
   to verify. It is a pre-written token picked by a rule.
 - **Nothing evaluative.** Every phrase below is a receipt for having heard
   the answer, never a judgement of it. "Great." and "Interesting." are absent
   on purpose: this fires BEFORE the Eval Tool has scored anything, so a
   positive noise here would be a verdict the system does not have yet
   (soul.md §"No fabrication").
 - **Two pools, and silence below the confidence floor.** Acknowledging a
   three-word answer the way a two-minute one is acknowledged is exactly what
   reads as canned, and acknowledging a transcript nobody trusts is worse —
   it tells the candidate they were heard when they were not (§1's tradeoff
   note).
"""

from __future__ import annotations

from typing import Optional, Sequence

from app.interview_domain.signals import SHORT_ANSWER_WORDS

#: The kind recorded against `used_phrases` in the Memory Agent, so
#: acknowledgment rotation and transition-cue rotation share one mechanism
#: without sharing a namespace.
PHRASE_KIND = "acknowledgment"

#: A substantive answer: the candidate said something there is a reason to sit
#: with for a moment.
SUBSTANTIVE_ACKS: tuple[str, ...] = (
    "Mm-hm.",
    "Okay.",
    "Got it.",
    "Right.",
    "Understood.",
)

#: A thin answer — short, or trailing off. Still acknowledged, because silence
#: after a struggling candidate stops talking is its own kind of harsh, but
#: acknowledged more lightly so the two do not sound identical.
BRIEF_ACKS: tuple[str, ...] = (
    "Okay.",
    "Alright.",
)

#: Below this word count the answer gets the brief pool. Deliberately the same
#: threshold `followup/server.py`'s `too_short_to_probe` branch uses — the two
#: are the same judgement ("there is not much here yet") and should not be
#: able to disagree, which is why it is imported rather than restated.
MIN_SUBSTANTIVE_WORDS = SHORT_ANSWER_WORDS

#: Below this transcript confidence, nothing is acknowledged at all. Mirrors
#: `followup.server.MIN_CONFIDENCE` and the Speech Service's own floor.
MIN_CONFIDENCE = 0.6


def acknowledgment_for(
    *,
    transcript: str,
    transcript_confidence: Optional[float] = None,
    used_phrases: Sequence[str] = (),
) -> Optional[str]:
    """The micro-acknowledgment to speak before the scoring pipeline starts,
    or `None` when nothing should be said.

    `used_phrases` is this session's acknowledgment history, oldest first, as
    the Memory Agent has it. The pick is the first pool entry that has not been
    used yet; once the pool is exhausted it is the one used longest ago. That
    is what stops a ten-question interview from saying "Mm-hm." ten times,
    which is the failure §4 is about.
    """
    if transcript_confidence is not None and transcript_confidence < MIN_CONFIDENCE:
        return None

    body = (transcript or "").strip()
    if not body:
        return None

    pool = SUBSTANTIVE_ACKS if len(body.split()) >= MIN_SUBSTANTIVE_WORDS else BRIEF_ACKS
    return least_recently_used(pool, used_phrases)


def least_recently_used(pool: Sequence[str], used: Sequence[str]) -> str:
    """First unused entry, else the one whose last use is furthest back.

    Ties break on pool order, so this is fully deterministic — the same session
    replayed produces the same acknowledgments, which is what makes the
    behaviour testable at all.

    Public because `continuers.py` (§8) rotates four more pools through exactly
    this rule. It is one rotation policy read by two modules, and two copies of
    it would be two policies the first time one of them was tuned — the same
    reasoning that moved `SHORT_ANSWER_WORDS` into `signals.py`.
    """
    last_use: dict[str, int] = {}
    for index, phrase in enumerate(used):
        last_use[phrase] = index

    unused = [phrase for phrase in pool if phrase not in last_use]
    if unused:
        return unused[0]
    return min(pool, key=lambda phrase: (last_use[phrase], pool.index(phrase)))

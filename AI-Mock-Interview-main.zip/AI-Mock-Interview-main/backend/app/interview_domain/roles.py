"""Role profiles — ~ packages/interview-domain/src/roles.ts.

The topics a role demands regardless of what a candidate's resume happens
to showcase (INSTRUCTIONS.md §4.3, soul.md §"Balanced coverage" — "a thin
resume in a required area is a reason to ask about it, not a reason to skip
it").
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class RoleProfile:
    id: str
    label: str
    matchers: tuple[str, ...]
    required_topics: tuple[str, ...]
    coding_round: bool
    question_budget: int


# Every role gets these. They are what an interviewer probes for in any
# role, and they keep a session from becoming a pure trivia quiz.
UNIVERSAL_REQUIRED_TOPICS: tuple[str, ...] = ("behavioral: ownership", "behavioral: collaboration")

ROLE_PROFILES: tuple[RoleProfile, ...] = (
    RoleProfile("backend-engineer", "Backend Engineer",
                ("backend", "back-end", "server-side", "platform engineer", "software engineer"),
                ("system design", "databases", "apis and services", "reliability and operations"), True, 8),
    RoleProfile("frontend-engineer", "Frontend Engineer",
                ("frontend", "front-end", "web engineer", "ui engineer"),
                ("frontend engineering", "apis and services", "testing and quality"), True, 8),
    RoleProfile("fullstack-engineer", "Full-Stack Engineer",
                ("full stack", "full-stack", "fullstack"),
                ("frontend engineering", "apis and services", "databases", "system design"), True, 8),
    RoleProfile("data-engineer", "Data Engineer",
                ("data engineer", "analytics engineer"),
                ("data engineering", "databases", "cloud and infrastructure"), True, 8),
    RoleProfile("ml-engineer", "Machine Learning Engineer",
                ("machine learning", "ml engineer", "ai engineer", "research engineer"),
                ("machine learning", "data engineering", "system design"), True, 8),
    RoleProfile("sre", "Site Reliability Engineer",
                ("sre", "site reliability", "devops", "infrastructure engineer"),
                ("reliability and operations", "cloud and infrastructure", "system design"), True, 8),
    RoleProfile("mobile-engineer", "Mobile Engineer",
                ("mobile", "ios engineer", "android engineer"),
                ("mobile engineering", "apis and services", "testing and quality"), True, 8),
    RoleProfile("engineering-manager", "Engineering Manager",
                ("engineering manager", "em ", "director of engineering", "head of engineering"),
                ("behavioral: leadership", "system design", "product sense"), False, 8),
    RoleProfile("product-manager", "Product Manager",
                ("product manager", "product owner", "pm "),
                ("product sense", "behavioral: leadership"), False, 8),

    # -- hardware engineering roles ---------------------------------------
    RoleProfile("hardware-engineer", "Hardware Engineer",
                ("hardware engineer", "hw engineer", "chip designer", "asic engineer", "rtl engineer"),
                ("digital logic design", "computer architecture", "hardware verification and testing", "signal integrity and timing"), False, 8),
    RoleProfile("embedded-engineer", "Embedded Systems Engineer",
                ("embedded", "firmware engineer", "firmware developer", "embedded software"),
                ("embedded systems", "hardware-software interface", "digital logic design"), True, 8),
    RoleProfile("fpga-engineer", "FPGA Engineer",
                ("fpga", "fpga engineer", "fpga developer"),
                ("digital logic design", "hardware verification and testing", "signal integrity and timing"), False, 8),
    RoleProfile("verification-engineer", "Verification Engineer",
                ("verification engineer", "dv engineer", "design verification"),
                ("hardware verification and testing", "digital logic design", "soc design"), False, 8),

    # -- mechanical engineering roles ---------------------------------------
    RoleProfile("mechanical-engineer", "Mechanical Engineer",
                ("mechanical engineer", "mech engineer", "mechanical design"),
                ("mechanics of materials", "machine design", "cad and 3d modeling", "manufacturing processes"), False, 8),
    RoleProfile("thermal-engineer", "Thermal Engineer",
                ("thermal engineer", "heat transfer engineer", "hvac engineer"),
                ("thermodynamics", "hvac and thermal systems", "fluid mechanics"), False, 8),
    RoleProfile("manufacturing-engineer", "Manufacturing Engineer",
                ("manufacturing engineer", "process engineer", "production engineer"),
                ("manufacturing processes", "quality and metrology", "materials science"), False, 8),
    RoleProfile("robotics-engineer", "Robotics Engineer",
                ("robotics engineer", "automation engineer", "mechatronics engineer"),
                ("robotics and mechatronics", "control systems", "embedded systems"), True, 8),
    RoleProfile("cae-analyst", "CAE / Simulation Analyst",
                ("cae", "simulation engineer", "fea analyst", "stress analyst", "structural analyst"),
                ("finite element analysis", "mechanics of materials", "vibrations and dynamics"), False, 8),

    # -- electrical engineering roles ---------------------------------------
    RoleProfile("electrical-engineer", "Electrical Engineer",
                ("electrical engineer", "ee ", "power engineer"),
                ("circuit analysis", "power systems", "electrical safety and standards"), False, 8),
    RoleProfile("analog-design-engineer", "Analog Design Engineer",
                ("analog engineer", "analog design", "mixed-signal"),
                ("analog electronics", "circuit analysis", "signal processing"), False, 8),
    RoleProfile("power-electronics-engineer", "Power Electronics Engineer",
                ("power electronics", "power supply engineer", "converter design"),
                ("power electronics", "circuit analysis", "electric machines and drives"), False, 8),
    RoleProfile("rf-engineer", "RF / Communications Engineer",
                ("rf engineer", "radio frequency", "antenna engineer", "wireless engineer", "communications engineer"),
                ("electromagnetic theory", "communication systems", "signal processing"), False, 8),
    RoleProfile("controls-engineer", "Controls / Automation Engineer",
                ("controls engineer", "plc programmer", "automation engineer", "control systems"),
                ("plc and industrial automation", "control systems", "instrumentation and measurement"), False, 8),
    RoleProfile("renewable-energy-engineer", "Renewable Energy Engineer",
                ("renewable energy", "solar engineer", "wind engineer", "energy engineer"),
                ("renewable energy systems", "power systems", "power electronics"), False, 8),
)

# Falls back to a generic technical profile rather than raising: an unknown
# role title must still produce a runnable interview.
DEFAULT_ROLE_PROFILE = RoleProfile(
    "generic-technical", "Technical Individual Contributor", (), ("system design", "testing and quality"), True, 8
)


def resolve_role_profile(role: str) -> RoleProfile:
    normalized = f" {role.lower()} "
    # Longest matcher first, so "engineering manager" beats "software engineer".
    candidates = sorted(
        ((profile, matcher) for profile in ROLE_PROFILES for matcher in profile.matchers),
        key=lambda pair: len(pair[1]),
        reverse=True,
    )
    for profile, matcher in candidates:
        if matcher.lower() in normalized:
            return profile
    return DEFAULT_ROLE_PROFILE


def required_topics_for(role: str) -> list[str]:
    """Required topics for a role, including the universal behavioral ones."""
    profile = resolve_role_profile(role)
    seen: dict[str, None] = {}
    for topic in (*profile.required_topics, *UNIVERSAL_REQUIRED_TOPICS):
        seen.setdefault(topic, None)
    return list(seen.keys())

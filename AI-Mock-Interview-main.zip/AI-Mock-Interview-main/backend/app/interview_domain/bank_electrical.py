"""Electrical engineering domain questions — ~ packages/interview-domain/src/bank-electrical.ts."""

from __future__ import annotations

from app.interview_domain.bank_types import RawBankQuestion


def _q(id: str, topic: str, difficulty: int, text: str, signals: list[str]) -> RawBankQuestion:
    return {"id": id, "topic": topic, "type": "technical", "difficulty": difficulty, "text": text, "expected_signals": signals}


ELECTRICAL_QUESTIONS: tuple[RawBankQuestion, ...] = (
    # -- circuit analysis ---------------------------------------------------
    _q("ckt-1", "circuit analysis", 2, "You have a resistive network and need to find the current through one branch. What method do you use?",
       ["KVL/KCL application", "Thevenin or mesh/nodal choice", "systematic approach"]),
    _q("ckt-2", "circuit analysis", 3, "An RLC circuit is ringing longer than expected. How do you characterise the damping?",
       ["damping ratio calculation", "Q factor relationship", "measurement approach"]),
    _q("ckt-3", "circuit analysis", 4, "How would you analyse a circuit with multiple coupled inductors and nonlinear elements?",
       ["SPICE simulation setup", "coupling coefficient modeling", "convergence challenges"]),

    # -- analog electronics ---------------------------------------------------
    _q("analog-1", "analog electronics", 2, "Design a non-inverting amplifier with a gain of 10. What practical issues do you consider?",
       ["resistor ratio", "op-amp bandwidth/GBP", "input/output range"]),
    _q("analog-2", "analog electronics", 3, "Your ADC readings have noise that wasn't in the datasheet. How do you track down the source?",
       ["grounding/layout review", "power supply noise measurement", "signal conditioning evaluation"]),
    _q("analog-3", "analog electronics", 4, "How would you design a precision current sense circuit for a 0-50A range with 1% accuracy?",
       ["shunt vs Hall effect tradeoff", "thermal drift compensation", "common-mode rejection"]),

    # -- power electronics ---------------------------------------------------
    _q("pe-1", "power electronics", 2, "Explain the difference between a buck and a boost converter. When would you use each?",
       ["voltage step-down vs step-up", "duty cycle relationship", "application examples"]),
    _q("pe-2", "power electronics", 3, "Your switch-mode power supply has excessive output ripple. What are the likely causes?",
       ["output capacitor ESR", "inductor sizing", "switching frequency considerations"]),
    _q("pe-3", "power electronics", 4, "How would you design a 3-phase inverter for a motor drive with regenerative braking?",
       ["switching topology choice", "deadtime insertion", "DC bus energy management"]),

    # -- power systems ---------------------------------------------------
    _q("ps-1", "power systems", 2, "What is the purpose of a transformer in power distribution? Walk me through the sizing considerations.",
       ["voltage transformation", "kVA rating vs load", "impedance and losses"]),
    _q("ps-2", "power systems", 3, "A feeder trips on overcurrent but the load hasn't changed. How do you investigate?",
       ["fault current analysis", "protection coordination review", "insulation testing"]),
    _q("ps-3", "power systems", 4, "How would you integrate a 50MW solar farm into an existing distribution network?",
       ["grid interconnection study", "voltage regulation impact", "protection scheme redesign"]),

    # -- electromagnetic theory ---------------------------------------------------
    _q("em-1", "electromagnetic theory", 2, "What is impedance matching and why does it matter in RF systems?",
       ["maximum power transfer", "reflection coefficient", "Smith chart basics"]),
    _q("em-2", "electromagnetic theory", 3, "Your PCB antenna's radiation pattern doesn't match simulation. How do you debug?",
       ["ground plane effects", "nearby conductor coupling", "measurement setup validation"]),
    _q("em-3", "electromagnetic theory", 4, "How would you design an antenna array for beam steering in a 5G base station?",
       ["element spacing for grating lobe avoidance", "phase shift control", "mutual coupling compensation"]),

    # -- signal processing ---------------------------------------------------
    _q("sp-1", "signal processing", 2, "What is the Nyquist theorem, and what happens if you violate it?",
       ["sampling rate requirement", "aliasing explanation", "anti-aliasing filter"]),
    _q("sp-2", "signal processing", 3, "Design a digital filter to remove 50Hz mains noise from a biomedical signal.",
       ["notch filter design", "IIR vs FIR tradeoff", "phase distortion consideration"]),
    _q("sp-3", "signal processing", 4, "How would you implement real-time spectral analysis on an FPGA for a wideband receiver?",
       ["FFT architecture choice", "windowing strategy", "throughput vs resource tradeoff"]),

    # -- communication systems ---------------------------------------------------
    _q("comm-1", "communication systems", 2, "Explain the difference between AM, FM, and digital modulation. When is each appropriate?",
       ["bandwidth efficiency", "noise resilience", "application context"]),
    _q("comm-2", "communication systems", 3, "A wireless link has high bit error rate at range. What factors do you investigate?",
       ["link budget analysis", "multipath effects", "modulation/coding scheme"]),
    _q("comm-3", "communication systems", 4, "How does OFDM handle frequency-selective fading, and what are its weaknesses?",
       ["subcarrier orthogonality", "cyclic prefix purpose", "PAPR problem"]),

    # -- electric machines and drives ---------------------------------------------------
    _q("emd-1", "electric machines and drives", 2, "Explain the operating principle of a 3-phase induction motor. How is speed controlled?",
       ["rotating magnetic field", "slip concept", "VFD application"]),
    _q("emd-2", "electric machines and drives", 3, "A motor runs hot at rated load. What are the possible causes?",
       ["voltage imbalance check", "ventilation/cooling review", "load profile analysis"]),
    _q("emd-3", "electric machines and drives", 4, "How would you design the control algorithm for a PMSM drive with field weakening?",
       ["d-q axis control", "flux weakening region constraints", "current limiting strategy"]),

    # -- instrumentation and measurement ---------------------------------------------------
    _q("inst-1", "instrumentation and measurement", 2, "How do you select a sensor for measuring temperature in an industrial process?",
       ["sensor type comparison", "range and environment", "signal conditioning needs"]),
    _q("inst-2", "instrumentation and measurement", 3, "Your measurements drift over time despite a stable process. What's causing it?",
       ["calibration verification", "thermal effects on sensor", "reference stability"]),
    _q("inst-3", "instrumentation and measurement", 4, "How would you design a data acquisition system that measures 64 channels at 100kHz each?",
       ["multiplexing vs parallel ADC", "channel-to-channel isolation", "timing synchronisation"]),

    # -- renewable energy systems ---------------------------------------------------
    _q("ren-1", "renewable energy systems", 2, "How does a grid-tied solar inverter work? What happens when the grid goes down?",
       ["DC-AC conversion", "MPPT concept", "anti-islanding protection"]),
    _q("ren-2", "renewable energy systems", 3, "A solar installation is producing 20% less than predicted. How do you diagnose?",
       ["shading analysis", "string voltage comparison", "inverter efficiency check"]),
    _q("ren-3", "renewable energy systems", 4, "How would you design a microgrid with solar, battery storage, and a diesel backup?",
       ["load profiling and sizing", "dispatch strategy", "battery cycling optimisation"]),

    # -- electrical safety and standards ---------------------------------------------------
    _q("esafe-1", "electrical safety and standards", 2, "What is the purpose of grounding in an electrical installation?",
       ["fault current path", "ground resistance testing", "personnel safety"]),
    _q("esafe-2", "electrical safety and standards", 3, "How do you perform an arc flash hazard analysis for a switchgear installation?",
       ["incident energy calculation", "boundary determination", "PPE selection"]),
    _q("esafe-3", "electrical safety and standards", 4, "How would you design the protection coordination for a multi-level industrial distribution system?",
       ["time-current curve coordination", "selectivity between devices", "short-circuit study"]),

    # -- plc and industrial automation ---------------------------------------------------
    _q("plc-1", "plc and industrial automation", 2, "How does a PLC control a process? Walk me through a simple conveyor example.",
       ["scan cycle concept", "input/output mapping", "ladder logic basics"]),
    _q("plc-2", "plc and industrial automation", 3, "A PLC-controlled process occasionally produces defective parts. How do you use data to find the cause?",
       ["data logging analysis", "timing correlation", "sensor validation"]),
    _q("plc-3", "plc and industrial automation", 4, "How would you architect a SCADA system for a water treatment plant with 2000 I/O points?",
       ["network topology design", "redundancy requirements", "cybersecurity considerations"]),
)

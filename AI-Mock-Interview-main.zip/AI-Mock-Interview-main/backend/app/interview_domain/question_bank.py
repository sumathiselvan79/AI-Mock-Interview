"""The question bank the Question Agent selects from — ~ packages/interview-domain/src/question-bank.ts.

Questions are data, not prompt strings scattered through an agent, so the
set can be reviewed by whoever owns interview subject-matter expertise
(INSTRUCTIONS.md §10) and so difficulty calibration is auditable. Every
entry carries `expected_signals` — what a strong answer would contain —
which is what the Follow-up Agent probes against and what the Eval Tool's
rubric looks for.

Difficulty is 1-5. The Question Agent opens below the target and works up
(soul.md §4).
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Literal

from app.interview_domain.bank_behavioral import BEHAVIORAL_QUESTIONS
from app.interview_domain.bank_electrical import ELECTRICAL_QUESTIONS
from app.interview_domain.bank_hardware import HARDWARE_QUESTIONS
from app.interview_domain.bank_mechanical import MECHANICAL_QUESTIONS
from app.interview_domain.bank_software import SOFTWARE_QUESTIONS
from app.interview_domain.bank_types import RawBankQuestion

Tier = Literal[1, 2, 3]


def tier_of(difficulty: int) -> Tier:
    if difficulty <= 2:
        return 1
    if difficulty == 3:
        return 2
    return 3


_SLUG_RE = re.compile(r"[^a-z0-9]+")


def _slug(text: str) -> str:
    return _SLUG_RE.sub("-", text.lower()).strip("-")


def concept_id(topic: str, tier: Tier, label: str) -> str:
    """A stable id for one thing a strong answer demonstrates, scoped to
    topic+tier so the same surface phrase in two topics doesn't collide."""
    return f"{_slug(topic)}.t{tier}.{_slug(label)}"


def label_from_concept_id(concept_id_: str) -> str:
    """Best-effort inverse of `concept_id`'s label segment, for callers that
    only carry the id across the wire and need something to term-match
    against."""
    last_segment = concept_id_.split(".")[-1] if concept_id_ else concept_id_
    return last_segment.replace("-", " ")


@dataclass(frozen=True)
class BankQuestion:
    id: str
    topic: str
    type: Literal["behavioral", "technical"]
    difficulty: int
    tier: Tier
    text: str
    expected_signals: tuple[str, ...]
    concept_ids: tuple[str, ...]


def _with_tier_and_concepts(q: RawBankQuestion) -> BankQuestion:
    tier = tier_of(q["difficulty"])
    return BankQuestion(
        id=q["id"],
        topic=q["topic"],
        type=q["type"],
        difficulty=q["difficulty"],
        tier=tier,
        text=q["text"],
        expected_signals=tuple(q["expected_signals"]),
        concept_ids=tuple(concept_id(q["topic"], tier, label) for label in q["expected_signals"]),
    )


_ALL_RAW_QUESTIONS: tuple[RawBankQuestion, ...] = (
    *SOFTWARE_QUESTIONS,
    *HARDWARE_QUESTIONS,
    *MECHANICAL_QUESTIONS,
    *ELECTRICAL_QUESTIONS,
    *BEHAVIORAL_QUESTIONS,
)

QUESTION_BANK: tuple[BankQuestion, ...] = tuple(_with_tier_and_concepts(q) for q in _ALL_RAW_QUESTIONS)


def questions_for_topic(topic: str) -> list[BankQuestion]:
    return [q for q in QUESTION_BANK if q.topic == topic]


def questions_for_topic_and_tier(topic: str, tier: Tier) -> list[BankQuestion]:
    return [q for q in QUESTION_BANK if q.topic == topic and q.tier == tier]


def bank_topics() -> list[str]:
    seen: dict[str, None] = {}
    for q in QUESTION_BANK:
        seen.setdefault(q.topic, None)
    return list(seen.keys())

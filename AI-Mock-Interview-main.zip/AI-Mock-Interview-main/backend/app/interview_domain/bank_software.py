"""Software engineering domain questions — ~ packages/interview-domain/src/bank-software.ts."""

from __future__ import annotations

from app.interview_domain.bank_types import RawBankQuestion


def _q(id: str, topic: str, difficulty: int, text: str, signals: list[str]) -> RawBankQuestion:
    return {"id": id, "topic": topic, "type": "technical", "difficulty": difficulty, "text": text, "expected_signals": signals}


SOFTWARE_QUESTIONS: tuple[RawBankQuestion, ...] = (
    # -- distributed systems ------------------------------------------------
    _q("ds-1", "distributed systems", 2, "Walk me through a system you've worked on where components ran on more than one machine. What talked to what, and why was it split that way?",
       ["component boundaries", "reason for the split", "communication mechanism"]),
    _q("ds-2", "distributed systems", 3, "You have a service that publishes events to a queue and a consumer that occasionally processes the same event twice. How would you find out why, and what would you change?",
       ["at-least-once delivery", "idempotency", "diagnosis before fix"]),
    _q("ds-3", "distributed systems", 4, "Two services need to stay in agreement about a piece of state, but the network between them is unreliable. Talk me through the tradeoffs you'd weigh.",
       ["consistency vs availability", "partition behaviour", "concrete tradeoff, not just CAP recital"]),

    # -- system design --------------------------------------------------------
    _q("sd-1", "system design", 2, "Design a URL shortener. Start wherever you'd naturally start, and tell me what you'd want to know before writing any code.",
       ["clarifying questions", "data model", "read/write ratio"]),
    _q("sd-2", "system design", 3, "A read-heavy endpoint is slow under load. Take me through how you'd decide between caching, an index, and a schema change.",
       ["measurement first", "tradeoffs of each option", "invalidation cost"]),
    _q("sd-3", "system design", 4, "Design the write path for a system that has to accept 50,000 events a second and lose none of them. Where does it break first?",
       ["buffering/backpressure", "durability guarantees", "identifies own bottleneck"]),

    # -- databases --------------------------------------------------------------
    _q("db-1", "databases", 2, "Tell me about a schema you designed. What did you get right, and what would you change now?",
       ["concrete schema", "normalisation choice", "hindsight with a reason"]),
    _q("db-2", "databases", 3, "A query that used to take 20ms now takes 4 seconds and nothing about the query changed. How do you work out what happened?",
       ["query plan", "data growth/statistics", "index selectivity"]),
    _q("db-3", "databases", 4, "You need to add a NOT NULL column to a table with 500 million rows, with no downtime. How do you do it?",
       ["backfill in batches", "lock behaviour", "rollout ordering with the app"]),

    # -- apis and services --------------------------------------------------------
    _q("api-1", "apis and services", 2, "Take an API you've built and walk me through one endpoint: its inputs, outputs, and what happens when it fails.",
       ["contract clarity", "error semantics", "status codes or equivalent"]),
    _q("api-2", "apis and services", 3, "You need to change the shape of a response field that other teams already depend on. How do you ship that?",
       ["versioning or additive change", "consumer migration", "deprecation window"]),
    _q("api-3", "apis and services", 4, "A client retries on timeout, and your endpoint isn't idempotent. Walk me through what goes wrong and how you'd fix it properly.",
       ["duplicate side effects", "idempotency keys", "server-side deduplication"]),

    # -- cloud and infrastructure ---------------------------------------------------
    _q("cloud-1", "cloud and infrastructure", 2, "Describe how something you built got from your laptop to production. What ran that pipeline?",
       ["build/deploy stages", "environments", "who or what triggers it"]),
    _q("cloud-2", "cloud and infrastructure", 3, "How would you roll out a risky change to a service with a lot of traffic, so that a mistake costs as little as possible?",
       ["staged rollout", "rollback plan", "signal that triggers rollback"]),
    _q("cloud-3", "cloud and infrastructure", 4, "Your infrastructure is defined in code, but production has drifted from it. How do you find the drift and get back to a state you trust?",
       ["drift detection", "reconciliation risk", "prevention, not just cleanup"]),

    # -- reliability and operations ---------------------------------------------------
    _q("rel-1", "reliability and operations", 2, "What did you watch to know whether your service was healthy, and why those signals?",
       ["specific metrics", "user-facing vs machine-facing", "reasoning behind the choice"]),
    _q("rel-2", "reliability and operations", 3, "You're paged at 3am for a service you didn't write. Walk me through your first ten minutes.",
       ["stabilise before diagnose", "where they look first", "communication"]),
    _q("rel-3", "reliability and operations", 4, "How would you set an SLO for a service, and what would you actually do differently once you had one?",
       ["ties to user impact", "error budget consequence", "avoids vanity targets"]),

    # -- testing and quality ---------------------------------------------------
    _q("test-1", "testing and quality", 2, "For something you've built recently — what did you test, and what did you deliberately not test?",
       ["explicit tradeoff", "risk-based reasoning", "concrete examples"]),
    _q("test-2", "testing and quality", 3, "A test in CI fails about one run in twenty and nobody can reproduce it locally. What do you do?",
       ["treats flakiness as a real defect", "isolation strategy", "doesn't just retry"]),
    _q("test-3", "testing and quality", 4, "You inherit a service with no tests and a weekly release. Where do you add tests first, and how do you justify the time?",
       ["prioritises by risk", "characterisation tests", "makes the case in business terms"]),

    # -- security ---------------------------------------------------
    _q("sec-1", "security", 2, "How did users authenticate in a system you worked on, and what was stored on your side?",
       ["credential handling", "hashing vs encryption", "session/token lifetime"]),
    _q("sec-2", "security", 3, "How would you decide what a given service is allowed to access, and where would you enforce it?",
       ["least privilege", "enforcement point", "auditability"]),
    _q("sec-3", "security", 4, "You find a credential committed to a repository eighteen months ago. Walk me through what happens next.",
       ["rotate first", "assess exposure", "prevention going forward"]),

    # -- data engineering ---------------------------------------------------
    _q("de-1", "data engineering", 2, "Describe a data pipeline you've worked on end to end — where the data came from and what consumed it.",
       ["source to sink", "scheduling", "consumers and their needs"]),
    _q("de-2", "data engineering", 3, "A nightly job half-completed and left partial data behind. How do you make that situation not hurt?",
       ["idempotent reruns", "atomic swap or staging", "detection"]),
    _q("de-3", "data engineering", 4, "Downstream users say a dashboard number is wrong. How do you trace it back, and how would you stop it recurring?",
       ["lineage", "data quality checks", "contract with producers"]),

    # -- machine learning ---------------------------------------------------
    _q("ml-1", "machine learning", 2, "Tell me about a model you worked with. What was it predicting, and how did you know whether it was any good?",
       ["problem framing", "metric choice", "baseline comparison"]),
    _q("ml-2", "machine learning", 3, "Your model scores well offline and disappoints in production. What are the likely reasons, and how do you check?",
       ["train/serve skew", "distribution shift", "evaluation design"]),
    _q("ml-3", "machine learning", 4, "How would you design the serving path for a model that has to answer in under 100ms at high volume?",
       ["batching/caching", "model size tradeoffs", "fallback behaviour"]),

    # -- frontend engineering ---------------------------------------------------
    _q("fe-1", "frontend engineering", 2, "Take a screen you've built and walk me through how state flowed through it.",
       ["state ownership", "data fetching", "why that structure"]),
    _q("fe-2", "frontend engineering", 3, "A page feels slow on a mid-range phone but fine on your laptop. How do you find out why?",
       ["measures before optimising", "bundle/render/network split", "real device conditions"]),
    _q("fe-3", "frontend engineering", 4, "How would you make a complex interactive component usable with a keyboard and a screen reader, and how would you verify it?",
       ["focus management", "semantics over ARIA patches", "actual verification method"]),

    # -- mobile engineering ---------------------------------------------------
    _q("mob-1", "mobile engineering", 2, "How did your app behave when the network dropped mid-action?",
       ["offline handling", "user feedback", "retry/queue"]),
    _q("mob-2", "mobile engineering", 3, "You need to ship a fix to users today, but the app store review takes days. What are your options?",
       ["server-side toggles", "remote config", "release planning"]),
    _q("mob-3", "mobile engineering", 4, "How would you diagnose a battery drain complaint you can't reproduce?",
       ["instrumentation", "background work audit", "narrowing by cohort"]),

    # -- data structures and algorithms ---------------------------------------------------
    _q("dsa-1", "data structures and algorithms", 2, "You need to look up items by key with very fast reads. Walk me through which data structure you'd choose and why.",
       ["hash map understanding", "collision handling", "time complexity reasoning"]),
    _q("dsa-2", "data structures and algorithms", 3, "You have a sorted list of a million items and need to find one. What approach do you take, and what's the cost?",
       ["binary search", "logarithmic complexity", "edge cases"]),
    _q("dsa-3", "data structures and algorithms", 4, "Describe a problem you solved using dynamic programming. How did you identify the substructure?",
       ["overlapping subproblems", "memoization vs tabulation", "state definition"]),

    # -- concurrency and parallelism ---------------------------------------------------
    _q("conc-1", "concurrency and parallelism", 2, "Describe a situation where two threads or processes needed to access the same resource. How did you handle it?",
       ["mutual exclusion concept", "lock or equivalent", "awareness of contention"]),
    _q("conc-2", "concurrency and parallelism", 3, "A multithreaded application occasionally produces wrong results but works fine under a debugger. What's your diagnosis approach?",
       ["race condition suspicion", "reproducibility challenges", "systematic narrowing"]),
    _q("conc-3", "concurrency and parallelism", 4, "How would you design a work-stealing scheduler for a thread pool? What are the tradeoffs?",
       ["load balancing", "lock-free queues", "cache locality considerations"]),

    # -- networking fundamentals ---------------------------------------------------
    _q("net-1", "networking fundamentals", 2, "Walk me through what happens from when you type a URL into a browser to when you see the page.",
       ["dns resolution", "tcp handshake", "http request/response"]),
    _q("net-2", "networking fundamentals", 3, "A service can reach the internet but not another service on the same network. How do you debug this?",
       ["layer-by-layer diagnosis", "firewall/security groups", "dns vs routing"]),
    _q("net-3", "networking fundamentals", 4, "How would you design a system to handle 100k concurrent WebSocket connections on a single host?",
       ["event-driven architecture", "connection pooling limits", "memory per connection"]),

    # -- operating systems ---------------------------------------------------
    _q("os-1", "operating systems", 2, "What's the difference between a process and a thread? When would you pick one over the other?",
       ["isolation vs shared memory", "context switch cost", "use-case reasoning"]),
    _q("os-2", "operating systems", 3, "A process is using far more memory than you expect. How do you investigate?",
       ["virtual vs resident memory", "tooling (top/pmap/etc)", "leak vs expected growth"]),
    _q("os-3", "operating systems", 4, "Explain how virtual memory works and what happens when a page fault occurs during a critical path.",
       ["page table mechanics", "major vs minor faults", "performance implications"]),

    # -- devops and ci/cd ---------------------------------------------------
    _q("devops-1", "devops and ci/cd", 2, "Describe your team's deployment pipeline. What steps ran automatically vs. required a human?",
       ["pipeline stages", "automated vs manual gates", "artifact management"]),
    _q("devops-2", "devops and ci/cd", 3, "A deployment went out and metrics degraded. How do you decide whether to roll back or roll forward?",
       ["severity assessment", "rollback cost vs fix time", "blast radius"]),
    _q("devops-3", "devops and ci/cd", 4, "How would you implement canary deployments for a stateful service with database migrations?",
       ["backward-compatible migrations", "traffic splitting", "rollback of schema changes"]),

    # -- version control and collaboration ---------------------------------------------------
    _q("vc-1", "version control and collaboration", 2, "How does your team use branches? Walk me through a feature from start to merge.",
       ["branching strategy", "review process", "merge vs rebase reasoning"]),
    _q("vc-2", "version control and collaboration", 3, "Two developers made conflicting changes to the same module. How do you resolve it without losing work?",
       ["conflict resolution strategy", "communication", "testing after merge"]),
    _q("vc-3", "version control and collaboration", 4, "Your monorepo has 500 contributors and CI takes 45 minutes. How do you keep velocity up?",
       ["affected-path detection", "caching strategies", "trunk-based development tradeoffs"]),
)

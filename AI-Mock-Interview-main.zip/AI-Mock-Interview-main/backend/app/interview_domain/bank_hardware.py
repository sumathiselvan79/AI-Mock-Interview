"""Hardware engineering domain questions — ~ packages/interview-domain/src/bank-hardware.ts."""

from __future__ import annotations

from app.interview_domain.bank_types import RawBankQuestion


def _q(id: str, topic: str, difficulty: int, text: str, signals: list[str]) -> RawBankQuestion:
    return {"id": id, "topic": topic, "type": "technical", "difficulty": difficulty, "text": text, "expected_signals": signals}


HARDWARE_QUESTIONS: tuple[RawBankQuestion, ...] = (
    # -- digital logic design ---------------------------------------------------
    _q("dld-1", "digital logic design", 2, "Explain the difference between combinational and sequential logic. Give an example of each you've designed.",
       ["stateless vs stateful distinction", "concrete examples", "clock dependency awareness"]),
    _q("dld-2", "digital logic design", 3, "You have a state machine with 16 states and glitchy outputs. How do you diagnose and fix it?",
       ["state encoding choices", "output registration", "simulation-based debugging"]),
    _q("dld-3", "digital logic design", 4, "How would you design a pipelined datapath for a custom accelerator? Where do you insert pipeline stages?",
       ["critical path analysis", "throughput vs latency tradeoff", "hazard handling"]),

    # -- computer architecture ---------------------------------------------------
    _q("arch-1", "computer architecture", 2, "Walk me through what happens inside a CPU when it executes a single instruction.",
       ["fetch-decode-execute cycle", "register file access", "ALU operation"]),
    _q("arch-2", "computer architecture", 3, "Why do modern CPUs have multiple levels of cache? How does data flow between them?",
       ["locality of reference", "inclusion vs exclusion policies", "cache coherence basics"]),
    _q("arch-3", "computer architecture", 4, "How does branch prediction work, and what happens to the pipeline when a prediction is wrong?",
       ["speculative execution", "pipeline flush cost", "prediction strategies (static vs dynamic)"]),

    # -- embedded systems ---------------------------------------------------
    _q("emb-1", "embedded systems", 2, "Describe a firmware project you worked on. What microcontroller did you use, and why that one?",
       ["peripheral requirements", "power/cost constraints", "toolchain familiarity"]),
    _q("emb-2", "embedded systems", 3, "Your embedded device randomly resets in the field. Walk me through your investigation.",
       ["watchdog timer analysis", "power supply integrity", "stack overflow checks"]),
    _q("emb-3", "embedded systems", 4, "How would you design firmware for an OTA-updatable device that must never brick itself?",
       ["dual-bank/A-B partitioning", "rollback on boot failure", "integrity verification"]),

    # -- pcb design and layout ---------------------------------------------------
    _q("pcb-1", "pcb design and layout", 2, "Walk me through your PCB design process from schematic capture to manufacturing files.",
       ["schematic review", "component placement rationale", "DRC before tapeout"]),
    _q("pcb-2", "pcb design and layout", 3, "You have a high-speed differential pair that isn't meeting signal integrity requirements. What do you check?",
       ["impedance control", "length matching", "reference plane continuity"]),
    _q("pcb-3", "pcb design and layout", 4, "How would you design a 12-layer PCB stackup for a mixed-signal board with sensitive analog and noisy digital sections?",
       ["ground plane isolation", "return current paths", "EMI containment strategy"]),

    # -- hardware verification and testing ---------------------------------------------------
    _q("hv-1", "hardware verification and testing", 2, "How do you verify that a Verilog/VHDL module behaves correctly before it goes to silicon?",
       ["testbench methodology", "stimulus generation", "checking against expected output"]),
    _q("hv-2", "hardware verification and testing", 3, "Your functional coverage is at 85% and the remaining holes are hard to hit. What's your strategy?",
       ["constrained random with targeted seeds", "corner case identification", "coverage closure plan"]),
    _q("hv-3", "hardware verification and testing", 4, "When would you use formal verification over simulation, and what are its limitations?",
       ["exhaustive proof vs bounded", "state space explosion", "property specification"]),

    # -- soc design ---------------------------------------------------
    _q("soc-1", "soc design", 2, "What components make up a typical SoC, and how do they communicate?",
       ["CPU/memory/peripherals", "bus interconnect", "address mapping"]),
    _q("soc-2", "soc design", 3, "How do you handle the integration of a third-party IP core into your SoC?",
       ["interface compliance verification", "clock domain handling", "documentation review"]),
    _q("soc-3", "soc design", 4, "Design the memory subsystem for an SoC that must serve a CPU, a GPU, and a DMA engine simultaneously.",
       ["arbitration policy", "QoS requirements", "bandwidth partitioning"]),

    # -- hardware-software interface ---------------------------------------------------
    _q("hsi-1", "hardware-software interface", 2, "How does a device driver communicate with hardware? Walk me through a register read.",
       ["memory-mapped I/O", "register address space", "volatile access"]),
    _q("hsi-2", "hardware-software interface", 3, "You wrote a driver, but the device behaves differently on two OS versions. How do you debug?",
       ["HAL abstraction differences", "kernel API changes", "register-level validation"]),
    _q("hsi-3", "hardware-software interface", 4, "How would you design a DMA engine's programming interface to be both efficient and safe for user-space access?",
       ["IOMMU protection", "descriptor ring design", "interrupt coalescing"]),

    # -- signal integrity and timing ---------------------------------------------------
    _q("si-1", "signal integrity and timing", 2, "What is setup time and hold time? Why do they matter?",
       ["data stability window", "metastability risk", "clock-to-q relationship"]),
    _q("si-2", "signal integrity and timing", 3, "Your design has a timing violation on a path that crosses clock domains. How do you fix it?",
       ["synchronizer insertion", "CDC analysis", "false path vs multi-cycle"]),
    _q("si-3", "signal integrity and timing", 4, "How do you analyze and mitigate jitter in a high-speed serial link?",
       ["deterministic vs random jitter", "eye diagram analysis", "equalization techniques"]),

    # -- low power design ---------------------------------------------------
    _q("lp-1", "low power design", 2, "What are the main sources of power consumption in a digital chip?",
       ["dynamic vs static power", "switching activity", "leakage current"]),
    _q("lp-2", "low power design", 3, "How would you reduce power in a block that toggles frequently but is only used intermittently?",
       ["clock gating", "power gating with isolation", "retention registers"]),
    _q("lp-3", "low power design", 4, "Design a multi-voltage-domain strategy for an IoT SoC that must last years on a coin cell.",
       ["always-on domain sizing", "wake-up latency budget", "level shifter placement"]),

    # -- semiconductor physics ---------------------------------------------------
    _q("semi-1", "semiconductor physics", 2, "Explain how a MOSFET works as a switch. What controls whether it's on or off?",
       ["gate voltage vs threshold", "channel formation", "n-type vs p-type"]),
    _q("semi-2", "semiconductor physics", 3, "Why does shrinking the process node increase leakage current, and what do foundries do about it?",
       ["short-channel effects", "gate oxide tunneling", "high-k metal gate"]),
    _q("semi-3", "semiconductor physics", 4, "How do FinFETs differ from planar transistors, and what design implications does that have?",
       ["3D channel structure", "quantized width", "variability reduction"]),
)

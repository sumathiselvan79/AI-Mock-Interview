"""Conversational continuers — `HUMAN_INTERACTION_FLOW.md` §8.

~ packages/interview-domain (static shared vocabulary, same place
`acknowledgments.py` and `transitions.py` live).

§1 gave the interview a noise to make the instant a candidate stops talking.
This module covers the three places it still says *nothing*:

 - **The wait after that noise.** The ack costs no round trip; everything
   after it costs two — the Follow-up Agent scores the answer, then the
   Question Agent writes the next question. On a slow provider that is tens of
   seconds of silence following a one-word "Okay.", which reads worse than the
   silence §1 removed: the candidate has been acknowledged and then abandoned.
 - **A follow-up answer.** §1's receipt fires in `submit_answer` only. A
   probing session is half follow-ups, and every one of those turns lands in
   silence today.
 - **The opening.** The session's first spoken words are "Tell me about
   yourself." There is no hello.

Same shape as everything else in the stage: a deterministic rule decides
whether a line is said and which one, and there is no model call anywhere in
this file. Three properties carry over from `acknowledgments.py` deliberately:

 - **Nothing evaluative.** Every pool below fires either before the Eval Tool
   has scored the turn (holding, receipt) or before the interview has begun
   (opening). A phrase that read as a verdict would be a claim the system
   cannot support yet — `soul.md §"No fabrication"`, the same reason "Great."
   is absent from the ack pools.
 - **Nothing content-bearing.** A continuer says the interviewer is still
   there. It never characterises the answer, previews the next question, or
   promises anything about the session, so there is no claim in it for the
   grounding check to have an opinion about.
 - **Least-recently-used rotation, shared with §1.** Four continuers in a row
   drawn from the same three phrases is the exact failure §4 exists to stop,
   so the pools rotate through the Memory Agent the same way, under their own
   `kind` namespaces so no pool can exhaust another.
"""

from __future__ import annotations

from typing import Literal, Optional, Sequence

from app.interview_domain.acknowledgments import least_recently_used

#: The kinds of continuer this module knows how to phrase.
#:
#: `holding` and `selection` are the two halves of the post-answer wait and are
#: separate pools rather than one, because the two waits are about different
#: things: one is the interviewer thinking about what was just said, the other
#: is the interviewer choosing where to go next. A single pool would say "let
#: me sit with that" while picking an unrelated topic.
ContinuerKind = Literal["opening", "holding", "selection", "follow_up_receipt"]

#: The Memory Agent `kind` each pool rotates under. Namespaced under a
#: `continuer:` prefix so they sit beside `acknowledgment` and `transition`
#: without any of the five sharing a history — spending the holding pool must
#: not silence an acknowledgment.
PHRASE_KIND: dict[str, str] = {
    "holding": "continuer:holding",
    "selection": "continuer:selection",
    "follow_up_receipt": "continuer:follow_up_receipt",
}

#: The session's first spoken words, before the introduction opener.
#:
#: One fixed line rather than a rotating pool: it is said once per session, so a
#: pool would be vocabulary that only ever reaches index 0 — dead words that
#: read as variety. What it says is constrained by `soul.md §3` more than by
#: tone: it may set expectations, and it may not make a promise the session
#: does not keep. "Take your time" would be exactly that promise, because there
#: is a budget and a visible clock; "it's fine to take a second to think" is
#: true and is the thing a candidate actually needs to hear.
OPENING_LINE = (
    "Thanks for making the time today. I'll take you through a few questions — "
    "you'll see the clock at the top, and it's fine to take a second to think "
    "before you start talking."
)

#: Spoken when the post-answer pipeline outruns `HOLDING_LINE_AFTER_MS`.
#:
#: Every line here is about the interviewer, never about the answer. "Let me
#: sit with that" says someone is still listening; "that's a lot to unpack"
#: would say the answer was complicated, which is a reading of it, and no
#: reading exists yet at this point in `submit_answer`.
HOLDING_LINES: tuple[str, ...] = (
    "Let me sit with that for a second.",
    "Bear with me a moment.",
    "One moment.",
    "Give me a second here.",
)

#: Spoken when question generation outruns `HOLDING_LINE_AFTER_MS`.
#:
#: These may refer to the interview moving on, because by this point it is: the
#: previous turn is scored and closed. They still name no topic — the Question
#: Agent has not returned one yet, and a continuer that guessed would be
#: announcing a question the interview then does not ask.
SELECTION_LINES: tuple[str, ...] = (
    "Let me line up the next one.",
    "One moment while I pick up the next thread.",
    "Just thinking about where to take this.",
)

#: Spoken when a follow-up answer lands, before it is scored.
#:
#: Shorter than the §1 pools on purpose. A follow-up exchange is the fast half
#: of a turn — the candidate has already been acknowledged once for the answer
#: this probe came out of, and a second full-weight "Understood." moments later
#: is what makes a rotation audible as a rotation.
FOLLOW_UP_RECEIPTS: tuple[str, ...] = (
    "Thanks.",
    "Okay.",
    "Noted.",
    "Got that.",
)

_POOLS: dict[str, tuple[str, ...]] = {
    "holding": HOLDING_LINES,
    "selection": SELECTION_LINES,
    "follow_up_receipt": FOLLOW_UP_RECEIPTS,
}

#: How long a wait has to run before it gets a continuer.
#:
#: Not a latency target and not tuned for the common case — it is the point at
#: which a silence stops reading as a person thinking and starts reading as a
#: system that has stopped responding. Below it, a continuer would talk over
#: the reply it is covering for, which is worse than the pause it removes.
#: Above roughly five seconds the candidate has already concluded something is
#: broken. A fast provider therefore never triggers one at all, which is the
#: correct outcome: there is no gap to fill.
HOLDING_LINE_AFTER_MS = 3_500


def continuer_for(kind: ContinuerKind, *, used_phrases: Sequence[str] = ()) -> Optional[str]:
    """The line to speak for `kind`, or `None` when the kind has no pool.

    `used_phrases` is this session's history for *this kind only*, oldest
    first, as the Memory Agent has it. The pick is the first unused entry,
    falling back to the one used longest ago — identical to §1's rotation, and
    identical for the same reason: the same session replayed says the same
    things, which is what makes any of this testable.
    """
    if kind == "opening":
        return OPENING_LINE
    pool = _POOLS.get(kind)
    if not pool:
        return None
    return least_recently_used(pool, used_phrases)


def phrase_kind_for(kind: ContinuerKind) -> Optional[str]:
    """The Memory Agent `kind` this pool rotates under, or `None` for a kind
    that is not rotated (`opening` — one fixed line, said once)."""
    return PHRASE_KIND.get(kind)

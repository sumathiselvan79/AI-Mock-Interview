"""Gateway config — ~ apps/gateway/src/config.ts."""

from __future__ import annotations

import ipaddress
import os
from dataclasses import dataclass, field
from urllib.parse import urlsplit

from app.auth.roles import parse_admin_email_allowlist
from app.paths import from_repo_root


@dataclass(frozen=True)
class GoogleOAuthConfig:
    client_id: str
    client_secret: str
    redirect_uri: str


@dataclass(frozen=True)
class GatewayConfig:
    port: int
    node_env: str
    auth_token_secret: str
    auth_token_ttl_seconds: int
    reset_token_ttl_seconds: int
    storage_driver: str  # "memory" | "postgres"
    database_url: str
    # (Stage 5, §11.4) The Supabase-hosted archive instance — a PHYSICALLY
    # SEPARATE database from `database_url`, reached only server-side with a
    # service-role credential (§8). Empty means archiving is off.
    supabase_db_url: str
    redis_url: str
    upload_dir: str
    max_resume_bytes: int
    # Largest recorded answer accepted, decoded. Sized for a long spoken
    # answer (16-bit 16 kHz mono runs ~1.9 MB/minute), enforced identically on
    # the REST route and the live WebSocket channel.
    max_audio_bytes: int
    speech_model_dir: str
    # --- STT (faster-whisper). TTS still reads `speech_model_dir` above.
    # Whisper size. `tiny.en` is the shipped default: English-only, ~75MB, and
    # fast enough on CPU to stay inside §9's latency budget.
    stt_model: str
    # int8 quantisation on CPU. `float32` is available for a deployment that
    # would rather have the accuracy than the speed.
    stt_compute_type: str
    # A vendored CTranslate2 model directory. Empty means resolve `stt_model`
    # through the HuggingFace cache instead (downloaded once, then offline).
    stt_model_dir: str
    # Hard wall-clock cap on one transcription. Bounds an unbounded failure —
    # fed noise, a Whisper decoder can loop emitting repeated tokens — rather
    # than describing expected latency (`whisper_provider.py`).
    stt_timeout_seconds: float
    # Silero VAD inside the decode, on top of the energy gate that runs before
    # the model. Off only for debugging what the raw decoder heard.
    stt_vad_filter: bool
    mcp_rate_limit: int
    mcp_rate_limit_window_ms: int
    # Hard gate for POST /auth/dev-login: both the env flag AND non-production
    # must hold, computed once here.
    dev_auth_enabled: bool
    whisper_beam_size: int = 5
    vad_min_silence_ms: int = 500
    vad_padding_ms: int = 150
    noise_estimation_ms: int = 500
    noise_margin_db: float = 8.0
    quality_retry_enabled: bool = True
    quality_max_retries: int = 1
    technical_normalization_enabled: bool = True
    transcript_consensus_enabled: bool = True
    echo_detection_enabled: bool = True
    admin_email_allowlist: list[str] = field(default_factory=list)
    google: GoogleOAuthConfig = field(
        default_factory=lambda: GoogleOAuthConfig("", "", "")
    )
    oauth_state_ttl_seconds: int = 600
    # Normalised: lowercase host, no default port, no trailing slash. In
    # production it is required and must be a bare https origin (`_origin`).
    frontend_url: str = "http://localhost:3000"
    # The exact origins CORS may echo with credentials. Production is
    # `[frontend_url]` and nothing else; development/test is an explicit list,
    # never `*` (deploy/aws/notes/cors.md #5). Read by gateway.py's
    # CORSMiddleware.
    cors_origins: list[str] = field(default_factory=lambda: ["http://localhost:3000", "http://127.0.0.1:3000"])
    # The coding round runs candidate JavaScript in a Node child inside the
    # backend container, which holds every secret (audit P0-2). Off by default
    # in production until the separate no-egress sandbox container exists.
    coding_round_enabled: bool = True
    # Per-IP / per-email limits on the /auth routes (`app/http/rate_limit.py`).
    # Always on in production; off by default in test only because the smoke
    # scripts register dozens of accounts from one TestClient address.
    auth_rate_limit_enabled: bool = False
    # Peers whose X-Forwarded-For is believed. Anything else is the client.
    trusted_proxy_cidrs: list[str] = field(default_factory=lambda: list(_LOOPBACK_CIDRS))


NODE_ENVS = ("development", "test", "production")

# Dev and test are allowed these browser origins on top of FRONTEND_URL.
_DEV_ORIGINS = ("http://localhost:3000", "http://127.0.0.1:3000")

_LOOPBACK_CIDRS = ("127.0.0.0/8", "::1/128")
# Production default: the backend publishes no port (docker-compose.prod.yml),
# so the only peers it can see are Caddy and other containers on the compose
# network, which sit in the private ranges. Override with TRUSTED_PROXY_CIDRS.
_PRIVATE_CIDRS = _LOOPBACK_CIDRS + ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "fc00::/7")


def _int(value: str | None, fallback: int) -> int:
    try:
        return int(value) if value is not None and value.strip() != "" else fallback
    except ValueError:
        return fallback


def _float(value: str | None, fallback: float) -> float:
    try:
        return float(value) if value is not None and value.strip() != "" else fallback
    except ValueError:
        return fallback


def _bool(env: dict[str, str], name: str, fallback: bool) -> bool:
    """Strict: a flag that guards something dangerous must not read a typo
    as "off" or "on". Unset or empty means the fallback."""
    raw = env.get(name, "").strip().lower()
    if raw == "":
        return fallback
    if raw in ("true", "1"):
        return True
    if raw in ("false", "0"):
        return False
    raise RuntimeError(f"{name} must be true or false, got {raw!r}")


def _origin(raw: str, *, name: str, require_https: bool) -> str:
    """A browser Origin as the browser sends it: `scheme://host[:port]`,
    lowercase host, default port dropped. Anything with a path, query,
    fragment or credentials is refused, because it can never equal an Origin
    header and would fail every CORS check silently (cors.md #6)."""
    value = raw.strip()
    parts = urlsplit(value)
    allowed = ("https",) if require_https else ("http", "https")
    if parts.scheme not in allowed or not parts.hostname:
        raise RuntimeError(f"{name} must be an {' or '.join(allowed)} origin, got {value!r}")
    if parts.path not in ("", "/") or parts.query or parts.fragment or parts.username or parts.password:
        raise RuntimeError(f"{name} must be a bare origin with no path, query or credentials, got {value!r}")
    try:
        port = parts.port
    except ValueError as err:
        raise RuntimeError(f"{name} has an invalid port: {value!r}") from err
    default_port = 443 if parts.scheme == "https" else 80
    suffix = f":{port}" if port is not None and port != default_port else ""
    host = parts.hostname.lower()
    if ":" in host:  # IPv6 literal
        host = f"[{host}]"
    return f"{parts.scheme}://{host}{suffix}"


def _cidrs(raw: str | None, fallback: tuple[str, ...]) -> list[str]:
    if raw is None:
        return list(fallback)
    out: list[str] = []
    for item in raw.split(","):
        item = item.strip()
        if not item:
            continue
        try:
            out.append(str(ipaddress.ip_network(item, strict=False)))
        except ValueError as err:
            raise RuntimeError(f"TRUSTED_PROXY_CIDRS has an invalid network: {item!r}") from err
    return out


def _storage_driver(env: dict[str, str], production: bool) -> str:
    raw = env.get("STORAGE_DRIVER", "").strip()
    if production and raw != "postgres":
        # The memory driver in production boots fine and loses every account
        # and report on the next restart (audit P1 #10).
        raise RuntimeError(f"STORAGE_DRIVER must be 'postgres' in production, got {raw or 'unset'!r}")
    if raw not in ("", "memory", "postgres"):
        raise RuntimeError(f"STORAGE_DRIVER must be 'memory' or 'postgres', got {raw!r}")
    return raw or "memory"


def load_config(env: dict[str, str] | None = None) -> GatewayConfig:
    """Builds the config, and raises on any production misconfiguration so the
    process fails at boot rather than serving with a gate quietly open. Every
    production-only gate in the app keys on `node_env == "production"`, so a
    misspelled NODE_ENV used to fall back to development: dev-login, the
    internal MCP route, permissive CORS and the insecure default secret
    (audit P1 #10, cors.md #5). An absent NODE_ENV is still development, the
    local default; the production image is expected to set it."""
    env = env if env is not None else os.environ  # type: ignore[assignment]
    node_env = env.get("NODE_ENV", "development")
    if node_env not in NODE_ENVS:
        raise RuntimeError(f"NODE_ENV must be one of {', '.join(NODE_ENVS)}, got {node_env!r}")
    production = node_env == "production"
    secret = env.get("AUTH_TOKEN_SECRET", "")

    if production and len(secret) < 32:
        raise RuntimeError("AUTH_TOKEN_SECRET must be set to at least 32 characters in production")

    storage_driver = _storage_driver(env, production)

    if production:
        for name in ("DATABASE_URL", "REDIS_URL"):
            if not env.get(name, "").strip():
                raise RuntimeError(f"{name} must be set in production")
        # dev_auth_enabled already ignores the flag in production; refusing to
        # boot makes the mistake visible instead of relying on that second
        # gate. "false" (the .env.example value) is accepted.
        if _bool(env, "ALLOW_DEV_AUTH", False):
            raise RuntimeError("ALLOW_DEV_AUTH must not be enabled in production")
        if not env.get("FRONTEND_URL", "").strip():
            raise RuntimeError("FRONTEND_URL must be set in production")
        frontend_url = _origin(env["FRONTEND_URL"], name="FRONTEND_URL", require_https=True)
        cors_origins = [frontend_url]
    else:
        frontend_url = _origin(env.get("FRONTEND_URL") or "http://localhost:3000", name="FRONTEND_URL", require_https=False)
        extra = [
            _origin(item, name="CORS_DEV_ORIGINS", require_https=False)
            for item in env.get("CORS_DEV_ORIGINS", "").split(",")
            # `*` is not an origin. Dropped rather than raised on, so an old
            # .env that tried it still boots, just without the wildcard.
            if item.strip() and item.strip() != "*"
        ]
        cors_origins = list(dict.fromkeys([frontend_url, *_DEV_ORIGINS, *extra]))

    return GatewayConfig(
        port=_int(env.get("PORT"), 4000),
        node_env=node_env,
        auth_token_secret=secret or "dev-only-insecure-secret",
        auth_token_ttl_seconds=_int(env.get("AUTH_TOKEN_TTL_SECONDS"), 3600),
        reset_token_ttl_seconds=_int(env.get("RESET_TOKEN_TTL_SECONDS"), 900),
        storage_driver=storage_driver,
        database_url=env.get("DATABASE_URL", "postgres://mia:mia@localhost:5432/mia"),
        supabase_db_url=env.get("SUPABASE_DB_URL", ""),
        redis_url=env.get("REDIS_URL", "redis://localhost:6379"),
        upload_dir=from_repo_root(env.get("UPLOAD_DIR", "uploads")),
        max_resume_bytes=_int(env.get("MAX_RESUME_BYTES"), 5 * 1024 * 1024),
        max_audio_bytes=_int(env.get("MAX_AUDIO_BYTES"), 20 * 1024 * 1024),
        speech_model_dir=from_repo_root(env.get("SPEECH_MODEL_DIR", "models")),
        stt_model=env.get("STT_MODEL", "tiny.en"),
        stt_compute_type=env.get("STT_COMPUTE_TYPE", "int8"),
        stt_model_dir=from_repo_root(env["STT_MODEL_DIR"]) if env.get("STT_MODEL_DIR") else "",
        stt_timeout_seconds=_float(env.get("STT_TIMEOUT_SECONDS"), 15.0),
        stt_vad_filter=env.get("STT_VAD_FILTER", "true").strip().lower() != "false",
        whisper_beam_size=_int(env.get("WHISPER_BEAM_SIZE"), 5),
        vad_min_silence_ms=_int(env.get("VAD_MIN_SILENCE_MS"), 500),
        vad_padding_ms=_int(env.get("VAD_PADDING_MS"), 150),
        noise_estimation_ms=_int(env.get("NOISE_ESTIMATION_MS"), 500),
        noise_margin_db=_float(env.get("NOISE_MARGIN_DB"), 8.0),
        quality_retry_enabled=env.get("QUALITY_RETRY_ENABLED", "true").strip().lower() != "false",
        quality_max_retries=_int(env.get("QUALITY_MAX_RETRIES"), 1),
        technical_normalization_enabled=env.get("TECHNICAL_NORMALIZATION_ENABLED", "true").strip().lower() != "false",
        transcript_consensus_enabled=env.get("TRANSCRIPT_CONSENSUS_ENABLED", "true").strip().lower() != "false",
        echo_detection_enabled=env.get("ECHO_DETECTION_ENABLED", "true").strip().lower() != "false",
        mcp_rate_limit=_int(env.get("MCP_RATE_LIMIT"), 300),
        mcp_rate_limit_window_ms=_int(env.get("MCP_RATE_LIMIT_WINDOW_MS"), 10_000),
        dev_auth_enabled=node_env != "production" and env.get("ALLOW_DEV_AUTH") == "true",
        admin_email_allowlist=parse_admin_email_allowlist(env.get("ADMIN_EMAIL_ALLOWLIST")),
        google=GoogleOAuthConfig(
            client_id=env.get("GOOGLE_CLIENT_ID", ""),
            client_secret=env.get("GOOGLE_CLIENT_SECRET", ""),
            redirect_uri=env.get("GOOGLE_REDIRECT_URI", ""),
        ),
        oauth_state_ttl_seconds=_int(env.get("OAUTH_STATE_TTL_SECONDS"), 600),
        frontend_url=frontend_url,
        cors_origins=cors_origins,
        coding_round_enabled=_bool(env, "CODING_ROUND_ENABLED", not production),
        # Not switchable in production: an env var cannot open this gate.
        auth_rate_limit_enabled=True if production else _bool(env, "AUTH_RATE_LIMIT_ENABLED", node_env != "test"),
        trusted_proxy_cidrs=_cidrs(env.get("TRUSTED_PROXY_CIDRS"), _PRIVATE_CIDRS if production else _LOOPBACK_CIDRS),
    )

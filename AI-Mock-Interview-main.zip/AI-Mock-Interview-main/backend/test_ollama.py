import asyncio
from app.llm_client.provider import resolve_provider
from app.llm_client.structured_call import structured_call, StructuredCallOptions
from app.llm_client.tools import JD_FIT_TOOL
from app.llm_client.types import ToolDefinition

async def test():
    import os
    os.environ["OLLAMA_BASE_URL"] = "http://localhost:11434/v1"
    os.environ["OLLAMA_MODEL"] = "gpt-oss:120b-cloud"
    os.environ["OLLAMA_API_KEY"] = "ollama"
    
    provider_choice = resolve_provider({"LLM_PROVIDER": "ollama"})
    print("Provider choice:", provider_choice)
    
    tool = ToolDefinition(
        name=JD_FIT_TOOL["name"],
        description="jd fit",
        schema=__import__("app.llm_client.schemas", fromlist=["JdFitGeneration"]).JdFitGeneration,
        prompt_version=JD_FIT_TOOL["prompt_version"],
        schema_ref=JD_FIT_TOOL["schema_ref"],
        required_grounded_paths=(),
    )
    result = await structured_call(
        tool,
        {
            "role": "backend engineer",
            "job_description": "Need Python and FastAPI skills.",
            "resume_lines": ["I have 5 years of Python and FastAPI."],
            "matched_requirements": ["Python", "FastAPI"],
            "gaps": [],
            "candidate_topics": ["Python"],
        },
        StructuredCallOptions(provider="ollama", source_documents=["Python", "FastAPI"]),
    )
    print("Result:", result)

asyncio.run(test())

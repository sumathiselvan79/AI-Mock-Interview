import asyncio
import os
import sys

from dotenv import load_dotenv
load_dotenv()

from app.gateway import create_app
from app.llm_client.structured_call import StructuredCallOptions, structured_call
from app.llm_client.tools import QUESTION_TOOL
from app.llm_client.types import ToolDefinition
from app.llm_client.provider import resolve_provider

app = create_app()

async def test_provider(provider_name: str):
    print(f"\n--- Testing provider: {provider_name} ---")
    
    # 1. Test Provider Resolution
    test_env = {**os.environ, "LLM_PROVIDER": provider_name}
    choice = resolve_provider(test_env)
    print(f"Resolution Choice: {choice.provider} (Reason: {choice.reason})")
    
    if choice.provider != provider_name:
        print(f"FAILED: {provider_name} is not fully configured (degraded to {choice.provider}).")
        return

    # 2. Test Structured Call (Real LLM invocation)
    tool = ToolDefinition(
        name=QUESTION_TOOL["name"],
        description="question generation",
        schema=__import__("app.llm_client.schemas", fromlist=["QuestionGeneration"]).QuestionGeneration,
        prompt_version=QUESTION_TOOL["prompt_version"],
        schema_ref=QUESTION_TOOL["schema_ref"],
        required_grounded_paths=QUESTION_TOOL["required_grounded_paths"],
    )
    
    print(f"Calling LLM over {provider_name}...")
    try:
        result = await structured_call(
            tool,
            {
                "role": "backend engineer",
                "topic_plan": [{"topic": "databases", "max_questions": 1, "source": "role_requirement"}],
                "candidate_profile_lines": ["Operated a large PostgreSQL fleet."],
                "baseline": {
                    "text": "Tell me about a time you worked with databases.",
                    "topic": "databases",
                    "type": "behavioral",
                    "difficulty": 2,
                    "expected_signals": ["a concrete database incident", "what they personally did"],
                },
            },
            StructuredCallOptions(provider=provider_name, source_documents=["databases (role_requirement)", "Operated a large PostgreSQL fleet."], env=test_env),
        )
        print(f"SUCCESS: {provider_name} works! Grounded: {result.grounded}")
        print(f"Output Question: {result.output.get('question', {}).get('text')}")
    except Exception as e:
        print(f"FAILED: {provider_name} structured_call failed: {e}")

async def main():
    providers = ["fixture", "ollama", "groq", "openrouter", "bedrock"]
    for p in providers:
        await test_provider(p)

if __name__ == "__main__":
    asyncio.run(main())

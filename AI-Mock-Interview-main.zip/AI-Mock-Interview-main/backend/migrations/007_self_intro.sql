-- Self-intro addition on top of Stage 6 (INSTRUCTIONS.md §4.3): a fixed
-- "Tell me about yourself" opener that seeds the topic plan.
--
-- Additive only. `topic_plan_entries.source` gains a fourth allowed value —
-- 'introduction' — for the fixed opener `build_topic_plan` now always
-- prepends ahead of the resume/role/jd_gap-derived, quota-capped set. No
-- column changes: the opener is just another row in this table, quota
-- always exactly 1.

ALTER TABLE topic_plan_entries
  DROP CONSTRAINT IF EXISTS topic_plan_entries_source_check,
  ADD CONSTRAINT topic_plan_entries_source_check
    CHECK (source IN ('resume', 'role_requirement', 'jd_gap', 'introduction'));

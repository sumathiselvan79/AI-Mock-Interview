-- Grading addition: a letter band alongside every rubric score
-- (`backend/app/tools/eval/grading.py`, CLAUDE.md §8).
--
-- Additive and nullable, for the reason the band scale itself has no "F":
-- a report written before this migration was not graded, and NULL has to read
-- back as "not graded" rather than as the bottom band. A candidate who was
-- never assessed has not failed (soul.md §"No fabrication") — the same rule
-- `formatScore` enforces on the frontend by rendering `—` instead of `0`.
--
-- Per-competency grades need no column: `competency_scores` is already JSONB,
-- so each entry simply gains a `grade` key. Only the session-level band is new
-- storage.
--
-- { letter, label, score, descriptor, isStrength, scaleVersion }
ALTER TABLE reports
  ADD COLUMN IF NOT EXISTS overall_grade JSONB;

"""Manual smoke test for the dynamic, JD/role-aware evaluation criteria and
scoring addition (see the plan: "Dynamic, JD/role-aware evaluation criteria
and scoring").

Three checks, matching the plan's Tests section:

 1. `technical_v1` vs `technical_v2` on the same hardware-domain transcript —
    the regression test for the actual bug: a non-software answer could
    never trigger the "specifics" signal under the old, software-only
    vocabulary.
 2. `weighted_aggregate` / `grade_scores` with `weights` supplied vs.
    omitted — proves the weighted number differs correctly, and that
    omitting `weights` reproduces the old, unweighted result exactly
    (backward compatibility for Part B).
 3. A non-software-role session driven end to end to `generate_report`,
    asserting both `overall_grade` and `role_fit_grade` come back present.
"""

from __future__ import annotations

import os

os.environ["NODE_ENV"] = "test"
os.environ["AUTH_TOKEN_SECRET"] = "x" * 32


def expect(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)
    print(f"OK: {msg}")


# ============================================================ 1. technical_v2

from app.tools.eval.rubrics import get_rubric  # noqa: E402
from app.tools.eval.server import score_against_rubric  # noqa: E402

# Real mechanics-of-materials vocabulary (`interview_domain/topics.py`), and
# deliberately NO numbers/metrics and NO software terms, so the only way the
# "specifics" signal can fire is by recognizing the domain vocabulary itself
# — proving the fix rather than accidentally passing on a METRIC match.
HARDWARE_TRANSCRIPT = (
    "I led the redesign of a bracket that had failed in fatigue in the field, because a stress "
    "concentration at the fillet exceeded the material's yield strength under repeated loading. "
    "We considered switching to a stronger alloy but rejected that because of the added cost, so "
    "instead I recalculated the beam bending stress and increased the fillet radius, which resolved "
    "the failure in subsequent testing."
)

v1_result = score_against_rubric(get_rubric("technical_v1"), HARDWARE_TRANSCRIPT)
v2_result = score_against_rubric(get_rubric("technical_v2"), HARDWARE_TRANSCRIPT, topic="mechanics of materials")

expect(
    any("concrete systems" in m for m in v1_result.missing_signals),
    f"technical_v1's software-only vocabulary cannot see hardware detail: 'specifics' is missing, got matched={v1_result.matched_signals}",
)
expect(
    any("concrete systems" in m for m in v2_result.matched_signals),
    f"technical_v2 recognizes this question's own topic vocabulary: 'specifics' is matched, got matched={v2_result.matched_signals}",
)
expect(
    v2_result.score > v1_result.score,
    f"the same transcript scores higher under the topic-aware rubric, got v1={v1_result.score} v2={v2_result.score}",
)

# An unrecognized topic falls back to the static vocabulary rather than
# scoring against an empty pattern set.
v2_unknown_topic = score_against_rubric(get_rubric("technical_v2"), HARDWARE_TRANSCRIPT, topic="not a real topic")
expect(
    any("concrete systems" in m for m in v2_unknown_topic.missing_signals),
    "an unrecognized topic falls back to the static vocabulary, not a silently-empty one",
)

print()

# ==================================================== 2. weighted_aggregate

from app.tools.eval.grading import aggregate, weighted_aggregate  # noqa: E402
from app.tools.eval.server import _grade_scores  # noqa: E402

wa = weighted_aggregate([(5.0, 1.5), (2.0, 1.0)])
plain = aggregate([5.0, 2.0])
expect(wa is not None and plain is not None, "weighted_aggregate and aggregate both grade a non-empty input")
expect(
    wa["score"] > plain["score"],
    f"weighting the higher score higher moves the weighted mean up, got weighted={wa['score']} vs plain={plain['score']}",
)
expect(weighted_aggregate([]) is None, "weighted_aggregate of nothing is None, never a fabricated bottom band")
expect(weighted_aggregate([(3.0, 0.0)]) is None, "an all-zero-weight input is None rather than a divide-by-zero or a bottom band")
expect(
    weighted_aggregate([(5.0, 1.0), (2.0, 1.0)])["score"] == plain["score"],
    "equal weights reproduce the plain mean exactly",
)

subjects = [{"id": "topic-a", "score": 5.0}, {"id": "topic-b", "score": 2.0}]

without_weights = _grade_scores({"subjects": subjects})
expect(
    "role_fit_grade" not in without_weights,
    "omitting weights reproduces the old grade_scores response exactly — no role_fit_grade key at all",
)

with_weights = _grade_scores({"subjects": subjects, "weights": {"topic-a": 1.5, "topic-b": 1.0}})
expect("role_fit_grade" in with_weights, "supplying weights adds role_fit_grade")
expect(
    with_weights["overall_grade"] == without_weights["overall_grade"],
    "overall_grade is unaffected by weights — it is a separate axis from role_fit_grade",
)
expect(
    with_weights["role_fit_grade"]["score"] == wa["score"],
    f"grade_scores' role_fit_grade matches a direct weighted_aggregate call, got {with_weights['role_fit_grade']['score']} vs {wa['score']}",
)

equal_weights = _grade_scores({"subjects": subjects, "weights": {"topic-a": 1.0, "topic-b": 1.0}})
expect(
    equal_weights["role_fit_grade"]["score"] == without_weights["overall_grade"]["score"],
    "equal weights reproduce the unweighted overall_grade exactly",
)

# A subject absent from `weights` defaults to weight 1.0 rather than being
# dropped or raising.
partial_weights = _grade_scores({"subjects": subjects, "weights": {"topic-a": 1.5}})
expect(
    partial_weights["role_fit_grade"]["score"] == with_weights["role_fit_grade"]["score"],
    "a subject missing from the weights map defaults to weight 1.0",
)

print()

# ==================================================== 3. non-software-role e2e

from fastapi.testclient import TestClient  # noqa: E402

from app.gateway import create_app  # noqa: E402

app = create_app()
client = TestClient(app)

r = client.post("/auth/register", json={"email": "mech-role-student@example.com", "passcode": "hunter22"})
token = r.json()["token"]
headers = {"Authorization": f"Bearer {token}"}

r = client.post(
    "/sessions",
    json={
        "role": "mechanical engineer",
        "job_description": "Looking for a mechanical engineer with deep experience in mechanics of materials, fatigue analysis, and machine design for rotating equipment.",
        "question_budget": 3,
    },
    headers=headers,
)
expect(r.status_code == 201, f"session created for a non-software role ({r.text})")
session_id = r.json()["session_id"]

for state in ("CONFIG", "TELEMETRY_CHECK"):
    r = client.post(f"/sessions/{session_id}/advance", json={"to": state}, headers=headers)
    expect(r.status_code == 200, f"advance to {state}")

r = client.post(f"/sessions/{session_id}/telemetry-check", json={"mic_ok": True, "speaker_ok": True}, headers=headers)
expect(r.status_code == 200, "telemetry check passed")

r = client.post(f"/sessions/{session_id}/begin", headers=headers)
expect(r.status_code == 200, f"begin interview succeeds ({r.text})")
expect(r.json()["state"] == "QUESTION_LOOP", "session enters QUESTION_LOOP")

MECH_ANSWER = (
    "I led the redesign of a bracket that had failed in fatigue in the field, because a stress "
    "concentration at the fillet exceeded the material's yield strength under repeated loading. "
    "We considered switching to a stronger alloy but rejected that because of the added cost, so "
    "instead I recalculated the beam bending stress and increased the fillet radius. As a result, "
    "the part passed accelerated life testing at several times its previous life, and the redesign "
    "shipped in the next production revision."
)

for turn in range(1, 7):  # safety cap; budget is 3 content questions + 1 fixed intro turn
    r = client.get(f"/sessions/{session_id}/questions/next", headers=headers)
    expect(r.status_code == 200, f"turn {turn}: get next question ({r.text})")
    qbody = r.json()
    if qbody["done"]:
        break
    question = qbody["question"]
    r = client.post(
        f"/sessions/{session_id}/answers",
        json={"question_id": question["id"], "transcript": MECH_ANSWER},
        headers=headers,
    )
    expect(r.status_code == 201, f"turn {turn}: answer submitted ({r.text})")

session_after = client.get(f"/sessions/{session_id}", headers=headers).json()["session"]
expect(session_after["state"] == "WRAP_UP", f"session auto-advances to WRAP_UP once budget is spent, got {session_after['state']}")

r = client.post(f"/sessions/{session_id}/wrap-up", headers=headers)
expect(r.status_code == 200, f"wrap-up succeeds ({r.text})")

r = client.post(f"/sessions/{session_id}/report", headers=headers)
expect(r.status_code == 201, f"report generated ({r.text})")
report = r.json()["report"]

expect(report.get("overallGrade") is not None, f"a non-software-role report still gets an overall_grade, got {report.get('overallGrade')}")
expect(
    report.get("roleFitGrade") is not None,
    f"the JD/role-aware weighted grade is present alongside overall_grade, got {report.get('roleFitGrade')}",
)
expect(
    0 <= report["roleFitGrade"]["score"] <= 5,
    f"role_fit_grade's score is in range 0-5, got {report['roleFitGrade']['score']}",
)

print("\nALL DYNAMIC EVALUATION SMOKE CHECKS PASSED")

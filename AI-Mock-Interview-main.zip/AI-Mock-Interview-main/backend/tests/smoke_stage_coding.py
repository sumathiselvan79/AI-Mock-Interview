"""Manual smoke test for F8 — Coding Agent (real Node sandbox execution),
Clipboard Monitor, Focus Monitor."""

from __future__ import annotations

import os

os.environ["NODE_ENV"] = "test"
os.environ["AUTH_TOKEN_SECRET"] = "x" * 32

from fastapi.testclient import TestClient  # noqa: E402

from app.gateway import CreateAppOptions, create_app  # noqa: E402
from app.tools.speech_service.fixture_provider import FixtureSpeechProvider  # noqa: E402
from app.tools.speech_service.server import ProviderChoice  # noqa: E402

app = create_app(CreateAppOptions(speech_provider_choice=ProviderChoice(FixtureSpeechProvider(), "pinned for test")))
client = TestClient(app)


def expect(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)
    print(f"OK: {msg}")


r = client.post("/auth/register", json={"email": "coder@example.com", "passcode": "hunter22"})
headers = {"Authorization": f"Bearer {r.json()['token']}"}

r = client.post("/sessions", json={"role": "backend engineer", "question_budget": 1}, headers=headers)
session_id = r.json()["session_id"]

for state in ("CONFIG", "TELEMETRY_CHECK"):
    client.post(f"/sessions/{session_id}/advance", json={"to": state}, headers=headers)
# no clipboard consent granted
client.post(f"/sessions/{session_id}/telemetry-check", json={"mic_ok": True, "speaker_ok": True, "consent": {"clipboard_monitor": False}}, headers=headers)
client.post(f"/sessions/{session_id}/begin", headers=headers)

# advance the question loop straight to CODING_ROUND (budget is 1: after one question the loop ends and auto-WRAP_UPs;
# instead we manually transition from QUESTION_LOOP -> CODING_ROUND via the coding-round route, which the harness allows from QUESTION_LOOP)
r = client.post(f"/sessions/{session_id}/coding-round", headers=headers)
expect(r.status_code == 201, f"coding round starts ({r.status_code}: {r.text})")
body = r.json()
problem = body["problem"]
expect(problem["entry_point"] and problem["statement"], f"a real problem was selected: {problem['title']}")
expect(body["clipboard_monitoring"] is False, "clipboard monitoring did not start without consent")

session_after = client.get(f"/sessions/{session_id}", headers=headers).json()["session"]
expect(session_after["state"] == "CODING_ROUND", f"session is in CODING_ROUND, got {session_after['state']}")

# a correct solution for whichever problem was picked
SOLUTIONS = {
    "rate-limiter": """
function allow(events, limit, windowMs) {
  const out = [];
  let windowStart = null;
  let count = 0;
  for (const t of events) {
    if (windowStart === null || t - windowStart >= windowMs) {
      windowStart = t;
      count = 0;
    }
    count += 1;
    out.push(count <= limit);
  }
  return out;
}
""",
    "merge-intervals": """
function merge(intervals) {
  const sorted = [...intervals].sort((a, b) => a[0] - b[0]);
  const out = [];
  for (const [s, e] of sorted) {
    const last = out[out.length - 1];
    if (last && s <= last[1]) last[1] = Math.max(last[1], e);
    else out.push([s, e]);
  }
  return out;
}
""",
    "retry-backoff": """
function schedule(attempts, baseMs, capMs) {
  const out = [];
  for (let n = 0; n < attempts; n++) out.push(Math.min(baseMs * (2 ** n), capMs));
  return out;
}
""",
    "dedupe-events": """
function dedupe(events) {
  const seen = new Set();
  const out = [];
  for (const e of events) {
    if (seen.has(e.key)) continue;
    seen.add(e.key);
    out.push(e.value);
  }
  return out;
}
""",
}

problem_id = problem["id"]
solution = SOLUTIONS[problem_id]

r = client.post(
    f"/sessions/{session_id}/coding-round/submissions",
    json={"code": solution, "talk_through": "I iterate through the input once, tracking the running state needed, and handle the edge cases like empty input directly."},
    headers=headers,
)
expect(r.status_code == 201, f"submission runs in the real sandbox ({r.status_code}: {r.text})")
result = r.json()
expect(result["total"] > 0, f"test cases ran: {result}")
expect(result["passed"] == result["total"], f"correct solution passes all cases: {result['passed']}/{result['total']} — {result}")
expect(result["evaluation"] is not None, f"talk-through gets scored: {result.get('evaluation_note')}")

# a wrong solution must fail cases, not silently pass
r = client.post(f"/sessions/{session_id}/coding-round/submissions", json={"code": "function " + problem["entry_point"] + "() { return null; }", "talk_through": "not sure"}, headers=headers)
wrong_result = r.json()
expect(wrong_result["passed"] < wrong_result["total"], f"a wrong solution does not pass every case: {wrong_result}")

# a non-JS language is rejected outright
r = client.post(f"/sessions/{session_id}/coding-round/submissions", json={"code": "print('hi')", "language": "python"}, headers=headers)
expect(r.status_code == 422, f"non-javascript submission is rejected ({r.status_code}: {r.text})")

# candidate code cannot read the filesystem or reach the network — sandbox escape attempts must fail
ESCAPE_ATTEMPTS = {
    "filesystem": f"function {problem['entry_point']}() {{ require('fs').readFileSync('/etc/passwd'); return null; }}",
    "network": f"function {problem['entry_point']}() {{ fetch('http://example.com'); return null; }}",
    "process_spawn": f"function {problem['entry_point']}() {{ require('child_process').execSync('echo pwned'); return null; }}",
    "infinite_loop": f"function {problem['entry_point']}() {{ while(true) {{}} return null; }}",
}
for name, code in ESCAPE_ATTEMPTS.items():
    r = client.post(f"/sessions/{session_id}/coding-round/submissions", json={"code": code}, headers=headers)
    escape_result = r.json()
    expect(r.status_code == 201 and escape_result["passed"] == 0, f"sandbox escape attempt ({name}) is blocked, not executed successfully: {escape_result}")

print("\nALL F8 SMOKE CHECKS PASSED")

"""Stage-gate test for HUMAN_INTERACTION_FLOW.md — the seven methods that make
the interview read as a conversation rather than a form being filled in.

Every one of them follows the same shape, and it is the shape being pinned
here as much as the behaviour: **detector -> directive -> narrow phrasing**. A
deterministic rule decides whether something happens; an LLM, at most, decides
how it is worded. So every assertion below runs without a provider, because
every decision below is made without one.

Numbered by the design note's own sections.
"""

from __future__ import annotations

import asyncio
import os
from dataclasses import dataclass
from typing import Any, Optional

os.environ["NODE_ENV"] = "test"
os.environ["AUTH_TOKEN_SECRET"] = "x" * 32


def expect(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)
    print(f"OK: {msg}")


# =====================================================================  §1  ==
# Thinking gap / acknowledgment beat.

from app.interview_domain.acknowledgments import (  # noqa: E402
    BRIEF_ACKS,
    SUBSTANTIVE_ACKS,
    acknowledgment_for,
)

SUBSTANTIVE = (
    "I led the migration of our billing service off the monolith because it could not scale past "
    "500 requests per second, and after we shipped it deploys went from weekly to daily."
)

ack = acknowledgment_for(transcript=SUBSTANTIVE, transcript_confidence=0.9, used_phrases=[])
expect(ack in SUBSTANTIVE_ACKS, f"a substantive answer gets a substantive acknowledgment, got {ack!r}")

thin = acknowledgment_for(transcript="Yeah, we used Postgres.", transcript_confidence=0.9, used_phrases=[])
expect(thin in BRIEF_ACKS, f"a thin answer gets the brief pool instead, got {thin!r}")
expect(
    thin not in SUBSTANTIVE_ACKS or thin in BRIEF_ACKS,
    "the two pools are distinguishable — a three-word answer is not acknowledged like a two-minute one",
)

expect(
    acknowledgment_for(transcript=SUBSTANTIVE, transcript_confidence=0.4, used_phrases=[]) is None,
    "a low-confidence transcript is not acknowledged at all — saying 'got it' to words nobody confirmed is worse than silence",
)
expect(
    acknowledgment_for(transcript="   ", transcript_confidence=0.9, used_phrases=[]) is None,
    "an empty transcript is not acknowledged",
)

# Rotation: a long session must not say the same thing every turn.
seen: list[str] = []
for _ in range(len(SUBSTANTIVE_ACKS)):
    line = acknowledgment_for(transcript=SUBSTANTIVE, transcript_confidence=0.9, used_phrases=seen)
    assert line
    seen.append(line)
expect(len(set(seen)) == len(SUBSTANTIVE_ACKS), f"the whole pool is used before any phrase repeats, got {seen}")

wrapped = acknowledgment_for(transcript=SUBSTANTIVE, transcript_confidence=0.9, used_phrases=seen)
expect(wrapped == seen[0], f"once the pool is spent it reuses the one used longest ago, got {wrapped!r} (oldest was {seen[0]!r})")

# Nothing in either pool may read as a verdict: this fires before the Eval Tool
# has scored anything (soul.md §"No fabrication").
VERDICT_WORDS = ("great", "good", "excellent", "nice", "perfect", "well done", "interesting", "wrong", "poor")
for phrase in (*SUBSTANTIVE_ACKS, *BRIEF_ACKS):
    lowered = phrase.lower()
    expect(
        not any(word in lowered for word in VERDICT_WORDS),
        f"acknowledgment {phrase!r} carries no verdict about an answer nothing has scored yet",
    )


# =====================================================================  §2  ==
# Struggle detection.

from app.agents.followup.server import (  # noqa: E402
    STRUGGLE_SCORE_FLOOR,
    _compute_next_action,
    consider_follow_up,
    detect_struggle,
)
from app.agents.question.server import (  # noqa: E402
    SelectQuestionInput,
    _STAY_DIRECTIVES,
    select_next_question,
)
from app.interview_domain.transitions import transition_style_for  # noqa: E402
from app.shared_types import TopicPlanEntry  # noqa: E402

expect(
    detect_struggle(answer_transcript="Honestly, I'm not sure.") is not None,
    "an explicit 'I'm not sure' is a struggle signal",
)
expect(
    detect_struggle(answer_transcript="I don't know, I've never used Kafka.") is not None,
    "'I don't know' is a struggle signal",
)
expect(
    detect_struggle(
        answer_transcript="I wasn't sure whether to shard by tenant or by time, so I measured both and shipped the one with the flatter p99."
    )
    is None,
    "reasoning out loud about an uncertainty is NOT struggling — the phrase has to be the whole clause",
)
expect(
    detect_struggle(answer_transcript="We used Postgres.", consecutive_short_answers=2) is not None,
    "a second consecutive near-empty answer is a struggle signal",
)
expect(
    detect_struggle(answer_transcript="We used Postgres.", consecutive_short_answers=1) is None,
    "one short answer is a normal turn, not a signal",
)
expect(
    detect_struggle(answer_transcript="I think it was maybe around the caching layer, sort of.", hedge_streak=1) is not None,
    "hedging that continues from the previous turn is a struggle signal",
)
expect(
    detect_struggle(answer_transcript=SUBSTANTIVE, hedge_streak=3) is None,
    "a streak alone is not enough — this turn has to hedge too, or the candidate has recovered",
)
expect(
    detect_struggle(answer_transcript=SUBSTANTIVE, topic_recent_scores=[2.0, 1.0]) is not None,
    f"a topic average at or below {STRUGGLE_SCORE_FLOOR} is a struggle signal",
)
expect(
    detect_struggle(answer_transcript=SUBSTANTIVE, topic_recent_scores=[4.0, 5.0]) is None,
    "a healthy topic is not a struggle",
)

signal = detect_struggle(answer_transcript="I have no idea.")
assert signal
action = _compute_next_action(
    should_follow_up=False, follow_up_text=signal.reframe, reason=signal.reason, verification=None, tier=1, struggle=signal
)
expect(action["system_directive"] == "support", f"a struggle produces the `support` directive, got {action['system_directive']}")
expect(action["transition_style"] == "supportive_reframe", f"`support` maps to the supportive_reframe style, got {action['transition_style']}")
expect(transition_style_for("support") == "supportive_reframe", "the style mapping is the shared one, not a second copy")

# A struggle outranks a gap. Probing a stuck candidate harder is the behaviour
# soul.md §3 rules out, so the directive must not come back `drill_down`.
both = _compute_next_action(
    should_follow_up=True, follow_up_text="probe text", reason="a gap", verification=None, tier=1, struggle=signal
)
expect(both["system_directive"] == "support", f"a struggle outranks a detected gap, got {both['system_directive']}")

# The reframe must not lower the bar or manufacture praise.
for phrase in (signal.reframe, action["synthesized_framing_strategy"]):
    lowered = phrase.lower()
    expect(
        not any(word in lowered for word in ("well done", "good job", "that's fine, you", "don't worry about")),
        f"the supportive text offers a way in without praising work that was not described: {phrase[:60]!r}…",
    )

# `support` reorders selection but cannot overrun a cap or raise a tier.
expect("support" in _STAY_DIRECTIVES, "`support` keeps the next question on the struggling topic")

capped = SelectQuestionInput(
    session_id="s",
    topic_plan=[TopicPlanEntry(topic="databases", max_questions=1, source="resume"), TopicPlanEntry(topic="apis and services", max_questions=2, source="resume")],
    topic_counts={"databases": 1},
    asked_question_ids=[],
    difficulty_target=3,
    topic_tier={"databases": 2},
    topic_scores={"databases": [1.0, 1.0]},
    directive="support",
    directive_topic="databases",
)
picked = select_next_question(capped)
expect(
    picked.question.topic != "databases",
    f"a `support` directive cannot buy a topic a question past its cap, got {picked.question.topic}",
)

under_cap = SelectQuestionInput(
    session_id="s",
    topic_plan=[TopicPlanEntry(topic="databases", max_questions=3, source="resume")],
    topic_counts={"databases": 1},
    asked_question_ids=[],
    difficulty_target=3,
    topic_tier={"databases": 3},
    topic_scores={"databases": [1.0, 2.0]},
    directive="support",
    directive_topic="databases",
)
supported = select_next_question(under_cap)
expect(supported.question.topic == "databases", "under the cap, `support` does keep the next question on the topic")
expect(
    (supported.question.tier or 3) < 3,
    f"a supported topic whose scores are low steps DOWN a tier, never up — got tier {supported.question.tier}",
)


# =====================================================================  §3  ==
# Meta-utterance detection.

from app.agents.harness.meta_utterance import classify_meta_utterance, response_for  # noqa: E402

for utterance in ("Can you repeat that?", "Sorry, could you say that again?", "What was the question?", "Come again?", "One more time please"):
    got = classify_meta_utterance(utterance)
    expect(got is not None and got.kind == "repeat", f"{utterance!r} is a repeat request, got {got}")

for utterance in ("What do you mean by that?", "Could you clarify?", "Sorry, can you rephrase that?", "I don't understand the question"):
    got = classify_meta_utterance(utterance)
    expect(got is not None and got.kind == "clarify", f"{utterance!r} is a clarify request, got {got}")

# The failure mode that matters: swallowing a real answer. A candidate loses
# work they do not get a second chance to give.
REAL_ANSWERS = (
    "Sorry, um — so what we did was split the monolith by bounded context, starting with billing.",
    "I'm not sure I'd do it the same way again, but at the time we picked Kafka because we already ran it.",
    "What do you mean by that is actually the question I asked the vendor, and their answer was that the SLA only covered reads.",
    "Can you repeat that pattern across services? That was the thing I kept asking, and eventually we wrote a shared library for it.",
    SUBSTANTIVE,
)
for answer in REAL_ANSWERS:
    expect(classify_meta_utterance(answer) is None, f"a real answer is never swallowed: {answer[:52]!r}…")

repeat = classify_meta_utterance("Sorry, can you repeat that?")
assert repeat
QUESTION_TEXT = "Walk me through how you found which query needed the index."
reply = response_for(repeat, QUESTION_TEXT)
expect(QUESTION_TEXT in reply, "a repeat request gets the question back VERBATIM, not a paraphrase of it")

clarify = classify_meta_utterance("What do you mean by that?")
assert clarify
clarify_reply = response_for(clarify, QUESTION_TEXT)
expect(QUESTION_TEXT in clarify_reply, "a clarify request also restates the question verbatim rather than inventing a reading of it")
for text in (reply, clarify_reply):
    expect(
        not any(word in text.lower() for word in ("wrong", "incorrect", "good", "great", "should have")),
        "neither reply implies a verdict — the candidate has not answered yet",
    )


# =====================================================================  §4  ==
# Phrasing variety.

from app.interview_domain.transitions import CUE_CATALOGUE, cues_used_in  # noqa: E402

expect(
    cues_used_in("Staying with that, how do you decide when an index costs more than it saves?") == ["Staying with that"],
    "a cue in a generated question is detected so it can be recorded as spent",
)
expect(
    cues_used_in("STAYING WITH THAT — how do you decide?") == ["Staying with that"],
    "detection survives casing and punctuation, so a reworded cue is not missed",
)
expect(
    cues_used_in("How do you decide when an index costs more than it saves?") == [],
    "a question with no cue records nothing — forbidding a phrase never used would be worse than not tracking",
)
expect(all(cues_used_in(cue) for cue in CUE_CATALOGUE), "every catalogue entry detects itself")


# =====================================================================  §5  ==
# Long-range callbacks.

from app.agents.harness.callbacks import NOTABLE_SCORE, callback_fact_from  # noqa: E402

METRIC_ANSWER = (
    "We looked at the slow query log first. The nightly aggregate went from 4 minutes to 8 seconds once "
    "the partial index was in. After that we left it alone."
)
fact = callback_fact_from(METRIC_ANSWER, score=2.0)
expect(fact is not None and "4 minutes to 8 seconds" in fact, f"a quantified claim is kept even on a middling score, got {fact!r}")
expect(
    fact is not None and "slow query log" not in fact,
    f"the sentence carrying the measure is preferred over the first one, got {fact!r}",
)
expect(
    callback_fact_from("We used Postgres for it.", score=NOTABLE_SCORE) is not None,
    "an answer the Eval Tool scored well is kept even without a metric",
)
expect(callback_fact_from("We used Postgres for it.", score=2.0) is None, "an unremarkable answer is not kept — the cap is small")
expect(callback_fact_from("", score=5.0) is None, "an empty transcript has nothing to remember")

verbatim = callback_fact_from("The nightly report went from 4 minutes to 8 seconds.", score=5.0)
expect(
    verbatim is not None and verbatim in "The nightly report went from 4 minutes to 8 seconds.",
    f"a short fact is a VERBATIM slice — it is handed to the grounding check as a source document, got {verbatim!r}",
)


# =====================================================================  §6  ==
# Audio pacing.

from app.interview_domain.transitions import split_leading_cue  # noqa: E402

split = split_leading_cue("Staying with that — how do you decide when an index costs more than it saves?")
expect(split is not None, "a line opening with a cue is split so a pause can go between the two halves")
assert split
expect(split[0] == "Staying with that", f"the cue is the first half, got {split[0]!r}")
expect(split[1].startswith("how do you decide"), f"the question is the second half, got {split[1]!r}")

expect(
    split_leading_cue("How do you decide when an index costs more than it saves?") is None,
    "a plain question is never split — a pause in the middle of a question is worse than no pause",
)
expect(
    split_leading_cue("What would you change about it — and why did you pick Kafka?") is None,
    "a leading clause that is not a catalogue cue is left alone, however dash-shaped it looks",
)
expect(split_leading_cue("Staying with that.") is None, "nothing is split off when there would be no question left")

from app.tools.speech_service.fixture_provider import FixtureSpeechProvider  # noqa: E402
from app.tools.speech_service.pacing import PAUSE_MS, synthesize_paced  # noqa: E402
from app.tools.speech_service.provider import decode_wav  # noqa: E402

provider = FixtureSpeechProvider()
paced = asyncio.run(synthesize_paced(provider, split[0], split[1]))
expect(paced is not None, "the two halves are stitched into one clip, so `audio_url` stays a single ref")
assert paced
plain = asyncio.run(provider.synthesize(f"{split[0]} {split[1]}"))
paced_ms = decode_wav(paced.audio).duration_ms
plain_ms = decode_wav(plain.audio).duration_ms
expect(
    paced_ms >= plain_ms + PAUSE_MS * 0.8,
    f"the stitched clip is about {PAUSE_MS}ms longer than the unpaced one ({paced_ms}ms vs {plain_ms}ms) — the pause is really in the audio",
)


# =====================================================================  §7  ==
# Session arc.

from app.agents.harness.session_arc import BASE_WRAP_UP, build_session_arc, wrap_up_line  # noqa: E402

arc = build_session_arc([("introduction", True), ("databases", True), ("databases", True), ("apis and services", True)])
expect(arc.answered_count == 3, f"the introduction opener is excluded from the count, got {arc.answered_count}")
expect(arc.covered_topics == ["databases", "apis and services"], f"topics are named once, in the order they came up, got {arc.covered_topics}")

line = wrap_up_line(arc)
expect("databases and apis and services" in line, f"the closing line names what was actually covered, got: {line}")
expect("3 questions" in line, f"and how many questions were answered, got: {line}")
expect(
    not any(word in line.lower() for word in ("well", "strong", "weak", "score", "grade", "best", "worst", "improve")),
    f"the closing line forms NO judgement — the report owns all of that: {line}",
)

expect(
    wrap_up_line(build_session_arc([("databases", False)])) == BASE_WRAP_UP,
    "a session with nothing answered falls back to the generic ending rather than inventing something to say",
)
expect(
    wrap_up_line(build_session_arc([("introduction", True)])) == BASE_WRAP_UP,
    "an interview that got no further than the opener has nothing specific to close on",
)

overflow = build_session_arc([(f"topic {i}", True) for i in range(7)])
overflow_line = wrap_up_line(overflow)
expect("other areas" in overflow_line, f"a long session summarises the tail rather than listing seven topics, got: {overflow_line}")


# =============================================================  end to end  ==
# The pieces above, wired through the real gateway.

from fastapi.testclient import TestClient  # noqa: E402

from app.gateway import create_app  # noqa: E402

client = TestClient(create_app())

r = client.post("/auth/register", json={"email": "human-flow@example.com", "passcode": "hunter22"})
token = r.json()["token"]
headers = {"Authorization": f"Bearer {token}"}

r = client.post("/sessions", json={"role": "backend engineer", "question_budget": 3}, headers=headers)
session_id = r.json()["session_id"]
for state in ("CONFIG", "TELEMETRY_CHECK"):
    client.post(f"/sessions/{session_id}/advance", json={"to": state}, headers=headers)
client.post(f"/sessions/{session_id}/telemetry-check", json={"mic_ok": True, "speaker_ok": True}, headers=headers)
client.post(f"/sessions/{session_id}/begin", headers=headers)

r = client.get(f"/sessions/{session_id}/questions/next", headers=headers)
question_id = r.json()["question"]["id"]

# (§3) A repeat request does not become an answer.
r = client.post(f"/sessions/{session_id}/answers", json={"question_id": question_id, "transcript": "Sorry, can you repeat that?"}, headers=headers)
body = r.json()
expect(body.get("answered") is False, f"a repeat request comes back as `answered: false`, got {body}")
expect("answer_id" not in body, "no answer id is issued, so nothing can hang a follow-up off a question that was never answered")
expect(body["clarification"]["question_id"] == question_id, "the clarification points back at the same unanswered question")

r = client.get(f"/sessions/{session_id}/transcript", headers=headers)
first = r.json()["transcript"][0]
expect(first["answer"] is None, "and no `Answer` row was written for it — the question is still unanswered")

# (§1) A real answer is acknowledged.
r = client.post(f"/sessions/{session_id}/answers", json={"question_id": question_id, "transcript": SUBSTANTIVE, "transcript_confidence": 0.95}, headers=headers)
body = r.json()
expect(body.get("answered") is True, "a real answer is answered")
expect(bool(body.get("acknowledgment", {}).get("text")), f"and is acknowledged, got {body.get('acknowledgment')}")

# (§2) A candidate who says they do not know gets support, not a harder probe.
r = client.get(f"/sessions/{session_id}/questions/next", headers=headers)
next_question_id = r.json()["question"]["id"]
r = client.post(
    f"/sessions/{session_id}/answers",
    json={"question_id": next_question_id, "transcript": "Honestly, I have no idea. I've never worked with that.", "transcript_confidence": 0.95},
    headers=headers,
)
body = r.json()
expect(body.get("next_action") == "support", f"an 'I have no idea' answer produces the support directive, got {body.get('next_action')}")
expect(body.get("struggle_signal") == "struggle_explicit_unknown", f"and names which signal fired, got {body.get('struggle_signal')}")
expect(body["follow_up"] is not None, "a stuck candidate is always offered a way back in, even though there was no claim to probe")

# (§7) The closing line reflects the session.
client.post(f"/sessions/{session_id}/advance", json={"to": "WRAP_UP"}, headers=headers)

print("\nALL HUMAN-INTERACTION-FLOW CHECKS PASSED")

"""Manual smoke test for F4 — mirrors TRACKING.md Stage 1's gate. Run directly
with the venv's python, not pytest (pytest suite lands alongside the real
agents/tools in later stages)."""

from __future__ import annotations

import os

os.environ["NODE_ENV"] = "test"
os.environ["AUTH_TOKEN_SECRET"] = "x" * 32
os.environ["ALLOW_DEV_AUTH"] = "true"
os.environ["ADMIN_EMAIL_ALLOWLIST"] = "admin@example.com"

from fastapi.testclient import TestClient  # noqa: E402

from app.gateway import create_app  # noqa: E402

app = create_app()
client = TestClient(app)


def expect(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)
    print(f"OK: {msg}")


# health
r = client.get("/health")
expect(r.status_code == 200 and r.json()["mcp_servers"] >= 1, "health reports at least 1 mcp server")

# register + login
r = client.post("/auth/register", json={"email": "student@example.com", "passcode": "hunter22", "full_name": "Stu Dent"})
expect(r.status_code == 201, f"register succeeds ({r.status_code}: {r.text})")
student_token = r.json()["token"]

r = client.post("/auth/login", json={"email": "student@example.com", "passcode": "wrong"})
expect(r.status_code == 401, "login with wrong passcode is 401")

# admin via dev-login (role resolved from allowlist, never from client)
r = client.post("/auth/dev-login", json={"email": "admin@example.com"})
expect(r.status_code == 200 and r.json()["user"]["role"] == "admin", "dev-login resolves admin role from allowlist")
admin_token = r.json()["token"]

r = client.post("/auth/dev-login", json={"email": "someone-else@example.com", "role": "admin"})
expect(r.json()["user"]["role"] == "student", "client-supplied role field is ignored by identity_login")

student_headers = {"Authorization": f"Bearer {student_token}"}
admin_headers = {"Authorization": f"Bearer {admin_token}"}

# RBAC: unauthenticated and wrong-role rejections
r = client.post("/sessions", json={"role": "swe"})
expect(r.status_code == 401, "POST /sessions with no token is 401")

r = client.post("/sessions", json={"role": "swe"}, headers=admin_headers)
expect(r.status_code == 403, "POST /sessions as admin is 403 (admins don't take interviews)")

# session lifecycle: CREATED -> CONFIG -> TELEMETRY_CHECK -> CALIBRATION
r = client.post("/sessions", json={"role": "swe", "job_description": "backend role"}, headers=student_headers)
expect(r.status_code == 201, f"session create succeeds ({r.text})")
session_id = r.json()["session_id"]
expect(r.json()["state"] == "CREATED", "new session starts CREATED")

r = client.get(f"/sessions/{session_id}", headers=student_headers)
expect(r.status_code == 200 and r.json()["session"]["state"] == "CREATED", "get session round-trips state")

# another student cannot read this session
r2 = client.post("/auth/register", json={"email": "other@example.com", "passcode": "hunter22"})
other_headers = {"Authorization": f"Bearer {r2.json()['token']}"}
r = client.get(f"/sessions/{session_id}", headers=other_headers)
expect(r.status_code == 403, "a different candidate cannot read another student's session")

# admin CAN read it
r = client.get(f"/sessions/{session_id}", headers=admin_headers)
expect(r.status_code == 200, "admin can read any session")

r = client.post(f"/sessions/{session_id}/advance", json={"to": "CONFIG"}, headers=student_headers)
expect(r.status_code == 200 and r.json()["session"]["state"] == "CONFIG", "CREATED -> CONFIG")

r = client.post(f"/sessions/{session_id}/advance", json={"to": "TELEMETRY_CHECK"}, headers=student_headers)
expect(r.status_code == 200 and r.json()["session"]["state"] == "TELEMETRY_CHECK", "CONFIG -> TELEMETRY_CHECK")

# CALIBRATION is gated behind a passed telemetry check
r = client.post(f"/sessions/{session_id}/advance", json={"to": "CALIBRATION"}, headers=student_headers)
expect(r.status_code == 409, "CALIBRATION is refused before the telemetry check passes")

r = client.post(
    f"/sessions/{session_id}/telemetry-check",
    json={"mic_ok": True, "speaker_ok": True, "consent": {"telemetry": True}},
    headers=student_headers,
)
expect(r.status_code == 200 and r.json()["passed"] is True, "telemetry check recorded as passed")
expect(r.json()["consent"]["clipboardMonitor"] is False, "consent wire shape is camelCase")

r = client.post(f"/sessions/{session_id}/advance", json={"to": "CALIBRATION"}, headers=student_headers)
expect(r.status_code == 200 and r.json()["session"]["state"] == "CALIBRATION", "CALIBRATION allowed once telemetry check passed")

# illegal transition
r = client.post(f"/sessions/{session_id}/advance", json={"to": "COMPLETED"}, headers=student_headers)
expect(r.status_code == 409, "illegal transition CALIBRATION -> COMPLETED is refused")

# audit trail: every transition's actor is the harness
r = client.get(f"/sessions/{session_id}/transitions", headers=student_headers)
transitions = r.json()["transitions"]
expect(len(transitions) == 3, f"three recorded transitions, got {len(transitions)}")
expect(all(t["actor"] == "harness-agent" for t in transitions), "every transition's actor is harness-agent")

print("\nALL SMOKE CHECKS PASSED")

"""Manual smoke test for F5 — resume parsing + Resume Service Agent (Stage 2 parity)."""

from __future__ import annotations

import base64
import os

os.environ["NODE_ENV"] = "test"
os.environ["AUTH_TOKEN_SECRET"] = "x" * 32

from fastapi.testclient import TestClient  # noqa: E402

from app.gateway import create_app  # noqa: E402

app = create_app()
client = TestClient(app)


def expect(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)
    print(f"OK: {msg}")


r = client.post("/auth/register", json={"email": "resume-student@example.com", "passcode": "hunter22"})
token = r.json()["token"]
headers = {"Authorization": f"Bearer {token}"}

r = client.post(
    "/sessions",
    json={
        "role": "backend engineer",
        "job_description": (
            "We need someone with strong experience in distributed systems and Kubernetes. "
            "You will own our microservices architecture and be responsible for on-call reliability. "
            "Experience with PostgreSQL and Redis is required. Familiarity with machine learning is a plus."
        ),
    },
    headers=headers,
)
session_id = r.json()["session_id"]

r = client.post(f"/sessions/{session_id}/advance", json={"to": "CONFIG"}, headers=headers)
expect(r.status_code == 200, "advance to CONFIG")

RESUME_TEXT = """
Jane Doe
Senior Software Engineer

Experience
Senior Backend Engineer at Acme Corp, 2019 - present
Led the migration to a distributed microservices architecture on Kubernetes.
Owned the on-call rotation and reduced incident response time by half.
Built a Postgres-backed event bus using Kafka for cross-service messaging.

Software Engineer at Widgets Inc, 2016 - 2019
Worked with cross-functional teams to deliver REST APIs.

Skills
Python, Kubernetes, Postgres, Kafka, Redis, Docker, AWS, Terraform

Education
B.S. Computer Science, State University
""".strip()

data_b64 = base64.b64encode(RESUME_TEXT.encode("utf-8")).decode("ascii")

r = client.post(
    f"/sessions/{session_id}/resume",
    json={"filename": "resume.txt", "content_type": "text/plain", "data_base64": data_b64},
    headers=headers,
)
expect(r.status_code == 201, f"resume upload succeeds ({r.status_code}: {r.text})")
body = r.json()
expect(body["resume"]["filename"] == "resume.txt", "stored filename round-trips")
expect(body["jd_fit"]["fit_score"] > 0, f"JD fit score is nonzero: {body['jd_fit']}")
expect(len(body["jd_fit"]["matched_requirements"]) > 0, "at least one JD requirement matched")
topics = {t["topic"] for t in body["topic_relevance"]}
expect("distributed systems" in topics, f"distributed systems topic detected: {topics}")
expect("cloud and infrastructure" in topics, f"cloud/infra topic detected: {topics}")

# every evidence string must be a literal line from the resume (no fabrication)
resume_lines = {line.strip() for line in RESUME_TEXT.splitlines() if line.strip()}
for t in body["topic_relevance"]:
    expect(t["evidence"] in resume_lines, f"evidence for {t['topic']!r} is a verbatim resume line: {t['evidence']!r}")

# GET jd-fit reflects what was just uploaded
r = client.get(f"/sessions/{session_id}/jd-fit", headers=headers)
expect(r.status_code == 200, "GET jd-fit")
expect(r.json()["jd_fit"]["fit_score"] == body["jd_fit"]["fit_score"], "jd-fit GET matches upload response")
expect(r.json()["seniority_estimate"] in ("junior", "mid", "senior", "staff+"), f"seniority estimated: {r.json()['seniority_estimate']}")

# a different candidate cannot touch this session's resume
r2 = client.post("/auth/register", json={"email": "resume-other@example.com", "passcode": "hunter22"})
other_headers = {"Authorization": f"Bearer {r2.json()['token']}"}
r = client.delete(f"/sessions/{session_id}/resume", headers=other_headers)
expect(r.status_code == 403, "a different candidate cannot delete another student's resume")

# delete hard-deletes; the structured profile survives
r = client.delete(f"/sessions/{session_id}/resume", headers=headers)
expect(r.status_code == 200 and r.json()["deleted"] is True, "resume delete succeeds")

r = client.get(f"/sessions/{session_id}", headers=headers)
expect(r.json()["session"]["resumeRef"] is None, "resumeRef cleared after delete")
profile = r.json()["session"]["candidateProfile"]
expect(profile is not None, "structured profile survives resume deletion")

# (highlights fix regression test) No LLM_PROVIDER is configured in this test
# environment, so `resolve_provider()` selects the deterministic fixture
# model (see `llm_client/provider.py`), and the resume-parser tool is wired
# to a real `tool_client_factory` in `gateway.py` — so `parse_resume` must
# actually take the LLM-powered path, not silently fall back to the
# regex-only parser. The regex parser has no way to produce `highlights` at
# all (it is always `[]` from that path), so any non-empty `highlights`
# array here is direct proof the LLM path ran end to end and its output
# survived being turned into a `CandidateProfile` without an exception —
# exactly what used to fail silently before this fix (a field-name mismatch
# between the LLM's output shape and the internal `ExperienceEntry`
# dataclass raised `TypeError`, caught by a blanket `except Exception`, and
# fell back to the regex parser on every single call).
experience = profile["experience"]
expect(len(experience) > 0, "candidate profile has at least one experience entry")
all_highlights = [h for entry in experience for h in entry.get("highlights", [])]
expect(len(all_highlights) > 0, f"LLM-powered resume parse produced experience highlights: {experience}")

# unsupported format is rejected plainly, not silently profiled
r = client.post(
    f"/sessions/{session_id}/resume",
    json={"filename": "resume.doc", "content_type": "application/msword", "data_base64": base64.b64encode(b"junk").decode()},
    headers=headers,
)
expect(r.status_code == 415, f"legacy .doc rejected as unsupported format ({r.status_code}: {r.text})")

print("\nALL F5 SMOKE CHECKS PASSED")

"""Manual smoke test for F10 — the LLM client (provider seam + structured_call
+ grounding), the LLM Provider Tool MCP server, and the three dormant call
sites (Resume Service Agent's `_enrich_jd_fit`, Question Agent's
`_generate_question`, Follow-up Agent's `_generate_probe`) coming alive now
that `tool-llm-provider` is registered. Run directly with the venv's python,
not pytest — same convention as every other smoke_stage*.py in this repo."""

from __future__ import annotations

import asyncio
import os

os.environ["NODE_ENV"] = "test"
os.environ["AUTH_TOKEN_SECRET"] = "x" * 32
# Deterministic for this whole run regardless of what's in backend/.env —
# this smoke test proves the WIRING, not any particular provider's output.
os.environ["LLM_PROVIDER"] = "fixture"
os.environ["QUESTION_AGENT_LLM_PROVIDER"] = ""
os.environ["RESUME_SERVICE_LLM_PROVIDER"] = ""

from fastapi.testclient import TestClient  # noqa: E402

from app.gateway import create_app  # noqa: E402
from app.llm_client.prompt_registry import PROMPT_FINGERPRINTS, PromptRegistry  # noqa: E402
from app.llm_client.provider import resolve_provider  # noqa: E402
from app.llm_client.schemas import LLM_SCHEMA_REFS  # noqa: E402
from app.llm_client.structured_call import StructuredCallOptions, structured_call  # noqa: E402
from app.llm_client.tools import FOLLOW_UP_TOOL, JD_FIT_TOOL, JD_REQUIREMENTS_TOOL, QUESTION_TOOL, RESUME_PARSE_TOOL  # noqa: E402
from app.llm_client.types import ToolDefinition  # noqa: E402

app = create_app()
client = TestClient(app)


def expect(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)
    print(f"OK: {msg}")


# ---------------------------------------------------------------- fingerprints
# Proves the ported prompt text is byte-for-byte the same as the TS source,
# not a paraphrase (prompt_registry.py's whole reason for checking this in).
fingerprints = PromptRegistry.fingerprints()
expect(fingerprints == PROMPT_FINGERPRINTS, f"prompt fingerprints match the TS registry: {fingerprints}")

# ------------------------------------------------------------- provider seam
choice = resolve_provider({"LLM_PROVIDER": "fixture"})
expect(choice.provider == "fixture", "resolve_provider honors an explicit fixture request")

choice = resolve_provider({"LLM_PROVIDER": "groq"})
expect(choice.provider == "fixture" and "GROQ_API_KEY" in choice.reason, "missing credentials degrade groq to the fixture")

choice = resolve_provider({"LLM_PROVIDER": "groq", "GROQ_API_KEY": "test-key"})
expect(choice.provider == "groq", "a present credential lets the real provider through")

choice = resolve_provider(
    {"LLM_PROVIDER": "groq", "QUESTION_AGENT_LLM_PROVIDER": "fixture"}, QUESTION_TOOL["name"]
)
expect(choice.provider == "fixture" and "QUESTION_AGENT_LLM_PROVIDER" in choice.reason, "a per-role override wins over LLM_PROVIDER")


# ------------------------------------------------------- structured_call unit
async def _run_structured_call_checks() -> None:
    for tool_dict, ref in (
        (JD_FIT_TOOL, LLM_SCHEMA_REFS["jd_fit"]),
        (QUESTION_TOOL, LLM_SCHEMA_REFS["question"]),
        (FOLLOW_UP_TOOL, LLM_SCHEMA_REFS["follow_up"]),
        (RESUME_PARSE_TOOL, LLM_SCHEMA_REFS["resume_parse"]),
        (JD_REQUIREMENTS_TOOL, LLM_SCHEMA_REFS["jd_requirements"]),
    ):
        assert tool_dict["schema_ref"] == ref

    # jd_fit: fixture builds `rationale.evidence` from a real source document,
    # so it must pass its own grounding check with a real `structured_call`.
    tool = ToolDefinition(
        name=JD_FIT_TOOL["name"],
        description="jd fit",
        schema=__import__("app.llm_client.schemas", fromlist=["JdFitGeneration"]).JdFitGeneration,
        prompt_version=JD_FIT_TOOL["prompt_version"],
        schema_ref=JD_FIT_TOOL["schema_ref"],
        required_grounded_paths=(),
    )
    job_description = "We need someone strong in Kubernetes and distributed systems."
    resume_lines = ["Built and operated Kubernetes clusters for a distributed systems team."]
    result = await structured_call(
        tool,
        {
            "role": "backend engineer",
            "job_description": job_description,
            "resume_lines": resume_lines,
            "matched_requirements": ["Kubernetes"],
            "gaps": [],
            "candidate_topics": ["system design"],
        },
        StructuredCallOptions(provider="fixture", source_documents=[job_description, "\n".join(resume_lines)]),
    )
    expect(result.output is not None and result.provider == "fixture", "structured_call round trips jd_fit through the fixture provider")
    expect(result.grounded, "the fixture's jd_fit evidence passes its own grounding check")


asyncio.run(_run_structured_call_checks())

# ------------------------------------------------- MCP dev passthrough (F3/F1)
r = client.post("/auth/register", json={"email": "llm-smoke@example.com", "passcode": "hunter22"})
token = r.json()["token"]
headers = {"Authorization": f"Bearer {token}"}

r = client.post("/sessions", json={"role": "backend engineer", "job_description": "distributed systems and databases"}, headers=headers)
session_id = r.json()["session_id"]

r = client.post(
    "/internal/mcp/call",
    json={
        "session_id": session_id,
        "server": "tool-llm-provider",
        "method": "generate_structured",
        "params": {
            "session_id": session_id,
            "tool_name": QUESTION_TOOL["name"],
            "prompt_version": QUESTION_TOOL["prompt_version"],
            "schema_ref": QUESTION_TOOL["schema_ref"],
            "input": {
                "role": "backend engineer",
                "topic_plan": [{"topic": "databases", "max_questions": 1, "source": "role_requirement"}],
                "candidate_profile_lines": ["Operated a large PostgreSQL fleet."],
                "baseline": {
                    "text": "Tell me about a time you worked with databases.",
                    "topic": "databases",
                    "type": "behavioral",
                    "difficulty": 2,
                    "expected_signals": ["a concrete database incident", "what they personally did"],
                },
            },
            "source_documents": ["databases (role_requirement)", "Operated a large PostgreSQL fleet."],
        },
    },
    headers=headers,
)
expect(r.status_code == 200 and r.json()["ok"], f"generate_structured succeeds over the MCP dev passthrough: {r.text}")
body = r.json()["data"]
expect(body["provider"] == "fixture" and body["output"] is not None, "the passthrough call returns a grounded fixture question")

# unknown_schema_ref / unknown_prompt_version error mapping
r = client.post(
    "/internal/mcp/call",
    json={
        "session_id": session_id,
        "server": "tool-llm-provider",
        "method": "generate_structured",
        "params": {
            "session_id": session_id,
            "tool_name": "nonexistent.method",
            "prompt_version": "nonexistent/v1",
            "schema_ref": "llm:nonexistent/ref@v1",
            "input": {},
        },
    },
    headers=headers,
)
expect(
    r.status_code == 400 and r.json()["error"]["code"] == "unknown_schema_ref",
    f"an unregistered schema_ref is rejected as unknown_schema_ref: {r.text}",
)

# --------------------------------------------------- dormant call sites, live
r = client.post(f"/sessions/{session_id}/advance", json={"to": "CONFIG"}, headers=headers)
expect(r.status_code == 200, "advance to CONFIG")

RESUME_TEXT = """
Jane Doe

Experience
Senior Backend Engineer, Northwind Systems (2020 - Present)
Operated a large PostgreSQL fleet and led the migration to Kubernetes.

Education
B.S. Computer Science, State University, 2018

Skills
PostgreSQL, Kubernetes, Go, Kafka
"""
import base64  # noqa: E402

r = client.post(
    f"/sessions/{session_id}/resume",
    json={"filename": "resume.txt", "content_type": "text/plain", "data_base64": base64.b64encode(RESUME_TEXT.encode()).decode()},
    headers=headers,
)
expect(r.status_code == 201, f"resume upload succeeds: {r.status_code} {r.text}")
profile = r.json()

jd_fit = profile["jd_fit"]
expect(jd_fit.get("rationale") is not None, f"F10 live: jd_fit.rationale is now populated by the LLM enrichment path: {jd_fit}")
expect(bool(jd_fit.get("topic_relevance")), "F10 live: jd_fit.topic_relevance (JD-anchored) is populated")
expect(jd_fit.get("role_level") is not None, "F10 live: jd_fit.role_level is populated by the JD requirements parser")
expect(bool(jd_fit.get("key_technologies")), "F10 live: jd_fit.key_technologies is populated")
expect(jd_fit.get("prompt_version") == JD_FIT_TOOL["prompt_version"], "the enrichment stamps the active prompt version")

# A second upload of byte-identical resume+JD content must hit the
# already-generated draft rather than spend a second provider round trip
# (§4.7's cached-draft path in `_enrich_jd_fit`, via the memory-agent).
r2 = client.post(
    f"/sessions/{session_id}/resume",
    json={"filename": "resume.txt", "content_type": "text/plain", "data_base64": base64.b64encode(RESUME_TEXT.encode()).decode()},
    headers=headers,
)
expect(
    r2.status_code == 201 and r2.json()["jd_fit"]["rationale"] == jd_fit["rationale"],
    "an identical re-upload reuses the cached jd_fit draft",
)

print()
print("ALL F10 SMOKE CHECKS PASSED")

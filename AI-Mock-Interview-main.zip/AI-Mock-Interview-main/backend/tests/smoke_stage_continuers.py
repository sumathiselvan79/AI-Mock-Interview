"""Stage-gate test for HUMAN_INTERACTION_FLOW.md §8 — conversational continuers.

The eighth method, and it holds the same two lines the first seven do:

 - **No interview logic moved into a model.** Nothing below configures a
   provider, because nothing a provider returns changes whether a continuer is
   spoken or which one it is. A deterministic rule picks a pre-written line.
 - **A continuer never advances the interview.** It is not a turn, not an
   answer, not a question, and — the one genuinely new hazard in this method —
   it goes out on the wire *while the reply the client is waiting for is still
   being computed*. Everything about ordering below is about that.

Run: `python -m tests.smoke_stage_continuers` from `backend/`.
"""

from __future__ import annotations

import asyncio
import os
import time
from typing import Any, Optional

os.environ["NODE_ENV"] = "test"
os.environ["AUTH_TOKEN_SECRET"] = "x" * 32


def expect(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)
    print(f"OK: {msg}")


# ==========================================================  the vocabulary  ==

from app.interview_domain.acknowledgments import BRIEF_ACKS, SUBSTANTIVE_ACKS  # noqa: E402
from app.interview_domain.continuers import (  # noqa: E402
    FOLLOW_UP_RECEIPTS,
    HOLDING_LINE_AFTER_MS,
    HOLDING_LINES,
    OPENING_LINE,
    SELECTION_LINES,
    continuer_for,
    phrase_kind_for,
)

ALL_POOLS = (*HOLDING_LINES, *SELECTION_LINES, *FOLLOW_UP_RECEIPTS)

# Every continuer fires before the Eval Tool has said anything about the turn it
# sits in — the holding line before the answer is scored, the receipt before the
# follow-up exchange is, the opening before the interview has begun. So none of
# them may read as a verdict. Same list §1's acknowledgment pools are held to,
# for the same reason (soul.md §"No fabrication").
VERDICT_WORDS = ("great", "good", "excellent", "nice", "perfect", "well done", "interesting", "wrong", "poor", "impressive", "clear")
for phrase in (*ALL_POOLS, OPENING_LINE):
    lowered = phrase.lower()
    expect(
        not any(word in lowered for word in VERDICT_WORDS),
        f"nothing in the continuer vocabulary reads as a verdict: {phrase[:48]!r}…",
    )

# A holding line covers the wait while an answer is being scored. It must
# therefore say nothing ABOUT the answer — a line that characterised it would be
# a reading of something the system has not read yet.
for phrase in HOLDING_LINES:
    lowered = phrase.lower()
    expect(
        "that's" not in lowered and "you said" not in lowered and "your answer" not in lowered,
        f"a holding line talks about the interviewer, never about the answer: {phrase!r}",
    )

# A selection line runs while the Question Agent is still writing. It cannot
# name a topic, because it does not know one yet — announcing a question the
# interview then does not ask is worse than saying nothing. Checked against the
# actual topic vocabulary rather than a hand-written word list, so a line added
# later that does name one is caught by the same assertion.
from app.interview_domain.topics import TOPICS  # noqa: E402

TOPIC_NAMES = tuple(t.topic.lower() for t in TOPICS)
for phrase in SELECTION_LINES:
    named = [name for name in TOPIC_NAMES if name in phrase.lower()]
    expect(not named, f"a selection line names no topic — none has been chosen yet: {phrase!r} named {named}")

# The opening line may set expectations and may not make a promise the session
# does not keep. There is a budget and a visible clock, so "take your time" and
# "no rush" are both false.
expect(
    "no rush" not in OPENING_LINE.lower() and "take your time" not in OPENING_LINE.lower(),
    "the opening line promises no time it cannot give — there is a budget and a clock on screen",
)
expect("clock" in OPENING_LINE.lower(), "the opening line says the clock exists rather than leaving the candidate to find it")

# The pools are namespaced apart, from each other and from §1 and §4. Two pools
# sharing a memory kind would let one exhaust the other's rotation.
kinds = {phrase_kind_for(k) for k in ("holding", "selection", "follow_up_receipt")}  # type: ignore[arg-type]
expect(len(kinds) == 3, f"each rotated pool has its own memory kind, got {kinds}")
expect(
    not (kinds & {"acknowledgment", "transition"}),
    "no continuer pool shares a namespace with §1's acknowledgments or §4's transition cues",
)
expect(phrase_kind_for("opening") is None, "the opening line is not rotated — it is one fixed line said once")  # type: ignore[arg-type]

# Rotation, identical to §1's: the whole pool is spent before anything repeats,
# then the least recently used comes back.
seen: list[str] = []
for _ in range(len(HOLDING_LINES)):
    line = continuer_for("holding", used_phrases=seen)
    assert line
    seen.append(line)
expect(len(set(seen)) == len(HOLDING_LINES), f"a long wait never hears the same holding line twice in a row, got {seen}")
expect(continuer_for("holding", used_phrases=seen) == seen[0], "once spent, the pool reuses the line used longest ago")

expect(continuer_for("opening") == OPENING_LINE, "the opening kind resolves to the fixed greeting")

# The holding pool and the acknowledgment pools are said seconds apart in the
# same turn. Sharing a phrase would make the pair read as a stutter.
expect(
    not (set(HOLDING_LINES) & set(SUBSTANTIVE_ACKS) & set(BRIEF_ACKS)),
    "a holding line is never the same words as the acknowledgment that preceded it by seconds",
)

expect(
    2_000 <= HOLDING_LINE_AFTER_MS <= 6_000,
    f"the threshold is a silence that has stopped reading as thinking, not a latency target — got {HOLDING_LINE_AFTER_MS}ms",
)


# =============================================================  the timing  ==
# The half of §8 that is not vocabulary: WHEN a continuer is spoken, and what
# happens to the turn it was covering for.

from app.agents.harness.interview import InterviewDeps, InterviewOrchestrator  # noqa: E402


class _Tools:
    """Just enough MCP surface for `speak` and the phrase-rotation calls."""

    def __init__(self) -> None:
        self.spoken: list[str] = []
        self.remembered: list[tuple[str, str]] = []
        self.speak_delay = 0.0

    async def call(self, server: str, method: str, params: dict[str, Any]) -> Any:
        if method == "synthesize_speech":
            if self.speak_delay:
                await asyncio.sleep(self.speak_delay)
            self.spoken.append(params["text"])
            return {"audio_url": "/audio/fake", "duration_ms": 400.0}
        if method == "get_used_phrases":
            return {"used_phrases": [k for kind, k in self.remembered if kind == params["kind"]]}
        if method == "remember_used_phrase":
            self.remembered.append((params["kind"], params["phrase"]))
            return {"remembered": True}
        raise AssertionError(f"unexpected MCP call {server}.{method}")


class _Telemetry:
    def __init__(self) -> None:
        self.spans: list[tuple[str, str, dict[str, Any]]] = []

    async def emit(self, event: str, session_id: str, payload: dict[str, Any]) -> None:
        self.spans.append((event, session_id, payload))


def _orchestrator() -> tuple[InterviewOrchestrator, _Tools, _Telemetry]:
    tools, telemetry = _Tools(), _Telemetry()
    return (
        InterviewOrchestrator(
            InterviewDeps(sessions=None, questions=None, answers=None, evaluations=None, telemetry=telemetry, tool_client=lambda _s, _c: tools)
        ),
        tools,
        telemetry,
    )


async def _work(delay: float, value: str = "done") -> str:
    await asyncio.sleep(delay)
    return value


async def timing_checks() -> None:
    threshold = HOLDING_LINE_AFTER_MS / 1000

    # 1. Fast work gets no continuer. There is no silence to fill, and a line
    #    spoken into a gap that short would collide with the reply.
    orch, tools, spans = _orchestrator()
    pushed: list[Any] = []
    result = await orch._await_with_continuer(
        _work(0.01), session_id="s1", kind="holding", on_continuer=lambda c: _record(pushed, c)
    )
    expect(result == "done" and not pushed, f"work that finishes quickly speaks no continuer, got {pushed}")
    expect(not spans.spans, "and emits no span either — a detector that did not fire has nothing to report")

    # 2. Slow work gets exactly one, and the result still comes back intact.
    orch, tools, spans = _orchestrator()
    pushed = []
    result = await orch._await_with_continuer(
        _work(threshold + 0.25), session_id="s2", kind="holding", on_continuer=lambda c: _record(pushed, c)
    )
    expect(result == "done", "the continuer never replaces or swallows the result it was covering for")
    expect(len(pushed) == 1, f"a long wait speaks exactly one continuer, not one per second, got {len(pushed)}")
    expect(pushed[0].kind == "holding", f"the pushed continuer carries its kind, got {pushed[0].kind!r}")
    expect(pushed[0].spoken.text in HOLDING_LINES, f"the line comes from the holding pool, got {pushed[0].spoken.text!r}")
    expect(tools.spoken == [pushed[0].spoken.text], "the line was actually synthesised, not merely pushed as text")
    expect(
        tools.remembered == [("continuer:holding", pushed[0].spoken.text)],
        f"the line is recorded as spent so the next wait says something else, got {tools.remembered}",
    )
    # Per the design note's cross-cutting rule: a detector that fires says so.
    # The detector here IS a clock, so the span doubles as the plainest signal
    # available that a provider round trip has gone long.
    expect(len(spans.spans) == 1 and spans.spans[0][0] == "continuer_spoken", f"one span per continuer, got {spans.spans}")
    expect(spans.spans[0][2]["kind"] == "holding", "the span names which wait it was")
    expect(spans.spans[0][2]["spoken"] is True, "and records that the line actually reached the candidate")
    expect(
        spans.spans[0][2]["waited_ms"] >= HOLDING_LINE_AFTER_MS,
        f"the span carries the REAL total wait, not the threshold that triggered it, got {spans.spans[0][2]}",
    )

    # 3. The continuer must never add latency to the turn it was meant to make
    #    feel faster. A synthesis slower than the work left is cancelled.
    orch, tools, spans = _orchestrator()
    tools.speak_delay = 5.0
    pushed = []
    started = time.monotonic()
    result = await orch._await_with_continuer(
        _work(threshold + 0.05), session_id="s3", kind="selection", on_continuer=lambda c: _record(pushed, c)
    )
    elapsed = time.monotonic() - started
    expect(result == "done", "a slow synthesis still yields the real result")
    expect(
        elapsed < threshold + 1.0,
        f"a slow continuer is cancelled rather than delaying the reply — took {elapsed:.2f}s for {threshold + 0.05:.2f}s of work",
    )
    expect(not pushed, "a continuer that lost the race is never pushed — the real reply is already on its way")
    expect(
        len(spans.spans) == 1 and spans.spans[0][2]["spoken"] is False,
        f"a lost race is still recorded, marked as not spoken — the wait happened even though the line did not, got {spans.spans}",
    )

    # 4. Work that raises still raises. A continuer is a courtesy layer, not an
    #    error handler; swallowing the failure here would strand the turn.
    orch, _, spans = _orchestrator()
    raised = False
    try:
        await orch._await_with_continuer(_boom(threshold + 0.1), session_id="s4", kind="holding", on_continuer=lambda c: _record([], c))
    except RuntimeError:
        raised = True
    expect(raised, "a failure in the covered work propagates unchanged")

    # 5. No push channel, no continuer. A REST caller receiving "one moment"
    #    alongside the thing it was waiting for is a log line, not a courtesy.
    orch, tools, spans = _orchestrator()
    result = await orch._await_with_continuer(_work(threshold + 0.2), session_id="s5", kind="holding", on_continuer=None)
    expect(result == "done" and not tools.spoken, "without a push channel nothing is spoken and nothing is delayed")

    # 6. A push that fails must not fail the turn. The socket closing mid-wait
    #    is the ordinary case, not an exceptional one.
    orch, _, spans = _orchestrator()

    async def _closed_socket(_c: Any) -> None:
        raise ConnectionResetError("socket went away")

    result = await orch._await_with_continuer(_work(threshold + 0.15), session_id="s6", kind="holding", on_continuer=_closed_socket)
    expect(result == "done", "a dead socket costs the continuer, never the answer")

    # 7. The window covers everything inside it, not one call.
    #    This is the case running the real app exposed: on the introduction
    #    turn a provider round trip (the topic-plan fusion) runs BEFORE the
    #    call the first version wrapped, so the candidate got "Mm-hm." and then
    #    34 seconds of nothing. Two short steps that are individually under the
    #    threshold but together over it must still produce a line.
    orch, tools, spans = _orchestrator()
    pushed = []
    async with orch._continuer_window(session_id="s7", kind="holding", on_continuer=lambda c: _record(pushed, c)):
        await _work(threshold * 0.6)
        await _work(threshold * 0.6)
    expect(len(pushed) == 1, f"a wait made of several short steps still gets a continuer, got {len(pushed)}")
    expect(
        spans.spans and spans.spans[0][2]["waited_ms"] >= HOLDING_LINE_AFTER_MS,
        f"and the span measures the whole window, not one step of it, got {spans.spans}",
    )

    # 8. A window that closes in time speaks nothing and reports nothing.
    orch, tools, spans = _orchestrator()
    pushed = []
    async with orch._continuer_window(session_id="s8", kind="holding", on_continuer=lambda c: _record(pushed, c)):
        await _work(0.05)
    expect(not pushed and not spans.spans, f"a short window is silent, got pushed={pushed} spans={spans.spans}")

    # 9. An exception inside the window still closes it — no orphaned timer
    #    left speaking into a turn that has already failed.
    orch, tools, spans = _orchestrator()
    pushed = []
    raised = False
    try:
        async with orch._continuer_window(session_id="s9", kind="holding", on_continuer=lambda c: _record(pushed, c)):
            raise RuntimeError("the follow-up agent fell over")
    except RuntimeError:
        raised = True
    expect(raised, "an exception inside the window propagates")
    await asyncio.sleep(threshold + 0.2)
    expect(not pushed, "and its timer is cancelled rather than firing into a turn that already failed")

    # 10. The opening line, spoken through the same path.
    orch, tools, spans = _orchestrator()
    pushed = []
    opening = await orch.opening_line("s10", lambda c: _record(pushed, c))
    assert opening
    expect(opening.kind == "opening" and opening.spoken.text == OPENING_LINE, "the opener speaks the fixed greeting")
    expect(tools.remembered == [], "the opener is not recorded as spent — it is said once and has no pool to rotate")
    expect(len(pushed) == 1, "the opener reaches the push channel like any other continuer")


async def _record(sink: list[Any], continuer: Any) -> None:
    sink.append(continuer)


async def _boom(delay: float) -> str:
    await asyncio.sleep(delay)
    raise RuntimeError("the follow-up agent fell over")


asyncio.run(timing_checks())


# ==============================================================  the wiring  ==
# The three call sites accept the hook, so the live channel can supply one.

import inspect  # noqa: E402
from pathlib import Path  # noqa: E402

from app.agents.harness.harness import HarnessAgent  # noqa: E402

for name in ("next_question", "submit_answer", "submit_follow_up_answer", "submit_audio_answer"):
    params = inspect.signature(getattr(HarnessAgent, name)).parameters
    expect("on_continuer" in params, f"HarnessAgent.{name} takes the continuer hook")
    expect(params["on_continuer"].default is None, f"HarnessAgent.{name}'s hook is optional — a caller without a socket is unchanged")

expect(hasattr(HarnessAgent, "opening_line"), "the harness exposes the opening line as its own call, not folded into begin_interview")

# The wire frame. `continuer` is the only server event pushed from inside a
# handler that has not returned, so the client contract that it is never replied
# to is asserted on the TypeScript side too (`live-protocol.test.ts`).
# Read as text rather than imported: `live_channel` pulls in the Postgres
# storage layer, and whether a continuer frame is well-formed has nothing to do
# with whether a database driver is installed on the machine running the gate.
source = (Path(__file__).resolve().parents[1] / "app" / "http" / "live_channel.py").read_text(encoding="utf-8")
expect('"continuer"' in source, "the live channel sends the continuer frame")
expect(
    '"kind": continuer.kind' in source,
    "the frame carries its kind — the room shows an opening in the thread and a holding line in the indicator",
)
payload_line = next(line for line in source.splitlines() if '_send(ws, "continuer"' in line)
expect(
    "answered" not in payload_line and "answer_id" not in payload_line,
    f"the continuer frame carries no `answered` flag and no ids — it ends no turn: {payload_line.strip()}",
)

print("\nStage 12 (§8, conversational continuers): all checks passed.")

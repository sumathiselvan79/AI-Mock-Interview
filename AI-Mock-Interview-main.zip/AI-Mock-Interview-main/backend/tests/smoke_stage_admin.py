"""Manual smoke test for F9 — Report Agent + retention job + the admin
surface (directory, profile drill-down, downloads, scheduling).

Mirrors TRACKING.md Stage 4's gate and `ADMIN_FEATURE_PROMPT.md`: a real
session is driven all the way to COMPLETED so there is a genuine report to
serve, then every admin route is exercised over real HTTP — including the
two boundaries that matter (a student token is refused everywhere under
/admin, and an Admin cannot consent on a candidate's behalf).
"""

from __future__ import annotations

import base64
import json
import os

os.environ["NODE_ENV"] = "test"
os.environ["AUTH_TOKEN_SECRET"] = "x" * 32
os.environ["ALLOW_DEV_AUTH"] = "true"
os.environ["ADMIN_EMAIL_ALLOWLIST"] = "boss@example.com"

from fastapi.testclient import TestClient  # noqa: E402

from app.gateway import create_app  # noqa: E402

app = create_app()
client = TestClient(app)


def expect(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)
    print(f"OK: {msg}")


RESUME_TEXT = """
Jane Doe

Experience
Senior Backend Engineer at Acme Corp, 2019 - present
Led the migration to a distributed microservices architecture on Kubernetes.
Owned the Postgres schema design for the billing service.

Skills
Python, Kubernetes, Postgres, Kafka, Docker

Education
B.S. Computer Science, State University
""".strip()

ANSWER = (
    "I led the migration of our billing service to a distributed microservices architecture on Kubernetes "
    "because the monolith couldn't scale past 500 requests per second. We considered staying monolithic but "
    "rejected it since the billing team needed independent deploys. As a result, deploy frequency went from "
    "weekly to daily and p99 latency dropped by 40%."
)


def run_full_session(email: str, *, budget: int = 2) -> tuple[str, str, dict]:
    """Register a student, drive a whole interview, and generate the report.
    Returns (candidate_id, session_id, report)."""
    r = client.post("/auth/register", json={"email": email, "passcode": "hunter22"})
    assert r.status_code in (200, 201), r.text
    token = r.json()["token"]
    candidate_id = r.json()["user"]["id"]
    h = {"Authorization": f"Bearer {token}"}

    session_id = client.post(
        "/sessions",
        json={"role": "backend engineer", "job_description": "distributed systems and databases", "question_budget": budget},
        headers=h,
    ).json()["session_id"]

    for state in ("CONFIG", "TELEMETRY_CHECK"):
        client.post(f"/sessions/{session_id}/advance", json={"to": state}, headers=h)

    client.post(
        f"/sessions/{session_id}/resume",
        json={
            "filename": "resume.txt",
            "content_type": "text/plain",
            "data_base64": base64.b64encode(RESUME_TEXT.encode()).decode(),
        },
        headers=h,
    )
    client.post(f"/sessions/{session_id}/telemetry-check", json={"mic_ok": True, "speaker_ok": True}, headers=h)
    client.post(f"/sessions/{session_id}/begin", headers=h)

    for _ in range(budget + 3):
        qbody = client.get(f"/sessions/{session_id}/questions/next", headers=h).json()
        if qbody["done"]:
            break
        client.post(
            f"/sessions/{session_id}/answers",
            json={"question_id": qbody["question"]["id"], "transcript": ANSWER},
            headers=h,
        )

    r = client.post(f"/sessions/{session_id}/report", headers=h)
    assert r.status_code in (200, 201), f"report generation failed: {r.text}"
    return candidate_id, session_id, r.json()["report"], h


# ---------------------------------------------------------------- the report

candidate_id, session_id, report, student_headers = run_full_session("admin-smoke-a@example.com")
expect(len(report["competencyScores"]) >= 1, f"report carries at least one competency score ({report})")
expect(all(c["evidence"] for c in report["competencyScores"]), "every competency cites verbatim evidence")
expect(bool(report["disclaimer"]), "report carries the required disclaimer")

# ------------------------------------------------------- grading (grade bands)
#
# The grade is an interpretation of scores that were already evidenced, banded
# by the Eval Tool (`app/tools/eval/grading.py`) and copied through untouched —
# never re-derived by the harness, the route, or the browser.

expect(
    all(c.get("grade") for c in report["competencyScores"]),
    f"every scored competency carries a grade band ({[c.get('grade') for c in report['competencyScores']]})",
)
expect(
    all(c["grade"]["score"] == c["score"] for c in report["competencyScores"]),
    "a competency's grade bands its OWN score — the number and the letter cannot disagree",
)
expect(
    all(c["grade"]["letter"] in ("A", "B", "C", "D", "E") for c in report["competencyScores"]),
    "grades come from the published band ladder; there is no 'F'",
)
expect(bool(report.get("overallGrade")), f"a session with scoreable answers gets an overall grade ({report.get('overallGrade')})")
expect(
    report["overallGrade"]["scaleVersion"] == "grade-scale/v1",
    f"the overall grade names the scale version that produced it ({report['overallGrade']})",
)

# Strengths vs focus areas is decided on the Eval Tool's `isStrength` flag, so a
# competency badged "B" can never also be filed under "worth strengthening".
_strong_names = {c["competency"] for c in report["competencyScores"] if c["grade"]["isStrength"]}
expect(
    all(not any(name in area for name in _strong_names) for area in report["focusAreas"]),
    f"no graded-strength competency appears in focus areas ({report['focusAreas']})",
)

session_after = client.get(f"/sessions/{session_id}", headers=student_headers).json()["session"]
expect(session_after["state"] == "COMPLETED", f"session reaches COMPLETED, got {session_after['state']}")

# The retention job (§8): the raw resume is gone and transcripts are redacted,
# because this candidate never opted into keeping their recordings.
expect(session_after.get("resumeRef") in (None, ""), "raw resume hard-deleted once the report exists")
transcript = client.get(f"/sessions/{session_id}/transcript", headers=student_headers).json()["transcript"]
expect(
    all(e["answer"] is None or "retention policy" in e["answer"]["transcript"] for e in transcript),
    f"answer transcripts redacted after the report: {[e['answer'] for e in transcript]}",
)
expect(
    all(ANSWER not in (e["answer"] or {}).get("transcript", "") for e in transcript),
    "no answer transcript survives redaction verbatim",
)
expect(
    all(c["evidence"] for c in report["competencyScores"]),
    "the report's own evidence quotes survived redaction (extracted before it ran)",
)

# A second candidate, so the directory has more than one row to sort/filter.
other_id, other_session, _other_report, _oh = run_full_session("admin-smoke-b@example.com")

# --------------------------------------------------------------- admin token

admin_token = client.post("/auth/dev-login", json={"email": "boss@example.com"}).json()["token"]
admin = {"Authorization": f"Bearer {admin_token}"}

# ------------------------------------------------------------------ RBAC

for method, path in [
    ("GET", "/admin/reports"),
    ("GET", "/admin/users"),
    ("GET", f"/admin/users/{candidate_id}"),
    ("GET", "/admin/scheduled-interviews"),
    ("GET", "/admin/archives"),
]:
    r = client.request(method, path, headers=student_headers)
    expect(r.status_code == 403, f"student token refused on {method} {path} (got {r.status_code})")

r = client.get("/admin/reports")
expect(r.status_code == 401, "an unauthenticated request to /admin is refused")

# ------------------------------------------------------------ reports

r = client.get("/admin/reports", headers=admin)
expect(r.status_code == 200 and len(r.json()["reports"]) == 2, f"admin dashboard lists both reports ({r.text[:200]})")

r = client.get(f"/admin/reports/{session_id}", headers=admin)
expect(r.status_code == 200 and r.json()["report"]["sessionId"] == session_id, "admin reads one report by session")
expect(
    "resumeRef" not in r.json()["report"] and "transcript" not in json.dumps(r.json()["report"]),
    "a Report has no field carrying a resume or transcript",
)

r = client.get(f"/admin/reports/{'no-such-session'}", headers=admin)
expect(r.status_code == 404, "unknown session reports 404")

r = client.get(f"/admin/reports/{session_id}/download", headers=admin)
expect(r.status_code == 200, "single-report download succeeds")
expect(
    r.headers["content-disposition"] == f'attachment; filename="report-{session_id}.json"',
    f"download carries an attachment filename ({r.headers.get('content-disposition')})",
)
expect(json.loads(r.text)["sessionId"] == session_id, "downloaded body is the report itself, camelCase as on the wire")

r = client.get(f"/admin/users/{candidate_id}/reports/download", headers=admin)
expect(r.status_code == 200 and len(json.loads(r.text)["reports"]) == 1, "per-candidate report bundle downloads")

# ---------------------------------------------------------------- directory

r = client.get("/admin/users", headers=admin)
expect(r.status_code == 200, f"directory responds ({r.text[:200]})")
page = r.json()
expect(page["total"] == 2 and len(page["rows"]) == 2, f"both students listed, got total={page['total']}")
expect(page["page"] == 1 and page["page_size"] == 25, "default paging is page 1 / 25")
row = next(x for x in page["rows"] if x["user_id"] == candidate_id)
expect(row["interviews_completed"] == 1, f"aggregate counts the completed interview, got {row['interviews_completed']}")
expect(row["average_score"] is not None, "average score comes from the report aggregate")
expect(row["status"] == "active", f"a candidate who has interviewed is active, got {row['status']}")
expect(
    not any(k in row for k in ("resume_ref", "transcript", "audio_ref")),
    "a directory row has no field that could carry a resume, transcript or audio ref",
)

r = client.get("/admin/users?search=admin-smoke-a", headers=admin)
expect(r.json()["total"] == 1, f"search filters by email, got {r.json()['total']}")

r = client.get("/admin/users?min_score=4.99", headers=admin)
expect(all(x["average_score"] >= 4.99 for x in r.json()["rows"]), "min_score filter excludes lower scores")

r = client.get("/admin/users?page_size=1", headers=admin)
expect(len(r.json()["rows"]) == 1 and r.json()["total"] == 2, "paging returns one row but the unpaged total")

r = client.get("/admin/users?sort=email&direction=asc", headers=admin)
emails = [x["email"] for x in r.json()["rows"]]
expect(emails == sorted(emails), f"sort=email ascending is actually ascending: {emails}")

r = client.get("/admin/users?sort=averageScore&direction=asc", headers=admin)
scores = [x["average_score"] for x in r.json()["rows"]]
expect(
    [s for s in scores if s is None] == scores[len([s for s in scores if s is not None]) :],
    f"null scores sort last even ascending: {scores}",
)

r = client.get("/admin/users?status=no_activity", headers=admin)
expect(r.json()["total"] == 0, "no candidate is inactive — both have interviewed")

# ------------------------------------------------------------ profile page

r = client.get(f"/admin/users/{candidate_id}", headers=admin)
expect(r.status_code == 200, f"profile drill-down responds ({r.text[:200]})")
view = r.json()
expect(view["profile"]["user_id"] == candidate_id, "profile is the right candidate")
expect(view["profile"]["interviews_completed"] == 1, "profile counts one completed interview")
expect(len(view["profile"]["score_trend"]) == 1, "score trend has one point")
expect(len(view["sessions"]) == 1 and view["sessions"][0]["has_report"], "session history shows the completed session")
expect(view["sessions"][0]["status"] == "completed", f"history status collapses COMPLETED, got {view['sessions'][0]['status']}")
expect(view["sessions"][0]["duration_minutes"] is not None, "a finished session reports a duration")
expect(view["scheduled"] == [], "no assignments yet")

# ------------------------------------------- the candidate's own history

# GET /me/sessions and the drill-down above are the same rows from the same
# builder (`app/http/session_summaries.py`). The point of checking them here,
# side by side, is that a candidate and an Admin must never be shown a
# different duration or score for one interview.
r = client.get("/me/sessions", headers=student_headers)
expect(r.status_code == 200, f"a student reads their own history ({r.text[:200]})")
mine = r.json()["sessions"]
expect(mine == view["sessions"], "the candidate's own history is byte-identical to the Admin drill-down's")
expect(len(mine) == 1 and mine[0]["session_id"] == session_id, "history is scoped to this candidate's session")

# The route takes no candidate id, so scoping is the token's subject. The
# second candidate must not appear in the first candidate's history.
expect(
    all(row["session_id"] != other_session for row in mine),
    "another candidate's session never appears in this candidate's history",
)
r = client.get("/me/sessions", headers=_oh)
expect(
    [row["session_id"] for row in r.json()["sessions"]] == [other_session],
    "the second candidate sees only their own session",
)

r = client.get("/me/sessions", headers=admin)
expect(r.status_code == 403, "an admin token is refused on /me/sessions, like every other /me route")

r = client.get("/me/sessions")
expect(r.status_code == 401, "an unauthenticated request to /me/sessions is refused")

# An admin account is not a candidate: the directory and this page agree.
admin_id = client.post("/auth/dev-login", json={"email": "boss@example.com"}).json()["user"]["id"]
r = client.get(f"/admin/users/{admin_id}", headers=admin)
expect(r.status_code == 404, "an admin account is not reachable as a candidate profile")

# ---------------------------------------------------------------- scheduling

r = client.post(
    "/admin/scheduled-interviews",
    json={
        "candidate_ids": [candidate_id, other_id, candidate_id],  # duplicate on purpose
        "role": "backend engineer",
        "job_description": "distributed systems",
        "interview_type": "behavioral+technical",
        "difficulty": "senior",
        "duration_minutes": 45,
        "scheduled_for": "2099-01-01T10:00:00Z",
        "deadline": "2099-01-08T10:00:00Z",
    },
    headers=admin,
)
expect(r.status_code == 201, f"batch schedule created ({r.text[:300]})")
created = r.json()["scheduled"]
expect(len(created) == 2, f"a duplicated candidate is assigned once, got {len(created)}")
expect(created[0]["status"] == "pending", f"a future window is pending, got {created[0]['status']}")
schedule_id = created[0]["id"]

# An Admin cannot consent on a candidate's behalf — rejected, not ignored.
r = client.post(
    "/admin/scheduled-interviews",
    json={
        "candidate_ids": [candidate_id],
        "role": "backend engineer",
        "interview_type": "technical",
        "difficulty": "mid",
        "duration_minutes": 30,
        "scheduled_for": "2099-02-01T10:00:00Z",
        "consent": {"clipboard_monitor": True},
    },
    headers=admin,
)
expect(r.status_code == 400 and r.json()["error"]["code"] == "invalid_schedule", f"consent on a schedule is refused ({r.text[:200]})")
expect("Telemetry Check" in r.json()["error"]["message"], "the refusal says where consent actually comes from")

for bad, why in [
    ({"candidate_ids": [], "role": "x", "interview_type": "technical", "difficulty": "mid", "duration_minutes": 30, "scheduled_for": "2099-01-01T10:00:00Z"}, "empty candidate_ids"),
    ({"candidate_ids": [candidate_id], "role": "x", "interview_type": "nonsense", "difficulty": "mid", "duration_minutes": 30, "scheduled_for": "2099-01-01T10:00:00Z"}, "unknown interview_type"),
    ({"candidate_ids": [candidate_id], "role": "x", "interview_type": "technical", "difficulty": "mid", "duration_minutes": 5, "scheduled_for": "2099-01-01T10:00:00Z"}, "duration below the floor"),
    ({"candidate_ids": [candidate_id], "role": "x", "interview_type": "technical", "difficulty": "mid", "duration_minutes": 30, "scheduled_for": "not-a-date"}, "unparseable scheduled_for"),
    ({"candidate_ids": [candidate_id], "role": "x", "interview_type": "technical", "difficulty": "mid", "duration_minutes": 30, "scheduled_for": "2099-01-08T10:00:00Z", "deadline": "2099-01-01T10:00:00Z"}, "deadline before scheduled_for"),
]:
    r = client.post("/admin/scheduled-interviews", json=bad, headers=admin)
    expect(r.status_code == 400, f"rejected: {why} (got {r.status_code})")

r = client.post(
    "/admin/scheduled-interviews",
    json={
        "candidate_ids": [admin_id],
        "role": "x",
        "interview_type": "technical",
        "difficulty": "mid",
        "duration_minutes": 30,
        "scheduled_for": "2099-01-01T10:00:00Z",
    },
    headers=admin,
)
expect(
    r.status_code == 400 and r.json()["error"]["code"] == "unknown_candidate",
    f"scheduling an interview for an Admin is refused ({r.text[:200]})",
)

r = client.get("/admin/scheduled-interviews", headers=admin)
expect(len(r.json()["scheduled"]) == 2, "both assignments listed")
expect(r.json()["scheduled"][0]["candidate_email"] is not None, "the list denormalises the candidate email for display")
expect("notes" in r.json()["scheduled"][0], "the admin projection carries notes")

# The student's own view of the same assignment.
r = client.get("/me/scheduled-interviews", headers=student_headers)
student_view = r.json()["scheduled"]
expect(len(student_view) == 1, f"the candidate sees only their own assignment, got {len(student_view)}")
expect("notes" not in student_view[0] and "created_by" not in student_view[0], "the student projection has no admin-internal KEY at all")
expect("consent" in student_view[0]["consent_note"], "every assignment says consent is still the candidate's to give")

r = client.post(f"/admin/scheduled-interviews/{schedule_id}/reschedule", json={"scheduled_for": "2099-03-01T10:00:00Z"}, headers=admin)
expect(r.status_code == 200 and r.json()["scheduled"]["scheduled_for"].startswith("2099-03-01"), f"reschedule moves the window ({r.text[:200]})")

r = client.post(f"/admin/scheduled-interviews/{schedule_id}/reschedule", json={"scheduled_for": "2099-03-08T10:00:00Z", "deadline": "2099-03-01T10:00:00Z"}, headers=admin)
expect(r.status_code == 400, "reschedule reuses the create validator's deadline rule")

r = client.post(f"/admin/scheduled-interviews/{schedule_id}/cancel", headers=admin)
expect(r.status_code == 200 and r.json()["scheduled"]["status"] == "cancelled", "cancel withdraws the assignment")

r = client.get("/me/scheduled-interviews", headers=student_headers)
expect(r.json()["scheduled"] == [], "a cancelled assignment disappears from the candidate's view entirely")

r = client.post("/admin/scheduled-interviews/no-such-id/cancel", headers=admin)
expect(r.status_code == 404, "cancelling an unknown assignment is a 404")

# a scheduled candidate shows as interview_scheduled in the directory
r = client.get("/admin/users", headers=admin)
other_row = next(x for x in r.json()["rows"] if x["user_id"] == other_id)
expect(other_row["status"] == "interview_scheduled", f"an open assignment wins over 'active', got {other_row['status']}")

# ----------------------------------------------------------------- archives

r = client.get("/admin/archives", headers=admin)
expect(r.status_code == 404, "archives report 404 when no archive store is configured")

# -------------------------------------------------------- internal MCP route

r = client.get("/internal/mcp/servers", headers=admin)
expect(r.status_code == 200 and "tool-telemetry" in r.json()["servers"], f"the MCP passthrough lists registered servers ({r.text[:200]})")

r = client.post(
    "/internal/mcp/call",
    json={"session_id": session_id, "server": "_dev", "method": "ping", "params": {"nonce": "hello"}},
    headers=admin,
)
expect(r.status_code == 200 and r.json()["ok"] is True, f"a dev-ping through the gateway succeeds ({r.text[:200]})")
expect("latencyMs" in r.json(), "the MCP envelope keeps its camelCase latencyMs")

r = client.post("/internal/mcp/call", json={"server": "_dev", "method": "ping"}, headers=admin)
expect(r.status_code == 400, "a call with no session_id is refused")

print("\nALL F9 SMOKE CHECKS PASSED")

"""Stage 13 gate — dynamic question synthesis and adaptive routing.

Six sections, in the order the machinery runs:

 1. the rolling snapshot (`interview_domain/routing.py`, `http/session_tracker.py`)
 2. the routing controller (`determine_next_node`)
 3. strict schema enforcement (`DynamicQuestionResponse` + the retry it triggers)
 4. the prompt (`question-agent/v6` — the fingerprint gate, and no baseline in it)
 5. selection (a routed topic reorders the plan and cannot overrun it)
 6. end to end, through the real gateway, with a model injected

Sections 1, 2, 4 and 5 need no provider at all — the routing decision is
arithmetic and the selection rules are deterministic, which is the point.
Sections 3 and 6 inject a model rather than calling one.

Run directly with the venv's python, not pytest — same convention as every
other smoke_stage*.py in this repo.
"""

from __future__ import annotations

import asyncio
import base64
import os

os.environ["NODE_ENV"] = "test"
os.environ["AUTH_TOKEN_SECRET"] = "x" * 32
os.environ["LLM_PROVIDER"] = "fixture"
os.environ["QUESTION_AGENT_LLM_PROVIDER"] = ""
os.environ["RESUME_SERVICE_LLM_PROVIDER"] = ""

from fastapi.testclient import TestClient  # noqa: E402
from pydantic import ValidationError  # noqa: E402

from app.agents.followup.server import _route, _with_routing  # noqa: E402
from app.agents.question.server import (  # noqa: E402
    SelectQuestionInput,
    _bankless_slot,
    _synthesize_question,
    select_next_question,
)
from app.gateway import CreateAppOptions, create_app  # noqa: E402
from app.http.session_tracker import SessionTracker  # noqa: E402
from app.interview_domain.question_bank import QUESTION_BANK  # noqa: E402
from app.interview_domain.routing import (  # noqa: E402
    ESCALATE_ABOVE,
    ROLLING_SCORE_ALPHA,
    SUPPORT_BELOW,
    InterviewSession,
    determine_next_node,
    exhausted_from,
    rebuilt_from,
    record_score,
)
from app.llm_client.prompt_registry import (  # noqa: E402
    ACTIVE_PROMPT_VERSION,
    PROMPT_FINGERPRINTS,
    PromptRegistry,
)
from app.llm_client.schemas import (  # noqa: E402
    LLM_SCHEMA_REFS,
    DynamicQuestionResponse,
    get_llm_schema,
    llm_json_schema,
)
from app.llm_client.structured_call import StructuredCallOptions, structured_call  # noqa: E402
from app.llm_client.tools import DYNAMIC_QUESTION_TOOL  # noqa: E402
from app.llm_client.types import StructuredCallError, ToolDefinition  # noqa: E402
from app.shared_types import TopicPlanEntry  # noqa: E402


def expect(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)
    print(f"OK: {msg}")


def section(title: str) -> None:
    print(f"\n--- {title} ---")


# ===========================================================================
section("1. the rolling snapshot")
# ===========================================================================

blank = InterviewSession(session_id="s1")
expect(blank.rolling_score is None and blank.last_score is None, "a session with nothing scored has no rolling score — not a zero")

first = record_score(blank, score=4.0, topic="databases", tier=2)
expect(first.rolling_score == 4.0, f"the first score seeds the EMA rather than being averaged against nothing, got {first.rolling_score}")
expect(blank.rolling_score is None, "record_score returns a copy and never mutates the snapshot it was given")

second = record_score(first, score=1.0, topic="databases", tier=2)
wanted = round(ROLLING_SCORE_ALPHA * 1.0 + (1 - ROLLING_SCORE_ALPHA) * 4.0, 4)
expect(second.rolling_score == wanted, f"the EMA weights the newest answer by alpha={ROLLING_SCORE_ALPHA}, got {second.rolling_score} wanted {wanted}")
expect(second.last_score == 1.0, "last_score is the single newest data point, distinct from the trajectory")
expect(second.rolling_score > 2.0, "one bad answer after a good one does not collapse the trajectory (an EMA, not a reset)")
expect(second.topic_scores["databases"] == [4.0, 1.0], "per-topic history accumulates oldest first")

replayed = rebuilt_from(
    session_id="s1",
    topic_counts={"databases": 2},
    topic_caps={"databases": 3},
    topic_scores={"databases": [4.0, 1.0]},
    topic_tier={"databases": 2},
    current_topic="databases",
    recent_scores=[4.0, 1.0],
)
expect(
    replayed.rolling_score == second.rolling_score,
    f"a snapshot rebuilt from persisted rows replays the same EMA a live one held ({replayed.rolling_score} vs {second.rolling_score})",
)
expect(replayed.exhausted_topics == [], "a topic under its cap is not exhausted")

capped = rebuilt_from(
    session_id="s1", topic_counts={"databases": 3}, topic_caps={"databases": 3}, topic_scores={}, topic_tier={}
)
expect(capped.exhausted_topics == ["databases"], "a topic at its cap is exhausted")
expect(exhausted_from({"a": 1}, {"a": 1, "b": 2}) == ["a"], "exhausted_from reads counts against caps and nothing else")

tracker = SessionTracker(store={})
tracker.record_answer_score("s2", score=5.0, topic="databases", tier=1)
tracker.record_answer_score("s2", score=5.0, topic="databases", tier=1)
snap = tracker.snapshot(
    "s2",
    topic_counts={"databases": 2},
    topic_caps={"databases": 2, "security": 2},
    topic_scores={"databases": [5.0, 5.0]},
    topic_tier={"databases": 1},
    current_topic="databases",
)
expect(snap.rolling_score == 5.0, "snapshot() carries the running EMA forward rather than recomputing it")
expect(snap.exhausted_topics == ["databases"], "snapshot() refreshes the caps from what the caller just read out of the stores")
expect(snap.answers_scored == 2, "the scored-answer count survives a reconciliation")
tracker.drop("s2")
expect(tracker.get("s2") is None and tracker.tracked() == [], "drop forgets a session, and dropping an untracked one is safe")


# ===========================================================================
section("2. the routing controller")
# ===========================================================================

PLAN = ["databases", "system design", "security", "behavioral: ownership"]


def snapshot(**kw) -> InterviewSession:
    return InterviewSession(session_id="r", **kw)


node = determine_next_node(snapshot(), available_topics=PLAN, topic_counts={})
expect(node.directive is None, "with nothing scored yet, routing offers no directive")
expect(node.topic in PLAN, "with nothing scored yet, routing still proposes a topic from the plan")

strong = snapshot(current_topic="databases", current_tier=1, topic_scores={"databases": [4.5]}, last_score=4.5)
node = determine_next_node(strong, available_topics=PLAN, topic_counts={"databases": 1})
expect(node.tier == 2, f"a score above {ESCALATE_ABOVE} steps the tier up, got {node.tier}")
expect(node.topic != "databases", f"the strong answer's topic is not the least covered, so routing moves on, got {node.topic}")
expect(node.directive == "pivot" and not node.lateral_pivot, "moving on after a strong answer is a pivot, and is not a lateral one")
expect(str(4.5) in node.rationale or "4.5" in node.rationale, f"the rationale names the score that produced it: {node.rationale}")

# The worked example from the goal: aced one area, untouched in another.
node = determine_next_node(
    snapshot(current_topic="cloud and infrastructure", current_tier=2, last_score=4.8),
    available_topics=["cloud and infrastructure", "data engineering"],
    topic_counts={"cloud and infrastructure": 2, "data engineering": 0},
)
expect(
    node.topic == "data engineering" and node.tier == 3,
    f"acing a well-covered area queues the untouched one, a tier higher, got {node.topic} at tier {node.tier}",
)

still_least_covered = snapshot(current_topic="databases", current_tier=1, last_score=4.5)
node = determine_next_node(still_least_covered, available_topics=PLAN, topic_counts={"system design": 2, "security": 2, "behavioral: ownership": 2})
expect(node.topic == "databases" and node.directive == "escalate", "when the strong topic IS the least covered, routing stays on it and escalates")

weak = snapshot(current_topic="databases", current_tier=2, topic_scores={"databases": [2.0]}, last_score=2.0)
node = determine_next_node(weak, available_topics=PLAN, topic_counts={"databases": 1})
expect(node.topic == "databases", "one weak answer keeps the topic — the candidate gets their recovery question")
expect(node.tier == 1, f"a score below {SUPPORT_BELOW} steps the tier down, got {node.tier}")
expect(node.directive == "support" and not node.lateral_pivot, "one weak answer is support, not a pivot")

stuck = snapshot(current_topic="databases", current_tier=2, topic_scores={"databases": [1.5, 2.0]}, last_score=2.0)
node = determine_next_node(stuck, available_topics=PLAN, topic_counts={"databases": 2})
expect(node.lateral_pivot and node.topic != "databases", f"two unrecovered answers on a topic pivot laterally off it, got {node.topic}")
expect(node.topic in ("system design", "security"), f"the lateral topic is technical, like the one it moved off, got {node.topic}")
expect(node.tier == 1, "a lateral pivot still steps the tier down — it is a move sideways, not a reprieve")

node = determine_next_node(stuck, available_topics=PLAN, topic_counts={})
expect(node.topic != "databases", "the lateral pivot is unaffected by coverage counts when the stuck topic is excluded")

node = determine_next_node(
    snapshot(current_topic="databases", current_tier=2, exhausted_topics=["system design", "security"], topic_scores={"databases": [1.0, 1.0]}, last_score=1.0),
    available_topics=PLAN,
    topic_counts={},
)
expect(node.topic == "behavioral: ownership", f"an exhausted topic is never proposed, even as the lateral escape, got {node.topic}")

node = determine_next_node(
    snapshot(current_topic="databases", current_tier=2, exhausted_topics=PLAN),
    available_topics=PLAN,
    topic_counts={},
)
expect(node.topic is None and node.directive is None, "with every topic capped, routing proposes nothing and leaves the last-resort path alone")

node = determine_next_node(snapshot(current_topic="databases", current_tier=2, last_score=3.0), available_topics=PLAN, topic_counts={})
expect(node.directive is None, "a score in the middle band produces no directive — routing has no opinion there")
expect(node.tier == 2, "a score in the middle band holds the tier")

for score in (5.0, 0.0):
    for tier in (1, 3):
        n = determine_next_node(snapshot(current_topic="databases", current_tier=tier, last_score=score), available_topics=PLAN, topic_counts={})
        expect(1 <= n.tier <= 3, f"the proposed tier never leaves 1-3 (score {score}, tier {tier} -> {n.tier})")


# --- the Follow-up Agent's half: routing annotates, and changes one thing

expect(_route({"topic": "databases"}, None) is None, "no routing_context means no proposal — every pre-Stage-13 caller is unaffected")
expect(
    _route({"topic": "databases", "routing_context": {"available_topics": []}}, None) is None,
    "a routing_context with no topics to choose between produces no proposal either",
)

from app.agents.followup.server import AnswerScore  # noqa: E402

WEAK = AnswerScore(rubric_id="technical_v2", value=1.0, rationale="thin", evidence_spans=[])
stuck_context = {
    "topic": "databases",
    "tier": 2,
    "routing_context": {
        "available_topics": PLAN,
        "exhausted_topics": [],
        "topic_counts": {"databases": 2},
        # One prior weak answer; this turn's weak score is appended by `_route`
        # itself, which is what makes the streak two.
        "topic_scores": {"databases": [1.5]},
        "topic_tier": {"databases": 2},
    },
}
stuck_node = _route(stuck_context, WEAK)
expect(stuck_node is not None and stuck_node.lateral_pivot, "this turn's score is folded in before routing, so the second weak answer is seen as a streak straight away")

base_support = {
    "system_directive": "support",
    "transition_style": "supportive_reframe",
    "target_concept_id_for_next_prompt": None,
    "synthesized_framing_strategy": "stay on this topic",
    "generated_follow_up_prompt": "Let's come at that from a different angle...",
}
routed_support = _with_routing(dict(base_support), stuck_node)
expect(routed_support["system_directive"] == "pivot", "a candidate stuck on a topic across two answers is routed off it, not asked a third question on it")
expect(routed_support["transition_style"] == "topic_shift", "and the transition style follows the directive rather than contradicting it")
expect(
    routed_support["generated_follow_up_prompt"] == base_support["generated_follow_up_prompt"],
    "the supportive follow-up for THIS turn survives untouched — routing decides where the interview goes next, not what it says now",
)
expect(
    "difficulty" not in routed_support["synthesized_framing_strategy"].split("Do not")[0],
    "the reframing strategy tells the model to open the new topic cleanly, without narrating the candidate's difficulty",
)

one_weak = _route(
    {**stuck_context, "routing_context": {**stuck_context["routing_context"], "topic_scores": {}}},
    WEAK,
)
expect(one_weak.directive == "support" and not one_weak.lateral_pivot, "one weak answer is still support, and `_with_routing` leaves that directive alone")
expect(_with_routing(dict(base_support), one_weak)["system_directive"] == "support", "routing only overrides a directive when the candidate is stuck, never merely when they answered badly once")

annotated = _with_routing({"system_directive": "drill_down", "transition_style": "same_topic"}, stuck_node)
expect(annotated["system_directive"] == "drill_down", "routing never rewrites a drill_down — a gap the detector found outranks a score band")
expect(annotated["next_topic"] == stuck_node.topic, "but it still annotates it, because the Question Agent only consults the topic where the directive leaves the choice open")


# ===========================================================================
section("3. strict schema enforcement")
# ===========================================================================

GOOD = {
    "reasoning": "The profile names a Postgres billing schema, so the scenario builds on that rather than a generic store.",
    "topic": "databases",
    "tier": 2,
    "question_text": "Your billing service's Postgres schema started as one table per tenant. What would you change first as tenant count grew?",
    "expected_signals": ["names a concrete schema change", "explains the trade-off"],
    "reference_answer": "A strong answer names a specific schema change, the constraint that forced it, and what it cost elsewhere.",
    "grounding_rationale": {"value": "The candidate owned a Postgres schema.", "evidence": "Owned the Postgres schema design for the billing service."},
}
CONSTRAINTS = {"question_constraints": {"topic": "databases", "tier": 2}}

parsed = DynamicQuestionResponse.model_validate(GOOD, context=CONSTRAINTS)
expect(parsed.topic == "databases", "a generation matching its slot validates")

DynamicQuestionResponse.model_validate({**GOOD, "topic": "machine learning"})
expect(True, "with no constraints supplied, no constraint is checked — an unconstrained caller is not silently policed")

for bad, why in (
    ({**GOOD, "topic": "machine learning"}, "a generation on a different topic"),
    ({**GOOD, "tier": 3}, "a generation at a different tier"),
    ({**GOOD, "question_text": "What did you build? And how did you test it?"}, "a generation that asked two questions"),
):
    try:
        DynamicQuestionResponse.model_validate(bad, context=CONSTRAINTS)
        raise AssertionError(f"{why} should have been rejected")
    except ValidationError:
        expect(True, f"{why} is rejected by Pydantic before it can reach a candidate")

entry = get_llm_schema(LLM_SCHEMA_REFS["dynamic_question"])
expect(entry is not None and entry.schema is DynamicQuestionResponse, "the dynamic-question schema is registered under its own ref")
expect(entry.required_grounded_paths == ("grounding_rationale",), "an ungrounded rationale rejects the whole generation, exactly as `question`'s does")
props = llm_json_schema(LLM_SCHEMA_REFS["dynamic_question"])["properties"]
for field in ("question_text", "expected_signals", "grounding_rationale"):
    expect(field in props, f"the JSON Schema handed to the provider requires `{field}`")


class ScriptedModel:
    """Returns each scripted response in turn. `provider` is what
    `structured_call` reports; the responses are what a provider would."""

    provider = "groq"

    def __init__(self, responses: list[dict]) -> None:
        self._responses = list(responses)
        self.calls: list[str | None] = []

    async def invoke(self, request):  # noqa: ANN001
        self.calls.append(request.correction)
        return self._responses.pop(0) if self._responses else {}


TOOL = ToolDefinition(
    name=DYNAMIC_QUESTION_TOOL["name"],
    description="gate",
    schema=DynamicQuestionResponse,
    prompt_version=DYNAMIC_QUESTION_TOOL["prompt_version"],
    schema_ref=DYNAMIC_QUESTION_TOOL["schema_ref"],
    required_grounded_paths=DYNAMIC_QUESTION_TOOL["required_grounded_paths"],
)
PROMPT_INPUT = {
    "constraints": {"topic": "databases", "tier": 2, "type": "technical", "difficulty": 3, "expected_signals": ["a concrete change"]},
    "candidate": {"role": "backend engineer", "profile_lines": ["Owned the Postgres schema design for the billing service."], "topic_plan": []},
}

drifting = ScriptedModel([{**GOOD, "topic": "machine learning"}, GOOD])
result = asyncio.run(
    structured_call(
        TOOL,
        PROMPT_INPUT,
        StructuredCallOptions(model=drifting, retries=2, validation_context=CONSTRAINTS, source_documents=[]),
    )
)
expect(result.output is not None and result.output["topic"] == "databases", "a hallucinated topic is retried automatically and the second attempt is what the caller sees")
expect(len(drifting.calls) == 2 and drifting.calls[1] and "databases" in drifting.calls[1], f"the retry carries the violation back as the corrective message: {drifting.calls[1]}")

never = ScriptedModel([{**GOOD, "topic": "machine learning"}] * 3)
try:
    asyncio.run(
        structured_call(TOOL, PROMPT_INPUT, StructuredCallOptions(model=never, retries=2, validation_context=CONSTRAINTS))
    )
    raise AssertionError("a generation that never satisfies the constraint should raise, not be coerced into shape")
except StructuredCallError:
    expect(True, "a generation that never satisfies the constraint raises, and the agent falls back rather than shipping it")


# ===========================================================================
section("4. question-agent/v6 — the prompt with no baseline")
# ===========================================================================

expect(PromptRegistry.fingerprints() == PROMPT_FINGERPRINTS, "the fingerprint gate passes: v1-v5 unmodified, v6 added")
expect(ACTIVE_PROMPT_VERSION["question_agent_dynamic"] == "question-agent/v6", "the synthesis job is pinned to v6")
expect(ACTIVE_PROMPT_VERSION["question_agent"] == "question-agent/v5", "the bank-rewrite job is still pinned to v5 — the two are separate jobs, not versions of each other")

v5 = PromptRegistry.get("question-agent/v5")
v6 = PromptRegistry.get("question-agent/v6")
expect("baseline" in v5.system.lower(), "v5 does instruct the model to sharpen a supplied baseline (the thing being removed)")
expect("baseline question" not in v6.system.lower().replace("no baseline question", ""), "v6's system text asks for no baseline question")
expect("NO baseline" in v6.system, "v6 says outright that there is no baseline")
expect("expected_signals" in v6.system, "v6 points the model at the expected signals as the specification")
for rule in ("soul.md", "VERBATIM", "one question"):
    expect(rule in v6.system, f"v6 keeps the pre-existing constraint: {rule}")

rendered = v6.render(PROMPT_INPUT)
expect("Topic: databases | Tier: 2" in rendered, f"the rendered request headlines the routing constraints: {rendered.splitlines()[0]}")
expect("a concrete change" in rendered, "the expected signals reach the prompt")
expect(
    rendered.lower().replace("there is no baseline question.", "").count("baseline") == 0,
    "the only mention of a baseline in the rendered prompt is the sentence saying there is not one",
)


class CapturingTools:
    """Stands in for the MCP tool client, recording what the agent sent."""

    def __init__(self, response=None) -> None:
        self.calls: list[tuple[str, str, dict]] = []
        self._response = response

    async def call(self, server: str, method: str, params: dict):  # noqa: ANN001
        self.calls.append((server, method, params))
        if self._response is None:
            raise RuntimeError("no provider")
        return self._response


slot_source = next(q for q in QUESTION_BANK if q.topic == "databases")
from app.agents.question.server import _slot_from_bank  # noqa: E402

captured = CapturingTools()
asyncio.run(
    _synthesize_question(
        captured,
        session_id="s",
        role="backend engineer",
        topic_plan=[TopicPlanEntry(topic="databases", max_questions=2, source="resume")],
        candidate_profile_lines=["Owned the Postgres schema design for the billing service."],
        slot=_slot_from_bank(slot_source),
    )
)
sent = captured.calls[0][2]
expect(sent["prompt_version"] == "question-agent/v6", "the synthesis call is stamped with v6")
expect("baseline" not in str(sent["input"]).lower(), "the synthesis payload contains no baseline anywhere in it")
expect(slot_source.text not in str(sent["input"]), "the bank question's own text is not sent — that is the decoupling")
expect(list(sent["input"]["constraints"]["expected_signals"]) == list(slot_source.expected_signals[:6]), "the bank entry's signals ARE sent, which is what it is now used for")
expect(sent["validation_context"]["question_constraints"] == {"topic": "databases", "tier": slot_source.tier}, "the slot travels as validation context, so drift fails rather than reads badly")
expect(sent["retries"] == 2, "the synthesis call budgets two retries — a malformed response and a constraint violation are different failures")


# ===========================================================================
section("5. selection — a routed topic reorders, and nothing more")
# ===========================================================================

PLAN_ENTRIES = [
    TopicPlanEntry(topic="databases", max_questions=2, source="resume"),
    TopicPlanEntry(topic="system design", max_questions=2, source="resume"),
    TopicPlanEntry(topic="security", max_questions=2, source="role_requirement"),
]


def select(**kw):
    base = dict(
        session_id="s",
        topic_plan=PLAN_ENTRIES,
        topic_counts={},
        asked_question_ids=[],
        difficulty_target=3,
        topic_tier={},
        topic_scores={},
    )
    base.update(kw)
    return select_next_question(SelectQuestionInput(**base))


plain = select()
routed = select(routed_topic="security")
expect(routed.question.topic == "security", f"a routed topic is brought to the front of selection, got {routed.question.topic}")
expect(plain.question.topic != "security", "and that is a real change — the default ordering picks something else")
expect(routed.followed_directive == "route", "a pick that came from routing alone is reported as `route`, so it lands in telemetry")

capped_out = select(routed_topic="security", topic_counts={"security": 2})
expect(capped_out.question.topic != "security", "a routed topic at its cap is refused — a proposal never overruns a quota")

stay_wins = select(routed_topic="security", directive="drill_down", directive_topic="databases")
expect(stay_wins.question.topic == "databases", "a stay directive keeps its own topic: a routing proposal cannot cancel a gap the detector found")

pivot_routes = select(routed_topic="security", directive="pivot", directive_topic="databases")
expect(pivot_routes.question.topic == "security", "a pivot directive hands the choice to routing, which is the whole point of naming a topic")

expect(plain.slot is not None and plain.slot.bank_question is not None, "an ordinary slot is still backed by a bank entry")
expect(len(plain.slot.expected_signals) > 0, "every slot carries the signals a strong answer has to demonstrate")

all_db = [q.id for q in QUESTION_BANK if q.topic == "databases"]
one_topic = [TopicPlanEntry(topic="databases", max_questions=9, source="resume")]
try:
    select_next_question(
        SelectQuestionInput(
            session_id="s", topic_plan=one_topic, topic_counts={}, asked_question_ids=all_db,
            difficulty_target=3, topic_tier={}, topic_scores={}, allow_synthesis=False,
        )
    )
    raise AssertionError("with the bank spent and synthesis off, selection should refuse")
except Exception as err:  # noqa: BLE001
    expect(type(err).__name__ == "NoQuestionsLeft", f"with the bank spent and synthesis off, selection refuses exactly as it did before this stage ({type(err).__name__})")

with_synthesis = select_next_question(
    SelectQuestionInput(
        session_id="s", topic_plan=one_topic, topic_counts={}, asked_question_ids=all_db,
        difficulty_target=3, topic_tier={}, topic_scores={}, allow_synthesis=True,
    )
)
expect(with_synthesis.slot.bank_question is None, "with the bank spent and synthesis on, a bank-less slot is produced instead")
expect(with_synthesis.question.text == "", "a bank-less slot carries no text — the scenario is the model's to write")
expect(with_synthesis.question.bank_id.startswith("synth:"), f"a bank-less slot gets its own id namespace, got {with_synthesis.question.bank_id}")
expect(len(with_synthesis.slot.expected_signals) > 0, "a bank-less slot still carries a signal specification")

bankless = _bankless_slot("machine learning", 3)
expect(bankless is not None and bankless.difficulty == 4, f"a bank-less slot keeps difficulty in lockstep with tier, got {bankless.difficulty}")


# ===========================================================================
section("6. end to end, with a model injected")
# ===========================================================================


class SynthesisModel:
    """Answers the dynamic-question call for real and defers everything else
    to the deterministic fixture, so this run exercises the synthesis path
    without inventing behaviour for the other five calls."""

    provider = "groq"

    def __init__(self) -> None:
        self.synthesized = 0

    async def invoke(self, request):  # noqa: ANN001
        if request.schema_ref != LLM_SCHEMA_REFS["dynamic_question"]:
            from app.llm_client.fixture_model import fixture_response

            return fixture_response(request)

        constraints = (request.input or {}).get("constraints") or {}
        evidence = next((doc.splitlines()[0] for doc in request.source_documents if doc.strip()), constraints.get("topic", ""))
        self.synthesized += 1
        return {
            "reasoning": f"Building a tier-{constraints.get('tier')} scenario on {constraints.get('topic')} from the candidate's own work.",
            "topic": constraints.get("topic", ""),
            "tier": constraints.get("tier", 1),
            "question_text": (
                f"[synthesized] Walk me through a {constraints.get('topic')} decision you owned, and what it cost you elsewhere."
            ),
            "expected_signals": list(constraints.get("expected_signals") or ["a concrete decision"])[:6],
            "reference_answer": "A strong answer names one concrete decision, the constraint behind it, and what it traded away.",
            "grounding_rationale": {"value": f"{constraints.get('topic')} is on this session's plan.", "evidence": evidence},
        }


model = SynthesisModel()
app = create_app(CreateAppOptions(llm_model=model))
client = TestClient(app)

r = client.post("/auth/register", json={"email": "stage13-student@example.com", "passcode": "hunter22"})
headers = {"Authorization": f"Bearer {r.json()['token']}"}

r = client.post(
    "/sessions",
    json={"role": "backend engineer", "job_description": "distributed systems and databases", "question_budget": 3},
    headers=headers,
)
session_id = r.json()["session_id"]
for state in ("CONFIG", "TELEMETRY_CHECK"):
    client.post(f"/sessions/{session_id}/advance", json={"to": state}, headers=headers)

RESUME_TEXT = """
Jane Doe

Experience
Senior Backend Engineer at Acme Corp, 2019 - present
Led the migration to a distributed microservices architecture on Kubernetes.
Owned the Postgres schema design for the billing service.

Skills
Python, Kubernetes, Postgres, Kafka, Docker

Education
B.S. Computer Science, State University
""".strip()

r = client.post(
    f"/sessions/{session_id}/resume",
    json={"filename": "resume.txt", "content_type": "text/plain", "data_base64": base64.b64encode(RESUME_TEXT.encode()).decode()},
    headers=headers,
)
expect(r.status_code == 201, f"resume upload succeeds ({r.text})")
client.post(f"/sessions/{session_id}/telemetry-check", json={"mic_ok": True, "speaker_ok": True}, headers=headers)
r = client.post(f"/sessions/{session_id}/begin", headers=headers)
expect(r.json()["state"] == "QUESTION_LOOP", "session enters QUESTION_LOOP")

STRONG = (
    "I led the migration of our billing service to a distributed microservices architecture on Kubernetes "
    "because the monolith couldn't scale past 500 requests per second. We considered staying monolithic but "
    "rejected it since the billing team needed independent deploys. As a result, deploy frequency went from "
    "weekly to daily and p99 latency dropped by 40%."
)

BANK_TEXTS = {q.text for q in QUESTION_BANK}
content_questions: list[dict] = []
routing_seen: list[dict] = []

for _turn in range(1, 7):
    r = client.get(f"/sessions/{session_id}/questions/next", headers=headers)
    body = r.json()
    if body["done"]:
        break
    question = body["question"]
    if question["topic"] != "introduction":
        content_questions.append(question)
    r = client.post(f"/sessions/{session_id}/answers", json={"question_id": question["id"], "transcript": STRONG}, headers=headers)
    expect(r.status_code == 201, f"answer submitted ({r.text})")
    # The REST route reports the directive as a bare string and the full
    # generator inside `live_session_state` — the routing fields live there.
    action = ((r.json().get("live_session_state") or {}).get("next_action_generator")) or {}
    if action.get("routing_rationale"):
        routing_seen.append(action)

expect(len(content_questions) == 3, f"the full question budget was served, got {len(content_questions)}")
expect(model.synthesized >= 3, f"every content question went through the synthesis path, got {model.synthesized}")
expect(
    all(q["text"].startswith("[synthesized]") for q in content_questions),
    "every content question is the synthesized scenario, not a bank entry",
)
expect(
    not any(q["text"] in BANK_TEXTS for q in content_questions),
    "no question served in this session is a verbatim bank question",
)
expect(len(routing_seen) >= 1, f"the routing decision reaches the client on the answer that produced it, got {len(routing_seen)}")
first = routing_seen[0]
expect(first.get("next_topic") is not None, f"the directive names where the interview goes next: {first}")
expect(isinstance(first.get("next_tier"), int), f"the directive names the tier it proposes: {first}")
expect(
    first["next_topic"] != "introduction",
    "the fixed opener is never proposed as a next topic — it is not a topic the interview routes between",
)

r = client.get(f"/sessions/{session_id}/transcript", headers=headers)
if r.status_code == 200:
    expect(r.json() is not None, "the transcript is still readable after a fully synthesized session")

print("\nStage 13 (dynamic question synthesis + adaptive routing): all checks passed.")

"""Manual smoke test for F7's live WebSocket channel."""

from __future__ import annotations

import os

os.environ["NODE_ENV"] = "test"
os.environ["AUTH_TOKEN_SECRET"] = "x" * 32

from fastapi.testclient import TestClient  # noqa: E402

from app.gateway import CreateAppOptions, create_app  # noqa: E402
from app.tools.speech_service.fixture_provider import FixtureSpeechProvider  # noqa: E402
from app.tools.speech_service.server import ProviderChoice  # noqa: E402

app = create_app(CreateAppOptions(speech_provider_choice=ProviderChoice(FixtureSpeechProvider(), "pinned for test")))
client = TestClient(app)


def expect(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)
    print(f"OK: {msg}")


r = client.post("/auth/register", json={"email": "ws-student@example.com", "passcode": "hunter22"})
token = r.json()["token"]
headers = {"Authorization": f"Bearer {token}"}

r = client.post("/sessions", json={"role": "backend engineer", "question_budget": 2}, headers=headers)
session_id = r.json()["session_id"]

for state in ("CONFIG", "TELEMETRY_CHECK"):
    client.post(f"/sessions/{session_id}/advance", json={"to": state}, headers=headers)
client.post(f"/sessions/{session_id}/telemetry-check", json={"mic_ok": True, "speaker_ok": True}, headers=headers)
client.post(f"/sessions/{session_id}/begin", headers=headers)

with client.websocket_connect(f"/sessions/{session_id}/live?token={token}") as ws:
    connected = ws.receive_json()
    expect(connected["type"] == "connected" and connected["state"] == "QUESTION_LOOP", f"connected event received: {connected}")

    ws.send_json({"type": "next_question"})
    q_event = ws.receive_json()
    expect(q_event["type"] == "question", f"question event received: {q_event}")
    expect(q_event["audio_url"] is not None, "question audio was synthesised over the socket path too")
    question_id = q_event["id"]

    ws.send_json({"type": "submit_answer_text", "question_id": question_id, "transcript": "I led the redesign of our checkout flow because conversion had dropped, and after shipping it we saw a fifteen percent lift in completed orders."})

    # (HUMAN_INTERACTION_FLOW.md §1) The micro-acknowledgment arrives FIRST, on
    # its own frame, before the scored result. That ordering is the feature:
    # the candidate hears something while the score and the follow-up decision
    # are still being computed. Asserting on the order, not just the presence,
    # is what would catch the ack being folded back into the answer response.
    ack_event = ws.receive_json()
    expect(ack_event["type"] == "acknowledgment", f"a micro-acknowledgment is spoken before the scored result: {ack_event}")
    expect(bool(ack_event.get("text")), f"the acknowledgment carries the line that was spoken: {ack_event}")

    answer_event = ws.receive_json()
    expect(answer_event["type"] in ("question", "follow_up"), f"answer produces a question or follow_up event: {answer_event}")
    if answer_event["type"] == "question":
        expect(answer_event["evaluation"] is not None, f"substantive answer gets scored over the socket: {answer_event}")

    # (§3) A request to repeat is not an answer. It must not produce an
    # `answered` event, must not create a second answer for this question, and
    # must leave the same question on the table.
    ws.send_json({"type": "submit_answer_text", "question_id": question_id, "transcript": "Sorry, can you repeat that?"})
    meta_event = ws.receive_json()
    expect(meta_event["type"] == "clarification", f"a repeat request produces a clarification, not a scored answer: {meta_event}")
    expect(meta_event["question_id"] == question_id, f"the clarification points back at the same unanswered question: {meta_event}")

    ws.send_json({"type": "unknown_message_type"})
    err_event = ws.receive_json()
    expect(err_event["type"] == "error" and err_event["code"] == "unknown_type", f"unknown message type is reported as an error: {err_event}")

    ws.send_json({"type": "end_session"})
    complete_event = ws.receive_json()
    expect(complete_event["type"] == "session_complete", f"end_session produces session_complete: {complete_event}")

print("\nALL F7 LIVE-CHANNEL SMOKE CHECKS PASSED")

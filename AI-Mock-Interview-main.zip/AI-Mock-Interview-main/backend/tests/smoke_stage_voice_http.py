"""Manual smoke test for F7's HTTP surface — spoken answers, audio serving,
paste/focus events, wrap-up. Pins the fixture speech provider (matching the
TS test suite's own pattern) so low-confidence behaviour is deterministic
without needing a bad real recording."""

from __future__ import annotations

import base64
import os

os.environ["NODE_ENV"] = "test"
os.environ["AUTH_TOKEN_SECRET"] = "x" * 32

from fastapi.testclient import TestClient  # noqa: E402

from app.gateway import CreateAppOptions, create_app  # noqa: E402
from app.tools.speech_service.fixture_provider import FixtureSpeechProvider, attenuate  # noqa: E402
from app.tools.speech_service.server import ProviderChoice  # noqa: E402

app = create_app(CreateAppOptions(speech_provider_choice=ProviderChoice(FixtureSpeechProvider(), "pinned for test")))
client = TestClient(app)


def expect(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)
    print(f"OK: {msg}")


r = client.post("/auth/register", json={"email": "voice-student@example.com", "passcode": "hunter22"})
headers = {"Authorization": f"Bearer {r.json()['token']}"}

r = client.post("/sessions", json={"role": "backend engineer", "question_budget": 2}, headers=headers)
session_id = r.json()["session_id"]

for state in ("CONFIG", "TELEMETRY_CHECK"):
    client.post(f"/sessions/{session_id}/advance", json={"to": state}, headers=headers)
client.post(f"/sessions/{session_id}/telemetry-check", json={"mic_ok": True, "speaker_ok": True}, headers=headers)

r = client.post(f"/sessions/{session_id}/begin", headers=headers)
expect(r.status_code == 200, f"begin interview ({r.text})")

r = client.get(f"/sessions/{session_id}/questions/next", headers=headers)
question = r.json()["question"]
expect(question["audio_url"] is not None, f"question audio was synthesised (fixture provider): {question}")
audio_url = question["audio_url"]
expect(audio_url.startswith(f"/audio/{session_id}/"), f"audio_url is scoped to this session: {audio_url}")

# GET the synthesised audio back through the HTTP route
ref_path = audio_url[len("/audio/") :]
r = client.get(f"/sessions/{session_id}/audio/{ref_path}", headers=headers)
expect(r.status_code == 200 and r.headers["content-type"] == "audio/wav", f"question audio is servable ({r.status_code})")
expect(r.content[:4] == b"RIFF", "served audio is a real WAV")

# a different candidate cannot fetch this session's audio
r2 = client.post("/auth/register", json={"email": "voice-other@example.com", "passcode": "hunter22"})
other_headers = {"Authorization": f"Bearer {r2.json()['token']}"}
r = client.get(f"/sessions/{session_id}/audio/{ref_path}", headers=other_headers)
expect(r.status_code in (403, 404), f"a different candidate cannot fetch this session's audio ({r.status_code})")

# synthesize a clean answer clip and submit it as spoken audio
clean = FixtureSpeechProvider()
import asyncio

synthesized = asyncio.run(clean.synthesize("I led the redesign of our checkout flow and cut cart abandonment by fifteen percent."))
r = client.post(
    f"/sessions/{session_id}/answers/audio",
    json={"question_id": question["id"], "audio_base64": base64.b64encode(synthesized.audio).decode(), "content_type": "audio/wav"},
    headers=headers,
)
expect(r.status_code == 201, f"clean spoken answer is accepted ({r.status_code}: {r.text})")
abody = r.json()
expect(abody["accepted"] is True, "answer marked accepted")
expect(abody["transcript"] == "I led the redesign of our checkout flow and cut cart abandonment by fifteen percent.", f"transcript round-trips verbatim: {abody['transcript']!r}")

# a quiet (low-confidence) recording must be refused, not silently scored
r = client.get(f"/sessions/{session_id}/questions/next", headers=headers)
question2 = r.json()["question"]
quiet_synth = asyncio.run(clean.synthesize("This should not be scored."))
quiet_audio = attenuate(quiet_synth.audio, 0.05)
r = client.post(
    f"/sessions/{session_id}/answers/audio",
    json={"question_id": question2["id"], "audio_base64": base64.b64encode(quiet_audio).decode(), "content_type": "audio/wav"},
    headers=headers,
)
expect(r.status_code == 202, f"low-confidence recording gets 202 retry, not scored ({r.status_code}: {r.text})")
expect(r.json()["accepted"] is False and r.json()["draft_transcript"] is not None, "retry response carries a draft transcript for the candidate to correct")

# paste + focus events (consent-independent at the route layer; the tool itself gates on consent)
r = client.post(f"/sessions/{session_id}/paste-events", json={"timestamp": "2026-01-01T00:00:00Z"}, headers=headers)
expect(r.status_code == 200, f"paste event route responds (no consent => not recorded, 200 not 201: got {r.status_code})")
expect(r.json()["recorded"] is False, "paste not recorded without consent/clipboard monitor tool")

r = client.post(f"/sessions/{session_id}/focus-events", json={"timestamp": "2026-01-01T00:00:00Z"}, headers=headers)
expect(r.status_code == 200, f"focus event route responds ({r.status_code})")

print("\nALL F7 HTTP SMOKE CHECKS PASSED")

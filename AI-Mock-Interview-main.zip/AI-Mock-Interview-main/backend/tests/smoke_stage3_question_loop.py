"""Manual smoke test for F6 — Eval, Question, Follow-up, Memory, Time
Tracking, wired into a full text-only QUESTION_LOOP (Stage 2 parity)."""

from __future__ import annotations

import base64
import os

os.environ["NODE_ENV"] = "test"
os.environ["AUTH_TOKEN_SECRET"] = "x" * 32

from fastapi.testclient import TestClient  # noqa: E402

from app.gateway import create_app  # noqa: E402

app = create_app()
client = TestClient(app)


def expect(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)
    print(f"OK: {msg}")


r = client.post("/auth/register", json={"email": "loop-student@example.com", "passcode": "hunter22"})
token = r.json()["token"]
headers = {"Authorization": f"Bearer {token}"}

r = client.post("/sessions", json={"role": "backend engineer", "job_description": "distributed systems and databases", "question_budget": 3}, headers=headers)
session_id = r.json()["session_id"]

for state in ("CONFIG", "TELEMETRY_CHECK"):
    r = client.post(f"/sessions/{session_id}/advance", json={"to": state}, headers=headers)
    expect(r.status_code == 200, f"advance to {state}")

RESUME_TEXT = """
Jane Doe

Experience
Senior Backend Engineer at Acme Corp, 2019 - present
Led the migration to a distributed microservices architecture on Kubernetes.
Owned the Postgres schema design for the billing service.

Skills
Python, Kubernetes, Postgres, Kafka, Docker

Education
B.S. Computer Science, State University
""".strip()

r = client.post(
    f"/sessions/{session_id}/resume",
    json={"filename": "resume.txt", "content_type": "text/plain", "data_base64": base64.b64encode(RESUME_TEXT.encode()).decode()},
    headers=headers,
)
expect(r.status_code == 201, f"resume upload succeeds ({r.text})")

r = client.post(f"/sessions/{session_id}/telemetry-check", json={"mic_ok": True, "speaker_ok": True}, headers=headers)
expect(r.status_code == 200, "telemetry check passed")

r = client.post(f"/sessions/{session_id}/begin", headers=headers)
expect(r.status_code == 200, f"begin interview succeeds ({r.text})")
body = r.json()
expect(body["state"] == "QUESTION_LOOP", f"session enters QUESTION_LOOP, got {body['state']}")
expect(len(body["topic_plan"]) > 0, "a topic plan was built")
expect(
    any(e["topic"] == "introduction" and e["maxQuestions"] == 1 for e in body["topic_plan"]),
    "topic plan has a fixed introduction slot with quota 1",
)
topic_plan_total = sum(e["maxQuestions"] for e in body["topic_plan"])
print(f"  topic_plan capacity={topic_plan_total}, budget=3")

# drive the full question budget (3 questions) with substantive typed answers
ANSWER = (
    "I led the migration of our billing service to a distributed microservices architecture on Kubernetes "
    "because the monolith couldn't scale past 500 requests per second. We considered staying monolithic but "
    "rejected it since the billing team needed independent deploys. As a result, deploy frequency went from "
    "weekly to daily and p99 latency dropped by 40%."
)

asked_count = 0
seen_topics = set()
follow_up_seen = False
quota_override_seen = False
intro_seen = False

for turn in range(1, 7):  # safety cap; budget is 3 content questions + 1 fixed intro turn
    r = client.get(f"/sessions/{session_id}/questions/next", headers=headers)
    expect(r.status_code == 200, f"turn {turn}: get next question ({r.text})")
    qbody = r.json()
    if qbody["done"]:
        expect(qbody["asked_count"] == 3, f"loop ends after budget of 3 CONTENT questions, got {qbody['asked_count']}")
        break

    question = qbody["question"]
    seen_topics.add(question["topic"])
    is_intro = question["topic"] == "introduction"
    if is_intro:
        intro_seen = True
        expect(turn == 1, "the introduction question is always asked first")
        expect(
            question["text"] == "Tell me about yourself — walk me through your background and what's brought you here today.",
            "the introduction question uses the fixed opener text, not a bank/LLM-generated one",
        )
    else:
        asked_count += 1
    expect(isinstance(question["text"], str) and len(question["text"]) > 0, f"turn {turn}: question has text")

    r = client.post(
        f"/sessions/{session_id}/answers",
        json={"question_id": question["id"], "transcript": ANSWER},
        headers=headers,
    )
    expect(r.status_code == 201, f"turn {turn}: answer submitted ({r.text})")
    abody = r.json()
    expect(abody["evaluation"] is not None, f"turn {turn}: a substantive answer gets scored, not refused: {abody.get('evaluation_note')}")
    expect(0 <= abody["evaluation"]["score"] <= 5, f"turn {turn}: score is in range 0-5")

    if abody.get("follow_up"):
        follow_up_seen = True
        r = client.post(
            f"/sessions/{session_id}/answers/{abody['answer_id']}/follow-up",
            json={"follow_up_text": abody["follow_up"]["text"], "transcript": "We went from 40% to 90% test coverage over two months."},
            headers=headers,
        )
        expect(r.status_code == 201 and r.json()["follow_ups"] == 1, f"turn {turn}: follow-up answer recorded")

    if question.get("quota_override"):
        quota_override_seen = True

session_after = client.get(f"/sessions/{session_id}", headers=headers).json()["session"]
expect(session_after["state"] == "WRAP_UP", f"session auto-advances to WRAP_UP once budget is spent, got {session_after['state']}")
expect(intro_seen, "the introduction question was asked during the loop")
expect(asked_count == 3, f"exactly 3 content questions asked (the budget), got {asked_count}")
expect(
    any(e["topic"] == "introduction" for e in session_after["topicPlan"]),
    "the introduction slot is still on the final topic plan after the intro-fused rebuild",
)

# the same pending question is re-served on a duplicate call (idempotent nextQuestion) —
# verified indirectly: transitions audit shows exactly the expected state changes
transitions = client.get(f"/sessions/{session_id}/transitions", headers=headers).json()["transitions"]
expected_states = ["CONFIG", "TELEMETRY_CHECK", "CALIBRATION", "QUESTION_LOOP", "WRAP_UP"]
actual_states = [t["toState"] for t in transitions]
expect(actual_states == expected_states, f"transition sequence matches expected: {actual_states}")

# transcript reflects everything asked/answered
transcript = client.get(f"/sessions/{session_id}/transcript", headers=headers).json()
expect(len(transcript["transcript"]) == 4, f"transcript has 4 entries (intro + 3 content), got {len(transcript['transcript'])}")
expect(all(entry["answer"] is not None for entry in transcript["transcript"]), "every question in the transcript has an answer")
expect(all(len(entry["evaluations"]) >= 1 for entry in transcript["transcript"]), "every answer has at least one persisted evaluation")

# ------------------------------------------- (Orchestration addition) directives
#
# The Follow-up Agent's `next_action` used to be computed, persisted, pushed to
# the browser — and then dropped. The next question was chosen from counts and
# tiers alone, so an `escalate` ("this topic's tier is covered, go deeper")
# could not actually cause an escalation: least-covered-topic-first ordering
# moved the interview off that topic on the very next turn.
#
# These exercise the selector directly rather than through a live session,
# because what needs pinning is the PRECEDENCE — a directive reorders the plan,
# and the quota still wins over it.

from app.agents.question.server import SelectQuestionInput, select_next_question  # noqa: E402
from app.shared_types import TopicPlanEntry  # noqa: E402

_PLAN = [
    TopicPlanEntry(topic="databases", max_questions=2, source="resume"),
    TopicPlanEntry(topic="apis and services", max_questions=2, source="role_requirement"),
]


def _select(**overrides):
    base = dict(
        session_id="directive-smoke",
        topic_plan=_PLAN,
        topic_counts={"databases": 1},
        asked_question_ids=[],
        difficulty_target=3,
        topic_tier={"databases": 1},
        topic_scores={"databases": [4.5]},
    )
    base.update(overrides)
    return select_next_question(SelectQuestionInput(**base))


# Without a directive: least-covered topic first, so the interview moves off
# `databases` (1 asked) and onto `apis and services` (0 asked).
expect(_select().question.topic == "apis and services", "with no directive, selection still moves to the least-covered topic")

# With `escalate` on `databases`: it stays, and goes a tier deeper.
escalated = _select(directive="escalate", directive_topic="databases")
expect(escalated.question.topic == "databases", f"an escalate directive keeps the next question on the same topic, got {escalated.question.topic}")
expect(escalated.followed_directive == "escalate", "the honoured directive is reported back so it lands in telemetry")
expect(escalated.question.tier == 2, f"escalating on a topic whose scores support it moves up a tier, got {escalated.question.tier}")

# `pivot` is the directive that means "move on" — it must not pin the topic.
expect(_select(directive="pivot", directive_topic="databases").question.topic == "apis and services", "a pivot directive does not hold the topic")

# The quota outranks the directive: `databases` at its cap cannot be held onto,
# even by an escalate. A directive may reorder the plan, never overrun it (§4.3).
capped = _select(directive="escalate", directive_topic="databases", topic_counts={"databases": 2})
expect(capped.question.topic == "apis and services", f"a capped topic is released despite an escalate directive, got {capped.question.topic}")
expect(capped.followed_directive is None, "a directive that did not change the pick is not reported as followed")

# ------------------------------------------- (follow-up continuity fix) recent_exchanges
#
# `_continuity()` builds the trailing window that lets `question-agent/v4`
# open a question by referring back to what was actually discussed. Before
# this fix it only ever looked at the ORIGINAL top-level answer, never a
# follow-up that probed it — even though probing past a vague first answer
# into something specific is the Follow-up Agent's entire job (§4.4), which
# makes the follow-up exchange systematically the one most likely to carry
# the concrete, quotable detail. Exercised directly against the orchestrator,
# like the directive tests above, because what needs pinning here is the DATA
# reaching the Question Agent — the fixture LLM's `_question` just echoes the
# baseline text back (see `fixture_model.py`), so it can't demonstrate this
# through a live session's generated question text.

import asyncio  # noqa: E402

from app.agents.harness.interview import InterviewDeps, InterviewOrchestrator  # noqa: E402
from app.shared_types import Answer, FollowUp, Question  # noqa: E402


class _FakeQuestionStore:
    def __init__(self, questions):
        self._questions = questions

    async def list_by_session(self, _session_id):
        return self._questions


class _FakeAnswerStore:
    def __init__(self, answers_by_question_id):
        self._answers = answers_by_question_id

    async def get_by_question(self, question_id):
        return self._answers.get(question_id)


_continuity_question = Question(
    id="q-continuity-1",
    bank_id="bank-1",
    session_id="continuity-smoke",
    text="Tell me about a time you owned a database migration.",
    topic="databases",
    type="technical",
    difficulty=3,
    asked_at="2024-01-01T00:00:00Z",
)
_continuity_answer = Answer(
    id="a-continuity-1",
    question_id=_continuity_question.id,
    transcript="We moved the billing service to Postgres.",
    submitted_at="2024-01-01T00:00:05Z",
    follow_ups=[
        FollowUp(
            text="What was your own part in that migration specifically?",
            transcript=(
                "I personally wrote the dual-write shim and ran the backfill, cutting the "
                "migration window from 6 hours down to 20 minutes."
            ),
        )
    ],
)

_continuity_orchestrator = InterviewOrchestrator(
    InterviewDeps(
        sessions=None,
        questions=_FakeQuestionStore([_continuity_question]),
        answers=_FakeAnswerStore({_continuity_question.id: _continuity_answer}),
        evaluations=None,
        telemetry=None,
        tool_client=lambda session_id, caller: None,
    )
)

continuity = asyncio.run(_continuity_orchestrator._continuity("continuity-smoke"))
continuity_exchanges = continuity.get("recent_exchanges") or []
expect(len(continuity_exchanges) == 1, f"one answered question produces one exchange, got {len(continuity_exchanges)}")
expect(
    "backfill" in continuity_exchanges[0]["answer_excerpt"] and "20 minutes" in continuity_exchanges[0]["answer_excerpt"],
    f"the answered follow-up's own content is folded into the exchange the next question can reference, got: {continuity_exchanges[0]['answer_excerpt']!r}",
)

print(f"\n  topics covered: {seen_topics}")
print(f"  follow-up triggered at least once: {follow_up_seen}")
print(f"  quota override used: {quota_override_seen}")
print("\nALL F6 SMOKE CHECKS PASSED")

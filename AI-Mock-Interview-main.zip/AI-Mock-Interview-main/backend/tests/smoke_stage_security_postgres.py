"""Manual smoke test for the Postgres half of the Phase 1 security fixes
(deploy/aws/notes/PATCH_PLAN.md A1 and A5), against a real Postgres + Redis.
The memory-driver half is `smoke_stage_security.py`.

Requires a migrated Postgres and a Redis, the same as `smoke_stage_postgres.py`
(`DATABASE_URL`/`REDIS_URL`, migrations applied via `python -m app.storage.migrate`).
Run directly with the venv's python, not pytest."""

from __future__ import annotations

import base64
import json
import os
import time
import uuid
from dataclasses import dataclass
from urllib.parse import parse_qs, urlparse

os.environ["NODE_ENV"] = "test"
os.environ["AUTH_TOKEN_SECRET"] = "x" * 32
os.environ.setdefault("DATABASE_URL", "postgres://mia:mia@localhost:5432/mia")
os.environ.setdefault("REDIS_URL", "redis://localhost:6380")

from fastapi.testclient import TestClient  # noqa: E402

from app.auth.google import GoogleTokenResponse  # noqa: E402
from app.config import load_config  # noqa: E402
from app.gateway import CreateAppOptions, create_app  # noqa: E402

CLIENT_ID = "test-client-id"


def expect(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)
    print(f"OK: {msg}")


def b64(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode()


@dataclass
class FakeGoogleClient:
    id_token: str = ""

    def create_authorization_url(self, state: str, code_verifier: str, scopes: list[str]) -> str:
        return "https://accounts.google.com/o/oauth2/v2/auth?fake=1"

    async def validate_authorization_code(self, code: str, code_verifier: str) -> GoogleTokenResponse:
        return GoogleTokenResponse(id_token=self.id_token)


suffix = uuid.uuid4().hex[:8]
boss = f"pg-boss-{suffix}@example.com"
victim = f"pg-victim-{suffix}@example.com"
late = f"pg-late-{suffix}@example.com"

fake = FakeGoogleClient()
config = load_config(
    {
        "NODE_ENV": "test",
        "AUTH_TOKEN_SECRET": "x" * 32,
        "STORAGE_DRIVER": "postgres",
        "DATABASE_URL": os.environ["DATABASE_URL"],
        "REDIS_URL": os.environ["REDIS_URL"],
        "GOOGLE_CLIENT_ID": CLIENT_ID,
        "GOOGLE_CLIENT_SECRET": "s",
        "GOOGLE_REDIRECT_URI": "http://localhost/cb",
        "ADMIN_EMAIL_ALLOWLIST": boss,
        "AUTH_RATE_LIMIT_ENABLED": "true",
    }
)
app = create_app(CreateAppOptions(config=config, google_auth_client=fake))
# Entered manually so the startup lifespan binds the pool to TestClient's loop
# (same reason as smoke_stage_postgres.py).
client = TestClient(app).__enter__()
expect(app.state.config.storage_driver == "postgres", "app booted against the real postgres+redis driver")


def google_login(email: str, sub: str) -> dict:
    claims = {"iss": "https://accounts.google.com", "aud": CLIENT_ID, "sub": sub, "email": email, "email_verified": True, "exp": int(time.time()) + 3600}
    fake.id_token = f"{b64(json.dumps({'alg': 'none'}).encode())}.{b64(json.dumps(claims).encode())}.{b64(b'sig')}"
    start = client.get("/auth/google/start", follow_redirects=False)
    res = client.get("/auth/google/callback", params={"code": "c", "state": start.cookies["mia_oauth_state"]}, follow_redirects=False)
    assert res.status_code == 302, f"google callback failed: {res.status_code} {res.text}"
    fragment = parse_qs(urlparse(res.headers["location"]).fragment)
    return {"token": fragment["token"][0], "role": fragment["role"][0]}


def as_ip(ip: str) -> TestClient:
    """The one entered client, re-pointed at a new peer address. A second
    TestClient would run on its own event loop, which the asyncpg pool (bound
    to this client's loop at startup) cannot serve."""
    client._transport.client = (ip, 5000)  # type: ignore[attr-defined]
    return client


# ------------------------------------------------------------ A1 pre-hijack
attacker = as_ip("203.0.113.10")
r = attacker.post("/auth/register", json={"email": boss, "passcode": "attacker-pass"})
expect(r.status_code == 201, f"attacker registers the not-yet-claimed admin email: {r.status_code}")

before = client.post("/auth/login", json={"email": boss, "passcode": "attacker-pass"})
expect(before.status_code == 200, "sanity: before the Google login the attacker's passcode works")

admin = google_login(boss, "g-boss")
expect(admin["role"] == "admin", "the admin's Google login lands on the existing row as admin")

r = attacker.post("/auth/login", json={"email": boss, "passcode": "attacker-pass"})
expect(r.status_code == 401, f"A1 (postgres): the attacker's passcode fails after the admin's Google login: {r.status_code} {r.text}")

r = client.get("/admin/users", headers={"Authorization": f"Bearer {admin['token']}"})
expect(r.status_code == 200, "the Google-minted admin token works")

as_ip("203.0.113.11").post("/auth/register", json={"email": victim, "passcode": "attacker-pass"})
google_login(victim, "g-victim")
r = attacker.post("/auth/login", json={"email": victim, "passcode": "attacker-pass"})
expect(r.status_code == 401, "A1 (postgres): a pre-claimed student row loses the attacker's passcode too")

google_login(late, "g-late")
r = attacker.post("/auth/register", json={"email": late, "passcode": "attacker-pass"})
expect(r.status_code == 409, f"A1 reverse (postgres): registering over an existing Google identity is refused: {r.status_code}")
r = attacker.post("/auth/login", json={"email": late, "passcode": "attacker-pass"})
expect(r.status_code == 401, "A1 reverse (postgres): no passcode logs in to a Google-created row")

again = google_login(boss, "g-boss")
expect(again["role"] == "admin", "a repeat Google login on the same row still works")

# ------------------------------------------------------ A5 via real Redis
target = f"pg-rl-{suffix}@example.com"
codes = [
    as_ip(f"198.51.100.{i}").post("/auth/login", json={"email": target, "passcode": "wrong-pass"}).status_code
    for i in range(1, 13)
]
expect(codes[:10] == [401] * 10 and codes[10:] == [429, 429], f"A5 (redis): per-email login limit holds across IPs: {codes}")

client.__exit__(None, None, None)
print("\nALL SECURITY POSTGRES SMOKE CHECKS PASSED")

"""Comprehensive tests for the production-grade STT pipeline.

Covers:
1. Pre-model acoustic quality analysis & gating (synthetic audio).
2. Adaptive VAD, noise estimation, and utterance segmentation with hysteresis.
3. Transcription quality scoring & deterministic hallucination detection.
4. Retry heuristics, multi-pass decode, and consensus resolution.
5. Exact and fuzzy technical vocabulary normalization (transcript integrity).
6. Echo classification enhancements (timing & confidence).
7. Observability counters and metrics reporting.
8. End-to-end Whisper STT pipeline (runs when models are available, skips gracefully otherwise).

Run: `python -m tests.test_stt_pipeline`
"""

from __future__ import annotations

import asyncio
import os
import time

os.environ["NODE_ENV"] = "test"
os.environ["AUTH_TOKEN_SECRET"] = "x" * 32

import numpy as np

from app.tools.speech_service.provider import (
    TranscriptionFailed,
    encode_wav,
)
from app.tools.speech_service.source import classify
from app.tools.speech_service.stt.audio_quality import analyse_audio_quality
from app.tools.speech_service.stt.config import STTPipelineConfig, load_stt_config
from app.tools.speech_service.stt.consensus import resolve_consensus
from app.tools.speech_service.stt.fuzzy_match import (
    fuzzy_match_score,
    phonetic_similarity,
    simplified_metaphone,
)
from app.tools.speech_service.stt.hallucination import detect_hallucinations
from app.tools.speech_service.stt.metrics import GLOBAL_METRICS, get_stt_metrics
from app.tools.speech_service.stt.models import (
    TranscriptionQuality,
    WhisperSegmentInfo,
)
from app.tools.speech_service.stt.normalizer import normalize_transcript
from app.tools.speech_service.stt.prompts import CandidateContext, build_initial_prompt
from app.tools.speech_service.stt.quality_scoring import score_transcription_quality
from app.tools.speech_service.stt.retry import should_retry
from app.tools.speech_service.stt.segmentation import segment_audio
from app.tools.speech_service.vad import VoiceActivity, analyse, trim

SR = 16_000


def expect(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)
    print(f"  OK: {msg}")


def tone(seconds: float, amp: float = 0.3, freq: float = 180.0) -> np.ndarray:
    t = np.arange(int(SR * seconds)) / SR
    return (amp * np.sin(2 * np.pi * freq * t)).astype(np.float32)


def hush(seconds: float, amp: float = 0.0005) -> np.ndarray:
    return np.random.default_rng(42).normal(0, amp, int(SR * seconds)).astype(np.float32)


def test_audio_quality() -> None:
    print("\n--- 1. Audio Quality & Pre-Model Acoustic Gating ---")
    cfg = STTPipelineConfig()

    # 1. Pure digital silence
    silence = np.zeros(SR * 2, dtype=np.float32)
    q_silence, vad_silence = analyse_audio_quality(silence, SR, cfg)
    expect(not q_silence.is_usable, "digital silence is rejected as unusable")
    expect("no speech detected" in (q_silence.rejection_reason or ""), "rejection reason correctly identifies silence")

    # 2. Steady room noise / hum without speech
    noise = hush(2.0, amp=0.01)
    q_noise, vad_noise = analyse_audio_quality(noise, SR, cfg)
    expect(not q_noise.is_usable, "steady background noise without speech is rejected")

    # 3. Valid speech with silent margins
    speech_signal = np.concatenate([hush(0.5, 0.001), tone(1.5, 0.25), hush(0.5, 0.001)])
    q_speech, vad_speech = analyse_audio_quality(speech_signal, SR, cfg)
    expect(q_speech.is_usable, "speech with silence margins is usable")
    expect(q_speech.speech_ratio > 0.3, f"speech ratio measured appropriately ({q_speech.speech_ratio})")
    expect(q_speech.snr_estimate_db > 15.0, f"snr estimated cleanly ({q_speech.snr_estimate_db}dB)")
    expect(q_speech.clipping_ratio == 0.0, "clean speech has zero clipping")

    # 4. Severe clipping detection
    clipped_speech = np.clip(speech_signal * 10.0, -1.0, 1.0)
    q_clipped, _ = analyse_audio_quality(clipped_speech, SR, cfg)
    expect(q_clipped.clipping_ratio > 0.30, f"clipping detected on saturated audio ({q_clipped.clipping_ratio:.1%})")
    expect(not q_clipped.is_usable, "severely clipped audio is rejected")

    # 5. Short audio (<200ms)
    short_audio = speech_signal[: int(SR * 0.1)]
    q_short, _ = analyse_audio_quality(short_audio, SR, cfg)
    expect(not q_short.is_usable, "sub-200ms audio is rejected")
    expect("too short" in (q_short.rejection_reason or ""), "rejection notes duration too short")


def test_vad_and_segmentation() -> None:
    print("\n--- 2. VAD, Noise Estimation, and Utterance Segmentation ---")
    cfg = STTPipelineConfig(vad_min_silence_ms=500, vad_padding_ms=100)

    # Speech with a brief conversational pause (200ms) with room tone margins -> should remain merged (hangover)
    paused_speech = np.concatenate([hush(0.5, 0.001), tone(0.8, 0.2), hush(0.2, 0.001), tone(0.8, 0.2), hush(0.5, 0.001)])
    segs = segment_audio(paused_speech, SR, cfg)
    expect(len(segs) == 1, f"short conversational pause (<500ms) is bridged into 1 segment, got {len(segs)}")

    # Speech with a long pause (1200ms) -> should split into 2 separate segments
    split_speech = np.concatenate([hush(0.5, 0.001), tone(0.8, 0.2), hush(1.2, 0.001), tone(0.8, 0.2), hush(0.5, 0.001)])
    segs_split = segment_audio(split_speech, SR, cfg)
    expect(len(segs_split) == 2, f"long pause (>500ms) splits into 2 distinct utterances, got {len(segs_split)}")

    # Trimming preserves margins
    act = analyse(split_speech, SR)
    trimmed = trim(split_speech, act, pad_ms=100)
    expect(len(trimmed) < len(split_speech), "silence trimming reduces sample count")


def test_hallucination_and_quality_scoring() -> None:
    print("\n--- 3. Whisper Quality Scoring & Hallucination Detection ---")
    dummy_act = VoiceActivity(
        sample_rate=SR,
        total_ms=3000.0,
        speech_ms=2000.0,
        silence_ms=1000.0,
        leading_silence_ms=500.0,
        trailing_silence_ms=500.0,
        speech_ratio=0.66,
        peak_dbfs=-6.0,
        noise_floor_dbfs=-40.0,
        threshold_dbfs=-30.0,
        has_speech=True,
        speech_start=8000,
        speech_end=40000,
    )

    # 1. High quality normal transcription
    seg_good = [WhisperSegmentInfo("I implemented a caching layer with Redis.", 0.5, 2.5, -0.2, 0.01, 1.1)]
    q_good = score_transcription_quality(seg_good[0].text, seg_good, dummy_act, rms_val=0.15)
    expect(q_good.quality_class == "GOOD", f"normal transcription classifies as GOOD, got {q_good.quality_class}")
    expect(q_good.quality_score >= 0.70, f"high score on clean transcript ({q_good.quality_score})")
    expect(len(q_good.hallucination_flags) == 0, "no hallucination flags on clean transcript")

    # 2. Repeated loop hallucination
    loop_text = "thank you thank you thank you thank you thank you thank you"
    seg_loop = [WhisperSegmentInfo(loop_text, 0.0, 3.0, -0.6, 0.1, 1.2)]
    h_loop = detect_hallucinations(loop_text, seg_loop, dummy_act)
    expect(h_loop.repetition_detected, "repetition loop is flagged by hallucination detector")
    q_loop = score_transcription_quality(loop_text, seg_loop, dummy_act)
    expect(q_loop.quality_class == "BAD", f"repetition loop receives BAD quality class, got {q_loop.quality_class}")

    # 3. Impossible word density (40 words in 0.5s of speech)
    short_act = VoiceActivity(
        sample_rate=SR,
        total_ms=1000.0,
        speech_ms=500.0,
        silence_ms=500.0,
        leading_silence_ms=250.0,
        trailing_silence_ms=250.0,
        speech_ratio=0.5,
        peak_dbfs=-10.0,
        noise_floor_dbfs=-35.0,
        threshold_dbfs=-25.0,
        has_speech=True,
        speech_start=4000,
        speech_end=12000,
    )
    dense_text = "word " * 30
    h_dense = detect_hallucinations(dense_text, [], short_act)
    expect(h_dense.density_anomaly_detected, "impossible speech density (>7 words/sec) is flagged")

    # 4. Low avg_logprob penalty
    seg_bad_logprob = [WhisperSegmentInfo("mumbled unclear sound", 0.5, 2.5, -1.8, 0.6, 1.2)]
    q_bad_logprob = score_transcription_quality(seg_bad_logprob[0].text, seg_bad_logprob, dummy_act)
    expect(q_bad_logprob.quality_score < q_good.quality_score, "low avg_logprob penalizes quality score")


def test_retry_and_consensus() -> None:
    print("\n--- 4. Retry Logic & Multi-Pass Consensus ---")
    cfg = STTPipelineConfig()

    good_quality = TranscriptionQuality(-0.2, 0.01, 1.1, 0.0, 2.5, 1.0, 0.88, "GOOD", [])
    uncertain_quality = TranscriptionQuality(-0.9, 0.25, 1.2, 0.2, 2.2, 0.6, 0.52, "UNCERTAIN", ["low confidence"])
    bad_quality = TranscriptionQuality(-1.5, 0.70, 2.5, 0.6, 6.0, 0.2, 0.25, "BAD", ["repetition loop"])

    expect(not should_retry(good_quality, cfg), "GOOD transcript does not trigger retry")
    expect(should_retry(uncertain_quality, cfg), "UNCERTAIN transcript triggers single retry")
    expect(should_retry(bad_quality, cfg), "transcript with hallucination flags triggers retry")

    # Consensus resolution when both passes agree
    t1 = "I created a binary search tree in Java"
    t2 = "I created a binary search tree in Java"
    res_agree = resolve_consensus(t1, uncertain_quality, t2, good_quality)
    expect(res_agree.is_consensus, "identical passes produce consensus")
    expect(res_agree.similarity == 1.0, "similarity is 1.0 on identical passes")
    expect(res_agree.chosen_pass == 2, "higher quality pass 2 is selected")

    # Consensus resolution when passes diverge significantly
    t_diverge_1 = "we used mongo db for storage"
    t_diverge_2 = "we had no degree for courage"
    res_diverge = resolve_consensus(t_diverge_1, uncertain_quality, t_diverge_2, bad_quality)
    expect(not res_diverge.is_consensus, "low similarity passes flag multi-pass disagreement")
    expect(res_diverge.chosen_pass == 1, "superior pass 1 chosen over bad pass 2")


def test_phonetic_and_normalization() -> None:
    print("\n--- 5. Phonetic Matching & Technical Vocabulary Normalization ---")

    # 1. Metaphone & phonetic similarity
    expect(simplified_metaphone("SQL") == simplified_metaphone("sequel") or simplified_metaphone("SQL") == "SKL", "SQL encodes phonetically")
    expect(phonetic_similarity("hashmap", "hash map") > 0.7, "phonetic similarity aligns spoken compounds")

    # 2. Exact alias replacement
    raw_1 = "we stored user records in my sequel and cached in redis"
    norm_1 = normalize_transcript(raw_1)
    expect("MySQL" in norm_1, f"'my sequel' normalized to 'MySQL': {norm_1}")
    expect("Redis" in norm_1, f"'redis' capitalized to 'Redis': {norm_1}")

    raw_2 = "the lookup complexity of a hash map is oh one on average"
    norm_2 = normalize_transcript(raw_2)
    expect("HashMap" in norm_2, f"'hash map' normalized to 'HashMap': {norm_2}")
    expect("O(1)" in norm_2, f"'oh one' normalized to 'O(1)': {norm_2}")

    raw_complexity = "the worst case is o of log n while sorting is o of n log n"
    norm_complexity = normalize_transcript(raw_complexity)
    expect("O(log n)" in norm_complexity, f"'o of log n' normalized to 'O(log n)': {norm_complexity}")
    expect("O(n log n)" in norm_complexity, f"'o of n log n' normalized to 'O(n log n)': {norm_complexity}")

    # 3. Context-aware fuzzy matching with topic terms
    topic_terms = ["Kubernetes", "PostgreSQL", "GraphQL", "TypeScript"]
    raw_fuzzy = "we deployed our services to kubernets with a post gres backend"
    norm_fuzzy = normalize_transcript(raw_fuzzy, topic_terms=topic_terms)
    expect("PostgreSQL" in norm_fuzzy, f"'post gres' normalized: {norm_fuzzy}")
    expect("Kubernetes" in norm_fuzzy, f"'kubernets' fuzzy-aligned to 'Kubernetes': {norm_fuzzy}")

    # 4. Strict Semantic Integrity: never alter non-target words or candidate meaning
    raw_unrelated = "the quick brown fox jumped over the lazy dog"
    expect(normalize_transcript(raw_unrelated) == raw_unrelated, "unrelated text remains unmodified")


def test_echo_enhancements() -> None:
    print("\n--- 6. Sound Source & Echo Detection Enhancements ---")
    Q = "Can you describe the lifecycle of a request in your framework?"

    # Exact echo
    v_exact = classify(transcript=Q, spoken_recently=[Q])
    expect(v_exact.reject, "exact repetition is rejected")
    expect(v_exact.status == "likely_echo", f"status is likely_echo ({v_exact.status})")
    expect(v_exact.echo_confidence >= 0.9, f"high echo confidence ({v_exact.echo_confidence})")

    # Timing overlap check
    now = time.time()
    v_overlap = classify(
        transcript="Well in my application we use middleware",
        device_hint="microphone",
        tts_playing_at=now - 0.5,
        recording_started_at=now,
    )
    expect(not v_overlap.reject, "timing overlap alone does not reject real answer")
    expect(v_overlap.status == "possible_echo", "timing overlap marks possible_echo")

    # Normal microphone input without overlap
    v_normal = classify(
        transcript="We routed requests through an API gateway",
        device_hint="microphone",
        spoken_recently=[Q],
    )
    expect(not v_normal.reject and v_normal.status == "normal", "normal answer has status normal")


def test_observability_metrics() -> None:
    print("\n--- 7. In-Memory Observability Metrics ---")
    GLOBAL_METRICS.reset()

    GLOBAL_METRICS.record(success=True, decode_ms=120.0, quality_class="GOOD")
    GLOBAL_METRICS.record(success=True, decode_ms=180.0, used_retry=True, quality_class="UNCERTAIN")
    GLOBAL_METRICS.record(success=False, no_speech=True, quality_class="BAD")

    metrics = get_stt_metrics()
    expect(metrics["total_transcriptions"] == 3, f"total transcriptions is 3, got {metrics['total_transcriptions']}")
    expect(metrics["successful"] == 2, f"successful count is 2, got {metrics['successful']}")
    expect(metrics["no_speech_rate"] > 0.3, "no_speech_rate computed accurately")
    expect(metrics["retry_rate"] > 0.3, "retry_rate computed accurately")
    expect(metrics["latency_ms"]["min_decode"] == 120.0, "min decode recorded")
    expect(metrics["latency_ms"]["max_decode"] == 180.0, "max decode recorded")


def test_prompt_builder() -> None:
    print("\n--- 8. Interview Prompt Builder ---")
    prompt_explicit = build_initial_prompt(topic_terms=["HashMap", "LinkedList", "O(1)"])
    expect(prompt_explicit is not None and "HashMap" in prompt_explicit, f"prompt includes explicit terms: {prompt_explicit}")

    prompt_question = build_initial_prompt(question_text="How would you design a distributed database with sharding?")
    expect(prompt_question is not None and "Technical interview vocabulary:" in prompt_question, f"prompt extracts domain terms: {prompt_question}")

    # 1. Full candidate context on introduction question (including exclusive keywords)
    ctx_full = CandidateContext(
        full_name="Varun Kumar",
        role="Full Stack Developer",
        recent_companies=["Zoho", "Infosys"],
        institutions=["Anna University"],
        degrees=["B.Tech Computer Science"],
        keywords=["Kubernetes", "Kafka"],
    )
    prompt_intro = build_initial_prompt(question_text="Tell me about yourself and your background", candidate_context=ctx_full)
    expect(
        prompt_intro == "Candidate introduction: Varun Kumar, Full Stack Developer, Zoho, Anna University, B.Tech Computer Science, Kubernetes, Kafka.",
        f"full introduction prompt generated with keywords: {prompt_intro}",
    )

    # 2. Keywords-only candidate context
    ctx_kw = CandidateContext(keywords=["FastAPI", "WebSockets"])
    prompt_kw = build_initial_prompt(question_text="Introduce yourself", candidate_context=ctx_kw)
    expect(prompt_kw == "Candidate introduction: FastAPI, WebSockets.", f"keywords-only prompt generated: {prompt_kw}")

    # 3. Deduplication of keywords matching existing parts or each other
    ctx_dedup = CandidateContext(role="Backend Engineer", keywords=["Backend Engineer", "backend engineer", "PostgreSQL"])
    prompt_dedup = build_initial_prompt(question_text="Tell me about yourself", candidate_context=ctx_dedup)
    expect(prompt_dedup == "Candidate introduction: Backend Engineer, PostgreSQL.", f"keywords deduplicated: {prompt_dedup}")

    # 4. Partial candidate context (name only)
    ctx_name = CandidateContext(full_name="Alice Smith")
    prompt_partial = build_initial_prompt(question_text="Could you give a brief introduction of yourself?", candidate_context=ctx_name)
    expect(prompt_partial == "Candidate introduction: Alice Smith.", f"name-only prompt generated: {prompt_partial}")

    # 5. None candidate context with introduction question -> falls back to None
    prompt_none = build_initial_prompt(question_text="Tell me about yourself", candidate_context=None)
    expect(prompt_none is None, "None candidate_context on introduction returns None")

    # 6. Empty candidate context with introduction question -> falls back to None
    ctx_empty = CandidateContext()
    prompt_empty = build_initial_prompt(question_text="Please introduce yourself", candidate_context=ctx_empty)
    expect(prompt_empty is None, "empty candidate_context on introduction returns None")

    # 7. Non-introduction question with candidate context -> uses technical vocabulary path
    prompt_tech = build_initial_prompt(
        question_text="How would you design a distributed database with sharding?",
        candidate_context=ctx_full,
    )
    expect(
        prompt_tech is not None and "Technical interview vocabulary:" in prompt_tech,
        f"technical question uses technical vocabulary even with context: {prompt_tech}",
    )


def test_config_loader() -> None:
    print("\n--- 9. STT Pipeline Config Loader ---")
    env = {
        "STT_MODEL": "tiny.en",
        "STT_COMPUTE_TYPE": "int8",
        "STT_TIMEOUT_SECONDS": "20.0",
        "WHISPER_BEAM_SIZE": "3",
        "QUALITY_RETRY_ENABLED": "true",
        "TECHNICAL_NORMALIZATION_ENABLED": "true",
    }
    cfg = load_stt_config(env=env)
    expect(cfg.model_size == "tiny.en", "model_size loaded")
    expect(cfg.timeout_seconds == 20.0, "timeout loaded")
    expect(cfg.beam_size == 3, "beam size loaded")
    expect(cfg.quality_retry_enabled is True, "retry enabled loaded")


def main() -> None:
    test_audio_quality()
    test_vad_and_segmentation()
    test_hallucination_and_quality_scoring()
    test_retry_and_consensus()
    test_phonetic_and_normalization()
    test_echo_enhancements()
    test_observability_metrics()
    test_prompt_builder()
    test_config_loader()
    print("\nALL STT PIPELINE UNIT TESTS PASSED SUCCESSFULLY!")


if __name__ == "__main__":
    main()

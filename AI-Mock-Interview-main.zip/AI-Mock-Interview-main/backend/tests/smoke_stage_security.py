"""Manual smoke test for the Phase 1 security fixes (deploy/aws/notes/PATCH_PLAN.md
A1, A2, A4-config, A5, A6), against the memory driver. The Postgres half of
A1 is `smoke_stage_security_postgres.py`. Run directly with the venv's python,
not pytest.

A1 runs first on purpose: it is the regression check for audit P0-1, and it
must fail against the pre-fix `upsert_identity` (it did; see
deploy/aws/notes/impl-security.md)."""

from __future__ import annotations

import base64
import json
import os
import time
from dataclasses import dataclass
from typing import Optional
from urllib.parse import parse_qs, urlparse

os.environ["NODE_ENV"] = "test"
os.environ["AUTH_TOKEN_SECRET"] = "x" * 32

from fastapi.testclient import TestClient  # noqa: E402

from app.auth.google import GoogleTokenResponse  # noqa: E402
from app.config import load_config  # noqa: E402
from app.gateway import CreateAppOptions, create_app  # noqa: E402

CLIENT_ID = "test-client-id"
SECRET = "x" * 32


def expect(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)
    print(f"OK: {msg}")


def raises(fn, needle: str) -> bool:
    try:
        fn()
    except RuntimeError as err:
        return needle in str(err)
    return False


def b64(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode()


def fake_id_token(email: str, sub: str) -> str:
    claims = {
        "iss": "https://accounts.google.com",
        "aud": CLIENT_ID,
        "sub": sub,
        "email": email,
        "email_verified": True,
        "exp": int(time.time()) + 3600,
    }
    # A signature segment that is valid base64: PyJWT >= 2.15 decodes it even
    # with verification off (audit A.1), and the route under test is ours,
    # not PyJWT's.
    return f"{b64(json.dumps({'alg': 'none', 'typ': 'JWT'}).encode())}.{b64(json.dumps(claims).encode())}.{b64(b'sig')}"


@dataclass
class FakeGoogleClient:
    id_token: str

    def create_authorization_url(self, state: str, code_verifier: str, scopes: list[str]) -> str:
        return "https://accounts.google.com/o/oauth2/v2/auth?fake=1"

    async def validate_authorization_code(self, code: str, code_verifier: str) -> GoogleTokenResponse:
        return GoogleTokenResponse(id_token=self.id_token)


def base_env(**extra: str) -> dict[str, str]:
    env = {
        "NODE_ENV": "test",
        "AUTH_TOKEN_SECRET": SECRET,
        "GOOGLE_CLIENT_ID": CLIENT_ID,
        "GOOGLE_CLIENT_SECRET": "s",
        "GOOGLE_REDIRECT_URI": "http://localhost/cb",
    }
    env.update(extra)
    return env


def google_login(client: TestClient, app, email: str, sub: str) -> dict:
    """One full /start -> /callback round trip. The fake client is swapped per
    call so one app (one user store) can see several Google identities."""
    app.state.google_client_for_test.id_token = fake_id_token(email, sub)
    start = client.get("/auth/google/start", follow_redirects=False)
    res = client.get(
        "/auth/google/callback", params={"code": "c", "state": start.cookies["mia_oauth_state"]}, follow_redirects=False
    )
    assert res.status_code == 302, f"google callback failed: {res.status_code} {res.text}"
    fragment = parse_qs(urlparse(res.headers["location"]).fragment)
    return {"token": fragment["token"][0], "role": fragment["role"][0], "location": res.headers["location"]}


def build(env: dict[str, str]):
    fake = FakeGoogleClient("")
    app = create_app(CreateAppOptions(config=load_config(env), google_auth_client=fake))
    app.state.google_client_for_test = fake
    return app, TestClient(app)


# ============================================================ A1: pre-hijack
app, client = build(base_env(ADMIN_EMAIL_ALLOWLIST="boss@example.com"))

# The attack, exactly as audit P0-1 reproduced it: register the admin's email
# before the admin has ever signed in.
r = client.post("/auth/register", json={"email": "boss@example.com", "passcode": "attacker-pass"})
expect(r.status_code == 201, f"attacker can still register an unclaimed email: {r.status_code}")
expect(r.json()["user"]["role"] == "student", "a self-registered account is a student")

admin = google_login(client, app, "boss@example.com", "google-boss")
expect(admin["role"] == "admin", "the real admin's Google login resolves admin from the allowlist")

r = client.post("/auth/login", json={"email": "boss@example.com", "passcode": "attacker-pass"})
expect(r.status_code == 401, f"A1: the attacker's pre-registered passcode no longer logs in after the Google login: {r.status_code}")

r = client.get("/admin/users", headers={"Authorization": f"Bearer {admin['token']}"})
expect(r.status_code == 200, "the Google-minted admin token still works")

# Same path, student flavour: pre-claiming any student's account.
client.post("/auth/register", json={"email": "victim@example.com", "passcode": "attacker-pass"})
google_login(client, app, "victim@example.com", "google-victim")
r = client.post("/auth/login", json={"email": "victim@example.com", "passcode": "attacker-pass"})
expect(r.status_code == 401, "A1: a pre-claimed student account loses the attacker's passcode too")

# The reverse order: the Google identity exists first, the attacker registers after.
google_login(client, app, "late@example.com", "google-late")
r = client.post("/auth/register", json={"email": "late@example.com", "passcode": "attacker-pass"})
expect(r.status_code == 409, f"A1 reverse: registering over an existing Google identity is refused: {r.status_code}")
r = client.post("/auth/login", json={"email": "late@example.com", "passcode": "attacker-pass"})
expect(r.status_code == 401, "A1 reverse: and no passcode logs in to a Google-created row")

# A second Google login is idempotent: still the same account, still works.
again = google_login(client, app, "boss@example.com", "google-boss")
expect(again["role"] == "admin", "a repeat Google login keeps working after the passcode was invalidated")

# The owner can still set a passcode through reset (which proves the mailbox).
client.post("/auth/reset-passcode/request", json={"email": "victim@example.com"})
token = app.state.mailer.last_for("victim@example.com").token
r = client.post("/auth/reset-passcode/confirm", json={"token": token, "passcode": "owner-pass-1"})
expect(r.status_code == 200, "the real owner can set a passcode via reset afterwards")
r = client.post("/auth/login", json={"email": "victim@example.com", "passcode": "owner-pass-1"})
expect(r.status_code == 200, "and log in with it")

# ===================================================== A6 + A4: config gates
PROD = {
    "NODE_ENV": "production",
    "AUTH_TOKEN_SECRET": SECRET,
    "STORAGE_DRIVER": "postgres",
    "DATABASE_URL": "postgres://u:p@db:5432/mia",
    "REDIS_URL": "redis://redis:6379",
    "FRONTEND_URL": "https://App.Example.test/",
}


def prod(**overrides: Optional[str]) -> dict[str, str]:
    env = dict(PROD)
    for key, value in overrides.items():
        if value is None:
            env.pop(key, None)
        else:
            env[key] = value
    return env


good = load_config(prod())
expect(good.node_env == "production" and good.storage_driver == "postgres", "a complete production env loads")
expect(good.frontend_url == "https://app.example.test", f"FRONTEND_URL is normalised (lowercase host, no slash): {good.frontend_url}")
expect(good.cors_origins == ["https://app.example.test"], f"A4: production CORS is exactly [FRONTEND_URL]: {good.cors_origins}")
expect(load_config(prod(FRONTEND_URL="https://app.example.test:8443")).frontend_url == "https://app.example.test:8443", "a non-default port is kept")
expect(load_config(prod(FRONTEND_URL="https://app.example.test:443")).frontend_url == "https://app.example.test", "the default port is dropped")

for bad in ("prod", "Production", "staging", " production", ""):
    expect(raises(lambda b=bad: load_config(prod(NODE_ENV=b)), "NODE_ENV"), f"A4: NODE_ENV={bad!r} fails at load")
expect(raises(lambda: load_config(prod(STORAGE_DRIVER="memory")), "STORAGE_DRIVER"), "A6: production refuses STORAGE_DRIVER=memory")
expect(raises(lambda: load_config(prod(STORAGE_DRIVER=None)), "STORAGE_DRIVER"), "A6: production refuses a missing STORAGE_DRIVER")
expect(raises(lambda: load_config(prod(STORAGE_DRIVER="postgress")), "STORAGE_DRIVER"), "A6: a misspelled STORAGE_DRIVER fails in production")
expect(raises(lambda: load_config({"NODE_ENV": "test", "STORAGE_DRIVER": "postgress"}), "STORAGE_DRIVER"), "A6: and in test")
expect(raises(lambda: load_config(prod(FRONTEND_URL=None)), "FRONTEND_URL"), "A6: production refuses a missing FRONTEND_URL")
expect(raises(lambda: load_config(prod(FRONTEND_URL="http://app.example.test")), "FRONTEND_URL"), "A6: production refuses an http FRONTEND_URL")
expect(raises(lambda: load_config(prod(FRONTEND_URL="https://app.example.test/app")), "FRONTEND_URL"), "A6: production refuses a FRONTEND_URL with a path")
expect(raises(lambda: load_config(prod(FRONTEND_URL="https://a.test,https://b.test")), "FRONTEND_URL"), "A6: production refuses a comma list in FRONTEND_URL")
expect(raises(lambda: load_config(prod(FRONTEND_URL="https://app.example.test/?x=1")), "FRONTEND_URL"), "A6: production refuses a FRONTEND_URL with a query")
expect(raises(lambda: load_config(prod(AUTH_TOKEN_SECRET=None)), "AUTH_TOKEN_SECRET"), "A6: production refuses a missing AUTH_TOKEN_SECRET")
expect(raises(lambda: load_config(prod(AUTH_TOKEN_SECRET="short")), "AUTH_TOKEN_SECRET"), "A6: production refuses a short AUTH_TOKEN_SECRET")
expect(raises(lambda: load_config(prod(DATABASE_URL=None)), "DATABASE_URL"), "A6: production refuses a missing DATABASE_URL")
expect(raises(lambda: load_config(prod(REDIS_URL="")), "REDIS_URL"), "A6: production refuses an empty REDIS_URL")
expect(raises(lambda: load_config(prod(ALLOW_DEV_AUTH="true")), "ALLOW_DEV_AUTH"), "A6: production refuses ALLOW_DEV_AUTH=true")
expect(load_config(prod(ALLOW_DEV_AUTH="false")).dev_auth_enabled is False, "ALLOW_DEV_AUTH=false (the .env.example value) still boots")

dev = load_config({"NODE_ENV": "development"})
expect(dev.node_env == "development" and dev.storage_driver == "memory", "development still defaults to the memory driver")
expect(load_config({}).node_env == "development", "an absent NODE_ENV is still development (local default)")
expect(dev.cors_origins == ["http://localhost:3000", "http://127.0.0.1:3000"], f"A4: dev CORS is an explicit list, not '*': {dev.cors_origins}")
custom = load_config({"NODE_ENV": "development", "FRONTEND_URL": "http://localhost:3100/", "CORS_DEV_ORIGINS": "http://localhost:5173, http://localhost:3000 ,"})
expect(
    custom.cors_origins == ["http://localhost:3100", "http://localhost:3000", "http://127.0.0.1:3000", "http://localhost:5173"],
    f"A4: dev list = FRONTEND_URL + localhost defaults + CORS_DEV_ORIGINS, deduplicated: {custom.cors_origins}",
)
expect("*" not in load_config({"NODE_ENV": "test", "CORS_DEV_ORIGINS": "*"}).cors_origins, "A4: a '*' in CORS_DEV_ORIGINS is dropped")
expect(load_config(prod(CORS_DEV_ORIGINS="http://localhost:5173")).cors_origins == ["https://app.example.test"], "A4: CORS_DEV_ORIGINS is ignored in production")

# Every existing smoke script builds its config from this shape; it must still load.
expect(load_config({"NODE_ENV": "test", "AUTH_TOKEN_SECRET": SECRET}).node_env == "test", "the smoke scripts' test env still loads")
expect(load_config({"NODE_ENV": "test", "STORAGE_DRIVER": "postgres"}).storage_driver == "postgres", "smoke_stage_postgres's env still loads")

# ======================================================= A2: coding flag
expect(load_config(prod()).coding_round_enabled is False, "A2: the coding round defaults OFF in production")
expect(load_config(prod(CODING_ROUND_ENABLED="true")).coding_round_enabled is True, "A2: it can be turned on explicitly")
expect(load_config({"NODE_ENV": "test"}).coding_round_enabled is True, "A2: it defaults ON outside production")
expect(load_config({"NODE_ENV": "development", "CODING_ROUND_ENABLED": "false"}).coding_round_enabled is False, "A2: and can be turned off in dev")
expect(raises(lambda: load_config({"NODE_ENV": "test", "CODING_ROUND_ENABLED": "yes"}), "CODING_ROUND_ENABLED"), "A2: an unparseable flag fails at load, not silently")

from app.tools.speech_service.fixture_provider import FixtureSpeechProvider  # noqa: E402
from app.tools.speech_service.server import ProviderChoice  # noqa: E402

off_app = create_app(
    CreateAppOptions(
        config=load_config({"NODE_ENV": "test", "AUTH_TOKEN_SECRET": SECRET, "CODING_ROUND_ENABLED": "false"}),
        speech_provider_choice=ProviderChoice(FixtureSpeechProvider(), "pinned for test"),
    )
)
off = TestClient(off_app)
r = off.post("/auth/register", json={"email": "coder@example.com", "passcode": "hunter22"})
headers = {"Authorization": f"Bearer {r.json()['token']}"}
session_id = off.post("/sessions", json={"role": "backend engineer", "question_budget": 1}, headers=headers).json()["session_id"]
for state in ("CONFIG", "TELEMETRY_CHECK"):
    off.post(f"/sessions/{session_id}/advance", json={"to": state}, headers=headers)
off.post(f"/sessions/{session_id}/telemetry-check", json={"mic_ok": True, "speaker_ok": True, "consent": {}}, headers=headers)
off.post(f"/sessions/{session_id}/begin", headers=headers)

r = off.post(f"/sessions/{session_id}/coding-round", headers=headers)
expect(r.status_code == 404 and r.json()["error"]["code"] == "coding_round_disabled", f"A2: starting the round is a clear 404: {r.status_code} {r.text}")
r = off.post(f"/sessions/{session_id}/coding-round/submissions", json={"code": "while(1){}"}, headers=headers)
expect(r.status_code == 404 and r.json()["error"]["code"] == "coding_round_disabled", f"A2: submitting code is a clear 404: {r.status_code}")
state_now = off.get(f"/sessions/{session_id}", headers=headers).json()["session"]["state"]
expect(state_now == "QUESTION_LOOP", f"A2: the refused start did not move the session: {state_now}")

with off.websocket_connect(f"/sessions/{session_id}/live?token={r.request.headers['authorization'].split()[1]}") as ws:
    ws.send_text(json.dumps({"type": "submit_code", "code": "process.exit(1)"}))
    frame = None
    for _ in range(10):
        candidate = json.loads(ws.receive_text())
        if candidate.get("type") == "error":
            frame = candidate
            break
    expect(frame is not None and frame["code"] == "coding_round_disabled", f"A2: the live channel refuses submit_code: {frame}")

# ========================================================= A5: rate limits
expect(load_config({"NODE_ENV": "test"}).auth_rate_limit_enabled is False, "A5: auth rate limiting is off by default in test (existing smokes register in bulk)")
expect(load_config({"NODE_ENV": "development"}).auth_rate_limit_enabled is True, "A5: on by default in development")
expect(load_config(prod(AUTH_RATE_LIMIT_ENABLED="false")).auth_rate_limit_enabled is True, "A5: and cannot be turned off in production")

rl_env = {"NODE_ENV": "test", "AUTH_TOKEN_SECRET": SECRET, "AUTH_RATE_LIMIT_ENABLED": "true", "TRUSTED_PROXY_CIDRS": "10.0.0.0/8"}
rl_app = create_app(CreateAppOptions(config=load_config(rl_env)))

# --- per email: login, from many different IPs, against one address
direct = [TestClient(rl_app, client=(f"203.0.113.{i}", 5000)) for i in range(1, 30)]
direct[0].post("/auth/register", json={"email": "target@example.com", "passcode": "right-pass"})
codes = [direct[i].post("/auth/login", json={"email": "target@example.com", "passcode": "wrong-pass"}).status_code for i in range(1, 11)]
expect(codes == [401] * 10, f"A5: 10 bad logins per email per window are answered normally: {codes}")
r = direct[11].post("/auth/login", json={"email": "Target@Example.com ", "passcode": "wrong-pass"})
expect(r.status_code == 429, f"A5: the 11th login for that email (case/space-normalised) is 429 even from a fresh IP: {r.status_code}")
expect(r.json() == {"error": {"code": "rate_limited", "message": r.json()["error"]["message"]}}, f"A5: 429 uses the app's error shape: {r.json()}")
r = direct[12].post("/auth/login", json={"email": "other@example.com", "passcode": "wrong-pass"})
expect(r.status_code == 401, "A5: another email from a fresh IP is unaffected")

# --- per IP: one IP spraying many emails
sprayer = TestClient(rl_app, client=("198.51.100.7", 5000))
codes = [sprayer.post("/auth/login", json={"email": f"spray{i}@example.com", "passcode": "nope-nope"}).status_code for i in range(20)]
expect(codes[:10] == [401] * 10 and codes[10:] == [429] * 10, f"A5: 10 logins per IP per minute, then 429: {codes}")

# --- X-Forwarded-For is honoured only from a trusted proxy
proxy = TestClient(rl_app, client=("10.0.0.2", 5000))
codes = [
    proxy.post("/auth/login", json={"email": f"xff{i}@example.com", "passcode": "nope-nope"}, headers={"X-Forwarded-For": f"192.0.2.{i}"}).status_code
    for i in range(15)
]
expect(codes == [401] * 15, f"A5: behind the trusted proxy each forwarded client gets its own bucket: {codes}")
spoof = TestClient(rl_app, client=("198.51.100.99", 5000))
codes = [
    spoof.post("/auth/login", json={"email": f"sp{i}@example.com", "passcode": "nope-nope"}, headers={"X-Forwarded-For": f"192.0.2.{100 + i}"}).status_code
    for i in range(12)
]
expect(codes[-1] == 429, f"A5: an untrusted peer cannot dodge the per-IP limit by rotating X-Forwarded-For: {codes}")

# --- register and reset routes
reg = TestClient(rl_app, client=("198.51.100.20", 5000))
codes = [reg.post("/auth/register", json={"email": f"new{i}@example.com", "passcode": "hunter22"}).status_code for i in range(22)]
expect(codes[:20] == [201] * 20 and codes[20:] == [429, 429], f"A5: register is 20 per IP per hour: {codes}")
rst = TestClient(rl_app, client=("198.51.100.30", 5000))
codes = [rst.post("/auth/reset-passcode/request", json={"email": "target@example.com"}).status_code for i in range(6)]
expect(codes[:5] == [202] * 5 and codes[5] == 429, f"A5: reset requests are 5 per email per hour: {codes}")
cfm = TestClient(rl_app, client=("198.51.100.40", 5000))
codes = [cfm.post("/auth/reset-passcode/confirm", json={"token": f"t{i}", "passcode": "hunter22"}).status_code for i in range(12)]
expect(codes[:10] == [400] * 10 and codes[10:] == [429, 429], f"A5: reset confirm is 10 per IP per 15 minutes: {codes}")

# --- the limiter is skipped entirely when disabled (default in test)
plain = TestClient(create_app(CreateAppOptions(config=load_config({"NODE_ENV": "test", "AUTH_TOKEN_SECRET": SECRET}))))
codes = {plain.post("/auth/login", json={"email": "x@example.com", "passcode": "nope-nope"}).status_code for _ in range(15)}
expect(codes == {401}, "A5: a test-mode app without the flag never answers 429")

# --- client_ip unit cases
from app.http.rate_limit import client_ip  # noqa: E402


class _Req:
    def __init__(self, host: Optional[str], xff: Optional[str]) -> None:
        self.client = type("C", (), {"host": host})() if host is not None else None
        self.headers = {"x-forwarded-for": xff} if xff is not None else {}


trusted = ["10.0.0.0/8", "127.0.0.0/8"]
expect(client_ip(_Req("10.0.0.2", "192.0.2.1"), trusted) == "192.0.2.1", "client_ip: trusted peer -> forwarded client")
expect(client_ip(_Req("10.0.0.2", "6.6.6.6, 192.0.2.1"), trusted) == "192.0.2.1", "client_ip: the right-most untrusted hop wins over a client-supplied prefix")
expect(client_ip(_Req("10.0.0.2", "192.0.2.1, 10.0.0.9"), trusted) == "192.0.2.1", "client_ip: trusted hops are skipped from the right")
expect(client_ip(_Req("10.0.0.2", "garbage"), trusted) == "10.0.0.2", "client_ip: an unparseable header falls back to the peer")
expect(client_ip(_Req("10.0.0.2", None), trusted) == "10.0.0.2", "client_ip: no header -> the peer")
expect(client_ip(_Req("203.0.113.5", "192.0.2.1"), trusted) == "203.0.113.5", "client_ip: an untrusted peer's header is ignored")
expect(client_ip(_Req("testclient", "192.0.2.1"), trusted) == "testclient", "client_ip: a non-IP peer is used as-is and never trusted")
expect(client_ip(_Req(None, None), trusted) == "unknown", "client_ip: no peer at all")
expect(load_config(prod()).trusted_proxy_cidrs[0] == "127.0.0.0/8" and "172.16.0.0/12" in load_config(prod()).trusted_proxy_cidrs, "production trusts loopback + private ranges (Caddy's compose network) by default")
expect(raises(lambda: load_config({"NODE_ENV": "test", "TRUSTED_PROXY_CIDRS": "10.0.0.0/33"}), "TRUSTED_PROXY_CIDRS"), "a malformed TRUSTED_PROXY_CIDRS fails at load")

print("\nALL SECURITY SMOKE CHECKS PASSED")

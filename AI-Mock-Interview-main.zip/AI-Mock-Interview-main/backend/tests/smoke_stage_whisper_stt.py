"""Stage-gate test for the Whisper STT swap — faster-whisper in place of the
sherpa-onnx ASR path, plus VAD, silence trimming, the 15-second timeout, and
mic-vs-speaker source recognition.

The four sections mirror the four things that changed. Sections 1-3 run with no
model at all (they are pure functions over synthetic audio and text); section 4
loads the real models and is skipped with a clear message when they are absent,
so this file is useful on a machine that has neither.

Run: `python -m tests.smoke_stage_whisper_stt`
"""

from __future__ import annotations

import asyncio
import os
import time

os.environ["NODE_ENV"] = "test"
os.environ["AUTH_TOKEN_SECRET"] = "x" * 32

import numpy as np  # noqa: E402


def expect(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)
    print(f"OK: {msg}")


SR = 16_000


def tone(seconds: float, amp: float = 0.3, freq: float = 180.0) -> np.ndarray:
    t = np.arange(int(SR * seconds)) / SR
    return (amp * np.sin(2 * np.pi * freq * t)).astype(np.float32)


def hush(seconds: float, amp: float = 0.0005) -> np.ndarray:
    return np.random.default_rng(0).normal(0, amp, int(SR * seconds)).astype(np.float32)


# ==========================================================  1. VAD + silence
print("\n--- 1. VAD, silence measurement, trimming ---")

from app.tools.speech_service.vad import analyse, trim  # noqa: E402

signal = np.concatenate([hush(1.0), tone(1.5), hush(2.0)])
activity = analyse(signal, SR)

expect(activity.has_speech, "speech between two stretches of silence is found")
expect(abs(activity.leading_silence_ms - 1000) < 100, f"leading silence measured at ~1000ms, got {activity.leading_silence_ms}")
expect(abs(activity.trailing_silence_ms - 2000) < 100, f"trailing silence measured at ~2000ms, got {activity.trailing_silence_ms}")
expect(abs(activity.speech_ms - 1500) < 150, f"speech measured at ~1500ms, got {activity.speech_ms}")
expect(
    abs(activity.total_ms - (activity.speech_ms + activity.silence_ms)) < 40,
    "speech and silence account for the whole recording",
)
expect(0.3 < activity.speech_ratio < 0.4, f"speech ratio is ~0.33, got {activity.speech_ratio}")

trimmed = trim(signal, activity)
trimmed_ms = len(trimmed) / SR * 1000
expect(
    1500 < trimmed_ms < 2000,
    f"trimming leaves the speech plus a little padding ({trimmed_ms:.0f}ms of an original {len(signal) / SR * 1000:.0f}ms)",
)
expect(trimmed_ms < len(signal) / SR * 1000 * 0.5, "which is less than half the audio Whisper would otherwise decode")

expect(not analyse(hush(3.0), SR).has_speech, "three seconds of room tone is NOT speech")
expect(not analyse(np.zeros(SR * 2, dtype=np.float32), SR).has_speech, "digital silence is not speech")
expect(not analyse(np.zeros(0, dtype=np.float32), SR).has_speech, "an empty recording is handled, not crashed on")
expect(not analyse(np.zeros(10, dtype=np.float32), SR).has_speech, "a recording shorter than one frame is handled too")

# The threshold adapts, so a quiet headset is not mistaken for silence and a
# noisy room is not mistaken for speech.
quiet = np.concatenate([hush(0.5, amp=0.0002), tone(1.0, amp=0.02), hush(0.5, amp=0.0002)])
expect(analyse(quiet, SR).has_speech, "quiet speech over a quiet floor is still speech (the threshold adapts)")
noisy = hush(2.0, amp=0.02)
expect(not analyse(noisy, SR).has_speech, "steady room noise with no speech in it is still not speech")


# =====================================================  2. mic vs speaker
print("\n--- 2. sound source: microphone or speaker ---")

from app.tools.speech_service.source import classify  # noqa: E402

QUESTION = "Walk me through how you found which query needed the index."
DEADLINE_Q = "Tell me about a time you shipped something under deadline pressure."

expect(
    classify(transcript="anything here at all", device_label="Stereo Mix (Realtek High Definition Audio)").reject,
    "a loopback capture device is rejected outright — it IS system output, by definition",
)
expect(
    classify(transcript="something", device_label="Monitor of Built-in Audio Analog Stereo").reject,
    "a PulseAudio output monitor is recognised as a loopback too",
)
expect(
    classify(transcript="Walk me through how you found which query needed the index", spoken_recently=[QUESTION]).reject,
    "a recording of the question we just asked is rejected as speaker echo",
)
expect(
    classify(transcript="how you found which query needed the index", spoken_recently=[QUESTION]).reject,
    "so is a recording that caught only the TAIL of it — the common case, when recording starts before the question ends",
)
expect(
    classify(transcript="um walk me through how you found which query needed the index", spoken_recently=[QUESTION]).reject,
    "a stray recogniser filler does not break the match",
)

# The false positive that matters most: answering a question in its own terms
# is what answering a question looks like.
reusing = classify(transcript="We shipped the billing feature under deadline pressure", spoken_recently=[DEADLINE_Q])
expect(not reusing.reject, f"an answer that REUSES the question's vocabulary is not echo, got {reusing.source}")

real = classify(
    transcript="I pulled the slow query log and found the nightly aggregate was doing a sequential scan, so I added a partial index on status.",
    spoken_recently=[QUESTION],
)
expect(not real.reject, f"a real answer to the question is not echo, got {real.source}")
expect(
    classify(transcript="About four minutes.", spoken_recently=[QUESTION]).source == "unknown",
    "a transcript too short to compare is `unknown`, which means 'score it normally'",
)
expect(
    classify(transcript="I added a partial index on the status column.", device_hint="microphone").source == "microphone",
    "a microphone device with nothing suspicious in the transcript is a microphone",
)

# A client hint alone can raise suspicion but must not reject: the hint is
# candidate-controlled, and a mislabelled device would silently eat answers.
hinted = classify(transcript="I added a partial index on the status column here.", device_hint="speaker", spoken_recently=[QUESTION])
expect(hinted.source == "speaker" and not hinted.reject, "a `speaker` hint the transcript does not corroborate is reported, NOT rejected")
expect(classify(transcript="Some answer about databases and indexes.").source == "unknown", "no information at all is `unknown`, never a guess")


# ==================================================  3. config and timeout
print("\n--- 3. configuration: model, timeout, VAD ---")

from app.config import load_config  # noqa: E402
from app.tools.speech_service.whisper_provider import DEFAULT_TIMEOUT_SECONDS, WhisperSettings  # noqa: E402

config = load_config({"NODE_ENV": "test", "AUTH_TOKEN_SECRET": "x" * 32})
expect(config.stt_model == "tiny.en", f"the default STT model is whisper tiny.en, got {config.stt_model}")
expect(config.stt_timeout_seconds == 15.0, f"the default STT timeout is 15 seconds, got {config.stt_timeout_seconds}")
expect(config.stt_vad_filter is True, "VAD filtering is on by default")
expect(DEFAULT_TIMEOUT_SECONDS == 15.0, "and the provider's own default agrees with the config's")

overridden = load_config({"NODE_ENV": "test", "AUTH_TOKEN_SECRET": "x" * 32, "STT_TIMEOUT_SECONDS": "30", "STT_VAD_FILTER": "false", "STT_MODEL": "base.en"})
expect(overridden.stt_timeout_seconds == 30.0, "the timeout is overridable per deployment")
expect(overridden.stt_vad_filter is False, "so is the VAD filter")
expect(overridden.stt_model == "base.en", "so is the model size")

# The timeout is a real wall clock around the decode, not a value that is only
# passed along. Proven with a transcriber whose decode is deliberately slow.
from app.tools.speech_service.provider import TranscriptionFailed, encode_wav  # noqa: E402
from app.tools.speech_service.whisper_provider import WhisperTranscriber  # noqa: E402


class _SlowTranscriber(WhisperTranscriber):
    def _decode(self, samples: np.ndarray) -> str:
        time.sleep(5)
        return "this should never be returned"


slow = _SlowTranscriber(WhisperSettings(timeout_seconds=0.5))
slow._model = object()  # satisfies the "is a model loaded" guard; _decode is overridden
speech_wav = encode_wav(np.clip(np.concatenate([hush(0.2), tone(1.2), hush(0.2)]) * 32767, -32768, 32767).astype(np.int16), SR)
silence_wav = encode_wav(np.zeros(SR * 3, dtype=np.int16), SR)


async def _timeout_checks() -> None:
    """Timed INSIDE the event loop on purpose.

    Measuring around `asyncio.run` would measure loop shutdown instead: a
    CTranslate2 decode cannot be cancelled, so the abandoned thread runs to
    completion and `asyncio.run` joins it on the way out. What matters — and
    what a live gateway experiences, because its loop does not shut down
    between requests — is that the AWAIT returns at the deadline.
    """
    started = time.time()
    try:
        await slow.transcribe(speech_wav)
        raise AssertionError("a decode past the timeout should have raised")
    except TranscriptionFailed as err:
        elapsed = time.time() - started
        expect("limit" in str(err), f"a decode past the timeout raises TranscriptionFailed, got: {err}")
        expect(elapsed < 2, f"and the caller is released at the deadline rather than waiting the decode out ({elapsed:.1f}s)")

    # Silence is refused before the model is ever reached, so the slow decode
    # never even happens for it.
    started = time.time()
    try:
        await slow.transcribe(silence_wav)
        raise AssertionError("silence should have been refused")
    except TranscriptionFailed as err:
        expect("no speech detected" in str(err), f"silence is refused by the VAD gate, got: {err}")
        expect(time.time() - started < 1, "and refused BEFORE the decode — the model is never asked about silence")


asyncio.run(_timeout_checks())
slow.close()
expect(True, "an abandoned decode runs on its own dedicated executor, so it cannot starve the event loop's shared one")


# ===============================================  4. the real model, if present
print("\n--- 4. end to end with the real models ---")

from app.tools.speech_service.provider import decode_wav  # noqa: E402
from app.tools.speech_service.sherpa_provider import SherpaSpeechProvider  # noqa: E402

MODEL_DIR = os.environ.get("SPEECH_MODEL_DIR") or os.path.join(os.path.dirname(__file__), "..", "..", "models")
tts = SherpaSpeechProvider.create(model_dir=MODEL_DIR)
asr = WhisperTranscriber.create(WhisperSettings())

if not tts or not asr:
    print(f"SKIPPED: needs the VITS voice in {MODEL_DIR} (tts={tts is not None}) and faster-whisper (asr={asr is not None}).")
    print("         Sections 1-3 above cover everything that does not need a model.")
else:
    expect(asr.name == "faster-whisper", f"the transcriber is faster-whisper, not sherpa-onnx — got {asr.name}")

    SPOKEN = "I led the migration of our billing service to a distributed architecture."
    synthesised = asyncio.run(tts.synthesize(SPOKEN))
    decoded = decode_wav(synthesised.audio)

    # Padded at both ends: the case trimming exists for, and the case Whisper
    # hallucinates into when it is not trimmed.
    padded = np.concatenate([np.zeros(decoded.sample_rate * 2, dtype=np.float32), decoded.samples, np.zeros(decoded.sample_rate * 3, dtype=np.float32)])
    wav = encode_wav(np.clip(padded * 32767, -32768, 32767).astype(np.int16), decoded.sample_rate)

    result = asyncio.run(asr.transcribe(wav))
    detail = asr.last_detail
    words = set(result.transcript.lower().replace(".", "").split())
    expect("migration" in words and "billing" in words, f"whisper transcribes real speech: {result.transcript!r}")
    expect(result.confidence >= 0.6, f"a clean recording clears the confidence floor, got {result.confidence}")
    expect(detail is not None and detail.trimmed_ms < detail.activity.total_ms * 0.7, f"5s of padding was trimmed before decode ({detail.trimmed_ms:.0f}ms of {detail.activity.total_ms:.0f}ms)")
    expect(detail.decode_ms < 15_000, f"and the decode finished inside the 15s budget ({detail.decode_ms:.0f}ms)")

    # The whole reason the VAD gate exists: tiny.en answers silence with a
    # confident invented word rather than an empty string.
    try:
        asyncio.run(asr.transcribe(encode_wav(np.zeros(SR * 3, dtype=np.int16), SR)))
        raise AssertionError("silence produced a transcript from the real model")
    except TranscriptionFailed as err:
        expect("no speech detected" in str(err), "the real model is never asked about silence — no invented word can reach the harness")

    # And the source check against a real transcript of our own voice.
    echo = classify(transcript=result.transcript, spoken_recently=[SPOKEN])
    expect(echo.reject, "a real recording of our own synthesised question is caught as speaker echo")

print("\nALL WHISPER-STT CHECKS PASSED")

"""Manual smoke test for F7 — Speech Service (TTS/STT). Exercises the REAL
sherpa-onnx models present under /models (VITS TTS + Whisper ASR), plus the
fixture provider's deterministic round trip and low-confidence path."""

from __future__ import annotations

import asyncio

from app.tools.speech_service.fixture_provider import FixtureSpeechProvider, attenuate
from app.tools.speech_service.sherpa_provider import SherpaSpeechProvider
from app.paths import from_repo_root


def expect(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)
    print(f"OK: {msg}")


async def main() -> None:
    # ---- fixture provider: deterministic round trip ----
    fixture = FixtureSpeechProvider()
    synthesized = await fixture.synthesize("Tell me about a challenging project.")
    expect(synthesized.audio[:4] == b"RIFF", "fixture WAV has a RIFF header")
    expect(synthesized.duration_ms > 0, "fixture synthesis reports a positive duration")

    transcribed = await fixture.transcribe(synthesized.audio)
    expect(transcribed.transcript == "Tell me about a challenging project.", f"fixture round-trips its own transcript verbatim: {transcribed.transcript!r}")
    expect(transcribed.confidence >= 0.6, f"clean fixture audio clears the confidence floor: {transcribed.confidence}")

    # attenuated audio must drop below the confidence floor
    quiet = attenuate(synthesized.audio, 0.05)
    quiet_result = await fixture.transcribe(quiet)
    expect(quiet_result.confidence < 0.6, f"attenuated audio falls below the confidence floor: {quiet_result.confidence}")

    # audio the fixture did not produce must fail loudly, not guess
    from app.tools.speech_service.provider import TranscriptionFailed, encode_wav
    import numpy as np

    foreign_wav = encode_wav(np.zeros(1600, dtype=np.int16), 16000)
    try:
        await fixture.transcribe(foreign_wav)
        raise AssertionError("fixture should refuse to transcribe audio it did not synthesise")
    except TranscriptionFailed:
        print("OK: fixture refuses to transcribe external audio rather than guessing")

    # ---- real sherpa-onnx models ----
    model_dir = from_repo_root("models")
    provider = SherpaSpeechProvider.create(model_dir=model_dir)
    expect(provider is not None, f"real sherpa-onnx models load from {model_dir}")

    real_synth = await provider.synthesize("Tell me about a time you disagreed with a teammate.")
    expect(real_synth.audio[:4] == b"RIFF", "real TTS output is a valid WAV")
    expect(real_synth.sample_rate > 0 and real_synth.duration_ms > 200, f"real TTS produced audible output: {real_synth.duration_ms}ms @ {real_synth.sample_rate}Hz")

    real_transcript = await provider.transcribe(real_synth.audio)
    print(f"  real ASR transcript of real TTS output: {real_transcript.transcript!r} (confidence {real_transcript.confidence})")
    words_said = set(w.strip(".,?!").lower() for w in real_transcript.transcript.split())
    words_expected = {"disagreed", "teammate", "time"}
    overlap = words_said & words_expected
    expect(len(overlap) >= 1, f"round-tripping real TTS through real ASR recovers at least one expected word, got {words_said}")

    print("\nALL F7 SMOKE CHECKS PASSED")


asyncio.run(main())

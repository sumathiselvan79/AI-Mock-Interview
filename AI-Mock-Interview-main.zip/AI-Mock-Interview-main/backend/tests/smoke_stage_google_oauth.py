"""Manual smoke test for F12's Google OAuth slice — GET /auth/google/start +
GET /auth/google/callback. ~ apps/gateway/tests/google-auth.test.ts.

The goal's test criteria there: "a tampered state is rejected and the
resulting token's role comes from the allowlist, not from Google." Both are
tested against the real route wiring; only the network call to Google's
token endpoint is swapped for a fake (via `CreateAppOptions.google_auth_client`
— the same seam `speech_provider_choice`/`llm_model` already use in this
suite). Run directly with the venv's python, not pytest."""

from __future__ import annotations

import base64
import json
import os
import time
from dataclasses import dataclass
from typing import Optional
from urllib.parse import parse_qs, urlparse

os.environ["NODE_ENV"] = "test"
os.environ["AUTH_TOKEN_SECRET"] = "x" * 32

from fastapi.testclient import TestClient  # noqa: E402

from app.auth.google import GoogleTokenResponse  # noqa: E402
from app.config import load_config  # noqa: E402
from app.gateway import CreateAppOptions, create_app  # noqa: E402

CLIENT_ID = "test-client-id"


def expect(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)
    print(f"OK: {msg}")


def b64(obj: dict) -> str:
    return base64.urlsafe_b64encode(json.dumps(obj).encode()).rstrip(b"=").decode()


def fake_id_token(claims: dict) -> str:
    return f"{b64({'alg': 'none', 'typ': 'JWT'})}.{b64(claims)}.fake-signature"


def valid_claims(**overrides) -> dict:
    base = {
        "iss": "https://accounts.google.com",
        "aud": CLIENT_ID,
        "sub": "google-subject-123",
        "email": "candidate@example.com",
        "email_verified": True,
        "exp": int(time.time()) + 3600,
    }
    base.update(overrides)
    return base


@dataclass
class FakeGoogleClient:
    id_token: str

    def create_authorization_url(self, state: str, code_verifier: str, scopes: list[str]) -> str:
        return "https://accounts.google.com/o/oauth2/v2/auth?fake=1"

    async def validate_authorization_code(self, code: str, code_verifier: str) -> GoogleTokenResponse:
        return GoogleTokenResponse(id_token=self.id_token)


def build_app(*, admin_email_allowlist: Optional[list[str]] = None, google_client=None, client_id: str = CLIENT_ID):
    config = load_config(
        {
            "NODE_ENV": "test",
            "AUTH_TOKEN_SECRET": "x" * 32,
            "GOOGLE_CLIENT_ID": client_id,
            "GOOGLE_CLIENT_SECRET": "s",
            "GOOGLE_REDIRECT_URI": "http://localhost/cb",
            "ADMIN_EMAIL_ALLOWLIST": ",".join(admin_email_allowlist or []),
        }
    )
    app = create_app(CreateAppOptions(config=config, google_auth_client=google_client))
    return TestClient(app)


def parse_callback_redirect(location: str) -> dict:
    fragment = urlparse(location).fragment
    params = parse_qs(fragment)
    return {"token": params.get("token", [""])[0], "role": params.get("role", [""])[0]}


def decode_token_claims(token: str) -> dict:
    _, body, _ = token.split(".")
    padded = body + "=" * (-len(body) % 4)
    return json.loads(base64.urlsafe_b64decode(padded))


# ------------------------------------------------------------------- /start
client = build_app()
r = client.get("/auth/google/start", follow_redirects=False)
expect(r.status_code == 302, f"/auth/google/start redirects: {r.status_code}")
expect("accounts.google.com" in r.headers["location"], "redirects to Google")
expect("mia_oauth_state" in r.cookies and "mia_oauth_verifier" in r.cookies, "sets state/PKCE cookies")

# without a configured google client, no routes are registered at all
unconfigured = TestClient(create_app(CreateAppOptions(config=load_config({"NODE_ENV": "test", "AUTH_TOKEN_SECRET": "x" * 32}))))
r = unconfigured.get("/auth/google/start", follow_redirects=False)
expect(r.status_code == 404, "an unconfigured deployment gets no /auth/google/* routes at all")

# --------------------------------------------------------- CSRF/state handling
client = build_app()
r = client.get("/auth/google/callback", params={"code": "abc", "state": "whatever"})
expect(r.status_code == 400, "rejects a callback with no OAuth flow in progress (no cookies)")

client = build_app()
client.cookies.set("mia_oauth_state", "real-state-from-start")
client.cookies.set("mia_oauth_verifier", "real-verifier")
r = client.get("/auth/google/callback", params={"code": "abc", "state": "attacker-supplied-state"})
expect(r.status_code == 400 and r.json()["error"]["code"] == "invalid_oauth_state", f"rejects a tampered state: {r.text}")

# ------------------------------------------------------------- role resolution
id_token = fake_id_token(valid_claims(email="attacker@example.com", role="admin"))
client = build_app(admin_email_allowlist=[], google_client=FakeGoogleClient(id_token))
start = client.get("/auth/google/start", follow_redirects=False)
res = client.get(
    "/auth/google/callback", params={"code": "fake-code", "state": start.cookies["mia_oauth_state"]}, follow_redirects=False
)
expect(res.status_code == 302, f"callback redirects on success: {res.status_code} {res.text}")
parsed = parse_callback_redirect(res.headers["location"])
expect(parsed["role"] == "student", "ignores a bogus 'role' claim on the ID token; defaults an unlisted email to student")
expect(decode_token_claims(parsed["token"])["email"] == "attacker@example.com", "token carries the verified email")

id_token = fake_id_token(valid_claims(email="boss@example.com", role="student"))
client = build_app(admin_email_allowlist=["boss@example.com"], google_client=FakeGoogleClient(id_token))
start = client.get("/auth/google/start", follow_redirects=False)
res = client.get(
    "/auth/google/callback", params={"code": "fake-code", "state": start.cookies["mia_oauth_state"]}, follow_redirects=False
)
parsed = parse_callback_redirect(res.headers["location"])
expect(parsed["role"] == "admin", "grants admin only when the verified email is on the allowlist, not from the token")
admin_check = client.get("/admin/reports", headers={"Authorization": f"Bearer {parsed['token']}"})
expect(admin_check.status_code == 200, f"the minted admin token actually works on an admin route: {admin_check.status_code}")

id_token = fake_id_token(valid_claims(aud="someone-elses-client-id"))
client = build_app(google_client=FakeGoogleClient(id_token))
start = client.get("/auth/google/start", follow_redirects=False)
res = client.get("/auth/google/callback", params={"code": "fake-code", "state": start.cookies["mia_oauth_state"]})
expect(res.status_code == 400 and res.json()["error"]["code"] == "invalid_id_token", f"rejects the wrong audience: {res.text}")

id_token = fake_id_token(valid_claims(email_verified=False))
client = build_app(google_client=FakeGoogleClient(id_token))
start = client.get("/auth/google/start", follow_redirects=False)
res = client.get("/auth/google/callback", params={"code": "fake-code", "state": start.cookies["mia_oauth_state"]})
expect(res.status_code == 400, "rejects an ID token whose email Google has not verified")

# --------------------------------------------------------- OAuth profile snapshot
id_token = fake_id_token(
    valid_claims(email="candidate@example.com", sub="google-subject-abc", name="Candidate Name", picture="https://example.com/avatar.png")
)
config = load_config(
    {
        "NODE_ENV": "test",
        "AUTH_TOKEN_SECRET": "x" * 32,
        "GOOGLE_CLIENT_ID": CLIENT_ID,
        "GOOGLE_CLIENT_SECRET": "s",
        "GOOGLE_REDIRECT_URI": "http://localhost/cb",
    }
)
app = create_app(CreateAppOptions(config=config, google_auth_client=FakeGoogleClient(id_token)))
client = TestClient(app)
start = client.get("/auth/google/start", follow_redirects=False)
res = client.get(
    "/auth/google/callback", params={"code": "fake-code", "state": start.cookies["mia_oauth_state"]}, follow_redirects=False
)
parsed = parse_callback_redirect(res.headers["location"])
user_id = decode_token_claims(parsed["token"])["sub"]

import asyncio  # noqa: E402

profile = asyncio.run(app.state.storage.oauth_profiles.get_by_user_id(user_id))
expect(profile is not None, "the OAuth profile snapshot was stored, keyed to the logged-in user")
expect(
    profile.provider == "google"
    and profile.provider_subject == "google-subject-abc"
    and profile.email == "candidate@example.com"
    and profile.name == "Candidate Name"
    and profile.avatar_url == "https://example.com/avatar.png",
    f"stores name/picture/subject from the ID token: {profile}",
)

id_token2 = fake_id_token(valid_claims(sub="google-subject-minimal"))
app2 = create_app(CreateAppOptions(config=config, google_auth_client=FakeGoogleClient(id_token2)))
client2 = TestClient(app2)
start2 = client2.get("/auth/google/start", follow_redirects=False)
res2 = client2.get(
    "/auth/google/callback", params={"code": "fake-code", "state": start2.cookies["mia_oauth_state"]}, follow_redirects=False
)
parsed2 = parse_callback_redirect(res2.headers["location"])
user_id2 = decode_token_claims(parsed2["token"])["sub"]
profile2 = asyncio.run(app2.state.storage.oauth_profiles.get_by_user_id(user_id2))
expect(
    profile2 is not None and profile2.provider_subject == "google-subject-minimal" and profile2.name is None and profile2.avatar_url is None,
    "still logs in successfully with no name/picture claims (profile scope declined)",
)

print("\nALL F12 GOOGLE OAUTH SMOKE CHECKS PASSED")

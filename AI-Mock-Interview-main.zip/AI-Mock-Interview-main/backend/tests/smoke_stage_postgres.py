"""Manual smoke test for F11 — the real Postgres + Redis storage drivers.

Re-runs the same core flow `smoke_stage1.py` (session lifecycle) and
`smoke_stage3_question_loop.py` (full question loop) exercise against the
memory driver, this time against `STORAGE_DRIVER=postgres` with a real
Postgres (`infra/docker-compose.yml`, migrations already applied via
`python -m app.storage.migrate`) and a real Redis, so a schema/query mistake
in `storage/postgres.py`/`interview_postgres.py`/`redis_store.py` shows up
here rather than only in production. Run directly with the venv's python,
not pytest.

Requires `docker compose -f infra/docker-compose.yml up -d` to have been run
first (see FASTAPI_MIGRATION.md's F11 notes).
"""

from __future__ import annotations

import base64
import os
import uuid

os.environ["NODE_ENV"] = "test"
os.environ["AUTH_TOKEN_SECRET"] = "x" * 32
os.environ["STORAGE_DRIVER"] = "postgres"
os.environ.setdefault("DATABASE_URL", "postgres://mia:mia@localhost:5432/mia")
os.environ.setdefault("REDIS_URL", "redis://localhost:6380")

from fastapi.testclient import TestClient  # noqa: E402

from app.gateway import create_app  # noqa: E402

app = create_app()
# Entered manually (rather than a `with` block, to avoid re-indenting the
# whole script) so FastAPI's startup lifespan actually runs — that's what
# calls `storage.connect()` and binds the Postgres pool / Redis client to
# TestClient's event loop. Without it every query fails with asyncpg's
# "another operation is in progress" (see `create_storage`'s docstring).
client = TestClient(app).__enter__()


def expect(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)
    print(f"OK: {msg}")


expect(app.state.config.storage_driver == "postgres", "app booted against the real postgres+redis driver")

# -------------------------------------------------------------- users/sessions
email = f"pg-smoke-{uuid.uuid4().hex[:8]}@example.com"
r = client.post("/auth/register", json={"email": email, "passcode": "hunter22"})
expect(r.status_code == 201, f"register persists a real users row: {r.status_code} {r.text}")
token = r.json()["token"]
headers = {"Authorization": f"Bearer {token}"}

# a second registration with the same email hits the real UNIQUE constraint
r_dup = client.post("/auth/register", json={"email": email, "passcode": "hunter22"})
expect(r_dup.status_code == 409, f"duplicate email is rejected via the real unique index: {r_dup.status_code}")

r_login = client.post("/auth/login", json={"email": email, "passcode": "hunter22"})
expect(r_login.status_code == 200, "login round-trips the scrypt-hashed passcode through a real row")

r = client.post(
    "/sessions",
    json={"role": "backend engineer", "job_description": "distributed systems and databases", "question_budget": 3},
    headers=headers,
)
expect(r.status_code == 201, f"session created in Postgres: {r.status_code} {r.text}")
session_id = r.json()["session_id"]

r = client.get(f"/sessions/{session_id}", headers=headers)
expect(r.status_code == 200 and r.json()["session"]["state"] == "CREATED", "session round-trips from Postgres")

r = client.post(f"/sessions/{session_id}/advance", json={"to": "CONFIG"}, headers=headers)
expect(r.status_code == 200, "advance to CONFIG — exercises the real harness-agent-only state write + transactional transition log")

# -------------------------------------------------------------------- resume
RESUME_TEXT = """
Jane Doe

Experience
Senior Backend Engineer, Northwind Systems (2020 - Present)
Operated a large PostgreSQL fleet and led the migration to Kubernetes.

Education
B.S. Computer Science, State University, 2018

Skills
PostgreSQL, Kubernetes, Go, Kafka
""".strip()

r = client.post(
    f"/sessions/{session_id}/resume",
    json={"filename": "resume.txt", "content_type": "text/plain", "data_base64": base64.b64encode(RESUME_TEXT.encode()).decode()},
    headers=headers,
)
expect(r.status_code == 201, f"resume profiled and candidate_profile/jd_fit JSONB columns round-trip: {r.status_code} {r.text}")
expect(len(r.json()["topic_relevance"]) > 0, "topic_relevance survives the Postgres JSONB round trip")

r = client.get(f"/sessions/{session_id}", headers=headers)
expect(r.json()["session"]["candidateProfile"] is not None, "candidate_profile JSONB column hydrates back into the session")

# ------------------------------------------------------------- question loop
r = client.post(f"/sessions/{session_id}/advance", json={"to": "TELEMETRY_CHECK"}, headers=headers)
expect(r.status_code == 200, "advance to TELEMETRY_CHECK")

r = client.post(f"/sessions/{session_id}/telemetry-check", json={"mic_ok": True, "speaker_ok": True}, headers=headers)
expect(r.status_code == 200, "telemetry check passed — Redis-backed live store round trip")

r = client.post(f"/sessions/{session_id}/begin", headers=headers)
expect(r.status_code == 200 and r.json()["state"] == "QUESTION_LOOP", f"begin interview succeeds and enters QUESTION_LOOP: {r.text}")

ANSWER = (
    "I led the migration of our billing service to a distributed microservices architecture on Kubernetes "
    "because the monolith couldn't scale past 500 requests per second. We considered staying monolithic but "
    "rejected it since the billing team needed independent deploys. As a result, deploy frequency went from "
    "weekly to daily and p99 latency dropped by 40%."
)

asked_count = 0
for turn in range(1, 7):  # budget is 3 content questions + 1 fixed intro turn
    r = client.get(f"/sessions/{session_id}/questions/next", headers=headers)
    expect(r.status_code == 200, f"turn {turn}: next question read from Postgres ({r.text})")
    qbody = r.json()
    if qbody["done"]:
        expect(qbody["asked_count"] == 3, f"loop ends after budget of 3 content questions, got {qbody['asked_count']}")
        break

    question = qbody["question"]
    if question["topic"] != "introduction":
        asked_count += 1
    r = client.post(
        f"/sessions/{session_id}/answers",
        json={"question_id": question["id"], "transcript": ANSWER},
        headers=headers,
    )
    expect(r.status_code == 201, f"turn {turn}: answer + evaluation persisted as real rows ({r.text})")
    abody = r.json()
    expect(abody["evaluation"] is not None and 0 <= abody["evaluation"]["score"] <= 5, f"turn {turn}: scored evaluation round-trips")

expect(asked_count == 3, f"question budget of 3 content questions enforced against real rows, asked {asked_count}")

r = client.get(f"/sessions/{session_id}", headers=headers)
expect(r.json()["session"]["state"] == "WRAP_UP", f"auto-advanced to WRAP_UP once budget spent: {r.json()['session']['state']}")

transitions = client.get(f"/sessions/{session_id}/transitions", headers=headers).json()["transitions"]
expected_states = ["CONFIG", "TELEMETRY_CHECK", "CALIBRATION", "QUESTION_LOOP", "WRAP_UP"]
actual_states = [t["toState"] for t in transitions]
expect(actual_states == expected_states, f"session_state_transitions audit trail is real rows, not an in-memory list: {actual_states}")

transcript = client.get(f"/sessions/{session_id}/transcript", headers=headers).json()
expect(len(transcript["transcript"]) == 4, f"transcript joins questions/answers/evaluations across three real tables (intro + 3 content): {len(transcript['transcript'])}")
expect(all(entry["answer"] is not None for entry in transcript["transcript"]), "every question in the transcript has a persisted answer")
expect(all(len(entry["evaluations"]) >= 1 for entry in transcript["transcript"]), "every answer has at least one persisted evaluation")

print("\nALL F11 POSTGRES+REDIS SMOKE CHECKS PASSED")

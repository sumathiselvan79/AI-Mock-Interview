# Stage 5 — LLM-backed agents, structured tool calling, session archival

Closes the Stage 5 checklist in [`TRACKING.md`](../TRACKING.md). Design is
`INSTRUCTIONS.md §11`; the behavioural constraints are the "(Stage 5 addition)"
entries throughout `soul.md`.

## What exists now

| Piece | Where | Notes |
|---|---|---|
| `packages/llm-client` | `packages/llm-client` | `ToolDefinition`, `PromptRegistry`, `createChatModel`, `groundingCheck`, `structuredCall` |
| Zod output schemas | `packages/mcp-schemas/src/llm-schemas.ts` | One definition per LLM call; the Ajv registry compiles `z.toJSONSchema()` of the same objects |
| LLM Provider Tool | `mcp-servers/tool-llm-provider` | `generate_structured`, registered with the MCP Gateway like every other tool |
| Resume Service Agent | `agents/resume-service-agent` | Grounded `jd_fit.rationale` + JD-anchored `topicRelevance`, `promptVersion` stamped |
| Question Agent | `agents/question-agent` | Question text + `reference_answer` generated together; selection stays deterministic |
| Follow-up Question Agent | `agents/followup-agent` | Score-then-decide; `score_follow_up_exchange` for an answered probe |
| Memory Agent working memory | `agents/memory-agent`, `apps/gateway/src/storage/{memory,redis}.ts` | Session-scoped scratch for the reference answer and the in-progress `jd_fit` |
| Archive job | `agents/harness-agent/src/archive.ts` | Compiles one `SessionArchive`, triggered at `COMPLETED` after retention |
| Archive store | `apps/gateway/src/storage/archive.ts` | `SessionArchiveStore` port; memory + Supabase-Postgres drivers |
| Archive API | `apps/gateway/src/http/routes/admin.ts` | `GET /admin/archives`, `/:sessionId`, `/:sessionId/download`, all audited |
| Profile fields | `apps/web/app/signup`, `apps/web/app/home`, `PATCH /me/profile` | `fullName`/`department`/`programYear`; archiving refuses without a name |
| Stateless-reducer rule | `packages/agent-lint` | `npm run lint:agents`, wired into `npm run lint` |

## Decisions worth knowing about

**Selection stayed deterministic; only the words are generated.** This is the
single most consequential decision in the stage. §4.3's quota rules, the
per-topic cap, the progressive difficulty curve and the Stage-2 gap detector
all still run exactly as they did — the model receives an already-chosen slot
and writes the question for it, or receives an already-detected gap and phrases
the probe for it. Two things follow. Balanced coverage stays a property of the
system rather than of a model's mood, which is what `soul.md §"Balanced
coverage"` actually asks for. And every Stage 2–4 gate test remains meaningful
instead of becoming a test of whatever the provider felt like returning that
morning.

**There is one schema per LLM call, not two.** §11.5 asks for the MCP contract
and the function-calling schema to be "literally the same object, not two
hand-synced copies". The Zod schemas live in `packages/mcp-schemas`, and the
Ajv registry the gateway validates against compiles `z.toJSONSchema()` of those
same objects at load time. So `structuredCall` re-validating a response and the
gateway validating an MCP payload are checking one definition. Writing the JSON
Schema out by hand alongside the Zod one would have satisfied the sentence and
missed the point.

**The grounding check is a substring match first, and that is deliberate.**
Every generated claim is shaped as `{ value, evidence }`, where `evidence` must
be a verbatim slice of a source document. The cheap pass is a whitespace-
normalised `includes`. It is strict on purpose: a model that reflowed a quote
across lines has still quoted it, a model that changed the words has not. The
expensive LLM pass exists (§11.3) but is off by default, because it costs a
second round trip inside a latency budget and the conservative reading of an
unverifiable claim is the one `soul.md` asks for — drop it, do not soften it.

This is also what turns §4.4's "a follow-up must target a specific gap or
claim in the answer, never a generic 'tell me more'" from a style note into
something enforced: `targeted_gap.evidence` has to appear in the transcript, so
a probe that cannot quote what it is probing fails grounding and the agent
falls back.

**The reference answer never touches a table.** It is a sibling of `question`
on the wire, not a field on it, and the harness routes it to the Memory Agent's
session-scoped store and nowhere else. It is never persisted on `Question`,
never synthesized to speech, never in the transcript, and dropped at
`COMPLETED`. `apps/gateway/tests/stage5-llm-and-archival.test.ts` asserts all
five of those, including that the string does not appear anywhere in the
question payload the frontend receives.

**The Eval Tool's reference answer can only raise a score.** `soul.md` requires
that "a candidate who reaches the same competence by a different route must
score the same as one who happens to match the reference answer's wording". A
symmetric blend of rubric score and reference coverage would quietly punish the
different route for not matching wording, so the reference contribution is
`max(ratio, ratio * 0.8 + coverage * 0.2)` — a floor-raiser and nothing else.
When no reference answer is supplied, which is every Stage 1–4 call path, the
arithmetic is untouched.

**Archive safety is expressed as ordering, not as a second redaction pass.**
`compileSessionArchive` contains no redaction logic and should not gain any. It
runs immediately after the Stage 4 retention job and reads the primary record
as-is, so whatever §8 already removed is simply not there to copy. The
guarantee — "the archive is never more permissive than the primary record at
write time" — therefore holds without two redaction implementations that could
drift apart. A redaction step inside the archive job would be a second thing to
keep correct, and the first time it fell behind, the archive would become the
back door `soul.md §5` forbids.

**`pg`, not `@supabase/supabase-js`.** §8's "Archive access boundary" is
explicit that Supabase's own auth and RLS are *not* the access control for this
data — the gateway's admin RBAC is, so there is exactly one place deciding who
can read candidate records. `supabase-js` exists to carry an end-user identity
into row-level policies, which is precisely the model §8 rules out. A
server-side Postgres connection over the service-role credential expresses the
intended boundary directly, is the shape §11.6's SQL is written in, and adds no
dependency. RLS is still enabled on the table with no permissive policy, as
defence in depth for a future non-service-role credential.

**Two migration directories, two commands.** `npm run db:migrate` applies
`migrations/*.sql` to the primary Postgres; `npm run db:migrate:archive`
applies `migrations/supabase/*.sql` to `SUPABASE_DB_URL`. Neither can reach the
other's database, which matters more than the small duplication: filing the
archive table into the database the retention job prunes would defeat the
reason for having a separate one.

**Every failure path routes to Stage 2, and none of them throws at a
candidate.** Provider unavailable, no schema-valid response after the retry, a
required claim failing grounding, a generated topic that is not on the plan —
all four return the deterministic result the agent already computed. A
candidate never sees an interview stop because a third-party API was slow, and
`jd_fit` never loses its score because the explanation could not be grounded.

**The stateless-reducer rule is a TypeScript AST check, not ESLint.**
`TRACKING.md` asks for "a custom ESLint (or equivalent) rule". The repo has no
ESLint install, and adding ESLint plus typescript-eslint to enforce one rule is
a large dependency for a small job when the compiler API is already a
dependency. It flags module-scope `let`/`var` and module-scope
`new Map()`/`new Set()`/array/object literals under `/agents/**`, and accepts
`Readonly<...>` / `readonly T[]` / `Object.freeze` / `as const`, which is the
idiom this repo already used. Running it found five module-scope literals in
Stage 1–4 agents; all were static config tables, so they are annotated
`Readonly` rather than exempted.

## The tracing gate is a data-sharing gate

`packages/llm-client/src/tracing.ts` does not merely decline to set LangChain's
tracing variables when tracing is off — it deletes them. LangChain reads
`LANGSMITH_TRACING` / `LANGCHAIN_TRACING_V2` from the ambient environment on its
own, so a value inherited from a shell profile or a base container image would
otherwise start shipping resume, JD and transcript text to a third party with
nothing in this repo saying so. Tracing requires `NODE_ENV=development` **and**
`LANGSMITH_OPT_IN=true` **and** an API key, all three.

## Known limitations carried forward

- **No real provider call has been made from this repo.** Everything runs
  against the deterministic fixture model, which produces schema-valid,
  genuinely grounded output built from the caller's own source documents — the
  same philosophy as `FixtureSpeechProvider`. The Groq/Bedrock/OpenRouter paths
  are wired and typed but unexercised; the first real run should be watched for
  providers that ignore their structured-output contract, which is what the
  retry and the `StructuredCallError` fallback exist for.
- **The expensive grounding pass is implemented but unused by default.** No
  agent currently passes `llm_grounding_fallback: true`. Turning it on is a
  per-call flag, and it should be measured against the §9 budget before being
  made a default.
- **The archive is never read back into an interview**, and nothing yet prunes
  it. §11.4 calls it a copy for admin export rather than a second source of
  truth; a retention policy for the archive itself is not specified and was not
  invented here.

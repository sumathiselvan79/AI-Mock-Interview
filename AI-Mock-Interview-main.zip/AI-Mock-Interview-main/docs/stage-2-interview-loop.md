# Stage 2 — Core interview loop: what was built and why

Closes the Stage 2 checklist in [`TRACKING.md`](../TRACKING.md): a full text-only
interview — resume in, calibrated and quota-capped questions out, follow-ups,
timing, memory. No voice, no coding round.

## What exists now

| Piece | Where | Notes |
|---|---|---|
| Resume Parser Tool | `mcp-servers/tool-resume-parser` | Real extraction for pdf / docx / txt / md; `unsupported_format` and `parse_failed` are surfaced, never guessed around |
| Resume Service Agent | `agents/resume-service-agent` | `topic_relevance[]` with verbatim evidence, `jd_fit`, JD gaps as topics, hard delete |
| Eval Tool | `mcp-servers/tool-eval` | `behavioral_v1`, `technical_v1`, `coding_round_v1`; persists an `Evaluation` per call |
| Question Agent | `agents/question-agent` | Topic plan (floor 1 / ceiling 3), quota enforcement, explicit `quota_override`, progressive difficulty |
| Follow-up Agent | `agents/followup-agent` | Probes a named gap in the answer; refuses to probe a low-confidence transcript |
| Memory Agent | `agents/memory-agent` | `session_context` with `topic_counts`; opt-in cross-session recall |
| Time Tracking | `mcp-servers/tool-time-tracking` + `agents/time-tracking-agent` | Per-segment budgets, `nudge` before `expired`, paused time excluded |
| Shared domain | `packages/interview-domain` | Topic vocabulary, role profiles, question bank |
| Interview Config page | `apps/web` | Login, new interview, resume upload/delete, JD-fit display |
| QUESTION_LOOP | `agents/harness-agent/src/interview.ts` | End to end with typed answers |

## Decisions worth knowing about

**The topic vocabulary is shared, not per-agent.** `packages/interview-domain`
holds the topics, role profiles and question bank. If the Resume Service Agent
and the Question Agent had separate vocabularies, `topic_plan` and
`topic_counts` could never line up and the per-topic quotas would be
unenforceable. That package is an addition to the layout in `CLAUDE.md §3`.

**Evidence is a verbatim slice, never a paraphrase.** Every `topic_relevance`
entry quotes the resume line that produced it, and the gate test asserts that
each `evidence` string appears literally in the source document. That is the
strongest available reading of "traces back to actual resume text", and it fails
the moment anything starts summarising.

**Refusals are first-class.** The Eval Tool returns `insufficient_transcript`
rather than a low score when there is too little to go on, and refuses outright
on a low-confidence transcript. The API passes that through as
`evaluation: null` plus an `evaluation_note`. A thin answer is not the same as a
bad one, and inventing the difference would be fabrication (soul.md).

**A quota override is an event, not a flag nobody reads.** When every topic is
capped and budget remains, the Question Agent may exceed one cap — and the
harness emits a `quota_override_used` telemetry event alongside setting
`quota_override: true` on the question. The gate test asserts on the event, not
just the field.

**Scoring is deterministic and evidence-first.** Each rubric is a set of signals;
a signal scores only when it can point at the span of transcript that produced
it. Signals are about substance — a concrete situation, the candidate's own
actions, an outcome, reasoning about tradeoffs — and never about fluency,
vocabulary or phrasing. There is a test asserting that the same answer written in
non-native English scores identically (soul.md §5).

**The model seam is deliberate, and empty for now.** Every agent's judgement
lives behind a single function — `computeTopicRelevance`, `selectNextQuestion`,
`considerFollowUp`, `scoreAgainstRubric`. Swapping any of them for a
Claude-backed implementation is a change to that function and nothing else: the
MCP contracts, persistence, quota rules and refusals all sit around it. **Nothing
in Stage 2 calls an LLM.** That is a real limitation, stated plainly: the
behaviour is rule-based, so it is deterministic, testable in CI with no API key,
and free of the risk that a model quietly invents evidence. Wiring the Anthropic
API into those four functions is the natural next increment and needs a
key plus its own evaluation work before it can be trusted with candidate-facing
output.

**Resume upload is base64 JSON, not multipart.** It keeps the bytes inside one
validated body, avoids a streaming-upload dependency in the gateway, and makes
the size cap enforceable before anything touches disk.

## Running the gate

```bash
npm install
npm test          # 102 tests
npm run typecheck # workspace + web
npm run build:web
```

Gate coverage:

| Gate test | Where |
|---|---|
| 1. Parser across 3–5 resumes; evidence traces to real text | `apps/gateway/tests/resume-parsing.test.ts` (txt, md, docx, pdf) |
| 2. Floor 1 / ceiling 3; required topic at zero relevance still gets a slot | `apps/gateway/tests/topic-plan.test.ts` |
| 3. Topic excluded at cap; override only when all are capped, flagged and logged | `apps/gateway/tests/topic-plan.test.ts`, `question-loop.test.ts` |
| 4. Scripted persona through CONFIG → CALIBRATION → QUESTION_LOOP, topic-balanced | `apps/gateway/tests/question-loop.test.ts` |
| 5. Upload then delete; the stored file is actually gone | `apps/gateway/tests/question-loop.test.ts` (checks the file store directly) |

## Trying it by hand

```bash
npm run infra:up
STORAGE_DRIVER=postgres npm run db:migrate
STORAGE_DRIVER=postgres SEED_STUDENT_PASSCODE=... SEED_ADMIN_PASSCODE=... \
  npm run seed --workspace @mia/gateway
STORAGE_DRIVER=postgres npm run dev   # gateway on :4000
npm run dev:web                        # web on :3000
```

Sign in at `http://localhost:3000`, create an interview, upload a resume, and the
JD-fit panel shows which topics your resume supports — each with the line it came
from — and which JD requirements to expect questions about.

## Deliberately not built (at the time this stage closed)

- **Voice, the coding round, and consent-gated monitoring** — landed in Stage 3,
  see `docs/stage-3-voice-and-coding.md`.
- **Reports and the Admin dashboard** — landed in Stage 4, see
  `docs/stage-4-reporting-and-admin.md`. At the time this doc was written,
  `GET /admin/reports` still returned an empty list behind its RBAC check.
- **The Telemetry Check page** — landed in Stage 3; at the time this doc was
  written only the API endpoint behind it
  (`POST /sessions/:id/telemetry-check`) existed.

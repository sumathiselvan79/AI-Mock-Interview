# docs

The four governing documents live at the repository root, not in this folder, so
they are the first thing anyone (or any AI agent) sees on opening the repo —
`CLAUDE.md` in particular is loaded automatically as project instructions and
must stay at the root to keep working.

| Document | What it is | Read it before |
|---|---|---|
| [`CLAUDE.md`](../CLAUDE.md) | Project map: architecture, repo layout, conventions | touching any code |
| [`soul.md`](../soul.md) | Constitution: voice, values, hard ethical guardrails | writing any prompt, persona, or scoring logic |
| [`INSTRUCTIONS.md`](../INSTRUCTIONS.md) | Technical spec: state machine, agent/tool contracts, schemas, API surface | implementing an agent or an MCP tool |
| [`TRACKING.md`](../TRACKING.md) | Build tracker: five stages, each with a gate | starting or closing out a stage |

If `INSTRUCTIONS.md` and `soul.md` ever conflict, `soul.md` wins.

Stage-specific notes as they are written go here:

- [`stage-1-foundation.md`](./stage-1-foundation.md) — auth, gateway, data layer, harness skeleton
- [`stage-2-interview-loop.md`](./stage-2-interview-loop.md) — resume, questions, follow-ups, memory, timing
- [`stage-3-voice-and-coding.md`](./stage-3-voice-and-coding.md) — text-to-speech/speech-to-text, the coding round, consent-gated monitoring
- [`stage-4-reporting-and-admin.md`](./stage-4-reporting-and-admin.md) — reports, retention, the Student/Admin Home pages
- [`stage-5-llm-and-archival.md`](./stage-5-llm-and-archival.md) — LLM-backed agents, grounding checks, structured tool calling, session archival

# Stage 3 — Voice, coding round, monitoring: what was built and why

Closes the Stage 3 checklist in [`TRACKING.md`](../TRACKING.md): the Telemetry
Check page, text-to-speech/speech-to-text, the coding round, and
consent-gated monitoring.

## What exists now

| Piece | Where | Notes |
|---|---|---|
| Speech Service Tool | `mcp-servers/tool-speech-service` | `synthesize_speech` + `transcribe_speech` via `sherpa-onnx-node`; a deterministic fixture provider stands in when the ONNX models aren't on disk |
| Telemetry Check page | `apps/web/app/interview/[id]/telemetry-check` | Mic/speaker check + explicit consent capture (telemetry, clipboard monitor, audio recording) |
| Consent at the tool layer | `mcp-servers/tool-clipboard-monitor` | `start_monitor` rejects a missing/invalid `consent_token`, independent of the UI |
| Coding Agent + sandbox | `agents/coding-agent` | `vm`-isolated child process; blocks filesystem/network/process access, kills infinite loops |
| Clipboard Monitor | `mcp-servers/tool-clipboard-monitor` | Records a boolean + timestamp only, never pasted content |
| WebSocket audio events | `apps/gateway/src/http/live-channel.ts`, `.../routes/voice.ts` | `submit_answer_audio`, question/follow-up `audio_url` playback, `submit_answer_text` fallback |
| Low-confidence handling | `agents/harness-agent/src/interview.ts` (`transcribe`) | A `transcription_low_confidence` refusal never reaches Eval or the Follow-up Agent — it comes back as a 202 with a retry instruction |
| Signup page | `apps/web/app/signup`, `POST /auth/register` | Always creates a `student` account; no client-settable role |

## Decisions worth knowing about

**Real speech when the models are present, a deterministic fixture otherwise.**
`selectSpeechProvider` picks `sherpa-onnx` when `models/` has the Whisper and
Piper files (`npm run speech:models`), and a fixture provider otherwise. Both
satisfy the same `SpeechProvider` port, so the gate tests run — and mean
something — either way; with the real models the accuracy assertions are
against genuine ASR output, not a canned string.

**Word-overlap, not exact string equality, for real ASR.** A small acoustic
model can mishear one phonetically similar word (`voice.test.ts`: "retry" as
"re-dry") without that being a system bug. Demanding byte-exact transcripts
would test the model's precision, not the pipeline's correctness — so gate
tests 2 and 3 both score real-speech transcripts by word overlap (≥0.8 and
≥0.9 respectively) and only fall back to exact equality against the
deterministic fixture provider.

**Consent is enforced twice, on purpose.** The Telemetry Check page is the
only place a candidate sees the consent copy, but the actual gate is
`start_monitor`'s `consent_token` check inside the tool — a test calls the MCP
method directly, with no UI in the loop, and confirms it's still rejected.

**Code execution never happens in-process.** `runner.ts` spawns a constrained
child; the sandbox tests attempt filesystem access, network access, process
spawning, and an infinite loop, and assert each is blocked without taking
down the Coding Agent itself.

**Audio is deleted the moment it has a transcript**, unless the candidate
opted into `consent.audioRecording` — the same rule Stage 4's retention job
applies to full transcripts (see `docs/stage-4-reporting-and-admin.md`).

## Running the gate

```bash
npm install
npm run speech:models   # optional: fetch the real ONNX models
npm test                # 137 tests as of Stage 3 completion
npm run typecheck
```

Gate coverage (`TRACKING.md` Stage 3, gate tests 1–7):

| Gate test | Where |
|---|---|
| 1. `synthesize_speech` under the 1.5s budget | `apps/gateway/tests/voice.test.ts` (gate test 1) |
| 2. `transcribe_speech` accuracy against known clips | `apps/gateway/tests/voice.test.ts` (gate test 2) |
| 3. Full voice loop: spoken question → transcribed answer → follow-up | `apps/gateway/tests/voice.test.ts` (gate test 3) |
| 4. Low-confidence transcript re-prompts, never scored silently | `apps/gateway/tests/voice.test.ts` (gate test 4) |
| 5. `start_monitor` rejects a missing/invalid consent token | `apps/gateway/tests/coding-monitoring.test.ts` (gate test 5) |
| 6. A paste event stores a boolean + timestamp only | `apps/gateway/tests/coding-monitoring.test.ts` (gate test 6) |
| 7. Sandbox escape attempts are blocked | `apps/gateway/tests/coding-monitoring.test.ts` (gate test 7) |

Plus `tests/e2e/stage3-voice-and-coding.test.ts`, which walks signup → voice
Q&A → coding round with consented paste detection → wrap-up in one run.

## Deliberately not built

- **Reports and the Admin dashboard** — Stage 4.
- **A Post-Interview Report page** — not on the Stage 4 checklist either; the
  backend (`POST`/`GET /sessions/:id/report`) is complete and covered by
  `apps/gateway/tests/reporting.test.ts`, but no frontend page consumes it yet.

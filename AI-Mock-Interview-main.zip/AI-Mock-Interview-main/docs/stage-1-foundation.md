# Stage 1 — Foundation: what was built and why

Closes the Stage 1 checklist in [`TRACKING.md`](../TRACKING.md): auth, gateway,
data layer, and a Harness Agent that can move a session through states with no
agent intelligence behind it.

## What exists now

| Piece | Where | Notes |
|---|---|---|
| Monorepo scaffold | `/apps`, `/agents`, `/mcp-servers`, `/packages`, `/infra`, `/docs` | npm workspaces; every agent and tool is its own package |
| Shared types | `packages/shared-types` | `User`, `Session`, `TopicPlanEntry`, `Question`, `Answer`, `Evaluation`, `Report`, telemetry + MCP contracts, storage ports |
| MCP schemas | `packages/mcp-schemas` | JSON Schema per server/method + an Ajv validator the gateway calls on every request *and* response |
| Postgres schema | `apps/gateway/migrations/001_init.sql` | All 7 entities plus `session_state_transitions`, `passcode_reset_tokens`, `telemetry_events` |
| Redis wiring | `apps/gateway/src/storage/redis.ts` | Device checks, session MCP tokens, segment timers, rate-limit counters |
| Auth | `apps/gateway/src/auth/` | scrypt passcode hashing, HS256 role tokens, single-use reset tokens |
| RBAC | `apps/gateway/src/http/middleware/auth.ts` | Enforced at the gateway on every request |
| MCP Gateway | `apps/gateway/src/mcp/gateway.ts` | Auth → caller allowlist → rate limit → request schema → dispatch → response schema → telemetry span |
| Harness Agent | `agents/harness-agent` | Real state machine; per-state work is a no-op until later stages |
| Agent + tool stubs | `agents/*`, `mcp-servers/*` | Registered and schema-backed; every method answers `not_implemented` with the stage that will fill it in |

## Decisions worth knowing about

**Storage is a port with two drivers.** `STORAGE_DRIVER=memory` (default) runs
the entire gateway with no Postgres or Redis; `postgres` wires the real thing.
Both satisfy the same interfaces, so no route or agent code branches on it, and
the test suite exercises the same object graph `npm run dev` builds.

**`Session.state` is protected by a capability, not a convention.**
`INSTRUCTIONS.md §3` says the Harness Agent is the only component allowed to
transition state. That is enforced three ways: `SessionStore.setState` requires a
grant object whose token is a module-private `Symbol` only
`@mia/harness-agent` can hand out; the store refuses to register a second
writer; and the `session_state_transitions.actor` column has a
`CHECK (actor = 'harness-agent')`. A forged grant with the right `actor` string
still fails, because the check is on symbol identity. See the tests in
`apps/gateway/tests/session-state.test.ts`.

**Telemetry cannot structurally carry candidate content.** `emit_event`'s schema
allows only scalar payload values, and the sink drops any forbidden key
(`transcript`, `resume_text`, `clipboard`, …) before storage, recording
`redacted_keys` instead so a leak *attempt* stays visible without the leaked
value. The application logger redacts the same key set and truncates long
strings independently (`CLAUDE.md §8`).

**Speech Service caller restriction lives in the schema package.** JSON Schema
cannot express "only the Harness Agent may call this", so `ALLOWED_CALLERS` in
`@mia/mcp-schemas` carries it and the gateway enforces it (`INSTRUCTIONS.md §5.6`).

**No build step yet.** Dev runs through `tsx`, tests through `vitest`, both from
source. `npm run typecheck` type-checks the whole workspace without emitting.
Add per-service bundling when the Docker images stop running `tsx`.

**Login and reset-request are not enumeration oracles.** A wrong passcode and an
unknown account produce byte-identical responses, and a login against a missing
account still runs a scrypt verification against a dummy hash so the timing
matches.

## Running the gate by hand

```bash
npm install
npm test                    # 54 tests: all four gate tests plus the e2e walk-through
npm run typecheck

# Against real infrastructure instead of the in-memory driver:
npm run infra:up
STORAGE_DRIVER=postgres npm run db:migrate
STORAGE_DRIVER=postgres SEED_STUDENT_PASSCODE=... SEED_ADMIN_PASSCODE=... \
  npm run seed --workspace @mia/gateway
STORAGE_DRIVER=postgres npm run dev
```

Then, with the gateway running:

```bash
curl -sX POST localhost:4000/auth/login \
  -H 'content-type: application/json' \
  -d '{"email":"student@example.com","passcode":"..."}'

curl -sX POST localhost:4000/sessions \
  -H "authorization: Bearer $TOKEN" -H 'content-type: application/json' \
  -d '{"role":"Senior Backend Engineer","job_description":"..."}'

curl -sX POST localhost:4000/sessions/$SESSION_ID/advance \
  -H "authorization: Bearer $TOKEN" -H 'content-type: application/json' \
  -d '{"to":"CONFIG"}'

curl -s localhost:4000/sessions/$SESSION_ID/transitions -H "authorization: Bearer $TOKEN"

curl -sX POST localhost:4000/internal/mcp/call \
  -H "authorization: Bearer $TOKEN" -H 'content-type: application/json' \
  -d '{"session_id":"'$SESSION_ID'","server":"_dev","method":"ping","params":{"nonce":"manual"}}'
```

The last call is Stage 1 gate test 4 done by hand: it lands a `tool_called` row
in `telemetry_events` with latency and status.

## Deliberately not built

- **`apps/web`** — nothing in the Stage 1 checklist is a page; the first one
  (Interview Config) lands in Stage 2 with the agent behind it.
- **Real MCP transports** — every server is registered behind the
  `McpServerHandler` interface and runs in-process. Swapping in the official MCP
  SDK's transport is a change to that seam only, not to the gateway or callers.
- **Agent bodies** — every specialized agent and tool answers `not_implemented`
  with the stage that owns it. That is the Stage 1 requirement ("states wired as
  no-ops"), not an oversight.

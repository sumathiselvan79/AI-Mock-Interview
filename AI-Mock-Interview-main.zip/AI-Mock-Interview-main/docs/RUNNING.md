# Running the app locally

## Prerequisites
- Node.js >= 20
- Dependencies already installed via `npm install` at the repo root (npm workspaces)

## Quick start (no Postgres/Redis needed)

Open two terminals from the repo root:

```bash
npm run dev       # gateway (+ all agent/tool MCP servers) on http://localhost:4000
npm run dev:web   # Next.js frontend on http://localhost:3000
```

Then open **http://localhost:3000** in a browser.

This uses `STORAGE_DRIVER=memory` (the default), so the gateway keeps all
session/candidate data in memory — nothing persists across a restart, and no
Postgres/Redis/Docker is required. Speech falls back to a `fixture` provider
since no `sherpa-onnx` models are present in `models/` (real TTS/STT needs
`npm run speech:models`, see `INSTRUCTIONS.md §5.6`).

## Full setup (durable storage via Postgres + Redis)

```bash
cp .env.example .env          # then set a real AUTH_TOKEN_SECRET
npm run infra:up              # starts Postgres + Redis via Docker Compose
STORAGE_DRIVER=postgres npm run db:migrate
STORAGE_DRIVER=postgres npm run dev
npm run dev:web
```

Stop the infra containers with `npm run infra:down`.

## Optional: real LLM generation (Stage 5)

Everything above runs with `LLM_PROVIDER=fixture`, the deterministic in-process
provider — no API key, and no candidate text leaves the machine. For real
generation:

```bash
LLM_PROVIDER=groq GROQ_API_KEY=... npm run dev
```

**Read the data-sharing notes at the top of that section in `.env.example`
first.** Resume text, job descriptions and answer transcripts are sent to
whichever provider is configured; that is the one documented exception to
"nothing is shared with third parties" (`soul.md §"Privacy by default"`), and
each provider's terms are recorded there. Bedrock and OpenRouter work through
the same seam — see `INSTRUCTIONS.md §5.7`.

LangSmith tracing is a *separate* third-party recipient of the same text. It is
off unless `NODE_ENV=development`, `LANGSMITH_OPT_IN=true` and
`LANGSMITH_API_KEY` are all set; the gate clears LangChain's own tracing
variables otherwise, so an inherited `LANGCHAIN_TRACING_V2` cannot turn it on.

## Optional: the session archive (Stage 5)

Completed sessions are compiled into a redacted, admin-only archive on a
**separate** Supabase-hosted Postgres instance (`INSTRUCTIONS.md §11.4`). Point
`SUPABASE_DB_URL` at it — never at the same database as `DATABASE_URL` — and
apply its schema:

```bash
npm run db:migrate:archive
```

Left blank, sessions complete exactly as they did at Stage 4 and
`GET /admin/archives/*` returns 404 rather than pretending.

## Other useful commands

```bash
npm test           # run the full test suite (205 tests, no infra or API key required)
npm run typecheck  # typecheck gateway + web
npm run lint       # typecheck + the stateless-reducer rule over /agents
npm run test:e2e   # scripted end-to-end mock interviews (Stages 1, 3 and 5)
```

## Ports

| Service | Port | URL |
|---|---|---|
| Gateway (API + WebSocket + MCP host) | 4000 | http://localhost:4000 |
| Web (Next.js frontend) | 3000 | http://localhost:3000 |

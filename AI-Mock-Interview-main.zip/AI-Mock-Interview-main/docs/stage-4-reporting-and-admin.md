# Stage 4 — Reporting, Admin, hardening: what was built and why

Closes the Stage 4 checklist in [`TRACKING.md`](../TRACKING.md): reports get
generated, persisted, and are visible to the right people only — then the
whole thing is stress-tested.

## What exists now

| Piece | Where | Notes |
|---|---|---|
| Report Agent | `agents/report-agent` | `generate_report`: per-topic competency scores, evidence-linked strengths/focus areas, the required disclaimer |
| Report persistence | `apps/gateway/src/storage/interview-{memory,postgres}.ts` (`ReportStore`) | Backed by the `reports` table from the Stage 1 schema — `candidateId` is denormalised onto it for the Admin dashboard |
| `REPORT_GENERATION` wiring | `agents/harness-agent/src/index.ts` (`generateReport`), `.../interview.ts` (`InterviewOrchestrator.generateReport`) | Assembles the full transcript, calls the Report Agent, persists the result, runs retention, transitions to `COMPLETED` |
| Student Home page | `apps/web/app/home` | Past interview stats (`GET /me/stats`) + "start new interview" |
| Admin Home dashboard | `apps/web/app/admin` | Aggregated view across all candidates (`GET /admin/reports`); no way to start a session as a candidate |
| Admin report routes | `apps/gateway/src/http/routes/admin.ts` | `GET /admin/reports`, `GET /admin/reports/:sessionId`, RBAC-gated |
| Retention | `agents/harness-agent/src/index.ts` (`generateReport`) | Hard-deletes the resume file, redacts every answer's transcript, unless `consent.audioRecording` opted in |

## Decisions worth knowing about

**The Harness Agent assembles the transcript; the Report Agent only scores
it.** Same separation as every other agent in this repo — the Report Agent
has no direct storage dependency, only `toolClient`. The harness reads every
`Question`, its `Answer`, and every persisted `Evaluation`, and hands the
whole thing over as one call's `params`, the same way it already does for the
Question Agent's `topic_plan`/`topic_counts` (`INSTRUCTIONS.md §4.3`).

**A competency score is never emitted without evidence — literally.** Each
`CompetencyScore.evidence` entry is a substring sliced out of an actual answer
transcript at the offsets the Eval Tool returned, never a generated sentence.
A topic where every answer was too thin to score gets no entry in
`competency_scores` at all; it's named instead in `focus_areas` ("not enough
was said... worth giving a fuller answer next time"), so the gap is visible
without inventing a number for it. `apps/gateway/tests/reporting.test.ts`
gate test 1 asserts this three ways: every evidence string is verbatim,
a session with nothing scoreable is refused outright
(`insufficient_evidence`), and a session with one strong topic and one
unscoreable topic reports the first and names the second.

**The "final holistic scoring pass" is a real second Eval Tool call, not a
re-read of the first one.** `INSTRUCTIONS.md §4.8` says the Report Agent
calls the Eval Tool; per-answer scores already exist from `QUESTION_LOOP`,
so the Report Agent adds one more `evaluate_answer` call per topic, against
that topic's answers concatenated, and averages it with the per-answer mean.
If the concatenated transcript is too thin for that extra pass (rare — every
contributing answer already cleared the per-answer bar), the per-answer
average stands alone rather than failing report generation.

**The coding round is folded in, even though it lives outside
`questions`/`answers`.** `CODING_ROUND` is the Coding Agent's own in-memory
state (`RoundState`), not a persisted `Question`/`Answer` pair — so without
deliberate wiring it would silently vanish from the report. `coding-agent`'s
`get_round_result` now also returns the problem statement, topics, the
evaluation's `evidence_spans`, and the talk-through text it was scored
against; the harness folds this into the transcript as one more entry, under
a fixed `"coding round"` competency label rather than one of the resume/role
topics, since blending a code-reasoning rubric's signals into, say,
"distributed systems" would muddy what the number means.

**Retention runs once, at the one testable moment `INSTRUCTIONS.md §8`
actually describes:** "retained only as long as needed to generate the
report, then deleted." That moment is exactly when `REPORT_GENERATION`
finishes — not a scheduled job, not a TTL. The resume is purged through the
same hard-delete path an explicit candidate delete already uses
(`deleteResume`); every answer's transcript (and its follow-ups) is replaced
with a redaction marker via a new `AnswerStore.redact`, unless
`consent.audioRecording` is set. That flag is reused deliberately: the schema
has exactly one "keep my personal data for longer review" consent flag, and
`INSTRUCTIONS.md §5.6` and `§8` describe audio and transcript retention in
near-identical terms, so this maps one candidate intent onto the one flag
that exists rather than adding a second for the same thing. Redaction happens
*after* the report is persisted, so the report's own evidence quotes —
already extracted verbatim — are unaffected by their source transcript being
purged a moment later.

**Admins get exactly what a `Report` contains, structurally.** `GET
/admin/reports` and `.../reports/:sessionId` serve the stored `Report` record
as-is — there's no separate redaction step because the type itself has no
field for a resume, transcript, or audio reference. The access rule from
`soul.md §5` is enforced by the shape of the data, not by a filter that could
be gotten wrong later.

**No Post-Interview Report page.** `CLAUDE.md §11` names one in the page
flow, but it isn't a Stage 4 checklist item, and the backend it would call
(`POST`/`GET /sessions/:id/report`) is fully built and tested independent of
any UI. Building the page is a small, self-contained addition for whoever
picks up the frontend next; skipping it now keeps this stage's diff to
exactly what `TRACKING.md` asks for.

## Running the gate

```bash
npm install
npm test          # 152 tests as of Stage 4 completion
npm run typecheck
npm run build --workspace @mia/web
```

The suite runs a capped thread pool (`vitest.config.ts`) — several test files
load real ONNX speech models or run `scrypt`, and letting every file claim a
full CPU-count of parallel threads was enough contention on modest hardware
to blow hook timeouts and, once, segfault a worker. The cap trades a little
wall-clock time for `npm test` passing reliably every run.

Gate coverage (`TRACKING.md` Stage 4, gate tests 1–6):

| Gate test | Where |
|---|---|
| 1. Every score is evidenced; a thin/ambiguous transcript is refused, not guessed at | `apps/gateway/tests/reporting.test.ts` (gate test 1, 4 cases incl. the coding round) |
| 2. RBAC: student 403 on `/admin/reports`; admin 403 on a candidate-only action | `apps/gateway/tests/reporting.test.ts` (gate test 2) |
| 3. A completed session appears on the Admin dashboard via a separate, later request | `apps/gateway/tests/reporting.test.ts` (gate test 3) |
| 4. Resume/transcripts deleted after `REPORT_GENERATION`, or retained only on opt-in | `apps/gateway/tests/reporting.test.ts` (gate test 4, both branches) |
| 5. N concurrent sessions, no state bleed | `apps/gateway/tests/reporting.test.ts` (gate test 5) |
| 6. Five personas, evidence checked mechanically for fabrication | `apps/gateway/tests/reporting.test.ts` (gate test 6) |

- [x] All Stage 1–3 gates still pass — `npm test` runs every stage's suite together; see the stage-1 and stage-3 docs for their own tables.
- [x] No raw PII found in logs, telemetry, or admin-visible data — telemetry sanitisation is Stage 1 (`mcp-gateway.test.ts`); Admin-visible data is structurally limited to `Report` fields (see above).
- [x] Every report in the regression run cites real evidence for every score — gate test 6.
- [x] RBAC holds under direct API calls, not just through the UI — gate test 2, and `auth-rbac.test.ts` throughout.

## Deliberately not built

- **A Post-Interview Report page** — see above.
- **A scheduled/background retention job** — deletion runs synchronously inside `generateReport`, which is the only point `INSTRUCTIONS.md §8`'s retention rule actually names; there's no other durably-stored candidate content left un-addressed by it.

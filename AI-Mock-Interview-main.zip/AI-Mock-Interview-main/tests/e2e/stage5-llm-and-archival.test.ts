/**
 * Stage 5 end-to-end: signup with profile -> LLM-backed config -> a question
 * loop whose questions are generated and whose answers are scored at follow-up
 * time -> report -> retention -> archive -> admin download.
 *
 * One run, in order, so the ordering constraint that matters most is exercised
 * the way it actually happens rather than asserted in isolation: the archive is
 * compiled after the retention job, and therefore carries the redaction.
 */

import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { REDACTED_TRANSCRIPT } from "@mia/shared-types";
import { ADMIN, bearer, buildHarness, loginToken, seedUsers, type TestHarness } from "../../apps/gateway/tests/helpers.js";
import { BACKEND_JOB_DESCRIPTION, SENIOR_BACKEND_TXT, encoder } from "../../apps/gateway/tests/fixtures/resumes.js";

const STUDENT = { email: "stage5.student@example.com", passcode: "practice-run-5" };

const ANSWER = `We had a settlement service that started timing out whenever a batch run overlapped with peak traffic.
I profiled the request path and found a synchronous Postgres write sitting inside the handler.
I moved that write onto a queue and added an idempotency key so a retried message could not double-charge anyone.
We chose the queue over a larger database instance because the write was never read back immediately,
and the tradeoff we accepted was that reconciliation became eventually consistent.
As a result p99 went from 900ms to 210ms and the overnight pages stopped for good.`;

/** Every JSON path in `value` whose string content contains `needle`. */
function pathsContaining(value: unknown, needle: string, path = "$"): string[] {
  if (typeof value === "string") return value.includes(needle) ? [path] : [];
  if (Array.isArray(value)) return value.flatMap((item, i) => pathsContaining(item, needle, `${path}[${i}]`));
  if (value && typeof value === "object") {
    return Object.entries(value).flatMap(([key, child]) => pathsContaining(child, needle, `${path}.${key}`));
  }
  return [];
}

let h: TestHarness;
let token: string;
let sessionId: string;

beforeAll(async () => {
  h = await buildHarness();
  await seedUsers(h);
});

afterAll(async () => {
  await h.close();
});

describe("Stage 5 — a full LLM-backed, archived session", () => {
  it("1. signs up with the profile fields archiving needs", async () => {
    const registered = await h.api
      .post("/auth/register")
      .send({
        email: STUDENT.email,
        passcode: STUDENT.passcode,
        full_name: "Aditi Sharma",
        department: "Information Technology",
        program_year: "Final Year",
      })
      .expect(201);

    token = registered.body.token;
    expect(registered.body.user.role).toBe("student");

    const profile = await h.api.get("/me/profile").set(...bearer(token)).expect(200);
    expect(profile.body.profile.full_name).toBe("Aditi Sharma");
    expect(profile.body.archive_ready).toBe(true);
  });

  it("2. gets a grounded JD-fit rationale on the config page", async () => {
    const created = await h.api
      .post("/sessions")
      .set(...bearer(token))
      .send({ role: "Senior Backend Engineer", job_description: BACKEND_JOB_DESCRIPTION })
      .expect(201);
    sessionId = created.body.session_id;

    await h.api
      .post(`/sessions/${sessionId}/resume`)
      .set(...bearer(token))
      .send({
        filename: "resume.txt",
        content_type: "text/plain",
        data_base64: Buffer.from(encoder.encode(SENIOR_BACKEND_TXT)).toString("base64"),
      })
      .expect(201);

    await h.api.post(`/sessions/${sessionId}/advance`).set(...bearer(token)).send({ to: "CONFIG" }).expect(200);

    const fit = await h.api.get(`/sessions/${sessionId}/jd-fit`).set(...bearer(token)).expect(200);
    expect(fit.body.jd_fit.prompt_version).toBe("resume-service-agent/v1");
    expect(fit.body.jd_fit.rationale).toBeTruthy();
    // Informational, never a gate (soul.md §3).
    expect(fit.body.blocks_start).toBe(false);
  });

  it("3. runs the question loop, scoring each answer as it goes", async () => {
    await h.api
      .post(`/sessions/${sessionId}/advance`)
      .set(...bearer(token))
      .send({ to: "TELEMETRY_CHECK" })
      .expect(200);
    await h.api
      .post(`/sessions/${sessionId}/telemetry-check`)
      .set(...bearer(token))
      .send({ mic_ok: true, speaker_ok: true, consent: { telemetry: true } })
      .expect(200);
    await h.api.post(`/sessions/${sessionId}/begin`).set(...bearer(token)).expect(200);

    let asked = 0;
    for (let turn = 0; turn < 20; turn += 1) {
      const next = await h.api.get(`/sessions/${sessionId}/questions/next`).set(...bearer(token)).expect(200);
      if (next.body.done) break;
      asked += 1;

      const answered = await h.api
        .post(`/sessions/${sessionId}/answers`)
        .set(...bearer(token))
        .send({ question_id: next.body.question.id, transcript: ANSWER })
        .expect(201);

      // Scored at follow-up time, not deferred to the report (§11.2).
      expect(answered.body.evaluation).not.toBeNull();
    }

    expect(asked).toBeGreaterThan(0);

    // Every question this session asked was LLM-generated and stamped.
    const questions = await h.storage.questions.listBySession(sessionId);
    expect(questions).toHaveLength(asked);
    for (const question of questions) expect(question.promptVersion).toBe("question-agent/v3");

    // ...and every one of them has a persisted Evaluation already.
    const evaluations = await h.storage.evaluations.listBySession(sessionId);
    expect(evaluations.length).toBe(asked);
  });

  it("4. generates the report, redacts, then archives — in that order", async () => {
    await h.api.post(`/sessions/${sessionId}/wrap-up`).set(...bearer(token)).expect(200);
    const report = await h.api.post(`/sessions/${sessionId}/report`).set(...bearer(token)).expect(201);
    expect(report.body.report.competencyScores.length).toBeGreaterThan(0);

    // Retention ran: the raw resume is gone and the transcripts are redacted.
    expect((await h.storage.sessions.get(sessionId))?.resumeRef).toBeNull();
    for (const question of await h.storage.questions.listBySession(sessionId)) {
      const answer = await h.storage.answers.getByQuestion(question.id);
      expect(answer?.transcript).toBe(REDACTED_TRANSCRIPT);
    }

    // The archive was compiled AFTER that, so it carries the redaction rather
    // than the original words — archiving is not a back door around retention
    // (soul.md §5 Stage 5 guardrail).
    const archive = await h.storage.archives!.get(sessionId);
    expect(archive).not.toBeNull();
    expect(archive!.candidateName).toBe("Aditi Sharma");
    expect(archive!.programYear).toBe("Final Year");
    for (const answer of archive!.document.answers) {
      expect(answer.transcript).toBe(REDACTED_TRANSCRIPT);
    }

    // Nothing anywhere in the document still quotes what the candidate SAID.
    // The phrase is one that appears only in the spoken answer: the archive
    // does still carry `session.candidateProfile`, and legitimately so — §8
    // hard-deletes the raw resume FILE, while the derived profile survives by
    // design so a configured session keeps working without it. Testing with a
    // phrase the resume also contains would conflate the two.
    //
    // Reported as the list of offending paths rather than a bare boolean, so a
    // future leak says where it is instead of only that it exists.
    expect(ANSWER).toContain("the overnight pages stopped");
    expect(pathsContaining(archive!.document, "the overnight pages stopped")).toEqual([]);
  });

  it("5. lets an admin download it, and records that they did", async () => {
    const adminToken = await loginToken(h, ADMIN);

    const listed = await h.api.get("/admin/archives").set(...bearer(adminToken)).expect(200);
    expect(listed.body.archives.some((a: { sessionId: string }) => a.sessionId === sessionId)).toBe(true);

    const download = await h.api
      .get(`/admin/archives/${sessionId}/download`)
      .set(...bearer(adminToken))
      .expect(200);
    expect(download.body.report.sessionId).toBe(sessionId);

    const audited = (await h.storage.telemetry.recent(300)).filter(
      (e) => e.eventType === "archive_downloaded" && e.sessionId === sessionId,
    );
    expect(audited).toHaveLength(1);
  });

  it("6. leaves nothing session-scoped behind in the Memory Agent", async () => {
    for (const question of await h.storage.questions.listBySession(sessionId)) {
      expect(
        await h.storage.live.getSessionScratch(sessionId, `reference-answer:${question.id}`),
      ).toBeNull();
    }
  });
});

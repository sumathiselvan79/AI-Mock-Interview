/**
 * Stage 3 gate, end to end (TRACKING.md):
 * "a full voice-driven session including a coding round runs end-to-end, every
 *  consent gate holds under a bypass attempt, and no raw audio or clipboard
 *  content appears anywhere in logs/telemetry."
 *
 * One run: sign up, configure, pass the device check with partial consent,
 * answer by voice, run the coding round, wrap up — then check the gates and
 * sweep the logs and telemetry for anything that should not be there.
 */

import { afterAll, beforeAll, describe, expect, it } from "vitest";
import {
  BACKEND_JOB_DESCRIPTION,
  SENIOR_BACKEND_TXT,
  encoder,
} from "../../apps/gateway/tests/fixtures/resumes.js";
import { bearer, buildHarness, type TestHarness } from "../../apps/gateway/tests/helpers.js";

let h: TestHarness;
let token: string;
let sessionId: string;
let sessionToken: string;

const CANDIDATE = { email: "voice-candidate@example.com", passcode: "practice-out-loud-1" };

beforeAll(async () => {
  h = await buildHarness();
});

afterAll(async () => {
  await h.close();
});

describe("Stage 3 — a full voice-driven session", () => {
  it("1. a student signs up for themselves and is never given the admin role", async () => {
    const signup = await h.api.post("/auth/register").send(CANDIDATE).expect(201);

    expect(signup.body.user.role).toBe("student");
    token = signup.body.token;

    // Asking for admin changes nothing: the gateway fixes the role (§3.2).
    const sneaky = await h.api
      .post("/auth/register")
      .send({ email: "sneaky@example.com", passcode: "let-me-in-please", role: "admin" })
      .expect(201);
    expect(sneaky.body.user.role).toBe("student");

    // ...and the new account is a student everywhere it matters.
    await h.api.get("/admin/reports").set(...bearer(sneaky.body.token)).expect(403);
  });

  it("2. configures the interview and passes the device check with partial consent", async () => {
    const created = await h.api
      .post("/sessions")
      .set(...bearer(token))
      .send({ role: "Senior Backend Engineer", job_description: BACKEND_JOB_DESCRIPTION })
      .expect(201);
    sessionId = created.body.session_id;
    sessionToken = created.body.session_token;

    await h.api
      .post(`/sessions/${sessionId}/resume`)
      .set(...bearer(token))
      .send({
        filename: "priya-raman.txt",
        content_type: "text/plain",
        data_base64: Buffer.from(encoder.encode(SENIOR_BACKEND_TXT)).toString("base64"),
      })
      .expect(201);

    for (const to of ["CONFIG", "TELEMETRY_CHECK"]) {
      await h.api.post(`/sessions/${sessionId}/advance`).set(...bearer(token)).send({ to }).expect(200);
    }

    // Telemetry yes, clipboard monitoring yes, keeping recordings NO.
    const check = await h.api
      .post(`/sessions/${sessionId}/telemetry-check`)
      .set(...bearer(token))
      .send({
        mic_ok: true,
        speaker_ok: true,
        consent: { telemetry: true, clipboard_monitor: true, audio_recording: false },
      })
      .expect(200);

    expect(check.body.passed).toBe(true);
    expect(check.body.consent).toMatchObject({ clipboardMonitor: true, audioRecording: false });
  });

  it("3. asks a question out loud", async () => {
    await h.api.post(`/sessions/${sessionId}/begin`).set(...bearer(token)).expect(200);

    const next = await h.api
      .get(`/sessions/${sessionId}/questions/next`)
      .set(...bearer(token))
      .expect(200);

    expect(next.body.question.text.length).toBeGreaterThan(0);
    expect(next.body.question.audio_url).toBeTruthy();
  });

  it("4. hears a spoken answer, transcribes it, and probes it", async () => {
    const questions = await h.storage.questions.listBySession(sessionId);
    const question = questions.at(-1)!;

    const spoken = "I rewrote the ingestion pipeline and I added a retry queue in front of it.";
    const clip = await synthesize(spoken);

    const answered = await h.api
      .post(`/sessions/${sessionId}/answers/audio`)
      .set(...bearer(token))
      .send({ question_id: question.id, audio_base64: Buffer.from(clip).toString("base64") })
      .expect(201);

    expect(answered.body.accepted).toBe(true);
    expect(answered.body.transcript.length).toBeGreaterThan(0);
    expect(answered.body.follow_up).not.toBeNull();

    // The recording is gone as soon as it has been transcribed: this candidate
    // did not opt into keeping recordings (§8).
    expect(await h.storage.files.listBySession(sessionId)).not.toContainEqual(
      expect.objectContaining({ contentType: "audio/wav", filename: expect.stringContaining("answer-") }),
    );
  });

  it("5. runs the coding round with consented paste detection", async () => {
    const round = await h.api.post(`/sessions/${sessionId}/coding-round`).set(...bearer(token)).expect(201);

    expect(round.body.clipboard_monitoring).toBe(true);
    expect(round.body.audio_url).toBeTruthy();

    const paste = await h.api
      .post(`/sessions/${sessionId}/paste-events`)
      .set(...bearer(token))
      .send({ timestamp: new Date().toISOString(), content: "PASTED-SECRET" })
      .expect(201);
    expect(paste.body.recorded).toBe(true);

    const submission = await h.api
      .post(`/sessions/${sessionId}/coding-round/submissions`)
      .set(...bearer(token))
      .send({
        code: `function allow(events, limit, windowMs) {
          const out = []; let start = null; let count = 0;
          for (const t of events) {
            if (start === null || t - start >= windowMs) { start = t; count = 0; }
            if (count < limit) { count += 1; out.push(true); } else { out.push(false); }
          }
          return out;
        }`,
        talk_through:
          "I keep one counter and a window start, because a fixed window does not need every timestamp. The edge case is the boundary where the window resets.",
      })
      .expect(201);

    expect(submission.body.passed).toBe(submission.body.total);
  });

  it("6. every consent gate holds under a direct bypass attempt", async () => {
    // A different session, whose candidate consented to nothing.
    const other = await h.api
      .post("/sessions")
      .set(...bearer(token))
      .send({ role: "Backend Engineer" })
      .expect(201);

    const bypass = await h.mcp.call(
      "tool-clipboard-monitor",
      "start_monitor",
      { session_id: other.body.session_id, consent_token: "forged.signature" },
      {
        sessionId: other.body.session_id,
        caller: "harness-agent",
        sessionToken: other.body.session_token,
      },
    );
    expect(bypass.ok).toBe(false);
    expect(bypass.error?.code).toBe("consent_invalid");

    // A consent token minted for one session does not work on another.
    const stolen = await h.mcp.call(
      "tool-clipboard-monitor",
      "paste_event_detected",
      { session_id: other.body.session_id, detected: true, timestamp: new Date().toISOString() },
      {
        sessionId: other.body.session_id,
        caller: "harness-agent",
        sessionToken: other.body.session_token,
      },
    );
    expect(stolen.ok).toBe(false);
  });

  it("7. wraps up, and the session lands in WRAP_UP", async () => {
    const wrap = await h.api.post(`/sessions/${sessionId}/wrap-up`).set(...bearer(token)).expect(200);
    expect(wrap.body.state).toBe("WRAP_UP");
    expect(String(wrap.body.message)).toMatch(/end of the session/i);

    const session = await h.storage.sessions.get(sessionId);
    expect(session?.state).toBe("WRAP_UP");
  });

  it("8. no raw audio, clipboard content, or passcode reached the logs or telemetry", async () => {
    const events = JSON.stringify(await h.storage.telemetry.recent(1000));
    const logs = h.logs.history().join("\n");

    for (const forbidden of ["PASTED-SECRET", CANDIDATE.passcode, "RIFF", "data:audio"]) {
      expect(events, `telemetry leaked ${forbidden}`).not.toContain(forbidden);
      expect(logs, `logs leaked ${forbidden}`).not.toContain(forbidden);
    }

    // Nor did the candidate's own words.
    expect(events).not.toContain("ingestion pipeline");
    expect(logs).not.toContain("ingestion pipeline");

    // The events that *should* be there, are.
    const types = new Set((await h.storage.telemetry.recent(1000)).map((e) => e.eventType));
    for (const expected of ["paste_detected", "coding_round_started", "code_submitted", "question_asked"]) {
      expect(types.has(expected as never), `expected a ${expected} event`).toBe(true);
    }
  });
});

/** Produces a clip using whichever speech provider is live. */
async function synthesize(text: string): Promise<Uint8Array> {
  const result = await h.mcp.call<{ audio_url: string }>(
    "tool-speech-service",
    "synthesize_speech",
    { text, session_id: sessionId },
    { sessionId, caller: "harness-agent", sessionToken },
  );
  const ref = result.data!.audio_url.replace("/audio/", "");
  const stored = await h.storage.files.get(ref);
  return stored!.bytes;
}

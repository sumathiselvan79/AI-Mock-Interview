/**
 * Stage 1 gate, end to end (TRACKING.md):
 * "don't start Stage 2 until login, RBAC, session creation, and state-transition
 *  logging all work end-to-end with zero real agent logic."
 *
 * One run through the whole Stage 1 surface: log in as a student, create a
 * session, drive it CREATED -> CONFIG -> TELEMETRY_CHECK -> CALIBRATION through
 * the Harness Agent, fire an MCP call, and confirm the audit trail and
 * telemetry both hold up — with every agent still a no-op.
 */

import { afterAll, beforeAll, describe, expect, it } from "vitest";
import {
  ADMIN,
  STUDENT,
  bearer,
  buildHarness,
  loginToken,
  seedUsers,
  type TestHarness,
} from "../../apps/gateway/tests/helpers.js";

let h: TestHarness;
let studentToken: string;
let adminToken: string;
let sessionId: string;
let sessionToken: string;

beforeAll(async () => {
  h = await buildHarness();
  await seedUsers(h);
});

afterAll(async () => {
  await h.close();
});

describe("Stage 1 foundation, end to end", () => {
  it("1. both roles log in and get a role-scoped token", async () => {
    studentToken = await loginToken(h, STUDENT);
    adminToken = await loginToken(h, ADMIN);
    expect(studentToken).not.toEqual(adminToken);
  });

  it("2. RBAC holds in both directions", async () => {
    await h.api.get("/admin/reports").set(...bearer(studentToken)).expect(403);
    await h.api.get("/me/stats").set(...bearer(adminToken)).expect(403);
    await h.api.get("/me/stats").set(...bearer(studentToken)).expect(200);
    await h.api.get("/admin/reports").set(...bearer(adminToken)).expect(200);
  });

  it("3. a student creates a session and it starts in CREATED", async () => {
    const res = await h.api
      .post("/sessions")
      .set(...bearer(studentToken))
      .send({
        role: "Senior Backend Engineer",
        job_description: "owns service reliability, distributed systems, mentors juniors",
      })
      .expect(201);

    sessionId = res.body.session_id;
    sessionToken = res.body.session_token;
    expect(res.body.state).toBe("CREATED");
  });

  it("4. the harness drives the session through CONFIG and TELEMETRY_CHECK", async () => {
    for (const to of ["CONFIG", "TELEMETRY_CHECK"]) {
      const res = await h.api
        .post(`/sessions/${sessionId}/advance`)
        .set(...bearer(studentToken))
        .send({ to, reason: "stage1_e2e" })
        .expect(200);
      expect(res.body.session.state).toBe(to);
    }
  });

  it("5. the device check gates everything downstream, then opens it", async () => {
    await h.api
      .post(`/sessions/${sessionId}/advance`)
      .set(...bearer(studentToken))
      .send({ to: "CALIBRATION" })
      .expect(409);

    await h.api
      .post(`/sessions/${sessionId}/telemetry-check`)
      .set(...bearer(studentToken))
      .send({
        mic_ok: true,
        speaker_ok: true,
        consent: { telemetry: true, clipboard_monitor: false, audio_recording: false },
      })
      .expect(200);

    await h.api
      .post(`/sessions/${sessionId}/advance`)
      .set(...bearer(studentToken))
      .send({ to: "CALIBRATION" })
      .expect(200);
  });

  it("6. every state transition is logged against the Harness Agent", async () => {
    const { body } = await h.api
      .get(`/sessions/${sessionId}/transitions`)
      .set(...bearer(studentToken))
      .expect(200);

    expect(body.transitions.map((t: { fromState: string; toState: string }) => [t.fromState, t.toState])).toEqual([
      ["CREATED", "CONFIG"],
      ["CONFIG", "TELEMETRY_CHECK"],
      ["TELEMETRY_CHECK", "CALIBRATION"],
    ]);
    for (const t of body.transitions) expect(t.actor).toBe("harness-agent");
  });

  it("7. an MCP call runs through the gateway and lands one instrumented span", async () => {
    const result = await h.mcp.call(
      "_dev",
      "ping",
      { nonce: "stage1" },
      { sessionId, caller: "harness-agent", sessionToken },
    );
    expect(result.ok).toBe(true);

    const span = (await h.storage.telemetry.recent(200))
      .filter((e) => e.eventType === "tool_called")
      .at(-1);
    expect(span?.payload.status).toBe("ok");
    expect(typeof span?.payload.latency_ms).toBe("number");
  });

  it("8. a specialized agent from a later stage is reachable through the same instrumented routing as a tool", async () => {
    // All seven agents are implemented as of Stage 4; what this still proves is
    // that an agent call is routed and validated exactly like a tool call —
    // the Report Agent refuses a session with nothing scoreable rather than
    // guessing, which is a real, stable refusal rather than a stub.
    const result = await h.mcp.call(
      "report-agent",
      "generate_report",
      { session_id: sessionId, candidate_id: "candidate-1", transcript: [] },
      { sessionId, caller: "harness-agent", sessionToken },
    );
    expect(result.error?.code).toBe("insufficient_evidence");
  });

  it("9. no candidate content leaked into telemetry along the way", async () => {
    const events = await h.storage.telemetry.recent(500);
    const serialized = JSON.stringify(events);
    expect(serialized).not.toContain("owns service reliability");
    expect(serialized).not.toContain(STUDENT.passcode);
    expect(h.logs.history().join("\n")).not.toContain(STUDENT.passcode);
  });
});

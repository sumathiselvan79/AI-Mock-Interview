-- Google OAuth profile snapshot, stored alongside session_archives in the
-- same Supabase-hosted Postgres instance (INSTRUCTIONS.md §11.4/§11.6
-- established this as the server-only, service-role-only archive database).
--
-- This table is NOT a session archive — it is a per-user snapshot of the
-- Google identity used to sign in (name, avatar, provider subject), kept for
-- Admin account review. It is a distinct concern from session_archives, so it
-- gets its own table rather than being folded into that one, and it is still
-- never the primary application database: the primary `users` row
-- (email/role/passcode) stays in DATABASE_URL exactly as it did before
-- Google OAuth existed (packages/shared-types/src/oauth-profile.ts).
--
-- Applied with `npm run db:migrate:archive` (SUPABASE_DB_URL), same as
-- 001_session_archives.sql.

CREATE TABLE IF NOT EXISTS oauth_profiles (
  user_id           UUID NOT NULL,
  provider          TEXT NOT NULL,
  provider_subject  TEXT NOT NULL,
  email             TEXT NOT NULL,
  name              TEXT,
  avatar_url        TEXT,
  linked_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, provider)
);

CREATE INDEX IF NOT EXISTS oauth_profiles_email_idx ON oauth_profiles (email);

-- Same access-boundary stance as session_archives (§8): RLS enabled, no
-- permissive policy, so only the service-role credential this gateway holds
-- can read or write here.
ALTER TABLE oauth_profiles ENABLE ROW LEVEL SECURITY;

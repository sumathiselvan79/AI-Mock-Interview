-- Stage 5 — the session archive store (INSTRUCTIONS.md §11.4, §11.6).
--
-- RUN THIS AGAINST THE SUPABASE-HOSTED POSTGRES ONLY, never the primary
-- application database. They are deliberately separate instances: the archive
-- is an export copy for Admin download, and keeping it inside the database the
-- retention job prunes would defeat the point of having one.
--
-- Applied with `npm run db:migrate:archive` (SUPABASE_DB_URL), which is a
-- separate command from `npm run db:migrate` for the same reason.

CREATE TABLE IF NOT EXISTS session_archives (
  session_id     UUID PRIMARY KEY,
  candidate_id   UUID NOT NULL,
  -- NOT NULL by design. §11.4 step 2 refuses to archive a session whose
  -- candidate has no `full_name` rather than archiving with blanks, and the
  -- column enforces that rather than trusting the application to.
  candidate_name TEXT NOT NULL,
  department     TEXT,
  program_year   TEXT,
  document       JSONB NOT NULL,
  archived_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS session_archives_candidate_idx ON session_archives (candidate_id);
CREATE INDEX IF NOT EXISTS session_archives_archived_at_idx ON session_archives (archived_at DESC);

-- No RLS policy is relied on for access control. §8's "Archive access boundary"
-- puts that squarely on this system's own Gateway RBAC, so there is exactly one
-- place deciding who may read candidate data. RLS below is defence in depth for
-- the case where someone later points a non-service-role credential at this
-- database: it default-denies, and is a no-op for the service role, which
-- bypasses RLS.
ALTER TABLE session_archives ENABLE ROW LEVEL SECURITY;

-- Deliberately no permissive policy. With RLS enabled and no policy, every
-- non-service-role connection reads zero rows.

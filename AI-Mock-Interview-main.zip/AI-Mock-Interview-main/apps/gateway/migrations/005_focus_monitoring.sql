-- Fullscreen-exit tracking during the active interview (soul.md §5
-- "Consent-first monitoring"). Additive only.
--
-- `sessions.focus_events`: append-only log of consented exit timestamps —
-- same minimal shape as clipboard monitoring's paste events (a timestamp,
-- nothing about what the candidate did outside the window).
--
-- `reports.browser_activity`: a copy of that log (plus a derived count and an
-- "ended early" flag) folded into the report at generation time, so the
-- candidate and Admin see it without a second query against a session that
-- may since have been redacted.

ALTER TABLE sessions
  ADD COLUMN IF NOT EXISTS focus_events JSONB NOT NULL DEFAULT '[]'::jsonb;

-- New sessions' consent default now includes focusLossMonitoring: false too.
-- (Existing rows are read through PostgresSessionStore's
-- `{ ...DEFAULT_CONSENT, ...row.consent }` merge, so they hydrate with the
-- key present regardless of what this ALTER changed.)
ALTER TABLE sessions
  ALTER COLUMN consent SET DEFAULT
    '{"telemetry":false,"clipboardMonitor":false,"audioRecording":false,"crossSessionMemory":false,"focusLossMonitoring":false}'::jsonb;

ALTER TABLE reports
  ADD COLUMN IF NOT EXISTS browser_activity JSONB NOT NULL DEFAULT
    '{"exitCount":0,"events":[],"concludedEarly":false}'::jsonb;

-- Stage 1 schema — INSTRUCTIONS.md §6.
-- Durable records only. Live session state and timers live in Redis.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ---------------------------------------------------------------- users/auth

CREATE TABLE IF NOT EXISTS users (
  id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email                       TEXT NOT NULL UNIQUE,
  role                        TEXT NOT NULL CHECK (role IN ('admin', 'student')),
  -- Salted scrypt hash, format: scrypt$N$r$p$salt$hash. Never plaintext (§8).
  passcode_hash               TEXT NOT NULL,
  -- Cross-session memory is opt-in at the account level (soul.md §5).
  cross_session_memory_opt_in BOOLEAN NOT NULL DEFAULT FALSE,
  created_at                  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Short-lived, single-use. Only the SHA-256 of the emailed token is stored, so a
-- database read cannot be replayed as a credential (§8).
CREATE TABLE IF NOT EXISTS passcode_reset_tokens (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TIMESTAMPTZ NOT NULL,
  used_at    TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_reset_tokens_user ON passcode_reset_tokens(user_id);

-- ----------------------------------------------------------------- sessions

CREATE TABLE IF NOT EXISTS sessions (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  candidate_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role            TEXT NOT NULL,
  job_description TEXT NOT NULL DEFAULT '',
  jd_fit          JSONB,
  state           TEXT NOT NULL DEFAULT 'CREATED' CHECK (state IN (
                    'CREATED','CONFIG','TELEMETRY_CHECK','CALIBRATION','QUESTION_LOOP',
                    'CODING_ROUND','WRAP_UP','REPORT_GENERATION','COMPLETED','ABORTED')),
  consent         JSONB NOT NULL DEFAULT
                    '{"telemetry":false,"clipboardMonitor":false,"audioRecording":false,"crossSessionMemory":false}'::jsonb,
  question_budget INTEGER NOT NULL DEFAULT 8 CHECK (question_budget > 0),
  -- Reference to the stored resume file; NULL once hard-deleted (§8).
  resume_ref      TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_sessions_candidate ON sessions(candidate_id, created_at DESC);

-- Append-only audit of every state change. `actor` is constrained to the Harness
-- Agent: the database refuses to record a transition made by anything else
-- (INSTRUCTIONS.md §3).
CREATE TABLE IF NOT EXISTS session_state_transitions (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id UUID NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  from_state TEXT NOT NULL,
  to_state   TEXT NOT NULL,
  actor      TEXT NOT NULL DEFAULT 'harness-agent' CHECK (actor = 'harness-agent'),
  reason     TEXT NOT NULL DEFAULT '',
  at         TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_transitions_session ON session_state_transitions(session_id, at);

-- Set once at CALIBRATION; read by the Question Agent on every call (§4.3).
CREATE TABLE IF NOT EXISTS topic_plan_entries (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id    UUID NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  topic         TEXT NOT NULL,
  max_questions INTEGER NOT NULL CHECK (max_questions BETWEEN 1 AND 3),
  source        TEXT NOT NULL CHECK (source IN ('resume', 'role_requirement', 'jd_gap')),
  UNIQUE (session_id, topic)
);

-- ------------------------------------------------------------ interview data

CREATE TABLE IF NOT EXISTS questions (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id     UUID NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  text           TEXT NOT NULL,
  audio_url      TEXT,
  topic          TEXT NOT NULL,
  type           TEXT NOT NULL CHECK (type IN ('behavioral', 'technical', 'coding')),
  difficulty     INTEGER NOT NULL CHECK (difficulty BETWEEN 1 AND 5),
  -- TRUE only when the topic quota was exceeded as a last resort; never silent (§4.3).
  quota_override BOOLEAN NOT NULL DEFAULT FALSE,
  asked_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_questions_session ON questions(session_id, asked_at);

CREATE TABLE IF NOT EXISTS answers (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  question_id           UUID NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
  -- STT output or the typed fallback. Purged after report generation unless the
  -- candidate opted into longer retention (§8).
  transcript            TEXT NOT NULL,
  transcript_confidence REAL,
  follow_ups            JSONB NOT NULL DEFAULT '[]'::jsonb,
  submitted_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_answers_question ON answers(question_id);

CREATE TABLE IF NOT EXISTS evaluations (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  answer_id      UUID NOT NULL REFERENCES answers(id) ON DELETE CASCADE,
  rubric_id      TEXT NOT NULL,
  score          REAL NOT NULL,
  rationale      TEXT NOT NULL,
  -- Non-empty by construction: a score with no evidence must not be persisted
  -- (soul.md §"No fabrication").
  evidence_spans JSONB NOT NULL CHECK (jsonb_array_length(evidence_spans) > 0),
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_evaluations_answer ON evaluations(answer_id);

CREATE TABLE IF NOT EXISTS reports (
  session_id        UUID PRIMARY KEY REFERENCES sessions(id) ON DELETE CASCADE,
  -- Denormalised so the Admin dashboard can query across candidates without
  -- joining back through sessions.
  candidate_id      UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  competency_scores JSONB NOT NULL,
  strengths         JSONB NOT NULL DEFAULT '[]'::jsonb,
  focus_areas       JSONB NOT NULL DEFAULT '[]'::jsonb,
  disclaimer        TEXT NOT NULL CHECK (length(disclaimer) > 0),
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_reports_candidate ON reports(candidate_id, created_at DESC);

-- ---------------------------------------------------------------- telemetry

-- Payload is scalar-only by convention and sanitised before insert; never raw
-- resume text, transcripts, audio, or clipboard content (§8).
CREATE TABLE IF NOT EXISTS telemetry_events (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type TEXT NOT NULL,
  session_id UUID,
  payload    JSONB NOT NULL DEFAULT '{}'::jsonb,
  emitted_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_telemetry_session ON telemetry_events(session_id, emitted_at DESC);
CREATE INDEX IF NOT EXISTS idx_telemetry_type ON telemetry_events(event_type, emitted_at DESC);

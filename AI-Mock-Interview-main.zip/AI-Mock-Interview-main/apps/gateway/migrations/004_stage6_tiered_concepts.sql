-- Stage 6: tiered concept-escalation model (INSTRUCTIONS.md §4.3, §4.4).
--
-- Additive only. `difficulty` on `questions` stays NOT NULL and keeps meaning
-- exactly what it always has (report/UI continuity) — `tier` is the new
-- escalation axis it now derives from (`tier + 1`), not a replacement for it.
-- Both new `questions` columns and both new `answers` columns are nullable so
-- a row from before this migration, or a question/answer the Stage-6 agents
-- didn't annotate, reads back as "no tier data" rather than failing a
-- NOT NULL check retroactively.

ALTER TABLE questions
  ADD COLUMN IF NOT EXISTS tier SMALLINT CHECK (tier BETWEEN 1 AND 3),
  ADD COLUMN IF NOT EXISTS target_concept_ids TEXT[];

ALTER TABLE answers
  -- { transcribedInputChunk, verifiedConceptIds[], unverifiedConceptIds[], antiPatternsDetected[] }
  ADD COLUMN IF NOT EXISTS extraction JSONB,
  -- { systemDirective, targetConceptIdForNextPrompt, synthesizedFramingStrategy, generatedFollowUpPrompt }
  ADD COLUMN IF NOT EXISTS next_action JSONB;

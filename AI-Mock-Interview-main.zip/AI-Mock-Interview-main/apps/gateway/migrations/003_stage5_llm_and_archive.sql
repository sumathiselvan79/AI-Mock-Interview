-- Stage 5 — LLM-backed agents and session archival (INSTRUCTIONS.md §11.6).
--
-- Primary application Postgres only. The `session_archives` table lives on a
-- SEPARATE, Supabase-hosted instance and is created by
-- `migrations/supabase/001_session_archives.sql` — deliberately not here, so
-- running this file can never create the archive table in the wrong database.

-- User profile fields required before a session can be archived (§6, §11.4).
-- Nullable: existing accounts predate them, and archiving refuses on a missing
-- `full_name` rather than archiving with blanks.
ALTER TABLE users ADD COLUMN IF NOT EXISTS full_name    TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS department   TEXT;
-- TEXT, not INT: covers "3rd Year", "Alumni", "Grad" (§6).
ALTER TABLE users ADD COLUMN IF NOT EXISTS program_year TEXT;

-- `sessions.jd_fit` is already JSONB (Stage 1). The Stage 5 `rationale`,
-- `topicRelevance`, `promptVersion` and `insufficientSignal` fields are a shape
-- change validated by /packages/mcp-schemas, not a column migration (§11.6).
--
-- What DOES need a column is the fingerprint of the resume those generated
-- fields came from, so the harness can look up the Memory Agent's working copy
-- on a resume replace without re-deriving it from a file that may already have
-- been hard-deleted (§4.7, §8).
ALTER TABLE sessions ADD COLUMN IF NOT EXISTS jd_fit_fingerprint TEXT;

-- `answers.follow_ups` is already JSONB (Stage 1). The per-follow-up
-- score/rationale/evidence_spans (§6 FollowUpExchange) is likewise a shape
-- change rather than a column migration — and deliberately NOT a new
-- `follow_up_evaluations` table: `evaluations.evidence_spans` already means
-- "indices into answers.transcript" for every existing reader, so reusing that
-- table for a follow-up's transcript would silently break them (§11.7).

-- One nullable column so an LLM-produced score is queryable by the prompt
-- version that produced it, without a second table (§11.6).
ALTER TABLE evaluations ADD COLUMN IF NOT EXISTS prompt_version TEXT;

-- Questions carry the same stamp when their text was generated rather than
-- picked from the bank (§6 Question, §11.5). Absent means "question bank".
ALTER TABLE questions ADD COLUMN IF NOT EXISTS prompt_version TEXT;

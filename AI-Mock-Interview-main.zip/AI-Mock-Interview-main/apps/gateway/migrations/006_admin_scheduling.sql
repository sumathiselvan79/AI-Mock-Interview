-- Stage 7 — Admin user directory + interview scheduling.
-- See ADMIN_FEATURE_PROMPT.md and TRACKING.md Stage 7. Additive only.
--
-- NOT added here: `users.department`. It already exists — migration
-- 003_stage5_llm_and_archive.sql added it for the session archive, and the
-- directory filters that same column rather than introducing a second one
-- (ADMIN_FEATURE_PROMPT.md §Reconciliation item 1).
--
-- One row per (assignment, candidate): scheduling a batch of twelve writes
-- twelve rows, not one row with an array. Each candidate's assignment has its
-- own lifecycle — one may start it, another let it lapse — and a shared row
-- could not represent that without a join table anyway.
--
-- There is deliberately NO consent column. soul.md §"Consent-first monitoring"
-- makes consent the candidate's to give; an Admin pre-answering it is exactly
-- what that rule forbids. The Telemetry Check page stays the only writer of
-- `sessions.consent`.

CREATE TABLE IF NOT EXISTS scheduled_interviews (
  id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  candidate_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  -- Snapshot at scheduling time, so a batch scheduled "for Engineering" still
  -- reads correctly after someone edits their own profile.
  department           TEXT,
  role                 TEXT NOT NULL,
  job_description      TEXT NOT NULL DEFAULT '',
  interview_type       TEXT NOT NULL CHECK (interview_type IN (
                         'behavioral', 'technical', 'behavioral+technical', 'coding', 'full')),
  difficulty           TEXT NOT NULL CHECK (difficulty IN ('junior', 'mid', 'senior', 'staff+')),
  duration_minutes     INTEGER NOT NULL CHECK (duration_minutes BETWEEN 10 AND 180),
  scheduled_for        TIMESTAMPTZ NOT NULL,
  deadline             TIMESTAMPTZ,
  recurring            TEXT NOT NULL DEFAULT 'none'
                         CHECK (recurring IN ('none', 'weekly', 'biweekly', 'monthly')),
  coding_round_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  -- Admin-only. Never serialized onto a student-facing response — enforced in
  -- the route layer, which has a separate student projection.
  notes                TEXT,
  notify_via           JSONB NOT NULL DEFAULT '["in_app"]'::jsonb,
  -- Only the four states something actually WRITES are storable. `sent` and
  -- `missed` are derived from the clock at read time by `effectiveStatus` —
  -- nothing in this repo runs on a timer, so a stored `sent` would be a lie
  -- until some job flipped it.
  status               TEXT NOT NULL DEFAULT 'pending'
                         CHECK (status IN ('pending', 'started', 'completed', 'cancelled')),
  -- Set when the candidate starts the session this seeded.
  session_id           UUID REFERENCES sessions(id) ON DELETE SET NULL,
  created_by           UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at           TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- A deadline before the window opens is not a tight schedule, it is a
  -- schedule that can never be started.
  CONSTRAINT deadline_after_window CHECK (deadline IS NULL OR deadline > scheduled_for)
);

-- The student's home page reads "my startable assignments" on every load; the
-- admin list reads by status and window. Both are covered here.
CREATE INDEX IF NOT EXISTS idx_scheduled_candidate
  ON scheduled_interviews(candidate_id, status, scheduled_for DESC);
CREATE INDEX IF NOT EXISTS idx_scheduled_window
  ON scheduled_interviews(scheduled_for DESC);
CREATE INDEX IF NOT EXISTS idx_scheduled_created_by
  ON scheduled_interviews(created_by);

-- The directory's aggregates are grouped by candidate over reports and
-- sessions. Without these, listing N users costs N report scans — the "no N+1"
-- requirement in ADMIN_FEATURE_PROMPT.md Part 1 is as much an index question as
-- a query-shape one.
CREATE INDEX IF NOT EXISTS idx_reports_candidate_created
  ON reports(candidate_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_sessions_candidate_created
  ON sessions(candidate_id, created_at DESC);

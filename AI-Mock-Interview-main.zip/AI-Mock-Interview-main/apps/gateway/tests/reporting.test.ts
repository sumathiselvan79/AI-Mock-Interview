/**
 * TRACKING.md Stage 4 — Reporting, Admin, hardening. Gate tests:
 *
 * 1. Unit test the Report Agent: every competency score has non-empty
 *    evidence, and it refuses to output a score it cannot evidence.
 * 2. RBAC: a student token gets 403 on GET /admin/reports; an admin token
 *    cannot hit a "start session as candidate" endpoint.
 * 3. Manual check (automated here): complete a session as a student, then
 *    confirm it appears on the Admin dashboard, read as a separate request —
 *    nothing about it depends on the student's session still being live.
 * 4. Retention: after REPORT_GENERATION, raw resume and full transcripts are
 *    deleted (or retained only where the candidate opted in) — checked
 *    against storage directly, not the API response.
 * 5. Load test: concurrent sessions through the Harness Agent's routing path
 *    do not bleed state between each other.
 * 6. Full regression: five scripted personas (varied roles, resumes, JDs)
 *    end-to-end, checked for fabricated claims the mechanical way this repo
 *    already uses elsewhere — every cited evidence string must be a verbatim
 *    substring of something the candidate actually said.
 */

import { describe, expect, it, afterEach } from "vitest";
import { REDACTED_TRANSCRIPT, REPORT_DISCLAIMER } from "@mia/shared-types";
import {
  BACKEND_JOB_DESCRIPTION,
  JUNIOR_FRONTEND_MD,
  PRODUCT_MANAGER_TXT,
  SENIOR_BACKEND_TXT,
  UNSTRUCTURED_TXT,
  encoder,
} from "./fixtures/resumes.js";
import { ADMIN, STUDENT, bearer, buildHarness, loginToken, seedUsers, type TestHarness } from "./helpers.js";

const STRONG_ANSWER = `At my last company we had a settlement service that was timing out under load.
I profiled the hot path and found we were doing a synchronous write to Postgres inside the request.
I moved that write onto a queue and added an idempotency key so retries could not double-charge anyone.
We chose the queue rather than a bigger database instance because the write was not read back immediately,
and the tradeoff was that reconciliation became eventually consistent, which finance signed off on.
As a result p99 latency went from 900ms to 210ms and the on-call pages for that service stopped.`;

const THIN_ANSWER = "Yeah, I did that once.";

const harnesses: TestHarness[] = [];

async function harness(): Promise<TestHarness> {
  const h = await buildHarness();
  harnesses.push(h);
  return h;
}

afterEach(async () => {
  while (harnesses.length > 0) await harnesses.pop()!.close();
});

async function studentSession(
  h: TestHarness,
  role: string,
  opts: { jobDescription?: string; resume?: string; consentAudioRecording?: boolean } = {},
): Promise<{ token: string; sessionId: string }> {
  const token = await loginToken(h, STUDENT);
  const created = await h.api
    .post("/sessions")
    .set(...bearer(token))
    .send({ role, job_description: opts.jobDescription ?? "" })
    .expect(201);
  const sessionId = created.body.session_id as string;

  if (opts.resume) {
    await h.api
      .post(`/sessions/${sessionId}/resume`)
      .set(...bearer(token))
      .send({
        filename: "resume.txt",
        content_type: "text/plain",
        data_base64: Buffer.from(encoder.encode(opts.resume)).toString("base64"),
      })
      .expect(201);
  }

  await h.api.post(`/sessions/${sessionId}/advance`).set(...bearer(token)).send({ to: "CONFIG" }).expect(200);
  await h.api
    .post(`/sessions/${sessionId}/advance`)
    .set(...bearer(token))
    .send({ to: "TELEMETRY_CHECK" })
    .expect(200);
  await h.api
    .post(`/sessions/${sessionId}/telemetry-check`)
    .set(...bearer(token))
    .send({
      mic_ok: true,
      speaker_ok: true,
      consent: { telemetry: true, audio_recording: opts.consentAudioRecording === true },
    })
    .expect(200);

  return { token, sessionId };
}

/** Answers every question the budget allows with `answerText`; returns each transcript submitted. */
async function runFullInterview(
  h: TestHarness,
  token: string,
  sessionId: string,
  answerText: string,
): Promise<string[]> {
  await h.api.post(`/sessions/${sessionId}/begin`).set(...bearer(token)).expect(200);

  const submitted: string[] = [];
  for (let turn = 0; turn < 20; turn += 1) {
    const next = await h.api.get(`/sessions/${sessionId}/questions/next`).set(...bearer(token)).expect(200);
    if (next.body.done) break;
    await h.api
      .post(`/sessions/${sessionId}/answers`)
      .set(...bearer(token))
      .send({ question_id: next.body.question.id, transcript: answerText })
      .expect(201);
    submitted.push(answerText);
  }
  return submitted;
}

async function wrapUpAndReport(h: TestHarness, token: string, sessionId: string) {
  await h.api.post(`/sessions/${sessionId}/wrap-up`).set(...bearer(token)).expect(200);
  return h.api.post(`/sessions/${sessionId}/report`).set(...bearer(token)).expect(201);
}

// ---------------------------------------------------------------------------

describe("gate test 1 — the Report Agent", () => {
  it("cites non-empty, verbatim evidence for every competency score", async () => {
    const h = await harness();
    await seedUsers(h);
    const { token, sessionId } = await studentSession(h, "Senior Backend Engineer", {
      jobDescription: BACKEND_JOB_DESCRIPTION,
      resume: SENIOR_BACKEND_TXT,
    });

    await runFullInterview(h, token, sessionId, STRONG_ANSWER);
    const report = await wrapUpAndReport(h, token, sessionId);

    const scores = report.body.report.competencyScores as { competency: string; score: number; evidence: string[] }[];
    expect(scores.length).toBeGreaterThan(0);
    for (const competency of scores) {
      expect(competency.evidence.length).toBeGreaterThan(0);
      expect(competency.score).toBeGreaterThanOrEqual(0);
      expect(competency.score).toBeLessThanOrEqual(5);
      for (const quote of competency.evidence) {
        expect(quote.length).toBeGreaterThan(0);
        expect(STRONG_ANSWER.includes(quote), `evidence "${quote}" is not verbatim from what was said`).toBe(true);
      }
    }
    expect(report.body.report.disclaimer).toBe(REPORT_DISCLAIMER);
  });

  it("refuses to generate a report for a session with nothing scoreable", async () => {
    const h = await harness();
    await seedUsers(h);
    const { token, sessionId } = await studentSession(h, "Senior Backend Engineer");

    // QUESTION_LOOP entered but no question was ever asked or answered.
    await h.api.post(`/sessions/${sessionId}/begin`).set(...bearer(token)).expect(200);
    await h.api.post(`/sessions/${sessionId}/wrap-up`).set(...bearer(token)).expect(200);

    const result = await h.api.post(`/sessions/${sessionId}/report`).set(...bearer(token)).expect(422);
    expect(result.body.error.code).toBe("insufficient_evidence");
    expect(await h.storage.reports.getBySession(sessionId)).toBeNull();
  });

  it("omits a topic it cannot evidence rather than guessing, and says so in focus_areas", async () => {
    const h = await harness();
    await seedUsers(h);
    const { token, sessionId } = await studentSession(h, "Senior Backend Engineer", {
      resume: SENIOR_BACKEND_TXT,
    });

    // Two topics, one question each: one gets a real answer, the other only a
    // thin one that the Eval Tool refuses to score.
    await h.storage.sessions.patch(sessionId, {
      topicPlan: [
        { topic: "databases", maxQuestions: 1, source: "resume" },
        { topic: "system design", maxQuestions: 1, source: "resume" },
      ],
    });
    await h.api.post(`/sessions/${sessionId}/begin`).set(...bearer(token)).expect(200);

    const first = await h.api.get(`/sessions/${sessionId}/questions/next`).set(...bearer(token)).expect(200);
    await h.api
      .post(`/sessions/${sessionId}/answers`)
      .set(...bearer(token))
      .send({ question_id: first.body.question.id, transcript: STRONG_ANSWER })
      .expect(201);
    const scoredTopic = first.body.question.topic as string;

    const second = await h.api.get(`/sessions/${sessionId}/questions/next`).set(...bearer(token)).expect(200);
    await h.api
      .post(`/sessions/${sessionId}/answers`)
      .set(...bearer(token))
      .send({ question_id: second.body.question.id, transcript: THIN_ANSWER })
      .expect(201);
    const thinTopic = second.body.question.topic as string;

    const report = await wrapUpAndReport(h, token, sessionId);
    const scores = report.body.report.competencyScores as { competency: string }[];
    const focusAreas = report.body.report.focusAreas as string[];

    expect(scores.some((c) => c.competency === scoredTopic)).toBe(true);
    expect(scores.some((c) => c.competency === thinTopic)).toBe(false);
    expect(focusAreas.some((f) => f.includes(thinTopic) && /not enough was said/i.test(f))).toBe(true);
  });

  it("folds a coding round into the report as its own evidenced competency", async () => {
    const h = await harness();
    await seedUsers(h);
    const { token, sessionId } = await studentSession(h, "Senior Backend Engineer");

    await h.api.post(`/sessions/${sessionId}/begin`).set(...bearer(token)).expect(200);
    const started = await h.api.post(`/sessions/${sessionId}/coding-round`).set(...bearer(token)).expect(201);
    const entryPoint = started.body.problem.entry_point as string;

    const talkThrough =
      "I would use a hash map keyed by the input because that gives constant time lookups. " +
      "The tradeoff is extra memory, but that is worth it here. One edge case is an empty input.";

    await h.api
      .post(`/sessions/${sessionId}/coding-round/submissions`)
      .set(...bearer(token))
      .send({ code: `function ${entryPoint}() { return null; }`, talk_through: talkThrough })
      .expect(201);

    const report = await wrapUpAndReport(h, token, sessionId);
    const scores = report.body.report.competencyScores as { competency: string; score: number; evidence: string[] }[];
    const coding = scores.find((c) => c.competency === "coding round");

    expect(coding).toBeDefined();
    expect(coding!.evidence.length).toBeGreaterThan(0);
    for (const quote of coding!.evidence) {
      expect(talkThrough.includes(quote)).toBe(true);
    }
  });
});

describe("gate test 2 — RBAC", () => {
  it("gives a student token 403 on GET /admin/reports", async () => {
    const h = await harness();
    await seedUsers(h);
    const token = await loginToken(h, STUDENT);
    await h.api.get("/admin/reports").set(...bearer(token)).expect(403);
  });

  it("gives an admin token 403 on the report-generation action, same as any other candidate-only endpoint", async () => {
    const h = await harness();
    await seedUsers(h);
    const { sessionId } = await studentSession(h, "Senior Backend Engineer");
    const adminToken = await loginToken(h, ADMIN);
    await h.api.post(`/sessions/${sessionId}/report`).set(...bearer(adminToken)).expect(403);
  });
});

describe("gate test 3 — the Admin dashboard shows a report independent of the student's connection", () => {
  it("is readable by the admin as a plain, separate request once the report exists", async () => {
    const h = await harness();
    await seedUsers(h);
    const { token, sessionId } = await studentSession(h, "Senior Backend Engineer", { resume: SENIOR_BACKEND_TXT });
    await runFullInterview(h, token, sessionId, STRONG_ANSWER);
    await wrapUpAndReport(h, token, sessionId);

    // A fresh admin login, no reference to the student's session or token at all.
    const adminToken = await loginToken(h, ADMIN);
    const list = await h.api.get("/admin/reports").set(...bearer(adminToken)).expect(200);
    expect(list.body.reports.some((r: { sessionId: string }) => r.sessionId === sessionId)).toBe(true);

    const detail = await h.api.get(`/admin/reports/${sessionId}`).set(...bearer(adminToken)).expect(200);
    expect(detail.body.report.sessionId).toBe(sessionId);

    const session = await h.storage.sessions.get(sessionId);
    expect(session?.state).toBe("COMPLETED");
  });
});

describe("gate test 4 — retention", () => {
  it("hard-deletes the resume and redacts full transcripts once the report exists", async () => {
    const h = await harness();
    await seedUsers(h);
    const { token, sessionId } = await studentSession(h, "Senior Backend Engineer", { resume: SENIOR_BACKEND_TXT });

    const resumeRef = (await h.storage.sessions.get(sessionId))!.resumeRef!;
    expect(await h.storage.files.exists(resumeRef)).toBe(true);

    await runFullInterview(h, token, sessionId, STRONG_ANSWER);
    await wrapUpAndReport(h, token, sessionId);

    expect(await h.storage.files.exists(resumeRef)).toBe(false);
    expect((await h.storage.sessions.get(sessionId))?.resumeRef).toBeNull();

    for (const question of await h.storage.questions.listBySession(sessionId)) {
      const answer = await h.storage.answers.getByQuestion(question.id);
      expect(answer?.transcript).toBe(REDACTED_TRANSCRIPT);
    }
  });

  it("keeps the full transcript when the candidate opted into audio/recording retention", async () => {
    const h = await harness();
    await seedUsers(h);
    const { token, sessionId } = await studentSession(h, "Senior Backend Engineer", {
      resume: SENIOR_BACKEND_TXT,
      consentAudioRecording: true,
    });

    await runFullInterview(h, token, sessionId, STRONG_ANSWER);
    await wrapUpAndReport(h, token, sessionId);

    for (const question of await h.storage.questions.listBySession(sessionId)) {
      const answer = await h.storage.answers.getByQuestion(question.id);
      expect(answer?.transcript).toBe(STRONG_ANSWER);
    }
  });
});

describe("gate test 5 — concurrent sessions do not bleed state", () => {
  it("keeps topic_counts and transcripts isolated per session under concurrency", async () => {
    const h = await harness();
    await seedUsers(h);

    const roles = [
      "Senior Backend Engineer",
      "Frontend Engineer",
      "Data Engineer",
      "Site Reliability Engineer",
      "Product Manager",
    ];

    const setups = await Promise.all(roles.map((role) => studentSession(h, role)));
    const runs = await Promise.all(
      setups.map(({ token, sessionId }) => runFullInterview(h, token, sessionId, STRONG_ANSWER)),
    );

    setups.forEach(({ sessionId }, index) => {
      expect(runs[index]!.length).toBeGreaterThan(0);
      void sessionId;
    });

    // Every question in every session belongs to that session, and only that one.
    for (const { sessionId } of setups) {
      const questions = await h.storage.questions.listBySession(sessionId);
      expect(questions.every((q) => q.sessionId === sessionId)).toBe(true);
      for (const other of setups) {
        if (other.sessionId === sessionId) continue;
        const otherIds = new Set((await h.storage.questions.listBySession(other.sessionId)).map((q) => q.id));
        expect(questions.some((q) => otherIds.has(q.id))).toBe(false);
      }
    }
  });
});

describe("gate test 6 — five-persona regression", () => {
  const personas: { label: string; role: string; jobDescription?: string; resume?: string }[] = [
    { label: "senior backend, resume + JD", role: "Senior Backend Engineer", jobDescription: BACKEND_JOB_DESCRIPTION, resume: SENIOR_BACKEND_TXT },
    { label: "junior frontend, resume only", role: "Frontend Engineer", resume: JUNIOR_FRONTEND_MD },
    { label: "product manager, non-technical", role: "Product Manager", resume: PRODUCT_MANAGER_TXT },
    { label: "unstructured resume, no headings", role: "Data Engineer", resume: UNSTRUCTURED_TXT },
    { label: "no resume at all, role requirements only", role: "Site Reliability Engineer" },
  ];

  for (const persona of personas) {
    it(`${persona.label}: every claim in the report traces to something actually said`, async () => {
      const h = await harness();
      await seedUsers(h);
      const { token, sessionId } = await studentSession(h, persona.role, {
        ...(persona.jobDescription ? { jobDescription: persona.jobDescription } : {}),
        ...(persona.resume ? { resume: persona.resume } : {}),
      });

      await runFullInterview(h, token, sessionId, STRONG_ANSWER);
      const report = await wrapUpAndReport(h, token, sessionId);
      const body = report.body.report as {
        competencyScores: { competency: string; score: number; evidence: string[] }[];
        strengths: string[];
        focusAreas: string[];
        disclaimer: string;
      };

      expect(body.competencyScores.length).toBeGreaterThan(0);
      expect(body.disclaimer).toBe(REPORT_DISCLAIMER);
      for (const competency of body.competencyScores) {
        expect(competency.evidence.length).toBeGreaterThan(0);
        for (const quote of competency.evidence) {
          expect(STRONG_ANSWER.includes(quote), `persona "${persona.label}": "${quote}" is not verbatim`).toBe(true);
        }
      }
    });
  }
});

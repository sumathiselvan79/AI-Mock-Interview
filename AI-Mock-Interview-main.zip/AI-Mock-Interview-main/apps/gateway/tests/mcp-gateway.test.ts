/**
 * TRACKING.md Stage 1, gate test 4:
 * "Fire one dummy MCP tool call through the gateway and confirm a `tool_called`
 *  telemetry event lands with latency and status — before writing any real
 *  tool, prove the instrumentation path works."
 */

import { afterEach, beforeEach, describe, expect, it } from "vitest";
import type { McpCallContext, TelemetryEvent } from "@mia/shared-types";
import { listServers } from "@mia/mcp-schemas";
import { STUDENT, bearer, buildHarness, loginToken, seedUsers, type TestHarness } from "./helpers.js";

let h: TestHarness;
let token: string;
let sessionId: string;
let ctx: McpCallContext;

beforeEach(async () => {
  h = await buildHarness();
  await seedUsers(h);
  token = await loginToken(h, STUDENT);
  const res = await h.api
    .post("/sessions")
    .set(...bearer(token))
    .send({ role: "Senior Backend Engineer" })
    .expect(201);
  sessionId = res.body.session_id;
  ctx = { sessionId, caller: "harness-agent", sessionToken: res.body.session_token };
});

afterEach(async () => {
  await h.close();
});

const spans = async (): Promise<TelemetryEvent[]> =>
  (await h.storage.telemetry.recent(200)).filter(
    (e) => e.eventType === "tool_called" || e.eventType === "agent_called",
  );

describe("every MCP call emits one instrumented span", () => {
  it("records latency and status for a successful call", async () => {
    const result = await h.mcp.call("_dev", "ping", { nonce: "abc", delay_ms: 25 }, ctx);

    expect(result.ok).toBe(true);
    expect((result.data as { pong: string }).pong).toBe("abc");

    const [span] = await spans();
    expect(span).toBeDefined();
    expect(span!.eventType).toBe("tool_called");
    expect(span!.sessionId).toBe(sessionId);
    expect(span!.payload.server).toBe("_dev");
    expect(span!.payload.method).toBe("ping");
    expect(span!.payload.status).toBe("ok");
    expect(span!.payload.error_code).toBeNull();
    expect(typeof span!.payload.latency_ms).toBe("number");
    // The handler slept 25ms, so the measured latency has to reflect real time.
    expect(span!.payload.latency_ms as number).toBeGreaterThanOrEqual(20);
  });

  it("records a span on the failure path too, with the error code", async () => {
    const result = await h.mcp.call("_dev", "ping", { nonce: "abc", fail: true }, ctx);
    expect(result.ok).toBe(false);

    const [span] = await spans();
    expect(span!.payload.status).toBe("error");
    expect(span!.payload.error_code).toBe("upstream_error");
  });

  it("labels a call to a specialized agent as agent_called", async () => {
    // The Report Agent (Stage 4) refuses a session with nothing scoreable
    // rather than guessing — a stable, real refusal that still shows an
    // agent's error being routed and instrumented like any other.
    await h.mcp.call(
      "report-agent",
      "generate_report",
      { session_id: sessionId, candidate_id: "candidate-1", transcript: [] },
      ctx,
    );
    const [span] = await spans();
    expect(span!.eventType).toBe("agent_called");
    expect(span!.payload.error_code).toBe("insufficient_evidence");
  });
});

describe("the gateway is the choke point", () => {
  it("rejects an unknown server and an unknown method", async () => {
    expect((await h.mcp.call("no-such-server", "ping", {}, ctx)).error?.code).toBe("unknown_server");
    expect((await h.mcp.call("_dev", "no_such_method", {}, ctx)).error?.code).toBe("unknown_method");
  });

  it("rejects a call with a missing or wrong session token", async () => {
    const noToken = await h.mcp.call("_dev", "ping", { nonce: "a" }, { ...ctx, sessionToken: "" });
    expect(noToken.error?.code).toBe("unauthorized");

    const wrongToken = await h.mcp.call("_dev", "ping", { nonce: "a" }, { ...ctx, sessionToken: "x.y.z" });
    expect(wrongToken.error?.code).toBe("unauthorized");
  });

  it("rejects a token minted for a different session", async () => {
    const other = await h.api
      .post("/sessions")
      .set(...bearer(token))
      .send({ role: "Backend Engineer" })
      .expect(201);
    const result = await h.mcp.call("_dev", "ping", { nonce: "a" }, {
      ...ctx,
      sessionToken: other.body.session_token,
    });
    expect(result.error?.code).toBe("unauthorized");
  });

  it("validates the request against its JSON Schema before the server is reached", async () => {
    const missingRequired = await h.mcp.call("_dev", "ping", {}, ctx);
    expect(missingRequired.error?.code).toBe("schema_invalid_request");

    const unknownField = await h.mcp.call("_dev", "ping", { nonce: "a", extra: true }, ctx);
    expect(unknownField.error?.code).toBe("schema_invalid_request");

    // A schema-rejected call is still instrumented — a rejection is an event.
    expect(await spans()).toHaveLength(2);
  });

  it("lets only the Harness Agent reach the Speech Service (INSTRUCTIONS.md §5.6)", async () => {
    const fromCodingAgent = await h.mcp.call(
      "tool-speech-service",
      "synthesize_speech",
      { text: "hello" },
      { ...ctx, caller: "coding-agent" },
    );
    expect(fromCodingAgent.error?.code).toBe("unauthorized");

    // The harness gets past the caller check and reaches the real tool.
    const fromHarness = await h.mcp.call<{ audio_url: string; duration_ms: number }>(
      "tool-speech-service",
      "synthesize_speech",
      { text: "hello", session_id: sessionId },
      { ...ctx, caller: "harness-agent" },
    );
    expect(fromHarness.ok).toBe(true);
    expect(fromHarness.data?.audio_url).toMatch(/^\/audio\//);
  });

  it("rate limits per session and emits a rate_limit_exceeded event", async () => {
    const limit = h.config.mcpRateLimit;
    for (let i = 0; i < limit; i += 1) {
      expect((await h.mcp.call("_dev", "ping", { nonce: `n${i}` }, ctx)).ok).toBe(true);
    }
    const overflow = await h.mcp.call("_dev", "ping", { nonce: "over" }, ctx);
    expect(overflow.error?.code).toBe("rate_limited");

    const events = await h.storage.telemetry.recent(400);
    expect(events.some((e) => e.eventType === "rate_limit_exceeded")).toBe(true);
  });
});

describe("telemetry payloads carry no candidate content (INSTRUCTIONS.md §8)", () => {
  it("drops forbidden keys and non-scalar values, recording only what was dropped", async () => {
    const event = await h.storage.telemetry.emit("question_asked", sessionId, {
      question_id: "q-1",
      transcript: "the candidate said something long and personal",
      resume_text: "Jane Doe, 10 years experience",
      nested: { a: 1 } as never,
      difficulty: 3,
    });

    expect(event.payload.question_id).toBe("q-1");
    expect(event.payload.difficulty).toBe(3);
    expect(event.payload.transcript).toBeUndefined();
    expect(event.payload.resume_text).toBeUndefined();
    expect(event.payload.nested).toBeUndefined();
    expect(event.payload.redacted_keys).toBe("transcript,resume_text,nested");
    expect(JSON.stringify(event)).not.toContain("Jane Doe");
  });
});

describe("MCP server registry", () => {
  it("registers every agent and tool server from CLAUDE.md §2", async () => {
    const registered = h.mcp.registered();
    for (const server of [
      "resume-service-agent",
      "question-agent",
      "followup-agent",
      "coding-agent",
      "time-tracking-agent",
      "memory-agent",
      "report-agent",
      "tool-resume-parser",
      "tool-eval",
      "tool-time-tracking",
      "tool-telemetry",
      "tool-clipboard-monitor",
      "tool-speech-service",
    ]) {
      expect(registered).toContain(server);
      // Registration is only real if the schema registry knows the server too.
      expect(listServers()).toContain(server);
    }
  });

  it("exposes the dev passthrough route for a hand-fired call", async () => {
    const res = await h.api
      .post("/internal/mcp/call")
      .set(...bearer(token))
      .send({ session_id: sessionId, server: "_dev", method: "ping", params: { nonce: "manual" } })
      .expect(200);

    expect(res.body.ok).toBe(true);
    expect(res.body.data.pong).toBe("manual");
    expect(typeof res.body.latencyMs).toBe("number");
  });
});

/**
 * POST /auth/dev-login — goal: "Build local auth (dev-login now, real auth
 * later, no rework)".
 *
 * Covers the three things that decision is actually staking a claim on:
 *  - the route is unreachable unless both env conditions hold (config.ts
 *    computes NODE_ENV !== "production" && ALLOW_DEV_AUTH === "true" once,
 *    into `devAuthEnabled`)
 *  - role is resolved from the admin-email allowlist, never from the
 *    request body, in either direction
 *  - the token dev-login mints is a normal role-scoped token — RBAC treats
 *    it exactly like a passcode-login token
 */

import { afterEach, describe, expect, it } from "vitest";
import { loadConfig } from "../src/config.js";
import { bearer, buildHarness, type TestHarness } from "./helpers.js";

let h: TestHarness | undefined;

afterEach(async () => {
  await h?.close();
  h = undefined;
});

describe("loadConfig: devAuthEnabled gate", () => {
  it("is false with no env flag set, regardless of NODE_ENV", () => {
    expect(loadConfig({ NODE_ENV: "development" }).devAuthEnabled).toBe(false);
    expect(loadConfig({ NODE_ENV: "test" }).devAuthEnabled).toBe(false);
  });

  it("is false in production even with the flag set", () => {
    const config = loadConfig({
      NODE_ENV: "production",
      ALLOW_DEV_AUTH: "true",
      AUTH_TOKEN_SECRET: "a".repeat(32),
    });
    expect(config.devAuthEnabled).toBe(false);
  });

  it("is true only outside production AND with the flag set", () => {
    expect(loadConfig({ NODE_ENV: "development", ALLOW_DEV_AUTH: "true" }).devAuthEnabled).toBe(true);
    expect(loadConfig({ NODE_ENV: "test", ALLOW_DEV_AUTH: "true" }).devAuthEnabled).toBe(true);
  });
});

describe("POST /auth/dev-login route registration", () => {
  it("is unreachable when devAuthEnabled is false (the default test config)", async () => {
    h = await buildHarness();
    // The route was never mounted, so the unscoped RBAC middleware below it
    // in app.ts is what answers — 401, same as any other unrecognized path.
    // A gated-off dev-login is indistinguishable from a route that was never
    // built at all; it doesn't even leak its own existence.
    await h.api.post("/auth/dev-login").send({ email: "anyone@example.com" }).expect(401);
  });

  it("is reachable once devAuthEnabled is true", async () => {
    h = await buildHarness({ config: { devAuthEnabled: true } });
    const res = await h.api.post("/auth/dev-login").send({ email: "anyone@example.com" }).expect(200);
    expect(typeof res.body.token).toBe("string");
    expect(res.body.user.email).toBe("anyone@example.com");
  });
});

describe("POST /auth/dev-login role resolution", () => {
  it("ignores a client-supplied role and defaults an unlisted email to student", async () => {
    h = await buildHarness({ config: { devAuthEnabled: true, adminEmailAllowlist: [] } });
    const res = await h.api
      .post("/auth/dev-login")
      .send({ email: "nobody@example.com", role: "admin" })
      .expect(200);
    expect(res.body.user.role).toBe("student");
  });

  it("grants admin only via the allowlist, even if the body says student", async () => {
    h = await buildHarness({
      config: { devAuthEnabled: true, adminEmailAllowlist: ["boss@example.com"] },
    });
    const res = await h.api
      .post("/auth/dev-login")
      .send({ email: "Boss@Example.com", role: "student" })
      .expect(200);
    expect(res.body.user.role).toBe("admin");
  });

  it("mints a token RBAC treats identically to a passcode-login token", async () => {
    h = await buildHarness({
      config: { devAuthEnabled: true, adminEmailAllowlist: ["boss@example.com"] },
    });
    const adminLogin = await h.api.post("/auth/dev-login").send({ email: "boss@example.com" }).expect(200);
    const studentLogin = await h.api
      .post("/auth/dev-login")
      .send({ email: "candidate@example.com" })
      .expect(200);

    await h.api.get("/admin/reports").set(...bearer(adminLogin.body.token)).expect(200);
    await h.api.get("/admin/reports").set(...bearer(studentLogin.body.token)).expect(403);
    await h.api.get("/me/stats").set(...bearer(studentLogin.body.token)).expect(200);
    await h.api.get("/me/stats").set(...bearer(adminLogin.body.token)).expect(403);
  });

  it("requires an email", async () => {
    h = await buildHarness({ config: { devAuthEnabled: true } });
    await h.api.post("/auth/dev-login").send({}).expect(400);
  });
});

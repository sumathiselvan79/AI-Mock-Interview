/**
 * TRACKING.md Stage 2, gate test 1:
 * "Run the Resume Parser against 3–5 sample resumes of different
 *  formats/lengths; confirm every `topic_relevance` entry traces back to actual
 *  resume text (spot-check by hand — this is the rule most likely to silently
 *  drift)."
 *
 * The hand spot-check is automated here as an exact-substring assertion: every
 * `evidence` string must appear verbatim in the source document. That is the
 * strongest available form of "traces back to actual resume text", and it fails
 * loudly the moment anything starts paraphrasing.
 */

import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { computeJdFit, computeTopicRelevance, gapTopics } from "@mia/resume-service-agent";
import { extractLinesFromPdf, toLines } from "@mia/tool-resume-parser";
import {
  BACKEND_JOB_DESCRIPTION,
  NEARLY_EMPTY_TXT,
  SENIOR_BACKEND_TXT,
  encoder,
  makePdf,
  sampleResumes,
} from "./fixtures/resumes.js";
import { STUDENT, bearer, buildHarness, loginToken, seedUsers, type TestHarness } from "./helpers.js";

let h: TestHarness;
let token: string;
let sessionId: string;

beforeEach(async () => {
  h = await buildHarness();
  await seedUsers(h);
  token = await loginToken(h, STUDENT);
  const res = await h.api
    .post("/sessions")
    .set(...bearer(token))
    .send({ role: "Senior Backend Engineer", job_description: BACKEND_JOB_DESCRIPTION })
    .expect(201);
  sessionId = res.body.session_id;
});

afterEach(async () => {
  await h.close();
});

async function upload(sample: {
  filename: string;
  contentType: string;
  bytes: Uint8Array;
}): Promise<{ status: number; body: Record<string, unknown> }> {
  const res = await h.api
    .post(`/sessions/${sessionId}/resume`)
    .set(...bearer(token))
    .send({
      filename: sample.filename,
      content_type: sample.contentType,
      data_base64: Buffer.from(sample.bytes).toString("base64"),
    });
  return { status: res.status, body: res.body };
}

/**
 * Collapses whitespace before comparing: text extractors legitimately differ on
 * line wrapping, but not on the words themselves.
 */
const normalize = (text: string): string => text.replace(/\s+/g, " ").trim().toLowerCase();

describe("resume parsing across formats and lengths", () => {
  for (const sample of sampleResumes()) {
    it(`parses and profiles: ${sample.label}`, async () => {
      const { status, body } = await upload(sample);
      expect(status, JSON.stringify(body)).toBe(201);

      const topicRelevance = body.topic_relevance as {
        topic: string;
        relevance_score: number;
        evidence: string;
      }[];

      expect(topicRelevance.length).toBeGreaterThan(0);

      const source = normalize(sample.sourceText);
      for (const entry of topicRelevance) {
        // The claim that matters: this evidence is real text from the document.
        expect(
          source.includes(normalize(entry.evidence)),
          `evidence for "${entry.topic}" is not literal resume text: ${entry.evidence}`,
        ).toBe(true);
        expect(entry.evidence.trim().length).toBeGreaterThan(0);
        expect(entry.relevance_score).toBeGreaterThan(0);
        expect(entry.relevance_score).toBeLessThanOrEqual(1);
      }
    });
  }

  it("finds the topics a senior backend resume actually supports", async () => {
    const lines = toLines(SENIOR_BACKEND_TXT);
    const relevance = computeTopicRelevance(lines);
    const topics = relevance.map((t) => t.topic);

    expect(topics).toContain("distributed systems");
    expect(topics).toContain("databases");
    expect(topics).toContain("reliability and operations");
    expect(topics).toContain("behavioral: leadership");

    // And nothing it does not: this resume never mentions ML work. (It does
    // mention "the mobile app" in passing, and the parser is right to notice
    // that — the rule is that a topic needs real text behind it, not that a
    // backend resume can only produce backend topics.)
    expect(topics).not.toContain("machine learning");
  });

  it("quotes the strongest matching line as evidence, verbatim", async () => {
    const lines = toLines(SENIOR_BACKEND_TXT);
    const distributed = computeTopicRelevance(lines).find((t) => t.topic === "distributed systems");
    expect(distributed).toBeDefined();
    expect(SENIOR_BACKEND_TXT).toContain(distributed!.evidence);
    expect(distributed!.evidence).toMatch(/kafka|event bus/i);
  });

  it("reports an unreadable file plainly instead of inventing a profile", async () => {
    const { status, body } = await upload({
      filename: "scanned.txt",
      contentType: "text/plain",
      bytes: encoder.encode(NEARLY_EMPTY_TXT),
    });
    expect(status).toBe(422);
    expect(body.error).toMatchObject({ code: "parse_failed" });
    expect(String((body.error as { message: string }).message)).toMatch(/scanned|words of text/i);
  });

  it("rejects a format it cannot read rather than guessing", async () => {
    const { status, body } = await upload({
      filename: "resume.doc",
      contentType: "application/msword",
      bytes: encoder.encode(SENIOR_BACKEND_TXT),
    });
    expect(status).toBe(415);
    expect(body.error).toMatchObject({ code: "unsupported_format" });
  });
});

describe("JD fit is informational, and gaps become topics", () => {
  it("matches requirements the resume supports and flags the rest as gaps", () => {
    const lines = toLines(SENIOR_BACKEND_TXT);
    const relevance = computeTopicRelevance(lines);
    const fit = computeJdFit(BACKEND_JOB_DESCRIPTION, lines, relevance);

    expect(fit.fitScore).toBeGreaterThan(0);
    expect(fit.fitScore).toBeLessThanOrEqual(1);
    expect(fit.matchedRequirements.length).toBeGreaterThan(0);

    // This resume says nothing about ML, and the JD asks for it.
    const allGaps = fit.gaps.join(" ").toLowerCase();
    expect(allGaps).toContain("machine learning");

    // Every matched requirement and gap is a real line from the JD.
    for (const requirement of [...fit.matchedRequirements, ...fit.gaps]) {
      expect(normalize(BACKEND_JOB_DESCRIPTION)).toContain(normalize(requirement));
    }
  });

  it("turns unmet JD requirements into interview topics", () => {
    const lines = toLines(SENIOR_BACKEND_TXT);
    const relevance = computeTopicRelevance(lines);
    const fit = computeJdFit(BACKEND_JOB_DESCRIPTION, lines, relevance);
    const topics = gapTopics(fit.gaps, relevance);

    // A gap is a reason to ask, not to avoid (soul.md §"Balanced coverage").
    expect(topics).toContain("machine learning");
  });

  it("never blocks starting, and says so on the config endpoint", async () => {
    await upload(sampleResumes()[1]!); // junior frontend resume against a backend JD
    const res = await h.api.get(`/sessions/${sessionId}/jd-fit`).set(...bearer(token)).expect(200);

    expect(res.body.blocks_start).toBe(false);
    expect(String(res.body.note)).toMatch(/not a judgement/i);
  });
});

describe("topic matching does not false-positive on a term that is also common English/ML vocabulary", () => {
  // Regression fixture: a real AI/ML resume upload once surfaced six unrelated
  // hardware/EE topics (control systems, analog electronics, power systems,
  // signal processing, instrumentation and measurement, pcb design and layout)
  // because each topic's term list carried a bare word — "feedback", "via",
  // "transformer", "sampling", "precision" — that also occurs in ordinary
  // ML/software phrasing ("feedback loop", "via a NestJS ... architecture",
  // ML "Transformer", "rejection sampling", "high precision"). Fixed by
  // qualifying those terms in packages/interview-domain/src/topics.ts.
  const AI_ML_RESUME_LINES = [
    "Mentor and guide junior AI/ML engineers, fostering a culture of continuous learning and improvement.",
    "Extensive experience with machine learning frameworks and libraries (e.g., TensorFlow, PyTorch,",
    "scikit-learn, Keras).",
    "Architected a scalable, full-stack RAG system using FastAPI, Streamlit, MongoDB, Qdrant, and Hugging Face",
    "Transformers, implementing voice-enabled semantic search across multi-PDF environments that improved retrieval",
    "speeds by 80% while ensuring concurrent request handling through enterprise-grade REST APIs.",
    "Developed a hybrid ILP-AI Hospital IVR system supporting 1,000+ concurrent scenarios via a",
    "NestJS/Python microservices architecture integrated with HL7/FHIR protocols.",
    "Git and GitHub",
    "Engineered a self-refining Knowledge Graph engine using Neo4j Aura and Gemini LLMs that utilizes an",
    "LLM-as-a-Judge feedback loop and rejection sampling to autonomously extract, score, and map complex job",
    "descriptions to deduplicated professional taxonomies with high precision.",
  ];

  const BOGUS_TOPICS = [
    "control systems",
    "analog electronics",
    "power systems",
    "signal processing",
    "instrumentation and measurement",
    "pcb design and layout",
  ];

  it("finds none of the bogus topics from plain-text lines", () => {
    const relevance = computeTopicRelevance(AI_ML_RESUME_LINES);
    const found = relevance.map((t) => t.topic).filter((topic) => BOGUS_TOPICS.includes(topic));
    expect(found).toEqual([]);
    // And the genuine signal is still there.
    expect(relevance.map((t) => t.topic)).toContain("machine learning");
  });

  it("finds none of the bogus topics through the real PDF extraction path end to end", async () => {
    // Exercises the actual pdfjs-dist-based extractor (mcp-servers/tool-resume-parser/src/pdf-layout.ts),
    // not just computeTopicRelevance on hand-typed lines — the whole point of
    // the regression is that it only reproduces once text has round-tripped
    // through real PDF parsing.
    const bytes = makePdf(AI_ML_RESUME_LINES);
    const lines = await extractLinesFromPdf(bytes);

    // The PDF round trip must not have dropped or split any word either.
    const extractedText = lines.join(" ");
    for (const word of AI_ML_RESUME_LINES.join(" ").split(/\s+/).filter((w) => w.length > 3)) {
      expect(extractedText, `"${word}" did not survive the PDF round trip`).toContain(word);
    }

    const relevance = computeTopicRelevance(lines);
    const found = relevance.map((t) => t.topic).filter((topic) => BOGUS_TOPICS.includes(topic));
    expect(found).toEqual([]);
    expect(relevance.map((t) => t.topic)).toContain("machine learning");
  });
});

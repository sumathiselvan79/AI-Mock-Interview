/**
 * Stage 6 gate test 7 (added in response to Stop-hook feedback on the first
 * pass): everything in `tiered-concepts.test.ts` exercises the tier/concept/
 * directive logic as pure functions. This test instead drives the REAL
 * question-agent and followup-agent MCP servers, through the real gateway
 * (auth, schema validation, telemetry — the same `/internal/mcp/call` dev
 * passthrough `mcp-gateway.test.ts` uses for its own hand-fired-call gate
 * test), and asserts on the LIVE values a running exchange actually produces.
 *
 * It drives one topic through all three tiers directly rather than relying on
 * a realistic multi-topic session to happen to repeat one topic three times —
 * a first attempt at this test tried exactly that and it starved: with a
 * strong-scoring generic answer, the SESSION-WIDE difficulty curve escalates
 * fast enough that almost every topic's *opening* question already lands at
 * tier 2, leaving little room to observe 1 -> 2 -> 3 within one topic inside a
 * single realistic session. Driving one topic directly removes that
 * confound and shows the mechanism itself, unambiguously.
 */

import { randomUUID } from "node:crypto";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { BACKEND_JOB_DESCRIPTION, SENIOR_BACKEND_TXT, encoder } from "./fixtures/resumes.js";
import { STUDENT, bearer, buildHarness, loginToken, seedUsers, type TestHarness } from "./helpers.js";

let h: TestHarness;
let token: string;
let sessionId: string;

const STRONG_ANSWER = `At my last company we had a settlement service that was timing out under load.
I profiled the hot path and found we were doing a synchronous write to Postgres inside the request.
I moved that write onto a queue and added an idempotency key so retries could not double-charge anyone.
We chose the queue rather than a bigger database instance because the write was not read back immediately,
and the tradeoff was that reconciliation became eventually consistent, which finance signed off on.
As a result p99 latency went from 900ms to 210ms and the on-call pages for that service stopped.`;

async function mcpCall<T = Record<string, unknown>>(server: string, method: string, params: unknown): Promise<T> {
  const res = await h.api
    .post("/internal/mcp/call")
    .set(...bearer(token))
    .send({ session_id: sessionId, server, method, params })
    .expect(200);
  expect(res.body.ok, JSON.stringify(res.body)).toBe(true);
  return res.body.data as T;
}

beforeEach(async () => {
  h = await buildHarness();
  await seedUsers(h);
  token = await loginToken(h, STUDENT);

  const created = await h.api
    .post("/sessions")
    .set(...bearer(token))
    .send({ role: "Senior Backend Engineer", job_description: BACKEND_JOB_DESCRIPTION })
    .expect(201);
  sessionId = created.body.session_id;

  await h.api
    .post(`/sessions/${sessionId}/resume`)
    .set(...bearer(token))
    .send({
      filename: "priya-raman.txt",
      content_type: "text/plain",
      data_base64: Buffer.from(encoder.encode(SENIOR_BACKEND_TXT)).toString("base64"),
    })
    .expect(201);

  await h.api.post(`/sessions/${sessionId}/advance`).set(...bearer(token)).send({ to: "CONFIG" }).expect(200);
  await h.api
    .post(`/sessions/${sessionId}/advance`)
    .set(...bearer(token))
    .send({ to: "TELEMETRY_CHECK" })
    .expect(200);
  await h.api
    .post(`/sessions/${sessionId}/telemetry-check`)
    .set(...bearer(token))
    .send({ mic_ok: true, speaker_ok: true, consent: { telemetry: true } })
    .expect(200);
});

afterEach(async () => {
  await h.close();
});

describe("gate test 7 — one topic driven live through all three tiers", () => {
  it("escalates tier 1 -> 2 -> 3 as real scores come in, with real concept verification and directives at every step", async () => {
    const topicPlan = [{ topic: "databases", max_questions: 3, source: "resume" as const }];

    type LiveTurn = {
      tier: number;
      difficulty: number;
      targetConceptIds: string[];
      score: number;
      antiPatternsDetected: string[];
      verifiedConceptIds: string[];
      unverifiedConceptIds: string[];
      nextAction: { system_directive: string; target_concept_id_for_next_prompt: string | null };
    };
    const turns: LiveTurn[] = [];

    // Simulates exactly what the Harness Agent derives from the Memory Agent
    // and threads through on every real call (§12.2, §12.3) — topic_tier and
    // topic_scores, growing turn by turn from what THIS loop actually
    // observes, never invented ahead of time.
    const topicTier: Record<string, number> = {};
    const topicScores: Record<string, number[]> = {};

    for (let i = 0; i < 3; i += 1) {
      const questionResult = await mcpCall<{
        question: { id: string; topic: string; tier: number; difficulty: number; target_concept_ids: string[] };
      }>("question-agent", "get_next_question", {
        session_id: sessionId,
        role: "Senior Backend Engineer",
        topic_plan: topicPlan,
        topic_counts: { databases: i },
        topic_tier: topicTier,
        topic_scores: topicScores,
        asked_question_ids: [],
      });

      const q = questionResult.question;
      expect(q.topic).toBe("databases");

      const followUp = await mcpCall<{
        anti_patterns_detected: string[];
        verified_concept_ids: string[];
        unverified_concept_ids: string[];
        next_action: { system_directive: string; target_concept_id_for_next_prompt: string | null };
        score?: { value: number };
      }>("followup-agent", "consider_follow_up", {
        session_id: sessionId,
        question: q.id,
        // A real Evaluation row needs an answer_id to key off of (§4.4:
        // "supplying it is what makes the Eval Tool persist the score") —
        // there's no separately-created Answer here since this test drives
        // the agents directly rather than through POST /answers, so a fresh
        // id stands in for one, same as any other answer_id the Eval Tool
        // treats opaquely.
        answer_id: randomUUID(),
        answer_transcript: STRONG_ANSWER,
        rubric_id: "technical_v1",
        tier: q.tier,
        target_concept_ids: q.target_concept_ids,
      });

      const score = followUp.score?.value ?? 0;
      turns.push({
        tier: q.tier,
        difficulty: q.difficulty,
        targetConceptIds: q.target_concept_ids,
        score,
        antiPatternsDetected: followUp.anti_patterns_detected,
        verifiedConceptIds: followUp.verified_concept_ids,
        unverifiedConceptIds: followUp.unverified_concept_ids,
        nextAction: followUp.next_action,
      });

      // What the Harness Agent would persist and feed forward into the next
      // `get_next_question` call (§12.2/§12.3) — the loop's only state.
      topicTier.databases = q.tier;
      (topicScores.databases ??= []).push(score);
    }

    // Printed so the live values are visible in test output, not just
    // asserted on blind.
    // eslint-disable-next-line no-console
    console.log("live tier escalation, one topic, three real MCP round trips:\n" + JSON.stringify(turns, null, 2));

    expect(turns.map((t) => t.tier)).toEqual([1, 2, 3]);
    expect(turns.map((t) => t.difficulty)).toEqual([2, 3, 4]);

    // Every turn's target concepts came from the real blueprint, and differ
    // tier to tier (never repeating the same concept set).
    expect(turns[0]!.targetConceptIds.length).toBeGreaterThan(0);
    const tier1Ids = new Set(turns[0]!.targetConceptIds);
    const overlap = turns[1]!.targetConceptIds.filter((id) => tier1Ids.has(id));
    expect(overlap).toEqual([]);

    // Every turn scored well (a strong, structured answer) and got a real,
    // computed directive back — never a placeholder, never absent.
    for (const t of turns) {
      expect(t.score).toBeGreaterThan(0);
      expect(["escalate", "pivot", "drill_down"]).toContain(t.nextAction.system_directive);
    }
  });
});

describe("gate test 8 — the real POST /answers response carries one coherent liveSessionState snapshot", () => {
  it("populates every field of the composed snapshot with real, live-computed values", async () => {
    await h.api.post(`/sessions/${sessionId}/begin`).set(...bearer(token)).expect(200);

    const next = await h.api
      .get(`/sessions/${sessionId}/questions/next`)
      .set(...bearer(token))
      .expect(200);
    expect(next.body.done).toBe(false);
    const question = next.body.question as { id: string; topic: string };

    const answered = await h.api
      .post(`/sessions/${sessionId}/answers`)
      .set(...bearer(token))
      .send({ question_id: question.id, transcript: STRONG_ANSWER })
      .expect(201);

    const live = answered.body.live_session_state;

    // Printed so the full composed object is visible in test output, not just
    // asserted on blind — this is the `liveSessionState` snapshot
    // INSTRUCTIONS.md §12.6 documents, populated with real values.
    // eslint-disable-next-line no-console
    console.log("live_session_state, one real POST /answers turn:\n" + JSON.stringify(live, null, 2));

    expect(live).toBeDefined();
    expect(live.session_id).toBe(sessionId);
    expect(live.candidate_id).toBeTruthy();
    expect(live.active_topic_id).toBe(question.topic);

    expect(live.session_metrics.elapsed_time_seconds).toBeGreaterThanOrEqual(0);
    expect(live.session_metrics.topic_competency_score).toBeGreaterThan(0);
    expect(live.session_metrics.topic_competency_score).toBeLessThanOrEqual(1);
    expect(live.session_metrics.current_demonstrated_tier).toBeGreaterThanOrEqual(1);
    expect(live.session_metrics.current_demonstrated_tier).toBeLessThanOrEqual(3);

    // Real resume text, not an invented anchor — either a genuine evidence
    // line from the uploaded resume, or the honest "no evidence" fallback
    // (soul.md §"No fabrication"), never blank.
    expect(live.context_engine.active_resume_anchor).toBeTruthy();
    expect(live.context_engine.last_delivered_prompt.length).toBeGreaterThan(0);

    // `transcribed_input_chunk` is this response's own field — it is never a
    // second persisted copy of `answer.transcript` (§12.7); this response IS
    // where it's allowed to appear.
    expect(live.extraction_processor.transcribed_input_chunk).toBe(STRONG_ANSWER);
    expect(Array.isArray(live.extraction_processor.verified_concept_ids)).toBe(true);
    expect(Array.isArray(live.extraction_processor.unverified_concept_ids)).toBe(true);
    expect(Array.isArray(live.extraction_processor.anti_patterns_detected)).toBe(true);

    expect(["escalate", "pivot", "drill_down"]).toContain(live.next_action_generator.system_directive);
    expect(typeof live.next_action_generator.synthesized_framing_strategy).toBe("string");
    expect(live.next_action_generator.synthesized_framing_strategy.length).toBeGreaterThan(0);
  });
});

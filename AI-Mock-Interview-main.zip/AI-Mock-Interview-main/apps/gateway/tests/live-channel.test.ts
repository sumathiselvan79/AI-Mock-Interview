/**
 * The live WebSocket channel, driven the way the room page drives it.
 *
 * `apps/gateway/src/http/live-channel.ts` had no integration coverage at all —
 * every other Stage 2/3/6 gate test drives the QUESTION_LOOP through its REST
 * equivalents (`GET /questions/next`, `POST /answers`), never the
 * `/sessions/:id/live` socket the browser actually uses. Three separate bugs
 * lived in that blind spot, and all three are pinned below.
 *
 * 1. The loop stalled after every answer. The gateway pushes questions but
 *    never volunteers the NEXT one, and the page only ever asked once, on
 *    connect. Every REST-level test asked for each question explicitly, so
 *    none of them could see it. Covered by "runs a whole interview without
 *    operator intervention", which also pins the exact turn-ending frame
 *    (`{ type: "question", answered: true }`) that `apps/web/lib/live-protocol.ts`
 *    keys on — the two halves of that handshake have to stay in step.
 *
 * 2. A race in `openSession`: the message listener was attached only after an
 *    `await storage.sessions.get(sessionId)`. The room page sends its first
 *    `next_question` the instant its own socket reports open, with no wait for
 *    a `connected` reply — a message that won that race landed on a socket
 *    with no listener yet and was silently dropped, hanging the page forever.
 *
 * 3. `next_question` was not idempotent: every call — including one fired by a
 *    reconnect (dropped wifi, a refreshed tab, a restarted gateway), not only a
 *    deliberate "give me the next one" — generated and persisted a brand-new
 *    question, discarding whatever was pending and burning a question-budget
 *    and topic-quota slot the candidate never got to answer.
 */

import { createServer, type Server } from "node:http";
import type { AddressInfo } from "node:net";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import WebSocket from "ws";
import { BACKEND_JOB_DESCRIPTION } from "./fixtures/resumes.js";
import { STUDENT, bearer, buildHarness, loginToken, seedUsers, type TestHarness } from "./helpers.js";

const STRONG_ANSWER = `We had a settlement service timing out under load. I profiled the hot path and
found a synchronous Postgres write inside the request. I moved it onto a queue and added an idempotency
key derived from the payment intent id, so a retry could not double-charge. We picked the queue over a
larger instance because the write was not read back immediately; the tradeoff was that reconciliation
became eventually consistent, which finance signed off on. p99 went from 900ms to 210ms.`;

interface Frame {
  type: string;
  [key: string]: unknown;
}

let h: TestHarness;
let server: Server;
let port: number;
let token: string;
let sessionId: string;

/**
 * A socket with a frame queue. `timer_tick` is dropped on arrival — it fires
 * every second and would otherwise swamp every wait.
 */
function connect(session = sessionId, authToken = token) {
  const ws = new WebSocket(
    `ws://127.0.0.1:${port}/sessions/${session}/live?token=${encodeURIComponent(authToken)}`,
  );
  const queue: Frame[] = [];
  let notify: (() => void) | null = null;

  // A refused upgrade surfaces as an `error` event, not a frame. Without a
  // listener `ws` re-throws it as an unhandled exception and fails the run.
  ws.on("error", (err) => {
    queue.push({ type: "socket_error", message: err.message });
    notify?.();
  });

  ws.on("message", (raw) => {
    const frame = JSON.parse(raw.toString()) as Frame;
    if (frame.type === "timer_tick") return;
    queue.push(frame);
    notify?.();
  });

  return {
    ws,
    send: (message: Record<string, unknown>) => ws.send(JSON.stringify(message)),
    /** Sends the moment the socket opens, without waiting for `connected`. */
    sendOnOpen(message: Record<string, unknown>) {
      ws.on("open", () => ws.send(JSON.stringify(message)));
    },
    /** Next queued frame, waiting for one if the queue is empty. */
    async next(timeoutMs = 15_000): Promise<Frame> {
      if (queue.length > 0) return queue.shift()!;
      return new Promise<Frame>((resolve, reject) => {
        const timer = setTimeout(() => {
          notify = null;
          reject(new Error("timed out waiting for a frame — the loop is stalled"));
        }, timeoutMs);
        notify = () => {
          clearTimeout(timer);
          notify = null;
          resolve(queue.shift()!);
        };
      });
    },
    /** Skips past frames like `connected` to the first one of `type`. */
    async nextOfType(type: string, timeoutMs = 15_000): Promise<Frame> {
      const deadline = Date.now() + timeoutMs;
      for (;;) {
        const frame = await this.next(Math.max(1, deadline - Date.now()));
        if (frame.type === type) return frame;
        if (frame.type === "error" || frame.type === "socket_error") {
          throw new Error(`unexpected ${frame.type} awaiting "${type}": ${JSON.stringify(frame)}`);
        }
      }
    },
    close: () =>
      new Promise<void>((resolve) => {
        ws.once("close", () => resolve());
        ws.close();
      }),
  };
}

beforeEach(async () => {
  h = await buildHarness();
  await seedUsers(h);
  token = await loginToken(h, STUDENT);

  const created = await h.api
    .post("/sessions")
    .set(...bearer(token))
    .send({ role: "Senior Backend Engineer", job_description: BACKEND_JOB_DESCRIPTION })
    .expect(201);
  sessionId = created.body.session_id;

  for (const to of ["CONFIG", "TELEMETRY_CHECK"]) {
    await h.api.post(`/sessions/${sessionId}/advance`).set(...bearer(token)).send({ to }).expect(200);
  }
  await h.api
    .post(`/sessions/${sessionId}/telemetry-check`)
    .set(...bearer(token))
    .send({ mic_ok: true, speaker_ok: true, consent: { telemetry: true } })
    .expect(200);
  await h.api.post(`/sessions/${sessionId}/begin`).set(...bearer(token)).expect(200);

  server = createServer(h.app);
  h.attachLiveChannel(server);
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  port = (server.address() as AddressInfo).port;
});

afterEach(async () => {
  await new Promise<void>((resolve) => server.close(() => resolve()));
  await h.close();
});

describe("the live channel runs a whole interview without operator intervention", () => {
  it("advances from question to question once each answer is accepted", async () => {
    const client = connect();

    const connected = await client.next();
    expect(connected.type).toBe("connected");

    client.send({ type: "next_question" });

    const questionsAsked: string[] = [];
    let acceptedFrames = 0;
    let completed = false;

    // The room page's loop, exactly: react to each frame, and never ask for
    // anything the page would not have asked for.
    for (let step = 0; step < 60 && !completed; step += 1) {
      const frame = await client.next();

      if (frame.type === "session_complete") {
        completed = true;
      } else if (frame.type === "question" && frame.answered === true) {
        // The turn ended and there is no probe. THIS is the step that was
        // missing in the browser — without it the loop stops here forever.
        acceptedFrames += 1;
        client.send({ type: "next_question" });
      } else if (frame.type === "question") {
        questionsAsked.push(String(frame.id));
        client.send({ type: "submit_answer_text", question_id: frame.id, transcript: STRONG_ANSWER });
      } else if (frame.type === "follow_up") {
        client.send({
          type: "submit_follow_up_text",
          answer_id: frame.answer_id,
          follow_up_text: frame.text,
          transcript: "The idempotency key was the upstream payment intent id, so retries collapsed onto one row.",
        });
      } else if (frame.type === "error") {
        throw new Error(`server error frame: ${JSON.stringify(frame)}`);
      }
    }

    expect(completed, "the session never reached session_complete").toBe(true);

    // The point of the test: more than the one question the socket asks for on
    // connect. A stalled loop scores exactly one and then sits there.
    const session = await h.storage.sessions.get(sessionId);
    expect(questionsAsked.length).toBeGreaterThan(1);
    expect(questionsAsked.length).toBe(session!.questionBudget);
    expect(new Set(questionsAsked).size).toBe(questionsAsked.length);
    expect(acceptedFrames).toBeGreaterThan(0);

    await client.close();
  }, 120_000);

  it("signals an accepted answer with exactly the frame the client keys on", async () => {
    // `apps/web/lib/live-protocol.ts` treats `answered === true` — a literal
    // boolean, on a frame typed "question" — as "ask for the next one". If this
    // shape ever drifts, the browser silently stalls again, so it is pinned.
    const client = connect();

    expect((await client.next()).type).toBe("connected");
    client.send({ type: "next_question" });

    const question = await client.next();
    expect(question.type).toBe("question");
    expect(question.answered).toBeUndefined();

    client.send({ type: "submit_answer_text", question_id: question.id, transcript: STRONG_ANSWER });

    const result = await client.next();
    // A strong answer may still draw a probe; either way the turn-ending frame
    // is one of these two, and only one of them means "ask for another".
    if (result.type === "follow_up") {
      client.send({
        type: "submit_follow_up_text",
        answer_id: result.answer_id,
        follow_up_text: result.text,
        transcript: "The payment intent id.",
      });
      const afterFollowUp = await client.next();
      expect(afterFollowUp.type).toBe("question");
      expect(afterFollowUp.answered).toBe(true);
    } else {
      expect(result.type).toBe("question");
      expect(result.answered).toBe(true);
    }

    await client.close();
  }, 60_000);

  it("refuses a socket for someone else's session", async () => {
    const other = await h.auth.createUser({
      email: "intruder@example.com",
      passcode: "practice-run-3",
      role: "student",
    });
    expect(other.id).toBeTruthy();
    const intruderToken = await loginToken(h, { email: "intruder@example.com", passcode: "practice-run-3" });

    const client = connect(sessionId, intruderToken);

    const frame = await client.next();
    expect(frame.type).toBe("error");
    expect(frame.code).toBe("forbidden");

    await client.close();
  }, 30_000);
});

describe("regression: the open-then-await race in openSession", () => {
  it("still answers a next_question sent the instant the socket reports open, with no wait for connected", async () => {
    const client = connect();
    // Sent from the "open" handler itself — no delay, no wait for a
    // "connected" reply first. This is exactly what the room page does, and
    // exactly the ordering that lost the race before the fix.
    client.sendOnOpen({ type: "next_question" });

    const question = await client.nextOfType("question");
    expect(typeof question.id).toBe("string");

    await client.close();
  }, 30_000);
});

describe("regression: next_question is resume-safe by default", () => {
  it("re-serves the same pending question across repeated connects instead of generating a new one each time", async () => {
    const first = connect();
    first.sendOnOpen({ type: "next_question" });
    const firstQuestion = await first.nextOfType("question");
    await first.close();

    // Three more "reconnects" — none of them answer the pending question.
    for (let i = 0; i < 3; i += 1) {
      const again = connect();
      again.sendOnOpen({ type: "next_question" });
      const repeated = await again.nextOfType("question");
      expect(repeated.id).toBe(firstQuestion.id);
      await again.close();
    }

    const persisted = await h.storage.questions.listBySession(sessionId);
    expect(persisted).toHaveLength(1);
  }, 60_000);

  it("advance: true (the Skip control) abandons the pending question and generates a new one", async () => {
    const first = connect();
    first.sendOnOpen({ type: "next_question" });
    const firstQuestion = await first.nextOfType("question");
    await first.close();

    const skipping = connect();
    skipping.sendOnOpen({ type: "next_question", advance: true });
    const second = await skipping.nextOfType("question");
    expect(second.id).not.toBe(firstQuestion.id);
    await skipping.close();

    const persisted = await h.storage.questions.listBySession(sessionId);
    expect(persisted).toHaveLength(2);
  }, 60_000);
});

/**
 * TRACKING.md Stage 5, gate tests 1, 2, 3 and 8 — `packages/llm-client` on its
 * own, before any agent is wired to it (per the stage's implementation note:
 * "build packages/llm-client and the LLM Provider Tool first, in isolation").
 *
 * 1. A malformed provider response is rejected by the schema before it can
 *    reach an agent's return value, and a second malformed response after one
 *    retry raises `StructuredCallError` rather than coercing.
 * 2. An ungrounded claim fails `groundingCheck`, is reported as insufficient
 *    signal, and the rest of the response still comes back.
 * 3. Editing a prompt template without bumping its version string fails CI.
 * 8. LangSmith tracing is off by default outside development, and stays off
 *    even when the ambient environment says otherwise.
 */

import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";
import {
  FOLLOW_UP_TOOL,
  JD_FIT_TOOL,
  JD_REQUIREMENTS_TOOL,
  PROMPT_FINGERPRINTS,
  PromptRegistry,
  QUESTION_TOOL,
  RESUME_PARSE_TOOL,
  StructuredCallError,
  applyTracingGate,
  extractGroundableFields,
  groundingCheck,
  isTransportFailure,
  resolveProvider,
  resolveTracing,
  structuredCall,
  type StructuredCallRequest,
  type StructuredChatModel,
} from "@mia/llm-client";
import { getLlmSchema, validateResponse } from "@mia/mcp-schemas";

const RESUME = [
  "Priya Raman — Senior Backend Engineer",
  "Led the sharded event bus migration at Northwind, cutting p99 publish latency from 900ms to 120ms.",
  "Mentored three junior engineers through their first on-call rotations.",
].join("\n");

const JD = [
  "Senior Backend Engineer — you will own service reliability for our payments platform.",
  "Deep experience with distributed systems and API design is essential.",
  "You will mentor junior engineers and run incident reviews.",
  "Kubernetes operations experience is required.",
].join("\n");

/** A model that returns whatever it is handed, however wrong. */
function stubModel(responses: unknown[]): StructuredChatModel & { calls: StructuredCallRequest[] } {
  const calls: StructuredCallRequest[] = [];
  return {
    provider: "fixture",
    calls,
    async invoke(request) {
      calls.push(request);
      return responses[Math.min(calls.length - 1, responses.length - 1)];
    },
  };
}

const JD_FIT_INPUT = {
  role: "Senior Backend Engineer",
  job_description: JD,
  resume_lines: RESUME.split("\n"),
  matched_requirements: ["distributed systems", "mentor junior engineers"],
  gaps: ["Kubernetes operations"],
  candidate_topics: ["distributed systems", "api design", "kubernetes"],
};

describe("gate test 1 — a malformed provider response never reaches an agent", () => {
  it("rejects a response that violates the schema, then retries once", async () => {
    // First response is malformed (relevance_score out of range, evidence
    // missing); second is well-formed.
    const model = stubModel([
      { rationale: { value: "looks fine" }, topic_relevance: [{ topic: "x", relevance_score: 4 }] },
      {
        rationale: {
          value: "Strong overlap on distributed systems; no evidence of Kubernetes.",
          evidence: "Deep experience with distributed systems and API design is essential.",
        },
        topic_relevance: [],
      },
    ]);

    const result = await structuredCall(JD_FIT_TOOL, JD_FIT_INPUT, { model, sourceDocuments: [JD, RESUME] });

    expect(model.calls).toHaveLength(2);
    expect(result.output?.rationale.value).toContain("distributed systems");
    // The retry carries what was wrong, per §11.5.
    expect(model.calls[1]?.correction).toBeTruthy();
  });

  it("raises StructuredCallError rather than coercing, when the retry is also malformed", async () => {
    const model = stubModel([{ rationale: "not an object" }]);

    await expect(structuredCall(JD_FIT_TOOL, JD_FIT_INPUT, { model, sourceDocuments: [JD] })).rejects.toBeInstanceOf(
      StructuredCallError,
    );
    expect(model.calls).toHaveLength(2);
  });

  it("validates against the same schema the MCP gateway registry compiled", () => {
    // The Zod schema and the registry's JSON Schema are one definition, derived
    // — not two hand-synced copies (§11.5).
    const malformed = { rationale: { value: "x" }, topic_relevance: [] };
    expect(JD_FIT_TOOL.schema.safeParse(malformed).success).toBe(false);
    expect(validateResponse("llm", JD_FIT_TOOL.schemaRef, malformed).valid).toBe(false);

    const wellFormed = {
      rationale: { value: "x", evidence: "Kubernetes operations experience is required." },
      topic_relevance: [],
    };
    expect(JD_FIT_TOOL.schema.safeParse(wellFormed).success).toBe(true);
    expect(validateResponse("llm", JD_FIT_TOOL.schemaRef, wellFormed).valid).toBe(true);
  });
});

describe("an unreachable provider is not mistaken for a malformed response", () => {
  // Found against the live OpenRouter key, which answers 402 (no credits). The
  // SDK error was landing in `structuredCall`'s retry path: the call was made
  // twice to earn the same 402, and the agent was told `schema_validation_failed`
  // — hiding the one failure class that means the DEPLOYMENT is broken, which
  // §5.7 keeps deliberately separate from a bad response.
  const withStatus = (status: number, message: string) => Object.assign(new Error(message), { status });

  it("treats an HTTP error from the provider as transport, not schema", () => {
    expect(isTransportFailure(withStatus(402, "Insufficient credits"))).toBe(true);
    expect(isTransportFailure(withStatus(401, "Invalid API Key"))).toBe(true);
    expect(isTransportFailure(withStatus(429, "Rate limit reached"))).toBe(true);
    expect(isTransportFailure(withStatus(503, "Service Unavailable"))).toBe(true);
  });

  it("treats a socket-level failure as transport", () => {
    expect(isTransportFailure(Object.assign(new Error("connect ECONNREFUSED"), { code: "ECONNREFUSED" }))).toBe(true);
    expect(isTransportFailure(Object.assign(new Error("getaddrinfo ENOTFOUND"), { code: "ENOTFOUND" }))).toBe(true);
    expect(isTransportFailure(new Error("fetch failed"))).toBe(true);
  });

  it("leaves a response-shaped failure on the retryable path", () => {
    // The conservative half of the rule: anything unrecognised keeps its retry,
    // so a future SDK's parse error is never silently reported as a dead key.
    expect(isTransportFailure(new Error("Failed to parse structured output"))).toBe(false);
    expect(isTransportFailure(withStatus(200, "malformed tool call arguments"))).toBe(false);
    expect(isTransportFailure("not an error at all")).toBe(false);
  });
});

describe("gate test 2 — grounding", () => {
  it("fails a claim whose cited evidence is nowhere in the source documents", async () => {
    const grounded = await groundingCheck(
      {
        real: { value: "mentoring", evidence: "You will mentor junior engineers and run incident reviews." },
        invented: { value: "ten years of Kubernetes", evidence: "Ran Kubernetes clusters at scale for a decade." },
      },
      [JD, RESUME],
    );

    expect(grounded).toEqual({ real: true, invented: false });
  });

  it("tolerates a requoted line whose whitespace was reflowed, but not one whose words changed", async () => {
    const grounded = await groundingCheck(
      {
        reflowed: { value: "reliability", evidence: "you will own service\n   reliability for our payments platform." },
        reworded: { value: "reliability", evidence: "you will own service reliability for our payment platform." },
      },
      [JD],
    );

    expect(grounded.reflowed).toBe(true);
    expect(grounded.reworded).toBe(false);
  });

  it("drops the ungrounded field, flags insufficient signal, and returns the rest of the response", async () => {
    const model = stubModel([
      {
        // The rationale is invented — the JD says nothing of the sort.
        rationale: {
          value: "The candidate has led a Kubernetes platform team for six years.",
          evidence: "Led the Kubernetes platform team from 2018.",
        },
        topic_relevance: [
          {
            topic: "distributed systems",
            relevance_score: 0.9,
            evidence: "Deep experience with distributed systems and API design is essential.",
          },
        ],
      },
    ]);

    const result = await structuredCall(JD_FIT_TOOL, JD_FIT_INPUT, { model, sourceDocuments: [JD, RESUME] });

    expect(result.grounded).toBe(false);
    expect(result.insufficientSignal).toEqual(["rationale"]);
    // Flagged, not silently omitted — the caller can tell "no signal" apart
    // from "signal that happened to be empty" (§11.3).
    expect(result.output?.rationale).toEqual({ insufficient_signal: true });
    // ...and the rest of jd_fit survives.
    expect(result.output?.topic_relevance).toHaveLength(1);
    expect(result.output?.topic_relevance[0]?.topic).toBe("distributed systems");
  });

  it("rejects the whole response when a REQUIRED claim is ungrounded", async () => {
    const model = stubModel([
      {
        should_follow_up: true,
        follow_up_text: "What did you do about the retries?",
        reason: "no outcome given",
        targeted_gap: { value: "retries", evidence: "we added exponential backoff to every call" },
      },
    ]);

    const transcript = "I rewrote the ingestion pipeline and added a retry queue in front of it.";
    const result = await structuredCall(
      FOLLOW_UP_TOOL,
      {
        question: "Tell me about a time you improved a system's reliability.",
        answer_transcript: transcript,
        baseline: { should_follow_up: true, reason: "no outcome given" },
      },
      { model, sourceDocuments: [transcript] },
    );

    // §11.3: a required field failing rejects the response, so the agent falls
    // back rather than asking a probe it cannot tie to what was said.
    expect(result.output).toBeNull();
    expect(result.insufficientSignal).toEqual(["targeted_gap"]);
  });

  it("finds groundable claims structurally, wherever they sit in the response", () => {
    const fields = extractGroundableFields({
      rationale: { value: "a", evidence: "b" },
      topic_relevance: [{ topic: "t", relevance_score: 1, evidence: "e" }],
      nested: { deeper: { value: "v", evidence: "x" } },
      ignored: { no_evidence_here: true },
    });

    expect(Object.keys(fields).sort()).toEqual(["nested.deeper", "rationale", "topic_relevance[0]"]);
    // An array entry uses its `topic` as the claim when it has no `value`.
    expect(fields["topic_relevance[0]"]).toEqual({ value: "t", evidence: "e" });
  });
});

describe("gate test 3 — prompt-version regression", () => {
  it("has a pinned fingerprint for every registered prompt version", () => {
    expect(Object.keys(PROMPT_FINGERPRINTS).sort()).toEqual(PromptRegistry.versions());
  });

  it("fails when a prompt's content changed without its version string being bumped", () => {
    // This is the regression guard itself: edit any prompt's system text and
    // this assertion fails until PROMPT_FINGERPRINTS is updated alongside a new
    // version string (§11.5).
    expect(PromptRegistry.fingerprints()).toEqual(PROMPT_FINGERPRINTS);
  });

  it("pins one active version per LLM-backed agent, and stamps it on every result", async () => {
    expect(JD_FIT_TOOL.promptVersion).toBe("resume-service-agent/v1");
    expect(QUESTION_TOOL.promptVersion).toBe("question-agent/v3");
    expect(FOLLOW_UP_TOOL.promptVersion).toBe("followup-agent/v1");

    const result = await structuredCall(JD_FIT_TOOL, JD_FIT_INPUT, { provider: "fixture", sourceDocuments: [JD, RESUME] });
    expect(result.promptVersion).toBe("resume-service-agent/v1");
    expect(result.provider).toBe("fixture");
  });
});

describe("gate test 8 — third-party data flow", () => {
  it("keeps LangSmith tracing off outside development", () => {
    expect(resolveTracing({ NODE_ENV: "production", LANGSMITH_OPT_IN: "true", LANGSMITH_API_KEY: "k" }).enabled).toBe(
      false,
    );
    expect(resolveTracing({ NODE_ENV: "test", LANGSMITH_OPT_IN: "true", LANGSMITH_API_KEY: "k" }).enabled).toBe(false);
  });

  it("keeps it off in development without an explicit opt-in", () => {
    expect(resolveTracing({ NODE_ENV: "development" }).enabled).toBe(false);
    expect(resolveTracing({ NODE_ENV: "development", LANGSMITH_OPT_IN: "true" }).enabled).toBe(false);
    expect(
      resolveTracing({ NODE_ENV: "development", LANGSMITH_OPT_IN: "true", LANGSMITH_API_KEY: "k" }).enabled,
    ).toBe(true);
  });

  it("clears an inherited LANGCHAIN_TRACING_V2 rather than merely not setting its own", () => {
    // A value inherited from a shell profile or a base image would otherwise
    // start shipping resume and transcript text to LangSmith with nothing in
    // this repo saying so (soul.md §"Privacy by default", Stage 5 addition).
    const env: NodeJS.ProcessEnv = { NODE_ENV: "production", LANGCHAIN_TRACING_V2: "true", LANGSMITH_TRACING: "true" };
    const decision = applyTracingGate(env);

    expect(decision.enabled).toBe(false);
    expect(env.LANGCHAIN_TRACING_V2).toBeUndefined();
    expect(env.LANGSMITH_TRACING).toBeUndefined();
  });

  it("documents data-use and retention terms in .env.example for every provider in use", () => {
    // §8: "must have its data-use/retention terms documented in .env.example;
    // this is a requirement, not a suggestion, and applies independently of
    // which provider is the active default."
    const envExample = readFileSync(
      join(dirname(fileURLToPath(import.meta.url)), "..", "..", "..", ".env.example"),
      "utf8",
    );

    for (const key of ["GROQ_API_KEY", "OPENROUTER_API_KEY", "BEDROCK_MODEL_ID", "LANGSMITH_API_KEY"]) {
      expect(envExample, `${key} is not present in .env.example`).toContain(key);
    }

    // The documentation is prose in comments, so it is normalised before
    // matching — a note that happens to wrap across two lines is still the
    // note. This checks for the content §8 requires, not its line breaks.
    const prose = envExample
      .split("\n")
      .map((line) => line.replace(/^\s*#\s?/, ""))
      .join(" ")
      .replace(/\s+/g, " ")
      .toLowerCase();

    // Each provider needs an actual statement about what happens to the text,
    // not just a blank key to fill in.
    for (const [provider, phrase] of [
      ["groq", "not used to train models"],
      ["bedrock", "not used to train the underlying models"],
      ["openrouter", "vary by which backing host"],
      ["langsmith", "retains trace data"],
    ] as const) {
      expect(prose, `${provider}'s data-use terms are not documented`).toContain(phrase);
    }

    // And the LangSmith callout has to name it as a SEPARATE recipient, not
    // fold it into the provider note (§11.7).
    expect(prose).toContain("second, independent third-party recipient");
  });

  it("falls back to the deterministic fixture when the configured provider has no credentials", () => {
    const choice = resolveProvider({ NODE_ENV: "test", LLM_PROVIDER: "groq" });
    expect(choice.provider).toBe("fixture");
    expect(choice.reason).toContain("GROQ_API_KEY");

    expect(resolveProvider({ NODE_ENV: "test", LLM_PROVIDER: "groq", GROQ_API_KEY: "k" }).provider).toBe("groq");
  });

  it("lets question generation and resume/JD parsing run on different providers", () => {
    const env = {
      NODE_ENV: "test",
      LLM_PROVIDER: "ollama",
      OLLAMA_API_KEY: "ok",
      QUESTION_AGENT_LLM_PROVIDER: "groq",
      GROQ_API_KEY: "gk",
    };

    // Question generation: overridden to groq.
    const question = resolveProvider(env, QUESTION_TOOL.name);
    expect(question.provider).toBe("groq");
    expect(question.reason).toContain("QUESTION_AGENT_LLM_PROVIDER=groq");

    // Resume/JD parsing: no override set, follows the global default.
    const resume = resolveProvider(env, JD_FIT_TOOL.name);
    expect(resume.provider).toBe("ollama");
    expect(resume.reason).toContain("LLM_PROVIDER=ollama");

    // Same tool_name prefix ("resume-service-agent"), same role.
    const jdRequirements = resolveProvider(env, "resume-service-agent.parse_jd_requirements");
    expect(jdRequirements.provider).toBe("ollama");

    // A different MCP server implementing the same resume-parsing capability
    // shares the resume-service-agent role.
    const resumeParse = resolveProvider(env, "tool-resume-parser.parse_resume_llm");
    expect(resumeParse.provider).toBe("ollama");

    // No role-specific override exists for follow-up — always the global default.
    const followUp = resolveProvider(env, FOLLOW_UP_TOOL.name);
    expect(followUp.provider).toBe("ollama");

    // Omitting tool_name entirely is unchanged, existing behavior.
    expect(resolveProvider(env).provider).toBe("ollama");
  });
});

describe("the LLM-powered resume/JD parsers (resume-parser/v1, jd-parser/v1)", () => {
  it("resolves resume-parser/v1 through the same schema/prompt-version wiring as every other LLM tool", () => {
    expect(RESUME_PARSE_TOOL.promptVersion).toBe("resume-parser/v1");
    expect(getLlmSchema(RESUME_PARSE_TOOL.schemaRef)?.schema).toBe(RESUME_PARSE_TOOL.schema);
    // Structural extraction, not a claim about the candidate — nothing here is
    // grounding-checked (§11.3 only applies to evidence-bearing claims).
    expect(RESUME_PARSE_TOOL.requiredGroundedPaths).toEqual([]);
  });

  it("accepts a schema-valid resume parse and rejects a malformed one, same as any other tool", async () => {
    const wellFormed = {
      skills: ["Go", "Kafka"],
      experience: [
        { title: "Senior Backend Engineer", company: "Northwind", start_year: 2019, end_year: null, years: 6, highlights: ["Led the sharded event bus migration"] },
      ],
      education: [{ degree: "B.Tech Computer Science", institution: "IIT Delhi", year: 2015 }],
      keywords: ["backend", "kafka"],
      summary: "Senior Backend Engineer with distributed systems experience.",
    };
    expect(RESUME_PARSE_TOOL.schema.safeParse(wellFormed).success).toBe(true);
    expect(validateResponse("llm", RESUME_PARSE_TOOL.schemaRef, wellFormed).valid).toBe(true);

    const model = stubModel([wellFormed]);
    const result = await structuredCall(RESUME_PARSE_TOOL, { resume_lines: RESUME.split("\n") }, { model });
    expect(result.output?.skills).toEqual(["Go", "Kafka"]);

    expect(RESUME_PARSE_TOOL.schema.safeParse({ skills: "not an array" }).success).toBe(false);
  });

  it("resolves jd-parser/v1 through the same wiring, and accepts/rejects role_level accordingly", async () => {
    expect(JD_REQUIREMENTS_TOOL.promptVersion).toBe("jd-parser/v1");
    expect(JD_REQUIREMENTS_TOOL.requiredGroundedPaths).toEqual([]);

    const wellFormed = {
      requirements: [{ text: "5+ years of distributed systems experience", category: "experience", is_mandatory: true }],
      role_level: "senior",
      key_technologies: ["Kubernetes", "Go"],
    };
    expect(JD_REQUIREMENTS_TOOL.schema.safeParse(wellFormed).success).toBe(true);
    expect(validateResponse("llm", JD_REQUIREMENTS_TOOL.schemaRef, wellFormed).valid).toBe(true);
    expect(JD_REQUIREMENTS_TOOL.schema.safeParse({ ...wellFormed, role_level: "not-a-level" }).success).toBe(false);

    const model = stubModel([wellFormed]);
    const result = await structuredCall(JD_REQUIREMENTS_TOOL, { role: "Senior Backend Engineer", job_description: JD }, { model });
    expect(result.output?.role_level).toBe("senior");
    expect(result.output?.key_technologies).toEqual(["Kubernetes", "Go"]);
  });
});

describe("the fixture provider grounds itself in real source text", () => {
  it("produces a schema-valid, genuinely grounded jd_fit response", async () => {
    const result = await structuredCall(JD_FIT_TOOL, JD_FIT_INPUT, {
      provider: "fixture",
      sourceDocuments: [JD, RESUME],
    });

    expect(result.grounded).toBe(true);
    expect(result.insufficientSignal).toEqual([]);

    const entry = getLlmSchema(JD_FIT_TOOL.schemaRef);
    expect(entry?.schema.safeParse(result.output).success).toBe(true);

    // Every evidence string it emitted is verbatim in a source document — the
    // fixture passes the same check a real provider has to pass.
    const normalized = [JD, RESUME].map((d) => d.replace(/\s+/g, " ").trim());
    for (const field of Object.values(extractGroundableFields(result.output))) {
      expect(normalized.some((doc) => doc.includes(field.evidence.replace(/\s+/g, " ").trim()))).toBe(true);
    }
  });
});

/**
 * Stage 7 gate tests — Admin user directory, profile drill-down, report
 * download, and interview scheduling (`ADMIN_FEATURE_PROMPT.md`, TRACKING.md
 * Stage 7).
 *
 * The three things these have to hold down, in order of how much damage
 * getting them wrong would do:
 *
 *  1. **The data boundary.** An Admin may see what a candidate's `Report`
 *     contains and nothing more (soul.md §"Admin role"). Every new route is
 *     asserted against the actual forbidden strings, not just against a
 *     field-name allowlist that a future field could sidestep.
 *  2. **Consent stays the candidate's.** An Admin scheduling an interview must
 *     not be able to pre-answer telemetry/clipboard/recording consent
 *     (soul.md §"Consent-first monitoring").
 *  3. **RBAC.** Every route added here is admin-only, and a student token gets
 *     403 on all of them.
 */

import { afterEach, beforeEach, describe, expect, it } from "vitest";
import {
  DEFAULT_CONSENT,
  effectiveStatus,
  isStartable,
  meanCompetencyScore,
  type Report,
} from "@mia/shared-types";
import { buildDirectoryPage } from "../src/admin/directory.js";
import { validateDraft, toStudentWire } from "../src/admin/scheduling.js";
import { ADMIN, STUDENT, bearer, buildHarness, loginToken, seedUsers, type TestHarness } from "./helpers.js";

let h: TestHarness;
let adminToken: string;
let studentToken: string;
let studentId: string;

/** A second and third student, so directory filtering has something to filter. */
const PEER = { email: "peer@example.com", passcode: "practice-run-2" };
const QUIET = { email: "quiet@example.com", passcode: "practice-run-3" };

const hourFromNow = (hours: number) => new Date(Date.now() + hours * 3_600_000).toISOString();

/**
 * Writes a report straight to the store.
 *
 * Running a full interview per report would make this suite minutes long, and
 * the thing under test is the aggregation over reports, not how they came to
 * exist — that is covered by `reporting.test.ts`.
 */
async function seedReport(
  candidateId: string,
  scores: number[],
  createdAt: string,
  sessionRole = "Senior Backend Engineer",
): Promise<Report> {
  const session = await h.storage.sessions.create({
    candidateId,
    role: sessionRole,
    jobDescription: "Backend work.",
  });
  return h.storage.reports.create({
    sessionId: session.id,
    candidateId,
    competencyScores: scores.map((score, i) => ({
      competency: `competency-${i}`,
      score,
      evidence: ["I moved the write onto a queue."],
    })),
    strengths: ["Concrete about tradeoffs"],
    focusAreas: ["Could quantify impact"],
    browserActivity: { exitCount: 0, events: [], concludedEarly: false },
    disclaimer: "Practice feedback, not a hiring decision.",
    createdAt,
  });
}

beforeEach(async () => {
  h = await buildHarness();
  const seeded = await seedUsers(h);
  studentId = seeded.studentId;
  adminToken = await loginToken(h, ADMIN);
  studentToken = await loginToken(h, STUDENT);
});

afterEach(async () => {
  await h.close();
});

// ---------------------------------------------------------------- gate 1

describe("gate test 1 — the directory aggregates without fanning out per user", () => {
  it("computes interviews, average score and last interview from one aggregate call", async () => {
    // Two reports: means are (4+2)/2 = 3 and (5+5+5)/3 = 5, so the candidate's
    // average is the mean of THOSE, 4 — not the mean of all five scores (4.2).
    await seedReport(studentId, [4, 2], "2026-01-10T10:00:00.000Z");
    await seedReport(studentId, [5, 5, 5], "2026-02-20T10:00:00.000Z");

    const res = await h.api.get("/admin/users").set(...bearer(adminToken)).expect(200);
    const row = res.body.rows.find((r: { user_id: string }) => r.user_id === studentId);

    expect(row.interviews_completed).toBe(2);
    expect(row.average_score).toBeCloseTo(4, 5);
    expect(row.last_interview_at).toBe("2026-02-20T10:00:00.000Z");
    expect(row.status).toBe("active");
  });

  it("agrees with the store's own aggregate — the two must not drift", async () => {
    await seedReport(studentId, [4, 2], "2026-01-10T10:00:00.000Z");
    await seedReport(studentId, [5, 5, 5], "2026-02-20T10:00:00.000Z");

    const aggregate = await h.storage.reports.aggregateByCandidate();
    const mine = aggregate.find((a) => a.candidateId === studentId);
    const reports = await h.storage.reports.listByCandidate(studentId);
    const byHand =
      reports
        .map((r) => meanCompetencyScore(r.competencyScores)!)
        .reduce((sum, m) => sum + m, 0) / reports.length;

    expect(mine!.averageScore).toBeCloseTo(byHand, 5);
    expect(mine!.interviewsCompleted).toBe(reports.length);
  });

  it("reports a candidate with no reports as null, never as zero", async () => {
    // A score of 0 is a judgement the system never made (soul.md §"No fabrication").
    const res = await h.api.get("/admin/users").set(...bearer(adminToken)).expect(200);
    const row = res.body.rows.find((r: { user_id: string }) => r.user_id === studentId);

    expect(row.average_score).toBeNull();
    expect(row.interviews_completed).toBe(0);
    expect(row.last_interview_at).toBeNull();
    expect(row.status).toBe("no_activity");
  });

  it("counts a started-but-unfinished session as activity, not as inactive", async () => {
    await h.storage.sessions.create({
      candidateId: studentId,
      role: "Senior Backend Engineer",
      jobDescription: "",
    });

    const res = await h.api.get("/admin/users").set(...bearer(adminToken)).expect(200);
    const row = res.body.rows.find((r: { user_id: string }) => r.user_id === studentId);
    expect(row.status).toBe("active");
  });

  it("lists students only — an admin is not a candidate", async () => {
    const res = await h.api.get("/admin/users").set(...bearer(adminToken)).expect(200);
    const emails = res.body.rows.map((r: { email: string }) => r.email);
    expect(emails).toContain(STUDENT.email);
    expect(emails).not.toContain(ADMIN.email);
  });
});

// ---------------------------------------------------------------- gate 2

describe("gate test 2 — search, filter, sort and paging", () => {
  beforeEach(async () => {
    await h.auth.createUser({ ...PEER, role: "student", profile: { fullName: "Ada Peer", department: "Data" } });
    await h.auth.createUser({ ...QUIET, role: "student", profile: { fullName: "Zed Quiet", department: "Design" } });
    await h.auth.updateProfile(studentId, { fullName: "Mia Student", department: "Engineering" });
  });

  it("searches on name and email", async () => {
    const byName = await h.api.get("/admin/users?search=Ada").set(...bearer(adminToken)).expect(200);
    expect(byName.body.rows).toHaveLength(1);
    expect(byName.body.rows[0].full_name).toBe("Ada Peer");

    const byEmail = await h.api.get("/admin/users?search=quiet@").set(...bearer(adminToken)).expect(200);
    expect(byEmail.body.rows).toHaveLength(1);
    expect(byEmail.body.rows[0].email).toBe(QUIET.email);
  });

  it("filters by department, and offers the departments actually in use", async () => {
    const res = await h.api.get("/admin/users?department=Data").set(...bearer(adminToken)).expect(200);
    expect(res.body.rows).toHaveLength(1);
    expect(res.body.rows[0].department).toBe("Data");
    expect(res.body.departments).toEqual(expect.arrayContaining(["Data", "Design", "Engineering"]));
  });

  it("excludes unscored candidates from a score filter rather than treating them as zero", async () => {
    const peer = await h.storage.users.findByEmail(PEER.email);
    await seedReport(peer!.id, [4, 4], "2026-03-01T10:00:00.000Z");

    const res = await h.api.get("/admin/users?min_score=3").set(...bearer(adminToken)).expect(200);
    const ids = res.body.rows.map((r: { user_id: string }) => r.user_id);

    expect(ids).toContain(peer!.id);
    // Never interviewed is not "scored below 3".
    expect(ids).not.toContain(studentId);
  });

  it("sorts null scores last in both directions", async () => {
    const peer = await h.storage.users.findByEmail(PEER.email);
    await seedReport(peer!.id, [4, 4], "2026-03-01T10:00:00.000Z");

    for (const direction of ["asc", "desc"]) {
      const res = await h.api
        .get(`/admin/users?sort=averageScore&direction=${direction}`)
        .set(...bearer(adminToken))
        .expect(200);
      const scores = res.body.rows.map((r: { average_score: number | null }) => r.average_score);
      // A candidate with no score is missing data, not the worst performer.
      expect(scores[0]).not.toBeNull();
      expect(scores[scores.length - 1]).toBeNull();
    }
  });

  it("pages server-side and reports the filtered total", async () => {
    const first = await h.api.get("/admin/users?page_size=2&page=1").set(...bearer(adminToken)).expect(200);
    expect(first.body.rows).toHaveLength(2);
    expect(first.body.total).toBe(3);

    const second = await h.api.get("/admin/users?page_size=2&page=2").set(...bearer(adminToken)).expect(200);
    expect(second.body.rows).toHaveLength(1);

    // No row appears on two pages — the tie-break on user id is what makes
    // paging stable when sort values are equal.
    const ids = [...first.body.rows, ...second.body.rows].map((r: { user_id: string }) => r.user_id);
    expect(new Set(ids).size).toBe(3);
  });

  it("pages a filtered set, not the whole set", async () => {
    const res = await h.api
      .get("/admin/users?department=Data&page_size=25")
      .set(...bearer(adminToken))
      .expect(200);
    expect(res.body.total).toBe(1);
  });
});

// ---------------------------------------------------------------- gate 3

describe("gate test 3 — the data boundary holds on every admin route", () => {
  it("never serves a resume, a transcript, or an audio ref", async () => {
    // A real session with real content, so the forbidden strings genuinely
    // exist somewhere in the system while these routes are called.
    const RESUME = "PRIVATE-RESUME-TEXT-should-never-reach-an-admin";
    const TRANSCRIPT = "PRIVATE-ANSWER-TRANSCRIPT-should-never-reach-an-admin";

    const session = await h.storage.sessions.create({
      candidateId: studentId,
      role: "Senior Backend Engineer",
      jobDescription: "Backend work.",
    });
    const stored = await h.storage.files.put({
      sessionId: session.id,
      filename: "resume.txt",
      contentType: "text/plain",
      bytes: Buffer.from(RESUME),
    });
    await h.storage.sessions.patch(session.id, { resumeRef: stored.ref });

    const question = await h.storage.questions.append({
      id: "q-boundary",
      bankId: "bank-1",
      sessionId: session.id,
      text: "Tell me about a system you scaled.",
      topic: "databases",
      type: "technical",
      difficulty: 3,
      quotaOverride: false,
      askedAt: new Date().toISOString(),
    });
    await h.storage.answers.append({
      id: "a-boundary",
      questionId: question.id,
      transcript: TRANSCRIPT,
      followUps: [],
      submittedAt: new Date().toISOString(),
    });
    await h.storage.reports.create({
      sessionId: session.id,
      candidateId: studentId,
      competencyScores: [{ competency: "databases", score: 4, evidence: ["I added a partial index."] }],
      strengths: [],
      focusAreas: [],
      browserActivity: { exitCount: 0, events: [], concludedEarly: false },
      disclaimer: "Practice feedback.",
      createdAt: new Date().toISOString(),
    });

    const routes = [
      "/admin/users",
      `/admin/users/${studentId}`,
      `/admin/reports/${session.id}`,
      `/admin/reports/${session.id}/download`,
      `/admin/users/${studentId}/reports/download`,
      "/admin/scheduled-interviews",
    ];

    for (const route of routes) {
      const res = await h.api.get(route).set(...bearer(adminToken));
      expect(res.status, `${route} should succeed`).toBeLessThan(400);
      const body = typeof res.text === "string" ? res.text : JSON.stringify(res.body);
      expect(body, `${route} leaked resume text`).not.toContain(RESUME);
      expect(body, `${route} leaked a transcript`).not.toContain(TRANSCRIPT);
      expect(body, `${route} leaked a resume ref`).not.toContain(stored.ref);
    }
  });

  it("has no admin route that serves a session transcript at all", async () => {
    const session = await h.storage.sessions.create({
      candidateId: studentId,
      role: "Senior Backend Engineer",
      jobDescription: "",
    });
    // The candidate's own transcript route exists; there is deliberately no
    // /admin/ equivalent, and the admin token is not a way into the student one.
    await h.api.get(`/sessions/${session.id}/transcript`).set(...bearer(studentToken)).expect(200);
    await h.api.get(`/admin/sessions/${session.id}/transcript`).set(...bearer(adminToken)).expect(404);
  });
});

// ---------------------------------------------------------------- gate 4

describe("gate test 4 — RBAC on every route this stage added", () => {
  const ADMIN_ROUTES: [string, string][] = [
    ["get", "/admin/users"],
    ["get", "/admin/users/some-id"],
    ["get", "/admin/users/some-id/reports/download"],
    ["get", "/admin/reports/some-session/download"],
    ["get", "/admin/scheduled-interviews"],
    ["post", "/admin/scheduled-interviews"],
    ["post", "/admin/scheduled-interviews/some-id/cancel"],
    ["post", "/admin/scheduled-interviews/some-id/reschedule"],
  ];

  it("gives a student token 403 on all of them", async () => {
    for (const [method, route] of ADMIN_ROUTES) {
      const res = await (method === "get"
        ? h.api.get(route).set(...bearer(studentToken))
        : h.api.post(route).set(...bearer(studentToken)).send({}));
      expect(res.status, `${method.toUpperCase()} ${route} should be 403 for a student`).toBe(403);
    }
  });

  it("rejects an unauthenticated caller on all of them", async () => {
    for (const [method, route] of ADMIN_ROUTES) {
      const res = await (method === "get" ? h.api.get(route) : h.api.post(route).send({}));
      expect(res.status, `${method.toUpperCase()} ${route} should be 401 unauthenticated`).toBe(401);
    }
  });

  it("gives an admin token 403 on the student-only scheduled-interviews read", async () => {
    // Symmetric, like every other role gate here: an Admin is not a candidate.
    await h.api.get("/me/scheduled-interviews").set(...bearer(adminToken)).expect(403);
  });
});

// ---------------------------------------------------------------- gate 5

describe("gate test 5 — scheduling lifecycle", () => {
  const draft = (overrides: Record<string, unknown> = {}) => ({
    candidate_ids: [studentId],
    role: "Senior Backend Engineer",
    job_description: "Payments platform, high throughput.",
    interview_type: "behavioral+technical",
    difficulty: "senior",
    duration_minutes: 45,
    scheduled_for: hourFromNow(-1),
    ...overrides,
  });

  it("assigns to a batch, one row per candidate, and reports it back", async () => {
    const peer = await h.auth.createUser({ ...PEER, role: "student" });

    const res = await h.api
      .post("/admin/scheduled-interviews")
      .set(...bearer(adminToken))
      .send(draft({ candidate_ids: [studentId, peer.id] }))
      .expect(201);

    expect(res.body.scheduled).toHaveLength(2);
    expect(new Set(res.body.scheduled.map((s: { candidate_id: string }) => s.candidate_id))).toEqual(
      new Set([studentId, peer.id]),
    );
    // Window already open, so the derived status is `sent`, not `pending`.
    expect(res.body.scheduled[0].status).toBe("sent");
  });

  it("de-duplicates a candidate selected twice", async () => {
    const res = await h.api
      .post("/admin/scheduled-interviews")
      .set(...bearer(adminToken))
      .send(draft({ candidate_ids: [studentId, studentId] }))
      .expect(201);
    expect(res.body.scheduled).toHaveLength(1);
  });

  it("runs the whole assignment through to a seeded session", async () => {
    const created = await h.api
      .post("/admin/scheduled-interviews")
      .set(...bearer(adminToken))
      .send(draft())
      .expect(201);
    const scheduleId = created.body.scheduled[0].id;

    // The candidate sees it.
    const mine = await h.api.get("/me/scheduled-interviews").set(...bearer(studentToken)).expect(200);
    expect(mine.body.scheduled).toHaveLength(1);
    expect(mine.body.scheduled[0].status).toBe("sent");

    // Starting it creates an ordinary session, seeded with the role and JD.
    const started = await h.api
      .post("/sessions")
      .set(...bearer(studentToken))
      .send({ scheduled_interview_id: scheduleId })
      .expect(201);

    const session = await h.storage.sessions.get(started.body.session_id);
    expect(session!.role).toBe("Senior Backend Engineer");
    expect(session!.jobDescription).toBe("Payments platform, high throughput.");
    // It lands in CREATED — Interview Config still has to run.
    expect(session!.state).toBe("CREATED");

    // And the assignment is now claimed.
    const after = await h.storage.scheduled.get(scheduleId);
    expect(after!.status).toBe("started");
    expect(after!.sessionId).toBe(started.body.session_id);

    // A second start is refused rather than creating a duplicate session.
    await h.api
      .post("/sessions")
      .set(...bearer(studentToken))
      .send({ scheduled_interview_id: scheduleId })
      .expect(409);
  });

  it("refuses an assignment that belongs to someone else, without confirming it exists", async () => {
    const peer = await h.auth.createUser({ ...PEER, role: "student" });
    const created = await h.api
      .post("/admin/scheduled-interviews")
      .set(...bearer(adminToken))
      .send(draft({ candidate_ids: [peer.id] }))
      .expect(201);

    const res = await h.api
      .post("/sessions")
      .set(...bearer(studentToken))
      .send({ scheduled_interview_id: created.body.scheduled[0].id });

    // 404, not 403 — otherwise this enumerates assignment ids.
    expect(res.status).toBe(404);
  });

  it("refuses one whose window has not opened, and one past its deadline", async () => {
    const future = await h.api
      .post("/admin/scheduled-interviews")
      .set(...bearer(adminToken))
      .send(draft({ scheduled_for: hourFromNow(48) }))
      .expect(201);
    await h.api
      .post("/sessions")
      .set(...bearer(studentToken))
      .send({ scheduled_interview_id: future.body.scheduled[0].id })
      .expect(409);

    const lapsed = await h.api
      .post("/admin/scheduled-interviews")
      .set(...bearer(adminToken))
      .send(draft({ scheduled_for: hourFromNow(-48), deadline: hourFromNow(-24) }))
      .expect(201);
    expect(lapsed.body.scheduled[0].status).toBe("missed");
    await h.api
      .post("/sessions")
      .set(...bearer(studentToken))
      .send({ scheduled_interview_id: lapsed.body.scheduled[0].id })
      .expect(409);
  });

  it("cancels an open assignment and hides it from the candidate", async () => {
    const created = await h.api
      .post("/admin/scheduled-interviews")
      .set(...bearer(adminToken))
      .send(draft())
      .expect(201);
    const id = created.body.scheduled[0].id;

    await h.api.post(`/admin/scheduled-interviews/${id}/cancel`).set(...bearer(adminToken)).expect(200);

    const mine = await h.api.get("/me/scheduled-interviews").set(...bearer(studentToken)).expect(200);
    expect(mine.body.scheduled).toHaveLength(0);

    await h.api
      .post("/sessions")
      .set(...bearer(studentToken))
      .send({ scheduled_interview_id: id })
      .expect(409);
  });

  it("will not cancel one the candidate already started", async () => {
    const created = await h.api
      .post("/admin/scheduled-interviews")
      .set(...bearer(adminToken))
      .send(draft())
      .expect(201);
    const id = created.body.scheduled[0].id;

    await h.api
      .post("/sessions")
      .set(...bearer(studentToken))
      .send({ scheduled_interview_id: id })
      .expect(201);

    const res = await h.api.post(`/admin/scheduled-interviews/${id}/cancel`).set(...bearer(adminToken));
    expect(res.status).toBe(400);
    expect(res.body.error.code).toBe("already_started");
  });

  it("moves the window on reschedule", async () => {
    const created = await h.api
      .post("/admin/scheduled-interviews")
      .set(...bearer(adminToken))
      .send(draft({ scheduled_for: hourFromNow(48) }))
      .expect(201);

    const moved = await h.api
      .post(`/admin/scheduled-interviews/${created.body.scheduled[0].id}/reschedule`)
      .set(...bearer(adminToken))
      .send({ scheduled_for: hourFromNow(72), deadline: hourFromNow(96) })
      .expect(200);

    expect(moved.body.scheduled.status).toBe("pending");
    expect(new Date(moved.body.scheduled.scheduled_for).getTime()).toBeGreaterThan(Date.now());
  });
});

// ---------------------------------------------------------------- gate 6

describe("gate test 6 — an admin cannot consent on a candidate's behalf", () => {
  const draft = (overrides: Record<string, unknown> = {}) => ({
    candidate_ids: [studentId],
    role: "Senior Backend Engineer",
    interview_type: "full",
    difficulty: "senior",
    duration_minutes: 45,
    scheduled_for: hourFromNow(-1),
    ...overrides,
  });

  it("rejects a schedule that tries to carry consent, rather than ignoring it", async () => {
    // Silently dropping it would leave the Admin believing they had answered it.
    for (const field of ["consent_defaults", "consent"]) {
      const res = await h.api
        .post("/admin/scheduled-interviews")
        .set(...bearer(adminToken))
        .send(draft({ [field]: { telemetry: true, clipboard_monitor: true, audio_recording: true } }));
      expect(res.status, `${field} should be rejected`).toBe(400);
      expect(res.body.error.message).toMatch(/consent/i);
    }
  });

  it("seeds a session whose consent is still entirely unanswered", async () => {
    const created = await h.api
      .post("/admin/scheduled-interviews")
      .set(...bearer(adminToken))
      .send(draft({ coding_round_enabled: true }))
      .expect(201);

    const started = await h.api
      .post("/sessions")
      .set(...bearer(studentToken))
      .send({ scheduled_interview_id: created.body.scheduled[0].id })
      .expect(201);

    const session = await h.storage.sessions.get(started.body.session_id);
    // Every flag false, exactly as a self-serve session starts — a coding round
    // being scheduled does not pre-grant clipboard monitoring.
    expect(session!.consent).toEqual(DEFAULT_CONSENT);
    expect(Object.values(session!.consent).every((v) => v === false)).toBe(true);
  });

  it("tells the candidate consent is still theirs to give", async () => {
    await h.api
      .post("/admin/scheduled-interviews")
      .set(...bearer(adminToken))
      .send(draft())
      .expect(201);

    const mine = await h.api.get("/me/scheduled-interviews").set(...bearer(studentToken)).expect(200);
    expect(mine.body.scheduled[0].consent_note).toMatch(/consent/i);
  });

  it("keeps the assigned session gated behind the device check like any other", async () => {
    const created = await h.api
      .post("/admin/scheduled-interviews")
      .set(...bearer(adminToken))
      .send(draft())
      .expect(201);
    const started = await h.api
      .post("/sessions")
      .set(...bearer(studentToken))
      .send({ scheduled_interview_id: created.body.scheduled[0].id })
      .expect(201);

    for (const to of ["CONFIG", "TELEMETRY_CHECK"]) {
      await h.api
        .post(`/sessions/${started.body.session_id}/advance`)
        .set(...bearer(studentToken))
        .send({ to })
        .expect(200);
    }
    // No device check recorded, so beginning is still refused.
    await h.api
      .post(`/sessions/${started.body.session_id}/begin`)
      .set(...bearer(studentToken))
      .expect(409);
  });
});

// ---------------------------------------------------------------- gate 7

describe("gate test 7 — the student projection carries nothing admin-internal", () => {
  it("has no notes or created_by key at all", async () => {
    const created = await h.api
      .post("/admin/scheduled-interviews")
      .set(...bearer(adminToken))
      .send({
        candidate_ids: [studentId],
        role: "Senior Backend Engineer",
        interview_type: "technical",
        difficulty: "mid",
        duration_minutes: 30,
        scheduled_for: hourFromNow(-1),
        notes: "ADMIN-ONLY-NOTE-do-not-show-the-candidate",
      })
      .expect(201);

    // The admin projection has it...
    expect(created.body.scheduled[0].notes).toBe("ADMIN-ONLY-NOTE-do-not-show-the-candidate");

    // ...and the student one has no key for it, rather than a stripped value.
    const mine = await h.api.get("/me/scheduled-interviews").set(...bearer(studentToken)).expect(200);
    const row = mine.body.scheduled[0];
    expect(Object.keys(row)).not.toContain("notes");
    expect(Object.keys(row)).not.toContain("created_by");
    expect(JSON.stringify(mine.body)).not.toContain("ADMIN-ONLY-NOTE");
  });

  it("is asserted on the projection itself, so a new field cannot leak by default", async () => {
    const wire = toStudentWire({
      id: "s1",
      candidateId: "c1",
      department: "Engineering",
      role: "Backend",
      jobDescription: "",
      interviewType: "technical",
      difficulty: "mid",
      durationMinutes: 30,
      scheduledFor: hourFromNow(-1),
      deadline: null,
      recurring: "none",
      codingRoundEnabled: false,
      notes: "SECRET",
      notifyVia: ["in_app"],
      status: "pending",
      sessionId: null,
      createdBy: "admin-1",
      createdAt: hourFromNow(-2),
      updatedAt: hourFromNow(-2),
    });

    // An exact key set: adding a field to `ScheduledInterview` that the student
    // projection should not carry fails here rather than in production.
    expect(Object.keys(wire).sort()).toEqual(
      [
        "consent_note",
        "deadline",
        "difficulty",
        "duration_minutes",
        "id",
        "interview_type",
        "job_description",
        "role",
        "runs_coding_round",
        "scheduled_for",
        "session_id",
        "status",
      ].sort(),
    );
  });
});

// ---------------------------------------------------------------- gate 8

describe("gate test 8 — scheduling input validation", () => {
  const base = {
    role: "Senior Backend Engineer",
    interview_type: "technical",
    difficulty: "mid",
    duration_minutes: 45,
    scheduled_for: hourFromNow(24),
  };

  it("rejects a deadline that is not after the window", () => {
    expect(() =>
      validateDraft({ ...base, candidate_ids: ["c1"], deadline: hourFromNow(12) }),
    ).toThrow(/deadline must be after/i);
  });

  it("rejects durations outside the allowed range, and non-integers", () => {
    for (const duration of [0, -5, 9, 181, 45.5, Number.NaN]) {
      expect(() =>
        validateDraft({ ...base, candidate_ids: ["c1"], duration_minutes: duration }),
      ).toThrow(/duration_minutes/);
    }
  });

  it("rejects an unparseable timestamp instead of storing an Invalid Date", () => {
    expect(() =>
      validateDraft({ ...base, candidate_ids: ["c1"], scheduled_for: "next tuesday" }),
    ).toThrow(/ISO 8601/);
  });

  it("rejects an empty candidate list and unknown enum values", () => {
    expect(() => validateDraft({ ...base, candidate_ids: [] })).toThrow(/candidate_ids/);
    expect(() =>
      validateDraft({ ...base, candidate_ids: ["c1"], interview_type: "vibes" }),
    ).toThrow(/interview_type/);
    expect(() => validateDraft({ ...base, candidate_ids: ["c1"], difficulty: "wizard" })).toThrow(
      /difficulty/,
    );
  });

  it("refuses to schedule for an account that is not a student", async () => {
    const admin = await h.storage.users.findByEmail(ADMIN.email);
    const res = await h.api
      .post("/admin/scheduled-interviews")
      .set(...bearer(adminToken))
      .send({ ...base, candidate_ids: [admin!.id] });

    expect(res.status).toBe(400);
    expect(res.body.error.code).toBe("unknown_candidate");
  });

  it("refuses an id that does not exist, and writes nothing", async () => {
    const res = await h.api
      .post("/admin/scheduled-interviews")
      .set(...bearer(adminToken))
      .send({ ...base, candidate_ids: [studentId, "00000000-0000-4000-8000-000000000000"] });

    expect(res.status).toBe(400);
    // All or nothing: the valid half of the batch must not have been assigned.
    expect(await h.storage.scheduled.list()).toHaveLength(0);
  });
});

// ---------------------------------------------------------------- gate 9

describe("gate test 9 — the profile drill-down and report download", () => {
  it("returns history, a score trend oldest-first, and per-session scores", async () => {
    const weak = await seedReport(studentId, [2, 2], "2026-01-10T10:00:00.000Z");
    const strong = await seedReport(studentId, [5, 5], "2026-03-10T10:00:00.000Z");

    const res = await h.api.get(`/admin/users/${studentId}`).set(...bearer(adminToken)).expect(200);

    expect(res.body.profile.interviews_completed).toBe(2);
    expect(res.body.profile.average_score).toBeCloseTo(3.5, 5);
    // Oldest first — a trend reads left to right. This ordering keys off report
    // `createdAt`, which the seed controls, so it is exact.
    expect(res.body.profile.score_trend.map((p: { score: number }) => p.score)).toEqual([2, 5]);

    // The history list keys off SESSION `createdAt`, which the store stamps
    // itself — two seeded sessions can land in the same millisecond, so the
    // scores are matched by session id rather than by position.
    expect(res.body.sessions).toHaveLength(2);
    const bySession = new Map(
      res.body.sessions.map((s: { session_id: string }) => [s.session_id, s]),
    );
    expect((bySession.get(strong.sessionId) as { overall_score: number }).overall_score).toBe(5);
    expect((bySession.get(weak.sessionId) as { overall_score: number }).overall_score).toBe(2);
    expect((bySession.get(strong.sessionId) as { has_report: boolean }).has_report).toBe(true);
  });

  it("orders history newest first, deterministically", async () => {
    await seedReport(studentId, [3, 3], "2026-01-10T10:00:00.000Z");
    await seedReport(studentId, [4, 4], "2026-02-10T10:00:00.000Z");

    // Same request twice: a tie on `startedAt` must not reshuffle the list.
    const first = await h.api.get(`/admin/users/${studentId}`).set(...bearer(adminToken)).expect(200);
    const second = await h.api.get(`/admin/users/${studentId}`).set(...bearer(adminToken)).expect(200);

    const ids = (body: { sessions: { session_id: string }[] }) =>
      body.sessions.map((s) => s.session_id);
    expect(ids(first.body)).toEqual(ids(second.body));

    const startedAts = first.body.sessions.map((s: { started_at: string }) => s.started_at);
    expect([...startedAts].sort().reverse()).toEqual(startedAts);
  });

  it("classifies session status from the session state", async () => {
    const running = await h.storage.sessions.create({
      candidateId: studentId,
      role: "R",
      jobDescription: "",
    });
    expect(running.state).toBe("CREATED");

    const res = await h.api.get(`/admin/users/${studentId}`).set(...bearer(adminToken)).expect(200);
    const row = res.body.sessions.find((s: { session_id: string }) => s.session_id === running.id);
    expect(row.status).toBe("in_progress");
    // Duration is null while it runs — `updatedAt` is not an end time.
    expect(row.duration_minutes).toBeNull();
  });

  it("404s a user who is not a student", async () => {
    const admin = await h.storage.users.findByEmail(ADMIN.email);
    await h.api.get(`/admin/users/${admin!.id}`).set(...bearer(adminToken)).expect(404);
  });

  it("downloads one report as an attachment and audits the read", async () => {
    const report = await seedReport(studentId, [4, 4], "2026-04-01T10:00:00.000Z");

    const res = await h.api
      .get(`/admin/reports/${report.sessionId}/download`)
      .set(...bearer(adminToken))
      .expect(200);

    expect(res.headers["content-disposition"]).toContain(`report-${report.sessionId}.json`);
    expect(JSON.parse(res.text).sessionId).toBe(report.sessionId);

    const events = await h.storage.telemetry.recent(50);
    const audit = events.find((e) => e.eventType === "admin_reports_downloaded");
    expect(audit).toBeTruthy();
    expect(audit!.payload.candidate_id).toBe(studentId);
    // IDs and counts only — the audit trail must not become a second copy.
    expect(Object.keys(audit!.payload).sort()).toEqual(
      ["admin_id", "candidate_id", "reports"].sort(),
    );
  });

  it("downloads a candidate's whole set, and 404s when they have none", async () => {
    await h.api
      .get(`/admin/users/${studentId}/reports/download`)
      .set(...bearer(adminToken))
      .expect(404);

    await seedReport(studentId, [3, 3], "2026-05-01T10:00:00.000Z");
    const res = await h.api
      .get(`/admin/users/${studentId}/reports/download`)
      .set(...bearer(adminToken))
      .expect(200);

    expect(res.headers["content-disposition"]).toContain(`reports-${studentId}.json`);
    expect(JSON.parse(res.text).reports).toHaveLength(1);
  });
});

// ---------------------------------------------------------------- gate 10

describe("gate test 10 — status is derived from the clock, never stale", () => {
  const schedule = (scheduledFor: string, deadline: string | null, status = "pending" as const) => ({
    status,
    scheduledFor,
    deadline,
  });

  it("moves pending -> sent -> missed as time passes, without anything writing a row", () => {
    const window = "2026-06-01T09:00:00.000Z";
    const deadline = "2026-06-02T09:00:00.000Z";

    expect(effectiveStatus(schedule(window, deadline), new Date("2026-05-31T00:00:00Z"))).toBe("pending");
    expect(effectiveStatus(schedule(window, deadline), new Date("2026-06-01T10:00:00Z"))).toBe("sent");
    expect(effectiveStatus(schedule(window, deadline), new Date("2026-06-03T00:00:00Z"))).toBe("missed");
  });

  it("never overrides a terminal or candidate-driven state with a clock-derived one", () => {
    const past = schedule("2026-06-01T09:00:00.000Z", "2026-06-02T09:00:00.000Z");
    const late = new Date("2026-07-01T00:00:00Z");

    // A cancelled assignment does not later become "missed".
    expect(effectiveStatus({ ...past, status: "cancelled" }, late)).toBe("cancelled");
    // Nor does one the candidate actually sat.
    expect(effectiveStatus({ ...past, status: "started" }, late)).toBe("started");
    expect(effectiveStatus({ ...past, status: "completed" }, late)).toBe("completed");
  });

  it("is startable only inside the open window", () => {
    const s = schedule("2026-06-01T09:00:00.000Z", "2026-06-02T09:00:00.000Z");
    expect(isStartable(s, new Date("2026-05-31T00:00:00Z"))).toBe(false);
    expect(isStartable(s, new Date("2026-06-01T10:00:00Z"))).toBe(true);
    expect(isStartable(s, new Date("2026-06-03T00:00:00Z"))).toBe(false);
  });

  it("treats a schedule with no deadline as open indefinitely once the window passes", () => {
    expect(isStartable(schedule("2026-06-01T09:00:00.000Z", null), new Date("2027-01-01T00:00:00Z"))).toBe(
      true,
    );
  });
});

// ---------------------------------------------------------------- gate 11

describe("gate test 11 — the directory builder in isolation", () => {
  const user = (id: string, over: Partial<{ email: string; fullName: string; department: string; createdAt: string }> = {}) =>
    ({
      id,
      email: over.email ?? `${id}@example.com`,
      role: "student" as const,
      passcodeHash: "x",
      crossSessionMemoryOptIn: false,
      ...(over.fullName ? { fullName: over.fullName } : {}),
      ...(over.department ? { department: over.department } : {}),
      createdAt: over.createdAt ?? "2026-01-01T00:00:00.000Z",
    });

  it("prefers `interview_scheduled` over `active`", () => {
    const page = buildDirectoryPage({
      students: [user("u1")],
      reportStats: [{ candidateId: "u1", interviewsCompleted: 9, averageScore: 4.5, lastInterviewAt: "2026-02-01T00:00:00.000Z" }],
      scheduledCandidateIds: ["u1"],
      sessionCounts: { u1: 9 },
      avatars: {},
    });
    // A candidate with ten interviews behind them and an eleventh assigned is,
    // on this screen, a scheduled one.
    expect(page.rows[0]!.status).toBe("interview_scheduled");
  });

  it("clamps page size and never returns more than the max", () => {
    const students = Array.from({ length: 250 }, (_, i) => user(`u${i}`));
    const page = buildDirectoryPage(
      { students, reportStats: [], scheduledCandidateIds: [], sessionCounts: {}, avatars: {} },
      { pageSize: 5000 },
    );
    expect(page.rows.length).toBeLessThanOrEqual(100);
    expect(page.total).toBe(250);
  });

  it("is stable across pages when the sort key ties", () => {
    // Every row has a null score, so the sort key alone cannot order them.
    const students = Array.from({ length: 6 }, (_, i) => user(`u${i}`));
    const inputs = { students, reportStats: [], scheduledCandidateIds: [], sessionCounts: {}, avatars: {} };

    const first = buildDirectoryPage(inputs, { sort: "averageScore", pageSize: 3, page: 1 });
    const second = buildDirectoryPage(inputs, { sort: "averageScore", pageSize: 3, page: 2 });
    const seen = [...first.rows, ...second.rows].map((r) => r.userId);

    expect(new Set(seen).size).toBe(6);
  });
});

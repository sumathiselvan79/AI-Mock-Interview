/**
 * Stage 6 — the tiered concept-escalation model (INSTRUCTIONS.md §4.3, §4.4).
 *
 * 1. `buildSystemBlueprint` produces exactly three tiers per topic, each with
 *    its own non-empty `targetConceptIds` (except tier 3's escalation
 *    condition, which is null — there is nothing above "advanced").
 * 2. The Question Agent's per-topic tier escalation: a strong run of scores at
 *    a topic's current tier escalates it, a weak run steps it back, and an
 *    ambiguous or absent signal holds — all scoped to ONE topic, never
 *    blended into another (soul.md §"Balanced coverage").
 * 3. The Eval Tool's `verifyConcepts` is evidence-first: a concept is verified
 *    only because its label's words actually appear in the transcript.
 * 4. The Follow-up Agent's deterministic gap detector reports its FULL hit
 *    list as `antiPatternsDetected`, not just the one gap it chose to probe.
 */

import { describe, expect, it } from "vitest";
import {
  buildSystemBlueprint,
  blueprintTopic,
  tierSpec,
  QUESTION_BANK,
  questionsForTopicAndTier,
  tierOf,
  conceptId,
} from "@mia/interview-domain";
import { nextTierFor, pickByTier, selectNextQuestion, type SelectQuestionInput } from "@mia/question-agent";
import { verifyConcepts } from "@mia/tool-eval";
import { considerFollowUp } from "@mia/followup-agent";
import type { TopicPlanEntry } from "@mia/shared-types";

describe("systemBlueprint: tiered extraction matrix", () => {
  const blueprint = buildSystemBlueprint("Senior Backend Engineer");

  it("carries a roleProfileId and domainFocus resolved from the role", () => {
    expect(blueprint.roleProfileId).toBe("backend-engineer");
    expect(blueprint.domainFocus).toBe("Backend Engineer");
  });

  it("gives every topic three tiers, each with the bank's concept ids for that tier", () => {
    const topic = blueprintTopic(blueprint, "databases");
    expect(topic).toBeDefined();

    for (const tier of [1, 2, 3] as const) {
      const spec = tierSpec(topic!, tier);
      expect(spec.tier).toBe(tier);
      const expected = questionsForTopicAndTier("databases", tier).flatMap((q) => q.conceptIds);
      expect(spec.targetConceptIds).toEqual(expect.arrayContaining(expected));
      expect(spec.targetConceptIds.length).toBeGreaterThan(0);
    }
  });

  it("only tier 3 has a null escalationTriggerCondition", () => {
    const topic = blueprintTopic(blueprint, "system design")!;
    expect(tierSpec(topic, 1).escalationTriggerCondition).not.toBeNull();
    expect(tierSpec(topic, 2).escalationTriggerCondition).not.toBeNull();
    expect(tierSpec(topic, 3).escalationTriggerCondition).toBeNull();
  });

  it("derives tier and conceptIds on every bank question consistently with tierOf/conceptId", () => {
    for (const q of QUESTION_BANK) {
      expect(q.tier).toBe(tierOf(q.difficulty));
      expect(q.conceptIds).toEqual(q.expectedSignals.map((label) => conceptId(q.topic, q.tier, label)));
    }
  });
});

describe("question-agent: per-topic tier escalation", () => {
  const plan: TopicPlanEntry[] = [{ topic: "databases", maxQuestions: 3, source: "resume" }];
  const base: Omit<SelectQuestionInput, "topicTier" | "topicScores"> = {
    sessionId: "s1",
    topicPlan: plan,
    topicCounts: {},
    askedQuestionIds: [],
    difficultyTarget: 3,
  };

  it("escalates a topic whose recent scores at its current tier are strong", () => {
    expect(nextTierFor("databases", 0, { ...base, topicTier: { databases: 1 }, topicScores: { databases: [4.5, 5] } })).toBe(2);
  });

  it("steps a topic back down when its recent scores are weak", () => {
    expect(nextTierFor("databases", 0, { ...base, topicTier: { databases: 2 }, topicScores: { databases: [1, 1.5] } })).toBe(1);
  });

  it("holds when the signal is ambiguous, and never escalates past tier 3", () => {
    expect(nextTierFor("databases", 0, { ...base, topicTier: { databases: 2 }, topicScores: { databases: [3, 3] } })).toBe(2);
    expect(nextTierFor("databases", 0, { ...base, topicTier: { databases: 3 }, topicScores: { databases: [5, 5] } })).toBe(3);
  });

  it("does not let one topic's scores move a different topic's tier", () => {
    const twoTopics: TopicPlanEntry[] = [
      { topic: "databases", maxQuestions: 3, source: "resume" },
      { topic: "system design", maxQuestions: 3, source: "role_requirement" },
    ];
    const input: SelectQuestionInput = {
      ...base,
      topicPlan: twoTopics,
      topicTier: { databases: 1, "system design": 1 },
      topicScores: { databases: [5, 5] }, // system design has no score history
    };
    expect(nextTierFor("databases", 0, input)).toBe(2);
    expect(nextTierFor("system design", 0, input)).toBe(1);
  });

  it("selectNextQuestion picks a question at the escalated tier once a topic's tier moves up", () => {
    const selected = selectNextQuestion({
      ...base,
      topicTier: { databases: 1 },
      topicScores: { databases: [5, 5] },
    });
    expect(selected.question.tier).toBe(2);
    expect(selected.question.difficulty).toBe(3);
  });

  it("pickByTier falls back to the nearest available tier when the exact one is unavailable", () => {
    const tier1Only = questionsForTopicAndTier("databases", 1);
    expect(pickByTier(tier1Only, 3).tier).toBe(1);
  });
});

describe("tool-eval: concept verification is evidence-first", () => {
  it("verifies a concept only when its label's words actually appear in the transcript", () => {
    const result = verifyConcepts(
      "I raised the connection pool size and cut latency by rewriting the query plan.",
      [
        { id: "c1", label: "connection pool size" },
        { id: "c2", label: "rollback procedure" },
      ],
    );
    expect(result.verifiedConceptIds).toContain("c1");
    expect(result.unverifiedConceptIds).toContain("c2");
  });

  it("returns nothing verified for an empty transcript", () => {
    const result = verifyConcepts("", [{ id: "c1", label: "component boundaries" }]);
    expect(result.verifiedConceptIds).toEqual([]);
    expect(result.unverifiedConceptIds).toEqual(["c1"]);
  });
});

describe("followup-agent: anti-patterns are the full hit list, not just the probed one", () => {
  it("reports every detected gap id, not just the one it chose to probe", () => {
    const decision = considerFollowUp({
      question: "Tell me about a project.",
      answerTranscript:
        "We shipped a new caching layer for the checkout service last quarter and it went smoothly overall.",
    });

    expect(decision.shouldFollowUp).toBe(true);
    // Two real gaps here: no stated outcome, and no reasoning behind the
    // approach. The probe only targets the first (no_outcome); the second is
    // still reported so nothing detected gets silently dropped.
    expect(decision.antiPatternsDetected).toEqual(["no_outcome", "no_reasoning"]);
    expect(decision.reason).toMatch(/turned out/i);
  });

  it("reports an empty anti-pattern list when nothing is worth probing", () => {
    const decision = considerFollowUp({
      question: "Tell me about a project.",
      answerTranscript:
        "I personally rebuilt the checkout service's retry logic because the old one double-charged customers on timeout. " +
        "I chose exponential backoff with jitter instead of a fixed retry interval, since the fixed interval was what caused " +
        "the thundering-herd problem in the first place. As a result we cut duplicate charges by 90%, and I verified it by " +
        "replaying the previous month's failure logs against the new code before shipping.",
    });

    expect(decision.antiPatternsDetected).toEqual([]);
    expect(decision.shouldFollowUp).toBe(false);
  });
});

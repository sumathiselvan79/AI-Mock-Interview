/**
 * TRACKING.md Stage 1, gate test 2:
 * "Contract test /auth/login: student token rejected on any /admin/* route
 *  (expect 403); admin token behaves the same on student-only routes."
 *
 * Plus the rest of the auth surface from INSTRUCTIONS.md §7.
 */

import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { ADMIN, STUDENT, bearer, buildHarness, loginToken, seedUsers, type TestHarness } from "./helpers.js";

let h: TestHarness;

beforeEach(async () => {
  h = await buildHarness();
  await seedUsers(h);
});

afterEach(async () => {
  await h.close();
});

describe("POST /auth/login", () => {
  it("issues a role-scoped token for a student", async () => {
    const res = await h.api.post("/auth/login").send(STUDENT).expect(200);
    expect(res.body.user.role).toBe("student");
    expect(typeof res.body.token).toBe("string");
    expect(res.body.user).not.toHaveProperty("passcodeHash");
  });

  it("issues an admin-scoped token for an admin", async () => {
    const res = await h.api.post("/auth/login").send(ADMIN).expect(200);
    expect(res.body.user.role).toBe("admin");
  });

  it("rejects a wrong passcode with the same message as an unknown account", async () => {
    const wrongPasscode = await h.api
      .post("/auth/login")
      .send({ email: STUDENT.email, passcode: "not-the-passcode" })
      .expect(401);
    const unknownAccount = await h.api
      .post("/auth/login")
      .send({ email: "nobody@example.com", passcode: "not-the-passcode" })
      .expect(401);

    // Identical responses: login must not be an account-enumeration oracle.
    expect(wrongPasscode.body).toEqual(unknownAccount.body);
  });

  it("rejects a malformed request", async () => {
    await h.api.post("/auth/login").send({ email: STUDENT.email }).expect(400);
  });
});

describe("role-based access control at the gateway", () => {
  it("rejects an unauthenticated request before it reaches any route", async () => {
    await h.api.get("/admin/reports").expect(401);
    await h.api.get("/me/stats").expect(401);
    await h.api.post("/sessions").send({ role: "Backend Engineer" }).expect(401);
  });

  it("rejects a tampered or garbage token", async () => {
    const token = await loginToken(h, STUDENT);
    const tampered = `${token.slice(0, -3)}aaa`;
    await h.api.get("/me/stats").set(...bearer(tampered)).expect(401);
    await h.api.get("/me/stats").set(...bearer("not.a.token")).expect(401);
  });

  it("gives a student token 403 on every /admin/* route", async () => {
    const token = await loginToken(h, STUDENT);
    await h.api.get("/admin/reports").set(...bearer(token)).expect(403);
    await h.api.get("/admin/reports/any-session-id").set(...bearer(token)).expect(403);
  });

  it("gives an admin token 403 on student-only routes, including starting a session", async () => {
    const token = await loginToken(h, ADMIN);
    await h.api.get("/me/stats").set(...bearer(token)).expect(403);
    // An Admin cannot start an interview as a candidate (INSTRUCTIONS.md §3.2).
    await h.api.post("/sessions").set(...bearer(token)).send({ role: "Backend Engineer" }).expect(403);
  });

  it("lets each role through on its own routes", async () => {
    const studentToken = await loginToken(h, STUDENT);
    const adminToken = await loginToken(h, ADMIN);
    await h.api.get("/me/stats").set(...bearer(studentToken)).expect(200);
    await h.api.get("/admin/reports").set(...bearer(adminToken)).expect(200);
  });

  it("stops one student reading another student's session", async () => {
    const other = await h.auth.createUser({
      email: "other@example.com",
      passcode: "another-practice-1",
      role: "student",
    });
    const session = await h.storage.sessions.create({
      candidateId: other.id,
      role: "Backend Engineer",
      jobDescription: "",
    });

    const token = await loginToken(h, STUDENT);
    await h.api.get(`/sessions/${session.id}`).set(...bearer(token)).expect(403);
  });
});

describe("passcode reset flow", () => {
  it("issues a single-use token that sets a new passcode exactly once", async () => {
    await h.api.post("/auth/reset-passcode/request").send({ email: STUDENT.email }).expect(202);

    const delivered = h.mailbox.lastFor(STUDENT.email);
    expect(delivered).toBeDefined();

    await h.api
      .post("/auth/reset-passcode/confirm")
      .send({ token: delivered!.token, passcode: "a-brand-new-passcode" })
      .expect(200);

    await h.api.post("/auth/login").send(STUDENT).expect(401);
    await h.api
      .post("/auth/login")
      .send({ email: STUDENT.email, passcode: "a-brand-new-passcode" })
      .expect(200);

    // Replaying the same token must fail — it is single-use (§8).
    await h.api
      .post("/auth/reset-passcode/confirm")
      .send({ token: delivered!.token, passcode: "yet-another-passcode" })
      .expect(400);
  });

  it("answers 202 for an unknown address without sending anything", async () => {
    await h.api.post("/auth/reset-passcode/request").send({ email: "nobody@example.com" }).expect(202);
    expect(h.mailbox.lastFor("nobody@example.com")).toBeUndefined();
  });

  it("rejects an unknown token and a too-short new passcode", async () => {
    await h.api
      .post("/auth/reset-passcode/confirm")
      .send({ token: "made-up-token", passcode: "long-enough-passcode" })
      .expect(400);

    await h.api.post("/auth/reset-passcode/request").send({ email: STUDENT.email }).expect(202);
    const delivered = h.mailbox.lastFor(STUDENT.email)!;
    await h.api
      .post("/auth/reset-passcode/confirm")
      .send({ token: delivered.token, passcode: "short" })
      .expect(400);
  });

  it("never writes the reset token itself to the logs", async () => {
    await h.api.post("/auth/reset-passcode/request").send({ email: STUDENT.email }).expect(202);
    const delivered = h.mailbox.lastFor(STUDENT.email)!;
    expect(h.logs.history().join("\n")).not.toContain(delivered.token);
  });
});

/**
 * Regression: `question_budget` is the one session field the client picks, and
 * it was taken on trust.
 *
 * `POST /sessions` guarded it with `typeof body.question_budget === "number"`,
 * which admits `NaN`, `Infinity`, `0`, negatives and fractions. That matters
 * because `InterviewOrchestrator.nextQuestion` ends the loop on exactly one
 * condition — `questions_asked >= session.questionBudget` — so:
 *
 *  - `NaN` makes every comparison false and the interview can never end. It is
 *    not a short session or a long one; it is one with no terminating
 *    condition at all.
 *  - `0` or a negative sends the session straight to WRAP_UP having asked
 *    nothing, and the Report Agent then refuses to report on a session with
 *    nothing scoreable — a dead end the candidate cannot get out of.
 *  - An arbitrarily large value lets one candidate spend unbounded provider
 *    calls, since every question is several MCP hops.
 */

import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { DEFAULT_QUESTION_BUDGET, MAX_QUESTION_BUDGET } from "@mia/shared-types";
import { STUDENT, bearer, buildHarness, loginToken, seedUsers, type TestHarness } from "./helpers.js";

let h: TestHarness;
let token: string;

const createWith = (budget: unknown) =>
  h.api
    .post("/sessions")
    .set(...bearer(token))
    .send({ role: "Senior Backend Engineer", job_description: "Backend work.", question_budget: budget });

beforeEach(async () => {
  h = await buildHarness();
  await seedUsers(h);
  token = await loginToken(h, STUDENT);
});

afterEach(async () => {
  await h.close();
});

describe("question_budget is validated at the boundary", () => {
  it("rejects NaN rather than creating a session that can never finish", async () => {
    // JSON has no NaN literal, so this is how it actually arrives on the wire.
    const res = await h.api
      .post("/sessions")
      .set(...bearer(token))
      .set("content-type", "application/json")
      .send('{"role":"Senior Backend Engineer","question_budget":1e999}');

    expect(res.status).toBe(400);
    expect(res.body.error.code).toBe("invalid_request");
  });

  it("rejects zero, negatives and fractions", async () => {
    for (const budget of [0, -1, -100, 2.5, 0.1]) {
      const res = await createWith(budget);
      expect(res.status, `budget ${budget} should be rejected`).toBe(400);
      expect(res.body.error.code).toBe("invalid_request");
    }
  });

  it("rejects a budget past the ceiling", async () => {
    const res = await createWith(MAX_QUESTION_BUDGET + 1);
    expect(res.status).toBe(400);

    const huge = await createWith(1_000_000);
    expect(huge.status).toBe(400);
  });

  it("rejects a non-number", async () => {
    for (const budget of ["8", true, null, [], {}]) {
      const res = await createWith(budget);
      expect(res.status, `budget ${JSON.stringify(budget)} should be rejected`).toBe(400);
    }
  });

  it("still accepts a legitimate budget, and stores it", async () => {
    const res = await createWith(12);
    expect(res.status).toBe(201);

    const session = await h.storage.sessions.get(res.body.session_id);
    expect(session?.questionBudget).toBe(12);
  });

  it("accepts both ends of the allowed range", async () => {
    for (const budget of [1, MAX_QUESTION_BUDGET]) {
      const res = await createWith(budget);
      expect(res.status, `budget ${budget} should be accepted`).toBe(201);
      expect((await h.storage.sessions.get(res.body.session_id))?.questionBudget).toBe(budget);
    }
  });

  it("falls back to the default when the field is omitted", async () => {
    const res = await h.api
      .post("/sessions")
      .set(...bearer(token))
      .send({ role: "Senior Backend Engineer", job_description: "Backend work." })
      .expect(201);

    expect((await h.storage.sessions.get(res.body.session_id))?.questionBudget).toBe(DEFAULT_QUESTION_BUDGET);
  });

  it("never stores a budget the loop cannot terminate on", async () => {
    // The property that matters, stated directly: whatever ends up on a
    // session, `questions_asked >= questionBudget` has to become true.
    const res = await createWith(3);
    expect(res.status).toBe(201);
    const budget = (await h.storage.sessions.get(res.body.session_id))!.questionBudget;

    expect(Number.isInteger(budget)).toBe(true);
    expect(budget).toBeGreaterThan(0);
    expect(budget >= budget).toBe(true);
  });
});

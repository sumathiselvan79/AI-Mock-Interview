/**
 * GET /auth/google/start + GET /auth/google/callback.
 *
 * The goal's test criteria: "a tampered state is rejected and the resulting
 * token's role comes from the allowlist, not from Google." Both are tested
 * against the real route wiring; only the network call to Google's token
 * endpoint is swapped for a fake (via `googleAuthClient` in CreateGatewayOptions
 * — the same seam `speechProvider`/`mailer` already use for this test suite).
 */

import { afterEach, describe, expect, it } from "vitest";
import type { GoogleAuthClient } from "../src/auth/google.js";
import { bearer, buildHarness, type TestHarness } from "./helpers.js";

let h: TestHarness | undefined;

afterEach(async () => {
  await h?.close();
  h = undefined;
});

function extractCookies(setCookieHeader: string[] | undefined): Record<string, string> {
  const out: Record<string, string> = {};
  for (const raw of setCookieHeader ?? []) {
    const [pair] = raw.split(";");
    const eq = pair!.indexOf("=");
    out[pair!.slice(0, eq)] = pair!.slice(eq + 1);
  }
  return out;
}

function fakeIdToken(claims: Record<string, unknown>): string {
  const b64 = (obj: unknown) => Buffer.from(JSON.stringify(obj)).toString("base64url");
  return `${b64({ alg: "none", typ: "JWT" })}.${b64(claims)}.fake-signature`;
}

function fakeGoogleClient(idToken: string): GoogleAuthClient {
  return {
    createAuthorizationURL: () => new URL("https://accounts.google.com/o/oauth2/v2/auth?fake=1"),
    validateAuthorizationCode: async () => ({ idToken: () => idToken }),
  };
}

/** Parses the `#token=...&role=...` fragment the callback redirects the browser to. */
function parseCallbackRedirect(location: string): { token: string; role: string } {
  const url = new URL(location);
  const params = new URLSearchParams(url.hash.replace(/^#/, ""));
  return { token: params.get("token") ?? "", role: params.get("role") ?? "" };
}

/** Reads the claims out of a session JWT without verifying its signature — the test only needs the payload. */
function decodeTokenClaims(token: string): { sub: string; email: string; role: string } {
  const [, body] = token.split(".");
  return JSON.parse(Buffer.from(body!, "base64url").toString("utf8"));
}

const CLIENT_ID = "test-client-id";
const validClaims = () => ({
  iss: "https://accounts.google.com",
  aud: CLIENT_ID,
  sub: "google-subject-123",
  email: "candidate@example.com",
  email_verified: true,
  exp: Math.floor(Date.now() / 1000) + 3600,
});

describe("GET /auth/google/start", () => {
  it("redirects to Google and sets short-lived state/PKCE cookies", async () => {
    h = await buildHarness({ config: { google: { clientId: CLIENT_ID, clientSecret: "s", redirectUri: "http://localhost/cb" } } });
    const res = await h.api.get("/auth/google/start").expect(302);
    expect(res.headers.location).toContain("accounts.google.com");

    const cookies = extractCookies(res.headers["set-cookie"] as unknown as string[]);
    expect(cookies["mia_oauth_state"]).toBeDefined();
    expect(cookies["mia_oauth_verifier"]).toBeDefined();
    const rawSetCookie = (res.headers["set-cookie"] as unknown as string[]).join("\n");
    expect(rawSetCookie).toMatch(/HttpOnly/);
  });
});

describe("GET /auth/google/callback — CSRF/state handling", () => {
  it("rejects a callback with no OAuth flow in progress (no cookies)", async () => {
    h = await buildHarness();
    await h.api.get("/auth/google/callback?code=abc&state=whatever").expect(400);
  });

  it("rejects a tampered state that doesn't match the cookie set at /start", async () => {
    h = await buildHarness();
    const res = await h.api
      .get("/auth/google/callback?code=abc&state=attacker-supplied-state")
      .set("Cookie", ["mia_oauth_state=real-state-from-start", "mia_oauth_verifier=real-verifier"])
      .expect(400);
    expect(res.body.error.code).toBe("invalid_oauth_state");
  });
});

describe("GET /auth/google/callback — role resolution", () => {
  it("ignores a bogus 'role' claim on the ID token and defaults an unlisted email to student", async () => {
    const idToken = fakeIdToken({ ...validClaims(), email: "attacker@example.com", role: "admin" });
    h = await buildHarness({
      config: {
        google: { clientId: CLIENT_ID, clientSecret: "s", redirectUri: "http://localhost/cb" },
        adminEmailAllowlist: [],
      },
      googleAuthClient: fakeGoogleClient(idToken),
    });

    const start = await h.api.get("/auth/google/start").expect(302);
    const cookies = extractCookies(start.headers["set-cookie"] as unknown as string[]);

    const res = await h.api
      .get(`/auth/google/callback?code=fake-code&state=${cookies["mia_oauth_state"]}`)
      .set("Cookie", [`mia_oauth_state=${cookies["mia_oauth_state"]}`, `mia_oauth_verifier=${cookies["mia_oauth_verifier"]}`])
      .expect(302);

    expect(res.headers.location).toContain("http://localhost:3000/auth/callback#");
    const { token, role } = parseCallbackRedirect(res.headers.location as string);
    expect(role).toBe("student");
    expect(decodeTokenClaims(token).email).toBe("attacker@example.com");
  });

  it("grants admin only when the verified email is on the allowlist, not from the token", async () => {
    const idToken = fakeIdToken({ ...validClaims(), email: "boss@example.com", role: "student" });
    h = await buildHarness({
      config: {
        google: { clientId: CLIENT_ID, clientSecret: "s", redirectUri: "http://localhost/cb" },
        adminEmailAllowlist: ["boss@example.com"],
      },
      googleAuthClient: fakeGoogleClient(idToken),
    });

    const start = await h.api.get("/auth/google/start").expect(302);
    const cookies = extractCookies(start.headers["set-cookie"] as unknown as string[]);

    const res = await h.api
      .get(`/auth/google/callback?code=fake-code&state=${cookies["mia_oauth_state"]}`)
      .set("Cookie", [`mia_oauth_state=${cookies["mia_oauth_state"]}`, `mia_oauth_verifier=${cookies["mia_oauth_verifier"]}`])
      .expect(302);

    const { token, role } = parseCallbackRedirect(res.headers.location as string);
    expect(role).toBe("admin");
    await h.api.get("/admin/reports").set(...bearer(token)).expect(200);
  });

  it("rejects an ID token with the wrong audience", async () => {
    const idToken = fakeIdToken({ ...validClaims(), aud: "someone-elses-client-id" });
    h = await buildHarness({
      config: { google: { clientId: CLIENT_ID, clientSecret: "s", redirectUri: "http://localhost/cb" } },
      googleAuthClient: fakeGoogleClient(idToken),
    });

    const start = await h.api.get("/auth/google/start").expect(302);
    const cookies = extractCookies(start.headers["set-cookie"] as unknown as string[]);

    const res = await h.api
      .get(`/auth/google/callback?code=fake-code&state=${cookies["mia_oauth_state"]}`)
      .set("Cookie", [`mia_oauth_state=${cookies["mia_oauth_state"]}`, `mia_oauth_verifier=${cookies["mia_oauth_verifier"]}`])
      .expect(400);
    expect(res.body.error.code).toBe("invalid_id_token");
  });

  it("rejects an ID token whose email Google has not verified", async () => {
    const idToken = fakeIdToken({ ...validClaims(), email_verified: false });
    h = await buildHarness({
      config: { google: { clientId: CLIENT_ID, clientSecret: "s", redirectUri: "http://localhost/cb" } },
      googleAuthClient: fakeGoogleClient(idToken),
    });

    const start = await h.api.get("/auth/google/start").expect(302);
    const cookies = extractCookies(start.headers["set-cookie"] as unknown as string[]);

    await h.api
      .get(`/auth/google/callback?code=fake-code&state=${cookies["mia_oauth_state"]}`)
      .set("Cookie", [`mia_oauth_state=${cookies["mia_oauth_state"]}`, `mia_oauth_verifier=${cookies["mia_oauth_verifier"]}`])
      .expect(400);
  });
});

describe("GET /auth/google/callback — OAuth profile snapshot", () => {
  it("stores name/picture/subject from the ID token in the OAuth profile store, keyed to the logged-in user", async () => {
    const idToken = fakeIdToken({
      ...validClaims(),
      email: "candidate@example.com",
      sub: "google-subject-abc",
      name: "Candidate Name",
      picture: "https://example.com/avatar.png",
    });
    h = await buildHarness({
      config: { google: { clientId: CLIENT_ID, clientSecret: "s", redirectUri: "http://localhost/cb" } },
      googleAuthClient: fakeGoogleClient(idToken),
    });

    const start = await h.api.get("/auth/google/start").expect(302);
    const cookies = extractCookies(start.headers["set-cookie"] as unknown as string[]);

    const res = await h.api
      .get(`/auth/google/callback?code=fake-code&state=${cookies["mia_oauth_state"]}`)
      .set("Cookie", [`mia_oauth_state=${cookies["mia_oauth_state"]}`, `mia_oauth_verifier=${cookies["mia_oauth_verifier"]}`])
      .expect(302);

    const { token } = parseCallbackRedirect(res.headers.location as string);
    const userId = decodeTokenClaims(token).sub;

    const profile = await h.storage.oauthProfiles?.getByUserId(userId);
    expect(profile).toEqual({
      userId,
      provider: "google",
      providerSubject: "google-subject-abc",
      email: "candidate@example.com",
      name: "Candidate Name",
      avatarUrl: "https://example.com/avatar.png",
      linkedAt: expect.any(String),
    });
  });

  it("still logs in successfully when the ID token has no name/picture claims (profile scope declined)", async () => {
    const idToken = fakeIdToken({ ...validClaims(), sub: "google-subject-minimal" });
    h = await buildHarness({
      config: { google: { clientId: CLIENT_ID, clientSecret: "s", redirectUri: "http://localhost/cb" } },
      googleAuthClient: fakeGoogleClient(idToken),
    });

    const start = await h.api.get("/auth/google/start").expect(302);
    const cookies = extractCookies(start.headers["set-cookie"] as unknown as string[]);

    const res = await h.api
      .get(`/auth/google/callback?code=fake-code&state=${cookies["mia_oauth_state"]}`)
      .set("Cookie", [`mia_oauth_state=${cookies["mia_oauth_state"]}`, `mia_oauth_verifier=${cookies["mia_oauth_verifier"]}`])
      .expect(302);

    const { token } = parseCallbackRedirect(res.headers.location as string);
    const userId = decodeTokenClaims(token).sub;
    const profile = await h.storage.oauthProfiles?.getByUserId(userId);
    expect(profile?.providerSubject).toBe("google-subject-minimal");
    expect(profile?.name).toBeUndefined();
    expect(profile?.avatarUrl).toBeUndefined();
  });
});

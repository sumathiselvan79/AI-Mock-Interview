/**
 * Regression: a follow-up may only ever be written onto an answer that belongs
 * to the session the caller was authorized for.
 *
 * `POST /sessions/:id/answers/:answerId/follow-up` checks that the caller owns
 * session `:id` — but `:answerId` is a second, independent client-supplied id,
 * and nothing used to tie the two together. `HarnessAgent.submitFollowUpAnswer`
 * took no session id at all and resolved the target session FROM the answer, so
 * an authenticated student could append their own text (and trigger scoring)
 * inside another candidate's session by pairing their own session id with a
 * borrowed answer id.
 *
 * The assertion that matters is not just the status code: it is that the
 * victim's answer is byte-for-byte unchanged afterwards. A 4xx returned after
 * the write already landed would be worse than useless.
 */

import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { BACKEND_JOB_DESCRIPTION } from "./fixtures/resumes.js";
import { STUDENT, bearer, buildHarness, loginToken, seedUsers, type TestHarness } from "./helpers.js";

const OTHER_STUDENT = { email: "other-student@example.com", passcode: "practice-run-2" };

const STRONG_ANSWER = `We had a settlement service timing out under load. I profiled the hot path,
found a synchronous Postgres write inside the request, moved it onto a queue and added an idempotency
key so retries could not double-charge. p99 went from 900ms to 210ms and the on-call pages stopped.`;

let h: TestHarness;

beforeEach(async () => {
  h = await buildHarness();
  await seedUsers(h);
  await h.auth.createUser({ ...OTHER_STUDENT, role: "student" });
});

afterEach(async () => {
  await h.close();
});

/** Drives one student from CREATED all the way to a stored, answered question. */
async function sessionWithAnswer(creds: { email: string; passcode: string }): Promise<{
  token: string;
  sessionId: string;
  answerId: string;
  questionId: string;
}> {
  const token = await loginToken(h, creds);

  const created = await h.api
    .post("/sessions")
    .set(...bearer(token))
    .send({ role: "Senior Backend Engineer", job_description: BACKEND_JOB_DESCRIPTION })
    .expect(201);
  const sessionId = created.body.session_id as string;

  for (const to of ["CONFIG", "TELEMETRY_CHECK"]) {
    await h.api.post(`/sessions/${sessionId}/advance`).set(...bearer(token)).send({ to }).expect(200);
  }
  await h.api
    .post(`/sessions/${sessionId}/telemetry-check`)
    .set(...bearer(token))
    .send({ mic_ok: true, speaker_ok: true, consent: { telemetry: true } })
    .expect(200);
  await h.api.post(`/sessions/${sessionId}/begin`).set(...bearer(token)).expect(200);

  const next = await h.api
    .get(`/sessions/${sessionId}/questions/next`)
    .set(...bearer(token))
    .expect(200);
  const questionId = next.body.question.id as string;

  const answered = await h.api
    .post(`/sessions/${sessionId}/answers`)
    .set(...bearer(token))
    .send({ question_id: questionId, transcript: STRONG_ANSWER })
    .expect(201);

  return { token, sessionId, answerId: answered.body.answer_id as string, questionId };
}

describe("follow-up submission is bound to the answer's own session", () => {
  it("refuses an answer id from another candidate's session, and writes nothing", async () => {
    const victim = await sessionWithAnswer(STUDENT);
    const attacker = await sessionWithAnswer(OTHER_STUDENT);

    // Two different candidates, two different sessions — the precondition the
    // whole test rests on.
    expect(attacker.sessionId).not.toBe(victim.sessionId);
    expect(attacker.answerId).not.toBe(victim.answerId);

    const before = await h.storage.answers.get(victim.answerId);
    expect(before?.followUps).toHaveLength(0);

    // The attacker owns `attacker.sessionId`, so the session-ownership check
    // passes. Only the answer-to-session check can stop this.
    await h.api
      .post(`/sessions/${attacker.sessionId}/answers/${victim.answerId}/follow-up`)
      .set(...bearer(attacker.token))
      .send({ follow_up_text: "Say more about the queue.", transcript: "I designed the whole thing myself." })
      .expect(404);

    const after = await h.storage.answers.get(victim.answerId);
    expect(after?.followUps).toHaveLength(0);
    expect(after?.transcript).toBe(before?.transcript);
  });

  it("still accepts a follow-up on the caller's own answer", async () => {
    const student = await sessionWithAnswer(STUDENT);

    const res = await h.api
      .post(`/sessions/${student.sessionId}/answers/${student.answerId}/follow-up`)
      .set(...bearer(student.token))
      .send({
        follow_up_text: "What was the idempotency key derived from?",
        transcript: "The upstream payment intent id, so a retry of the same charge collapsed onto one row.",
      })
      .expect(201);

    expect(res.body.follow_ups).toBe(1);
    const stored = await h.storage.answers.get(student.answerId);
    expect(stored?.followUps).toHaveLength(1);
  });

  it("404s an answer id that does not exist at all", async () => {
    const student = await sessionWithAnswer(STUDENT);

    await h.api
      .post(`/sessions/${student.sessionId}/answers/00000000-0000-4000-8000-000000000000/follow-up`)
      .set(...bearer(student.token))
      .send({ follow_up_text: "anything", transcript: "anything" })
      .expect(404);
  });

  it("rejects the same substitution at the harness, not only at the route", async () => {
    // The route's 404 is the friendly status code; this is the actual boundary.
    // A caller reaching the harness directly (the live WebSocket channel does)
    // must be refused too.
    const victim = await sessionWithAnswer(STUDENT);
    const attacker = await sessionWithAnswer(OTHER_STUDENT);

    await expect(
      h.harness.submitFollowUpAnswer({
        sessionId: attacker.sessionId,
        answerId: victim.answerId,
        followUpText: "Say more.",
        transcript: "borrowed",
      }),
    ).rejects.toThrow(/does not belong to this session/);

    expect((await h.storage.answers.get(victim.answerId))?.followUps).toHaveLength(0);
  });
});

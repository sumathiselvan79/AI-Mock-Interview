/**
 * Eval Tool, Follow-up Agent and Time Tracking behaviour that the Stage 2 gate
 * assumes but does not spell out — including the fairness guardrails in
 * soul.md §3 and §5, which are exactly the kind of rule that erodes quietly
 * unless something asserts on it.
 */

import { describe, expect, it } from "vitest";
import { getRubric, rubricIds, scoreAgainstRubric, MIN_SCOREABLE_CONFIDENCE } from "@mia/tool-eval";
import { considerFollowUp } from "@mia/followup-agent";
import { segmentStateFor, elapsedMs } from "@mia/tool-time-tracking";
import { buildHarness, seedUsers, loginToken, bearer, STUDENT } from "./helpers.js";

const STRONG = `At my last company the checkout service was falling over every Monday.
I traced it to a connection pool that we never resized after a traffic change.
I raised the pool and added a circuit breaker, because the alternative — adding instances —
would have cost more and hidden the real problem. As a result error rates dropped from 4% to 0.2%.`;

/**
 * The same substance as STRONG, in non-native phrasing with grammatical slips.
 * It must score the same: "Never let scoring penalize accent, non-native
 * phrasing, or communication style" (soul.md §5).
 */
const STRONG_NON_NATIVE = `At my last company the checkout service is falling over every Monday.
I trace it to a connection pool what we never resized after a traffic change.
I raised the pool and added a circuit breaker, because the alternative — adding instances —
would have cost more and hidden the real problem. As a result error rates dropped from 4% to 0.2%.`;

describe("Eval Tool rubrics", () => {
  it("ships a first versioned behavioural rubric", () => {
    expect(rubricIds()).toContain("behavioral_v1");
    const rubric = getRubric("behavioral_v1");
    expect(rubric?.version).toBe(1);
    expect(rubric?.signals.length).toBeGreaterThan(0);
  });

  it("scores every point against a span of the transcript it can point at", () => {
    const rubric = getRubric("behavioral_v1")!;
    const result = scoreAgainstRubric(rubric, STRONG);

    expect(result.score).toBeGreaterThan(3);
    expect(result.evidenceSpans.length).toBeGreaterThan(0);
    for (const span of result.evidenceSpans) {
      expect(span.start).toBeGreaterThanOrEqual(0);
      expect(span.end).toBeGreaterThan(span.start);
      expect(span.end).toBeLessThanOrEqual(STRONG.length);
      // The span must actually contain words from the answer.
      expect(STRONG.slice(span.start, span.end).trim().length).toBeGreaterThan(0);
    }
  });

  it("says which signals were missing, so feedback is actionable", () => {
    const rubric = getRubric("behavioral_v1")!;
    const vague = `I have worked on lots of systems over the years and I would say I am good at
      this kind of thing, it is something I have done many times in different places.`;
    const result = scoreAgainstRubric(rubric, vague);

    expect(result.missingSignals.length).toBeGreaterThan(0);
    expect(result.rationale).toMatch(/not evidenced/i);
    expect(result.score).toBeLessThan(3);
  });

  it("does not penalise non-native phrasing for the same substance", () => {
    const rubric = getRubric("behavioral_v1")!;
    const native = scoreAgainstRubric(rubric, STRONG);
    const nonNative = scoreAgainstRubric(rubric, STRONG_NON_NATIVE);

    expect(nonNative.score).toBe(native.score);
    expect(nonNative.matchedSignals.sort()).toEqual(native.matchedSignals.sort());
  });

  it("lets executed tests move a coding score, not just the talk-through", () => {
    const rubric = getRubric("coding_round_v1")!;
    const talk = "I looped over the array and returned the first duplicate I found.";
    const allPassing = scoreAgainstRubric(rubric, talk, [
      { case: "basic", passed: true },
      { case: "empty", passed: true },
    ]);
    const allFailing = scoreAgainstRubric(rubric, talk, [
      { case: "basic", passed: false },
      { case: "empty", passed: false },
    ]);

    expect(allPassing.score).toBeGreaterThan(allFailing.score);
    expect(allPassing.rationale).toMatch(/2 of 2 test cases passed/);
  });
});

describe("Eval Tool refusals", () => {
  it("refuses a thin transcript instead of returning a low score", async () => {
    const h = await buildHarness();
    try {
      await seedUsers(h);
      const token = await loginToken(h, STUDENT);
      const created = await h.api
        .post("/sessions")
        .set(...bearer(token))
        .send({ role: "Backend Engineer" })
        .expect(201);

      const ctx = {
        sessionId: created.body.session_id as string,
        caller: "harness-agent",
        sessionToken: created.body.session_token as string,
      };

      const thin = await h.mcp.call("tool-eval", "evaluate_answer", {
        rubric_id: "behavioral_v1",
        question: "Tell me about a time you led something.",
        answer_transcript: "I did, yes.",
      }, ctx);
      expect(thin.error?.code).toBe("insufficient_transcript");

      // A low-confidence transcript is never scored silently (soul.md §5).
      const lowConfidence = await h.mcp.call("tool-eval", "evaluate_answer", {
        rubric_id: "behavioral_v1",
        question: "Tell me about a time you led something.",
        answer_transcript: STRONG,
        transcript_confidence: MIN_SCOREABLE_CONFIDENCE - 0.1,
      }, ctx);
      expect(lowConfidence.error?.code).toBe("insufficient_transcript");
      expect(lowConfidence.error?.message).toMatch(/re-prompt|typed text/i);

      const unknownRubric = await h.mcp.call("tool-eval", "evaluate_answer", {
        rubric_id: "made_up_v9",
        question: "?",
        answer_transcript: STRONG,
      }, ctx);
      expect(unknownRubric.error?.code).toBe("unknown_rubric_id");
    } finally {
      await h.close();
    }
  });
});

describe("Follow-up Agent", () => {
  it("targets the specific gap it found, and names it", () => {
    const noOutcome = considerFollowUp({
      question: "Tell me about a system you improved.",
      answerTranscript:
        "I rewrote the ingestion pipeline in Go and I added a retry queue in front of it because the old one dropped messages under load.",
    });

    expect(noOutcome.shouldFollowUp).toBe(true);
    expect(noOutcome.reason).toMatch(/turned out|outcome/i);
    expect(noOutcome.followUpText!.length).toBeGreaterThan(20);
  });

  it("leaves a complete answer alone", () => {
    const complete = considerFollowUp({
      question: "Tell me about a system you improved.",
      answerTranscript: STRONG,
    });
    expect(complete.shouldFollowUp).toBe(false);
    expect(complete.reason).toMatch(/no gap worth probing/i);
  });

  it("gives a struggling candidate a way in rather than a trap", () => {
    const thin = considerFollowUp({
      question: "Tell me about a time you led something.",
      answerTranscript: "Not much comes to mind.",
    });
    expect(thin.shouldFollowUp).toBe(true);
    expect(thin.followUpText).toMatch(/start with|specific/i);
  });

  it("will not probe a low-confidence transcript", () => {
    const decision = considerFollowUp({
      question: "Tell me about a system you improved.",
      answerTranscript: STRONG,
      transcriptConfidence: 0.3,
    });
    expect(decision.shouldFollowUp).toBe(false);
    expect(decision.reason).toMatch(/re-prompt|typed text/i);
  });
});

describe("Time Tracking", () => {
  it("warns before it expires, never straight to expired", () => {
    const budget = 240_000;
    expect(segmentStateFor(budget, budget)).toBe("on_track");
    expect(segmentStateFor(budget * 0.5, budget)).toBe("on_track");
    expect(segmentStateFor(budget * 0.1, budget)).toBe("nudge");
    expect(segmentStateFor(0, budget)).toBe("expired");
    expect(segmentStateFor(-5_000, budget)).toBe("expired");
  });

  it("does not count paused time against the candidate", () => {
    const start = 1_000_000;
    const timer = { segmentId: "s:q1", budgetMs: 60_000, startedAt: start, pausedAt: null, pausedMs: 0 };

    expect(elapsedMs(timer, start + 10_000)).toBe(10_000);
    expect(elapsedMs({ ...timer, pausedAt: start + 10_000 }, start + 30_000)).toBe(10_000);
    expect(elapsedMs({ ...timer, pausedMs: 20_000 }, start + 30_000)).toBe(10_000);
  });
});

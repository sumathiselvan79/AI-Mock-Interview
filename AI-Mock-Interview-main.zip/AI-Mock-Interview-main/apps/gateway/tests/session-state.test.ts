/**
 * TRACKING.md Stage 1, gate test 3:
 * "Create a Session via POST /sessions, confirm it starts in CREATED, then
 *  manually drive it through CONFIG -> TELEMETRY_CHECK and confirm each
 *  transition is only ever made by the Harness Agent (nothing else writes
 *  Session.state)."
 */

import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { HARNESS_GRANT, canTransition, allowedNextStates } from "@mia/harness-agent";
import type { StateWriteGrant } from "@mia/shared-types";
import { StateWriteForbidden } from "../src/storage/memory.js";
import { STUDENT, bearer, buildHarness, loginToken, seedUsers, type TestHarness } from "./helpers.js";

let h: TestHarness;
let token: string;

beforeEach(async () => {
  h = await buildHarness();
  await seedUsers(h);
  token = await loginToken(h, STUDENT);
});

afterEach(async () => {
  await h.close();
});

async function createSession(): Promise<string> {
  const res = await h.api
    .post("/sessions")
    .set(...bearer(token))
    .send({ role: "Senior Backend Engineer", job_description: "owns service reliability" })
    .expect(201);
  expect(res.body.state).toBe("CREATED");
  return res.body.session_id as string;
}

const advance = (id: string, to: string) =>
  h.api.post(`/sessions/${id}/advance`).set(...bearer(token)).send({ to });

describe("session creation and the CREATED -> CONFIG -> TELEMETRY_CHECK path", () => {
  it("starts a new session in CREATED", async () => {
    const id = await createSession();
    const res = await h.api.get(`/sessions/${id}`).set(...bearer(token)).expect(200);
    expect(res.body.session.state).toBe("CREATED");
    expect(res.body.allowed_next_states).toEqual(["CONFIG", "ABORTED"]);
  });

  it("drives CREATED -> CONFIG -> TELEMETRY_CHECK and logs every transition against the harness", async () => {
    const id = await createSession();

    expect((await advance(id, "CONFIG").expect(200)).body.session.state).toBe("CONFIG");
    expect((await advance(id, "TELEMETRY_CHECK").expect(200)).body.session.state).toBe("TELEMETRY_CHECK");

    const { body } = await h.api.get(`/sessions/${id}/transitions`).set(...bearer(token)).expect(200);
    expect(body.transitions).toHaveLength(2);
    expect(body.transitions.map((t: { toState: string }) => t.toState)).toEqual([
      "CONFIG",
      "TELEMETRY_CHECK",
    ]);
    // Nothing else is capable of writing a transition row.
    for (const t of body.transitions) expect(t.actor).toBe("harness-agent");
  });

  it("rejects a skipped or backwards transition with 409", async () => {
    const id = await createSession();
    await advance(id, "QUESTION_LOOP").expect(409); // skips CONFIG + TELEMETRY_CHECK
    await advance(id, "CONFIG").expect(200);
    await advance(id, "CREATED").expect(409); // backwards
    await advance(id, "CONFIG").expect(409); // already there
  });

  it("blocks everything downstream of TELEMETRY_CHECK until the device check passes", async () => {
    const id = await createSession();
    await advance(id, "CONFIG").expect(200);
    await advance(id, "TELEMETRY_CHECK").expect(200);

    // Device check not recorded yet: CALIBRATION is gated (INSTRUCTIONS.md §3).
    await advance(id, "CALIBRATION").expect(409);

    // A failed check is still a failed check.
    await h.api
      .post(`/sessions/${id}/telemetry-check`)
      .set(...bearer(token))
      .send({ mic_ok: true, speaker_ok: false, consent: { telemetry: true } })
      .expect(200);
    await advance(id, "CALIBRATION").expect(409);

    await h.api
      .post(`/sessions/${id}/telemetry-check`)
      .set(...bearer(token))
      .send({ mic_ok: true, speaker_ok: true, consent: { telemetry: true, clipboard_monitor: true } })
      .expect(200);
    await advance(id, "CALIBRATION").expect(200);

    const session = (await h.api.get(`/sessions/${id}`).set(...bearer(token)).expect(200)).body.session;
    expect(session.consent).toEqual({
      telemetry: true,
      clipboardMonitor: true,
      audioRecording: false,
      crossSessionMemory: false,
      focusLossMonitoring: false,
    });
  });

  it("can always abort, and nothing moves after that", async () => {
    const id = await createSession();
    await advance(id, "CONFIG").expect(200);
    await h.harness.abort(id, "candidate_left");
    expect((await h.harness.getSession(id))!.state).toBe("ABORTED");
    await advance(id, "TELEMETRY_CHECK").expect(409);
  });
});

describe("Session.state is writable by the Harness Agent alone", () => {
  it("refuses a write with no grant", async () => {
    const id = await createSession();
    await expect(
      // Casting away the type is exactly what a rogue caller would do; the store
      // still refuses, because the check is on the symbol's identity at runtime.
      h.storage.sessions.setState(id, "CONFIG", undefined as unknown as StateWriteGrant, "rogue"),
    ).rejects.toBeInstanceOf(StateWriteForbidden);
  });

  it("refuses a forged grant that only looks like the harness's", async () => {
    const id = await createSession();
    const forged: StateWriteGrant = { actor: "harness-agent", token: Symbol("harness-agent.state-write") };
    await expect(h.storage.sessions.setState(id, "CONFIG", forged, "forged")).rejects.toBeInstanceOf(
      StateWriteForbidden,
    );
    expect((await h.harness.getSession(id))!.state).toBe("CREATED");
  });

  it("refuses to register a second state writer", () => {
    const other: StateWriteGrant = { actor: "harness-agent", token: Symbol("someone-else") };
    expect(() => h.storage.sessions.registerStateWriter(other)).toThrow(StateWriteForbidden);
  });

  it("accepts the real grant, and records no transition row for a rejected write", async () => {
    const id = await createSession();
    await expect(
      h.storage.sessions.setState(id, "CONFIG", {} as StateWriteGrant, "rogue"),
    ).rejects.toBeInstanceOf(StateWriteForbidden);
    expect(await h.storage.sessions.transitions(id)).toHaveLength(0);

    await h.storage.sessions.setState(id, "CONFIG", HARNESS_GRANT, "direct_harness_write");
    expect(await h.storage.sessions.transitions(id)).toHaveLength(1);
  });
});

describe("state machine rules (INSTRUCTIONS.md §3)", () => {
  it("matches the documented lifecycle", () => {
    expect(canTransition("CREATED", "CONFIG").allowed).toBe(true);
    expect(canTransition("CONFIG", "TELEMETRY_CHECK").allowed).toBe(true);
    expect(canTransition("TELEMETRY_CHECK", "CALIBRATION").allowed).toBe(true);
    expect(canTransition("CALIBRATION", "QUESTION_LOOP").allowed).toBe(true);
    expect(canTransition("QUESTION_LOOP", "WRAP_UP").allowed).toBe(true); // coding round skipped
    expect(canTransition("QUESTION_LOOP", "CODING_ROUND").allowed).toBe(true);
    expect(canTransition("CODING_ROUND", "WRAP_UP").allowed).toBe(true);
    expect(canTransition("WRAP_UP", "REPORT_GENERATION").allowed).toBe(true);
    expect(canTransition("REPORT_GENERATION", "COMPLETED").allowed).toBe(true);
  });

  it("allows ABORTED from every non-terminal state, and nothing from a terminal one", () => {
    for (const state of ["CREATED", "CONFIG", "QUESTION_LOOP", "WRAP_UP"] as const) {
      expect(allowedNextStates(state)).toContain("ABORTED");
    }
    expect(allowedNextStates("COMPLETED")).toEqual([]);
    expect(allowedNextStates("ABORTED")).toEqual([]);
    expect(canTransition("COMPLETED", "QUESTION_LOOP").allowed).toBe(false);
  });
});

/**
 * TRACKING.md Stage 2, gate tests 2 and 3:
 *
 * 2. "Unit test topic-plan generation: confirm the floor (1) and ceiling (3)
 *     per topic hold, and that a `required_topic` with zero resume relevance
 *     still gets a slot."
 * 3. "Simulate a session hitting a topic's cap mid-loop — confirm the Question
 *     Agent excludes that topic. Then simulate exhausting *every* topic's cap
 *     before `question_budget` is used up — confirm it only then overrides, and
 *     that `quota_override: true` is set and logged, never silent."
 */

import { describe, expect, it } from "vitest";
import {
  buildTopicPlan,
  planCapacity,
  selectNextQuestion,
  NoQuestionsLeft,
  difficultyTargetFrom,
} from "@mia/question-agent";
import {
  TOPIC_QUESTION_CEILING,
  TOPIC_QUESTION_FLOOR,
  type TopicPlanEntry,
  type TopicRelevance,
} from "@mia/shared-types";
import { requiredTopicsFor, questionsForTopic } from "@mia/interview-domain";

const relevance = (topic: string, score: number): TopicRelevance => ({
  topic,
  relevanceScore: score,
  evidence: `line mentioning ${topic}`,
});

describe("topic plan: floor, ceiling, and guaranteed coverage", () => {
  it("keeps every topic between the floor and the ceiling", () => {
    const plan = buildTopicPlan({
      topicRelevance: [
        relevance("distributed systems", 1),
        relevance("databases", 0.9),
        relevance("behavioral: leadership", 0.8),
      ],
      requiredTopics: requiredTopicsFor("Senior Backend Engineer"),
      questionBudget: 8,
    });

    expect(plan.length).toBeGreaterThan(0);
    for (const entry of plan) {
      expect(entry.maxQuestions).toBeGreaterThanOrEqual(TOPIC_QUESTION_FLOOR);
      expect(entry.maxQuestions).toBeLessThanOrEqual(TOPIC_QUESTION_CEILING);
    }
  });

  it("holds the ceiling even when one topic dominates the resume", () => {
    // A resume that screams one topic must not turn into a one-topic interview
    // (soul.md §"Balanced coverage").
    const plan = buildTopicPlan({
      topicRelevance: [relevance("distributed systems", 1)],
      requiredTopics: ["system design"],
      questionBudget: 8,
    });

    const distributed = plan.find((e) => e.topic === "distributed systems");
    expect(distributed?.maxQuestions).toBeLessThanOrEqual(TOPIC_QUESTION_CEILING);
  });

  it("gives a required topic a slot even at zero resume relevance", () => {
    const plan = buildTopicPlan({
      topicRelevance: [relevance("frontend engineering", 1)],
      requiredTopics: ["security", "reliability and operations"],
      questionBudget: 8,
    });

    for (const required of ["security", "reliability and operations"]) {
      const entry = plan.find((e) => e.topic === required);
      expect(entry, `${required} must be in the plan`).toBeDefined();
      expect(entry!.maxQuestions).toBeGreaterThanOrEqual(TOPIC_QUESTION_FLOOR);
      expect(entry!.source).toBe("role_requirement");
    }
  });

  it("gives a JD gap a slot and labels where it came from", () => {
    const plan = buildTopicPlan({
      topicRelevance: [relevance("databases", 0.9)],
      requiredTopics: ["system design"],
      jdGapTopics: ["machine learning"],
      questionBudget: 6,
    });

    const gap = plan.find((e) => e.topic === "machine learning");
    expect(gap).toBeDefined();
    expect(gap!.source).toBe("jd_gap");
    expect(gap!.maxQuestions).toBeGreaterThanOrEqual(1);
  });

  it("spends the budget without exceeding it when the topics fit", () => {
    const plan = buildTopicPlan({
      topicRelevance: [
        relevance("distributed systems", 0.9),
        relevance("databases", 0.7),
        relevance("behavioral: leadership", 0.5),
      ],
      requiredTopics: ["system design"],
      questionBudget: 8,
    });

    expect(planCapacity(plan)).toBeLessThanOrEqual(8);
    expect(planCapacity(plan)).toBeGreaterThanOrEqual(plan.length);
  });

  it("keeps required topics when the budget is smaller than the topic set", () => {
    const plan = buildTopicPlan({
      topicRelevance: [
        relevance("distributed systems", 0.9),
        relevance("databases", 0.8),
        relevance("frontend engineering", 0.7),
        relevance("mobile engineering", 0.6),
        relevance("data engineering", 0.5),
      ],
      requiredTopics: ["security"],
      questionBudget: 3,
    });

    expect(plan.find((e) => e.topic === "security")).toBeDefined();
    for (const entry of plan) expect(entry.maxQuestions).toBe(TOPIC_QUESTION_FLOOR);
  });

  it("returns an empty plan rather than inventing topics when there is nothing to go on", () => {
    expect(buildTopicPlan({ topicRelevance: [], requiredTopics: [], questionBudget: 8 })).toEqual([]);
  });
});

describe("quota enforcement during the question loop", () => {
  const plan: TopicPlanEntry[] = [
    { topic: "databases", maxQuestions: 1, source: "resume" },
    { topic: "system design", maxQuestions: 2, source: "role_requirement" },
  ];

  it("excludes a topic once it reaches its cap", () => {
    const selected = selectNextQuestion({
      sessionId: "s1",
      topicPlan: plan,
      topicCounts: { databases: 1, "system design": 0 },
      askedQuestionIds: [],
      difficultyTarget: 3,
    });

    expect(selected.question.topic).toBe("system design");
    expect(selected.quotaOverride).toBe(false);
  });

  it("picks the least-covered topic first, so coverage stays even", () => {
    const selected = selectNextQuestion({
      sessionId: "s1",
      topicPlan: plan,
      topicCounts: { databases: 0, "system design": 1 },
      askedQuestionIds: [],
      difficultyTarget: 3,
    });
    expect(selected.question.topic).toBe("databases");
  });

  it("never repeats a question already asked", () => {
    const first = selectNextQuestion({
      sessionId: "s1",
      topicPlan: plan,
      topicCounts: {},
      askedQuestionIds: [],
      difficultyTarget: 3,
    });
    const second = selectNextQuestion({
      sessionId: "s1",
      topicPlan: plan,
      topicCounts: { [first.question.topic]: 1 },
      askedQuestionIds: [first.question.bankId],
      difficultyTarget: 3,
    });
    expect(second.question.bankId).not.toBe(first.question.bankId);
  });

  it("overrides only once every topic is capped, and flags it explicitly", () => {
    const selected = selectNextQuestion({
      sessionId: "s1",
      topicPlan: plan,
      // Every topic at its cap, but the budget still has room.
      topicCounts: { databases: 1, "system design": 2 },
      askedQuestionIds: [],
      difficultyTarget: 3,
    });

    expect(selected.quotaOverride).toBe(true);
    expect(selected.question.quotaOverride).toBe(true);
    expect(selected.overrideReason).toMatch(/cap/i);
  });

  it("gives up rather than repeating itself when the bank is exhausted", () => {
    const allDatabaseQuestions = questionsForTopic("databases").map((q) => q.id);
    expect(() =>
      selectNextQuestion({
        sessionId: "s1",
        topicPlan: [{ topic: "databases", maxQuestions: 3, source: "resume" }],
        topicCounts: { databases: 3 },
        askedQuestionIds: allDatabaseQuestions,
        difficultyTarget: 3,
      }),
    ).toThrow(NoQuestionsLeft);
  });
});

describe("progressive difficulty", () => {
  it("opens below the target and climbs as a topic is revisited", () => {
    const first = selectNextQuestion({
      sessionId: "s1",
      topicPlan: [{ topic: "databases", maxQuestions: 3, source: "resume" }],
      topicCounts: {},
      askedQuestionIds: [],
      difficultyTarget: 3,
    });
    const second = selectNextQuestion({
      sessionId: "s1",
      topicPlan: [{ topic: "databases", maxQuestions: 3, source: "resume" }],
      topicCounts: { databases: 1 },
      askedQuestionIds: [first.question.bankId],
      difficultyTarget: 3,
    });

    expect(second.question.difficulty).toBeGreaterThan(first.question.difficulty);
  });

  it("moves the target with the running performance signal, and stays in 1-5", () => {
    expect(difficultyTargetFrom([])).toBe(3);
    expect(difficultyTargetFrom([4.5, 4.2, 5])).toBe(4);
    expect(difficultyTargetFrom([1, 1.5, 2])).toBe(2);
    expect(difficultyTargetFrom([5, 5, 5], 5)).toBe(5);
    expect(difficultyTargetFrom([0, 0, 0], 1)).toBe(1);
  });
});

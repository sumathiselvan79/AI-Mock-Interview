/**
 * TRACKING.md Stage 2, gate tests 4 and 5, plus the stage gate itself:
 *
 * 4. "Run a scripted candidate persona through CONFIG -> CALIBRATION ->
 *     QUESTION_LOOP by typed text; confirm the resulting question set is
 *     topic-balanced and matches `topic_plan`."
 * 5. "On the Interview Config page, upload a resume, then delete it — confirm
 *     the underlying stored file is actually gone (check storage directly, not
 *     just that the UI stops showing it)."
 *
 * Gate: "a full session runs start-to-finish with typed Q&A and the transcript
 * stored in Postgres matches exactly what the frontend displayed."
 */

import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { BACKEND_JOB_DESCRIPTION, SENIOR_BACKEND_TXT, encoder } from "./fixtures/resumes.js";
import { STUDENT, bearer, buildHarness, loginToken, seedUsers, type TestHarness } from "./helpers.js";

let h: TestHarness;
let token: string;
let sessionId: string;

/** A scripted candidate: a strong STAR answer, reused for every question. */
const STRONG_ANSWER = `At my last company we had a settlement service that was timing out under load.
I profiled the hot path and found we were doing a synchronous write to Postgres inside the request.
I moved that write onto a queue and added an idempotency key so retries could not double-charge anyone.
We chose the queue rather than a bigger database instance because the write was not read back immediately,
and the tradeoff was that reconciliation became eventually consistent, which finance signed off on.
As a result p99 latency went from 900ms to 210ms and the on-call pages for that service stopped.`;

/** A thin answer: too little to score, on purpose. */
const THIN_ANSWER = "Yeah, I did that once.";

beforeEach(async () => {
  h = await buildHarness();
  await seedUsers(h);
  token = await loginToken(h, STUDENT);

  const created = await h.api
    .post("/sessions")
    .set(...bearer(token))
    .send({ role: "Senior Backend Engineer", job_description: BACKEND_JOB_DESCRIPTION })
    .expect(201);
  sessionId = created.body.session_id;
});

afterEach(async () => {
  await h.close();
});

async function uploadResume(): Promise<void> {
  await h.api
    .post(`/sessions/${sessionId}/resume`)
    .set(...bearer(token))
    .send({
      filename: "priya-raman.txt",
      content_type: "text/plain",
      data_base64: Buffer.from(encoder.encode(SENIOR_BACKEND_TXT)).toString("base64"),
    })
    .expect(201);
}

/** CREATED -> CONFIG -> TELEMETRY_CHECK, device check passed. */
async function configureAndCheck(): Promise<void> {
  await h.api.post(`/sessions/${sessionId}/advance`).set(...bearer(token)).send({ to: "CONFIG" }).expect(200);
  await h.api
    .post(`/sessions/${sessionId}/advance`)
    .set(...bearer(token))
    .send({ to: "TELEMETRY_CHECK" })
    .expect(200);
  await h.api
    .post(`/sessions/${sessionId}/telemetry-check`)
    .set(...bearer(token))
    .send({ mic_ok: true, speaker_ok: true, consent: { telemetry: true } })
    .expect(200);
}

describe("resume upload and hard deletion (gate test 5)", () => {
  it("stores the file, then actually removes the bytes on delete", async () => {
    await uploadResume();

    const stored = await h.storage.sessions.get(sessionId);
    expect(stored?.resumeRef).toBeTruthy();
    // Check the backing store, not the UI or the session pointer.
    expect(await h.storage.files.exists(stored!.resumeRef!)).toBe(true);
    expect(await h.storage.files.listBySession(sessionId)).toHaveLength(1);

    const ref = stored!.resumeRef!;
    await h.api.delete(`/sessions/${sessionId}/resume`).set(...bearer(token)).expect(200);

    expect(await h.storage.files.exists(ref)).toBe(false);
    expect(await h.storage.files.get(ref)).toBeNull();
    expect(await h.storage.files.listBySession(sessionId)).toHaveLength(0);

    const after = await h.storage.sessions.get(sessionId);
    expect(after?.resumeRef).toBeNull();
    // The structured profile survives, so a configured session still works (§8).
    expect(after?.candidateProfile?.topicRelevance.length).toBeGreaterThan(0);
  });

  it("hard-deletes the old file when a resume is replaced", async () => {
    await uploadResume();
    const first = (await h.storage.sessions.get(sessionId))!.resumeRef!;

    await uploadResume();
    const second = (await h.storage.sessions.get(sessionId))!.resumeRef!;

    expect(second).not.toBe(first);
    expect(await h.storage.files.exists(first)).toBe(false);
    expect(await h.storage.files.exists(second)).toBe(true);
  });

  it("404s a delete when there is nothing uploaded", async () => {
    await h.api.delete(`/sessions/${sessionId}/resume`).set(...bearer(token)).expect(404);
  });
});

describe("scripted candidate through CONFIG -> CALIBRATION -> QUESTION_LOOP (gate test 4)", () => {
  it("runs a full typed interview that matches the topic plan", async () => {
    await uploadResume();
    await configureAndCheck();

    const begun = await h.api.post(`/sessions/${sessionId}/begin`).set(...bearer(token)).expect(200);
    expect(begun.body.state).toBe("QUESTION_LOOP");

    const topicPlan = begun.body.topic_plan as { topic: string; maxQuestions: number; source: string }[];
    expect(topicPlan.length).toBeGreaterThan(0);

    const askedTopics: string[] = [];
    const displayed: { questionId: string; text: string; answer: string }[] = [];

    // Run until the harness says the budget is spent.
    for (let turn = 0; turn < 20; turn += 1) {
      const next = await h.api
        .get(`/sessions/${sessionId}/questions/next`)
        .set(...bearer(token))
        .expect(200);

      if (next.body.done) break;

      const question = next.body.question as { id: string; text: string; topic: string };
      askedTopics.push(question.topic);

      const answered = await h.api
        .post(`/sessions/${sessionId}/answers`)
        .set(...bearer(token))
        .send({ question_id: question.id, transcript: STRONG_ANSWER })
        .expect(201);

      displayed.push({ questionId: question.id, text: question.text, answer: STRONG_ANSWER });

      expect(answered.body.evaluation).not.toBeNull();
      expect(answered.body.evaluation.score).toBeGreaterThan(0);
    }

    // Budget spent, and the harness moved the session on by itself.
    const session = await h.storage.sessions.get(sessionId);
    expect(session?.state).toBe("WRAP_UP");
    expect(askedTopics).toHaveLength(session!.questionBudget);

    // Topic balance: nothing exceeded its cap, and every question came from the plan.
    const planByTopic = new Map(topicPlan.map((e) => [e.topic, e.maxQuestions]));
    const counts = askedTopics.reduce<Record<string, number>>((acc, topic) => {
      acc[topic] = (acc[topic] ?? 0) + 1;
      return acc;
    }, {});

    for (const [topic, count] of Object.entries(counts)) {
      expect(planByTopic.has(topic), `${topic} was asked but is not in the topic plan`).toBe(true);
      expect(count, `${topic} exceeded its cap`).toBeLessThanOrEqual(planByTopic.get(topic)!);
    }
    // More than one topic: a balanced session, not a drill on one strength.
    expect(Object.keys(counts).length).toBeGreaterThan(1);

    // The stored transcript matches exactly what the frontend was shown.
    const transcript = await h.api
      .get(`/sessions/${sessionId}/transcript`)
      .set(...bearer(token))
      .expect(200);

    const stored = transcript.body.transcript as {
      question: { id: string; text: string };
      answer: { transcript: string } | null;
      evaluations: unknown[];
    }[];

    expect(stored).toHaveLength(displayed.length);
    stored.forEach((row, index) => {
      expect(row.question.id).toBe(displayed[index]!.questionId);
      expect(row.question.text).toBe(displayed[index]!.text);
      expect(row.answer?.transcript).toBe(displayed[index]!.answer);
      expect(row.evaluations.length).toBeGreaterThan(0);
    });
  });

  it("refuses to start without a topic plan", async () => {
    // No resume uploaded, but the role still has required topics, so this
    // session can start — the plan is built from role requirements alone.
    await configureAndCheck();
    const begun = await h.api.post(`/sessions/${sessionId}/begin`).set(...bearer(token)).expect(200);
    expect(begun.body.topic_plan.length).toBeGreaterThan(0);
    for (const entry of begun.body.topic_plan) {
      expect(entry.source).toBe("role_requirement");
    }
  });

  it("will not serve questions before the interview has begun", async () => {
    await h.api.get(`/sessions/${sessionId}/questions/next`).set(...bearer(token)).expect(409);
  });

  it("says plainly when an answer is too thin to score, instead of inventing one", async () => {
    await uploadResume();
    await configureAndCheck();
    await h.api.post(`/sessions/${sessionId}/begin`).set(...bearer(token)).expect(200);

    const next = await h.api.get(`/sessions/${sessionId}/questions/next`).set(...bearer(token)).expect(200);
    const answered = await h.api
      .post(`/sessions/${sessionId}/answers`)
      .set(...bearer(token))
      .send({ question_id: next.body.question.id, transcript: THIN_ANSWER })
      .expect(201);

    expect(answered.body.evaluation).toBeNull();
    expect(String(answered.body.evaluation_note)).toMatch(/too little to score/i);
    // And it still offers a way forward rather than just marking it down.
    expect(answered.body.follow_up).not.toBeNull();
  });

  it("asks a follow-up that targets something the candidate actually said", async () => {
    await uploadResume();
    await configureAndCheck();
    await h.api.post(`/sessions/${sessionId}/begin`).set(...bearer(token)).expect(200);

    const next = await h.api.get(`/sessions/${sessionId}/questions/next`).set(...bearer(token)).expect(200);
    const answered = await h.api
      .post(`/sessions/${sessionId}/answers`)
      .set(...bearer(token))
      .send({
        question_id: next.body.question.id,
        transcript:
          "We moved the whole billing system onto a new queue and it went much better afterwards.",
      })
      .expect(201);

    const followUp = answered.body.follow_up as { text: string; reason: string };
    expect(followUp).not.toBeNull();
    expect(followUp.reason.length).toBeGreaterThan(0);
    // Not a generic "tell me more" (§4.4).
    expect(followUp.text.toLowerCase()).not.toBe("tell me more.");
    expect(followUp.text.length).toBeGreaterThan(20);

    // The reply is recorded against the answer it belongs to.
    await h.api
      .post(`/sessions/${sessionId}/answers/${answered.body.answer_id}/follow-up`)
      .set(...bearer(token))
      .send({ follow_up_text: followUp.text, transcript: "I owned the migration end to end." })
      .expect(201);

    const stored = await h.storage.answers.get(answered.body.answer_id);
    expect(stored?.followUps).toHaveLength(1);
  });

  it("logs a quota override rather than over-drilling one topic silently", async () => {
    await uploadResume();
    await configureAndCheck();
    await h.api.post(`/sessions/${sessionId}/begin`).set(...bearer(token)).expect(200);

    // Shrink the plan to one topic with a cap of 1 while leaving the budget at
    // 8: after the first question every topic is capped, so the next one can
    // only come from an override.
    await h.storage.sessions.patch(sessionId, {
      topicPlan: [{ topic: "databases", maxQuestions: 1, source: "resume" }],
    });

    const first = await h.api.get(`/sessions/${sessionId}/questions/next`).set(...bearer(token)).expect(200);
    await h.api
      .post(`/sessions/${sessionId}/answers`)
      .set(...bearer(token))
      .send({ question_id: first.body.question.id, transcript: STRONG_ANSWER })
      .expect(201);

    await h.api.get(`/sessions/${sessionId}/questions/next`).set(...bearer(token)).expect(200);

    const questions = await h.storage.questions.listBySession(sessionId);
    expect(questions[1]?.quotaOverride).toBe(true);

    const events = await h.storage.telemetry.recent(500);
    const override = events.find((e) => e.eventType === "quota_override_used");
    expect(override, "a quota override must be logged, never silent").toBeDefined();
    expect(override!.payload.topic).toBe("databases");
    expect(String(override!.payload.reason)).toMatch(/cap/i);
  });
});

describe("session-scoped memory", () => {
  it("derives topic counts from what was actually asked", async () => {
    await uploadResume();
    await configureAndCheck();
    await h.api.post(`/sessions/${sessionId}/begin`).set(...bearer(token)).expect(200);

    const first = await h.api.get(`/sessions/${sessionId}/questions/next`).set(...bearer(token)).expect(200);
    const topic = first.body.question.topic as string;

    const sessionToken = await h.storage.live.getSessionToken(sessionId);
    const context = await h.mcp.call<{
      session_context: { topic_counts: Record<string, number>; questions_asked: number };
    }>("memory-agent", "get_session_context", { session_id: sessionId }, {
      sessionId,
      caller: "harness-agent",
      sessionToken: sessionToken!,
    });

    expect(context.ok).toBe(true);
    expect(context.data!.session_context.topic_counts[topic]).toBe(1);
    expect(context.data!.session_context.questions_asked).toBe(1);
  });

  it("returns nothing at all across sessions without account-level opt-in", async () => {
    const sessionToken = await h.storage.live.getSessionToken(sessionId);
    const candidate = await h.storage.users.findByEmail(STUDENT.email);

    const prior = await h.mcp.call<{ opted_in: boolean; previously_asked_question_ids?: string[] }>(
      "memory-agent",
      "get_prior_context",
      { candidate_id: candidate!.id },
      { sessionId, caller: "harness-agent", sessionToken: sessionToken! },
    );

    expect(prior.ok).toBe(true);
    expect(prior.data!.opted_in).toBe(false);
    expect(prior.data!.previously_asked_question_ids).toBeUndefined();
  });
});

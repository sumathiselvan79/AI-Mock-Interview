/**
 * TRACKING.md Stage 5 — gate tests 4, 5, 6 and 7, plus the two invariants the
 * stage's soul.md additions turn on.
 *
 * 4. Follow-up scoring: an `Evaluation` exists for the primary answer
 *    immediately (not only after REPORT_GENERATION), and `follow_ups[0]`
 *    carries its own score whose `evidence_spans` index into the FOLLOW-UP's
 *    transcript rather than the original answer's.
 * 5. Stateless reducer: the same request+context against two separately
 *    instantiated agent processes — one fresh, one that has already served
 *    other sessions — produces byte-identical output; and the lint rule fails
 *    on a fixture with module-scope mutable state.
 * 6. Archive ordering: exactly one archive row per session, and its
 *    `document.answers[].transcript` is redacted whenever the primary record's
 *    was — the archive is never more permissive than the primary at write time.
 * 7. Archive RBAC: a student token gets 403 on both archive routes, and
 *    `archive_downloaded` fires with a sanitized payload on a successful admin
 *    download.
 *
 * Plus:
 *  - the reference answer never escapes the Memory Agent (soul.md §5);
 *  - a session that completes with archiving unconfigured still completes.
 */

import { describe, expect, it, afterEach } from "vitest";
import { REDACTED_TRANSCRIPT } from "@mia/shared-types";
import { checkSource } from "@mia/agent-lint";
import { createQuestionAgentServer } from "@mia/question-agent";
import { createFollowupAgentServer } from "@mia/followup-agent";
import { BACKEND_JOB_DESCRIPTION, SENIOR_BACKEND_TXT, encoder } from "./fixtures/resumes.js";
import { ADMIN, STUDENT, bearer, buildHarness, loginToken, seedUsers, type TestHarness } from "./helpers.js";

const STRONG_ANSWER = `At my last company we had a settlement service that was timing out under load.
I profiled the hot path and found we were doing a synchronous write to Postgres inside the request.
I moved that write onto a queue and added an idempotency key so retries could not double-charge anyone.
We chose the queue rather than a bigger database instance because the write was not read back immediately,
and the tradeoff was that reconciliation became eventually consistent, which finance signed off on.
As a result p99 latency went from 900ms to 210ms and the on-call pages for that service stopped.`;

/**
 * Deliberately incomplete: it describes what the candidate did but never how it
 * turned out, which is the gap the Stage-2 detector probes for. STRONG_ANSWER
 * above covers action, outcome, metric AND reasoning, so it correctly draws no
 * follow-up at all — which makes it the wrong fixture for this test.
 */
const GAPPED_ANSWER = `I rewrote the ingestion pipeline last year and I added a retry queue in front of it.
I moved the deduplication into the consumer and I changed the batch size so the workers were not idle between polls.`;

const FOLLOW_UP_ANSWER = `The idempotency key was a hash of the settlement id and the attempt window.
I stored it in Redis with a short expiry, and the consumer checked it before writing anything to Postgres.
That meant a retried message was a no-op rather than a second charge, which was the failure we were most worried about.`;

const harnesses: TestHarness[] = [];

async function harness(): Promise<TestHarness> {
  const h = await buildHarness();
  harnesses.push(h);
  return h;
}

afterEach(async () => {
  while (harnesses.length > 0) await harnesses.pop()!.close();
});

/** A student session configured, consented, and ready to begin. */
async function studentSession(
  h: TestHarness,
  opts: { consentAudioRecording?: boolean; fullName?: string | null } = {},
): Promise<{ token: string; sessionId: string; candidateId: string }> {
  const token = await loginToken(h, STUDENT);
  const me = await h.storage.users.findByEmail(STUDENT.email);

  // Archiving requires a full name (§11.4 step 2); `fullName: null` is how a
  // test asks for the refusal path.
  if (opts.fullName !== null) {
    await h.storage.users.updateProfile(me!.id, {
      fullName: opts.fullName ?? "Priya Raman",
      department: "Computer Science",
      programYear: "3rd Year",
    });
  }

  const created = await h.api
    .post("/sessions")
    .set(...bearer(token))
    .send({ role: "Senior Backend Engineer", job_description: BACKEND_JOB_DESCRIPTION })
    .expect(201);
  const sessionId = created.body.session_id as string;

  await h.api
    .post(`/sessions/${sessionId}/resume`)
    .set(...bearer(token))
    .send({
      filename: "resume.txt",
      content_type: "text/plain",
      data_base64: Buffer.from(encoder.encode(SENIOR_BACKEND_TXT)).toString("base64"),
    })
    .expect(201);

  await h.api.post(`/sessions/${sessionId}/advance`).set(...bearer(token)).send({ to: "CONFIG" }).expect(200);
  await h.api
    .post(`/sessions/${sessionId}/advance`)
    .set(...bearer(token))
    .send({ to: "TELEMETRY_CHECK" })
    .expect(200);
  await h.api
    .post(`/sessions/${sessionId}/telemetry-check`)
    .set(...bearer(token))
    .send({
      mic_ok: true,
      speaker_ok: true,
      consent: { telemetry: true, audio_recording: opts.consentAudioRecording === true },
    })
    .expect(200);

  return { token, sessionId, candidateId: me!.id };
}

async function runFullInterview(h: TestHarness, token: string, sessionId: string): Promise<void> {
  await h.api.post(`/sessions/${sessionId}/begin`).set(...bearer(token)).expect(200);
  for (let turn = 0; turn < 20; turn += 1) {
    const next = await h.api.get(`/sessions/${sessionId}/questions/next`).set(...bearer(token)).expect(200);
    if (next.body.done) break;
    await h.api
      .post(`/sessions/${sessionId}/answers`)
      .set(...bearer(token))
      .send({ question_id: next.body.question.id, transcript: STRONG_ANSWER })
      .expect(201);
  }
}

async function completeSession(h: TestHarness, token: string, sessionId: string): Promise<void> {
  await h.api.post(`/sessions/${sessionId}/wrap-up`).set(...bearer(token)).expect(200);
  await h.api.post(`/sessions/${sessionId}/report`).set(...bearer(token)).expect(201);
}

// ---------------------------------------------------------------------------

describe("gate test 4 — follow-up scoring", () => {
  it("persists an Evaluation for the primary answer at follow-up time, not at report time", async () => {
    const h = await harness();
    await seedUsers(h);
    const { token, sessionId } = await studentSession(h);

    await h.api.post(`/sessions/${sessionId}/begin`).set(...bearer(token)).expect(200);
    const next = await h.api.get(`/sessions/${sessionId}/questions/next`).set(...bearer(token)).expect(200);

    const answered = await h.api
      .post(`/sessions/${sessionId}/answers`)
      .set(...bearer(token))
      .send({ question_id: next.body.question.id, transcript: STRONG_ANSWER })
      .expect(201);

    // The session is nowhere near REPORT_GENERATION and the score is already
    // on record — which is the point: a dropped session keeps its scores
    // (§11.2).
    const evaluations = await h.storage.evaluations.listByAnswer(answered.body.answer_id);
    expect(evaluations).toHaveLength(1);
    expect(evaluations[0]?.score).toBeGreaterThan(0);
    expect(evaluations[0]?.evidenceSpans.length).toBeGreaterThan(0);

    const session = await h.storage.sessions.get(sessionId);
    expect(session?.state).toBe("QUESTION_LOOP");
  });

  it("scores an answered follow-up onto that follow-up, with spans into its own transcript", async () => {
    const h = await harness();
    await seedUsers(h);
    const { token, sessionId } = await studentSession(h);

    await h.api.post(`/sessions/${sessionId}/begin`).set(...bearer(token)).expect(200);
    const next = await h.api.get(`/sessions/${sessionId}/questions/next`).set(...bearer(token)).expect(200);
    const answered = await h.api
      .post(`/sessions/${sessionId}/answers`)
      .set(...bearer(token))
      .send({ question_id: next.body.question.id, transcript: GAPPED_ANSWER })
      .expect(201);

    expect(answered.body.follow_up).not.toBeNull();

    await h.api
      .post(`/sessions/${sessionId}/answers/${answered.body.answer_id}/follow-up`)
      .set(...bearer(token))
      .send({ follow_up_text: answered.body.follow_up.text, transcript: FOLLOW_UP_ANSWER })
      .expect(201);

    const answer = await h.storage.answers.get(answered.body.answer_id);
    const followUp = answer!.followUps[0]!;

    expect(followUp.score).toBeDefined();
    expect(followUp.score!.value).toBeGreaterThanOrEqual(0);
    expect(followUp.score!.rationale.length).toBeGreaterThan(0);

    // The spans index into THIS follow-up's transcript, not the answer's
    // (§11.7). Both assertions matter: in range for the follow-up, and the
    // slice has to read as part of what was actually said in it.
    for (const span of followUp.score!.evidenceSpans) {
      expect(span.end).toBeLessThanOrEqual(FOLLOW_UP_ANSWER.length);
      expect(span.start).toBeLessThan(span.end);
      const quoted = FOLLOW_UP_ANSWER.slice(span.start, span.end);
      expect(quoted.trim().length).toBeGreaterThan(0);
    }

    // And no second top-level Evaluation was created for the exchange: the
    // answer still has exactly the one from its primary transcript.
    const evaluations = await h.storage.evaluations.listByAnswer(answered.body.answer_id);
    expect(evaluations).toHaveLength(1);
  });
});

describe("gate test 5 — stateless reducers", () => {
  it("gives byte-identical output from a fresh agent and one that already served other sessions", async () => {
    const request = {
      session_id: "session-under-test",
      role: "Senior Backend Engineer",
      topic_plan: [
        { topic: "distributed systems", max_questions: 3, source: "resume" as const },
        { topic: "system design", max_questions: 2, source: "role_requirement" as const },
      ],
      topic_counts: { "distributed systems": 1 },
      asked_question_ids: ["ds-1"],
      recent_scores: [3.2, 4.1],
    };

    // One agent instance that has already handled a different session's
    // traffic, and one constructed just now. A per-session cache or an
    // accumulator inside the agent would show up as a difference here.
    const warm = createQuestionAgentServer();
    await warm.call(
      "get_next_question",
      { ...request, session_id: "some-other-session", topic_counts: { "system design": 2 } },
      { sessionId: "some-other-session", caller: "harness-agent", sessionToken: "" },
    );
    await warm.call("build_topic_plan", { role: "Junior Frontend Engineer", question_budget: 6 }, {
      sessionId: "another-session",
      caller: "harness-agent",
      sessionToken: "",
    });

    const fresh = createQuestionAgentServer();
    const ctx = { sessionId: request.session_id, caller: "harness-agent", sessionToken: "" };

    const fromWarm = (await warm.call("get_next_question", request, ctx)) as {
      question: Record<string, unknown>;
    };
    const fromFresh = (await fresh.call("get_next_question", request, ctx)) as {
      question: Record<string, unknown>;
    };

    // `id` is a fresh uuid per asking by design (§4.3), so it is excluded —
    // everything the caller actually reasons about must match.
    const { id: _warmId, ...warmQuestion } = fromWarm.question;
    const { id: _freshId, ...freshQuestion } = fromFresh.question;
    expect(JSON.stringify(warmQuestion)).toBe(JSON.stringify(freshQuestion));
  });

  it("is also stateless for the Follow-up Agent across separately instantiated processes", async () => {
    const request = {
      question: "Tell me about a time you improved a system's reliability.",
      answer_transcript: STRONG_ANSWER,
    };
    const ctx = { sessionId: "s1", caller: "harness-agent", sessionToken: "" };

    const warm = createFollowupAgentServer();
    await warm.call("consider_follow_up", { question: "something else", answer_transcript: "a different answer entirely" }, ctx);

    const fresh = createFollowupAgentServer();
    expect(JSON.stringify(await warm.call("consider_follow_up", request, ctx))).toBe(
      JSON.stringify(await fresh.call("consider_follow_up", request, ctx)),
    );
  });

  it("fails the lint rule on an agent file with module-scope mutable state", () => {
    // The fixture is the thing the contract actually forbids: a cache keyed by
    // session id, and a counter, both living between calls (§11.1).
    const offending = `
      const seenSessions = new Map<string, number>();
      let callCount = 0;
      export function handle(sessionId: string) {
        callCount += 1;
        seenSessions.set(sessionId, callCount);
        return callCount;
      }
    `;
    const violations = checkSource("agents/fixture-agent/src/index.ts", offending);

    expect(violations).toHaveLength(2);
    expect(violations.map((v) => v.name).sort()).toEqual(["callCount", "seenSessions"]);
    expect(violations.find((v) => v.name === "seenSessions")?.reason).toMatch(/Memory Agent/);
  });

  it("accepts the immutable module-scope constants a stateless agent legitimately has", () => {
    const fine = `
      const RUBRIC_FOR_TYPE: Readonly<Record<string, string>> = { behavioral: "behavioral_v1" };
      const GAPS: readonly string[] = ["no_outcome"];
      const PATTERN = /\\bwe\\b/i;
      const FROZEN = Object.freeze({ a: 1 });
      export function handle() { return GAPS.length + Object.keys(RUBRIC_FOR_TYPE).length; }
    `;
    expect(checkSource("agents/fixture-agent/src/ok.ts", fine)).toEqual([]);
  });
});

describe("gate test 6 — archive ordering", () => {
  it("writes exactly one archive row, compiled after redaction so it is never more permissive", async () => {
    const h = await harness();
    await seedUsers(h);
    const { token, sessionId, candidateId } = await studentSession(h);

    await runFullInterview(h, token, sessionId);
    await completeSession(h, token, sessionId);

    const archive = await h.storage.archives!.get(sessionId);
    expect(archive).not.toBeNull();
    expect(archive!.candidateName).toBe("Priya Raman");
    expect(archive!.department).toBe("Computer Science");
    expect(archive!.candidateId).toBe(candidateId);

    // Exactly one row for the session.
    const all = await h.storage.archives!.list();
    expect(all.filter((a) => a.sessionId === sessionId)).toHaveLength(1);

    // This candidate did NOT opt into retention, so the primary transcripts are
    // redacted — and the archive, compiled afterwards, carries the redaction
    // rather than the original words (soul.md §5 Stage 5 guardrail).
    const questions = await h.storage.questions.listBySession(sessionId);
    expect(questions.length).toBeGreaterThan(0);
    for (const question of questions) {
      const primary = await h.storage.answers.getByQuestion(question.id);
      if (!primary) continue;
      expect(primary.transcript).toBe(REDACTED_TRANSCRIPT);

      const archived = archive!.document.answers.find((a) => a.id === primary.id);
      expect(archived, "every answered question should appear in the archive").toBeDefined();
      expect(archived!.transcript).toBe(REDACTED_TRANSCRIPT);
    }

    // The report and the evaluations survive — §8 purges the candidate's own
    // words, not the assessment of them.
    expect(archive!.document.report.competencyScores.length).toBeGreaterThan(0);
    expect(archive!.document.evaluations.length).toBeGreaterThan(0);
    expect(archive!.document.questions.length).toBe(questions.length);
  });

  it("keeps the full transcript in the archive when the candidate opted into retention", async () => {
    const h = await harness();
    await seedUsers(h);
    const { token, sessionId } = await studentSession(h, { consentAudioRecording: true });

    await runFullInterview(h, token, sessionId);
    await completeSession(h, token, sessionId);

    const archive = await h.storage.archives!.get(sessionId);
    expect(archive!.document.answers.length).toBeGreaterThan(0);
    for (const answer of archive!.document.answers) {
      expect(answer.transcript).toBe(STRONG_ANSWER);
    }
  });

  it("refuses to archive rather than filing a session under a blank name", async () => {
    const h = await harness();
    await seedUsers(h);
    const { token, sessionId } = await studentSession(h, { fullName: null });

    await runFullInterview(h, token, sessionId);
    // The session still completes normally for the candidate — archiving never
    // blocks REPORT_GENERATION -> COMPLETED (§11.4 step 4).
    await completeSession(h, token, sessionId);

    expect(await h.storage.archives!.get(sessionId)).toBeNull();
    expect((await h.storage.sessions.get(sessionId))?.state).toBe("COMPLETED");

    const failures = (await h.storage.telemetry.recent(200)).filter(
      (e) => e.eventType === "session_archive_failed" && e.sessionId === sessionId,
    );
    expect(failures).toHaveLength(1);
    expect(String(failures[0]?.payload.reason)).toBe("archive_refused");
  });
});

describe("gate test 7 — archive RBAC and audit", () => {
  it("gives a student token 403 on both archive routes", async () => {
    const h = await harness();
    await seedUsers(h);
    const { token, sessionId } = await studentSession(h);
    await runFullInterview(h, token, sessionId);
    await completeSession(h, token, sessionId);

    await h.api.get(`/admin/archives/${sessionId}`).set(...bearer(token)).expect(403);
    await h.api.get(`/admin/archives/${sessionId}/download`).set(...bearer(token)).expect(403);
  });

  it("lets an admin download it, and audits the read with a sanitized payload", async () => {
    const h = await harness();
    await seedUsers(h);
    const { token, sessionId } = await studentSession(h);
    await runFullInterview(h, token, sessionId);
    await completeSession(h, token, sessionId);

    const adminToken = await loginToken(h, ADMIN);

    // The metadata view carries no document body — a listing must not become an
    // unaudited way to read transcripts (§7).
    const summary = await h.api.get(`/admin/archives/${sessionId}`).set(...bearer(adminToken)).expect(200);
    expect(summary.body.archive.candidateName).toBe("Priya Raman");
    expect(summary.body.archive.document).toBeUndefined();

    const download = await h.api
      .get(`/admin/archives/${sessionId}/download`)
      .set(...bearer(adminToken))
      .expect(200);
    expect(download.headers["content-disposition"]).toContain(`session-${sessionId}.json`);
    expect(download.body.report).toBeDefined();
    expect(download.body.questions.length).toBeGreaterThan(0);

    const downloads = (await h.storage.telemetry.recent(200)).filter(
      (e) => e.eventType === "archive_downloaded" && e.sessionId === sessionId,
    );
    expect(downloads).toHaveLength(1);

    // Sanitized: ids, counts and timestamps only. No transcript, no resume, and
    // nothing free-form that could carry either (§8).
    const payload = downloads[0]!.payload;
    expect(Object.keys(payload).sort()).toEqual([
      "admin_id",
      "answers",
      "archived_at",
      "candidate_id",
      "questions",
    ]);
    const serialized = JSON.stringify(payload);
    expect(serialized).not.toContain("settlement service");
    expect(serialized).not.toContain(REDACTED_TRANSCRIPT);
  });
});

describe("the reference answer never leaves the Memory Agent", () => {
  it("is absent from the question the candidate is served, from storage, and from the transcript", async () => {
    const h = await harness();
    await seedUsers(h);
    const { token, sessionId } = await studentSession(h);

    await h.api.post(`/sessions/${sessionId}/begin`).set(...bearer(token)).expect(200);
    const next = await h.api.get(`/sessions/${sessionId}/questions/next`).set(...bearer(token)).expect(200);
    const questionId = next.body.question.id as string;

    // It exists — the Question Agent generated one and the harness parked it.
    const remembered = await h.storage.live.getSessionScratch<string>(
      sessionId,
      `reference-answer:${questionId}`,
    );
    expect(remembered).toBeTruthy();
    expect(remembered!.length).toBeGreaterThan(40);

    // ...and it is nowhere the candidate or an Admin can reach it (soul.md §5).
    expect(JSON.stringify(next.body)).not.toContain(remembered);

    const stored = await h.storage.questions.get(questionId);
    expect(JSON.stringify(stored)).not.toContain(remembered);
    expect((stored as unknown as Record<string, unknown>).referenceAnswer).toBeUndefined();

    await h.api
      .post(`/sessions/${sessionId}/answers`)
      .set(...bearer(token))
      .send({ question_id: questionId, transcript: STRONG_ANSWER })
      .expect(201);

    const transcript = await h.api.get(`/sessions/${sessionId}/transcript`).set(...bearer(token)).expect(200);
    expect(JSON.stringify(transcript.body)).not.toContain(remembered);
  });

  it("is dropped once the session is COMPLETED", async () => {
    const h = await harness();
    await seedUsers(h);
    const { token, sessionId } = await studentSession(h);

    await runFullInterview(h, token, sessionId);
    const questions = await h.storage.questions.listBySession(sessionId);
    expect(
      await h.storage.live.getSessionScratch(sessionId, `reference-answer:${questions[0]!.id}`),
    ).toBeTruthy();

    await completeSession(h, token, sessionId);

    for (const question of questions) {
      expect(
        await h.storage.live.getSessionScratch(sessionId, `reference-answer:${question.id}`),
      ).toBeNull();
    }
  });
});

describe("the LLM-backed Resume Service Agent", () => {
  it("adds a grounded rationale and JD-anchored topic relevance, stamped with a prompt version", async () => {
    const h = await harness();
    await seedUsers(h);
    const { token, sessionId } = await studentSession(h);

    const jdFit = await h.api.get(`/sessions/${sessionId}/jd-fit`).set(...bearer(token)).expect(200);
    const fit = jdFit.body.jd_fit as {
      rationale?: string;
      topic_relevance?: { topic: string; evidence: string }[];
      prompt_version?: string;
      matched_requirements: string[];
      gaps: string[];
    };

    expect(fit.prompt_version).toBe("resume-service-agent/v1");
    expect(fit.rationale).toBeTruthy();

    // Every JD-anchored evidence string traces to the job description
    // verbatim — the same mechanical check the rest of this repo uses for
    // "no fabrication" (soul.md §"Grounding is checked, not assumed").
    const normalizedJd = BACKEND_JOB_DESCRIPTION.replace(/\s+/g, " ").trim();
    for (const entry of fit.topic_relevance ?? []) {
      expect(
        normalizedJd.includes(entry.evidence.replace(/\s+/g, " ").trim()),
        `JD-anchored evidence for "${entry.topic}" is not verbatim from the job description`,
      ).toBe(true);
    }

    // The deterministic fields are untouched by the enrichment.
    expect(Array.isArray(fit.matched_requirements)).toBe(true);
    expect(Array.isArray(fit.gaps)).toBe(true);
  });
});

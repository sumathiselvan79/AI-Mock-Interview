/**
 * TRACKING.md Stage 3, gate tests 5-7:
 *
 * 5. Starting the Clipboard Monitor with no `consent_token` must be rejected at
 *    the tool layer, even with the UI bypassed.
 * 6. A paste event during the coding round stores a boolean and a timestamp —
 *    never the pasted content.
 * 7. Sandbox escape: code attempting filesystem or network access is blocked and
 *    does not affect the Coding Agent process.
 */

import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { runInSandbox } from "@mia/coding-agent";
import { STUDENT, bearer, buildHarness, loginToken, seedUsers, type TestHarness } from "./helpers.js";

let h: TestHarness;
let token: string;
let sessionId: string;
let sessionToken: string;

beforeAll(async () => {
  h = await buildHarness();
  await seedUsers(h);
  token = await loginToken(h, STUDENT);

  const created = await h.api
    .post("/sessions")
    .set(...bearer(token))
    .send({ role: "Senior Backend Engineer" })
    .expect(201);
  sessionId = created.body.session_id;
  sessionToken = created.body.session_token;
});

afterAll(async () => {
  await h.close();
});

const harnessCtx = () => ({ sessionId, caller: "harness-agent", sessionToken });

/** Runs one submission against the sandbox directly. */
async function run(code: string, expected: unknown = "__never__") {
  return runInSandbox({
    code,
    entryPoint: "solve",
    testCases: [{ name: "attempt", args: [], expected }],
    timeoutMs: 5000,
  });
}

describe("gate test 5 — consent is enforced at the tool layer", () => {
  it("refuses to start monitoring with no consent token, bypassing the UI entirely", async () => {
    // This is a direct MCP call: no page, no form, no consent checkbox.
    const result = await h.mcp.call(
      "tool-clipboard-monitor",
      "start_monitor",
      { session_id: sessionId },
      harnessCtx(),
    );

    expect(result.ok).toBe(false);
    // The schema requires consent_token, so the call is refused before the tool
    // is even reached — the outermost of the two gates.
    expect(result.error?.code).toBe("schema_invalid_request");
  });

  it("refuses an empty, forged, or wrong-session consent token", async () => {
    const empty = await h.mcp.call(
      "tool-clipboard-monitor",
      "start_monitor",
      { session_id: sessionId, consent_token: "" },
      harnessCtx(),
    );
    expect(empty.ok).toBe(false);

    const forged = await h.mcp.call(
      "tool-clipboard-monitor",
      "start_monitor",
      { session_id: sessionId, consent_token: "eyJmYWtlIjp0cnVlfQ.not-a-real-signature" },
      harnessCtx(),
    );
    expect(forged.ok).toBe(false);
    expect(forged.error?.code).toBe("consent_invalid");
  });

  it("discards a paste event when no consented monitor is running", async () => {
    const result = await h.mcp.call(
      "tool-clipboard-monitor",
      "paste_event_detected",
      { session_id: sessionId, detected: true, timestamp: new Date().toISOString() },
      harnessCtx(),
    );

    expect(result.ok).toBe(false);
    expect(result.error?.code).toBe("consent_missing");
  });

  it("does not start monitoring for a candidate who declined it", async () => {
    await h.api
      .post(`/sessions/${sessionId}/advance`)
      .set(...bearer(token))
      .send({ to: "CONFIG" })
      .expect(200);
    await h.api
      .post(`/sessions/${sessionId}/advance`)
      .set(...bearer(token))
      .send({ to: "TELEMETRY_CHECK" })
      .expect(200);

    // Device check passes, but clipboard monitoring is declined.
    await h.api
      .post(`/sessions/${sessionId}/telemetry-check`)
      .set(...bearer(token))
      .send({ mic_ok: true, speaker_ok: true, consent: { telemetry: true, clipboard_monitor: false } })
      .expect(200);

    await h.api.post(`/sessions/${sessionId}/begin`).set(...bearer(token)).expect(200);
    const round = await h.api.post(`/sessions/${sessionId}/coding-round`).set(...bearer(token)).expect(201);

    // The round runs; it is simply not monitored (soul.md §"Consent-first").
    expect(round.body.clipboard_monitoring).toBe(false);
    expect(round.body.problem.statement.length).toBeGreaterThan(0);
  });
});

describe("gate test 6 — a paste event stores a boolean and a timestamp only", () => {
  let consentedSession: string;
  let consented: TestHarness;
  let consentedToken: string;

  beforeAll(async () => {
    consented = await buildHarness();
    await seedUsers(consented);
    consentedToken = await loginToken(consented, STUDENT);

    const created = await consented.api
      .post("/sessions")
      .set(...bearer(consentedToken))
      .send({ role: "Senior Backend Engineer" })
      .expect(201);
    consentedSession = created.body.session_id;

    for (const to of ["CONFIG", "TELEMETRY_CHECK"]) {
      await consented.api
        .post(`/sessions/${consentedSession}/advance`)
        .set(...bearer(consentedToken))
        .send({ to })
        .expect(200);
    }
    // This candidate DID consent to clipboard monitoring.
    await consented.api
      .post(`/sessions/${consentedSession}/telemetry-check`)
      .set(...bearer(consentedToken))
      .send({ mic_ok: true, speaker_ok: true, consent: { telemetry: true, clipboard_monitor: true } })
      .expect(200);
    await consented.api.post(`/sessions/${consentedSession}/begin`).set(...bearer(consentedToken)).expect(200);
  });

  afterAll(async () => {
    await consented.close();
  });

  it("starts monitoring for a consenting candidate", async () => {
    const round = await consented.api
      .post(`/sessions/${consentedSession}/coding-round`)
      .set(...bearer(consentedToken))
      .expect(201);
    expect(round.body.clipboard_monitoring).toBe(true);
  });

  it("records the event without the pasted content — which has no field to travel in", async () => {
    const at = new Date().toISOString();

    // The API accepts a timestamp. There is no content parameter, so a client
    // cannot send the pasted text even deliberately.
    const response = await consented.api
      .post(`/sessions/${consentedSession}/paste-events`)
      .set(...bearer(consentedToken))
      .send({ timestamp: at, content: "SECRET-PASTED-ANSWER-TEXT" })
      .expect(201);

    expect(response.body.recorded).toBe(true);

    // Inspect the stored record directly, as the gate asks.
    const events = await consented.storage.telemetry.recent(300);
    const paste = events.filter((e) => e.eventType === "paste_detected");
    expect(paste.length).toBeGreaterThan(0);

    const stored = paste.at(-1)!;
    expect(stored.payload.detected).toBe(true);
    expect(stored.payload.at).toBe(at);
    expect(Object.keys(stored.payload).sort()).toEqual(["at", "detected"]);

    // Nothing anywhere carries the content.
    expect(JSON.stringify(events)).not.toContain("SECRET-PASTED-ANSWER-TEXT");
    expect(consented.logs.history().join("\n")).not.toContain("SECRET-PASTED-ANSWER-TEXT");
  });
});

describe("gate test 7 — sandbox escape attempts", () => {
  it("runs a correct solution and reports the passing cases", async () => {
    const outcome = await runInSandbox({
      code: "function solve(a, b) { return a + b; }",
      entryPoint: "solve",
      testCases: [
        { name: "basic", args: [1, 2], expected: 3 },
        { name: "negative", args: [-1, 1], expected: 0 },
      ],
    });

    expect(outcome.ok).toBe(true);
    expect(outcome.results.every((r) => r.passed)).toBe(true);
  });

  it("blocks filesystem access", async () => {
    const viaRequire = await run("function solve(){ return require('node:fs').readdirSync('.').length; }");
    expect(viaRequire.results[0]!.passed).toBe(false);
    expect(viaRequire.results[0]!.error).toBeDefined();

    // Even after escaping the vm context — which Node documents as possible —
    // the permission model still denies the filesystem binding.
    const viaEscape = await run(
      "function solve(){ const p = Object.constructor('return process')(); try { p.binding('fs'); return 'REACHED FS'; } catch (e) { return 'blocked:' + e.code; } }",
      "REACHED FS",
    );
    expect(viaEscape.results[0]!.passed).toBe(false);
    expect(viaEscape.results[0]!.actual).toContain("blocked:ERR_ACCESS_DENIED");
  });

  it("blocks network access", async () => {
    const viaFetch = await run("function solve(){ return typeof fetch; }", "function");
    expect(viaFetch.results[0]!.passed).toBe(false);

    const viaRequire = await run("function solve(){ return typeof require('node:net').connect; }", "function");
    expect(viaRequire.results[0]!.passed).toBe(false);

    const viaEscape = await run(
      "function solve(){ const p = Object.constructor('return process')(); try { p.mainModule.require('node:https'); return 'REACHED NET'; } catch (e) { return 'blocked:' + (e.code || e.message); } }",
      "REACHED NET",
    );
    expect(viaEscape.results[0]!.actual).toContain("blocked:");
  });

  it("blocks spawning processes", async () => {
    const viaEscape = await run(
      "function solve(){ const p = Object.constructor('return process')(); try { p.mainModule.require('node:child_process').execSync('echo pwned'); return 'SPAWNED'; } catch (e) { return 'blocked:' + (e.code || e.message); } }",
      "SPAWNED",
    );
    expect(viaEscape.results[0]!.passed).toBe(false);
    expect(viaEscape.results[0]!.actual).toContain("blocked:");
  });

  it("does not leak the agent's environment to candidate code", async () => {
    const outcome = await run(
      "function solve(){ const p = Object.constructor('return process')(); return Object.keys(p.env).join(','); }",
    );
    const env = String(outcome.results[0]!.actual ?? "");

    // Only OS-level variables survive; nothing the gateway was configured with.
    for (const secret of ["AUTH_TOKEN_SECRET", "DATABASE_URL", "REDIS_URL", "SEED_"]) {
      expect(env).not.toContain(secret);
    }
  });

  it("kills an infinite loop instead of hanging the agent", async () => {
    const outcome = await runInSandbox({
      code: "function solve(){ while (true) {} }",
      entryPoint: "solve",
      testCases: [{ name: "loop", args: [], expected: 1 }],
      timeoutMs: 4000,
    });

    expect(outcome.results[0]!.passed).toBe(false);
    expect(outcome.results[0]!.error?.type).toBe("timeout");
    // INSTRUCTIONS.md §9: sandboxed execution stays under 5s.
    expect(outcome.elapsedMs).toBeLessThan(5000);
  });

  it("survives code that throws, and keeps the agent process running", async () => {
    const outcome = await run("function solve(){ throw new Error('candidate error'); }");
    expect(outcome.results[0]!.error?.message).toContain("candidate error");

    // The agent is unharmed: the next run still works.
    const after = await runInSandbox({
      code: "function solve(){ return 42; }",
      entryPoint: "solve",
      testCases: [{ name: "after", args: [], expected: 42 }],
    });
    expect(after.results[0]!.passed).toBe(true);
  });

  it("reports a missing entry point rather than passing vacuously", async () => {
    const outcome = await runInSandbox({
      code: "const notTheFunction = 1;",
      entryPoint: "solve",
      testCases: [{ name: "x", args: [], expected: 1 }],
    });
    expect(outcome.ok).toBe(false);
    expect(outcome.error?.type).toBe("no_entry_point");
  });
});

describe("the coding round end to end", () => {
  it("runs hidden cases, so passing the examples is not enough", async () => {
    const cheating = await h.api
      .post(`/sessions/${sessionId}/coding-round/submissions`)
      .set(...bearer(token))
      .send({
        // Hard-codes the visible examples only.
        code: "function allow(events, limit, windowMs){ if (events.length === 2) return [true, true]; return [true, true, false]; }",
        talk_through: "I return the answers the examples expect.",
      })
      .expect(201);

    expect(cheating.body.passed).toBeLessThan(cheating.body.total);
  });

  it("scores the talk-through and the tests together", async () => {
    const honest = await h.api
      .post(`/sessions/${sessionId}/coding-round/submissions`)
      .set(...bearer(token))
      .send({
        code: `function allow(events, limit, windowMs) {
          const out = []; let windowStart = null; let count = 0;
          for (const t of events) {
            if (windowStart === null || t - windowStart >= windowMs) { windowStart = t; count = 0; }
            if (count < limit) { count += 1; out.push(true); } else { out.push(false); }
          }
          return out;
        }`,
        talk_through:
          "I track the window start and a count, because a fixed window only needs one counter rather than storing every timestamp. The edge case is the boundary, where the window resets exactly at windowMs.",
      })
      .expect(201);

    expect(honest.body.passed).toBe(honest.body.total);
    expect(honest.body.evaluation).not.toBeNull();
    expect(honest.body.evaluation.score).toBeGreaterThan(0);
  });

  it("never returns the hidden cases' inputs", async () => {
    const result = await h.api
      .post(`/sessions/${sessionId}/coding-round/submissions`)
      .set(...bearer(token))
      .send({ code: "function allow(){ return []; }" })
      .expect(201);

    for (const caseResult of result.body.results) {
      expect(Object.keys(caseResult).sort()).toEqual(
        expect.arrayContaining(["case", "duration_ms", "passed"]),
      );
      expect(caseResult).not.toHaveProperty("args");
      expect(caseResult).not.toHaveProperty("expected");
    }
  });
});

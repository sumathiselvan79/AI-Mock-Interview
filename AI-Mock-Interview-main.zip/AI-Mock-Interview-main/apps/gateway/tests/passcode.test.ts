/**
 * TRACKING.md Stage 1, gate test 1:
 * "Unit test passcode hashing: assert the plaintext value is never present
 *  anywhere in the User row or in logs."
 */

import { describe, expect, it } from "vitest";
import { hashPasscode, verifyPasscode, WeakPasscodeError, assertPasscodeAcceptable } from "../src/auth/passcode.js";
import { buildHarness, STUDENT } from "./helpers.js";

describe("passcode hashing", () => {
  it("produces a salted scrypt hash that never contains the plaintext", async () => {
    const passcode = "correct-horse-battery";
    const hash = await hashPasscode(passcode);

    expect(hash.startsWith("scrypt$")).toBe(true);
    expect(hash).not.toContain(passcode);
    expect(hash.split("$")).toHaveLength(6);
  });

  it("salts, so the same passcode hashes differently every time", async () => {
    const a = await hashPasscode("correct-horse-battery");
    const b = await hashPasscode("correct-horse-battery");
    expect(a).not.toEqual(b);
  });

  it("verifies the right passcode and rejects a wrong one", async () => {
    const hash = await hashPasscode("correct-horse-battery");
    await expect(verifyPasscode("correct-horse-battery", hash)).resolves.toBe(true);
    await expect(verifyPasscode("correct-horse-batteryy", hash)).resolves.toBe(false);
    await expect(verifyPasscode("", hash)).resolves.toBe(false);
  });

  it("returns false rather than throwing on a malformed stored value", async () => {
    for (const bad of ["", "not-a-hash", "scrypt$x$y$z$q$r", "bcrypt$1$2$3$4$5"]) {
      await expect(verifyPasscode("anything", bad)).resolves.toBe(false);
    }
  });

  it("refuses a passcode below the minimum length", () => {
    expect(() => assertPasscodeAcceptable("short")).toThrow(WeakPasscodeError);
  });
});

describe("passcode never reaches storage or logs", () => {
  it("stores no plaintext anywhere in the persisted User row", async () => {
    const h = await buildHarness();
    try {
      const user = await h.auth.createUser({ ...STUDENT, role: "student" });
      const row = await h.storage.users.rawRow(user.id);

      expect(row).not.toBeNull();
      // Scan every value of the row, not just the fields we expect to exist.
      const serialized = JSON.stringify(row);
      expect(serialized).not.toContain(STUDENT.passcode);
      expect(Object.values(row!).some((v) => v === STUDENT.passcode)).toBe(false);
    } finally {
      await h.close();
    }
  });

  it("writes no plaintext passcode to the logs, on success or on failure", async () => {
    const h = await buildHarness();
    try {
      await h.auth.createUser({ ...STUDENT, role: "student" });

      await h.api.post("/auth/login").send(STUDENT).expect(200);
      await h.api.post("/auth/login").send({ email: STUDENT.email, passcode: "wrong-passcode-x" }).expect(401);

      const logs = h.logs.history().join("\n");
      expect(logs).not.toContain(STUDENT.passcode);
      expect(logs).not.toContain("wrong-passcode-x");
      expect(logs).not.toMatch(/scrypt\$/);
    } finally {
      await h.close();
    }
  });

  it("redacts sensitive fields if a caller does log a request body", async () => {
    const h = await buildHarness();
    try {
      h.logs.info("handled_request", { body: { email: STUDENT.email, passcode: STUDENT.passcode } });
      const logs = h.logs.history().join("\n");
      expect(logs).not.toContain(STUDENT.passcode);
      expect(logs).toContain("[redacted]");
    } finally {
      await h.close();
    }
  });
});

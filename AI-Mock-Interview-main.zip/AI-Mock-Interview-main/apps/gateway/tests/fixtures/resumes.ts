/**
 * Sample resumes for Stage 2 gate test 1: "Run the Resume Parser against 3–5
 * sample resumes of different formats/lengths; confirm every `topic_relevance`
 * entry traces back to actual resume text."
 *
 * Five resumes, deliberately varied: a long senior backend one, a short junior
 * one, a non-technical one, one with no section headings at all, and one that
 * is effectively unreadable (the scanned-PDF case). Formats are produced here
 * rather than checked in as binaries, so the .docx and .pdf paths are exercised
 * for real without opaque fixture files in the repo.
 */

import { deflateRawSync, crc32 } from "node:zlib";

export const SENIOR_BACKEND_TXT = `Priya Raman
Senior Backend Engineer

SUMMARY
Backend engineer with eight years building payment and messaging systems.

EXPERIENCE
Senior Backend Engineer at Northwind Payments (2019 - 2024)
Led the sharded event bus migration that moved 40 services off a single Kafka topic.
Owned the reliability of the settlement service: cut p99 latency from 900ms to 210ms.
Ran the on-call rotation and wrote the postmortem process the team still uses.
Mentored three junior engineers through their first production incidents.

Backend Engineer at Halcyon Logistics (2016 - 2019)
Designed the Postgres schema behind route planning; added partial indexes that took a
nightly report from 4 minutes to 8 seconds.
Built the REST API used by the mobile app, including idempotent retry handling.
Introduced integration testing to a codebase that had none.

EDUCATION
BSc Computer Science, University of Bristol

SKILLS
Go, Python, Postgres, Kafka, Redis, Kubernetes, Terraform, AWS, gRPC, Prometheus
`;

export const JUNIOR_FRONTEND_MD = `# Sam Okafor

Junior Frontend Developer looking for my second role.

## Experience

Frontend Developer at Bright Studio (2022 - 2024)
- Built React components for the customer dashboard
- Improved accessibility on the checkout flow after an audit
- Wrote unit tests with Jest

## Education

BA Design, Leeds

## Skills

React, TypeScript, CSS, Tailwind, Jest, Figma
`;

/** Non-technical: exercises the behavioural topics and the non-coding role path. */
export const PRODUCT_MANAGER_TXT = `Dana Whitfield
Product Manager

EXPERIENCE
Product Manager at Cobalt Health (2020 - 2024)
Owned the roadmap for the patient scheduling product across three engineering teams.
Ran user research with 40 clinicians and cut the booking flow from nine steps to four.
Partnered with engineering and design on prioritization; drove the launch of the
self-service rebooking feature, which reduced call volume by 22%.

Associate Product Manager at Ledger Group (2018 - 2020)
Collaborated with stakeholders across sales and support to gather requirements.
Delivered the first A/B test framework the team had.

EDUCATION
MBA, Warwick Business School

SKILLS
Roadmapping, User research, Prioritization, Stakeholder management, SQL, Figma
`;

/** No section headings at all — the parser must not fall over on it. */
export const UNSTRUCTURED_TXT = `Marco Silva

I have spent the last six years working on data pipelines and machine learning
infrastructure. At Vela Analytics I built the Airflow pipelines that fed our
recommendation models, moving about two terabytes a day through Spark jobs into
Snowflake. I owned the model serving path in production and reduced inference
latency from 300ms to 90ms by batching requests and caching embeddings. Before
that I was at Tanner Systems where I wrote ETL jobs in Python and maintained the
Postgres warehouse. I studied Mathematics at Coimbra.
`;

/** The scanned-resume case: opens fine, contains almost no text. */
export const NEARLY_EMPTY_TXT = `Resume\n\nJ. Doe\n`;

// ---------------------------------------------------------------- format helpers

/**
 * A minimal single-page PDF with an uncompressed text stream. Real enough for a
 * PDF text extractor to read, small enough to keep in the repo as code.
 */
export function makePdf(lines: string[]): Uint8Array {
  const escaped = lines.map((line) => line.replace(/([()\\])/g, "\\$1"));
  const content = [
    "BT",
    "/F1 11 Tf",
    "14 TL",
    "50 760 Td",
    ...escaped.map((line) => `(${line}) Tj T*`),
    "ET",
  ].join("\n");

  const objects = [
    "<</Type/Catalog/Pages 2 0 R>>",
    "<</Type/Pages/Kids[3 0 R]/Count 1>>",
    "<</Type/Page/Parent 2 0 R/Resources<</Font<</F1 4 0 R>>>>/MediaBox[0 0 612 792]/Contents 5 0 R>>",
    "<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>",
    `<</Length ${content.length}>>\nstream\n${content}\nendstream`,
  ];

  let pdf = "%PDF-1.4\n";
  const offsets: number[] = [];
  objects.forEach((body, index) => {
    offsets.push(pdf.length);
    pdf += `${index + 1} 0 obj\n${body}\nendobj\n`;
  });

  const xrefStart = pdf.length;
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  for (const offset of offsets) pdf += `${offset.toString().padStart(10, "0")} 00000 n \n`;
  pdf += `trailer\n<</Size ${objects.length + 1}/Root 1 0 R>>\nstartxref\n${xrefStart}\n%%EOF`;

  return new Uint8Array(Buffer.from(pdf, "latin1"));
}

/**
 * A minimal .docx — a ZIP of the three parts Word requires. Written by hand so
 * the docx extraction path is tested without adding a zip dependency.
 */
export function makeDocx(lines: string[]): Uint8Array {
  const paragraphs = lines
    .map((line) => `<w:p><w:r><w:t xml:space="preserve">${escapeXml(line)}</w:t></w:r></w:p>`)
    .join("");

  const files: { name: string; content: string }[] = [
    {
      name: "[Content_Types].xml",
      content: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>`,
    },
    {
      name: "_rels/.rels",
      content: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>`,
    },
    {
      name: "word/document.xml",
      content: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>${paragraphs}</w:body></w:document>`,
    },
  ];

  return zip(files);
}

function escapeXml(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

/** Deflate-compressed ZIP writer, enough for the OOXML container. */
function zip(files: { name: string; content: string }[]): Uint8Array {
  const localParts: Buffer[] = [];
  const centralParts: Buffer[] = [];
  let offset = 0;

  for (const file of files) {
    const nameBuf = Buffer.from(file.name, "utf8");
    const raw = Buffer.from(file.content, "utf8");
    const compressed = deflateRawSync(raw);
    const crc = crc32(raw) >>> 0;

    const localHeader = Buffer.alloc(30);
    localHeader.writeUInt32LE(0x04034b50, 0);
    localHeader.writeUInt16LE(20, 4); // version needed
    localHeader.writeUInt16LE(0, 6); // flags
    localHeader.writeUInt16LE(8, 8); // deflate
    localHeader.writeUInt32LE(0, 10); // time/date
    localHeader.writeUInt32LE(crc, 14);
    localHeader.writeUInt32LE(compressed.length, 18);
    localHeader.writeUInt32LE(raw.length, 22);
    localHeader.writeUInt16LE(nameBuf.length, 26);
    localHeader.writeUInt16LE(0, 28);

    const centralHeader = Buffer.alloc(46);
    centralHeader.writeUInt32LE(0x02014b50, 0);
    centralHeader.writeUInt16LE(20, 4);
    centralHeader.writeUInt16LE(20, 6);
    centralHeader.writeUInt16LE(0, 8);
    centralHeader.writeUInt16LE(8, 10);
    centralHeader.writeUInt32LE(0, 12);
    centralHeader.writeUInt32LE(crc, 16);
    centralHeader.writeUInt32LE(compressed.length, 20);
    centralHeader.writeUInt32LE(raw.length, 24);
    centralHeader.writeUInt16LE(nameBuf.length, 28);
    centralHeader.writeUInt32LE(0, 38); // external attrs
    centralHeader.writeUInt32LE(offset, 42);

    localParts.push(localHeader, nameBuf, compressed);
    centralParts.push(centralHeader, nameBuf);
    offset += localHeader.length + nameBuf.length + compressed.length;
  }

  const central = Buffer.concat(centralParts);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(files.length, 8);
  end.writeUInt16LE(files.length, 10);
  end.writeUInt32LE(central.length, 12);
  end.writeUInt32LE(offset, 16);

  return new Uint8Array(Buffer.concat([...localParts, central, end]));
}

export const encoder = new TextEncoder();

export interface SampleResume {
  label: string;
  filename: string;
  contentType: string;
  bytes: Uint8Array;
  /** Phrases that must appear in the source text for evidence checks. */
  sourceText: string;
}

export function sampleResumes(): SampleResume[] {
  return [
    {
      label: "senior backend, long, plain text",
      filename: "priya-raman.txt",
      contentType: "text/plain",
      bytes: encoder.encode(SENIOR_BACKEND_TXT),
      sourceText: SENIOR_BACKEND_TXT,
    },
    {
      label: "junior frontend, short, markdown",
      filename: "sam-okafor.md",
      contentType: "text/markdown",
      bytes: encoder.encode(JUNIOR_FRONTEND_MD),
      sourceText: JUNIOR_FRONTEND_MD,
    },
    {
      label: "product manager, non-technical, docx",
      filename: "dana-whitfield.docx",
      contentType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      bytes: makeDocx(PRODUCT_MANAGER_TXT.split("\n")),
      sourceText: PRODUCT_MANAGER_TXT,
    },
    {
      label: "unstructured prose, no headings, pdf",
      filename: "marco-silva.pdf",
      contentType: "application/pdf",
      bytes: makePdf(UNSTRUCTURED_TXT.split("\n").filter(Boolean)),
      sourceText: UNSTRUCTURED_TXT,
    },
  ];
}

export const BACKEND_JOB_DESCRIPTION = `Senior Backend Engineer

We are looking for someone with deep experience in distributed systems and service reliability.
You will own the design of high-throughput APIs and mentor junior engineers.
Strong knowledge of Postgres and query optimization is required.
Experience with Kubernetes and infrastructure as code is expected.
You must have a solid background in security, including authentication and authorization.
Familiarity with machine learning pipelines is a plus.
`;

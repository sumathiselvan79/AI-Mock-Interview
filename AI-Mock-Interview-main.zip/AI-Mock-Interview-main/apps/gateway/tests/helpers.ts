/**
 * Shared test harness: builds the real gateway object graph against in-memory
 * storage, so every test exercises the same wiring `npm run dev` does.
 */

import request from "supertest";
import { FixtureSpeechProvider, selectSpeechProvider, type SpeechProvider } from "@mia/tool-speech-service";
import { createGateway, type Gateway } from "../src/app.js";
import { loadConfig, type GatewayConfig } from "../src/config.js";
import { createLogger, type Logger } from "../src/logging/logger.js";
import { MemoryResetMailer } from "../src/auth/service.js";
import type { GoogleAuthClient } from "../src/auth/google.js";

export interface TestHarness extends Gateway {
  logs: Logger;
  mailbox: MemoryResetMailer;
  api: request.Agent;
}

export interface BuildHarnessOptions {
  /** Pins the speech provider — see `CreateGatewayOptions.speechProvider`. */
  speechProvider?: SpeechProvider;
  /**
   * Opts this harness into whatever `selectSpeechProvider` resolves — the real
   * sherpa-onnx models when they are on disk. Only the voice suite needs that;
   * see the note on the fixture default below.
   */
  realSpeech?: boolean;
  /** Overrides applied on top of the base test config (e.g. devAuthEnabled, adminEmailAllowlist). */
  config?: Partial<GatewayConfig>;
  /** Substitutes arctic's real Google client so OAuth tests don't hit the network. */
  googleAuthClient?: GoogleAuthClient;
}

/**
 * Speech provider default: the fixture, unless a test asks otherwise.
 *
 * Vitest isolates each test file's module registry, which defeats the Speech
 * Service's own per-process provider cache — so on a machine that HAS the
 * sherpa-onnx models on disk, every test file paid a fresh ~300MB ONNX load and
 * warm-up, and four of those running concurrently pushed unrelated suites past
 * their timeouts. The fixture provider emits real WAV bytes and exercises every
 * part of the voice pipeline except the acoustic model, which is all any suite
 * other than `voice.test.ts` asserts on. That suite passes `realSpeech: true`
 * and keeps its real-ASR accuracy assertions.
 */
function resolveSpeechProvider(options: BuildHarnessOptions, config: GatewayConfig): SpeechProvider {
  if (options.speechProvider) return options.speechProvider;
  if (options.realSpeech) return selectSpeechProvider(config.speechModelDir).provider;
  return new FixtureSpeechProvider();
}

export async function buildHarness(options: BuildHarnessOptions = {}): Promise<TestHarness> {
  // Captured, not printed: several tests assert on what was written to the log.
  const logger = createLogger({ writeToConsole: false, minLevel: "debug" });
  const mailbox = new MemoryResetMailer();
  const config = { ...loadConfig(), nodeEnv: "test", storageDriver: "memory" as const, ...options.config };
  const gateway = await createGateway({
    config,
    logger,
    mailer: mailbox,
    speechProvider: resolveSpeechProvider(options, config),
    ...(options.googleAuthClient ? { googleAuthClient: options.googleAuthClient } : {}),
  });
  return { ...gateway, logs: logger, mailbox, api: request(gateway.app) };
}

export const STUDENT = { email: "student@example.com", passcode: "practice-run-1" };
export const ADMIN = { email: "admin@example.com", passcode: "oversight-run-1" };

export async function seedUsers(h: TestHarness): Promise<{ studentId: string; adminId: string }> {
  const student = await h.auth.createUser({ ...STUDENT, role: "student" });
  const admin = await h.auth.createUser({ ...ADMIN, role: "admin" });
  return { studentId: student.id, adminId: admin.id };
}

export async function loginToken(h: TestHarness, creds: { email: string; passcode: string }): Promise<string> {
  const res = await h.api.post("/auth/login").send(creds);
  if (res.status !== 200) throw new Error(`login failed: ${res.status} ${JSON.stringify(res.body)}`);
  return res.body.token as string;
}

export const bearer = (token: string): [string, string] => ["authorization", `Bearer ${token}`];

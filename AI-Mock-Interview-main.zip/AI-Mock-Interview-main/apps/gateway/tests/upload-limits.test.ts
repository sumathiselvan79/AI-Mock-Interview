/**
 * Regression: the documented upload caps have to be the caps that actually
 * apply, and going over one has to say so.
 *
 * `express.json()` is mounted app-wide and runs BEFORE any route handler, so
 * its limit — not `config.maxResumeBytes`, not `config.maxAudioBytes` — was
 * what really decided whether an upload was accepted. At 1mb it rejected every
 * resume over roughly 750 KiB (base64 inflates by 4/3), which is an ordinary
 * two-page PDF, and made the 20 MiB audio cap unreachable by a wide margin.
 *
 * Worse, body-parser's own `entity.too.large` is not an `HttpError`, so the
 * terminal error handler logged it as unhandled and answered `500 internal
 * error` — a candidate whose resume was slightly too big was told the server
 * was broken.
 */

import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { BACKEND_JOB_DESCRIPTION, SENIOR_BACKEND_TXT } from "./fixtures/resumes.js";
import { STUDENT, bearer, buildHarness, loginToken, seedUsers, type TestHarness } from "./helpers.js";

let h: TestHarness;
let token: string;
let sessionId: string;

/**
 * Real resume text padded to `bytes` so the parser still has something to read.
 * Built in one `repeat` rather than a concat loop — the fixture is pure ASCII,
 * so `length` is `byteLength`, and re-measuring a growing multi-MB string on
 * every iteration is quadratic.
 */
function resumeOfSize(bytes: number): string {
  const filler = "\nAdditional project detail, repeated to reach a realistic file size.";
  const base = SENIOR_BACKEND_TXT;
  const shortfall = Math.max(0, bytes - base.length);
  return (base + filler.repeat(Math.ceil(shortfall / filler.length))).slice(0, bytes);
}

beforeEach(async () => {
  h = await buildHarness();
  await seedUsers(h);
  token = await loginToken(h, STUDENT);
  const created = await h.api
    .post("/sessions")
    .set(...bearer(token))
    .send({ role: "Senior Backend Engineer", job_description: BACKEND_JOB_DESCRIPTION })
    .expect(201);
  sessionId = created.body.session_id;
});

afterEach(async () => {
  await h.close();
});

describe("upload size limits are the configured ones", () => {
  it("accepts a resume that is well over 1 MiB but under the configured cap", async () => {
    // 1.2 MiB of text — ~1.6 MiB once base64-encoded, which is what the body
    // parser actually measures, and comfortably past the old 1mb ceiling. Kept
    // just past that ceiling rather than at a full 2 MiB because the upload
    // route parses and profiles the resume inline, and that cost grows with the
    // document; the limit is what is under test here, not the parser.
    const text = resumeOfSize(1_200 * 1024);
    expect(Buffer.from(text).toString("base64").length).toBeGreaterThan(1024 * 1024);
    expect(Buffer.byteLength(text)).toBeLessThan(h.config.maxResumeBytes);

    const res = await h.api
      .post(`/sessions/${sessionId}/resume`)
      .set(...bearer(token))
      .send({
        filename: "long-resume.txt",
        content_type: "text/plain",
        data_base64: Buffer.from(text).toString("base64"),
      });

    expect(res.status).toBe(201);
    expect(res.body.resume.size_bytes).toBe(Buffer.byteLength(text));
  }, 120_000);

  it("rejects a resume over the configured cap with 413 file_too_large, not 500", async () => {
    const text = resumeOfSize(h.config.maxResumeBytes + 1024);

    const res = await h.api
      .post(`/sessions/${sessionId}/resume`)
      .set(...bearer(token))
      .send({
        filename: "enormous-resume.txt",
        content_type: "text/plain",
        data_base64: Buffer.from(text).toString("base64"),
      });

    expect(res.status).toBe(413);
    expect(res.body.error.code).toBe("file_too_large");
    // Nothing was written for a rejected upload.
    expect(await h.storage.files.listBySession(sessionId)).toHaveLength(0);
  });

  it("accepts an audio body over 1 MiB rather than failing it at the parser", async () => {
    // 3 MiB of audio — roughly 90 seconds of 16-bit 16 kHz mono, i.e. a normal
    // spoken answer, and comfortably under the configured audio cap.
    const audio = Buffer.alloc(3 * 1024 * 1024, 1);
    expect(audio.byteLength).toBeLessThan(h.config.maxAudioBytes);

    const res = await h.api
      .post(`/sessions/${sessionId}/answers/audio`)
      .set(...bearer(token))
      .send({ question_id: "no-such-question", audio_base64: audio.toString("base64") });

    // The body has to survive the parser. What the interview logic then makes
    // of an unknown question id is a different concern — the only thing being
    // asserted here is that it was not rejected for its size.
    expect(res.status).not.toBe(413);
    expect(res.body?.error?.code).not.toBe("internal_error");
  });

  it("rejects audio over the configured cap with 413, not 500", async () => {
    const audio = Buffer.alloc(h.config.maxAudioBytes + 1024, 1);

    const res = await h.api
      .post(`/sessions/${sessionId}/answers/audio`)
      .set(...bearer(token))
      .send({ question_id: "no-such-question", audio_base64: audio.toString("base64") });

    expect(res.status).toBe(413);
    expect(res.body.error.code).toBe("file_too_large");
  });

  it("keeps the small body limit on routes that take no blob", async () => {
    // The blob limit is scoped to the two upload routes on purpose: a 27 MiB
    // body must not be aimable at the login endpoint.
    const res = await h.api
      .post("/auth/login")
      .send({ email: STUDENT.email, passcode: "x".repeat(2 * 1024 * 1024) });

    expect(res.status).toBe(413);
    expect(res.body.error.code).toBe("payload_too_large");
  });
});

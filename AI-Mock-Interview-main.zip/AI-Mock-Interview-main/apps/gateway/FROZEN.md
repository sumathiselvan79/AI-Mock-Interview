# Frozen — superseded by `backend/`

As of this cutover, the TypeScript gateway (this package), `agents/*`, and
`mcp-servers/*` are **frozen**: no new features, no bug fixes beyond what's
needed to keep them readable as historical reference. The active
implementation is the Python/FastAPI port at `backend/` — see
`FASTAPI_MIGRATION.md` at the repo root for the full stage-by-stage record of
the port, and `CLAUDE.md` for the (language-agnostic) architecture these two
implementations both follow.

`apps/web` now talks to `backend/` by default (`NEXT_PUBLIC_GATEWAY_URL`,
same port `:4000` both implementations use). `npm run dev` starts the FastAPI
backend, not this package — use `npm run dev:ts-frozen` if you specifically
need to run this frozen implementation (e.g. to diff behavior against the
port while `FASTAPI_MIGRATION.md`'s remaining stages land).

Why frozen rather than deleted: it's still the reference implementation
`backend/`'s Python port is checked against file-by-file, and every
`FASTAPI_MIGRATION.md` stage entry cites the specific TS source file it
ported. Deleting it now would remove the thing the port is provably faithful
to.

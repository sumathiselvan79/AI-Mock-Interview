/**
 * Blob storage for uploaded resumes (audio follows in Stage 3).
 *
 * `delete` is a hard delete in both drivers — the bytes are removed, not
 * unlinked from an index (INSTRUCTIONS.md §8). `exists` reads the backing store
 * directly so a deletion test can check the real thing rather than a cache.
 */

import { randomUUID } from "node:crypto";
import { mkdir, readFile, readdir, rm, stat, writeFile } from "node:fs/promises";
import { existsSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import type { FileStore, StoredFileMeta } from "@mia/shared-types";

interface StoredFile {
  meta: StoredFileMeta;
  bytes: Uint8Array;
}

function newRef(sessionId: string, filename: string): string {
  const safe = filename.replace(/[^\w.\-]+/g, "_").slice(-80);
  return `${sessionId}/${randomUUID()}-${safe}`;
}

export class MemoryFileStore implements FileStore {
  private readonly files = new Map<string, StoredFile>();

  async put(input: {
    sessionId: string;
    filename: string;
    contentType: string;
    bytes: Uint8Array;
  }): Promise<StoredFileMeta> {
    const meta: StoredFileMeta = {
      ref: newRef(input.sessionId, input.filename),
      sessionId: input.sessionId,
      filename: input.filename,
      contentType: input.contentType,
      sizeBytes: input.bytes.byteLength,
      uploadedAt: new Date().toISOString(),
    };
    this.files.set(meta.ref, { meta, bytes: new Uint8Array(input.bytes) });
    return meta;
  }

  async get(ref: string): Promise<{ meta: StoredFileMeta; bytes: Uint8Array } | null> {
    const found = this.files.get(ref);
    return found ? { meta: { ...found.meta }, bytes: new Uint8Array(found.bytes) } : null;
  }

  async stat(ref: string): Promise<StoredFileMeta | null> {
    const found = this.files.get(ref);
    return found ? { ...found.meta } : null;
  }

  async exists(ref: string): Promise<boolean> {
    return this.files.has(ref);
  }

  async delete(ref: string): Promise<boolean> {
    return this.files.delete(ref);
  }

  async listBySession(sessionId: string): Promise<StoredFileMeta[]> {
    return [...this.files.values()].filter((f) => f.meta.sessionId === sessionId).map((f) => ({ ...f.meta }));
  }
}

/** Disk-backed store. Metadata sits beside each blob as `<name>.meta.json`. */
export class DiskFileStore implements FileStore {
  constructor(private readonly root: string) {}

  private path(ref: string): string {
    const full = resolve(this.root, ref);
    // Refs are generated internally, but a path-traversal check costs nothing
    // and this function takes a value that has crossed a process boundary.
    if (!full.startsWith(resolve(this.root))) throw new Error("invalid file ref");
    return full;
  }

  async put(input: {
    sessionId: string;
    filename: string;
    contentType: string;
    bytes: Uint8Array;
  }): Promise<StoredFileMeta> {
    const meta: StoredFileMeta = {
      ref: newRef(input.sessionId, input.filename),
      sessionId: input.sessionId,
      filename: input.filename,
      contentType: input.contentType,
      sizeBytes: input.bytes.byteLength,
      uploadedAt: new Date().toISOString(),
    };
    const target = this.path(meta.ref);
    await mkdir(dirname(target), { recursive: true });
    await writeFile(target, input.bytes);
    await writeFile(`${target}.meta.json`, JSON.stringify(meta), "utf8");
    return meta;
  }

  async get(ref: string): Promise<{ meta: StoredFileMeta; bytes: Uint8Array } | null> {
    const meta = await this.stat(ref);
    if (!meta) return null;
    return { meta, bytes: new Uint8Array(await readFile(this.path(ref))) };
  }

  async stat(ref: string): Promise<StoredFileMeta | null> {
    const metaPath = `${this.path(ref)}.meta.json`;
    if (!existsSync(metaPath)) return null;
    return JSON.parse(await readFile(metaPath, "utf8")) as StoredFileMeta;
  }

  async exists(ref: string): Promise<boolean> {
    return existsSync(this.path(ref));
  }

  async delete(ref: string): Promise<boolean> {
    const target = this.path(ref);
    if (!existsSync(target)) return false;
    await rm(target, { force: true });
    await rm(`${target}.meta.json`, { force: true });
    return true;
  }

  async listBySession(sessionId: string): Promise<StoredFileMeta[]> {
    const dir = join(this.root, sessionId);
    if (!existsSync(dir)) return [];
    const entries = await readdir(dir);
    const metas: StoredFileMeta[] = [];
    for (const entry of entries) {
      if (!entry.endsWith(".meta.json")) continue;
      const file = join(dir, entry);
      if ((await stat(file)).isFile()) {
        metas.push(JSON.parse(await readFile(file, "utf8")) as StoredFileMeta);
      }
    }
    return metas;
  }
}

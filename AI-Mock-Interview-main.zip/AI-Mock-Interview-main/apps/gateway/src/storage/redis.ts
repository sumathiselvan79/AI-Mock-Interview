/**
 * Redis-backed live session state and timers (INSTRUCTIONS.md §5.3, §9).
 *
 * Everything here is ephemeral: device-check results, session MCP tokens,
 * segment timers, and rate-limit counters. Losing it costs a session its live
 * pacing, never a durable record.
 */

import { createClient, type RedisClientType } from "redis";
import type { DeviceCheckResult, LiveSessionStore, TimerState } from "./types.js";

const DEVICE_CHECK_TTL_S = 60 * 60 * 6;
const SESSION_TOKEN_TTL_S = 60 * 60 * 6;
const TIMER_TTL_S = 60 * 60 * 6;

/**
 * (Stage 5) The Memory Agent's session-scoped working memory (§4.7). Given its
 * own TTL because a reference answer is the one thing here that must not
 * outlive its session by design, not merely by convenience — soul.md §5 forbids
 * it ever reaching the candidate or the transcript, so a stale key surviving a
 * crashed session is a privacy question, not a cache question.
 */
const SCRATCH_TTL_S = 60 * 60 * 6;

const key = {
  deviceCheck: (sessionId: string) => `mia:session:${sessionId}:device-check`,
  sessionToken: (sessionId: string) => `mia:session:${sessionId}:mcp-token`,
  timer: (segmentId: string) => `mia:timer:${segmentId}`,
  rate: (k: string) => `mia:rate:${k}`,
  scratch: (sessionId: string) => `mia:session:${sessionId}:scratch`,
};

export class RedisLiveSessionStore implements LiveSessionStore {
  constructor(private readonly client: RedisClientType) {}

  static async connect(url: string): Promise<RedisLiveSessionStore> {
    const client = createClient({ url }) as RedisClientType;
    await client.connect();
    return new RedisLiveSessionStore(client);
  }

  async setDeviceCheck(sessionId: string, result: DeviceCheckResult): Promise<void> {
    await this.client.set(key.deviceCheck(sessionId), JSON.stringify(result), { EX: DEVICE_CHECK_TTL_S });
  }

  async getDeviceCheck(sessionId: string): Promise<DeviceCheckResult | null> {
    const raw = await this.client.get(key.deviceCheck(sessionId));
    return raw ? (JSON.parse(raw) as DeviceCheckResult) : null;
  }

  async setSessionToken(sessionId: string, token: string): Promise<void> {
    await this.client.set(key.sessionToken(sessionId), token, { EX: SESSION_TOKEN_TTL_S });
  }

  async getSessionToken(sessionId: string): Promise<string | null> {
    return this.client.get(key.sessionToken(sessionId));
  }

  /** One hash per session, so `clearSessionScratch` is a single DEL. */
  async setSessionScratch(sessionId: string, k: string, value: unknown): Promise<void> {
    const redisKey = key.scratch(sessionId);
    await this.client.hSet(redisKey, k, JSON.stringify(value));
    await this.client.expire(redisKey, SCRATCH_TTL_S);
  }

  async getSessionScratch<T = unknown>(sessionId: string, k: string): Promise<T | null> {
    const raw = await this.client.hGet(key.scratch(sessionId), k);
    return raw ? (JSON.parse(raw) as T) : null;
  }

  async clearSessionScratch(sessionId: string): Promise<void> {
    await this.client.del(key.scratch(sessionId));
  }

  async saveTimer(state: TimerState): Promise<void> {
    await this.client.set(key.timer(state.segmentId), JSON.stringify(state), { EX: TIMER_TTL_S });
  }

  async loadTimer(segmentId: string): Promise<TimerState | null> {
    const raw = await this.client.get(key.timer(segmentId));
    return raw ? (JSON.parse(raw) as TimerState) : null;
  }

  async clearTimer(segmentId: string): Promise<void> {
    await this.client.del(key.timer(segmentId));
  }

  /** INCR + first-write EXPIRE: a fixed window, atomic enough for rate limiting. */
  async incrementRateCounter(k: string, windowMs: number): Promise<number> {
    const redisKey = key.rate(k);
    const count = await this.client.incr(redisKey);
    if (count === 1) await this.client.pExpire(redisKey, windowMs);
    return count;
  }

  async close(): Promise<void> {
    if (this.client.isOpen) await this.client.quit();
  }
}

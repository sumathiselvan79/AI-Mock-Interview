import type {
  AnswerStore,
  EvaluationStore,
  FileStore,
  OAuthProfileStore,
  PasscodeResetToken,
  QuestionStore,
  ReportStore,
  Role,
  ScheduledInterviewStore,
  Session,
  SessionArchiveStore,
  SessionStore,
  TelemetrySink,
  User,
  UserProfile,
} from "@mia/shared-types";

export interface UserStore {
  create(input: {
    email: string;
    role: Role;
    passcodeHash: string;
    crossSessionMemoryOptIn?: boolean;
    profile?: UserProfile;
  }): Promise<User>;
  /**
   * (Stage 5, §11.4) Sets the archive-required profile fields. Only the keys
   * present are written, so a partial profile update cannot blank a field the
   * candidate filled in earlier.
   */
  updateProfile(userId: string, profile: UserProfile): Promise<User>;
  findByEmail(email: string): Promise<User | null>;
  findById(id: string): Promise<User | null>;
  updatePasscodeHash(userId: string, passcodeHash: string): Promise<void>;
  /**
   * Find-or-create for identity paths that never collect a passcode
   * (dev-login, Google OAuth). `unusablePasscodeHash` is only ever written on
   * the create branch — an existing row's real passcode hash is never
   * touched, so an OAuth login can never lock a passcode account out. On an
   * existing row, only `role` is synced, so a later allowlist change takes
   * effect on the next login without a manual DB edit.
   */
  upsertIdentity(input: { email: string; role: Role; unusablePasscodeHash: string }): Promise<User>;
  /** Raw row as persisted — used by the privacy test that asserts no plaintext is stored. */
  rawRow(userId: string): Promise<Record<string, unknown> | null>;
  /**
   * (Stage 7) Every account with this role, oldest first.
   *
   * The Admin directory pages and filters in the gateway rather than in SQL:
   * the filters span three stores (users, reports, schedules) and a candidate's
   * score is not a column on any of them, so a `LIMIT`/`OFFSET` at this layer
   * would page the wrong set. Bounded by the number of student accounts, which
   * is the population the directory exists to show; if that ever outgrows a
   * single page of memory, the aggregate belongs in a materialized view rather
   * than a different slice here.
   */
  listByRole(role: Role): Promise<User[]>;
}

export interface ResetTokenStore {
  create(userId: string, tokenHash: string, expiresAt: string): Promise<PasscodeResetToken>;
  findValidByHash(tokenHash: string, now: Date): Promise<PasscodeResetToken | null>;
  markUsed(id: string, at: string): Promise<void>;
}

export interface DeviceCheckResult {
  passed: boolean;
  micOk: boolean;
  speakerOk: boolean;
  at: string;
}

/** A segment timer as stored. Pause is accumulated, so elapsed excludes paused time. */
export interface TimerState {
  segmentId: string;
  budgetMs: number;
  /** epoch ms */
  startedAt: number;
  /** epoch ms, set while paused */
  pausedAt: number | null;
  /** total ms spent paused so far */
  pausedMs: number;
}

/**
 * Live session state and timers — Redis in production (INSTRUCTIONS.md §5.3,
 * §9). Everything here is ephemeral and reconstructable; durable records live
 * in Postgres.
 */
export interface LiveSessionStore {
  setDeviceCheck(sessionId: string, result: DeviceCheckResult): Promise<void>;
  getDeviceCheck(sessionId: string): Promise<DeviceCheckResult | null>;

  /** Session-scoped MCP token, minted at session creation. */
  setSessionToken(sessionId: string, token: string): Promise<void>;
  getSessionToken(sessionId: string): Promise<string | null>;

  /**
   * (Stage 5) Session-scoped working memory for the Memory Agent
   * (INSTRUCTIONS.md §4.7): each question's `reference_answer`, and the
   * in-progress `jd_fit` fields during CONFIG.
   *
   * It lives here rather than in a new Postgres table on purpose. Both are
   * ephemeral by design — the reference answer must never reach `questions`,
   * `answers`, the transcript, or anything the candidate or an Admin can read
   * (soul.md §5 Stage 5 addition) — and "a new durable table is the wrong
   * default" for data that should disappear with the session (§4.7).
   */
  setSessionScratch(sessionId: string, key: string, value: unknown): Promise<void>;
  getSessionScratch<T = unknown>(sessionId: string, key: string): Promise<T | null>;
  /** Drops everything the Memory Agent was holding for this session. */
  clearSessionScratch(sessionId: string): Promise<void>;

  saveTimer(state: TimerState): Promise<void>;
  loadTimer(segmentId: string): Promise<TimerState | null>;
  clearTimer(segmentId: string): Promise<void>;

  /** Token-bucket counter backing the MCP gateway's per-session rate limit. */
  incrementRateCounter(key: string, windowMs: number): Promise<number>;

  close(): Promise<void>;
}

export interface Storage {
  users: UserStore;
  sessions: SessionStore;
  resets: ResetTokenStore;
  telemetry: TelemetrySink;
  live: LiveSessionStore;
  files: FileStore;
  questions: QuestionStore;
  answers: AnswerStore;
  evaluations: EvaluationStore;
  reports: ReportStore;
  /**
   * (Stage 7) Admin-scheduled interviews. In the PRIMARY Postgres, not the
   * Supabase archive instance — this is live operational data a student's home
   * page reads on every load, not an export copy (`ADMIN_FEATURE_PROMPT.md`
   * §non-goals: "no second database duplicating session_archives").
   */
  scheduled: ScheduledInterviewStore;
  /**
   * (Stage 5, §11.4) The Supabase-hosted archive. Optional: a deployment that
   * has not provisioned the second database completes sessions exactly as
   * Stage 4 did, and the admin archive routes 404 rather than pretending.
   */
  archives?: SessionArchiveStore;
  /**
   * The Google OAuth profile snapshot, in the same Supabase instance as
   * `archives` (packages/shared-types/src/oauth-profile.ts). Optional for the
   * same reason `archives` is: a deployment without the second database still
   * completes Google sign-in exactly as before, just without the snapshot.
   */
  oauthProfiles?: OAuthProfileStore;
  close(): Promise<void>;
}

export type {
  Session,
  SessionStore,
  TelemetrySink,
  FileStore,
  QuestionStore,
  AnswerStore,
  EvaluationStore,
  ReportStore,
  ScheduledInterviewStore,
};

/**
 * In-memory question/answer/evaluation stores. Mirrors the Postgres driver in
 * `interview-postgres.ts` port for port.
 */

import type {
  Answer,
  AnswerStore,
  CandidateReportAggregate,
  Evaluation,
  EvaluationStore,
  Question,
  QuestionStore,
  Report,
  ReportStore,
} from "@mia/shared-types";
import { REDACTED_TRANSCRIPT, meanCompetencyScore } from "@mia/shared-types";

const clone = <T>(value: T): T => structuredClone(value);

export class MemoryQuestionStore implements QuestionStore {
  private readonly rows = new Map<string, Question>();

  async append(question: Question): Promise<Question> {
    this.rows.set(question.id, clone(question));
    return clone(question);
  }

  async get(questionId: string): Promise<Question | null> {
    const row = this.rows.get(questionId);
    return row ? clone(row) : null;
  }

  async listBySession(sessionId: string): Promise<Question[]> {
    return [...this.rows.values()]
      .filter((q) => q.sessionId === sessionId)
      .sort((a, b) => a.askedAt.localeCompare(b.askedAt))
      .map(clone);
  }
}

export class MemoryAnswerStore implements AnswerStore {
  private readonly rows = new Map<string, Answer>();

  async append(answer: Answer): Promise<Answer> {
    this.rows.set(answer.id, clone(answer));
    return clone(answer);
  }

  async get(answerId: string): Promise<Answer | null> {
    const row = this.rows.get(answerId);
    return row ? clone(row) : null;
  }

  async getByQuestion(questionId: string): Promise<Answer | null> {
    const row = [...this.rows.values()].find((a) => a.questionId === questionId);
    return row ? clone(row) : null;
  }

  async appendFollowUp(answerId: string, followUp: { text: string; transcript: string }): Promise<Answer> {
    const row = this.rows.get(answerId);
    if (!row) throw new Error(`unknown answer ${answerId}`);
    row.followUps.push(clone(followUp));
    return clone(row);
  }

  async scoreFollowUp(
    answerId: string,
    index: number,
    score: NonNullable<Answer["followUps"][number]["score"]>,
  ): Promise<Answer> {
    const row = this.rows.get(answerId);
    if (!row) throw new Error(`unknown answer ${answerId}`);
    const followUp = row.followUps[index];
    if (!followUp) throw new Error(`answer ${answerId} has no follow-up at index ${index}`);
    followUp.score = clone(score);
    return clone(row);
  }

  async recordExtraction(
    answerId: string,
    extraction: NonNullable<Answer["extraction"]>,
    nextAction: NonNullable<Answer["nextAction"]>,
  ): Promise<Answer> {
    const row = this.rows.get(answerId);
    if (!row) throw new Error(`unknown answer ${answerId}`);
    row.extraction = clone(extraction);
    row.nextAction = clone(nextAction);
    return clone(row);
  }

  async redact(answerId: string): Promise<Answer> {
    const row = this.rows.get(answerId);
    if (!row) throw new Error(`unknown answer ${answerId}`);
    row.transcript = REDACTED_TRANSCRIPT;
    // The score and its rationale survive redaction, as `Evaluation` rows do —
    // §8 purges the candidate's own words, not the assessment of them.
    row.followUps = row.followUps.map((f) => ({ ...f, transcript: REDACTED_TRANSCRIPT }));
    return clone(row);
  }
}

export class MemoryEvaluationStore implements EvaluationStore {
  private readonly rows: Evaluation[] = [];

  /** Session scope is derived by walking evaluation -> answer -> question, the
   * same join the Postgres driver does, rather than denormalising a session id
   * onto every evaluation row. */
  constructor(
    private readonly questions: MemoryQuestionStore,
    private readonly answers: MemoryAnswerStore,
  ) {}

  async append(evaluation: Evaluation): Promise<Evaluation> {
    this.rows.push(clone(evaluation));
    return clone(evaluation);
  }

  async listByAnswer(answerId: string): Promise<Evaluation[]> {
    return this.rows.filter((e) => e.answerId === answerId).map(clone);
  }

  async listBySession(sessionId: string): Promise<Evaluation[]> {
    const questionIds = new Set((await this.questions.listBySession(sessionId)).map((q) => q.id));
    const out: Evaluation[] = [];
    for (const row of this.rows) {
      const answer = await this.answers.get(row.answerId);
      if (answer && questionIds.has(answer.questionId)) out.push(clone(row));
    }
    return out;
  }
}

export class MemoryReportStore implements ReportStore {
  private readonly rows = new Map<string, Report>();

  async create(report: Report): Promise<Report> {
    this.rows.set(report.sessionId, clone(report));
    return clone(report);
  }

  async getBySession(sessionId: string): Promise<Report | null> {
    const row = this.rows.get(sessionId);
    return row ? clone(row) : null;
  }

  async listByCandidate(candidateId: string): Promise<Report[]> {
    return [...this.rows.values()]
      .filter((r) => r.candidateId === candidateId)
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
      .map(clone);
  }

  async listAll(): Promise<Report[]> {
    return [...this.rows.values()].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).map(clone);
  }

  /**
   * (Stage 7) One pass over the reports, grouped by candidate — the same shape
   * the Postgres driver computes in SQL, so the directory's numbers cannot
   * differ between drivers.
   *
   * `averageScore` is the mean of each report's OWN mean, not the mean of every
   * competency score pooled together. Those differ whenever sessions scored
   * different numbers of competencies, and "average score per interview" is the
   * one the directory column claims to show.
   */
  async aggregateByCandidate(): Promise<CandidateReportAggregate[]> {
    const byCandidate = new Map<string, { means: number[]; count: number; last: string | null }>();

    for (const report of this.rows.values()) {
      const entry = byCandidate.get(report.candidateId) ?? { means: [], count: 0, last: null };
      entry.count += 1;
      const mean = meanCompetencyScore(report.competencyScores);
      if (mean !== null) entry.means.push(mean);
      if (!entry.last || report.createdAt > entry.last) entry.last = report.createdAt;
      byCandidate.set(report.candidateId, entry);
    }

    return [...byCandidate.entries()].map(([candidateId, entry]) => ({
      candidateId,
      interviewsCompleted: entry.count,
      averageScore:
        entry.means.length === 0
          ? null
          : entry.means.reduce((sum, m) => sum + m, 0) / entry.means.length,
      lastInterviewAt: entry.last,
    }));
  }
}

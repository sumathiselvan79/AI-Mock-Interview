/**
 * Migration runner: applies every .sql file in a migrations directory in
 * filename order, once each, tracked in `schema_migrations`.
 *
 * There are two directories and two commands on purpose (§11.4, §11.6):
 *  - `npm run db:migrate` -> ./migrations, the primary application Postgres;
 *  - `npm run db:migrate:archive` -> ./migrations/supabase, the separate
 *    Supabase-hosted archive instance.
 *
 * Keeping them apart means no single command can create the archive table in
 * the primary database, or the application schema in the archive — and
 * `readdirSync` here only picks up files, so the `supabase/` subdirectory can
 * never be swept into the primary run by accident.
 */

import { readFileSync, readdirSync, statSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import pg from "pg";
import { loadConfig } from "../config.js";
import { loadDotEnv } from "../paths.js";
import { createPool } from "./postgres.js";

const MIGRATIONS_DIR = join(dirname(fileURLToPath(import.meta.url)), "..", "..", "migrations");
const ARCHIVE_MIGRATIONS_DIR = join(MIGRATIONS_DIR, "supabase");

export async function migrate(
  databaseUrl: string,
  directory: string = MIGRATIONS_DIR,
  pool: pg.Pool = createPool(databaseUrl),
): Promise<string[]> {
  const MIGRATIONS_DIR = directory;
  const applied: string[] = [];
  try {
    await pool.query(
      `CREATE TABLE IF NOT EXISTS schema_migrations (
         name TEXT PRIMARY KEY,
         applied_at TIMESTAMPTZ NOT NULL DEFAULT now()
       )`,
    );
    const files = readdirSync(MIGRATIONS_DIR)
      .filter((f) => f.endsWith(".sql") && statSync(join(MIGRATIONS_DIR, f)).isFile())
      .sort();
    for (const file of files) {
      const { rowCount } = await pool.query(`SELECT 1 FROM schema_migrations WHERE name = $1`, [file]);
      if (rowCount && rowCount > 0) continue;

      const sql = readFileSync(join(MIGRATIONS_DIR, file), "utf8");
      const client = await pool.connect();
      try {
        await client.query("BEGIN");
        await client.query(sql);
        await client.query(`INSERT INTO schema_migrations (name) VALUES ($1)`, [file]);
        await client.query("COMMIT");
        applied.push(file);
      } catch (err) {
        await client.query("ROLLBACK");
        throw new Error(`migration ${file} failed: ${(err as Error).message}`);
      } finally {
        client.release();
      }
    }
    return applied;
  } finally {
    await pool.end();
  }
}

/**
 * (Stage 5, §11.6) The Supabase archive instance. Its own pool because Supabase
 * terminates TLS with a chain the default Node trust store does not carry, and
 * its own connection string because it must never be the primary database.
 */
export async function migrateArchive(connectionString: string): Promise<string[]> {
  return migrate(
    connectionString,
    ARCHIVE_MIGRATIONS_DIR,
    new pg.Pool({ connectionString, ssl: { rejectUnauthorized: false }, max: 2 }),
  );
}

const isDirectRun = process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1];
if (isDirectRun) {
  // DATABASE_URL and SUPABASE_DB_URL live in the repo-root `.env`; without
  // this the CLI would migrate whatever the compiled-in defaults point at.
  loadDotEnv();
  const config = loadConfig();
  const archiveOnly = process.argv.includes("--archive");

  if (archiveOnly && !config.supabaseDbUrl) {
    process.stderr.write("SUPABASE_DB_URL is not set; nothing to migrate on the archive instance\n");
    process.exitCode = 1;
  } else {
    (archiveOnly ? migrateArchive(config.supabaseDbUrl) : migrate(config.databaseUrl))
      .then((applied) => {
        process.stdout.write(
          applied.length > 0 ? `applied: ${applied.join(", ")}\n` : "no pending migrations\n",
        );
      })
      .catch((err: Error) => {
        process.stderr.write(`${err.message}\n`);
        process.exitCode = 1;
      });
  }
}

/**
 * In-memory storage driver.
 *
 * Used by the test suite and by `npm run dev` before Postgres/Redis are up. It
 * implements exactly the same ports as the Postgres/Redis driver — including
 * the state-write grant check — so a behaviour proven here is the behaviour the
 * real driver has to match.
 */

import { randomUUID } from "node:crypto";
import {
  DEFAULT_CONSENT,
  DEFAULT_QUESTION_BUDGET,
  FORBIDDEN_TELEMETRY_KEYS,
  type PasscodeResetToken,
  type ScheduledInterview,
  type ScheduledInterviewStore,
  type Session,
  type SessionState,
  type SessionStateTransition,
  type SessionStore,
  type StateWriteGrant,
  type TelemetryEvent,
  type TelemetryEventType,
  type TelemetryPayload,
  type TelemetrySink,
  type User,
  type UserProfile,
} from "@mia/shared-types";
import type {
  DeviceCheckResult,
  LiveSessionStore,
  ResetTokenStore,
  Storage,
  TimerState,
  UserStore,
} from "./types.js";
import { MemoryFileStore } from "./files.js";
import {
  MemoryAnswerStore,
  MemoryEvaluationStore,
  MemoryQuestionStore,
  MemoryReportStore,
} from "./interview-memory.js";

const clone = <T>(value: T): T => structuredClone(value);

/** Drops absent and blank profile keys so they never overwrite a stored value. */
function definedProfile(profile: UserProfile | undefined): UserProfile {
  if (!profile) return {};
  return Object.fromEntries(
    Object.entries(profile).filter(([, value]) => typeof value === "string" && value.trim().length > 0),
  ) as UserProfile;
}

class MemoryUserStore implements UserStore {
  private readonly rows = new Map<string, User>();

  async create(input: {
    email: string;
    role: User["role"];
    passcodeHash: string;
    crossSessionMemoryOptIn?: boolean;
    profile?: UserProfile;
  }): Promise<User> {
    const email = input.email.trim().toLowerCase();
    if ([...this.rows.values()].some((u) => u.email === email)) {
      throw new Error(`user already exists: ${email}`);
    }
    const user: User = {
      id: randomUUID(),
      email,
      role: input.role,
      passcodeHash: input.passcodeHash,
      crossSessionMemoryOptIn: input.crossSessionMemoryOptIn ?? false,
      ...definedProfile(input.profile),
      createdAt: new Date().toISOString(),
    };
    this.rows.set(user.id, user);
    return clone(user);
  }

  async updateProfile(userId: string, profile: UserProfile): Promise<User> {
    const user = this.rows.get(userId);
    if (!user) throw new Error(`unknown user ${userId}`);
    // Only the keys actually supplied — a partial update must not blank a
    // field the candidate filled in earlier (§11.4).
    Object.assign(user, definedProfile(profile));
    return clone(user);
  }

  async findByEmail(email: string): Promise<User | null> {
    const match = [...this.rows.values()].find((u) => u.email === email.trim().toLowerCase());
    return match ? clone(match) : null;
  }

  async findById(id: string): Promise<User | null> {
    const match = this.rows.get(id);
    return match ? clone(match) : null;
  }

  async updatePasscodeHash(userId: string, passcodeHash: string): Promise<void> {
    const user = this.rows.get(userId);
    if (!user) throw new Error(`unknown user ${userId}`);
    user.passcodeHash = passcodeHash;
  }

  async upsertIdentity(input: {
    email: string;
    role: User["role"];
    unusablePasscodeHash: string;
  }): Promise<User> {
    const email = input.email.trim().toLowerCase();
    const existing = [...this.rows.values()].find((u) => u.email === email);
    if (existing) {
      // Role only — never touch a passcode hash that might be real.
      existing.role = input.role;
      return clone(existing);
    }
    const user: User = {
      id: randomUUID(),
      email,
      role: input.role,
      passcodeHash: input.unusablePasscodeHash,
      crossSessionMemoryOptIn: false,
      createdAt: new Date().toISOString(),
    };
    this.rows.set(user.id, user);
    return clone(user);
  }

  async rawRow(userId: string): Promise<Record<string, unknown> | null> {
    const user = this.rows.get(userId);
    return user ? (clone(user) as unknown as Record<string, unknown>) : null;
  }

  /** (Stage 7) Every account with this role, oldest first — the directory's page source. */
  async listByRole(role: User["role"]): Promise<User[]> {
    return [...this.rows.values()]
      .filter((u) => u.role === role)
      .sort((a, b) => a.createdAt.localeCompare(b.createdAt))
      .map(clone);
  }
}

class MemoryResetTokenStore implements ResetTokenStore {
  private readonly rows = new Map<string, PasscodeResetToken>();

  async create(userId: string, tokenHash: string, expiresAt: string): Promise<PasscodeResetToken> {
    // Invalidate any outstanding token for this user — one live reset at a time.
    for (const row of this.rows.values()) {
      if (row.userId === userId && !row.usedAt) row.usedAt = new Date().toISOString();
    }
    const row: PasscodeResetToken = {
      id: randomUUID(),
      userId,
      tokenHash,
      expiresAt,
      usedAt: null,
    };
    this.rows.set(row.id, row);
    return clone(row);
  }

  async findValidByHash(tokenHash: string, now: Date): Promise<PasscodeResetToken | null> {
    const match = [...this.rows.values()].find(
      (r) => r.tokenHash === tokenHash && r.usedAt === null && new Date(r.expiresAt) > now,
    );
    return match ? clone(match) : null;
  }

  async markUsed(id: string, at: string): Promise<void> {
    const row = this.rows.get(id);
    if (row) row.usedAt = at;
  }
}

export class StateWriteForbidden extends Error {
  readonly code = "state_write_forbidden";
  constructor(message: string) {
    super(message);
    this.name = "StateWriteForbidden";
  }
}

class MemorySessionStore implements SessionStore {
  private readonly rows = new Map<string, Session>();
  private readonly audit: SessionStateTransition[] = [];
  private grant: StateWriteGrant | null = null;

  registerStateWriter(grant: StateWriteGrant): void {
    if (this.grant && this.grant.token !== grant.token) {
      throw new StateWriteForbidden("a state writer is already registered for this store");
    }
    if (grant.actor !== "harness-agent") {
      throw new StateWriteForbidden(`state writer must be harness-agent, got ${grant.actor}`);
    }
    this.grant = grant;
  }

  async create(input: {
    candidateId: string;
    role: string;
    jobDescription: string;
    questionBudget?: number;
  }): Promise<Session> {
    const now = new Date().toISOString();
    const session: Session = {
      id: randomUUID(),
      candidateId: input.candidateId,
      role: input.role,
      jobDescription: input.jobDescription,
      jdFit: null,
      state: "CREATED",
      consent: { ...DEFAULT_CONSENT },
      questionBudget: input.questionBudget ?? DEFAULT_QUESTION_BUDGET,
      topicPlan: [],
      resumeRef: null,
      candidateProfile: null,
      jdGapTopics: [],
      jdFitFingerprint: null,
      focusEvents: [],
      createdAt: now,
      updatedAt: now,
    };
    this.rows.set(session.id, session);
    return clone(session);
  }

  async get(sessionId: string): Promise<Session | null> {
    const row = this.rows.get(sessionId);
    return row ? clone(row) : null;
  }

  async listByCandidate(candidateId: string): Promise<Session[]> {
    return [...this.rows.values()].filter((s) => s.candidateId === candidateId).map(clone);
  }

  async setState(
    sessionId: string,
    toState: SessionState,
    grant: StateWriteGrant,
    reason: string,
  ): Promise<Session> {
    // Identity check against the registered grant. A forged object literal with
    // the right `actor` string fails here because the symbol cannot be recreated.
    if (!this.grant || !grant || grant.token !== this.grant.token || grant.actor !== "harness-agent") {
      throw new StateWriteForbidden(
        "Session.state may only be written by the Harness Agent (INSTRUCTIONS.md §3)",
      );
    }
    const row = this.rows.get(sessionId);
    if (!row) throw new Error(`unknown session ${sessionId}`);

    const at = new Date().toISOString();
    this.audit.push({
      id: randomUUID(),
      sessionId,
      fromState: row.state,
      toState,
      actor: grant.actor,
      reason,
      at,
    });
    row.state = toState;
    row.updatedAt = at;
    return clone(row);
  }

  async transitions(sessionId: string): Promise<SessionStateTransition[]> {
    return this.audit.filter((t) => t.sessionId === sessionId).map(clone);
  }

  async patch(
    sessionId: string,
    patch: Partial<
      Pick<
        Session,
        | "consent"
        | "resumeRef"
        | "topicPlan"
        | "jdFit"
        | "questionBudget"
        | "candidateProfile"
        | "jdGapTopics"
        | "jdFitFingerprint"
        | "focusEvents"
      >
    >,
  ): Promise<Session> {
    const row = this.rows.get(sessionId);
    if (!row) throw new Error(`unknown session ${sessionId}`);
    Object.assign(row, clone(patch));
    row.updatedAt = new Date().toISOString();
    return clone(row);
  }

  // No `await` between the read and the write, so — unlike a caller doing
  // `get()` then `patch()` as two separate awaited calls — nothing else can
  // interleave between them under Node's single-threaded event loop. This is
  // what makes it atomic in-memory the same way the Postgres version is
  // atomic via a single `UPDATE`.
  async appendFocusEvent(sessionId: string, timestamp: string): Promise<{ exitCount: number }> {
    const row = this.rows.get(sessionId);
    if (!row) throw new Error(`unknown session ${sessionId}`);
    row.focusEvents.push({ timestamp });
    row.updatedAt = new Date().toISOString();
    return { exitCount: row.focusEvents.length };
  }

  /** (Stage 7) See `SessionStore.countsByCandidate`. */
  async countsByCandidate(): Promise<Record<string, number>> {
    const counts: Record<string, number> = {};
    for (const row of this.rows.values()) {
      counts[row.candidateId] = (counts[row.candidateId] ?? 0) + 1;
    }
    return counts;
  }
}

/**
 * (Stage 7) In-memory scheduled interviews. Mirrors
 * `PostgresScheduledInterviewStore` port for port.
 */
class MemoryScheduledInterviewStore implements ScheduledInterviewStore {
  private readonly rows = new Map<string, ScheduledInterview>();

  async createMany(rows: ScheduledInterview[]): Promise<ScheduledInterview[]> {
    for (const row of rows) this.rows.set(row.id, clone(row));
    return rows.map(clone);
  }

  async get(id: string): Promise<ScheduledInterview | null> {
    const row = this.rows.get(id);
    return row ? clone(row) : null;
  }

  async list(): Promise<ScheduledInterview[]> {
    return [...this.rows.values()]
      .sort((a, b) => b.scheduledFor.localeCompare(a.scheduledFor))
      .map(clone);
  }

  async listByCandidate(candidateId: string): Promise<ScheduledInterview[]> {
    return [...this.rows.values()]
      .filter((r) => r.candidateId === candidateId)
      .sort((a, b) => b.scheduledFor.localeCompare(a.scheduledFor))
      .map(clone);
  }

  async candidatesWithOpenSchedules(): Promise<string[]> {
    // "Open" is the stored status, not the clock-derived one: a `pending` row
    // whose deadline has quietly passed reads as `missed` to a user but is
    // still an assignment an Admin made and has not withdrawn.
    const open = [...this.rows.values()].filter(
      (r) => r.status === "pending" || r.status === "started",
    );
    return [...new Set(open.map((r) => r.candidateId))];
  }

  async update(
    id: string,
    patch: Partial<Pick<ScheduledInterview, "status" | "sessionId" | "scheduledFor" | "deadline">>,
  ): Promise<ScheduledInterview | null> {
    const row = this.rows.get(id);
    if (!row) return null;
    Object.assign(row, clone(patch));
    row.updatedAt = new Date().toISOString();
    return clone(row);
  }
}

export class MemoryTelemetrySink implements TelemetrySink {
  private readonly events: TelemetryEvent[] = [];

  async emit(
    eventType: TelemetryEventType,
    sessionId: string | null,
    payload: TelemetryPayload,
  ): Promise<TelemetryEvent> {
    const event: TelemetryEvent = {
      id: randomUUID(),
      eventType,
      sessionId,
      payload: sanitizeTelemetryPayload(payload),
      emittedAt: new Date().toISOString(),
    };
    this.events.push(event);
    return clone(event);
  }

  async recent(limit = 100): Promise<TelemetryEvent[]> {
    return this.events.slice(-limit).map(clone);
  }
}

/**
 * Drops forbidden keys and any non-scalar value before an event is stored
 * (INSTRUCTIONS.md §8). Records what was dropped so a leak attempt is visible
 * without the leaked value itself being written.
 */
export function sanitizeTelemetryPayload(payload: TelemetryPayload): TelemetryPayload {
  const out: TelemetryPayload = {};
  const dropped: string[] = [];
  for (const [key, value] of Object.entries(payload ?? {})) {
    const forbidden = (FORBIDDEN_TELEMETRY_KEYS as readonly string[]).includes(key);
    const scalar =
      value === null ||
      typeof value === "string" ||
      typeof value === "number" ||
      typeof value === "boolean";
    if (forbidden || !scalar) {
      dropped.push(key);
      continue;
    }
    out[key] = typeof value === "string" && value.length > 512 ? `${value.slice(0, 512)}…` : value;
  }
  if (dropped.length > 0) out.redacted_keys = dropped.join(",");
  return out;
}

class MemoryLiveSessionStore implements LiveSessionStore {
  private readonly deviceChecks = new Map<string, DeviceCheckResult>();
  private readonly sessionTokens = new Map<string, string>();
  private readonly timers = new Map<string, TimerState>();
  private readonly counters = new Map<string, { count: number; resetAt: number }>();
  private readonly scratch = new Map<string, Map<string, string>>();

  async setSessionScratch(sessionId: string, key: string, value: unknown): Promise<void> {
    const bucket = this.scratch.get(sessionId) ?? new Map<string, string>();
    // Serialised, so the in-memory driver cannot hand a caller a live reference
    // that Redis would have given them a copy of.
    bucket.set(key, JSON.stringify(value));
    this.scratch.set(sessionId, bucket);
  }
  async getSessionScratch<T = unknown>(sessionId: string, key: string): Promise<T | null> {
    const raw = this.scratch.get(sessionId)?.get(key);
    return raw === undefined ? null : (JSON.parse(raw) as T);
  }
  async clearSessionScratch(sessionId: string): Promise<void> {
    this.scratch.delete(sessionId);
  }

  async setDeviceCheck(sessionId: string, result: DeviceCheckResult): Promise<void> {
    this.deviceChecks.set(sessionId, { ...result });
  }
  async getDeviceCheck(sessionId: string): Promise<DeviceCheckResult | null> {
    return this.deviceChecks.get(sessionId) ?? null;
  }
  async setSessionToken(sessionId: string, token: string): Promise<void> {
    this.sessionTokens.set(sessionId, token);
  }
  async getSessionToken(sessionId: string): Promise<string | null> {
    return this.sessionTokens.get(sessionId) ?? null;
  }
  async saveTimer(state: TimerState): Promise<void> {
    this.timers.set(state.segmentId, { ...state });
  }
  async loadTimer(segmentId: string): Promise<TimerState | null> {
    const timer = this.timers.get(segmentId);
    return timer ? { ...timer } : null;
  }
  async clearTimer(segmentId: string): Promise<void> {
    this.timers.delete(segmentId);
  }
  async incrementRateCounter(key: string, windowMs: number): Promise<number> {
    const now = Date.now();
    const existing = this.counters.get(key);
    if (!existing || existing.resetAt <= now) {
      this.counters.set(key, { count: 1, resetAt: now + windowMs });
      return 1;
    }
    existing.count += 1;
    return existing.count;
  }
  async close(): Promise<void> {
    /* nothing to release */
  }
}

export function createMemoryStorage(): Storage {
  const live = new MemoryLiveSessionStore();
  const questions = new MemoryQuestionStore();
  const answers = new MemoryAnswerStore();
  return {
    users: new MemoryUserStore(),
    sessions: new MemorySessionStore(),
    resets: new MemoryResetTokenStore(),
    telemetry: new MemoryTelemetrySink(),
    live,
    files: new MemoryFileStore(),
    questions,
    answers,
    evaluations: new MemoryEvaluationStore(questions, answers),
    reports: new MemoryReportStore(),
    scheduled: new MemoryScheduledInterviewStore(),
    close: () => live.close(),
  };
}

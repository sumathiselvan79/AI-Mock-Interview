/**
 * Google OAuth profile store — same two-driver pattern as `archive.ts`:
 * `memory` for a run with no infra, `supabase` for the real thing, both
 * satisfying the `OAuthProfileStore` port so route/auth code never branches
 * on which one is live.
 *
 * `pg` rather than `@supabase/supabase-js`, for the same reason `archive.ts`
 * uses it: a plain server-side connection over the service-role credential is
 * the access boundary this system already relies on for the archive table,
 * and there is no reason for this table to answer to a different model.
 */

import pg from "pg";
import type { OAuthProfile, OAuthProfileStore } from "@mia/shared-types";

export class MemoryOAuthProfileStore implements OAuthProfileStore {
  private readonly rows = new Map<string, OAuthProfile>();

  async upsert(profile: OAuthProfile): Promise<OAuthProfile> {
    this.rows.set(profile.userId, structuredClone(profile));
    return structuredClone(profile);
  }

  async getByUserId(userId: string): Promise<OAuthProfile | null> {
    const row = this.rows.get(userId);
    return row ? structuredClone(row) : null;
  }

  async close(): Promise<void> {
    /* nothing to release */
  }
}

interface OAuthProfileRow {
  user_id: string;
  provider: string;
  provider_subject: string;
  email: string;
  name: string | null;
  avatar_url: string | null;
  linked_at: Date;
}

export class SupabaseOAuthProfileStore implements OAuthProfileStore {
  constructor(private readonly pool: pg.Pool) {}

  static connect(connectionString: string): SupabaseOAuthProfileStore {
    return new SupabaseOAuthProfileStore(
      new pg.Pool({
        connectionString,
        // Supabase terminates TLS with a certificate chain the default Node
        // trust store does not carry; the connection is still encrypted.
        ssl: { rejectUnauthorized: false },
        max: 4,
      }),
    );
  }

  async upsert(profile: OAuthProfile): Promise<OAuthProfile> {
    const { rows } = await this.pool.query<OAuthProfileRow>(
      `INSERT INTO oauth_profiles
         (user_id, provider, provider_subject, email, name, avatar_url, linked_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       ON CONFLICT (user_id, provider) DO UPDATE
         SET provider_subject = EXCLUDED.provider_subject,
             email            = EXCLUDED.email,
             name             = EXCLUDED.name,
             avatar_url       = EXCLUDED.avatar_url,
             linked_at        = EXCLUDED.linked_at
       RETURNING *`,
      [
        profile.userId,
        profile.provider,
        profile.providerSubject,
        profile.email,
        profile.name ?? null,
        profile.avatarUrl ?? null,
        profile.linkedAt,
      ],
    );
    return toProfile(rows[0] as OAuthProfileRow);
  }

  async getByUserId(userId: string): Promise<OAuthProfile | null> {
    const { rows } = await this.pool.query<OAuthProfileRow>(
      `SELECT * FROM oauth_profiles WHERE user_id = $1`,
      [userId],
    );
    return rows[0] ? toProfile(rows[0]) : null;
  }

  async close(): Promise<void> {
    await this.pool.end();
  }
}

function toProfile(row: OAuthProfileRow): OAuthProfile {
  return {
    userId: row.user_id,
    provider: row.provider as "google",
    providerSubject: row.provider_subject,
    email: row.email,
    ...(row.name ? { name: row.name } : {}),
    ...(row.avatar_url ? { avatarUrl: row.avatar_url } : {}),
    linkedAt: row.linked_at.toISOString(),
  };
}

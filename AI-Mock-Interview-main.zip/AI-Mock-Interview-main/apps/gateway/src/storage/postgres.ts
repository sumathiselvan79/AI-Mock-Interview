/**
 * Postgres storage driver. Mirrors `memory.ts` port-for-port, including the
 * Harness-Agent-only state write — enforced here in application code *and*
 * again by the CHECK constraint on `session_state_transitions.actor`.
 */

import pg from "pg";
import {
  DEFAULT_CONSENT,
  DEFAULT_QUESTION_BUDGET,
  type FocusEvent,
  type PasscodeResetToken,
  type Session,
  type SessionState,
  type SessionStateTransition,
  type SessionStore,
  type StateWriteGrant,
  type TelemetryEvent,
  type TelemetryEventType,
  type TelemetryPayload,
  type TelemetrySink,
  type User,
  type UserProfile,
} from "@mia/shared-types";
import { StateWriteForbidden, sanitizeTelemetryPayload } from "./memory.js";
import type { ResetTokenStore, UserStore } from "./types.js";

type Pool = pg.Pool;

interface UserRow {
  id: string;
  email: string;
  role: User["role"];
  passcode_hash: string;
  cross_session_memory_opt_in: boolean;
  full_name: string | null;
  department: string | null;
  program_year: string | null;
  created_at: Date;
}

const toUser = (row: UserRow): User => ({
  id: row.id,
  email: row.email,
  role: row.role,
  passcodeHash: row.passcode_hash,
  crossSessionMemoryOptIn: row.cross_session_memory_opt_in,
  ...(row.full_name ? { fullName: row.full_name } : {}),
  ...(row.department ? { department: row.department } : {}),
  ...(row.program_year ? { programYear: row.program_year } : {}),
  createdAt: row.created_at.toISOString(),
});

/** A whitespace-only profile field is not a value; it must not overwrite one. */
const blankToNull = (value: string | undefined): string | null =>
  value && value.trim().length > 0 ? value.trim() : null;

export class PostgresUserStore implements UserStore {
  constructor(private readonly pool: Pool) {}

  async create(input: {
    email: string;
    role: User["role"];
    passcodeHash: string;
    crossSessionMemoryOptIn?: boolean;
    profile?: UserProfile;
  }): Promise<User> {
    const { rows } = await this.pool.query<UserRow>(
      `INSERT INTO users (email, role, passcode_hash, cross_session_memory_opt_in, full_name, department, program_year)
       VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
      [
        input.email.trim().toLowerCase(),
        input.role,
        input.passcodeHash,
        input.crossSessionMemoryOptIn ?? false,
        blankToNull(input.profile?.fullName),
        blankToNull(input.profile?.department),
        blankToNull(input.profile?.programYear),
      ],
    );
    return toUser(rows[0] as UserRow);
  }

  /**
   * (Stage 5, §11.4) COALESCE so an absent key keeps whatever is stored — a
   * partial profile update must not blank a field the candidate already gave.
   */
  async updateProfile(userId: string, profile: UserProfile): Promise<User> {
    const { rows } = await this.pool.query<UserRow>(
      `UPDATE users
          SET full_name    = COALESCE($2, full_name),
              department   = COALESCE($3, department),
              program_year = COALESCE($4, program_year)
        WHERE id = $1
      RETURNING *`,
      [
        userId,
        blankToNull(profile.fullName),
        blankToNull(profile.department),
        blankToNull(profile.programYear),
      ],
    );
    if (!rows[0]) throw new Error(`unknown user ${userId}`);
    return toUser(rows[0]);
  }

  async findByEmail(email: string): Promise<User | null> {
    const { rows } = await this.pool.query<UserRow>(`SELECT * FROM users WHERE email = $1`, [
      email.trim().toLowerCase(),
    ]);
    return rows[0] ? toUser(rows[0]) : null;
  }

  async findById(id: string): Promise<User | null> {
    const { rows } = await this.pool.query<UserRow>(`SELECT * FROM users WHERE id = $1`, [id]);
    return rows[0] ? toUser(rows[0]) : null;
  }

  async updatePasscodeHash(userId: string, passcodeHash: string): Promise<void> {
    await this.pool.query(`UPDATE users SET passcode_hash = $2 WHERE id = $1`, [userId, passcodeHash]);
  }

  async upsertIdentity(input: {
    email: string;
    role: User["role"];
    unusablePasscodeHash: string;
  }): Promise<User> {
    // ON CONFLICT only ever touches `role`. A row that already exists — say,
    // a passcode account whose email later lands on the admin allowlist —
    // keeps its real passcode_hash; the random one here is only ever stored
    // on the INSERT branch, for a brand-new identity-only row.
    const { rows } = await this.pool.query<UserRow>(
      `INSERT INTO users (email, role, passcode_hash)
       VALUES ($1, $2, $3)
       ON CONFLICT (email) DO UPDATE SET role = EXCLUDED.role
       RETURNING *`,
      [input.email.trim().toLowerCase(), input.role, input.unusablePasscodeHash],
    );
    return toUser(rows[0] as UserRow);
  }

  async rawRow(userId: string): Promise<Record<string, unknown> | null> {
    const { rows } = await this.pool.query(`SELECT * FROM users WHERE id = $1`, [userId]);
    return (rows[0] as Record<string, unknown> | undefined) ?? null;
  }

  /** (Stage 7) See `UserStore.listByRole`. */
  async listByRole(role: User["role"]): Promise<User[]> {
    const { rows } = await this.pool.query<UserRow>(
      `SELECT * FROM users WHERE role = $1 ORDER BY created_at`,
      [role],
    );
    return rows.map(toUser);
  }
}

export class PostgresResetTokenStore implements ResetTokenStore {
  constructor(private readonly pool: Pool) {}

  async create(userId: string, tokenHash: string, expiresAt: string): Promise<PasscodeResetToken> {
    await this.pool.query(
      `UPDATE passcode_reset_tokens SET used_at = now() WHERE user_id = $1 AND used_at IS NULL`,
      [userId],
    );
    const { rows } = await this.pool.query(
      `INSERT INTO passcode_reset_tokens (user_id, token_hash, expires_at)
       VALUES ($1, $2, $3) RETURNING id, user_id, token_hash, expires_at, used_at`,
      [userId, tokenHash, expiresAt],
    );
    const row = rows[0] as {
      id: string;
      user_id: string;
      token_hash: string;
      expires_at: Date;
      used_at: Date | null;
    };
    return {
      id: row.id,
      userId: row.user_id,
      tokenHash: row.token_hash,
      expiresAt: row.expires_at.toISOString(),
      usedAt: row.used_at ? row.used_at.toISOString() : null,
    };
  }

  async findValidByHash(tokenHash: string, now: Date): Promise<PasscodeResetToken | null> {
    const { rows } = await this.pool.query(
      `SELECT id, user_id, token_hash, expires_at, used_at FROM passcode_reset_tokens
       WHERE token_hash = $1 AND used_at IS NULL AND expires_at > $2`,
      [tokenHash, now.toISOString()],
    );
    const row = rows[0] as
      | { id: string; user_id: string; token_hash: string; expires_at: Date; used_at: Date | null }
      | undefined;
    if (!row) return null;
    return {
      id: row.id,
      userId: row.user_id,
      tokenHash: row.token_hash,
      expiresAt: row.expires_at.toISOString(),
      usedAt: null,
    };
  }

  async markUsed(id: string, at: string): Promise<void> {
    await this.pool.query(`UPDATE passcode_reset_tokens SET used_at = $2 WHERE id = $1`, [id, at]);
  }
}

interface SessionRow {
  id: string;
  candidate_id: string;
  role: string;
  job_description: string;
  jd_fit: Session["jdFit"];
  state: SessionState;
  consent: Session["consent"];
  question_budget: number;
  resume_ref: string | null;
  candidate_profile: Session["candidateProfile"];
  jd_gap_topics: string[] | null;
  jd_fit_fingerprint: string | null;
  focus_events: FocusEvent[] | null;
  created_at: Date;
  updated_at: Date;
}

export class PostgresSessionStore implements SessionStore {
  private grant: StateWriteGrant | null = null;

  constructor(private readonly pool: Pool) {}

  registerStateWriter(grant: StateWriteGrant): void {
    if (this.grant && this.grant.token !== grant.token) {
      throw new StateWriteForbidden("a state writer is already registered for this store");
    }
    if (grant.actor !== "harness-agent") {
      throw new StateWriteForbidden(`state writer must be harness-agent, got ${grant.actor}`);
    }
    this.grant = grant;
  }

  private async hydrate(row: SessionRow): Promise<Session> {
    const { rows: planRows } = await this.pool.query(
      `SELECT topic, max_questions, source FROM topic_plan_entries WHERE session_id = $1 ORDER BY topic`,
      [row.id],
    );
    return {
      id: row.id,
      candidateId: row.candidate_id,
      role: row.role,
      jobDescription: row.job_description,
      jdFit: row.jd_fit,
      state: row.state,
      // Merge onto DEFAULT_CONSENT so a row written before `focusLossMonitoring`
      // existed hydrates as `false` for it rather than `undefined`.
      consent: { ...DEFAULT_CONSENT, ...row.consent },
      questionBudget: row.question_budget,
      topicPlan: (planRows as { topic: string; max_questions: number; source: string }[]).map((p) => ({
        topic: p.topic,
        maxQuestions: p.max_questions,
        source: p.source as Session["topicPlan"][number]["source"],
      })),
      resumeRef: row.resume_ref,
      candidateProfile: row.candidate_profile ?? null,
      jdGapTopics: row.jd_gap_topics ?? [],
      jdFitFingerprint: row.jd_fit_fingerprint ?? null,
      focusEvents: row.focus_events ?? [],
      createdAt: row.created_at.toISOString(),
      updatedAt: row.updated_at.toISOString(),
    };
  }

  async create(input: {
    candidateId: string;
    role: string;
    jobDescription: string;
    questionBudget?: number;
  }): Promise<Session> {
    const { rows } = await this.pool.query<SessionRow>(
      `INSERT INTO sessions (candidate_id, role, job_description, question_budget)
       VALUES ($1, $2, $3, $4) RETURNING *`,
      [input.candidateId, input.role, input.jobDescription, input.questionBudget ?? DEFAULT_QUESTION_BUDGET],
    );
    return this.hydrate(rows[0] as SessionRow);
  }

  async get(sessionId: string): Promise<Session | null> {
    const { rows } = await this.pool.query<SessionRow>(`SELECT * FROM sessions WHERE id = $1`, [sessionId]);
    return rows[0] ? this.hydrate(rows[0]) : null;
  }

  async listByCandidate(candidateId: string): Promise<Session[]> {
    const { rows } = await this.pool.query<SessionRow>(
      `SELECT * FROM sessions WHERE candidate_id = $1 ORDER BY created_at DESC`,
      [candidateId],
    );
    return Promise.all(rows.map((r) => this.hydrate(r)));
  }

  async setState(
    sessionId: string,
    toState: SessionState,
    grant: StateWriteGrant,
    reason: string,
  ): Promise<Session> {
    if (!this.grant || !grant || grant.token !== this.grant.token || grant.actor !== "harness-agent") {
      throw new StateWriteForbidden(
        "Session.state may only be written by the Harness Agent (INSTRUCTIONS.md §3)",
      );
    }
    const client = await this.pool.connect();
    try {
      await client.query("BEGIN");
      const { rows } = await client.query<SessionRow>(
        `SELECT * FROM sessions WHERE id = $1 FOR UPDATE`,
        [sessionId],
      );
      const current = rows[0];
      if (!current) throw new Error(`unknown session ${sessionId}`);

      await client.query(
        `INSERT INTO session_state_transitions (session_id, from_state, to_state, actor, reason)
         VALUES ($1, $2, $3, $4, $5)`,
        [sessionId, current.state, toState, grant.actor, reason],
      );
      const { rows: updated } = await client.query<SessionRow>(
        `UPDATE sessions SET state = $2, updated_at = now() WHERE id = $1 RETURNING *`,
        [sessionId, toState],
      );
      await client.query("COMMIT");
      return this.hydrate(updated[0] as SessionRow);
    } catch (err) {
      await client.query("ROLLBACK");
      throw err;
    } finally {
      client.release();
    }
  }

  async transitions(sessionId: string): Promise<SessionStateTransition[]> {
    const { rows } = await this.pool.query(
      `SELECT id, session_id, from_state, to_state, actor, reason, at
       FROM session_state_transitions WHERE session_id = $1 ORDER BY at`,
      [sessionId],
    );
    return (
      rows as {
        id: string;
        session_id: string;
        from_state: SessionState;
        to_state: SessionState;
        actor: string;
        reason: string;
        at: Date;
      }[]
    ).map((r) => ({
      id: r.id,
      sessionId: r.session_id,
      fromState: r.from_state,
      toState: r.to_state,
      actor: r.actor,
      reason: r.reason,
      at: r.at.toISOString(),
    }));
  }

  async patch(
    sessionId: string,
    patch: Partial<
      Pick<
        Session,
        | "consent"
        | "resumeRef"
        | "topicPlan"
        | "jdFit"
        | "questionBudget"
        | "candidateProfile"
        | "jdGapTopics"
        | "jdFitFingerprint"
        | "focusEvents"
      >
    >,
  ): Promise<Session> {
    const sets: string[] = [];
    const values: unknown[] = [sessionId];
    const push = (fragment: string, value: unknown) => {
      values.push(value);
      sets.push(`${fragment} = $${values.length}`);
    };

    if (patch.consent !== undefined) push("consent", JSON.stringify(patch.consent));
    if (patch.resumeRef !== undefined) push("resume_ref", patch.resumeRef);
    if (patch.jdFit !== undefined) push("jd_fit", JSON.stringify(patch.jdFit));
    if (patch.questionBudget !== undefined) push("question_budget", patch.questionBudget);
    if (patch.candidateProfile !== undefined) {
      push("candidate_profile", JSON.stringify(patch.candidateProfile));
    }
    if (patch.jdGapTopics !== undefined) push("jd_gap_topics", JSON.stringify(patch.jdGapTopics));
    if (patch.jdFitFingerprint !== undefined) push("jd_fit_fingerprint", patch.jdFitFingerprint);
    if (patch.focusEvents !== undefined) push("focus_events", JSON.stringify(patch.focusEvents));

    if (sets.length > 0) {
      await this.pool.query(
        `UPDATE sessions SET ${sets.join(", ")}, updated_at = now() WHERE id = $1`,
        values,
      );
    }

    if (patch.topicPlan !== undefined) {
      await this.pool.query(`DELETE FROM topic_plan_entries WHERE session_id = $1`, [sessionId]);
      for (const entry of patch.topicPlan) {
        await this.pool.query(
          `INSERT INTO topic_plan_entries (session_id, topic, max_questions, source)
           VALUES ($1, $2, $3, $4)`,
          [sessionId, entry.topic, entry.maxQuestions, entry.source],
        );
      }
    }

    const session = await this.get(sessionId);
    if (!session) throw new Error(`unknown session ${sessionId}`);
    return session;
  }

  /**
   * A single `UPDATE ... focus_events = focus_events || $2` rather than this
   * class's own `get()` then `patch()` — Postgres applies that append and
   * recomputes the row atomically per statement, so two exits recorded in the
   * same instant still both land instead of the second write clobbering the
   * first's read-before-write.
   */
  async appendFocusEvent(sessionId: string, timestamp: string): Promise<{ exitCount: number }> {
    const { rows } = await this.pool.query<{ exit_count: number }>(
      `UPDATE sessions
       SET focus_events = focus_events || $2::jsonb, updated_at = now()
       WHERE id = $1
       RETURNING jsonb_array_length(focus_events) AS exit_count`,
      [sessionId, JSON.stringify([{ timestamp }])],
    );
    const row = rows[0];
    if (!row) throw new Error(`unknown session ${sessionId}`);
    return { exitCount: row.exit_count };
  }

  /** (Stage 7) See `SessionStore.countsByCandidate` — one GROUP BY, not N queries. */
  async countsByCandidate(): Promise<Record<string, number>> {
    const { rows } = await this.pool.query<{ candidate_id: string; count: string }>(
      `SELECT candidate_id, COUNT(*)::text AS count FROM sessions GROUP BY candidate_id`,
    );
    return Object.fromEntries(rows.map((r) => [r.candidate_id, Number(r.count)]));
  }
}

export class PostgresTelemetrySink implements TelemetrySink {
  constructor(private readonly pool: Pool) {}

  async emit(
    eventType: TelemetryEventType,
    sessionId: string | null,
    payload: TelemetryPayload,
  ): Promise<TelemetryEvent> {
    const safe = sanitizeTelemetryPayload(payload);
    const { rows } = await this.pool.query(
      `INSERT INTO telemetry_events (event_type, session_id, payload)
       VALUES ($1, $2, $3) RETURNING id, emitted_at`,
      [eventType, sessionId, JSON.stringify(safe)],
    );
    const row = rows[0] as { id: string; emitted_at: Date };
    return { id: row.id, eventType, sessionId, payload: safe, emittedAt: row.emitted_at.toISOString() };
  }

  async recent(limit = 100): Promise<TelemetryEvent[]> {
    const { rows } = await this.pool.query(
      `SELECT id, event_type, session_id, payload, emitted_at
       FROM telemetry_events ORDER BY emitted_at DESC LIMIT $1`,
      [limit],
    );
    return (
      rows as {
        id: string;
        event_type: TelemetryEventType;
        session_id: string | null;
        payload: TelemetryPayload;
        emitted_at: Date;
      }[]
    )
      .map((r) => ({
        id: r.id,
        eventType: r.event_type,
        sessionId: r.session_id,
        payload: r.payload,
        emittedAt: r.emitted_at.toISOString(),
      }))
      .reverse();
  }
}

export function createPool(databaseUrl: string): Pool {
  return new pg.Pool({ connectionString: databaseUrl });
}

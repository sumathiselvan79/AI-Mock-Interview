import type { GatewayConfig } from "../config.js";
import { createMemoryStorage } from "./memory.js";
import { DiskFileStore } from "./files.js";
import {
  PostgresResetTokenStore,
  PostgresSessionStore,
  PostgresTelemetrySink,
  PostgresUserStore,
  createPool,
} from "./postgres.js";
import {
  PostgresAnswerStore,
  PostgresEvaluationStore,
  PostgresQuestionStore,
  PostgresReportStore,
} from "./interview-postgres.js";
import { PostgresScheduledInterviewStore } from "./scheduled-postgres.js";
import { RedisLiveSessionStore } from "./redis.js";
import { MemorySessionArchiveStore, SupabaseSessionArchiveStore } from "./archive.js";
import { MemoryOAuthProfileStore, SupabaseOAuthProfileStore } from "./oauth-profiles.js";
import type { Storage } from "./types.js";

export * from "./types.js";
export { createMemoryStorage, StateWriteForbidden, sanitizeTelemetryPayload } from "./memory.js";
export { DiskFileStore, MemoryFileStore } from "./files.js";
export { MemorySessionArchiveStore, SupabaseSessionArchiveStore } from "./archive.js";
export { MemoryOAuthProfileStore, SupabaseOAuthProfileStore } from "./oauth-profiles.js";

/**
 * `STORAGE_DRIVER=memory` (the default in dev and in tests) keeps the whole
 * gateway runnable with no infrastructure; `postgres` wires the real thing.
 * Both satisfy the same ports, so route and agent code never branches on it.
 */
export async function createStorage(config: GatewayConfig): Promise<Storage> {
  if (config.storageDriver === "memory") {
    // (Stage 5) The archive is in-memory here too, so the archive-ordering and
    // archive-RBAC gates run with no second database — and so a `npm run dev`
    // session still exercises the archive path end to end. Same reasoning for
    // the OAuth profile snapshot.
    return {
      ...createMemoryStorage(),
      archives: new MemorySessionArchiveStore(),
      oauthProfiles: new MemoryOAuthProfileStore(),
    };
  }

  const pool = createPool(config.databaseUrl);
  const live = await RedisLiveSessionStore.connect(config.redisUrl);

  // (Stage 5, §11.4) A SEPARATE instance from `databaseUrl`, always. Absent, the
  // gateway runs without archiving rather than quietly filing archives into the
  // primary database the retention job prunes. The OAuth profile snapshot
  // lives in the same Supabase instance, behind the same absence behavior:
  // Google sign-in still works, it just skips recording the snapshot.
  const archives = config.supabaseDbUrl
    ? SupabaseSessionArchiveStore.connect(config.supabaseDbUrl)
    : undefined;
  const oauthProfiles = config.supabaseDbUrl
    ? SupabaseOAuthProfileStore.connect(config.supabaseDbUrl)
    : undefined;

  return {
    users: new PostgresUserStore(pool),
    sessions: new PostgresSessionStore(pool),
    resets: new PostgresResetTokenStore(pool),
    telemetry: new PostgresTelemetrySink(pool),
    live,
    files: new DiskFileStore(config.uploadDir),
    questions: new PostgresQuestionStore(pool),
    answers: new PostgresAnswerStore(pool),
    evaluations: new PostgresEvaluationStore(pool),
    reports: new PostgresReportStore(pool),
    scheduled: new PostgresScheduledInterviewStore(pool),
    ...(archives ? { archives } : {}),
    ...(oauthProfiles ? { oauthProfiles } : {}),
    close: async () => {
      await live.close();
      await archives?.close();
      await oauthProfiles?.close();
      await pool.end();
    },
  };
}

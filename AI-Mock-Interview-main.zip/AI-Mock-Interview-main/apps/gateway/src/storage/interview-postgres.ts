/**
 * Postgres question/answer/evaluation stores. Same ports as the in-memory
 * driver in `interview-memory.ts`.
 */

import pg from "pg";
import type {
  Answer,
  AnswerStore,
  CandidateReportAggregate,
  Evaluation,
  EvaluationStore,
  Question,
  QuestionStore,
  Report,
  ReportStore,
} from "@mia/shared-types";
import { REDACTED_TRANSCRIPT } from "@mia/shared-types";

type Pool = pg.Pool;

interface QuestionRow {
  id: string;
  bank_id: string;
  session_id: string;
  text: string;
  audio_url: string | null;
  topic: string;
  type: Question["type"];
  difficulty: number;
  tier: number | null;
  target_concept_ids: string[] | null;
  quota_override: boolean;
  prompt_version: string | null;
  asked_at: Date;
}

const toQuestion = (row: QuestionRow): Question => ({
  id: row.id,
  bankId: row.bank_id,
  sessionId: row.session_id,
  text: row.text,
  ...(row.audio_url ? { audioUrl: row.audio_url } : {}),
  topic: row.topic,
  type: row.type,
  difficulty: row.difficulty,
  ...(row.tier === null ? {} : { tier: row.tier as 1 | 2 | 3 }),
  ...(row.target_concept_ids ? { targetConceptIds: row.target_concept_ids } : {}),
  quotaOverride: row.quota_override,
  ...(row.prompt_version ? { promptVersion: row.prompt_version } : {}),
  askedAt: row.asked_at.toISOString(),
});

export class PostgresQuestionStore implements QuestionStore {
  constructor(private readonly pool: Pool) {}

  async append(question: Question): Promise<Question> {
    const { rows } = await this.pool.query<QuestionRow>(
      `INSERT INTO questions (id, bank_id, session_id, text, audio_url, topic, type, difficulty, tier, target_concept_ids, quota_override, prompt_version, asked_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13) RETURNING *`,
      [
        question.id,
        question.bankId,
        question.sessionId,
        question.text,
        question.audioUrl ?? null,
        question.topic,
        question.type,
        question.difficulty,
        question.tier ?? null,
        question.targetConceptIds ?? null,
        question.quotaOverride ?? false,
        question.promptVersion ?? null,
        question.askedAt,
      ],
    );
    return toQuestion(rows[0] as QuestionRow);
  }

  async get(questionId: string): Promise<Question | null> {
    const { rows } = await this.pool.query<QuestionRow>(`SELECT * FROM questions WHERE id = $1`, [questionId]);
    return rows[0] ? toQuestion(rows[0]) : null;
  }

  async listBySession(sessionId: string): Promise<Question[]> {
    const { rows } = await this.pool.query<QuestionRow>(
      `SELECT * FROM questions WHERE session_id = $1 ORDER BY asked_at`,
      [sessionId],
    );
    return rows.map(toQuestion);
  }
}

interface AnswerRow {
  id: string;
  question_id: string;
  transcript: string;
  transcript_confidence: number | null;
  follow_ups: Answer["followUps"];
  extraction: Answer["extraction"] | null;
  next_action: Answer["nextAction"] | null;
  submitted_at: Date;
}

const toAnswer = (row: AnswerRow): Answer => ({
  id: row.id,
  questionId: row.question_id,
  transcript: row.transcript,
  ...(row.transcript_confidence === null ? {} : { transcriptConfidence: row.transcript_confidence }),
  followUps: row.follow_ups,
  ...(row.extraction ? { extraction: row.extraction } : {}),
  ...(row.next_action ? { nextAction: row.next_action } : {}),
  submittedAt: row.submitted_at.toISOString(),
});

export class PostgresAnswerStore implements AnswerStore {
  constructor(private readonly pool: Pool) {}

  async append(answer: Answer): Promise<Answer> {
    const { rows } = await this.pool.query<AnswerRow>(
      `INSERT INTO answers (id, question_id, transcript, transcript_confidence, follow_ups, submitted_at)
       VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
      [
        answer.id,
        answer.questionId,
        answer.transcript,
        answer.transcriptConfidence ?? null,
        JSON.stringify(answer.followUps),
        answer.submittedAt,
      ],
    );
    return toAnswer(rows[0] as AnswerRow);
  }

  async get(answerId: string): Promise<Answer | null> {
    const { rows } = await this.pool.query<AnswerRow>(`SELECT * FROM answers WHERE id = $1`, [answerId]);
    return rows[0] ? toAnswer(rows[0]) : null;
  }

  async getByQuestion(questionId: string): Promise<Answer | null> {
    const { rows } = await this.pool.query<AnswerRow>(
      `SELECT * FROM answers WHERE question_id = $1 ORDER BY submitted_at LIMIT 1`,
      [questionId],
    );
    return rows[0] ? toAnswer(rows[0]) : null;
  }

  async appendFollowUp(answerId: string, followUp: { text: string; transcript: string }): Promise<Answer> {
    const { rows } = await this.pool.query<AnswerRow>(
      `UPDATE answers SET follow_ups = follow_ups || $2::jsonb WHERE id = $1 RETURNING *`,
      [answerId, JSON.stringify([followUp])],
    );
    if (!rows[0]) throw new Error(`unknown answer ${answerId}`);
    return toAnswer(rows[0]);
  }

  /**
   * (Stage 5, §11.2) Writes the score onto one `follow_ups[]` element in place.
   * `jsonb_set` rather than a read-modify-write of the whole array, so a
   * concurrent `appendFollowUp` cannot lose the score it just wrote.
   */
  async scoreFollowUp(
    answerId: string,
    index: number,
    score: NonNullable<Answer["followUps"][number]["score"]>,
  ): Promise<Answer> {
    const { rows } = await this.pool.query<AnswerRow>(
      `UPDATE answers
          SET follow_ups = jsonb_set(follow_ups, ARRAY[$2::text, 'score'], $3::jsonb, true)
        WHERE id = $1
          AND jsonb_array_length(follow_ups) > $2::int
      RETURNING *`,
      [answerId, String(index), JSON.stringify(score)],
    );
    if (!rows[0]) throw new Error(`answer ${answerId} has no follow-up at index ${index}`);
    return toAnswer(rows[0]);
  }

  /** (Stage 6, §4.4) See `AnswerStore.recordExtraction` — an enrichment write, never a gate. */
  async recordExtraction(
    answerId: string,
    extraction: NonNullable<Answer["extraction"]>,
    nextAction: NonNullable<Answer["nextAction"]>,
  ): Promise<Answer> {
    const { rows } = await this.pool.query<AnswerRow>(
      `UPDATE answers SET extraction = $2::jsonb, next_action = $3::jsonb WHERE id = $1 RETURNING *`,
      [answerId, JSON.stringify(extraction), JSON.stringify(nextAction)],
    );
    if (!rows[0]) throw new Error(`unknown answer ${answerId}`);
    return toAnswer(rows[0]);
  }

  async redact(answerId: string): Promise<Answer> {
    const existing = await this.get(answerId);
    if (!existing) throw new Error(`unknown answer ${answerId}`);
    const redactedFollowUps = existing.followUps.map((f) => ({ ...f, transcript: REDACTED_TRANSCRIPT }));

    const { rows } = await this.pool.query<AnswerRow>(
      `UPDATE answers SET transcript = $2, follow_ups = $3::jsonb WHERE id = $1 RETURNING *`,
      [answerId, REDACTED_TRANSCRIPT, JSON.stringify(redactedFollowUps)],
    );
    if (!rows[0]) throw new Error(`unknown answer ${answerId}`);
    return toAnswer(rows[0]);
  }
}

interface EvaluationRow {
  id: string;
  answer_id: string;
  rubric_id: string;
  score: number;
  rationale: string;
  evidence_spans: { start: number; end: number }[];
  prompt_version: string | null;
  created_at: Date;
}

const toEvaluation = (row: EvaluationRow): Evaluation => ({
  id: row.id,
  answerId: row.answer_id,
  rubricId: row.rubric_id,
  score: row.score,
  rationale: row.rationale,
  evidenceSpans: row.evidence_spans,
  ...(row.prompt_version ? { promptVersion: row.prompt_version } : {}),
  createdAt: row.created_at.toISOString(),
});

export class PostgresEvaluationStore implements EvaluationStore {
  constructor(private readonly pool: Pool) {}

  async append(evaluation: Evaluation): Promise<Evaluation> {
    const { rows } = await this.pool.query<EvaluationRow>(
      `INSERT INTO evaluations (id, answer_id, rubric_id, score, rationale, evidence_spans, prompt_version, created_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
      [
        evaluation.id,
        evaluation.answerId,
        evaluation.rubricId,
        evaluation.score,
        evaluation.rationale,
        JSON.stringify(evaluation.evidenceSpans),
        evaluation.promptVersion ?? null,
        evaluation.createdAt,
      ],
    );
    return toEvaluation(rows[0] as EvaluationRow);
  }

  async listByAnswer(answerId: string): Promise<Evaluation[]> {
    const { rows } = await this.pool.query<EvaluationRow>(
      `SELECT * FROM evaluations WHERE answer_id = $1 ORDER BY created_at`,
      [answerId],
    );
    return rows.map(toEvaluation);
  }

  async listBySession(sessionId: string): Promise<Evaluation[]> {
    const { rows } = await this.pool.query<EvaluationRow>(
      `SELECT e.* FROM evaluations e
         JOIN answers a ON a.id = e.answer_id
         JOIN questions q ON q.id = a.question_id
        WHERE q.session_id = $1
        ORDER BY e.created_at`,
      [sessionId],
    );
    return rows.map(toEvaluation);
  }
}

interface ReportRow {
  session_id: string;
  candidate_id: string;
  competency_scores: Report["competencyScores"];
  strengths: string[];
  focus_areas: string[];
  browser_activity: Report["browserActivity"] | null;
  disclaimer: string;
  created_at: Date;
}

const DEFAULT_BROWSER_ACTIVITY: Report["browserActivity"] = { exitCount: 0, events: [], concludedEarly: false };

const toReport = (row: ReportRow): Report => ({
  sessionId: row.session_id,
  candidateId: row.candidate_id,
  competencyScores: row.competency_scores,
  strengths: row.strengths,
  focusAreas: row.focus_areas,
  browserActivity: row.browser_activity ?? DEFAULT_BROWSER_ACTIVITY,
  disclaimer: row.disclaimer,
  createdAt: row.created_at.toISOString(),
});

export class PostgresReportStore implements ReportStore {
  constructor(private readonly pool: Pool) {}

  async create(report: Report): Promise<Report> {
    const { rows } = await this.pool.query<ReportRow>(
      `INSERT INTO reports (session_id, candidate_id, competency_scores, strengths, focus_areas, browser_activity, disclaimer, created_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
      [
        report.sessionId,
        report.candidateId,
        JSON.stringify(report.competencyScores),
        JSON.stringify(report.strengths),
        JSON.stringify(report.focusAreas),
        JSON.stringify(report.browserActivity),
        report.disclaimer,
        report.createdAt,
      ],
    );
    return toReport(rows[0] as ReportRow);
  }

  async getBySession(sessionId: string): Promise<Report | null> {
    const { rows } = await this.pool.query<ReportRow>(`SELECT * FROM reports WHERE session_id = $1`, [sessionId]);
    return rows[0] ? toReport(rows[0]) : null;
  }

  async listByCandidate(candidateId: string): Promise<Report[]> {
    const { rows } = await this.pool.query<ReportRow>(
      `SELECT * FROM reports WHERE candidate_id = $1 ORDER BY created_at DESC`,
      [candidateId],
    );
    return rows.map(toReport);
  }

  async listAll(): Promise<Report[]> {
    const { rows } = await this.pool.query<ReportRow>(`SELECT * FROM reports ORDER BY created_at DESC`);
    return rows.map(toReport);
  }

  /**
   * (Stage 7) See `ReportStore.aggregateByCandidate`.
   *
   * The inner query reduces each report's `competency_scores` JSONB array to
   * that report's own mean; the outer one averages those per candidate. The
   * nesting is the point — `AVG` over every score pooled together would weight
   * a session that scored six competencies more heavily than one that scored
   * three, which is not what "average score per interview" means. The in-memory
   * driver computes the identical mean-of-means.
   */
  async aggregateByCandidate(): Promise<CandidateReportAggregate[]> {
    const { rows } = await this.pool.query<{
      candidate_id: string;
      interviews_completed: string;
      average_score: string | null;
      last_interview_at: Date | null;
    }>(
      `SELECT candidate_id,
              COUNT(*)::text                AS interviews_completed,
              AVG(report_mean)::text        AS average_score,
              MAX(created_at)               AS last_interview_at
         FROM (
           SELECT r.candidate_id,
                  r.created_at,
                  (SELECT AVG((c->>'score')::numeric)
                     FROM jsonb_array_elements(r.competency_scores) AS c) AS report_mean
             FROM reports r
         ) per_report
        GROUP BY candidate_id`,
    );

    return rows.map((row) => ({
      candidateId: row.candidate_id,
      interviewsCompleted: Number(row.interviews_completed),
      averageScore: row.average_score === null ? null : Number(row.average_score),
      lastInterviewAt: row.last_interview_at ? row.last_interview_at.toISOString() : null,
    }));
  }
}

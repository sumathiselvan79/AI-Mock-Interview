/**
 * (Stage 7) Postgres scheduled-interview store. Same port as the in-memory
 * driver in `memory.ts`, backed by `scheduled_interviews` from migration 006.
 *
 * In the PRIMARY database, not the Supabase archive instance: this is live
 * operational data a student's home page reads on every load, not an export
 * copy (`ADMIN_FEATURE_PROMPT.md` §non-goals).
 */

import pg from "pg";
import type {
  InterviewType,
  NotifyChannel,
  Recurrence,
  ScheduleDifficulty,
  ScheduleStatus,
  ScheduledInterview,
  ScheduledInterviewStore,
} from "@mia/shared-types";

type Pool = pg.Pool;

interface ScheduledRow {
  id: string;
  candidate_id: string;
  department: string | null;
  role: string;
  job_description: string;
  interview_type: InterviewType;
  difficulty: ScheduleDifficulty;
  duration_minutes: number;
  scheduled_for: Date;
  deadline: Date | null;
  recurring: Recurrence;
  coding_round_enabled: boolean;
  notes: string | null;
  notify_via: NotifyChannel[];
  status: ScheduleStatus;
  session_id: string | null;
  created_by: string;
  created_at: Date;
  updated_at: Date;
}

const toScheduled = (row: ScheduledRow): ScheduledInterview => ({
  id: row.id,
  candidateId: row.candidate_id,
  department: row.department,
  role: row.role,
  jobDescription: row.job_description,
  interviewType: row.interview_type,
  difficulty: row.difficulty,
  durationMinutes: row.duration_minutes,
  scheduledFor: row.scheduled_for.toISOString(),
  deadline: row.deadline ? row.deadline.toISOString() : null,
  recurring: row.recurring,
  codingRoundEnabled: row.coding_round_enabled,
  notes: row.notes,
  notifyVia: row.notify_via,
  status: row.status,
  sessionId: row.session_id,
  createdBy: row.created_by,
  createdAt: row.created_at.toISOString(),
  updatedAt: row.updated_at.toISOString(),
});

const SELECT_COLUMNS = `id, candidate_id, department, role, job_description, interview_type,
  difficulty, duration_minutes, scheduled_for, deadline, recurring, coding_round_enabled,
  notes, notify_via, status, session_id, created_by, created_at, updated_at`;

export class PostgresScheduledInterviewStore implements ScheduledInterviewStore {
  constructor(private readonly pool: Pool) {}

  /**
   * One statement for the whole batch, inside a transaction: scheduling twelve
   * candidates either assigns all twelve or none. A partially-applied batch
   * would leave an Admin with no way to tell who was actually assigned.
   */
  async createMany(rows: ScheduledInterview[]): Promise<ScheduledInterview[]> {
    if (rows.length === 0) return [];

    const client = await this.pool.connect();
    try {
      await client.query("BEGIN");
      const created: ScheduledInterview[] = [];
      for (const row of rows) {
        const { rows: inserted } = await client.query<ScheduledRow>(
          `INSERT INTO scheduled_interviews
             (id, candidate_id, department, role, job_description, interview_type, difficulty,
              duration_minutes, scheduled_for, deadline, recurring, coding_round_enabled,
              notes, notify_via, status, session_id, created_by, created_at, updated_at)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19)
           RETURNING ${SELECT_COLUMNS}`,
          [
            row.id,
            row.candidateId,
            row.department,
            row.role,
            row.jobDescription,
            row.interviewType,
            row.difficulty,
            row.durationMinutes,
            row.scheduledFor,
            row.deadline,
            row.recurring,
            row.codingRoundEnabled,
            row.notes,
            JSON.stringify(row.notifyVia),
            row.status,
            row.sessionId,
            row.createdBy,
            row.createdAt,
            row.updatedAt,
          ],
        );
        created.push(toScheduled(inserted[0] as ScheduledRow));
      }
      await client.query("COMMIT");
      return created;
    } catch (err) {
      await client.query("ROLLBACK");
      throw err;
    } finally {
      client.release();
    }
  }

  async get(id: string): Promise<ScheduledInterview | null> {
    const { rows } = await this.pool.query<ScheduledRow>(
      `SELECT ${SELECT_COLUMNS} FROM scheduled_interviews WHERE id = $1`,
      [id],
    );
    return rows[0] ? toScheduled(rows[0]) : null;
  }

  async list(): Promise<ScheduledInterview[]> {
    const { rows } = await this.pool.query<ScheduledRow>(
      `SELECT ${SELECT_COLUMNS} FROM scheduled_interviews ORDER BY scheduled_for DESC`,
    );
    return rows.map(toScheduled);
  }

  async listByCandidate(candidateId: string): Promise<ScheduledInterview[]> {
    const { rows } = await this.pool.query<ScheduledRow>(
      `SELECT ${SELECT_COLUMNS} FROM scheduled_interviews
        WHERE candidate_id = $1 ORDER BY scheduled_for DESC`,
      [candidateId],
    );
    return rows.map(toScheduled);
  }

  async candidatesWithOpenSchedules(): Promise<string[]> {
    // Stored status, not the clock-derived one — see the in-memory driver's
    // note: an assignment whose deadline lapsed is still one an Admin made.
    const { rows } = await this.pool.query<{ candidate_id: string }>(
      `SELECT DISTINCT candidate_id FROM scheduled_interviews
        WHERE status IN ('pending', 'started')`,
    );
    return rows.map((r) => r.candidate_id);
  }

  async update(
    id: string,
    patch: Partial<Pick<ScheduledInterview, "status" | "sessionId" | "scheduledFor" | "deadline">>,
  ): Promise<ScheduledInterview | null> {
    const sets: string[] = [];
    const values: unknown[] = [id];
    const push = (column: string, value: unknown) => {
      values.push(value);
      sets.push(`${column} = $${values.length}`);
    };

    if (patch.status !== undefined) push("status", patch.status);
    if (patch.sessionId !== undefined) push("session_id", patch.sessionId);
    if (patch.scheduledFor !== undefined) push("scheduled_for", patch.scheduledFor);
    if (patch.deadline !== undefined) push("deadline", patch.deadline);
    if (sets.length === 0) return this.get(id);

    const { rows } = await this.pool.query<ScheduledRow>(
      `UPDATE scheduled_interviews SET ${sets.join(", ")}, updated_at = now()
        WHERE id = $1 RETURNING ${SELECT_COLUMNS}`,
      values,
    );
    return rows[0] ? toScheduled(rows[0]) : null;
  }
}

/**
 * Session archive store — INSTRUCTIONS.md §11.4, §11.6, §8.
 *
 * Two drivers behind one port, the same pattern the rest of `storage/` uses:
 * `memory` for a run with no infra, and `supabase` for the real thing.
 *
 * **Why `pg` and not `@supabase/supabase-js`.** §8's "Archive access boundary"
 * is explicit that Supabase's own auth and RLS are NOT the access-control
 * boundary for this data — this system's Gateway RBAC is, so that there is
 * exactly one place deciding who can read candidate records. The supabase-js
 * client exists to carry an end-user's identity into row-level policies, which
 * is precisely the model §8 rules out. A plain server-side Postgres connection
 * over the service-role credential expresses the intended boundary directly,
 * and it is the shape §11.6's SQL is written in.
 *
 * The connection string is separate from `DATABASE_URL` and must never be the
 * same instance: mixing them would put the archive back inside the database the
 * retention job prunes, defeating the point of an export copy.
 */

import pg from "pg";
import type {
  SessionArchive,
  SessionArchiveStore,
  SessionArchiveSummary,
} from "@mia/shared-types";

export class MemorySessionArchiveStore implements SessionArchiveStore {
  private readonly rows = new Map<string, SessionArchive>();

  async upsert(archive: SessionArchive): Promise<SessionArchive> {
    // Deep-copied on the way in AND out, so a caller mutating the object it
    // handed over cannot retroactively change what was archived — which would
    // quietly break the "never more permissive than the primary record at write
    // time" guarantee this store exists to make checkable.
    this.rows.set(archive.sessionId, structuredClone(archive));
    return structuredClone(archive);
  }

  async get(sessionId: string): Promise<SessionArchive | null> {
    const row = this.rows.get(sessionId);
    return row ? structuredClone(row) : null;
  }

  async summary(sessionId: string): Promise<SessionArchiveSummary | null> {
    const row = this.rows.get(sessionId);
    return row ? toSummary(row) : null;
  }

  async list(): Promise<SessionArchiveSummary[]> {
    return [...this.rows.values()]
      .sort((a, b) => b.archivedAt.localeCompare(a.archivedAt))
      .map(toSummary);
  }

  async close(): Promise<void> {
    /* nothing to release */
  }
}

interface ArchiveRow {
  session_id: string;
  candidate_id: string;
  candidate_name: string;
  department: string | null;
  program_year: string | null;
  document: SessionArchive["document"];
  archived_at: Date;
}

export class SupabaseSessionArchiveStore implements SessionArchiveStore {
  constructor(private readonly pool: pg.Pool) {}

  static connect(connectionString: string): SupabaseSessionArchiveStore {
    return new SupabaseSessionArchiveStore(
      new pg.Pool({
        connectionString,
        // Supabase terminates TLS with a certificate chain the default Node
        // trust store does not carry; the connection is still encrypted.
        ssl: { rejectUnauthorized: false },
        max: 4,
      }),
    );
  }

  async upsert(archive: SessionArchive): Promise<SessionArchive> {
    const { rows } = await this.pool.query<ArchiveRow>(
      `INSERT INTO session_archives
         (session_id, candidate_id, candidate_name, department, program_year, document, archived_at)
       VALUES ($1, $2, $3, $4, $5, $6::jsonb, $7)
       ON CONFLICT (session_id) DO UPDATE
         SET candidate_name = EXCLUDED.candidate_name,
             department     = EXCLUDED.department,
             program_year   = EXCLUDED.program_year,
             document       = EXCLUDED.document,
             archived_at    = EXCLUDED.archived_at
       RETURNING *`,
      [
        archive.sessionId,
        archive.candidateId,
        archive.candidateName,
        archive.department ?? null,
        archive.programYear ?? null,
        JSON.stringify(archive.document),
        archive.archivedAt,
      ],
    );
    return toArchive(rows[0] as ArchiveRow);
  }

  async get(sessionId: string): Promise<SessionArchive | null> {
    const { rows } = await this.pool.query<ArchiveRow>(
      `SELECT * FROM session_archives WHERE session_id = $1`,
      [sessionId],
    );
    return rows[0] ? toArchive(rows[0]) : null;
  }

  /** Deliberately does not SELECT `document`: a listing has no business reading the body (§7). */
  async summary(sessionId: string): Promise<SessionArchiveSummary | null> {
    const { rows } = await this.pool.query<Omit<ArchiveRow, "document">>(
      `SELECT session_id, candidate_id, candidate_name, department, program_year, archived_at
         FROM session_archives WHERE session_id = $1`,
      [sessionId],
    );
    return rows[0] ? toSummary(toArchiveMeta(rows[0])) : null;
  }

  async list(): Promise<SessionArchiveSummary[]> {
    const { rows } = await this.pool.query<Omit<ArchiveRow, "document">>(
      `SELECT session_id, candidate_id, candidate_name, department, program_year, archived_at
         FROM session_archives ORDER BY archived_at DESC`,
    );
    return rows.map((row) => toSummary(toArchiveMeta(row)));
  }

  async close(): Promise<void> {
    await this.pool.end();
  }
}

function toArchiveMeta(row: Omit<ArchiveRow, "document">): SessionArchiveSummary {
  return {
    sessionId: row.session_id,
    candidateId: row.candidate_id,
    candidateName: row.candidate_name,
    ...(row.department ? { department: row.department } : {}),
    ...(row.program_year ? { programYear: row.program_year } : {}),
    archivedAt: row.archived_at.toISOString(),
  };
}

function toArchive(row: ArchiveRow): SessionArchive {
  return { ...toArchiveMeta(row), document: row.document };
}

function toSummary(archive: SessionArchive | SessionArchiveSummary): SessionArchiveSummary {
  return {
    sessionId: archive.sessionId,
    candidateId: archive.candidateId,
    candidateName: archive.candidateName,
    ...(archive.department ? { department: archive.department } : {}),
    ...(archive.programYear ? { programYear: archive.programYear } : {}),
    archivedAt: archive.archivedAt,
  };
}

import { createGateway } from "./app.js";
import { loadConfig } from "./config.js";
import { createLogger } from "./logging/logger.js";
import { loadDotEnv } from "./paths.js";

// Must run before `loadConfig()` reads `process.env`. Nothing loaded the
// repo-root `.env` before this, so every "cp .env.example .env, then set
// AUTH_TOKEN_SECRET" instruction in the README and docs/RUNNING.md was a no-op
// and the whole file was silently ignored.
const env = loadDotEnv();

const config = loadConfig();
const logger = createLogger({ minLevel: config.nodeEnv === "production" ? "info" : "debug" });

logger.info("env_file", { loaded: env.loaded, path: env.path });

const gateway = await createGateway({ config, logger });

const server = gateway.app.listen(config.port, () => {
  logger.info("gateway_listening", {
    port: config.port,
    env: config.nodeEnv,
    storage: config.storageDriver,
    speech: gateway.speech.provider.name,
    mcp_servers: gateway.mcp.registered().length,
  });
});

// The live interview channel shares the HTTP server (INSTRUCTIONS.md §7).
gateway.attachLiveChannel(server);

const shutdown = (signal: string) => {
  logger.info("gateway_shutting_down", { signal });
  server.close(() => {
    void gateway.close().then(() => process.exit(0));
  });
};

process.on("SIGINT", () => shutdown("SIGINT"));
process.on("SIGTERM", () => shutdown("SIGTERM"));

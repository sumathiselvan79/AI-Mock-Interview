/**
 * Repo-root path resolution and `.env` loading.
 *
 * Both exist because of the same footgun: `npm run dev` runs the gateway
 * through its workspace script, so the process CWD is `apps/gateway`, not the
 * repository root. Anything resolved against CWD — `UPLOAD_DIR=uploads`,
 * `SPEECH_MODEL_DIR=models`, `.env` — silently pointed at
 * `apps/gateway/<name>`, which does not exist. The symptom was not an error:
 * the Speech Service simply reported "no sherpa-onnx models in models" and
 * degraded to the fixture provider on a machine where the models were sitting
 * in the repo root all along.
 *
 * Relative config paths are therefore resolved from the repo root, which is
 * what a value like `models` in `.env.example` plainly means. An absolute path
 * is left alone, so a deployment can still point anywhere.
 */

import { existsSync } from "node:fs";
import { dirname, isAbsolute, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

/** `apps/gateway/src` -> `apps/gateway` -> `apps` -> the repo root. */
export const REPO_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "..", "..", "..");

export function fromRepoRoot(path: string): string {
  return isAbsolute(path) ? path : join(REPO_ROOT, path);
}

/**
 * Loads the repo-root `.env` into `process.env`, if there is one.
 *
 * Called from entrypoints only (`index.ts`, `migrate.ts`, `seed.ts`) and never
 * from `config.ts` or `app.ts`, so the test suite keeps the hermetic
 * environment `vitest.config.ts` gives it rather than picking up whatever a
 * developer has in their `.env`.
 *
 * `process.loadEnvFile` does not overwrite variables that are already set, so a
 * real environment variable still beats the file — which is the precedence you
 * want when a container sets `DATABASE_URL` and a stale `.env` is lying around
 * in the image.
 */
export function loadDotEnv(): { loaded: boolean; path: string } {
  const path = join(REPO_ROOT, ".env");
  if (!existsSync(path)) return { loaded: false, path };
  process.loadEnvFile(path);
  return { loaded: true, path };
}

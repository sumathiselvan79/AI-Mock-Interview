/**
 * Creates one student and one admin account so the Stage 1 gate can be walked
 * by hand against a running gateway. Development only.
 *
 * Passcodes come from the environment — never hardcode a credential, not even
 * a throwaway one, in a file that ships with the repo.
 *
 *   SEED_STUDENT_PASSCODE=... SEED_ADMIN_PASSCODE=... npm run seed --workspace @mia/gateway
 */

import { loadConfig } from "./config.js";
import { createLogger } from "./logging/logger.js";
import { AuthService, MemoryResetMailer } from "./auth/service.js";
import { createStorage } from "./storage/index.js";
import { loadDotEnv } from "./paths.js";

loadDotEnv();

const config = loadConfig();
if (config.nodeEnv === "production") {
  throw new Error("seed is a development helper; refusing to run with NODE_ENV=production");
}

const studentPasscode = process.env.SEED_STUDENT_PASSCODE;
const adminPasscode = process.env.SEED_ADMIN_PASSCODE;
if (!studentPasscode || !adminPasscode) {
  throw new Error("set SEED_STUDENT_PASSCODE and SEED_ADMIN_PASSCODE before seeding");
}

const logger = createLogger({ minLevel: "debug" });
const storage = await createStorage(config);
const auth = new AuthService({
  users: storage.users,
  resets: storage.resets,
  telemetry: storage.telemetry,
  config,
  logger,
  mailer: new MemoryResetMailer(),
});

const student = await auth.createUser({
  email: process.env.SEED_STUDENT_EMAIL ?? "student@example.com",
  passcode: studentPasscode,
  role: "student",
});
const admin = await auth.createUser({
  email: process.env.SEED_ADMIN_EMAIL ?? "admin@example.com",
  passcode: adminPasscode,
  role: "admin",
});

logger.info("seeded_accounts", { student_id: student.id, admin_id: admin.id });
await storage.close();

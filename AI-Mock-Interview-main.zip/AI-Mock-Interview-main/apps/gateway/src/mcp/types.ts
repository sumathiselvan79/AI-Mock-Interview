/**
 * Re-exported from @mia/shared-types so agent and tool packages can implement
 * the handler contract without depending on the gateway that hosts them.
 */
export { McpHandlerError, type McpServerHandler } from "@mia/shared-types";

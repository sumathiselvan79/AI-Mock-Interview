/**
 * MCP Gateway — CLAUDE.md §5, INSTRUCTIONS.md §2.
 *
 * Every MCP call in the system passes through `call()`. In order it: resolves
 * the server, authenticates the session token, enforces the caller allowlist,
 * applies the per-session rate limit, validates the request against its JSON
 * Schema, invokes the server, validates the response, and — on every path,
 * including every failure path — emits one `tool_called`/`agent_called`
 * telemetry span with latency and status. No agent instruments itself.
 */

import {
  MCP_AGENT_SERVERS,
  MCP_ERROR_CODES,
  type McpCallContext,
  type McpCallResult,
  type McpError,
  type TelemetrySink,
} from "@mia/shared-types";
import {
  ALLOWED_CALLERS,
  describeViolations,
  isKnownMethod,
  isKnownServer,
  validateRequest,
  validateResponse,
} from "@mia/mcp-schemas";
import type { GatewayConfig } from "../config.js";
import type { Logger } from "../logging/logger.js";
import type { LiveSessionStore } from "../storage/types.js";
import { verifySessionToken } from "../auth/tokens.js";
import { McpHandlerError, type McpServerHandler } from "./types.js";

export interface McpGatewayDeps {
  config: GatewayConfig;
  telemetry: TelemetrySink;
  live: LiveSessionStore;
  logger: Logger;
}

const AGENT_SERVER_NAMES: readonly string[] = MCP_AGENT_SERVERS;

export class McpGateway {
  private readonly handlers = new Map<string, McpServerHandler>();

  constructor(private readonly deps: McpGatewayDeps) {}

  register(handler: McpServerHandler): void {
    this.handlers.set(handler.name, handler);
    this.deps.logger.info("mcp_server_registered", { server: handler.name });
  }

  registered(): string[] {
    return [...this.handlers.keys()].sort();
  }

  async call<T = unknown>(
    server: string,
    method: string,
    params: unknown,
    ctx: McpCallContext,
  ): Promise<McpCallResult<T>> {
    const startedAt = process.hrtime.bigint();
    let error: McpError | undefined;
    let data: T | undefined;

    try {
      data = (await this.dispatch(server, method, params, ctx)) as T;
    } catch (err) {
      error =
        err instanceof McpHandlerError
          ? { code: err.code, message: err.message }
          : { code: MCP_ERROR_CODES.UPSTREAM_ERROR, message: (err as Error).message };
    }

    const latencyMs = Number(process.hrtime.bigint() - startedAt) / 1_000_000;

    // The auto-emitted span. Fire-and-forget by contract (§5.4), but awaited
    // here so a dropped span can never race a test or a shutdown.
    await this.deps.telemetry.emit(
      AGENT_SERVER_NAMES.includes(server) ? "agent_called" : "tool_called",
      ctx.sessionId ?? null,
      {
        server,
        method,
        caller: ctx.caller,
        status: error ? "error" : "ok",
        latency_ms: Math.round(latencyMs * 1000) / 1000,
        error_code: error?.code ?? null,
      },
    );

    return error ? { ok: false, error, latencyMs } : { ok: true, data: data as T, latencyMs };
  }

  private async dispatch(
    server: string,
    method: string,
    params: unknown,
    ctx: McpCallContext,
  ): Promise<unknown> {
    const handler = this.handlers.get(server);
    if (!handler || !isKnownServer(server)) {
      throw new McpHandlerError(MCP_ERROR_CODES.UNKNOWN_SERVER, `unknown MCP server: ${server}`);
    }
    if (!isKnownMethod(server, method)) {
      throw new McpHandlerError(
        MCP_ERROR_CODES.UNKNOWN_METHOD,
        `${server} has no method ${method} in /packages/mcp-schemas`,
      );
    }

    if (!verifySessionToken(ctx.sessionToken ?? "", ctx.sessionId ?? "", this.deps.config.authTokenSecret)) {
      throw new McpHandlerError(
        MCP_ERROR_CODES.UNAUTHORIZED,
        "invalid or missing session token for this MCP call",
      );
    }

    // The Speech Service is Harness-Agent-only (INSTRUCTIONS.md §5.6); any other
    // server absent from the map is callable by any authenticated agent.
    const allowed = ALLOWED_CALLERS[server];
    if (allowed && !allowed.includes(ctx.caller)) {
      throw new McpHandlerError(
        MCP_ERROR_CODES.UNAUTHORIZED,
        `${server} may only be called by ${allowed.join(", ")}, not ${ctx.caller}`,
      );
    }

    await this.enforceRateLimit(ctx);

    const requestCheck = validateRequest(server, method, params);
    if (!requestCheck.valid) {
      throw new McpHandlerError(
        MCP_ERROR_CODES.SCHEMA_INVALID_REQUEST,
        `${server}.${method} request failed schema: ${describeViolations(requestCheck.violations)}`,
      );
    }

    const result = await handler.call(method, params, ctx);

    const responseCheck = validateResponse(server, method, result);
    if (!responseCheck.valid) {
      throw new McpHandlerError(
        MCP_ERROR_CODES.SCHEMA_INVALID_RESPONSE,
        `${server}.${method} response failed schema: ${describeViolations(responseCheck.violations)}`,
      );
    }

    return result;
  }

  private async enforceRateLimit(ctx: McpCallContext): Promise<void> {
    const { mcpRateLimit, mcpRateLimitWindowMs } = this.deps.config;
    const count = await this.deps.live.incrementRateCounter(
      `mcp:${ctx.sessionId}`,
      mcpRateLimitWindowMs,
    );
    if (count > mcpRateLimit) {
      await this.deps.telemetry.emit("rate_limit_exceeded", ctx.sessionId ?? null, {
        caller: ctx.caller,
        limit: mcpRateLimit,
        window_ms: mcpRateLimitWindowMs,
      });
      throw new McpHandlerError(
        MCP_ERROR_CODES.RATE_LIMITED,
        `session exceeded ${mcpRateLimit} MCP calls per ${mcpRateLimitWindowMs}ms`,
      );
    }
  }
}

/**
 * Dummy MCP server for TRACKING.md Stage 1, gate test 4: "Fire one dummy MCP
 * tool call through the gateway and confirm a `tool_called` telemetry event
 * lands with latency and status — before writing any real tool, prove the
 * instrumentation path works."
 *
 * Registered in development and test only — never in production.
 */

import { McpHandlerError, type McpServerHandler } from "@mia/shared-types";

export function createDevPingServer(): McpServerHandler {
  return {
    name: "_dev",
    async call(method, params) {
      if (method !== "ping") {
        throw new McpHandlerError("unknown_method", `_dev has no method ${method}`);
      }
      const { delay_ms: delayMs, fail, nonce } = (params ?? {}) as {
        nonce: string;
        delay_ms?: number;
        fail?: boolean;
      };
      if (delayMs && delayMs > 0) await new Promise((resolve) => setTimeout(resolve, delayMs));
      if (fail) throw new McpHandlerError("upstream_error", "ping asked to fail");
      return { pong: nonce, server_time: new Date().toISOString() };
    },
  };
}

/**
 * (Stage 7) Admin user directory — search, filter, sort, paginate.
 *
 * A pure function over already-fetched inputs, deliberately: the filters span
 * three stores (accounts, report aggregates, open schedules) and a candidate's
 * average score is not a column on any single one of them, so this cannot be a
 * `WHERE`/`ORDER BY`/`LIMIT` in one query without denormalising a score onto
 * `users` and keeping it correct forever. Fetching three bounded sets and
 * combining them here costs three queries TOTAL for the page — which is the
 * thing `ADMIN_FEATURE_PROMPT.md` Part 1 actually rules out ("aggregate stats
 * should come from a summary query, not N+1 report fetches"), and it keeps the
 * ordering rules in one readable place instead of spread across SQL.
 *
 * Nothing here reads a resume, an audio ref, or a transcript. `DirectoryRow`
 * has no field that could carry one (soul.md §"Admin role").
 */

import {
  DEFAULT_DIRECTORY_PAGE_SIZE,
  MAX_DIRECTORY_PAGE_SIZE,
  type CandidateReportAggregate,
  type DirectoryPage,
  type DirectoryQuery,
  type DirectoryRow,
  type DirectorySortKey,
  type DirectoryStatus,
  type User,
} from "@mia/shared-types";

export interface DirectoryInputs {
  /** Student accounts only — an Admin is not a candidate (INSTRUCTIONS.md §3.2). */
  students: User[];
  reportStats: CandidateReportAggregate[];
  /** Candidate ids with at least one open assignment. */
  scheduledCandidateIds: string[];
  /** Session count per candidate — distinguishes "started nothing" from "finished nothing". */
  sessionCounts: Record<string, number>;
  /** Avatar URL per candidate id, for accounts that signed in with Google. */
  avatars: Record<string, string>;
}

/**
 * `interview_scheduled` wins over `active` because it is the state an Admin is
 * looking for when they filter — a candidate who has done ten interviews and
 * has an eleventh assigned is, for this screen, a scheduled one.
 */
function statusFor(
  userId: string,
  interviewsCompleted: number,
  sessionCount: number,
  scheduled: Set<string>,
): DirectoryStatus {
  if (scheduled.has(userId)) return "interview_scheduled";
  if (interviewsCompleted > 0 || sessionCount > 0) return "active";
  return "no_activity";
}

/** Builds every row, unfiltered. Exported for the profile page's reuse of the same shape. */
export function buildRows(inputs: DirectoryInputs): DirectoryRow[] {
  const statsByCandidate = new Map(inputs.reportStats.map((s) => [s.candidateId, s]));
  const scheduled = new Set(inputs.scheduledCandidateIds);

  return inputs.students.map((user) => {
    const stats = statsByCandidate.get(user.id);
    const interviewsCompleted = stats?.interviewsCompleted ?? 0;
    return {
      userId: user.id,
      email: user.email,
      fullName: user.fullName ?? null,
      department: user.department ?? null,
      avatarUrl: inputs.avatars[user.id] ?? null,
      interviewsCompleted,
      averageScore: stats?.averageScore ?? null,
      lastInterviewAt: stats?.lastInterviewAt ?? null,
      createdAt: user.createdAt,
      status: statusFor(user.id, interviewsCompleted, inputs.sessionCounts[user.id] ?? 0, scheduled),
    };
  });
}

/**
 * Sort comparator.
 *
 * Null always sorts last regardless of direction — a candidate with no score
 * yet is missing data, not the worst performer, and flipping to ascending
 * should not fill the top of the screen with blanks.
 */
function compare(a: DirectoryRow, b: DirectoryRow, key: DirectorySortKey, direction: "asc" | "desc"): number {
  const left = a[key];
  const right = b[key];
  if (left === null && right === null) return 0;
  if (left === null) return 1;
  if (right === null) return -1;

  const sign = direction === "asc" ? 1 : -1;
  if (typeof left === "number" && typeof right === "number") return (left - right) * sign;
  return String(left).localeCompare(String(right), undefined, { sensitivity: "base" }) * sign;
}

function matchesSearch(row: DirectoryRow, search: string): boolean {
  const needle = search.trim().toLowerCase();
  if (needle === "") return true;
  return (
    row.email.toLowerCase().includes(needle) || (row.fullName ?? "").toLowerCase().includes(needle)
  );
}

/**
 * Applies the query and returns one page.
 *
 * `total` is the count AFTER filtering and before paging, so the UI can render
 * "showing 25 of 312 matching" rather than a page count that ignores filters.
 */
export function buildDirectoryPage(inputs: DirectoryInputs, query: DirectoryQuery = {}): DirectoryPage {
  const pageSize = Math.min(
    Math.max(1, Math.floor(query.pageSize ?? DEFAULT_DIRECTORY_PAGE_SIZE)),
    MAX_DIRECTORY_PAGE_SIZE,
  );
  const page = Math.max(1, Math.floor(query.page ?? 1));

  const filtered = buildRows(inputs).filter((row) => {
    if (!matchesSearch(row, query.search ?? "")) return false;
    if (query.department && row.department !== query.department) return false;
    if (query.status && row.status !== query.status) return false;

    // A score filter is a statement about scores. A candidate with none has not
    // scored below the floor — they are outside the question, so they are
    // excluded rather than silently counted as zero.
    if (query.minScore !== undefined) {
      if (row.averageScore === null || row.averageScore < query.minScore) return false;
    }
    if (query.maxScore !== undefined) {
      if (row.averageScore === null || row.averageScore > query.maxScore) return false;
    }

    // The date range is about interview activity, so it filters
    // `lastInterviewAt` — same reasoning: never interviewed is not "interviewed
    // outside the range".
    if (query.from && (row.lastInterviewAt === null || row.lastInterviewAt < query.from)) return false;
    if (query.to && (row.lastInterviewAt === null || row.lastInterviewAt > query.to)) return false;

    return true;
  });

  const sortKey: DirectorySortKey = query.sort ?? "createdAt";
  const direction = query.direction ?? (query.sort ? "asc" : "desc");
  // Tie-break on user id so paging is stable: without it two candidates with
  // equal scores can swap places between page 1 and page 2 and one of them
  // never appears.
  const sorted = [...filtered].sort(
    (a, b) => compare(a, b, sortKey, direction) || a.userId.localeCompare(b.userId),
  );

  const start = (page - 1) * pageSize;
  return { rows: sorted.slice(start, start + pageSize), total: sorted.length, page, pageSize };
}

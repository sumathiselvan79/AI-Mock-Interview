/**
 * (Stage 7) Validation and projection for admin-scheduled interviews.
 *
 * Split out from the route so the rules are testable without HTTP, and so the
 * two projections — what an Admin sees and what a student sees — sit next to
 * each other where the difference between them is obvious.
 */

import { randomUUID } from "node:crypto";
import {
  INTERVIEW_TYPES,
  MAX_SCHEDULE_DURATION_MINUTES,
  MIN_SCHEDULE_DURATION_MINUTES,
  NOTIFY_CHANNELS,
  RECURRENCES,
  SCHEDULE_DIFFICULTIES,
  effectiveStatus,
  runsCodingRound,
  type InterviewType,
  type NotifyChannel,
  type Recurrence,
  type ScheduleDifficulty,
  type ScheduledInterview,
  type User,
} from "@mia/shared-types";

export class ScheduleInvalid extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ScheduleInvalid";
  }
}

/** An ISO instant, or throw. Rejects `new Date("nonsense")` producing an Invalid Date. */
function isoInstant(value: unknown, field: string): string {
  if (typeof value !== "string" || value.trim() === "") {
    throw new ScheduleInvalid(`${field} is required and must be an ISO 8601 timestamp`);
  }
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) {
    throw new ScheduleInvalid(`${field} is not a valid ISO 8601 timestamp`);
  }
  // Normalised to UTC on the way in, so two admins in different timezones who
  // pick "the same" moment store the same instant.
  return parsed.toISOString();
}

function oneOf<T extends string>(value: unknown, allowed: readonly T[], field: string): T {
  if (typeof value !== "string" || !(allowed as readonly string[]).includes(value)) {
    throw new ScheduleInvalid(`${field} must be one of: ${allowed.join(", ")}`);
  }
  return value as T;
}

export interface ValidatedDraft {
  candidateIds: string[];
  role: string;
  jobDescription: string;
  interviewType: InterviewType;
  difficulty: ScheduleDifficulty;
  durationMinutes: number;
  scheduledFor: string;
  deadline: string | null;
  recurring: Recurrence;
  codingRoundEnabled: boolean;
  notes: string | null;
  notifyVia: NotifyChannel[];
}

/**
 * Validates an admin's scheduling request.
 *
 * Deliberately rejects rather than coerces. Scheduling creates a real
 * obligation for a named student, so a request this function cannot read
 * exactly is one an Admin should be shown an error for, not one that silently
 * becomes something slightly different.
 */
export function validateDraft(body: Record<string, unknown>): ValidatedDraft {
  const candidateIds = body.candidate_ids;
  if (!Array.isArray(candidateIds) || candidateIds.length === 0) {
    throw new ScheduleInvalid("candidate_ids must be a non-empty array of student ids");
  }
  if (!candidateIds.every((id) => typeof id === "string" && id.trim() !== "")) {
    throw new ScheduleInvalid("every entry in candidate_ids must be a non-empty string");
  }
  // De-duplicated so selecting a student twice — easy in a bulk UI that offers
  // both "select rows" and "select department" — does not assign them twice.
  const uniqueIds = [...new Set(candidateIds as string[])];

  if (typeof body.role !== "string" || body.role.trim() === "") {
    throw new ScheduleInvalid("role is required");
  }

  const duration = body.duration_minutes;
  if (
    typeof duration !== "number" ||
    !Number.isInteger(duration) ||
    duration < MIN_SCHEDULE_DURATION_MINUTES ||
    duration > MAX_SCHEDULE_DURATION_MINUTES
  ) {
    throw new ScheduleInvalid(
      `duration_minutes must be a whole number between ${MIN_SCHEDULE_DURATION_MINUTES} and ${MAX_SCHEDULE_DURATION_MINUTES}`,
    );
  }

  const scheduledFor = isoInstant(body.scheduled_for, "scheduled_for");
  const deadline =
    body.deadline === undefined || body.deadline === null
      ? null
      : isoInstant(body.deadline, "deadline");
  if (deadline && new Date(deadline).getTime() <= new Date(scheduledFor).getTime()) {
    // Not a tight schedule — one that can never be started.
    throw new ScheduleInvalid("deadline must be after scheduled_for");
  }

  const notifyVia = body.notify_via === undefined ? ["in_app"] : body.notify_via;
  if (!Array.isArray(notifyVia) || notifyVia.length === 0) {
    throw new ScheduleInvalid(`notify_via must be a non-empty array of: ${NOTIFY_CHANNELS.join(", ")}`);
  }
  const channels = notifyVia.map((c) => oneOf(c, NOTIFY_CHANNELS, "notify_via"));

  // Rejected explicitly rather than ignored. An Admin who sent this believes
  // they answered consent for the candidate, and silently dropping it would
  // leave them believing it (soul.md §"Consent-first monitoring").
  if (body.consent_defaults !== undefined || body.consent !== undefined) {
    throw new ScheduleInvalid(
      "consent cannot be set on a schedule — the candidate gives it themselves on the Telemetry Check page",
    );
  }

  return {
    candidateIds: uniqueIds,
    role: body.role.trim(),
    jobDescription: typeof body.job_description === "string" ? body.job_description : "",
    interviewType: oneOf(body.interview_type, INTERVIEW_TYPES, "interview_type"),
    difficulty: oneOf(body.difficulty, SCHEDULE_DIFFICULTIES, "difficulty"),
    durationMinutes: duration,
    scheduledFor,
    deadline,
    recurring:
      body.recurring === undefined ? "none" : oneOf(body.recurring, RECURRENCES, "recurring"),
    codingRoundEnabled: body.coding_round_enabled === true,
    notes: typeof body.notes === "string" && body.notes.trim() !== "" ? body.notes : null,
    notifyVia: [...new Set(channels)],
  };
}

/** Expands a validated draft into one row per candidate. */
export function draftToRows(
  draft: ValidatedDraft,
  candidates: User[],
  createdBy: string,
  now: Date = new Date(),
): ScheduledInterview[] {
  const at = now.toISOString();
  const byId = new Map(candidates.map((c) => [c.id, c]));

  return draft.candidateIds.map((candidateId) => ({
    id: randomUUID(),
    candidateId,
    // Snapshot, so a batch scheduled "for Engineering" still reads correctly
    // after the candidate edits their own profile.
    department: byId.get(candidateId)?.department ?? null,
    role: draft.role,
    jobDescription: draft.jobDescription,
    interviewType: draft.interviewType,
    difficulty: draft.difficulty,
    durationMinutes: draft.durationMinutes,
    scheduledFor: draft.scheduledFor,
    deadline: draft.deadline,
    recurring: draft.recurring,
    codingRoundEnabled: draft.codingRoundEnabled,
    notes: draft.notes,
    notifyVia: draft.notifyVia,
    status: "pending",
    sessionId: null,
    createdBy,
    createdAt: at,
    updatedAt: at,
  }));
}

/** Admin-facing wire shape. Carries `notes`, because notes are for admins. */
export function toAdminWire(schedule: ScheduledInterview, now: Date = new Date()) {
  return {
    id: schedule.id,
    candidate_id: schedule.candidateId,
    department: schedule.department,
    role: schedule.role,
    job_description: schedule.jobDescription,
    interview_type: schedule.interviewType,
    difficulty: schedule.difficulty,
    duration_minutes: schedule.durationMinutes,
    scheduled_for: schedule.scheduledFor,
    deadline: schedule.deadline,
    recurring: schedule.recurring,
    coding_round_enabled: schedule.codingRoundEnabled,
    notes: schedule.notes,
    notify_via: schedule.notifyVia,
    status: effectiveStatus(schedule, now),
    stored_status: schedule.status,
    session_id: schedule.sessionId,
    created_by: schedule.createdBy,
    created_at: schedule.createdAt,
  };
}

/**
 * Student-facing wire shape.
 *
 * `notes` is absent — the field is documented as internal to admins, and the
 * only way to guarantee that is for the student projection to have no key for
 * it at all rather than to remember to strip it. `created_by` is absent for the
 * same reason: which Admin assigned this is not the candidate's business.
 *
 * `runs_coding_round` is included because the candidate is entitled to know
 * what they are walking into — specifically that a coding round will ask for
 * clipboard monitoring, which they will be asked to consent to.
 */
export function toStudentWire(schedule: ScheduledInterview, now: Date = new Date()) {
  return {
    id: schedule.id,
    role: schedule.role,
    job_description: schedule.jobDescription,
    interview_type: schedule.interviewType,
    difficulty: schedule.difficulty,
    duration_minutes: schedule.durationMinutes,
    scheduled_for: schedule.scheduledFor,
    deadline: schedule.deadline,
    runs_coding_round: runsCodingRound(schedule),
    status: effectiveStatus(schedule, now),
    session_id: schedule.sessionId,
    // Said plainly on every assignment: being scheduled does not pre-answer
    // anything the candidate would otherwise be asked (soul.md §5).
    consent_note:
      "You will still be asked for consent, and to upload your resume, before this interview starts.",
  };
}

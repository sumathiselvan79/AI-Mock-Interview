/**
 * Role resolution — the single place that decides `admin` vs `student`.
 *
 * Every identity path (passcode login's stored role aside, which is set at
 * operator-provisioned creation time) that authenticates via a *third party
 * or a typed-in email* — dev-login, Google OAuth — runs its email through
 * this function rather than trusting a role the client or the provider
 * handed back. A new identity defaults to `student`; only an email on the
 * allowlist ever becomes `admin`.
 */

import type { Role } from "@mia/shared-types";

export function resolveRole(email: string, adminEmailAllowlist: readonly string[]): Role {
  const normalized = email.trim().toLowerCase();
  return adminEmailAllowlist.includes(normalized) ? "admin" : "student";
}

/** Parses `ADMIN_EMAIL_ALLOWLIST` (comma-separated) into normalized emails. */
export function parseAdminEmailAllowlist(raw: string | undefined): string[] {
  return (raw ?? "")
    .split(",")
    .map((email) => email.trim().toLowerCase())
    .filter((email) => email.length > 0);
}

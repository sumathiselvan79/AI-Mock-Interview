/**
 * Google OAuth identity check — the second identity path, added without
 * touching mintSessionToken, the RBAC middleware, or role resolution
 * (auth/roles.ts). It ends at the same place dev-login does: a verified
 * email handed to AuthService.identityLogin().
 */

import { Google, OAuth2RequestError, decodeIdToken } from "arctic";
import type { GatewayConfig } from "../config.js";

/**
 * The slice of arctic's `Google` client this module actually uses — kept as
 * an interface so tests can inject a fake instead of hitting Google's token
 * endpoint over the network.
 */
export interface GoogleAuthClient {
  createAuthorizationURL(state: string, codeVerifier: string, scopes: string[]): URL;
  validateAuthorizationCode(code: string, codeVerifier: string): Promise<{ idToken(): string }>;
}

export function createGoogleAuthClient(config: GatewayConfig): GoogleAuthClient {
  return new Google(config.google.clientId, config.google.clientSecret, config.google.redirectUri);
}

export { OAuth2RequestError };

const VALID_ISSUERS = new Set(["https://accounts.google.com", "accounts.google.com"]);

export class InvalidGoogleIdTokenError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "InvalidGoogleIdTokenError";
  }
}

/** The identity facts this system actually trusts from a Google ID token. */
export interface VerifiedGoogleProfile {
  email: string;
  /** Google's `sub` claim — stable per Google account, unlike email. */
  subject: string;
  /** Present only when the `profile` scope was granted at /start. */
  name?: string;
  picture?: string;
}

/**
 * Decodes and validates Google's ID token, then returns the verified profile.
 *
 * arctic's `decodeIdToken` only base64-decodes the JWT — it does not check
 * the signature, which is fine here because this token was fetched directly
 * from Google's token endpoint over TLS (not passed through the browser), so
 * the channel itself is the trust anchor per OIDC's code-flow guidance. What
 * still has to be checked by hand is that it's the token *we* asked for:
 * issuer, audience, expiry, and that Google actually verified the address.
 *
 * `name`/`picture` are read but never validated the way `email` is — they are
 * display data for the OAuth profile snapshot (storage/oauth-profiles.ts),
 * never used for identity or role resolution.
 */
export function extractVerifiedGoogleProfile(
  idToken: string,
  expectedAudience: string,
): VerifiedGoogleProfile {
  let claims: Record<string, unknown>;
  try {
    claims = decodeIdToken(idToken) as Record<string, unknown>;
  } catch {
    throw new InvalidGoogleIdTokenError("could not decode Google ID token");
  }

  if (typeof claims.iss !== "string" || !VALID_ISSUERS.has(claims.iss)) {
    throw new InvalidGoogleIdTokenError("unexpected issuer");
  }
  if (claims.aud !== expectedAudience) {
    throw new InvalidGoogleIdTokenError("unexpected audience");
  }
  if (typeof claims.exp !== "number" || claims.exp * 1000 <= Date.now()) {
    throw new InvalidGoogleIdTokenError("ID token is expired");
  }
  if (claims.email_verified !== true) {
    throw new InvalidGoogleIdTokenError("Google has not verified this email address");
  }
  if (typeof claims.email !== "string" || !claims.email.includes("@")) {
    throw new InvalidGoogleIdTokenError("ID token is missing an email claim");
  }
  if (typeof claims.sub !== "string" || !claims.sub) {
    throw new InvalidGoogleIdTokenError("ID token is missing a sub claim");
  }

  return {
    email: claims.email,
    subject: claims.sub,
    ...(typeof claims.name === "string" ? { name: claims.name } : {}),
    ...(typeof claims.picture === "string" ? { picture: claims.picture } : {}),
  };
}

/**
 * Auth service — INSTRUCTIONS.md §7 (endpoints) and §8 (storage rules).
 *
 * Two deliberate choices worth keeping:
 *  - login and reset-request give the same answer whether or not the account
 *    exists, so neither becomes an account-enumeration oracle;
 *  - the reset token's plaintext exists only in the value handed to the mailer.
 *    Only its SHA-256 is stored, and it is single-use.
 */

import type { OAuthProfileStore, PublicUser, Role, TelemetrySink, User, UserProfile } from "@mia/shared-types";
import type { GatewayConfig } from "../config.js";
import type { Logger } from "../logging/logger.js";
import type { ResetTokenStore, UserStore } from "../storage/types.js";
import { randomBytes } from "node:crypto";
import { assertPasscodeAcceptable, hashPasscode, verifyPasscode } from "./passcode.js";
import { resolveRole } from "./roles.js";
import { generateResetToken, hashResetToken, mintSessionToken } from "./tokens.js";

export interface ResetMailer {
  /** Delivers the single-use token out of band. The token is never logged. */
  deliver(email: string, token: string, expiresAt: string): Promise<void>;
}

/** Dev/test mailer: keeps the last token in memory so a manual run can complete the flow. */
export class MemoryResetMailer implements ResetMailer {
  private readonly delivered: { email: string; token: string; expiresAt: string }[] = [];
  async deliver(email: string, token: string, expiresAt: string): Promise<void> {
    this.delivered.push({ email, token, expiresAt });
  }
  lastFor(email: string): { email: string; token: string; expiresAt: string } | undefined {
    return [...this.delivered].reverse().find((d) => d.email === email.trim().toLowerCase());
  }
}

export class AuthError extends Error {
  constructor(
    readonly code: string,
    message: string,
  ) {
    super(message);
    this.name = "AuthError";
  }
}

export interface AuthServiceDeps {
  users: UserStore;
  resets: ResetTokenStore;
  telemetry: TelemetrySink;
  config: GatewayConfig;
  logger: Logger;
  mailer: ResetMailer;
  /** Optional: absent, Google identity login still works, it just skips the profile snapshot. */
  oauthProfiles?: OAuthProfileStore;
}

/** What a verified Google identity contributes to `identityLogin`, beyond the email every identity path shares. */
export interface GoogleIdentity {
  provider: "google";
  subject: string;
  name?: string;
  avatarUrl?: string;
}

const toPublicUser = (user: User): PublicUser => ({
  id: user.id,
  email: user.email,
  role: user.role,
  crossSessionMemoryOptIn: user.crossSessionMemoryOptIn,
  // (Stage 5) Surfaced so the frontend can tell whether a profile still needs
  // completing before this candidate's sessions can be archived (§11.4).
  ...(user.fullName ? { fullName: user.fullName } : {}),
  ...(user.department ? { department: user.department } : {}),
  ...(user.programYear ? { programYear: user.programYear } : {}),
});

export class AuthService {
  constructor(private readonly deps: AuthServiceDeps) {}

  /** Account creation is an operator action in Stage 1 — role is fixed here (§3.2). */
  async createUser(input: {
    email: string;
    passcode: string;
    role: Role;
    crossSessionMemoryOptIn?: boolean;
    /** (Stage 5, §11.4) Collected at signup; required before a session can be archived. */
    profile?: UserProfile;
  }): Promise<PublicUser> {
    assertPasscodeAcceptable(input.passcode);
    const user = await this.deps.users.create({
      email: input.email,
      role: input.role,
      passcodeHash: await hashPasscode(input.passcode),
      crossSessionMemoryOptIn: input.crossSessionMemoryOptIn ?? false,
      ...(input.profile ? { profile: input.profile } : {}),
    });
    return toPublicUser(user);
  }

  /** (Stage 5, §11.4) A candidate completing their own profile. */
  async updateProfile(userId: string, profile: UserProfile): Promise<PublicUser> {
    return toPublicUser(await this.deps.users.updateProfile(userId, profile));
  }

  async login(email: string, passcode: string): Promise<{ token: string; user: PublicUser }> {
    const user = await this.deps.users.findByEmail(email);
    // Verify against a dummy hash when the user is missing so both branches cost
    // the same and the response time does not reveal which one happened.
    const stored = user?.passcodeHash ?? DUMMY_HASH;
    const ok = await verifyPasscode(passcode, stored);

    if (!user || !ok) {
      await this.deps.telemetry.emit("auth_login_failed", null, { reason: "invalid_credentials" });
      this.deps.logger.warn("login_failed", { email_domain: email.split("@")[1] ?? "unknown" });
      throw new AuthError("invalid_credentials", "invalid email or passcode");
    }

    const { token } = mintSessionToken({
      userId: user.id,
      email: user.email,
      role: user.role,
      ttlSeconds: this.deps.config.authTokenTtlSeconds,
      secret: this.deps.config.authTokenSecret,
    });

    await this.deps.telemetry.emit("auth_login_succeeded", null, { user_id: user.id, role: user.role });
    return { token, user: toPublicUser(user) };
  }

  /**
   * Shared endpoint for every identity path that doesn't collect a passcode:
   * dev-login today, Google OAuth once its callback validates an ID token.
   * The caller hands over a *verified* email; role is never taken from the
   * caller — it is always resolved from the admin-email allowlist, right
   * here, so a client field or a provider claim can never mint an admin
   * token.
   *
   * `googleIdentity` is dev-login's absence and Google OAuth's presence: when
   * set (and `oauthProfiles` is configured), the profile snapshot is upserted
   * into the Supabase-hosted store alongside the login itself — never
   * blocking the login if that write fails, since the snapshot is a record of
   * the sign-in, not a precondition for it.
   */
  async identityLogin(
    email: string,
    googleIdentity?: GoogleIdentity,
  ): Promise<{ token: string; user: PublicUser }> {
    const role = resolveRole(email, this.deps.config.adminEmailAllowlist);
    const unusablePasscodeHash = await hashPasscode(randomBytes(32).toString("base64url"));
    const user = await this.deps.users.upsertIdentity({
      email,
      role,
      unusablePasscodeHash,
    });

    if (googleIdentity && this.deps.oauthProfiles) {
      try {
        await this.deps.oauthProfiles.upsert({
          userId: user.id,
          provider: googleIdentity.provider,
          providerSubject: googleIdentity.subject,
          email: user.email,
          ...(googleIdentity.name ? { name: googleIdentity.name } : {}),
          ...(googleIdentity.avatarUrl ? { avatarUrl: googleIdentity.avatarUrl } : {}),
          linkedAt: new Date().toISOString(),
        });
      } catch (err) {
        this.deps.logger.warn("oauth_profile_snapshot_failed", {
          user_id: user.id,
          error: (err as Error).message,
        });
      }
    }

    const { token } = mintSessionToken({
      userId: user.id,
      email: user.email,
      role: user.role,
      ttlSeconds: this.deps.config.authTokenTtlSeconds,
      secret: this.deps.config.authTokenSecret,
    });

    await this.deps.telemetry.emit("auth_login_succeeded", null, { user_id: user.id, role: user.role });
    return { token, user: toPublicUser(user) };
  }

  /** Always resolves the same way, whether or not the account exists. */
  async requestPasscodeReset(email: string): Promise<void> {
    const user = await this.deps.users.findByEmail(email);
    if (!user) {
      this.deps.logger.info("reset_requested_unknown_account", {});
      return;
    }
    const { plaintext, hash } = generateResetToken();
    const expiresAt = new Date(Date.now() + this.deps.config.resetTokenTtlSeconds * 1000).toISOString();
    await this.deps.resets.create(user.id, hash, expiresAt);
    await this.deps.mailer.deliver(user.email, plaintext, expiresAt);
    this.deps.logger.info("reset_token_issued", { user_id: user.id, expires_at: expiresAt });
  }

  async confirmPasscodeReset(token: string, newPasscode: string): Promise<void> {
    assertPasscodeAcceptable(newPasscode);
    const record = await this.deps.resets.findValidByHash(hashResetToken(token), new Date());
    if (!record) {
      throw new AuthError("invalid_reset_token", "reset token is invalid, expired, or already used");
    }
    await this.deps.users.updatePasscodeHash(record.userId, await hashPasscode(newPasscode));
    // Marked used only after the new passcode lands, so a failed write cannot
    // burn the token and lock the account out.
    await this.deps.resets.markUsed(record.id, new Date().toISOString());
    this.deps.logger.info("passcode_reset_confirmed", { user_id: record.userId });
  }
}

/**
 * A well-formed hash of a value nobody knows, used to equalise the timing of a
 * login against a non-existent account. Generated once per process.
 */
const DUMMY_HASH =
  "scrypt$16384$8$1$AAAAAAAAAAAAAAAAAAAAAA==$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=";

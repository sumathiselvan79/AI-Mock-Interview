/**
 * Passcode hashing — INSTRUCTIONS.md §8: "passcodes are stored as salted
 * hashes, never plaintext."
 *
 * scrypt from node:crypto: memory-hard, no native dependency to build on
 * Windows, and the parameters are encoded in the stored string so they can be
 * raised later without invalidating existing rows.
 */

import { randomBytes, scrypt as scryptCb, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";

const scrypt = promisify(scryptCb) as (
  password: string | Buffer,
  salt: string | Buffer,
  keylen: number,
  options: { N: number; r: number; p: number; maxmem: number },
) => Promise<Buffer>;

const PARAMS = { N: 16384, r: 8, p: 1, keylen: 32 };
const MAXMEM = 64 * 1024 * 1024;
const SALT_BYTES = 16;

export const MIN_PASSCODE_LENGTH = 8;

export class WeakPasscodeError extends Error {
  readonly code = "weak_passcode";
  constructor(message: string) {
    super(message);
    this.name = "WeakPasscodeError";
  }
}

export function assertPasscodeAcceptable(passcode: string): void {
  if (passcode.length < MIN_PASSCODE_LENGTH) {
    throw new WeakPasscodeError(`passcode must be at least ${MIN_PASSCODE_LENGTH} characters`);
  }
}

/** Returns `scrypt$N$r$p$saltB64$hashB64`. The plaintext never leaves this function. */
export async function hashPasscode(passcode: string): Promise<string> {
  assertPasscodeAcceptable(passcode);
  const salt = randomBytes(SALT_BYTES);
  const derived = await scrypt(passcode, salt, PARAMS.keylen, { ...PARAMS, maxmem: MAXMEM });
  return [
    "scrypt",
    PARAMS.N,
    PARAMS.r,
    PARAMS.p,
    salt.toString("base64"),
    derived.toString("base64"),
  ].join("$");
}

/** Constant-time verification. Returns false on any malformed stored value rather than throwing. */
export async function verifyPasscode(passcode: string, stored: string): Promise<boolean> {
  const parts = stored.split("$");
  if (parts.length !== 6 || parts[0] !== "scrypt") return false;

  const [, nRaw, rRaw, pRaw, saltB64, hashB64] = parts;
  const N = Number(nRaw);
  const r = Number(rRaw);
  const p = Number(pRaw);
  if (!Number.isInteger(N) || !Number.isInteger(r) || !Number.isInteger(p)) return false;

  const expected = Buffer.from(hashB64 ?? "", "base64");
  if (expected.length === 0) return false;

  try {
    const derived = await scrypt(passcode, Buffer.from(saltB64 ?? "", "base64"), expected.length, {
      N,
      r,
      p,
      maxmem: MAXMEM,
    });
    return derived.length === expected.length && timingSafeEqual(derived, expected);
  } catch {
    return false;
  }
}

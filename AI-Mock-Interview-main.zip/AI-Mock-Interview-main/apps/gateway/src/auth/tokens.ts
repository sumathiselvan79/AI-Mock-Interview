/**
 * Role-scoped auth tokens and single-use reset tokens (INSTRUCTIONS.md §7–8).
 *
 * HS256, implemented on node:crypto — the token carries the role so the gateway
 * can enforce RBAC on every request without a database round trip, and is
 * signed so the role cannot be edited client-side.
 */

import { createHmac, randomBytes, createHash, timingSafeEqual } from "node:crypto";
import type {
  AuthTokenClaims,
  ConsentClaims,
  ConsentScope,
  ConsentVerdict,
  Role,
} from "@mia/shared-types";

function b64url(input: Buffer | string): string {
  return Buffer.from(input).toString("base64url");
}

function sign(data: string, secret: string): string {
  return createHmac("sha256", secret).update(data).digest("base64url");
}

export interface MintSessionTokenInput {
  userId: string;
  email: string;
  role: Role;
  ttlSeconds: number;
  secret: string;
  now?: number;
}

/**
 * The one place a session JWT gets signed. Every identity path — passcode
 * login, dev-login, Google OAuth callback — ends here with a role that path
 * has already resolved (never a role read off the request body or a
 * provider's claims). Swapping or adding an identity check never touches
 * this function.
 */
export function mintSessionToken(
  input: MintSessionTokenInput,
): { token: string; claims: AuthTokenClaims } {
  const iat = Math.floor((input.now ?? Date.now()) / 1000);
  const claims: AuthTokenClaims = {
    sub: input.userId,
    email: input.email,
    role: input.role,
    iat,
    exp: iat + input.ttlSeconds,
  };
  const header = b64url(JSON.stringify({ alg: "HS256", typ: "JWT" }));
  const body = b64url(JSON.stringify(claims));
  const signature = sign(`${header}.${body}`, input.secret);
  return { token: `${header}.${body}.${signature}`, claims };
}

export type TokenFailure = "malformed" | "bad_signature" | "expired";

export type VerifyResult =
  | { ok: true; claims: AuthTokenClaims }
  | { ok: false; reason: TokenFailure };

export function verifyToken(token: string, secret: string, now = Date.now()): VerifyResult {
  const parts = token.split(".");
  if (parts.length !== 3) return { ok: false, reason: "malformed" };
  const [header, body, signature] = parts as [string, string, string];

  const expected = sign(`${header}.${body}`, secret);
  const a = Buffer.from(signature);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return { ok: false, reason: "bad_signature" };

  let claims: AuthTokenClaims;
  try {
    claims = JSON.parse(Buffer.from(body, "base64url").toString("utf8")) as AuthTokenClaims;
  } catch {
    return { ok: false, reason: "malformed" };
  }
  if (typeof claims.exp !== "number" || claims.exp * 1000 <= now) {
    return { ok: false, reason: "expired" };
  }
  if (claims.role !== "admin" && claims.role !== "student") return { ok: false, reason: "malformed" };

  return { ok: true, claims };
}

/**
 * Reset tokens: the plaintext is emailed once and never stored. Only its SHA-256
 * is persisted, so a database read cannot be replayed as a credential.
 */
export function generateResetToken(): { plaintext: string; hash: string } {
  const plaintext = randomBytes(32).toString("base64url");
  return { plaintext, hash: hashResetToken(plaintext) };
}

export function hashResetToken(plaintext: string): string {
  return createHash("sha256").update(plaintext).digest("hex");
}

/**
 * Session-scoped token minted for a live session and required on every MCP call
 * through the gateway (INSTRUCTIONS.md §2).
 */
export function issueSessionToken(sessionId: string, secret: string): string {
  const nonce = randomBytes(12).toString("base64url");
  return `${sessionId}.${nonce}.${sign(`${sessionId}.${nonce}`, secret)}`;
}

/**
 * Consent tokens — one per scope, bound to a session (soul.md
 * §"Consent-first monitoring").
 *
 * Signed rather than looked up so a tool can verify consent without a database
 * round trip on a hot path, and scoped so agreeing to telemetry never silently
 * enables clipboard monitoring.
 */
export function issueConsentToken(
  sessionId: string,
  scope: ConsentScope,
  secret: string,
  now = Date.now(),
): string {
  const claims: ConsentClaims = { sessionId, scope, grantedAt: Math.floor(now / 1000) };
  const payload = b64url(JSON.stringify(claims));
  return `${payload}.${sign(payload, secret)}`;
}

export function verifyConsentToken(
  token: string | undefined,
  sessionId: string,
  scope: ConsentScope,
  secret: string,
): ConsentVerdict {
  if (!token) return { ok: false, reason: "missing" };

  const parts = token.split(".");
  if (parts.length !== 2) return { ok: false, reason: "malformed" };
  const [payload, signature] = parts as [string, string];

  const expected = sign(payload, secret);
  const a = Buffer.from(signature);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return { ok: false, reason: "bad_signature" };

  let claims: ConsentClaims;
  try {
    claims = JSON.parse(Buffer.from(payload, "base64url").toString("utf8")) as ConsentClaims;
  } catch {
    return { ok: false, reason: "malformed" };
  }

  // Bound to one session and one scope: a token minted for another candidate,
  // or for a different kind of monitoring, is not consent for this call.
  if (claims.sessionId !== sessionId) return { ok: false, reason: "wrong_session" };
  if (claims.scope !== scope) return { ok: false, reason: "wrong_scope" };

  return { ok: true, claims };
}

export function verifySessionToken(token: string, sessionId: string, secret: string): boolean {
  const parts = token.split(".");
  if (parts.length !== 3) return false;
  const [tokenSessionId, nonce, signature] = parts as [string, string, string];
  if (tokenSessionId !== sessionId) return false;
  const expected = sign(`${tokenSessionId}.${nonce}`, secret);
  const a = Buffer.from(signature);
  const b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
}

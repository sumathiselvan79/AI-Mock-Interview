/**
 * POST /auth/dev-login — local development convenience only.
 *
 * Mounted by app.ts only when `config.devAuthEnabled` is true, which itself
 * requires NODE_ENV !== "production" AND ALLOW_DEV_AUTH=true (config.ts). Do
 * not weaken that gate here — this route skips every credential check.
 */

import { Router } from "express";
import type { AuthService } from "../../auth/service.js";
import { requireString } from "./validate.js";

export function devAuthRoutes(auth: AuthService): Router {
  const router = Router();

  router.post("/dev-login", async (req, res, next) => {
    try {
      const email = requireString(req.body, "email");
      // The request body may include a `role` for the developer's own
      // bookkeeping (which persona this test email is meant to be), but it
      // is never read here. identityLogin() resolves the real role from the
      // admin-email allowlist — exactly the same rule every other identity
      // path (Google OAuth included) goes through, so a typed-in "role":
      // "admin" cannot mint an admin token.
      const { token, user } = await auth.identityLogin(email);
      res.status(200).json({ token, user });
    } catch (err) {
      next(err);
    }
  });

  return router;
}

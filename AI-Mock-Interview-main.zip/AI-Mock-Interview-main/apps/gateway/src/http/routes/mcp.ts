/**
 * Development-only passthrough to the MCP Gateway.
 *
 * The frontend never speaks MCP (CLAUDE.md §5) — this route exists so a human
 * can fire a call by hand and watch the auth / rate-limit / schema / telemetry
 * path work, which is Stage 1 gate test 4. It is not mounted in production.
 */

import { Router } from "express";
import type { McpGateway } from "../../mcp/gateway.js";
import type { Storage } from "../../storage/types.js";
import { badRequest, notFound } from "../errors.js";
import { assertOwnsOrAdmin } from "../middleware/auth.js";

export function mcpRoutes(mcp: McpGateway, storage: Storage): Router {
  const router = Router();

  router.get("/servers", (_req, res) => {
    res.json({ servers: mcp.registered() });
  });

  router.post("/call", async (req, res, next) => {
    try {
      const body = (req.body ?? {}) as {
        session_id?: unknown;
        server?: unknown;
        method?: unknown;
        params?: unknown;
        caller?: unknown;
      };
      if (typeof body.session_id !== "string") throw badRequest("invalid_request", "session_id is required");
      if (typeof body.server !== "string") throw badRequest("invalid_request", "server is required");
      if (typeof body.method !== "string") throw badRequest("invalid_request", "method is required");

      const session = await storage.sessions.get(body.session_id);
      if (!session) throw notFound("unknown session");
      assertOwnsOrAdmin(req, session.candidateId);

      const sessionToken = (await storage.live.getSessionToken(session.id)) ?? "";
      const result = await mcp.call(body.server, body.method, body.params ?? {}, {
        sessionId: session.id,
        caller: typeof body.caller === "string" ? body.caller : "harness-agent",
        sessionToken,
      });

      res.status(result.ok ? 200 : 400).json(result);
    } catch (err) {
      next(err);
    }
  });

  return router;
}

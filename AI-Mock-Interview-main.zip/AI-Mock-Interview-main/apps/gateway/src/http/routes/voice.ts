/**
 * Stage 3 routes: spoken answers, the coding round, paste events, and serving
 * synthesised audio.
 *
 * The pattern from Stage 2 holds — these handlers check ownership, hand off to
 * the Harness Agent, and shape the reply. The one thing they add is the
 * low-confidence contract: when transcription is not trusted, the response is a
 * `202` carrying a retry instruction and (when available) a draft for the
 * candidate to correct. It is deliberately not a `201`, because nothing was
 * accepted, and deliberately not a `4xx`, because the candidate did nothing
 * wrong.
 */

import { Router } from "express";
import { McpHandlerError } from "@mia/shared-types";
import { TransitionRejected, type HarnessAgent } from "@mia/harness-agent";
import type { GatewayConfig } from "../../config.js";
import type { Storage } from "../../storage/types.js";
import { assertOwnsOrAdmin, requireRole } from "../middleware/auth.js";
import { HttpError, badRequest, notFound } from "../errors.js";

export interface VoiceRouteDeps {
  storage: Storage;
  harness: HarnessAgent;
  config: GatewayConfig;
  speechProviderName?: string;
}

function toHttpError(err: unknown): HttpError {
  if (err instanceof McpHandlerError) {
    switch (err.code) {
      case "consent_missing":
      case "consent_invalid":
        return new HttpError(403, err.code, err.message);
      case "no_active_round":
        return new HttpError(409, err.code, err.message);
      case "unsupported_language":
      case "insufficient_transcript":
      case "insufficient_evidence":
        return new HttpError(422, err.code, err.message);
      case "transcription_failed":
      case "synthesis_failed":
        return new HttpError(502, err.code, err.message);
      default:
        return new HttpError(502, err.code, err.message);
    }
  }
  if (err instanceof TransitionRejected) return new HttpError(409, "illegal_transition", err.message);
  return err as HttpError;
}

export function voiceRoutes(deps: VoiceRouteDeps): Router {
  const router = Router({ mergeParams: true });
  const { storage, harness, config } = deps;

  const loadOwnedSession = async (req: Parameters<Parameters<Router["get"]>[1]>[0]) => {
    const session = await storage.sessions.get(req.params.id as string);
    if (!session) throw notFound("unknown session");
    assertOwnsOrAdmin(req, session.candidateId);
    return session;
  };

  // POST /sessions/:id/answers/audio — a spoken answer.
  router.post("/answers/audio", requireRole("student"), async (req, res, next) => {
    try {
      const session = await loadOwnedSession(req);
      const body = (req.body ?? {}) as {
        question_id?: unknown;
        audio_base64?: unknown;
        content_type?: unknown;
      };

      if (typeof body.question_id !== "string") {
        throw badRequest("invalid_request", "question_id is required");
      }
      if (typeof body.audio_base64 !== "string" || body.audio_base64 === "") {
        throw badRequest("invalid_request", "audio_base64 is required");
      }

      const bytes = Buffer.from(body.audio_base64, "base64");
      if (bytes.byteLength === 0) throw badRequest("invalid_request", "audio_base64 decoded to zero bytes");
      if (bytes.byteLength > config.maxAudioBytes) {
        throw new HttpError(413, "file_too_large", `recording exceeds ${config.maxAudioBytes} bytes`);
      }

      // Stored so the Speech Service can read it by reference; it deletes the
      // blob as soon as a transcript exists, unless the candidate opted into
      // keeping recordings (§8).
      const stored = await storage.files.put({
        sessionId: session.id,
        filename: `answer-${Date.now()}.wav`,
        contentType: typeof body.content_type === "string" ? body.content_type : "audio/wav",
        bytes,
      });

      const outcome = await harness.submitAudioAnswer({
        sessionId: session.id,
        questionId: body.question_id,
        audioRef: stored.ref,
      });

      if (!outcome.accepted) {
        res.status(202).json({
          accepted: false,
          action: "retry_or_type",
          reason: outcome.retry.reason,
          confidence: outcome.retry.confidence ?? null,
          // Shown to the candidate to correct. Never scored as-is.
          draft_transcript: outcome.retry.draftTranscript ?? null,
          message:
            "That recording was hard to make out. Say it again, or type what you meant — nothing has been scored yet.",
        });
        return;
      }

      res.status(201).json({
        accepted: true,
        answer_id: outcome.result.answer.id,
        transcript: outcome.result.answer.transcript,
        transcript_confidence: outcome.result.answer.transcriptConfidence ?? null,
        evaluation: outcome.result.evaluation,
        ...(outcome.result.evaluationNote ? { evaluation_note: outcome.result.evaluationNote } : {}),
        follow_up: outcome.result.followUp,
      });
    } catch (err) {
      next(toHttpError(err));
    }
  });

  // GET /audio/:ref — serves synthesised question audio.
  router.get("/audio/*splat", async (req, res, next) => {
    try {
      const session = await loadOwnedSession(req);
      // Express 5 hands a wildcard back as an array of path segments; file refs
      // contain slashes, so they have to be rejoined rather than stringified.
      const splat = (req.params as Record<string, unknown>).splat;
      const ref = Array.isArray(splat) ? splat.join("/") : String(splat ?? "");
      const stored = await storage.files.get(ref);

      if (!stored) throw notFound("that audio is no longer available");
      // A ref from another session must not be readable through this one.
      if (stored.meta.sessionId !== session.id) throw notFound("that audio is no longer available");

      res.setHeader("content-type", stored.meta.contentType);
      res.setHeader("cache-control", "no-store");
      if (deps.speechProviderName) {
        res.setHeader("x-speech-provider", deps.speechProviderName);
        res.setHeader("access-control-expose-headers", "x-speech-provider, content-type");
      }
      res.send(Buffer.from(stored.bytes));
    } catch (err) {
      next(toHttpError(err));
    }
  });

  // POST /sessions/:id/coding-round — QUESTION_LOOP -> CODING_ROUND.
  router.post("/coding-round", requireRole("student"), async (req, res, next) => {
    try {
      const session = await loadOwnedSession(req);
      const started = await harness.startCodingRound(session.id);
      res.status(201).json({
        problem: started.problem,
        clipboard_monitoring: started.clipboardMonitoring,
        audio_url: started.spoken.audioUrl ?? null,
        ...(started.spoken.speechNote ? { speech_note: started.spoken.speechNote } : {}),
      });
    } catch (err) {
      next(toHttpError(err));
    }
  });

  router.post("/coding-round/submissions", requireRole("student"), async (req, res, next) => {
    try {
      const session = await loadOwnedSession(req);
      const body = (req.body ?? {}) as { code?: unknown; language?: unknown; talk_through?: unknown };
      if (typeof body.code !== "string" || body.code.trim() === "") {
        throw badRequest("invalid_request", "code is required");
      }

      const result = await harness.submitCode({
        sessionId: session.id,
        code: body.code,
        ...(typeof body.language === "string" ? { language: body.language } : {}),
        ...(typeof body.talk_through === "string" ? { talkThrough: body.talk_through } : {}),
      });
      res.status(201).json(result);
    } catch (err) {
      next(toHttpError(err));
    }
  });

  // POST /sessions/:id/paste-events — the frontend reporting a paste.
  // Body carries a timestamp and nothing else: there is no field for content,
  // so the pasted text cannot reach the server even by mistake (soul.md §5).
  router.post("/paste-events", requireRole("student"), async (req, res, next) => {
    try {
      const session = await loadOwnedSession(req);
      const body = (req.body ?? {}) as { timestamp?: unknown };
      const timestamp = typeof body.timestamp === "string" ? body.timestamp : new Date().toISOString();

      const recorded = await harness.recordPasteEvent(session.id, timestamp);
      res.status(recorded ? 201 : 200).json({ recorded });
    } catch (err) {
      next(toHttpError(err));
    }
  });

  // POST /sessions/:id/focus-events — the frontend reporting a fullscreen
  // exit. REST counterpart of the live channel's `focus_lost` message, for
  // callers that are not on the WebSocket (soul.md §5: a timestamp only).
  // Past MAX_FOCUS_EXITS the harness has already wrapped the session up by
  // the time this responds — `concluded` tells the caller so.
  router.post("/focus-events", requireRole("student"), async (req, res, next) => {
    try {
      const session = await loadOwnedSession(req);
      const body = (req.body ?? {}) as { timestamp?: unknown };
      const timestamp = typeof body.timestamp === "string" ? body.timestamp : new Date().toISOString();

      const outcome = await harness.recordFocusEvent(session.id, timestamp);
      res.status(outcome.recorded ? 201 : 200).json({
        recorded: outcome.recorded,
        exit_count: outcome.exitCount,
        concluded: outcome.concluded,
      });
    } catch (err) {
      next(toHttpError(err));
    }
  });

  // POST /sessions/:id/wrap-up — the harness's closing message.
  router.post("/wrap-up", requireRole("student"), async (req, res, next) => {
    try {
      const session = await loadOwnedSession(req);
      const result = await harness.wrapUp(session.id);
      res.json({
        state: result.session.state,
        message: result.spoken.text,
        audio_url: result.spoken.audioUrl ?? null,
      });
    } catch (err) {
      next(toHttpError(err));
    }
  });

  // POST /sessions/:id/report — WRAP_UP -> REPORT_GENERATION -> COMPLETED.
  // Compiles and persists the report; idempotent, since a report already on
  // file is just returned rather than regenerated.
  router.post("/report", requireRole("student"), async (req, res, next) => {
    try {
      const session = await loadOwnedSession(req);
      const existing = await storage.reports.getBySession(session.id);
      if (existing) {
        res.json({ state: session.state, report: existing });
        return;
      }
      const { session: updated, report } = await harness.generateReport(session.id);
      res.status(201).json({ state: updated.state, report });
    } catch (err) {
      next(toHttpError(err));
    }
  });

  // GET /sessions/:id/report — INSTRUCTIONS.md §7: fetch the final report once
  // COMPLETED. A plain read; it never triggers generation itself.
  router.get("/report", async (req, res, next) => {
    try {
      const session = await loadOwnedSession(req);
      const report = await storage.reports.getBySession(session.id);
      if (!report) throw notFound("no report for this session yet");
      res.json({ state: session.state, report });
    } catch (err) {
      next(toHttpError(err));
    }
  });

  return router;
}

/**
 * Admin-only routes (INSTRUCTIONS.md §7).
 *
 * Admins read `Report` records across candidates and nothing more: no raw
 * resumes, audio, or transcripts beyond what a report already contains
 * (soul.md §5, §"Admin role"). A `Report` is exactly that boundary already —
 * it has no field for a resume, transcript, or audio ref — so serving the
 * stored record as-is satisfies the access rule without needing a separate
 * redaction step here.
 */

import { Router } from "express";
import type { Storage } from "../../storage/types.js";
import { requireRole } from "../middleware/auth.js";
import { notFound } from "../errors.js";
import { adminUserRoutes } from "./admin-users.js";

export function adminRoutes(storage: Storage): Router {
  const router = Router();

  router.use(requireRole("admin"));

  // (Stage 7) User directory, profile drill-down, report download and
  // scheduling. Mounted INSIDE the role gate above, so every route it adds is
  // admin-only by construction rather than by remembering (ADMIN_FEATURE_PROMPT.md).
  router.use(adminUserRoutes(storage));

  // GET /admin/reports — the aggregated Admin Home dashboard (INSTRUCTIONS.md
  // §3.1): every candidate's report, independent of whether their session is
  // still connected (§4.8).
  router.get("/reports", async (_req, res, next) => {
    try {
      const reports = await storage.reports.listAll();
      res.json({ reports });
    } catch (err) {
      next(err);
    }
  });

  // GET /admin/reports/:sessionId — one candidate's full report.
  router.get("/reports/:sessionId", async (req, res, next) => {
    try {
      const report = await storage.reports.getBySession(req.params.sessionId as string);
      if (!report) throw notFound("no report for that session");
      res.json({ report });
    } catch (err) {
      next(err);
    }
  });

  // ------------------------------------------------ (Stage 5) session archives
  //
  // The archive is the one place an Admin sees more than a `Report`, and it is
  // allowed to exist only because of what it is NOT: it is compiled after the
  // retention job, so a transcript the policy already redacted is redacted here
  // too (§11.4, soul.md §5). Access is audited on both routes — a consolidated
  // cross-table document is elevated access, so being permitted is not enough,
  // it must also be recorded (§8).
  //
  // Supabase itself is never exposed to any client: these two routes are the
  // only way in, and they read it server-side through a service-role
  // credential (§8 "Archive access boundary", §11.4).

  router.get("/archives", async (_req, res, next) => {
    try {
      if (!storage.archives) throw notFound("archiving is not configured for this deployment");
      res.json({ archives: await storage.archives.list() });
    } catch (err) {
      next(err);
    }
  });

  // Metadata only — no `document` body, so the listing view cannot become an
  // unaudited way to read transcripts (§7).
  router.get("/archives/:sessionId", async (req, res, next) => {
    try {
      if (!storage.archives) throw notFound("archiving is not configured for this deployment");
      const sessionId = req.params.sessionId as string;
      const summary = await storage.archives.summary(sessionId);
      if (!summary) throw notFound("no archive for that session");

      await storage.telemetry.emit("archive_viewed", sessionId, {
        admin_id: req.auth!.sub,
        candidate_id: summary.candidateId,
      });
      res.json({ archive: summary });
    } catch (err) {
      next(err);
    }
  });

  router.get("/archives/:sessionId/download", async (req, res, next) => {
    try {
      if (!storage.archives) throw notFound("archiving is not configured for this deployment");
      const sessionId = req.params.sessionId as string;
      const archive = await storage.archives.get(sessionId);
      if (!archive) throw notFound("no archive for that session");

      // Emitted BEFORE the body is streamed, so a download that fails midway is
      // still recorded as having been requested. IDs and counts only — the
      // audit trail must not become a second copy of the document (§8).
      await storage.telemetry.emit("archive_downloaded", sessionId, {
        admin_id: req.auth!.sub,
        candidate_id: archive.candidateId,
        questions: archive.document.questions.length,
        answers: archive.document.answers.length,
        archived_at: archive.archivedAt,
      });

      res.setHeader("content-type", "application/json");
      res.setHeader("content-disposition", `attachment; filename="session-${sessionId}.json"`);
      res.status(200).send(JSON.stringify(archive.document, null, 2));
    } catch (err) {
      next(err);
    }
  });

  return router;
}

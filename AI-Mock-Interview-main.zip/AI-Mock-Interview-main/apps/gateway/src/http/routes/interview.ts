/**
 * Interview Config + QUESTION_LOOP routes — INSTRUCTIONS.md §7.
 *
 * These handlers do three things and nothing more: check the caller owns the
 * session, hand off to the Harness Agent, and shape the reply. No interview
 * logic lives here, and nothing here writes `Session.state`.
 *
 * Resume upload takes base64 JSON rather than multipart. It keeps the raw bytes
 * inside a single validated body, avoids a streaming-upload dependency in the
 * gateway, and makes the size cap trivially enforceable before anything is
 * written to disk.
 */

import { Router } from "express";
import { McpHandlerError, type JdFit } from "@mia/shared-types";
import { TransitionRejected, type HarnessAgent } from "@mia/harness-agent";
import type { GatewayConfig } from "../../config.js";
import type { Logger } from "../../logging/logger.js";
import type { Storage } from "../../storage/types.js";
import { assertOwnsOrAdmin, requireRole } from "../middleware/auth.js";
import { HttpError, badRequest, notFound } from "../errors.js";

export interface InterviewRouteDeps {
  storage: Storage;
  harness: HarnessAgent;
  config: GatewayConfig;
  logger: Logger;
}

const ACCEPTED_RESUME_TYPES = new Set([
  "application/pdf",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "text/plain",
  "text/markdown",
]);

/** Maps an agent's MCP error onto an HTTP status the frontend can act on. */
/**
 * (Stage 5) One wire shape for `JdFit`, used by both the upload response and
 * the config page's read, so the two cannot drift.
 *
 * The Stage 5 fields are omitted rather than nulled when the provider was
 * unavailable or a claim failed grounding — with one exception:
 * `insufficient_signal` is present precisely so a reader can tell "the model
 * had nothing to say" apart from "the model was never asked" (§11.3).
 */
function jdFitToWire(jdFit: JdFit) {
  return {
    fit_score: jdFit.fitScore,
    matched_requirements: jdFit.matchedRequirements,
    gaps: jdFit.gaps,
    ...(jdFit.rationale === undefined ? {} : { rationale: jdFit.rationale }),
    ...(jdFit.topicRelevance === undefined
      ? {}
      : {
          topic_relevance: jdFit.topicRelevance.map((t) => ({
            topic: t.topic,
            relevance_score: t.relevanceScore,
            evidence: t.evidence,
          })),
        }),
    ...(jdFit.promptVersion === undefined ? {} : { prompt_version: jdFit.promptVersion }),
    ...(jdFit.insufficientSignal === undefined || jdFit.insufficientSignal.length === 0
      ? {}
      : { insufficient_signal: jdFit.insufficientSignal }),
    ...(jdFit.roleLevel === undefined ? {} : { role_level: jdFit.roleLevel }),
    ...(jdFit.keyTechnologies === undefined ? {} : { key_technologies: jdFit.keyTechnologies }),
  };
}

function toHttpError(err: unknown): HttpError {
  if (err instanceof McpHandlerError) {
    switch (err.code) {
      case "unsupported_format":
      case "parse_failed":
        return new HttpError(422, err.code, err.message);
      case "insufficient_transcript":
        return new HttpError(422, err.code, err.message);
      case "no_questions_available":
        return new HttpError(409, err.code, err.message);
      case "rate_limited":
        return new HttpError(429, err.code, err.message);
      default:
        return new HttpError(502, err.code, err.message);
    }
  }
  if (err instanceof TransitionRejected) {
    return new HttpError(409, "illegal_transition", err.message);
  }
  return err as HttpError;
}

export function interviewRoutes(deps: InterviewRouteDeps): Router {
  const router = Router({ mergeParams: true });
  const { storage, harness, config } = deps;

  const loadOwnedSession = async (req: Parameters<Parameters<Router["get"]>[1]>[0]) => {
    const session = await storage.sessions.get(req.params.id as string);
    if (!session) throw notFound("unknown session");
    assertOwnsOrAdmin(req, session.candidateId);
    return session;
  };

  // POST /sessions/:id/resume — upload; triggers parsing + the JD-fit check.
  router.post("/resume", requireRole("student"), async (req, res, next) => {
    try {
      const session = await loadOwnedSession(req);
      const body = (req.body ?? {}) as {
        filename?: unknown;
        content_type?: unknown;
        data_base64?: unknown;
      };

      if (typeof body.filename !== "string" || body.filename.trim() === "") {
        throw badRequest("invalid_request", "filename is required");
      }
      if (typeof body.data_base64 !== "string" || body.data_base64 === "") {
        throw badRequest("invalid_request", "data_base64 is required");
      }
      const contentType = typeof body.content_type === "string" ? body.content_type : "application/octet-stream";
      if (!ACCEPTED_RESUME_TYPES.has(contentType) && !/\.(pdf|docx|txt|md)$/i.test(body.filename)) {
        throw new HttpError(
          415,
          "unsupported_format",
          `${contentType} is not an accepted resume format; upload a pdf, docx, txt or md file`,
        );
      }

      const bytes = Buffer.from(body.data_base64, "base64");
      if (bytes.byteLength === 0) throw badRequest("invalid_request", "data_base64 decoded to zero bytes");
      if (bytes.byteLength > config.maxResumeBytes) {
        throw new HttpError(
          413,
          "file_too_large",
          `resume is ${bytes.byteLength} bytes; the limit is ${config.maxResumeBytes}`,
        );
      }

      // Replacing a resume hard-deletes the previous one rather than orphaning
      // it in storage (§8).
      if (session.resumeRef) await storage.files.delete(session.resumeRef);

      const stored = await storage.files.put({
        sessionId: session.id,
        filename: body.filename,
        contentType,
        bytes,
      });
      await storage.sessions.patch(session.id, { resumeRef: stored.ref });

      const profiled = await harness.profileResume(session.id);

      res.status(201).json({
        resume: { filename: stored.filename, size_bytes: stored.sizeBytes, uploaded_at: stored.uploadedAt },
        jd_fit: profiled.jdFit,
        topic_relevance: profiled.topicRelevance,
      });
    } catch (err) {
      next(toHttpError(err));
    }
  });

  // DELETE /sessions/:id/resume — hard-deletes the stored file (§8). The
  // structured profile survives, so a configured session still works.
  router.delete("/resume", requireRole("student"), async (req, res, next) => {
    try {
      const session = await loadOwnedSession(req);
      if (!session.resumeRef) throw notFound("no resume uploaded for this session");

      const deleted = await harness.deleteResume(session.id);
      res.json({ deleted });
    } catch (err) {
      next(toHttpError(err));
    }
  });

  // GET /sessions/:id/jd-fit — for the Interview Config page. Informational:
  // it never gates starting the interview (soul.md §3).
  router.get("/jd-fit", async (req, res, next) => {
    try {
      const session = await loadOwnedSession(req);
      res.json({
        jd_fit: session.jdFit ? jdFitToWire(session.jdFit) : null,
        // Same wire shape as the upload response, so the config page reads one
        // format whether it just uploaded or is reloading an existing session.
        topic_relevance: (session.candidateProfile?.topicRelevance ?? []).map((t) => ({
          topic: t.topic,
          relevance_score: t.relevanceScore,
          evidence: t.evidence,
        })),
        seniority_estimate: session.candidateProfile?.seniorityEstimate ?? null,
        note: "This shows what the interview will focus on. A low score means expect more questions in the gap areas — it is not a judgement on whether to apply.",
        blocks_start: false,
      });
    } catch (err) {
      next(toHttpError(err));
    }
  });

  // POST /sessions/:id/begin — CALIBRATION (build the topic plan) then
  // QUESTION_LOOP. The device-check gate is enforced inside the harness.
  router.post("/begin", requireRole("student"), async (req, res, next) => {
    try {
      const session = await loadOwnedSession(req);
      const started = await harness.beginInterview(session.id);
      res.json({ state: started.state, topic_plan: started.topicPlan });
    } catch (err) {
      next(toHttpError(err));
    }
  });

  // GET /sessions/:id/questions/next — one turn of the loop.
  router.get("/questions/next", requireRole("student"), async (req, res, next) => {
    try {
      const session = await loadOwnedSession(req);
      const result = await harness.nextQuestion(session.id);

      if (result.done) {
        res.json({
          done: true,
          note: result.note,
          asked_count: result.askedCount,
          question_budget: result.questionBudget,
        });
        return;
      }

      res.json({
        done: false,
        question: {
          id: result.question!.id,
          text: result.question!.text,
          topic: result.question!.topic,
          type: result.question!.type,
          difficulty: result.question!.difficulty,
          // (Stage 6, §4.3) Absent for a question asked before this field
          // existed — never backfilled, per the same rule as every other
          // optional field on this response.
          ...(result.question!.tier === undefined ? {} : { tier: result.question!.tier }),
          // Set by the Harness Agent via the Speech Service before the question
          // reaches the frontend (§4.1); null when synthesis failed and the
          // candidate reads it instead.
          audio_url: result.question!.audioUrl ?? null,
        },
        ...(result.speechNote ? { speech_note: result.speechNote } : {}),
        asked_count: result.askedCount,
        question_budget: result.questionBudget,
      });
    } catch (err) {
      next(toHttpError(err));
    }
  });

  // POST /sessions/:id/answers — typed answers. Stage 3 adds the audio path;
  // this stays as the fallback when transcription confidence is low.
  router.post("/answers", requireRole("student"), async (req, res, next) => {
    try {
      const session = await loadOwnedSession(req);
      const body = (req.body ?? {}) as {
        question_id?: unknown;
        transcript?: unknown;
        transcript_confidence?: unknown;
      };
      if (typeof body.question_id !== "string") {
        throw badRequest("invalid_request", "question_id is required");
      }
      if (typeof body.transcript !== "string") {
        throw badRequest("invalid_request", "transcript is required");
      }

      const result = await harness.submitAnswer({
        sessionId: session.id,
        questionId: body.question_id,
        transcript: body.transcript,
        ...(typeof body.transcript_confidence === "number"
          ? { transcriptConfidence: body.transcript_confidence }
          : {}),
      });

      res.status(201).json({
        answer_id: result.answer.id,
        // Null when the Eval Tool refused to score; `evaluation_note` says why,
        // rather than a low score being invented (soul.md §"No fabrication").
        evaluation: result.evaluation,
        ...(result.evaluationNote ? { evaluation_note: result.evaluationNote } : {}),
        follow_up: result.followUp,
        // (Stage 6, §4.4) Diagnostic detail in the same spirit as `follow_up.
        // reason` above — what was and wasn't demonstrated, never a preview of
        // a future question's content.
        ...(result.extraction
          ? {
              anti_patterns_detected: result.extraction.antiPatternsDetected,
              verified_concept_ids: result.extraction.verifiedConceptIds,
              unverified_concept_ids: result.extraction.unverifiedConceptIds,
            }
          : {}),
        ...(result.nextAction ? { next_action: result.nextAction.systemDirective } : {}),
        // (Stage 6, §12.6) One coherent runtime snapshot of this turn, composed
        // from state that's still owned exactly where it always was — see
        // `LiveSessionState`'s doc comment. Not a new stored shape.
        ...(result.liveSessionState
          ? {
              live_session_state: {
                session_id: result.liveSessionState.sessionId,
                candidate_id: result.liveSessionState.candidateId,
                active_topic_id: result.liveSessionState.activeTopicId,
                session_metrics: {
                  elapsed_time_seconds: result.liveSessionState.sessionMetrics.elapsedTimeSeconds,
                  topic_competency_score: result.liveSessionState.sessionMetrics.topicCompetencyScore,
                  current_demonstrated_tier: result.liveSessionState.sessionMetrics.currentDemonstratedTier,
                },
                context_engine: {
                  active_resume_anchor: result.liveSessionState.contextEngine.activeResumeAnchor,
                  last_delivered_prompt: result.liveSessionState.contextEngine.lastDeliveredPrompt,
                },
                extraction_processor: {
                  transcribed_input_chunk: result.liveSessionState.extractionProcessor.transcribedInputChunk,
                  verified_concept_ids: result.liveSessionState.extractionProcessor.verifiedConceptIds,
                  unverified_concept_ids: result.liveSessionState.extractionProcessor.unverifiedConceptIds,
                  anti_patterns_detected: result.liveSessionState.extractionProcessor.antiPatternsDetected,
                },
                next_action_generator: {
                  system_directive: result.liveSessionState.nextActionGenerator.systemDirective,
                  target_concept_id_for_next_prompt:
                    result.liveSessionState.nextActionGenerator.targetConceptIdForNextPrompt,
                  synthesized_framing_strategy: result.liveSessionState.nextActionGenerator.synthesizedFramingStrategy,
                  generated_follow_up_prompt: result.liveSessionState.nextActionGenerator.generatedFollowUpPrompt,
                },
              },
            }
          : {}),
      });
    } catch (err) {
      next(toHttpError(err));
    }
  });

  // POST /sessions/:id/answers/:answerId/follow-up — the reply to a probe.
  router.post("/answers/:answerId/follow-up", requireRole("student"), async (req, res, next) => {
    try {
      const session = await loadOwnedSession(req);
      const body = (req.body ?? {}) as { follow_up_text?: unknown; transcript?: unknown };
      if (typeof body.follow_up_text !== "string" || typeof body.transcript !== "string") {
        throw badRequest("invalid_request", "follow_up_text and transcript are required");
      }

      // Owning session `:id` is not the same as owning answer `:answerId`. An
      // answer from another session is reported as "unknown" rather than
      // "forbidden", so this route cannot be used to probe which answer ids
      // exist. The harness re-checks the same thing — this is the friendly
      // status code, not the security boundary.
      const answer = await deps.storage.answers.get(req.params.answerId as string);
      const question = answer ? await deps.storage.questions.get(answer.questionId) : null;
      if (!answer || !question || question.sessionId !== session.id) throw notFound("unknown answer");

      const updated = await harness.submitFollowUpAnswer({
        sessionId: session.id,
        answerId: answer.id,
        followUpText: body.follow_up_text,
        transcript: body.transcript,
      });
      res.status(201).json({ follow_ups: updated.followUps.length });
    } catch (err) {
      next(toHttpError(err));
    }
  });

  // GET /sessions/:id/transcript — what was asked and answered, for the review
  // screen. Owner or admin only, same as every other session read.
  router.get("/transcript", async (req, res, next) => {
    try {
      const session = await loadOwnedSession(req);
      const questions = await storage.questions.listBySession(session.id);
      const transcript = [];
      for (const question of questions) {
        const answer = await storage.answers.getByQuestion(question.id);
        transcript.push({
          question: { id: question.id, text: question.text, topic: question.topic, type: question.type },
          answer: answer
            ? { transcript: answer.transcript, follow_ups: answer.followUps, submitted_at: answer.submittedAt }
            : null,
          evaluations: answer ? await storage.evaluations.listByAnswer(answer.id) : [],
        });
      }
      res.json({ state: session.state, topic_plan: session.topicPlan, transcript });
    } catch (err) {
      next(toHttpError(err));
    }
  });

  return router;
}

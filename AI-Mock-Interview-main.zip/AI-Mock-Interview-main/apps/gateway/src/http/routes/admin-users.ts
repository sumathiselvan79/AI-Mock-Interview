/**
 * (Stage 7) Admin user directory, profile drill-down, report download, and
 * interview scheduling — `ADMIN_FEATURE_PROMPT.md`.
 *
 * Mounted under `/admin`, which already applies `requireRole("admin")` for
 * every route beneath it. The role gate is therefore not repeated per handler;
 * it is asserted per handler by the RBAC test instead, which is the check that
 * would actually catch someone remounting this router somewhere less careful.
 *
 * The data boundary, restated because this is the file most likely to erode
 * it: everything served here is either a candidate's own account metadata or
 * something already inside their `Report`. There is no handler that reads
 * `session.resumeRef`, `answers.transcript`, or a stored audio blob, and the
 * wire types have no field that could carry one (soul.md §"Admin role").
 */

import { Router } from "express";
import {
  DIRECTORY_SORT_KEYS,
  DIRECTORY_STATUSES,
  effectiveStatus,
  meanCompetencyScore,
  type CandidateProfileView,
  type CandidateSessionSummary,
  type DirectoryQuery,
  type DirectorySortKey,
  type DirectoryStatus,
  type Report,
  type Session,
  type SessionHistoryStatus,
  type User,
} from "@mia/shared-types";
import type { Storage } from "../../storage/types.js";
import { buildDirectoryPage, type DirectoryInputs } from "../../admin/directory.js";
import {
  ScheduleInvalid,
  draftToRows,
  toAdminWire,
  validateDraft,
} from "../../admin/scheduling.js";
import { badRequest, notFound } from "../errors.js";

/** `Session.state` collapsed to the three states the history list shows. */
function historyStatus(state: Session["state"]): SessionHistoryStatus {
  if (state === "COMPLETED") return "completed";
  if (state === "ABORTED") return "abandoned";
  return "in_progress";
}

/**
 * Wall-clock minutes from session creation to its last write.
 *
 * Null while the session is still running: `updatedAt` on a live session is
 * "when something last happened", not "when it ended", and reporting that as a
 * duration would show a number that shrinks and grows as the page is reloaded.
 */
function durationMinutes(session: Session): number | null {
  if (historyStatus(session.state) === "in_progress") return null;
  const ms = new Date(session.updatedAt).getTime() - new Date(session.createdAt).getTime();
  return ms > 0 ? Math.round(ms / 60_000) : 0;
}

function parseNumber(value: unknown): number | undefined {
  if (typeof value !== "string" || value.trim() === "") return undefined;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : undefined;
}

function parseQuery(raw: Record<string, unknown>): DirectoryQuery {
  const sort = typeof raw.sort === "string" && (DIRECTORY_SORT_KEYS as readonly string[]).includes(raw.sort)
    ? (raw.sort as DirectorySortKey)
    : undefined;
  const status =
    typeof raw.status === "string" && (DIRECTORY_STATUSES as readonly string[]).includes(raw.status)
      ? (raw.status as DirectoryStatus)
      : undefined;

  return {
    ...(typeof raw.search === "string" ? { search: raw.search } : {}),
    ...(typeof raw.department === "string" && raw.department !== "" ? { department: raw.department } : {}),
    ...(status ? { status } : {}),
    ...(parseNumber(raw.min_score) === undefined ? {} : { minScore: parseNumber(raw.min_score)! }),
    ...(parseNumber(raw.max_score) === undefined ? {} : { maxScore: parseNumber(raw.max_score)! }),
    ...(typeof raw.from === "string" && raw.from !== "" ? { from: raw.from } : {}),
    ...(typeof raw.to === "string" && raw.to !== "" ? { to: raw.to } : {}),
    ...(sort ? { sort } : {}),
    ...(raw.direction === "asc" || raw.direction === "desc" ? { direction: raw.direction } : {}),
    ...(parseNumber(raw.page) === undefined ? {} : { page: parseNumber(raw.page)! }),
    ...(parseNumber(raw.page_size) === undefined ? {} : { pageSize: parseNumber(raw.page_size)! }),
  };
}

export function adminUserRoutes(storage: Storage): Router {
  const router = Router();

  /**
   * Everything the directory needs, in a fixed number of queries regardless of
   * how many candidates there are: accounts, report aggregates, open
   * schedules, session counts. Avatars are the one per-user read, and only for
   * the rows actually being returned — see the note at the call site.
   */
  async function directoryInputs(): Promise<Omit<DirectoryInputs, "avatars">> {
    const [students, reportStats, scheduledCandidateIds, sessionCounts] = await Promise.all([
      storage.users.listByRole("student"),
      storage.reports.aggregateByCandidate(),
      storage.scheduled.candidatesWithOpenSchedules(),
      storage.sessions.countsByCandidate(),
    ]);
    return { students, reportStats, scheduledCandidateIds, sessionCounts };
  }

  /**
   * Avatars for a bounded set of user ids.
   *
   * `OAuthProfileStore` is keyed by user id with no bulk read, and it lives in
   * the separate Supabase instance — so this is done for one PAGE of rows
   * (25 by default), after filtering and paging, rather than for every account
   * in the system. That keeps it off the N+1 path the spec rules out: the cost
   * is bounded by page size, not by directory size.
   */
  async function avatarsFor(userIds: string[]): Promise<Record<string, string>> {
    if (!storage.oauthProfiles) return {};
    const entries = await Promise.all(
      userIds.map(async (id) => {
        const profile = await storage.oauthProfiles!.getByUserId(id);
        return profile?.avatarUrl ? ([id, profile.avatarUrl] as const) : null;
      }),
    );
    return Object.fromEntries(entries.filter((e): e is readonly [string, string] => e !== null));
  }

  // GET /admin/users — the directory. Search, filter, sort, server-side paging.
  router.get("/users", async (req, res, next) => {
    try {
      const inputs = await directoryInputs();
      const query = parseQuery(req.query as Record<string, unknown>);

      // Paged first, then avatars, so the avatar lookups are bounded by page
      // size rather than by the number of accounts.
      const paged = buildDirectoryPage({ ...inputs, avatars: {} }, query);
      const avatars = await avatarsFor(paged.rows.map((r) => r.userId));

      res.json({
        rows: paged.rows.map((row) => ({
          user_id: row.userId,
          email: row.email,
          full_name: row.fullName,
          department: row.department,
          avatar_url: avatars[row.userId] ?? null,
          interviews_completed: row.interviewsCompleted,
          average_score: row.averageScore,
          last_interview_at: row.lastInterviewAt,
          created_at: row.createdAt,
          status: row.status,
        })),
        total: paged.total,
        page: paged.page,
        page_size: paged.pageSize,
        // So the filter dropdown offers what candidates actually put in the
        // free-text column, not only the canonical list.
        departments: [
          ...new Set(inputs.students.map((s) => s.department).filter((d): d is string => !!d)),
        ].sort(),
      });
    } catch (err) {
      next(err);
    }
  });

  // GET /admin/users/:userId — the profile drill-down.
  router.get("/users/:userId", async (req, res, next) => {
    try {
      const userId = req.params.userId as string;
      const user = await storage.users.findById(userId);
      // An Admin is not a candidate and has no interview history; treating them
      // as "not found" here keeps the directory and this page consistent.
      if (!user || user.role !== "student") throw notFound("unknown student");

      const [sessions, reports, profile] = await Promise.all([
        storage.sessions.listByCandidate(userId),
        storage.reports.listByCandidate(userId),
        storage.oauthProfiles?.getByUserId(userId) ?? Promise.resolve(null),
      ]);

      const reportBySession = new Map(reports.map((r) => [r.sessionId, r]));
      const summaries: CandidateSessionSummary[] = sessions
        .map((session) => {
          const report = reportBySession.get(session.id);
          return {
            sessionId: session.id,
            role: session.role,
            state: session.state,
            status: historyStatus(session.state),
            startedAt: session.createdAt,
            durationMinutes: durationMinutes(session),
            overallScore: report ? meanCompetencyScore(report.competencyScores) : null,
            hasReport: !!report,
          };
        })
        // Newest first, tie-broken on id. Two sessions created in the same
        // millisecond are not hypothetical — a seeded cohort or a fast script
        // produces them — and without the tie-break their order changes
        // between requests, which makes the history list appear to shuffle.
        .sort((a, b) => b.startedAt.localeCompare(a.startedAt) || b.sessionId.localeCompare(a.sessionId));

      // Oldest first: a trend line reads left to right.
      const scoreTrend = [...reports]
        .sort((a, b) => a.createdAt.localeCompare(b.createdAt))
        .map((report) => ({ at: report.createdAt, score: meanCompetencyScore(report.competencyScores) }))
        .filter((point): point is { at: string; score: number } => point.score !== null);

      const view: CandidateProfileView = {
        userId: user.id,
        email: user.email,
        fullName: user.fullName ?? null,
        department: user.department ?? null,
        programYear: user.programYear ?? null,
        avatarUrl: profile?.avatarUrl ?? null,
        createdAt: user.createdAt,
        interviewsCompleted: reports.length,
        averageScore:
          scoreTrend.length === 0
            ? null
            : scoreTrend.reduce((sum, p) => sum + p.score, 0) / scoreTrend.length,
        lastInterviewAt: reports.length === 0 ? null : reports[0]!.createdAt,
        scoreTrend,
        sessions: summaries,
      };

      const schedules = await storage.scheduled.listByCandidate(userId);

      res.json({
        profile: {
          user_id: view.userId,
          email: view.email,
          full_name: view.fullName,
          department: view.department,
          program_year: view.programYear,
          avatar_url: view.avatarUrl,
          created_at: view.createdAt,
          interviews_completed: view.interviewsCompleted,
          average_score: view.averageScore,
          last_interview_at: view.lastInterviewAt,
          score_trend: view.scoreTrend,
        },
        sessions: view.sessions.map((s) => ({
          session_id: s.sessionId,
          role: s.role,
          state: s.state,
          status: s.status,
          started_at: s.startedAt,
          duration_minutes: s.durationMinutes,
          overall_score: s.overallScore,
          has_report: s.hasReport,
        })),
        scheduled: schedules.map((s) => toAdminWire(s)),
      });
    } catch (err) {
      next(err);
    }
  });

  /**
   * GET /admin/users/:userId/reports/download — every report this candidate
   * has, as one JSON attachment.
   *
   * JSON with a `content-disposition`, following the precedent already set by
   * `GET /admin/archives/:id/download`, rather than adding a PDF toolchain for
   * one button. The payload is the stored `Report` objects verbatim — which is
   * exactly the boundary, since a `Report` has no resume, audio or transcript
   * field to leak.
   */
  router.get("/users/:userId/reports/download", async (req, res, next) => {
    try {
      const userId = req.params.userId as string;
      const user = await storage.users.findById(userId);
      if (!user || user.role !== "student") throw notFound("unknown student");

      const reports = await storage.reports.listByCandidate(userId);
      if (reports.length === 0) throw notFound("this candidate has no reports yet");

      await storage.telemetry.emit("admin_reports_downloaded", null, {
        admin_id: req.auth!.sub,
        candidate_id: userId,
        reports: reports.length,
      });

      res.setHeader("content-type", "application/json");
      res.setHeader("content-disposition", `attachment; filename="reports-${userId}.json"`);
      res.status(200).send(JSON.stringify({ candidate_id: userId, reports }, null, 2));
    } catch (err) {
      next(err);
    }
  });

  /** GET /admin/reports/:sessionId/download — one report as an attachment. */
  router.get("/reports/:sessionId/download", async (req, res, next) => {
    try {
      const sessionId = req.params.sessionId as string;
      const report = await storage.reports.getBySession(sessionId);
      if (!report) throw notFound("no report for that session");

      await storage.telemetry.emit("admin_reports_downloaded", sessionId, {
        admin_id: req.auth!.sub,
        candidate_id: report.candidateId,
        reports: 1,
      });

      res.setHeader("content-type", "application/json");
      res.setHeader("content-disposition", `attachment; filename="report-${sessionId}.json"`);
      res.status(200).send(JSON.stringify(report, null, 2));
    } catch (err) {
      next(err);
    }
  });

  // ------------------------------------------------------- scheduling

  // GET /admin/scheduled-interviews — everything, newest window first.
  router.get("/scheduled-interviews", async (_req, res, next) => {
    try {
      const schedules = await storage.scheduled.list();
      const students = await storage.users.listByRole("student");
      const byId = new Map(students.map((s) => [s.id, s]));

      res.json({
        scheduled: schedules.map((schedule) => ({
          ...toAdminWire(schedule),
          // Denormalised for display so the list does not need a second call
          // per row just to render a name.
          candidate_email: byId.get(schedule.candidateId)?.email ?? null,
          candidate_name: byId.get(schedule.candidateId)?.fullName ?? null,
        })),
      });
    } catch (err) {
      next(err);
    }
  });

  /**
   * POST /admin/scheduled-interviews — assign one interview to one or many
   * candidates. A batch writes one row per candidate, all or nothing.
   */
  router.post("/scheduled-interviews", async (req, res, next) => {
    try {
      const draft = validateDraft((req.body ?? {}) as Record<string, unknown>);

      // Every target must exist AND be a student. Scheduling an interview for
      // an Admin is not a thing (INSTRUCTIONS.md §3.2), and a typo'd id must
      // fail loudly rather than create an assignment nobody can ever start.
      const candidates: User[] = [];
      for (const id of draft.candidateIds) {
        const user = await storage.users.findById(id);
        if (!user || user.role !== "student") {
          throw badRequest("unknown_candidate", `${id} is not a student account`);
        }
        candidates.push(user);
      }

      const rows = draftToRows(draft, candidates, req.auth!.sub);
      const created = await storage.scheduled.createMany(rows);

      await storage.telemetry.emit("interviews_scheduled", null, {
        admin_id: req.auth!.sub,
        candidates: created.length,
        role: draft.role,
        interview_type: draft.interviewType,
        scheduled_for: draft.scheduledFor,
      });

      res.status(201).json({ scheduled: created.map((s) => toAdminWire(s)) });
    } catch (err) {
      if (err instanceof ScheduleInvalid) {
        next(badRequest("invalid_schedule", err.message));
        return;
      }
      next(err);
    }
  });

  /**
   * POST /admin/scheduled-interviews/:id/cancel — withdraw an assignment.
   *
   * Cancelling is terminal and never reverses a candidate's own progress: an
   * assignment they already started stays `started`, because the session it
   * seeded exists and its report will too.
   */
  router.post("/scheduled-interviews/:id/cancel", async (req, res, next) => {
    try {
      const id = req.params.id as string;
      const existing = await storage.scheduled.get(id);
      if (!existing) throw notFound("unknown scheduled interview");
      if (existing.status === "started" || existing.status === "completed") {
        throw badRequest(
          "already_started",
          "this interview has already been started and cannot be cancelled",
        );
      }

      const updated = await storage.scheduled.update(id, { status: "cancelled" });
      await storage.telemetry.emit("scheduled_interview_cancelled", null, {
        admin_id: req.auth!.sub,
        candidate_id: existing.candidateId,
      });
      res.json({ scheduled: toAdminWire(updated!) });
    } catch (err) {
      next(err);
    }
  });

  /** POST /admin/scheduled-interviews/:id/reschedule — move the window. */
  router.post("/scheduled-interviews/:id/reschedule", async (req, res, next) => {
    try {
      const id = req.params.id as string;
      const existing = await storage.scheduled.get(id);
      if (!existing) throw notFound("unknown scheduled interview");
      if (effectiveStatus(existing) === "started" || existing.status === "completed") {
        throw badRequest("already_started", "this interview has already been started");
      }

      const body = (req.body ?? {}) as Record<string, unknown>;
      // Reuses the create validator's rules by validating a whole draft, so
      // "deadline must be after scheduled_for" cannot hold on create and be
      // skipped here.
      const draft = validateDraft({
        candidate_ids: [existing.candidateId],
        role: existing.role,
        interview_type: existing.interviewType,
        difficulty: existing.difficulty,
        duration_minutes: existing.durationMinutes,
        scheduled_for: body.scheduled_for,
        deadline: body.deadline ?? null,
      });

      const updated = await storage.scheduled.update(id, {
        scheduledFor: draft.scheduledFor,
        deadline: draft.deadline,
        status: "pending",
      });
      res.json({ scheduled: toAdminWire(updated!) });
    } catch (err) {
      if (err instanceof ScheduleInvalid) {
        next(badRequest("invalid_schedule", err.message));
        return;
      }
      next(err);
    }
  });

  return router;
}

export type { Report };

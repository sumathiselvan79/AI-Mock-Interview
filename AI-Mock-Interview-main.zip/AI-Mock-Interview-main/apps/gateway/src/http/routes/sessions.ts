/**
 * Session routes — INSTRUCTIONS.md §7.
 *
 * Every route that changes `Session.state` goes through the Harness Agent; the
 * routes themselves never touch it. Stage 1 exposes the transitions explicitly
 * (`POST /sessions/:id/advance`) because there is no agent intelligence yet to
 * decide them; later stages drive the same harness method from agent results
 * instead of from the client.
 */

import { Router } from "express";
import type { SessionState } from "@mia/shared-types";
import {
  MAX_QUESTION_BUDGET,
  MIN_QUESTION_BUDGET,
  SESSION_STATES,
  effectiveStatus,
  isStartable,
  isValidQuestionBudget,
  runsCodingRound,
} from "@mia/shared-types";
import { HarnessAgent, TransitionRejected, allowedNextStates } from "@mia/harness-agent";
import { issueSessionToken } from "../../auth/tokens.js";
import type { GatewayConfig } from "../../config.js";
import type { Logger } from "../../logging/logger.js";
import type { Storage } from "../../storage/types.js";
import { assertOwnsOrAdmin, requireRole } from "../middleware/auth.js";
import { HttpError, badRequest, notFound } from "../errors.js";
import { interviewRoutes } from "./interview.js";

export interface SessionRouteDeps {
  storage: Storage;
  harness: HarnessAgent;
  config: GatewayConfig;
  logger: Logger;
}

export function sessionRoutes(deps: SessionRouteDeps): Router {
  const router = Router();
  const { storage, harness, config } = deps;

  // POST /sessions — students only. An Admin cannot start an interview as a
  // candidate (INSTRUCTIONS.md §3.2).
  router.post("/", requireRole("student"), async (req, res, next) => {
    try {
      const body = (req.body ?? {}) as {
        role?: unknown;
        job_description?: unknown;
        question_budget?: unknown;
        scheduled_interview_id?: unknown;
      };

      /**
       * (Stage 7) Starting an Admin-assigned interview.
       *
       * The schedule is session-SEED data and nothing more: it supplies the
       * role and JD the candidate would otherwise type, and the session it
       * creates is an ordinary one. It does not skip Interview Config, it does
       * not pre-answer consent, and no agent ever reads it — so this adds no
       * agent-to-agent path (CLAUDE.md §5).
       */
      let schedule: Awaited<ReturnType<typeof storage.scheduled.get>> = null;
      if (body.scheduled_interview_id !== undefined) {
        if (typeof body.scheduled_interview_id !== "string") {
          throw badRequest("invalid_request", "scheduled_interview_id must be a string");
        }
        schedule = await storage.scheduled.get(body.scheduled_interview_id);
        // Reported as "unknown" rather than "forbidden" when it belongs to
        // someone else, so this cannot be used to enumerate assignment ids.
        if (!schedule || schedule.candidateId !== req.auth!.sub) {
          throw notFound("unknown scheduled interview");
        }
        if (!isStartable(schedule)) {
          throw new HttpError(
            409,
            "not_startable",
            `this interview is ${effectiveStatus(schedule)} — it cannot be started right now`,
          );
        }
      }

      // The schedule's role fills in only when the candidate did not type one.
      const role = typeof body.role === "string" && body.role.trim() !== "" ? body.role : schedule?.role;
      if (typeof role !== "string" || role.trim() === "") {
        throw badRequest("invalid_request", "role is required");
      }
      // `question_budget` is the only session field the client chooses, and the
      // QUESTION_LOOP termination check is the only thing that reads it. A
      // `typeof === "number"` test let `NaN`, `Infinity`, `0`, negatives and
      // fractions straight through — and `questions_asked >= NaN` is false
      // forever, so the interview could never end on its own.
      if (body.question_budget !== undefined && !isValidQuestionBudget(body.question_budget)) {
        throw badRequest(
          "invalid_request",
          `question_budget must be a whole number between ${MIN_QUESTION_BUDGET} and ${MAX_QUESTION_BUDGET}`,
        );
      }
      const session = await storage.sessions.create({
        candidateId: req.auth!.sub,
        role,
        jobDescription:
          typeof body.job_description === "string"
            ? body.job_description
            : (schedule?.jobDescription ?? ""),
        ...(isValidQuestionBudget(body.question_budget) ? { questionBudget: body.question_budget } : {}),
      });

      // Session-scoped token required on every MCP call for this session (§2).
      const sessionToken = issueSessionToken(session.id, config.authTokenSecret);
      await storage.live.setSessionToken(session.id, sessionToken);

      await storage.telemetry.emit("session_created", session.id, {
        candidate_id: session.candidateId,
        role: session.role,
        question_budget: session.questionBudget,
      });

      // Claimed AFTER the session exists, so a failed create never leaves an
      // assignment marked started with nothing behind it. One assignment maps
      // to one session: `isStartable` above already refused a second attempt.
      if (schedule) {
        await storage.scheduled.update(schedule.id, { status: "started", sessionId: session.id });
        await storage.telemetry.emit("scheduled_interview_started", session.id, {
          candidate_id: session.candidateId,
          scheduled_interview_id: schedule.id,
        });
      }

      res.status(201).json({
        session_id: session.id,
        state: session.state,
        session_token: sessionToken,
        // Echoed so the Interview Config page can pre-fill from the assignment
        // rather than needing a second fetch. Config still runs — resume upload
        // and the JD-fit check are not skippable.
        ...(schedule
          ? {
              scheduled: {
                id: schedule.id,
                role: schedule.role,
                job_description: schedule.jobDescription,
                interview_type: schedule.interviewType,
                difficulty: schedule.difficulty,
                duration_minutes: schedule.durationMinutes,
                runs_coding_round: runsCodingRound(schedule),
              },
            }
          : {}),
      });
    } catch (err) {
      next(err);
    }
  });

  router.get("/:id", async (req, res, next) => {
    try {
      const session = await storage.sessions.get(req.params.id as string);
      if (!session) throw notFound("unknown session");
      assertOwnsOrAdmin(req, session.candidateId);
      res.json({
        session,
        allowed_next_states: allowedNextStates(session.state),
      });
    } catch (err) {
      next(err);
    }
  });

  // The audit trail behind Stage 1 gate test 3: every row's actor is the harness.
  router.get("/:id/transitions", async (req, res, next) => {
    try {
      const session = await storage.sessions.get(req.params.id as string);
      if (!session) throw notFound("unknown session");
      assertOwnsOrAdmin(req, session.candidateId);
      res.json({ transitions: await storage.sessions.transitions(session.id) });
    } catch (err) {
      next(err);
    }
  });

  // POST /sessions/:id/advance — asks the Harness Agent to move the session.
  // The handler has no authority of its own: an illegal move, or one gated
  // behind an unpassed telemetry check, comes back as a 409 from the harness.
  router.post("/:id/advance", requireRole("student"), async (req, res, next) => {
    try {
      const session = await storage.sessions.get(req.params.id as string);
      if (!session) throw notFound("unknown session");
      assertOwnsOrAdmin(req, session.candidateId);

      const body = (req.body ?? {}) as { to?: unknown; reason?: unknown };
      if (typeof body.to !== "string" || !(SESSION_STATES as readonly string[]).includes(body.to)) {
        throw badRequest("invalid_request", `to must be one of: ${SESSION_STATES.join(", ")}`);
      }

      const updated = await harness.transition(
        session.id,
        body.to as SessionState,
        typeof body.reason === "string" ? body.reason : "client_advance",
      );
      res.json({ session: updated, allowed_next_states: allowedNextStates(updated.state) });
    } catch (err) {
      if (err instanceof TransitionRejected) {
        next(new HttpError(409, "illegal_transition", err.message));
        return;
      }
      next(err);
    }
  });

  // POST /sessions/:id/telemetry-check — records the device check and the
  // per-session consent flags. Nothing downstream may start until this passes
  // (INSTRUCTIONS.md §3); consent captured here is what the Clipboard Monitor
  // and Speech Service check at the tool level in Stage 3.
  router.post("/:id/telemetry-check", requireRole("student"), async (req, res, next) => {
    try {
      const session = await storage.sessions.get(req.params.id as string);
      if (!session) throw notFound("unknown session");
      assertOwnsOrAdmin(req, session.candidateId);

      const body = (req.body ?? {}) as {
        mic_ok?: unknown;
        speaker_ok?: unknown;
        consent?: Record<string, unknown>;
      };
      const micOk = body.mic_ok === true;
      const speakerOk = body.speaker_ok === true;
      const passed = micOk && speakerOk;

      await storage.live.setDeviceCheck(session.id, {
        passed,
        micOk,
        speakerOk,
        at: new Date().toISOString(),
      });

      const consent = {
        telemetry: body.consent?.telemetry === true,
        clipboardMonitor: body.consent?.clipboard_monitor === true,
        audioRecording: body.consent?.audio_recording === true,
        crossSessionMemory: body.consent?.cross_session_memory === true,
        focusLossMonitoring: body.consent?.focus_loss_monitoring === true,
      };
      await storage.sessions.patch(session.id, { consent });

      await storage.telemetry.emit(passed ? "device_check_passed" : "device_check_failed", session.id, {
        mic_ok: micOk,
        speaker_ok: speakerOk,
        consent_telemetry: consent.telemetry,
        consent_clipboard_monitor: consent.clipboardMonitor,
        consent_audio_recording: consent.audioRecording,
        consent_focus_loss_monitoring: consent.focusLossMonitoring,
      });

      res.json({ passed, consent });
    } catch (err) {
      next(err);
    }
  });

  // Interview Config + QUESTION_LOOP live under the same /sessions/:id prefix.
  router.use("/:id", interviewRoutes(deps));

  return router;
}

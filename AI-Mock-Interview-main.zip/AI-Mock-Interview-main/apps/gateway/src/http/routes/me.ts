/**
 * Student-only routes. An admin token is rejected here exactly as a student
 * token is rejected on /admin/* — the Home page is role-specific by design
 * (INSTRUCTIONS.md §3.1, §3.2).
 */

import { Router } from "express";
import type { CandidateStats } from "@mia/shared-types";
import { STRENGTH_THRESHOLD } from "@mia/report-agent";
import { toStudentWire } from "../../admin/scheduling.js";
import type { AuthService } from "../../auth/service.js";
import type { Storage } from "../../storage/types.js";
import { HttpError } from "../errors.js";
import { requireRole } from "../middleware/auth.js";
import { optionalString } from "./validate.js";

const round1 = (n: number): number => Math.round(n * 10) / 10;

export function meRoutes(storage: Storage, auth: AuthService): Router {
  const router = Router();

  // GET /me/profile — (Stage 5, §11.4) lets the frontend tell whether this
  // candidate's profile is complete enough for their sessions to be archived.
  router.get("/profile", requireRole("student"), async (req, res, next) => {
    try {
      const user = await storage.users.findById(req.auth!.sub);
      if (!user) throw new HttpError(404, "unknown_user", "no such account");
      res.json({
        profile: {
          full_name: user.fullName ?? null,
          department: user.department ?? null,
          program_year: user.programYear ?? null,
        },
        // `fullName` is the only hard requirement: archiving refuses on it
        // rather than writing a candidate's archive with a blank name (§11.4).
        archive_ready: Boolean(user.fullName),
      });
    } catch (err) {
      next(err);
    }
  });

  // PATCH /me/profile — the catch-up path for an account created before these
  // fields existed, or one that skipped them at signup. Only the keys supplied
  // are written, so this cannot blank a field the candidate already gave.
  router.patch("/profile", requireRole("student"), async (req, res, next) => {
    try {
      const fullName = optionalString(req.body, "full_name");
      const department = optionalString(req.body, "department");
      const programYear = optionalString(req.body, "program_year");

      if (fullName === undefined && department === undefined && programYear === undefined) {
        throw new HttpError(
          400,
          "invalid_request",
          "supply at least one of full_name, department, program_year",
        );
      }

      const user = await auth.updateProfile(req.auth!.sub, {
        ...(fullName === undefined ? {} : { fullName }),
        ...(department === undefined ? {} : { department }),
        ...(programYear === undefined ? {} : { programYear }),
      });
      res.json({ user, archive_ready: Boolean(user.fullName) });
    } catch (err) {
      next(err);
    }
  });

  // GET /me/stats — the student Home page: past interview stats built from
  // real reports (INSTRUCTIONS.md §3.1, §7).
  router.get("/stats", requireRole("student"), async (req, res, next) => {
    try {
      const candidateId = req.auth!.sub;
      const sessions = await storage.sessions.listByCandidate(candidateId);
      const completed = sessions.filter((s) => s.state === "COMPLETED");
      const reports = await storage.reports.listByCandidate(candidateId);

      const allScores = reports.flatMap((r) => r.competencyScores.map((c) => c.score));
      const averageScore = allScores.length > 0 ? round1(allScores.reduce((a, b) => a + b, 0) / allScores.length) : null;

      // "Recurring" means named as a weak spot in more than one report — a
      // single off session is not a pattern worth surfacing back to the
      // candidate (soul.md §"Encouraging rigor").
      const weakCounts = new Map<string, number>();
      for (const report of reports) {
        for (const competency of report.competencyScores) {
          if (competency.score < STRENGTH_THRESHOLD) {
            weakCounts.set(competency.competency, (weakCounts.get(competency.competency) ?? 0) + 1);
          }
        }
      }
      const recurringFocusAreas = [...weakCounts.entries()]
        .filter(([, count]) => count >= 2)
        .sort((a, b) => b[1] - a[1])
        .map(([topic]) => topic);

      const stats: CandidateStats = {
        candidateId,
        sessionsCompleted: completed.length,
        averageScore,
        lastSessionAt: sessions[0]?.createdAt ?? null,
        recurringFocusAreas,
      };
      res.json({ stats, sessions_started: sessions.length });
    } catch (err) {
      next(err);
    }
  });

  /**
   * GET /me/scheduled-interviews — (Stage 7) what an Admin has assigned to this
   * candidate, for the Home page.
   *
   * The student projection, never the admin one: `notes` and `created_by` have
   * no key in the response rather than being stripped from it, so an
   * admin-internal note cannot reach a candidate through a field someone forgot
   * about (`admin/scheduling.ts` `toStudentWire`).
   *
   * Cancelled assignments are dropped entirely — an interview that was
   * withdrawn is not something to show a candidate and explain.
   */
  router.get("/scheduled-interviews", requireRole("student"), async (req, res, next) => {
    try {
      const schedules = await storage.scheduled.listByCandidate(req.auth!.sub);
      res.json({
        scheduled: schedules
          .filter((s) => s.status !== "cancelled")
          .map((s) => toStudentWire(s)),
      });
    } catch (err) {
      next(err);
    }
  });

  return router;
}

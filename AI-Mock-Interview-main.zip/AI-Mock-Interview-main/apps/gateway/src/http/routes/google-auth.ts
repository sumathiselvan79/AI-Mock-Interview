/**
 * GET /auth/google/start + GET /auth/google/callback (arctic-based OAuth).
 *
 * This is an *identity* path only: it proves "this email belongs to whoever
 * is sitting at the browser" and then hands the verified email to
 * AuthService.identityLogin(), the exact same function POST /auth/dev-login
 * calls. Nothing here mints a token, decides a role, or touches RBAC — see
 * auth/tokens.ts and auth/roles.ts, which this route does not modify.
 */

import { generateCodeVerifier, generateState } from "arctic";
import { Router, type Request, type Response } from "express";
import type { AuthService } from "../../auth/service.js";
import {
  extractVerifiedGoogleProfile,
  InvalidGoogleIdTokenError,
  OAuth2RequestError,
  type GoogleAuthClient,
} from "../../auth/google.js";
import type { GatewayConfig } from "../../config.js";
import { badRequest } from "../errors.js";

const STATE_COOKIE = "mia_oauth_state";
const VERIFIER_COOKIE = "mia_oauth_verifier";

function parseCookies(header: string | undefined): Record<string, string> {
  const out: Record<string, string> = {};
  if (!header) return out;
  for (const part of header.split(";")) {
    const eq = part.indexOf("=");
    if (eq === -1) continue;
    const name = part.slice(0, eq).trim();
    const value = part.slice(eq + 1).trim();
    if (name) out[name] = decodeURIComponent(value);
  }
  return out;
}

/**
 * Constant-time-ish comparison isn't the point here (the state isn't a
 * secret an attacker is brute-forcing character-by-character over this
 * check); what matters is that a request whose `state` query param doesn't
 * match the httpOnly cookie we set at /start is rejected outright — that's
 * the CSRF defense.
 */
function statesMatch(a: string, b: string): boolean {
  return a.length === b.length && a === b;
}

function setOAuthCookie(res: Response, name: string, value: string, config: GatewayConfig): void {
  res.cookie(name, value, {
    httpOnly: true,
    sameSite: "lax",
    secure: config.nodeEnv === "production",
    maxAge: config.oauthStateTtlSeconds * 1000,
    path: "/auth/google",
  });
}

function clearOAuthCookies(res: Response, config: GatewayConfig): void {
  for (const name of [STATE_COOKIE, VERIFIER_COOKIE]) {
    res.clearCookie(name, { path: "/auth/google", secure: config.nodeEnv === "production", sameSite: "lax" });
  }
}

export function googleAuthRoutes(deps: {
  auth: AuthService;
  config: GatewayConfig;
  google: GoogleAuthClient;
}): Router {
  const router = Router();

  router.get("/google/start", (_req, res) => {
    const state = generateState();
    const codeVerifier = generateCodeVerifier();
    // "profile" in addition to the identity-only scopes Stage 1 used, so the
    // ID token carries `name`/`picture` for the OAuth profile snapshot
    // (storage/oauth-profiles.ts). Identity and role resolution never depend
    // on these two claims — only on `email`/`email_verified` — so their
    // absence (a user who declines the profile scope) cannot change login.
    const url = deps.google.createAuthorizationURL(state, codeVerifier, ["openid", "email", "profile"]);

    setOAuthCookie(res, STATE_COOKIE, state, deps.config);
    setOAuthCookie(res, VERIFIER_COOKIE, codeVerifier, deps.config);
    res.redirect(url.toString());
  });

  router.get("/google/callback", async (req: Request, res: Response, next) => {
    // One-shot: the state/verifier cookies are consumed on this request
    // whether it succeeds or fails, so a callback can never be replayed.
    const cookies = parseCookies(req.headers.cookie);
    clearOAuthCookies(res, deps.config);

    try {
      const rawCode = req.query.code;
      const rawState = req.query.state;
      const expectedState = cookies[STATE_COOKIE];
      const codeVerifier = cookies[VERIFIER_COOKIE];

      if (typeof rawCode !== "string" || typeof rawState !== "string") {
        throw badRequest("invalid_oauth_request", "missing code or state");
      }
      if (!expectedState || !codeVerifier) {
        throw badRequest("invalid_oauth_request", "no OAuth flow in progress for this browser");
      }
      if (!statesMatch(rawState, expectedState)) {
        throw badRequest("invalid_oauth_state", "state did not match — possible CSRF, request rejected");
      }

      const tokens = await deps.google.validateAuthorizationCode(rawCode, codeVerifier);
      const profile = extractVerifiedGoogleProfile(tokens.idToken(), deps.config.google.clientId);

      // Role is resolved inside identityLogin() from the admin-email
      // allowlist — never from anything Google's ID token claims. The
      // `name`/`picture` claims flow through only as far as the OAuth
      // profile snapshot; they never touch identity or role.
      const { token, user } = await deps.auth.identityLogin(profile.email, {
        provider: "google",
        subject: profile.subject,
        ...(profile.name ? { name: profile.name } : {}),
        ...(profile.picture ? { avatarUrl: profile.picture } : {}),
      });

      // The browser lands here directly off Google's redirect, so a JSON body
      // would just be shown at the gateway's own origin — not useful to a
      // candidate. Hand the token to the SPA instead via a redirect back to
      // it, in the URL fragment rather than a query string: fragments are
      // never sent to a server (this one included) on that next navigation,
      // only read by the frontend's own JS (apps/web/app/auth/callback).
      const redirectUrl = new URL("/auth/callback", deps.config.frontendUrl);
      redirectUrl.hash = `token=${encodeURIComponent(token)}&role=${encodeURIComponent(user.role)}`;
      res.redirect(redirectUrl.toString());
    } catch (err) {
      if (err instanceof OAuth2RequestError) {
        next(badRequest("oauth_exchange_failed", err.message));
        return;
      }
      if (err instanceof InvalidGoogleIdTokenError) {
        next(badRequest("invalid_id_token", err.message));
        return;
      }
      next(err);
    }
  });

  return router;
}

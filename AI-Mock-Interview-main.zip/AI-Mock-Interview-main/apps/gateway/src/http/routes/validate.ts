import { badRequest } from "../errors.js";

export function requireString(body: unknown, field: string): string {
  const value = (body as Record<string, unknown> | null)?.[field];
  if (typeof value !== "string" || value.trim() === "") {
    throw badRequest("invalid_request", `${field} is required`);
  }
  return value;
}

/**
 * A non-empty string if present, `undefined` if absent or blank. Rejects a
 * non-string outright rather than coercing — a caller sending `{ fullName: 42 }`
 * has a bug, and silently storing "42" would hide it.
 */
export function optionalString(body: unknown, field: string): string | undefined {
  const value = (body as Record<string, unknown> | null)?.[field];
  if (value === undefined || value === null) return undefined;
  if (typeof value !== "string") {
    throw badRequest("invalid_request", `${field} must be a string`);
  }
  return value.trim() === "" ? undefined : value.trim();
}

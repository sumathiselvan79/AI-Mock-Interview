import { Router } from "express";
import { AuthError, type AuthService } from "../../auth/service.js";
import { WeakPasscodeError } from "../../auth/passcode.js";
import { HttpError } from "../errors.js";
import { optionalString, requireString } from "./validate.js";

export function authRoutes(auth: AuthService): Router {
  const router = Router();

  // POST /auth/register — self-service signup (INSTRUCTIONS.md §7, Stage 3).
  // The role is hardcoded to "student" and is never read from the request:
  // there is no self-service path to `admin` (§3.2). Admin accounts stay
  // operator-provisioned.
  router.post("/register", async (req, res, next) => {
    try {
      const email = requireString(req.body, "email");
      const passcode = requireString(req.body, "passcode");

      // (Stage 5, §11.4) Profile fields are collected here rather than after
      // the fact, because archiving refuses without `fullName` — a candidate
      // who never fills these in has sessions that silently cannot be
      // archived. They stay optional at signup so an existing flow (or an
      // OAuth identity) is not broken by the addition; PATCH /me/profile is
      // the catch-up path.
      const user = await auth.createUser({
        email,
        passcode,
        role: "student",
        profile: {
          ...(optionalString(req.body, "full_name") === undefined
            ? {}
            : { fullName: optionalString(req.body, "full_name") }),
          ...(optionalString(req.body, "department") === undefined
            ? {}
            : { department: optionalString(req.body, "department") }),
          ...(optionalString(req.body, "program_year") === undefined
            ? {}
            : { programYear: optionalString(req.body, "program_year") }),
        },
      });
      const { token } = await auth.login(email, passcode);
      res.status(201).json({ token, user });
    } catch (err) {
      if (err instanceof WeakPasscodeError) {
        next(new HttpError(400, err.code, err.message));
        return;
      }
      if (err instanceof Error && /already exists/i.test(err.message)) {
        // Deliberately not "that email is taken" — that would confirm which
        // addresses have accounts to anyone who asks.
        next(
          new HttpError(
            409,
            "registration_failed",
            "could not create an account with those details; try signing in or resetting your passcode",
          ),
        );
        return;
      }
      next(err);
    }
  });

  // POST /auth/login — returns a role-scoped token (INSTRUCTIONS.md §7).
  router.post("/login", async (req, res, next) => {
    try {
      const email = requireString(req.body, "email");
      const passcode = requireString(req.body, "passcode");
      const { token, user } = await auth.login(email, passcode);
      res.status(200).json({ token, user });
    } catch (err) {
      if (err instanceof AuthError) {
        next(new HttpError(401, err.code, err.message));
        return;
      }
      next(err);
    }
  });

  // POST /auth/reset-passcode/request — always 202, so it cannot be used to
  // probe which email addresses have accounts.
  router.post("/reset-passcode/request", async (req, res, next) => {
    try {
      const email = requireString(req.body, "email");
      await auth.requestPasscodeReset(email);
      res.status(202).json({
        status: "accepted",
        message: "if an account exists for that address, a reset link has been sent",
      });
    } catch (err) {
      next(err);
    }
  });

  // POST /auth/reset-passcode/confirm — consumes the single-use token.
  router.post("/reset-passcode/confirm", async (req, res, next) => {
    try {
      const token = requireString(req.body, "token");
      const passcode = requireString(req.body, "passcode");
      await auth.confirmPasscodeReset(token, passcode);
      res.status(200).json({ status: "ok" });
    } catch (err) {
      if (err instanceof WeakPasscodeError) {
        next(new HttpError(400, err.code, err.message));
        return;
      }
      if (err instanceof AuthError) {
        next(new HttpError(400, err.code, err.message));
        return;
      }
      next(err);
    }
  });

  return router;
}

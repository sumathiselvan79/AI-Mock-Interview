/**
 * Authentication + role-based access, enforced at the gateway on every request
 * — not just in the frontend router (INSTRUCTIONS.md §8).
 */

import type { NextFunction, Request, RequestHandler, Response } from "express";
import type { AuthTokenClaims, Role } from "@mia/shared-types";
import { verifyToken } from "../../auth/tokens.js";
import { forbidden, unauthorized } from "../errors.js";

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      auth?: AuthTokenClaims;
    }
  }
}

export function requireAuth(secret: string): RequestHandler {
  return (req: Request, _res: Response, next: NextFunction) => {
    const header = req.header("authorization") ?? "";
    const [scheme, token] = header.split(" ");
    if (scheme?.toLowerCase() !== "bearer" || !token) {
      return next(unauthorized("missing bearer token"));
    }
    const result = verifyToken(token, secret);
    if (!result.ok) return next(unauthorized(`token ${result.reason}`));
    req.auth = result.claims;
    return next();
  };
}

/**
 * Role gate. Deliberately symmetric: an admin token is rejected on student-only
 * routes exactly as a student token is rejected on /admin/* — an Admin cannot
 * start interviews as a candidate (INSTRUCTIONS.md §3.2).
 */
export function requireRole(...roles: Role[]): RequestHandler {
  return (req: Request, _res: Response, next: NextFunction) => {
    if (!req.auth) return next(unauthorized());
    if (!roles.includes(req.auth.role)) {
      return next(forbidden(`this route requires role: ${roles.join(" or ")}`));
    }
    return next();
  };
}

/** A student may only ever read their own sessions and reports (§8). */
export function assertOwnsOrAdmin(req: Request, candidateId: string): void {
  if (!req.auth) throw unauthorized();
  if (req.auth.role === "admin") return;
  if (req.auth.sub !== candidateId) throw forbidden("this session belongs to another candidate");
}

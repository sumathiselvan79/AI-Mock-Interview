import type { NextFunction, Request, Response } from "express";
import type { Logger } from "../logging/logger.js";

export class HttpError extends Error {
  constructor(
    readonly status: number,
    readonly code: string,
    message: string,
  ) {
    super(message);
    this.name = "HttpError";
  }
}

export const badRequest = (code: string, message: string) => new HttpError(400, code, message);
export const unauthorized = (message = "authentication required") =>
  new HttpError(401, "unauthorized", message);
export const forbidden = (message = "insufficient role for this route") =>
  new HttpError(403, "forbidden", message);
export const notFound = (message = "not found") => new HttpError(404, "not_found", message);
export const conflict = (code: string, message: string) => new HttpError(409, code, message);

/**
 * body-parser rejects a malformed or oversized body before any route handler
 * runs, and it throws its own error type rather than an `HttpError`. Without
 * this, a resume a few hundred KB too big was logged as an unhandled error and
 * answered `500 internal error` — telling the candidate the server was broken
 * when the request was simply too large.
 */
function bodyParserError(err: unknown): HttpError | null {
  const candidate = err as { type?: string; status?: number };
  switch (candidate?.type) {
    case "entity.too.large":
      return new HttpError(413, "payload_too_large", "request body is too large");
    case "entity.parse.failed":
      return badRequest("invalid_json", "request body is not valid JSON");
    case "encoding.unsupported":
      return badRequest("unsupported_encoding", "request body uses an unsupported content encoding");
    default:
      return null;
  }
}

/** Terminal error handler. Never leaks internals or request bodies to the client. */
export function errorHandler(logger: Logger) {
  return (err: unknown, req: Request, res: Response, _next: NextFunction): void => {
    if (err instanceof HttpError) {
      res.status(err.status).json({ error: { code: err.code, message: err.message } });
      return;
    }

    const parserError = bodyParserError(err);
    if (parserError) {
      res.status(parserError.status).json({ error: { code: parserError.code, message: parserError.message } });
      return;
    }
    logger.error("unhandled_error", {
      path: req.path,
      method: req.method,
      message: (err as Error)?.message,
    });
    res.status(500).json({ error: { code: "internal_error", message: "internal error" } });
  };
}

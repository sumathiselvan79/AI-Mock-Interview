/**
 * WebSocket live channel — `/sessions/:id/live` (INSTRUCTIONS.md §7).
 *
 * Server -> client: `question` (with `audio_url`), `follow_up`, `timer_tick`,
 * `coding_problem`, `paste_detected`, `focus_recorded`, `transcript_draft`,
 * `transcript_rejected`, `session_complete`.
 * Client -> server: `transcribe_audio`, `submit_answer_audio`,
 * `submit_answer_text`, `submit_code`, `paste_detected`, `focus_lost`, `pause`,
 * `end_session`.
 *
 * `focus_lost` is the fullscreen-exit counterpart of `paste_detected` — a
 * timestamp only, gated the same way by `Session.consent.focusLossMonitoring`.
 * Past `MAX_FOCUS_EXITS` recorded exits the harness wraps the session up on
 * its own; the `focus_recorded` reply and a `session_complete` (reason
 * `focus_exit_limit`) arrive together so the room page's normal "session
 * over" handling is what takes it from there.
 *
 * `transcribe_audio` is the review-before-submit path the room page uses: it
 * transcribes and returns a `transcript_draft` for the candidate to read and
 * correct, and scores nothing. The corrected text is submitted afterwards
 * through `submit_answer_text` like any other typed answer.
 * `submit_answer_audio` (transcribe-and-score in one step) is kept for callers
 * that genuinely want it — the scripted E2E personas — and is not the UI path.
 *
 * The socket is a transport, not an authority: every message is routed straight
 * to the Harness Agent, which owns the state machine. Nothing here decides what
 * happens next, and the connection is authenticated with the same role-scoped
 * token as every REST route — a socket is not a way around RBAC.
 */

import type { Server } from "node:http";
import { WebSocketServer, type WebSocket } from "ws";
import type { HarnessAgent } from "@mia/harness-agent";
import { verifyToken } from "../auth/tokens.js";
import type { GatewayConfig } from "../config.js";
import type { Logger } from "../logging/logger.js";
import type { Storage } from "../storage/types.js";

export interface LiveChannelDeps {
  server: Server;
  harness: HarnessAgent;
  storage: Storage;
  config: GatewayConfig;
  logger: Logger;
}

type ServerEvent =
  | "connected"
  | "question"
  | "follow_up"
  | "timer_tick"
  | "coding_problem"
  | "paste_detected"
  | "focus_recorded"
  | "transcript_draft"
  | "transcript_rejected"
  | "session_complete"
  | "error";

interface ClientMessage {
  type: string;
  [key: string]: unknown;
}

/** How often the timer state is pushed while a session is live. */
export const TIMER_TICK_MS = 1_000;

export function attachLiveChannel(deps: LiveChannelDeps): WebSocketServer {
  const { server, harness, storage, config, logger } = deps;

  // The same audio cap the REST route enforces. Without it the socket was the
  // uncapped way in: `ws` defaults to a 100 MiB frame and nothing here measured
  // the decoded bytes, so a client could send far more over the socket than the
  // equivalent HTTP request would ever accept. `maxPayload` rejects the frame
  // at the protocol level; the explicit check below catches a payload that fits
  // in a frame but still exceeds the configured limit once decoded.
  const maxAudioBase64 = Math.ceil(config.maxAudioBytes * (4 / 3));
  const wss = new WebSocketServer({ noServer: true, maxPayload: maxAudioBase64 + 64 * 1024 });

  /**
   * Decodes a client-supplied base64 audio field, refusing anything over the
   * configured cap rather than buffering it. Returns null after telling the
   * client why, so the caller simply stops.
   */
  function decodeAudio(ws: WebSocket, value: unknown): Buffer | null {
    const base64 = String(value ?? "");
    if (base64.length > maxAudioBase64) {
      send(ws, "error", {
        code: "file_too_large",
        message: `recording exceeds ${config.maxAudioBytes} bytes`,
      });
      return null;
    }
    const bytes = Buffer.from(base64, "base64");
    if (bytes.byteLength === 0) {
      send(ws, "error", { code: "bad_message", message: "audio_base64 decoded to zero bytes" });
      return null;
    }
    if (bytes.byteLength > config.maxAudioBytes) {
      send(ws, "error", {
        code: "file_too_large",
        message: `recording exceeds ${config.maxAudioBytes} bytes`,
      });
      return null;
    }
    return bytes;
  }

  server.on("upgrade", (request, socket, head) => {
    const url = new URL(request.url ?? "/", "http://localhost");
    const match = /^\/sessions\/([^/]+)\/live$/.exec(url.pathname);
    if (!match) {
      socket.destroy();
      return;
    }

    // The browser WebSocket API cannot set headers, so the token arrives as a
    // query parameter. It is still the same signed, role-scoped token, and it
    // is verified before the socket is accepted.
    const token = url.searchParams.get("token") ?? "";
    const verdict = verifyToken(token, config.authTokenSecret);
    if (!verdict.ok) {
      socket.write("HTTP/1.1 401 Unauthorized\r\n\r\n");
      socket.destroy();
      return;
    }

    wss.handleUpgrade(request, socket, head, (ws) => {
      void openSession(ws, match[1] as string, verdict.claims.sub, verdict.claims.role);
    });
  });

  async function openSession(ws: WebSocket, sessionId: string, userId: string, role: string) {
    // The message listener is attached before anything else here — in
    // particular before the `await` below — because the client sends its
    // first message (`next_question`) the instant its own socket reports
    // open, with no wait for a `connected` reply. That race is real, not
    // theoretical: a message that arrives while this function is still
    // awaiting the session lookup would otherwise be delivered to a socket
    // with no "message" listener on it yet and silently lost, hanging the
    // room page forever on a session that never serves a first question.
    // Anything that arrives before the ownership check below resolves is
    // queued and replayed, in order, once it does.
    const queuedBeforeReady: string[] = [];
    let ready = false;
    ws.on("message", (raw) => {
      const text = raw.toString();
      if (ready) {
        void handleMessage(ws, sessionId, text);
      } else {
        queuedBeforeReady.push(text);
      }
    });

    const session = await storage.sessions.get(sessionId);

    // Ownership is checked here exactly as `assertOwnsOrAdmin` does for REST.
    if (!session || (role !== "admin" && session.candidateId !== userId)) {
      send(ws, "error", { code: "forbidden", message: "this session is not yours" });
      ws.close();
      return;
    }

    send(ws, "connected", { session_id: sessionId, state: session.state });

    const ticker = setInterval(() => {
      void pushTimer(ws, sessionId);
    }, TIMER_TICK_MS);

    ready = true;
    for (const text of queuedBeforeReady) {
      void handleMessage(ws, sessionId, text);
    }

    ws.on("close", () => clearInterval(ticker));
    ws.on("error", (err) => logger.warn("live_socket_error", { session_id: sessionId, message: err.message }));
  }

  async function pushTimer(ws: WebSocket, sessionId: string): Promise<void> {
    const timer = await storage.live.loadTimer(`${sessionId}:session`);
    if (!timer) return;
    const elapsed = Date.now() - timer.startedAt - timer.pausedMs;
    send(ws, "timer_tick", {
      elapsed_ms: Math.max(0, elapsed),
      remaining_ms: timer.budgetMs - elapsed,
    });
  }

  async function handleMessage(ws: WebSocket, sessionId: string, raw: string): Promise<void> {
    let message: ClientMessage;
    try {
      message = JSON.parse(raw) as ClientMessage;
    } catch {
      send(ws, "error", { code: "bad_message", message: "expected JSON" });
      return;
    }

    try {
      switch (message.type) {
        case "begin_interview": {
          const started = await harness.beginInterview(sessionId);
          send(ws, "connected", { session_id: sessionId, state: started.state });
          return;
        }

        case "next_question": {
          // `advance: true` (the Skip control) explicitly abandons a pending,
          // unanswered question and generates the next one. Absent the flag —
          // including every reconnect, which sends this same message on open —
          // the harness re-serves the current pending question instead of
          // silently replacing it (agents/harness-agent/src/interview.ts).
          const result = await harness.nextQuestion(sessionId, { advance: message.advance === true });
          if (result.done) {
            send(ws, "session_complete", { note: result.note ?? null });
          } else {
            send(ws, "question", {
              id: result.question!.id,
              text: result.question!.text,
              topic: result.question!.topic,
              question_type: result.question!.type,
              difficulty: (result.question! as any).difficulty,
              audio_url: result.question!.audioUrl ?? null,
            });
            if (result.speechNote) {
              send(ws, "error", { message: result.speechNote });
            }
          }
          return;
        }

        case "transcribe_audio": {
          const audio = decodeAudio(ws, message.audio_base64);
          if (!audio) return;
          const stored = await storage.files.put({
            sessionId,
            filename: `answer-draft-${Date.now()}.wav`,
            contentType: "audio/wav",
            bytes: audio,
          });
          const outcome = await harness.transcribeAudio({ sessionId, audioRef: stored.ref });

          if (!outcome.accepted) {
            // Same refusal as the scoring path — the candidate is told plainly
            // and handed the keyboard with whatever was made out (soul.md §5).
            send(ws, "transcript_rejected", {
              reason: outcome.reason,
              confidence: outcome.confidence ?? null,
              draft_transcript: outcome.draftTranscript ?? null,
              action: "retry_or_type",
            });
            return;
          }

          send(ws, "transcript_draft", {
            transcript: outcome.transcript,
            confidence: outcome.confidence,
            // Echoed back so a draft that arrives after the candidate has moved
            // on cannot overwrite the answer to a different question.
            question_id: message.question_id ?? null,
            answer_id: message.answer_id ?? null,
          });
          return;
        }

        case "submit_answer_audio": {
          const audio = decodeAudio(ws, message.audio_base64);
          if (!audio) return;
          const stored = await storage.files.put({
            sessionId,
            filename: `answer-${Date.now()}.wav`,
            contentType: "audio/wav",
            bytes: audio,
          });
          const outcome = await harness.submitAudioAnswer({
            sessionId,
            questionId: String(message.question_id ?? ""),
            audioRef: stored.ref,
          });

          if (!outcome.accepted) {
            // The candidate is asked again or offered the keyboard. Nothing has
            // been scored (soul.md §5).
            send(ws, "transcript_rejected", {
              reason: outcome.retry.reason,
              confidence: outcome.retry.confidence ?? null,
              draft_transcript: outcome.retry.draftTranscript ?? null,
              action: "retry_or_type",
            });
            return;
          }
          sendAnswerResult(ws, outcome.result);
          return;
        }

        case "submit_answer_text": {
          const result = await harness.submitAnswer({
            sessionId,
            questionId: String(message.question_id ?? ""),
            transcript: String(message.transcript ?? ""),
          });
          sendAnswerResult(ws, result);
          return;
        }

        case "submit_follow_up_audio": {
          const audio = decodeAudio(ws, message.audio_base64);
          if (!audio) return;
          const stored = await storage.files.put({
            sessionId,
            filename: `answer-followup-${Date.now()}.wav`,
            contentType: "audio/wav",
            bytes: audio,
          });
          const outcome = await harness.submitFollowUpAudioAnswer({
            sessionId,
            answerId: String(message.answer_id ?? ""),
            followUpText: String(message.follow_up_text ?? ""),
            audioRef: stored.ref,
          });

          if (!outcome.accepted) {
            send(ws, "transcript_rejected", {
              reason: outcome.retry.reason,
              confidence: outcome.retry.confidence ?? null,
              draft_transcript: outcome.retry.draftTranscript ?? null,
              action: "retry_or_type",
            });
            return;
          }
          send(ws, "question", { answered: true, answer_id: outcome.result.answer.id });
          return;
        }

        case "submit_follow_up_text": {
          const result = await harness.submitFollowUpAnswer({
            // Bound to the socket's own session, never to an id the client
            // could substitute — the harness rejects a mismatch.
            sessionId,
            answerId: String(message.answer_id ?? ""),
            followUpText: String(message.follow_up_text ?? ""),
            transcript: String(message.transcript ?? ""),
          });
          send(ws, "question", { answered: true, answer_id: result.id });
          return;
        }

        case "submit_code": {
          const result = await harness.submitCode({
            sessionId,
            code: String(message.code ?? ""),
            ...(typeof message.talk_through === "string" ? { talkThrough: message.talk_through } : {}),
          });
          send(ws, "coding_problem", { submission: result });
          return;
        }

        case "paste_detected": {
          // Only a timestamp crosses the wire; there is no content field.
          const recorded = await harness.recordPasteEvent(
            sessionId,
            typeof message.timestamp === "string" ? message.timestamp : new Date().toISOString(),
          );
          send(ws, "paste_detected", { recorded });
          return;
        }

        case "focus_lost": {
          // Only a timestamp crosses the wire, same as paste_detected above.
          const outcome = await harness.recordFocusEvent(
            sessionId,
            typeof message.timestamp === "string" ? message.timestamp : new Date().toISOString(),
          );
          send(ws, "focus_recorded", {
            recorded: outcome.recorded,
            exit_count: outcome.exitCount,
            concluded: outcome.concluded,
          });
          // More than MAX_FOCUS_EXITS exits: the harness has already wrapped
          // the session up. Tell the frontend the same way `end_session` does,
          // so the room page's existing "session over" handling takes it from
          // here rather than needing a second code path.
          if (outcome.concluded && outcome.wrapUp) {
            send(ws, "session_complete", {
              state: outcome.wrapUp.session.state,
              message: outcome.wrapUp.spoken.text,
              audio_url: outcome.wrapUp.spoken.audioUrl ?? null,
              reason: "focus_exit_limit",
            });
          }
          return;
        }

        case "end_session": {
          const result = await harness.wrapUp(sessionId);
          send(ws, "session_complete", {
            state: result.session.state,
            message: result.spoken.text,
            audio_url: result.spoken.audioUrl ?? null,
          });
          return;
        }

        default:
          send(ws, "error", { code: "unknown_type", message: `unsupported message: ${message.type}` });
      }
    } catch (err) {
      const error = err as { code?: string; message: string };
      logger.warn("live_message_failed", { session_id: sessionId, type: message.type, code: error.code });
      send(ws, "error", { code: error.code ?? "failed", message: error.message });
    }
  }

  function sendAnswerResult(ws: WebSocket, result: Awaited<ReturnType<HarnessAgent["submitAnswer"]>>): void {
    if (result.followUp) {
      send(ws, "follow_up", {
        answer_id: result.answer.id,
        text: result.followUp.text,
        reason: result.followUp.reason,
        audio_url: result.followUp.audioUrl ?? null,
      });
    } else {
      send(ws, "question", {
        answered: true,
        answer_id: result.answer.id,
        evaluation: result.evaluation,
        ...(result.evaluationNote ? { evaluation_note: result.evaluationNote } : {}),
      });
    }
  }

  return wss;
}

function send(ws: WebSocket, type: ServerEvent, payload: Record<string, unknown>): void {
  if (ws.readyState === ws.OPEN) ws.send(JSON.stringify({ type, ...payload }));
}

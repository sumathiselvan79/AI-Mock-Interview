import { parseAdminEmailAllowlist } from "./auth/roles.js";
import { fromRepoRoot } from "./paths.js";

export interface GoogleOAuthConfig {
  clientId: string;
  clientSecret: string;
  redirectUri: string;
}

export interface GatewayConfig {
  port: number;
  nodeEnv: string;
  authTokenSecret: string;
  authTokenTtlSeconds: number;
  resetTokenTtlSeconds: number;
  storageDriver: "memory" | "postgres";
  databaseUrl: string;
  /**
   * (Stage 5, §11.4) The Supabase-hosted archive instance — a PHYSICALLY
   * SEPARATE database from `databaseUrl`, reached only server-side with a
   * service-role credential (§8). Empty means archiving is off for this
   * deployment.
   */
  supabaseDbUrl: string;
  redisUrl: string;
  uploadDir: string;
  maxResumeBytes: number;
  /**
   * Largest recorded answer accepted, decoded. Sized for a long spoken answer
   * (16-bit 16 kHz mono runs ~1.9 MB/minute), and enforced identically on the
   * REST route and the live WebSocket channel so one is not a way around the
   * other.
   */
  maxAudioBytes: number;
  speechModelDir: string;
  mcpRateLimit: number;
  mcpRateLimitWindowMs: number;
  /**
   * Gate for POST /auth/dev-login. True only outside production AND with the
   * env flag explicitly set — never on by accident (goal: "Build local auth").
   */
  devAuthEnabled: boolean;
  /** Never trust a role from the client or an identity provider — resolved here instead. */
  adminEmailAllowlist: string[];
  google: GoogleOAuthConfig;
  /** Lifetime of the OAuth state/PKCE cookies set by GET /auth/google/start. */
  oauthStateTtlSeconds: number;
  /**
   * Where the web app runs. The only current use is GET /auth/google/callback
   * redirecting the browser back to `${frontendUrl}/auth/callback` with the
   * token in the URL fragment once Google's redirect lands here — the gateway
   * origin is not somewhere a candidate is meant to see a raw JSON response.
   */
  frontendUrl: string;
}

function int(value: string | undefined, fallback: number): number {
  const parsed = Number.parseInt(value ?? "", 10);
  return Number.isFinite(parsed) ? parsed : fallback;
}

export function loadConfig(env: NodeJS.ProcessEnv = process.env): GatewayConfig {
  const nodeEnv = env.NODE_ENV ?? "development";
  const secret = env.AUTH_TOKEN_SECRET ?? "";

  if (nodeEnv === "production" && secret.length < 32) {
    throw new Error("AUTH_TOKEN_SECRET must be set to at least 32 characters in production");
  }

  return {
    port: int(env.PORT, 4000),
    nodeEnv,
    authTokenSecret: secret || "dev-only-insecure-secret",
    authTokenTtlSeconds: int(env.AUTH_TOKEN_TTL_SECONDS, 3600),
    resetTokenTtlSeconds: int(env.RESET_TOKEN_TTL_SECONDS, 900),
    storageDriver: env.STORAGE_DRIVER === "postgres" ? "postgres" : "memory",
    databaseUrl: env.DATABASE_URL ?? "postgres://mia:mia@localhost:5432/mia",
    supabaseDbUrl: env.SUPABASE_DB_URL ?? "",
    redisUrl: env.REDIS_URL ?? "redis://localhost:6379",
    // Both of these are resolved from the REPO ROOT, not the process CWD:
    // `npm run dev` runs the gateway through its workspace script, so CWD is
    // `apps/gateway` and a relative path would quietly mean the wrong
    // directory (see `paths.ts`). An absolute value is passed through.
    uploadDir: fromRepoRoot(env.UPLOAD_DIR ?? "uploads"),
    maxResumeBytes: int(env.MAX_RESUME_BYTES, 5 * 1024 * 1024),
    maxAudioBytes: int(env.MAX_AUDIO_BYTES, 20 * 1024 * 1024),
    // sherpa-onnx TTS/STT models. Absent, the Speech Service falls back to the
    // deterministic fixture provider and logs that it did.
    speechModelDir: fromRepoRoot(env.SPEECH_MODEL_DIR ?? "models"),
    // One interview turn is several MCP calls (memory, question, timer, eval,
    // follow-up), so the ceiling has to leave room for a fast candidate without
    // stopping being a real limit.
    mcpRateLimit: int(env.MCP_RATE_LIMIT, 300),
    mcpRateLimitWindowMs: int(env.MCP_RATE_LIMIT_WINDOW_MS, 10_000),
    // Hard gate for POST /auth/dev-login (INSTRUCTIONS.md / goal: "Build local
    // auth"): both the env flag AND non-production must hold, computed once
    // here so the route-mounting code has one boolean to check.
    devAuthEnabled: nodeEnv !== "production" && env.ALLOW_DEV_AUTH === "true",
    adminEmailAllowlist: parseAdminEmailAllowlist(env.ADMIN_EMAIL_ALLOWLIST),
    google: {
      clientId: env.GOOGLE_CLIENT_ID ?? "",
      clientSecret: env.GOOGLE_CLIENT_SECRET ?? "",
      redirectUri: env.GOOGLE_REDIRECT_URI ?? "",
    },
    oauthStateTtlSeconds: int(env.OAUTH_STATE_TTL_SECONDS, 600),
    frontendUrl: env.FRONTEND_URL ?? "http://localhost:3000",
  };
}

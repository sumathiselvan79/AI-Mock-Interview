/**
 * Gateway composition root: REST entry point, auth, RBAC, and the MCP Gateway
 * that every agent-to-tool call passes through (CLAUDE.md §5).
 *
 * `createGateway` wires the whole thing from a config object and returns the
 * parts a test needs to reach directly — so the test suite exercises the same
 * object graph the server runs, not a parallel one.
 */

import type { Server } from "node:http";
import express, { type Express } from "express";
import cors from "cors";
import type { WebSocketServer } from "ws";
import { McpHandlerError, type ToolClientFactory } from "@mia/shared-types";
import { HarnessAgent } from "@mia/harness-agent";
import { createResumeServiceAgentServer } from "@mia/resume-service-agent";
import { createQuestionAgentServer } from "@mia/question-agent";
import { createFollowupAgentServer } from "@mia/followup-agent";
import { createCodingAgentServer } from "@mia/coding-agent";
import { createTimeTrackingAgentServer } from "@mia/time-tracking-agent";
import { createMemoryAgentServer } from "@mia/memory-agent";
import { createReportAgentServer } from "@mia/report-agent";
import { createToolResumeParserServer } from "@mia/tool-resume-parser";
import { createToolEvalServer } from "@mia/tool-eval";
import { createToolTimeTrackingServer } from "@mia/tool-time-tracking";
import { createToolTelemetryServer } from "@mia/tool-telemetry";
import { createToolClipboardMonitorServer } from "@mia/tool-clipboard-monitor";
import { createToolFocusMonitorServer } from "@mia/tool-focus-monitor";
import {
  createToolSpeechServiceServer,
  selectSpeechProvider,
  type SpeechProvider,
} from "@mia/tool-speech-service";
import { createToolLlmProviderServer } from "@mia/tool-llm-provider";
import {
  resolveProvider,
  QUESTION_TOOL,
  JD_FIT_TOOL,
  type ProviderChoice as LlmProviderChoice,
  type StructuredChatModel,
} from "@mia/llm-client";

import { loadConfig, type GatewayConfig } from "./config.js";
import { createLogger, type Logger } from "./logging/logger.js";
import { AuthService, MemoryResetMailer, type ResetMailer } from "./auth/service.js";
import { issueConsentToken, verifyConsentToken } from "./auth/tokens.js";
import { createGoogleAuthClient, type GoogleAuthClient } from "./auth/google.js";
import { createStorage } from "./storage/index.js";
import type { Storage } from "./storage/types.js";
import { McpGateway } from "./mcp/gateway.js";
import { createDevPingServer } from "./mcp/dev-ping-server.js";
import { errorHandler } from "./http/errors.js";
import { requireAuth } from "./http/middleware/auth.js";
import { authRoutes } from "./http/routes/auth.js";
import { devAuthRoutes } from "./http/routes/dev-auth.js";
import { googleAuthRoutes } from "./http/routes/google-auth.js";
import { sessionRoutes } from "./http/routes/sessions.js";
import { meRoutes } from "./http/routes/me.js";
import { adminRoutes } from "./http/routes/admin.js";
import { mcpRoutes } from "./http/routes/mcp.js";
import { voiceRoutes } from "./http/routes/voice.js";
import { attachLiveChannel } from "./http/live-channel.js";

export interface Gateway {
  app: Express;
  config: GatewayConfig;
  logger: Logger;
  storage: Storage;
  auth: AuthService;
  harness: HarnessAgent;
  mcp: McpGateway;
  mailer: ResetMailer;
  /** Which speech provider is live, and why — see `selectSpeechProvider`. */
  speech: { provider: SpeechProvider; reason: string };
  /** Which LLM provider is live, why, and whether tracing is on (INSTRUCTIONS.md §5.7, §8). */
  llm: LlmProviderChoice;
  attachLiveChannel(server: Server): WebSocketServer;
  close(): Promise<void>;
}

export interface CreateGatewayOptions {
  config?: GatewayConfig;
  logger?: Logger;
  storage?: Storage;
  mailer?: ResetMailer;
  /**
   * Pins the speech provider. Used by tests that need a deterministic
   * confidence signal — forcing a low-confidence transcription is not something
   * you can reliably ask a real ASR model for.
   */
  speechProvider?: SpeechProvider;
  /**
   * Substitutes the LLM Provider Tool's chat model. Used by tests that need a
   * malformed or deliberately ungrounded generation — not something you can
   * reliably ask a real provider for.
   */
  llmModel?: StructuredChatModel;
  /**
   * Substitutes arctic's real Google client. Used by tests that need to
   * exercise the OAuth callback (state validation, ID token role handling)
   * without a network round trip to Google's token endpoint.
   */
  googleAuthClient?: GoogleAuthClient;
}

/**
 * The two routes whose body is a base64 blob rather than ordinary JSON:
 * `POST /sessions/:id/resume` and `POST /sessions/:id/answers/audio`. Matched on
 * the path suffix because both are mounted under a session id.
 */
export function isBlobUpload(method: string, path: string): boolean {
  if (method !== "POST") return false;
  return /^\/sessions\/[^/]+\/(resume|answers\/audio)$/.test(path);
}

/**
 * Byte budget a base64-encoded payload of `decodedBytes` needs: 4/3 for the
 * encoding, plus room for the surrounding JSON envelope (field names, filename,
 * content type) and any transport padding.
 */
export function base64BodyLimit(decodedBytes: number): number {
  return Math.ceil(decodedBytes * (4 / 3)) + 64 * 1024;
}

export async function createGateway(options: CreateGatewayOptions = {}): Promise<Gateway> {
  const config = options.config ?? loadConfig();
  const logger = options.logger ?? createLogger();
  const storage = options.storage ?? (await createStorage(config));
  const mailer = options.mailer ?? new MemoryResetMailer();

  const auth = new AuthService({
    users: storage.users,
    resets: storage.resets,
    telemetry: storage.telemetry,
    config,
    logger,
    mailer,
    ...(storage.oauthProfiles ? { oauthProfiles: storage.oauthProfiles } : {}),
  });

  const mcp = new McpGateway({ config, telemetry: storage.telemetry, live: storage.live, logger });

  // Real speech when the sherpa-onnx models are on disk, the deterministic
  // fixture otherwise. Which one was chosen is logged rather than left a
  // mystery, because it changes what the voice pipeline can actually do.
  const speech = options.speechProvider
    ? { provider: options.speechProvider, reason: "pinned by the caller" }
    : selectSpeechProvider(config.speechModelDir);
  logger.info("speech_provider_selected", { provider: speech.provider.name, reason: speech.reason });

  // Same contract as the speech provider: the configured provider when its
  // credentials exist, the deterministic fixture otherwise, and the choice is
  // logged rather than inferred. Tracing is a separate, louder line because it
  // is a second third-party recipient of candidate text (§8, soul.md §3).
  const llm = resolveProvider();
  logger.info("llm_provider_selected", { provider: llm.provider, reason: llm.reason });
  logger.info("llm_tracing_gate", { enabled: llm.tracing.enabled, reason: llm.tracing.reason });

  // Question generation and resume/JD parsing can be pointed at different
  // providers (QUESTION_AGENT_LLM_PROVIDER / RESUME_SERVICE_LLM_PROVIDER
  // override LLM_PROVIDER per role — see resolveProvider). Logged separately
  // whenever either actually differs from the global default, so a deployment
  // running a genuine split is visible at a glance rather than only inferable
  // from `llm_provider_selected` above.
  const questionLlm = resolveProvider(process.env, QUESTION_TOOL.name);
  const resumeLlm = resolveProvider(process.env, JD_FIT_TOOL.name);
  if (questionLlm.provider !== llm.provider || resumeLlm.provider !== llm.provider) {
    logger.info("llm_provider_selected_per_role", {
      question_agent: questionLlm.provider,
      resume_service_agent: resumeLlm.provider,
    });
  }

  /**
   * How every agent reaches a tool. The session token is looked up here rather
   * than passed in, so an agent cannot present a token for a session it is not
   * working on, and a failed call surfaces as a typed error instead of an
   * `ok: false` an agent might forget to check.
   */
  const toolClient: ToolClientFactory = (sessionId, caller) => ({
    async call<T>(server: string, method: string, params: unknown): Promise<T> {
      const sessionToken = (await storage.live.getSessionToken(sessionId)) ?? "";
      const result = await mcp.call<T>(server, method, params, { sessionId, caller, sessionToken });
      if (!result.ok) {
        throw new McpHandlerError(
          result.error?.code ?? "upstream_error",
          result.error?.message ?? `${server}.${method} failed`,
        );
      }
      return result.data as T;
    },
  });

  // Constructing the harness registers its state-write grant with the session
  // store; from here on nothing else can write Session.state.
  const harness = new HarnessAgent({
    sessions: storage.sessions,
    telemetry: storage.telemetry,
    telemetryCheckPassed: async (sessionId) =>
      (await storage.live.getDeviceCheck(sessionId))?.passed === true,
    questions: storage.questions,
    answers: storage.answers,
    evaluations: storage.evaluations,
    reports: storage.reports,
    toolClient,
    // (Stage 5) Archiving is triggered at COMPLETED, strictly after the Stage 4
    // retention job the same method already runs (§11.4).
    ...(storage.archives ? { archives: storage.archives } : {}),
    users: storage.users,
    // Minted server-side, and only for a session whose candidate actually
    // agreed on the Telemetry Check page — same shape as the Coding Agent's
    // `clipboardConsentToken` below, but owned by the harness itself since it
    // starts the monitor for the whole active interview, not one round of it.
    focusConsentToken: async (sessionId) => {
      const session = await storage.sessions.get(sessionId);
      if (!session?.consent.focusLossMonitoring) return null;
      return issueConsentToken(sessionId, "focus_monitoring", config.authTokenSecret);
    },
  });

  // One registration per deployable service. Servers whose stage has arrived
  // get their real dependencies; the rest answer `not_implemented` with the
  // stage that owns them.
  for (const server of [
    createResumeServiceAgentServer({ sessions: storage.sessions, toolClient }),
    createQuestionAgentServer({ toolClient }),
    // (Stage 5) Gains a tool client so it can score the triggering answer
    // through the Eval Tool before deciding on a probe (§11.2).
    createFollowupAgentServer({ toolClient }),
    createCodingAgentServer({
      toolClient,
      // Minted server-side, and only for a session whose candidate actually
      // agreed on the Telemetry Check page. The token never reaches the
      // browser, so a client cannot present one it was not given.
      clipboardConsentToken: async (sessionId) => {
        const session = await storage.sessions.get(sessionId);
        if (!session?.consent.clipboardMonitor) return null;
        return issueConsentToken(sessionId, "clipboard_monitor", config.authTokenSecret);
      },
    }),
    createTimeTrackingAgentServer({ toolClient }),
    createMemoryAgentServer({
      questions: storage.questions,
      sessions: storage.sessions,
      crossSessionOptIn: async (candidateId) =>
        (await storage.users.findById(candidateId))?.crossSessionMemoryOptIn === true,
      // (Stage 5) Session-scoped working memory, backed by Redis in production
      // (§4.7). The live store satisfies the narrow scratch port, so the Memory
      // Agent gets scratch space without reaching device checks or timers.
      scratch: storage.live,
    }),
    createReportAgentServer({ toolClient }),
    createToolResumeParserServer({ files: storage.files, toolClientFactory: toolClient }),
    createToolEvalServer({ evaluations: storage.evaluations }),
    createToolTimeTrackingServer({ timers: storage.live }),
    createToolTelemetryServer(),
    createToolClipboardMonitorServer({
      verifyConsent: (sessionId, token) =>
        verifyConsentToken(token, sessionId, "clipboard_monitor", config.authTokenSecret),
      recordPaste: async (event) => {
        // A boolean and a timestamp. There is nothing else in `event` to store.
        await storage.telemetry.emit("paste_detected", event.sessionId, {
          detected: event.detected,
          at: event.timestamp,
        });
      },
    }),
    createToolFocusMonitorServer({
      verifyConsent: (sessionId, token) =>
        verifyConsentToken(token, sessionId, "focus_monitoring", config.authTokenSecret),
      recordFocusLoss: async (event) => {
        // Atomic append — NOT get() then patch(), which lost events under
        // concurrent calls (two exits in the same tick both read the same
        // starting array; the second write clobbered the first).
        const { exitCount } = await storage.sessions.appendFocusEvent(event.sessionId, event.timestamp);
        await storage.telemetry.emit("focus_lost", event.sessionId, {
          at: event.timestamp,
          exit_count: exitCount,
        });
        return { exitCount };
      },
    }),
    createToolSpeechServiceServer({
      files: storage.files,
      provider: speech.provider,
      audioRetentionOptIn: async (sessionId) =>
        (await storage.sessions.get(sessionId))?.consent.audioRecording === true,
    }),
    createToolLlmProviderServer({
      provider: llm.provider,
      ...(options.llmModel ? { model: options.llmModel } : {}),
    }),
  ]) {
    mcp.register(server);
  }

  if (config.nodeEnv !== "production") mcp.register(createDevPingServer());

  const app = express();
  app.disable("x-powered-by");

  // Body limits, scoped.
  //
  // `express.json()` runs before every route handler, so ITS limit — not
  // `maxResumeBytes`, not `maxAudioBytes` — is what really decides whether an
  // upload is accepted. A single app-wide 1mb made both of those caps
  // unreachable: base64 inflates by 4/3, so an ordinary two-page PDF resume was
  // refused. Raising one global limit to fit the largest blob would instead let
  // a 27 MiB body be aimed at /auth/login, so the big limit is scoped to the
  // two routes that actually carry base64 and everything else keeps the small
  // one. Each route still enforces its own decoded byte cap afterwards; this
  // only decides how much is buffered before the handler can look at it.
  const jsonSmall = express.json({ limit: "1mb" });
  const jsonBlob = express.json({ limit: base64BodyLimit(Math.max(config.maxResumeBytes, config.maxAudioBytes)) });
  app.use((req, res, next) => (isBlobUpload(req.method, req.path) ? jsonBlob : jsonSmall)(req, res, next));

  app.use(
    cors({
      origin: config.nodeEnv === "production" ? false : true,
      credentials: true,
    }),
  );

  app.get("/health", (_req, res) => {
    res.json({ status: "ok", storage: config.storageDriver, mcp_servers: mcp.registered().length });
  });

  app.use("/auth", authRoutes(auth));

  // Hard-gated: must not register unless NODE_ENV !== "production" AND
  // ALLOW_DEV_AUTH=true (config.ts computes both conditions into one flag).
  if (config.devAuthEnabled) {
    app.use("/auth", devAuthRoutes(auth));
  }

  const googleAuthClient = options.googleAuthClient ?? createGoogleAuthClient(config);
  app.use("/auth", googleAuthRoutes({ auth, config, google: googleAuthClient }));

  // Everything below this line requires a valid, role-scoped token.
  app.use(requireAuth(config.authTokenSecret));
  app.use("/sessions", sessionRoutes({ storage, harness, config, logger }));
  app.use("/sessions/:id", voiceRoutes({ storage, harness, config, speechProviderName: speech.provider.name }));
  app.use("/me", meRoutes(storage, auth));
  app.use("/admin", adminRoutes(storage));
  if (config.nodeEnv !== "production") app.use("/internal/mcp", mcpRoutes(mcp, storage));

  app.use(errorHandler(logger));

  return {
    app,
    config,
    logger,
    storage,
    auth,
    harness,
    mcp,
    mailer,
    speech,
    llm,
    /** Called by the server bootstrap once an http.Server exists (§7). */
    attachLiveChannel: (server) => attachLiveChannel({ server, harness, storage, config, logger }),
    close: () => storage.close(),
  };
}

/**
 * Application logger with mandatory redaction.
 *
 * CLAUDE.md §8: "Never log full resume text, full clipboard content, or full
 * answer transcripts in plaintext application logs." Rather than trusting every
 * call site to remember, this logger drops known-sensitive keys and truncates
 * any string long enough to be a transcript.
 */

const SENSITIVE_KEYS = new Set([
  "passcode",
  "passcodehash",
  "passcode_hash",
  "password",
  "token",
  "authorization",
  "accesstoken",
  "access_token",
  "sessiontoken",
  "session_token",
  "resettoken",
  "reset_token",
  "consenttoken",
  "consent_token",
  "resume",
  "resumetext",
  "resume_text",
  "transcript",
  "answer",
  "answertranscript",
  "answer_transcript",
  "audio",
  "clipboard",
  "clipboardcontent",
  "clipboard_content",
  "jobdescription",
  "job_description",
]);

const MAX_STRING = 200;

export function redact(value: unknown, depth = 0): unknown {
  if (depth > 6) return "[depth-limit]";
  if (typeof value === "string") {
    return value.length > MAX_STRING ? `${value.slice(0, MAX_STRING)}…[truncated]` : value;
  }
  if (Array.isArray(value)) return value.slice(0, 25).map((v) => redact(v, depth + 1));
  if (value && typeof value === "object") {
    const out: Record<string, unknown> = {};
    for (const [key, v] of Object.entries(value)) {
      out[key] = SENSITIVE_KEYS.has(key.toLowerCase()) ? "[redacted]" : redact(v, depth + 1);
    }
    return out;
  }
  return value;
}

export type LogLevel = "debug" | "info" | "warn" | "error";

export interface Logger {
  debug(msg: string, fields?: Record<string, unknown>): void;
  info(msg: string, fields?: Record<string, unknown>): void;
  warn(msg: string, fields?: Record<string, unknown>): void;
  error(msg: string, fields?: Record<string, unknown>): void;
  /** Everything this logger has written — used by the privacy tests. */
  history(): string[];
}

export interface LoggerOptions {
  /** Set false in tests to capture without writing to stdout. */
  writeToConsole?: boolean;
  minLevel?: LogLevel;
}

const LEVEL_ORDER: Record<LogLevel, number> = { debug: 10, info: 20, warn: 30, error: 40 };

export function createLogger(options: LoggerOptions = {}): Logger {
  const { writeToConsole = true, minLevel = "info" } = options;
  const lines: string[] = [];

  const write = (level: LogLevel, msg: string, fields?: Record<string, unknown>) => {
    if (LEVEL_ORDER[level] < LEVEL_ORDER[minLevel]) return;
    const line = JSON.stringify({
      level,
      msg,
      at: new Date().toISOString(),
      ...(fields ? (redact(fields) as Record<string, unknown>) : {}),
    });
    lines.push(line);
    if (writeToConsole) process.stdout.write(`${line}\n`);
  };

  return {
    debug: (m, f) => write("debug", m, f),
    info: (m, f) => write("info", m, f),
    warn: (m, f) => write("warn", m, f),
    error: (m, f) => write("error", m, f),
    history: () => [...lines],
  };
}

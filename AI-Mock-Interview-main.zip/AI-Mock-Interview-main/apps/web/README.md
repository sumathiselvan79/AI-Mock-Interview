# apps/web — candidate- and admin-facing frontend

Next.js app: Login, Home, Interview Config, Telemetry Check, Interview Environment,
Post-Interview Report (page-to-state mapping in `INSTRUCTIONS.md §3.1`).

**Not built yet — deliberately.** Nothing in the Stage 1 checklist
(`TRACKING.md`) is a page: Stage 1 is auth, gateway, data layer and the harness
skeleton, all of which are proven through the API. The first pages land in
Stage 2 with the Interview Config page, which is the first one with an agent
behind it.

The contract this app will be built against already exists:

- REST + WebSocket surface — `INSTRUCTIONS.md §7`
- Shared types — `@mia/shared-types`
- Auth: `POST /auth/login` returns a role-scoped bearer token; the gateway
  enforces the role on every request, so the frontend's routing is a
  convenience, never the control (`INSTRUCTIONS.md §8`)

The frontend never speaks MCP. It talks to the gateway, which talks to the
Harness Agent (`CLAUDE.md §5`).

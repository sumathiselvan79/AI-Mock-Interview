/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // The backend is a separate service; the browser calls it directly over REST
  // (CLAUDE.md §5). Set NEXT_PUBLIC_GATEWAY_URL per environment.
  //
  // Points at the FastAPI port (`backend/`, `npm run dev:backend`) by
  // default — the TypeScript gateway (`apps/gateway`) is frozen (see
  // `apps/gateway/FROZEN.md`) and both implementations serve on :4000, so no
  // URL change was needed for the cutover, only this default's meaning.
  env: {
    NEXT_PUBLIC_GATEWAY_URL: process.env.NEXT_PUBLIC_GATEWAY_URL ?? "http://localhost:4000",
  },
};

export default nextConfig;

/** Tailwind v4 is a PostCSS plugin; there is no tailwind.config.js — the theme
 *  lives in `app/globals.css` under `@theme`. See the comment block there. */
const config = {
  plugins: {
    "@tailwindcss/postcss": {},
  },
};

export default config;

"use client";

/**
 * Student Home page (CLAUDE.md §11, INSTRUCTIONS.md §3.1): the student's own
 * past interview stats and a "start new interview" button. This is the page
 * an Admin never sees — an Admin has no way to start a session as a candidate
 * (INSTRUCTIONS.md §3.2), and this page never renders for that role.
 */

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  CalendarClock,
  CircleUserRound,
  Clock,
  Code2,
  HelpCircle,
  Loader2,
  Menu,
  Play,
  Settings,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import { toast } from "sonner";
import { api, auth, ApiCallError, type StudentSchedule } from "@/lib/api";
import { formatDate, formatDateTime, formatScoreValue } from "@/lib/format";
import { cn } from "@/lib/utils";
import {
  BentoGrid,
  InlineError,
  Notice,
  Page,
  PageHeader,
  SectionTitle,
  Stat,
  StatGrid,
} from "@/app/components/shell";
import { useReveal } from "@/lib/motion";
import { InterviewHistory } from "@/app/components/interview-history";
import { Alert, AlertDescription, AlertTitle } from "@/app/components/ui/alert";
import { Badge } from "@/app/components/ui/badge";
import { Button } from "@/app/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/app/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/app/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/app/components/ui/dropdown-menu";
import { Input } from "@/app/components/ui/input";
import { Label } from "@/app/components/ui/label";
import { Skeleton } from "@/app/components/ui/skeleton";

interface Stats {
  sessionsCompleted: number;
  averageScore: number | null;
  lastSessionAt: string | null;
  recurringFocusAreas: string[];
}

export default function StudentHomePage() {
  const router = useRouter();
  const bentoRef = useReveal<HTMLDivElement>();
  const [stats, setStats] = useState<Stats | null>(null);
  const [error, setError] = useState<string | null>(null);
  // (Stage 5, §11.4) Accounts created before the profile fields existed, or
  // through an OAuth identity that never collected them, still need a full
  // name before their sessions can be archived.
  const [needsProfile, setNeedsProfile] = useState(false);
  const [fullName, setFullName] = useState("");
  const [department, setDepartment] = useState("");
  const [programYear, setProgramYear] = useState("");
  const [savingProfile, setSavingProfile] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);

  useEffect(() => {
    if (auth.role() === "admin") {
      router.replace("/admin");
      return;
    }
    if (!auth.token()) {
      router.replace("/");
      return;
    }
    api
      .myStats()
      .then((result) => setStats(result.stats))
      .catch((err) => setError(err instanceof ApiCallError ? err.message : "could not load your stats"));

    api
      .getProfile()
      .then((result) => {
        setNeedsProfile(!result.archive_ready);
        setFullName(result.profile.full_name ?? "");
        setDepartment(result.profile.department ?? "");
        setProgramYear(result.profile.program_year ?? "");
      })
      // A profile check failing is not worth an error banner on the Home page;
      // the prompt simply does not appear.
      .catch(() => setNeedsProfile(false));
  }, [router]);

  async function saveProfile(event: React.FormEvent) {
    event.preventDefault();
    setSavingProfile(true);
    try {
      const result = await api.updateProfile({
        full_name: fullName,
        department,
        program_year: programYear,
      });
      setNeedsProfile(!result.archive_ready);
      setProfileOpen(false);
      toast.success("Your details are saved.");
    } catch (err) {
      setError(err instanceof ApiCallError ? err.message : "could not save your details");
    } finally {
      setSavingProfile(false);
    }
  }

  return (
    <Page>
      <PageHeader
        title="Your practice history"
        lede="Run a timed mock interview and get specific, evidence-based feedback tied to what you actually said."
        actions={
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm">
                <Menu aria-hidden="true" />
                Menu
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-44">
              <DropdownMenuItem onSelect={() => setProfileOpen(true)}>
                <CircleUserRound aria-hidden="true" />
                Profile
              </DropdownMenuItem>
              <DropdownMenuItem
                // Was a window.alert(). A toast says the same thing without
                // seizing the page, and never blocks the tab.
                onSelect={() => toast("Settings are not available yet.")}
              >
                <Settings aria-hidden="true" />
                Settings
              </DropdownMenuItem>
              <DropdownMenuItem onSelect={() => setHelpOpen(true)}>
                <HelpCircle aria-hidden="true" />
                Help
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        }
      />

      {error ? <InlineError>{error}</InlineError> : null}

      {/*
        The "finish your profile" prompt stays INLINE and non-modal, unlike the
        Profile dialog it opens. It is a standing condition on the account, not
        something the candidate just asked to see, and a modal thrown up over the
        page on every load would be the wrong register for "we need one more
        field before your next session can be filed".
      */}
      {needsProfile ? (
        <Alert variant="warn">
          <CircleUserRound aria-hidden="true" />
          <AlertTitle>Finish your profile</AlertTitle>
          <AlertDescription>
            <p>
              Your name is needed before a completed interview can be filed with your department. It
              does not change how you are interviewed or scored.
            </p>
            <Button size="sm" variant="outline" className="mt-2" onClick={() => setProfileOpen(true)}>
              Add your name
            </Button>
          </AlertDescription>
        </Alert>
      ) : null}

      <section className="space-y-4">
        <SectionTitle>At a glance</SectionTitle>
        {stats ? (
          <BentoGrid ref={bentoRef} className="grid-cols-1 auto-rows-auto gap-3 sm:grid-cols-3">
            <Stat value={stats.sessionsCompleted} label="Interviews completed" />
            {/* formatScoreValue, not `?? 0`: no reports is not a score of zero. */}
            <Stat value={formatScoreValue(stats.averageScore)} label="Avg score / 5" />
            <Stat value={formatDate(stats.lastSessionAt)} label="Last session" emphasis="date" />

            {stats.recurringFocusAreas.length > 0 ? (
              <Card className="sm:col-span-3">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-base">
                    <Sparkles className="size-4 text-muted-foreground" aria-hidden="true" />
                    Keeps coming up
                  </CardTitle>
                  <Notice>Areas that showed up as a focus area in more than one report.</Notice>
                </CardHeader>
                <CardContent className="flex flex-wrap gap-2">
                  {stats.recurringFocusAreas.map((topic) => (
                    <Badge key={topic} variant="outline" className="px-2.5 py-1 text-sm font-normal">
                      {topic}
                    </Badge>
                  ))}
                </CardContent>
              </Card>
            ) : null}
          </BentoGrid>
        ) : error ? null : (
          <StatGrid>
            {[0, 1, 2].map((i) => (
              <div key={i} className="rounded-lg border bg-background px-3.5 py-3">
                <Skeleton className="h-7 w-14" />
                <Skeleton className="mt-2 h-3 w-24" />
              </div>
            ))}
          </StatGrid>
        )}
      </section>

      {/*
        (Stage 7) Interviews an Admin assigned. Shown ABOVE the free-form
        "start new interview" button because an assignment has a deadline and
        the self-serve option does not — but the free-form option stays, since
        being assigned one interview is not a reason to stop practising.
      */}
      <ScheduledInterviews />

      <Card className="overflow-hidden border-primary/25 bg-gradient-to-br from-primary/[0.06] via-card to-card">
        <CardContent className="flex flex-col items-start gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="space-y-0.5">
            <p className="font-display text-lg font-semibold tracking-tight">Practise on your own</p>
            <Notice>Pick any role and job description — no deadline, as many as you like.</Notice>
          </div>
          <Button size="lg" onClick={() => router.push("/interview/new")} className="w-full sm:w-auto">
            <Play aria-hidden="true" />
            Start new interview
          </Button>
        </CardContent>
      </Card>

      {/*
        Past sessions, BELOW the start button rather than above it: the point of
        this page is to run another interview, and history is what you consult
        after deciding not to. It renders its own empty state, so a candidate
        with no history still learns that reports will land here.
      */}
      <InterviewHistory />

      {/* One form, two entry points: the menu item and the prompt above. */}
      <Dialog open={profileOpen} onOpenChange={setProfileOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Your profile</DialogTitle>
            <DialogDescription>
              Only your name is required. Department and year help an admin find your reports.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={saveProfile} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="profile-full-name">Full name</Label>
              <Input
                id="profile-full-name"
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                autoComplete="name"
                required
              />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="profile-department" className="text-muted-foreground">
                  Department <span className="font-normal">(optional)</span>
                </Label>
                <Input
                  id="profile-department"
                  type="text"
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="profile-year" className="text-muted-foreground">
                  Year <span className="font-normal">(optional)</span>
                </Label>
                <Input
                  id="profile-year"
                  type="text"
                  value={programYear}
                  onChange={(e) => setProgramYear(e.target.value)}
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="submit" disabled={savingProfile}>
                {savingProfile ? <Loader2 className="animate-spin" aria-hidden="true" /> : null}
                {savingProfile ? "Saving…" : "Save"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={helpOpen} onOpenChange={setHelpOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Help &amp; FAQ</DialogTitle>
          </DialogHeader>
          <dl className="space-y-4 text-sm">
            <div className="space-y-1">
              <dt className="font-medium">How does this work?</dt>
              <dd className="text-muted-foreground">
                You will be asked a series of questions, and you can answer them using your
                microphone. Typing is always available too.
              </dd>
            </div>
            <div className="space-y-1">
              <dt className="font-medium">How is my score calculated?</dt>
              <dd className="text-muted-foreground">
                An AI evaluates your answers against a fixed rubric, and every score points back to
                something you actually said.
              </dd>
            </div>
            {/* soul.md §3 again, at the moment a candidate is asking what the
                score means. The header says it too; this is where it matters. */}
            <div className="space-y-1">
              <dt className="font-medium">Is this a real interview?</dt>
              <dd className="text-muted-foreground">
                No. This is practice, not a hiring decision, and nothing here is a prediction about
                a real job.
              </dd>
            </div>
          </dl>
        </DialogContent>
      </Dialog>
    </Page>
  );
}

/**
 * (Stage 7) The candidate's assigned interviews.
 *
 * Starting one creates an ordinary session seeded with the assignment's role
 * and JD, then lands on Interview Config exactly like the self-serve path —
 * resume upload, the JD-fit check and the device check all still happen
 * (`ADMIN_FEATURE_PROMPT.md` Part 3, soul.md §"Consent-first monitoring").
 */
function ScheduledInterviews() {
  const router = useRouter();
  const [scheduled, setScheduled] = useState<StudentSchedule[]>([]);
  const [starting, setStarting] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api
      .myScheduledInterviews()
      .then((result) => setScheduled(result.scheduled))
      // A student with no assignments is the normal case; an error here just
      // means the section does not render.
      .catch(() => setScheduled([]));
  }, []);

  const start = async (id: string) => {
    setStarting(id);
    setError(null);
    try {
      const session = await api.startScheduledInterview(id);
      router.push(`/interview/${session.session_id}/config`);
    } catch (err) {
      setError(err instanceof ApiCallError ? err.message : "could not start that interview");
      setStarting(null);
    }
  };

  // Cancelled assignments are already filtered out server-side. `completed`
  // ones are dropped here: they are in the stats above, not upcoming work.
  const upcoming = scheduled.filter((s) => s.status !== "completed");
  if (upcoming.length === 0) return null;

  return (
    <section className="space-y-4">
      <SectionTitle>Assigned to you</SectionTitle>
      {error ? <InlineError>{error}</InlineError> : null}
      <ul className="space-y-3">
        {upcoming.map((s) => (
          <li key={s.id}>
            <ScheduleCard
              schedule={s}
              starting={starting === s.id}
              onStart={() => void start(s.id)}
              onResume={() => router.push(`/interview/${s.session_id}/config`)}
            />
          </li>
        ))}
      </ul>
    </section>
  );
}

/** The window/deadline sentence, as one place rather than a nested ternary in JSX. */
function windowCopy(s: StudentSchedule): { text: string; tone: "ok" | "warn" | "muted" } {
  switch (s.status) {
    case "sent":
      return s.deadline
        ? { text: `Open now — due by ${formatDateTime(s.deadline)}`, tone: "ok" }
        : { text: "Open now", tone: "ok" };
    case "pending":
      return { text: `Opens ${formatDateTime(s.scheduled_for)}`, tone: "muted" };
    case "missed":
      return { text: "The deadline for this one has passed", tone: "warn" };
    default:
      return { text: "In progress", tone: "warn" };
  }
}

function ScheduleCard({
  schedule: s,
  starting,
  onStart,
  onResume,
}: {
  schedule: StudentSchedule;
  starting: boolean;
  onStart: () => void;
  onResume: () => void;
}) {
  // Not named `window` — that shadows the global inside a client component.
  const windowState = windowCopy(s);
  const open = s.status === "sent";

  return (
    <Card
      className={cn(
        "transition-[transform,box-shadow] duration-300 hover:-translate-y-0.5 hover:shadow-md",
        open && "border-primary/40",
      )}
    >
      <CardContent className="space-y-3">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0 space-y-1.5">
            <p className="font-medium leading-tight">{s.role}</p>
            <div className="flex flex-wrap items-center gap-1.5">
              <Badge variant="secondary" className="font-normal">
                {s.interview_type}
              </Badge>
              <Badge variant="outline" className="font-normal">
                {s.difficulty}
              </Badge>
              <Badge variant="outline" className="font-normal">
                <Clock aria-hidden="true" />
                {s.duration_minutes} min
              </Badge>
              {s.runs_coding_round ? (
                <Badge variant="outline" className="font-normal">
                  <Code2 aria-hidden="true" />
                  coding round
                </Badge>
              ) : null}
            </div>
          </div>

          {open ? (
            <Button onClick={onStart} disabled={starting}>
              {starting ? <Loader2 className="animate-spin" aria-hidden="true" /> : <Play aria-hidden="true" />}
              {starting ? "Starting…" : "Start"}
            </Button>
          ) : s.status === "started" && s.session_id ? (
            <Button variant="outline" onClick={onResume}>
              Resume
            </Button>
          ) : (
            <Badge variant={windowState.tone}>{s.status}</Badge>
          )}
        </div>

        <p
          className={
            windowState.tone === "ok"
              ? "flex items-center gap-1.5 text-sm text-ok"
              : windowState.tone === "warn"
                ? "flex items-center gap-1.5 text-sm text-warn"
                : "flex items-center gap-1.5 text-sm text-muted-foreground"
          }
        >
          <CalendarClock className="size-3.5 shrink-0" aria-hidden="true" />
          {windowState.text}
        </p>

        {/*
          The consent note the gateway attaches to the student projection. Kept
          on the card rather than tucked behind a tooltip: it is how a candidate
          learns an Admin did NOT answer the consent questions for them
          (soul.md §"Consent-first monitoring", CLAUDE.md §14).
        */}
        <p className="flex items-start gap-1.5 border-t pt-3 text-xs text-muted-foreground">
          <ShieldCheck className="mt-0.5 size-3.5 shrink-0" aria-hidden="true" />
          {s.consent_note}
        </p>
      </CardContent>
    </Card>
  );
}

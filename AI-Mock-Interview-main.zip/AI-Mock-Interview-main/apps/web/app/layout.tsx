import type { Metadata } from "next";
import type { ReactNode } from "react";
import { GeistSans } from "geist/font/sans";
import { GeistMono } from "geist/font/mono";
import "./globals.css";
import { ThemeProvider } from "./components/theme-provider";
import { SiteHeader } from "./components/site-header";
import { Toaster } from "./components/ui/sonner";
import { TooltipProvider } from "./components/ui/tooltip";

/**
 * Type system (see globals.css's type-conventions comment for where each is
 * used) — the full-reskin pivot away from Stage 8's IBM Plex/Space Grotesk
 * pairing: Geist Sans/Mono, one family for body, display, and numeric
 * readouts, self-hosted via the `geist` package (pre-built next/font-style
 * loading — no runtime request, no layout shift, still works offline once
 * built). `GeistSans`/`GeistMono` are ready-made font objects, not factory
 * calls, and already expose the `--font-geist-sans`/`--font-geist-mono`
 * variables `globals.css`'s `@theme inline` block reads.
 */

export const metadata: Metadata = {
  title: "Mock Interview Practice",
  description: "Practice interviews with structured, evidence-based feedback.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    // next-themes stamps the theme class onto <html> on the client before paint,
    // so the server-rendered markup legitimately differs for this one attribute.
    <html
      lang="en"
      suppressHydrationWarning
      className={`${GeistSans.variable} ${GeistMono.variable}`}
    >
      <body className="min-h-dvh">
        <ThemeProvider>
          <TooltipProvider delayDuration={300}>
            <SiteHeader />
            {/* `.mia-main` is the 46rem reading column; a page opts into the
                80rem admin width with <WidePage> (see components/shell.tsx). */}
            <main className="mia-main">{children}</main>
            <Toaster />
          </TooltipProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}

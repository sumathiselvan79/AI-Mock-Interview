"use client";

/**
 * Signup — self-service student registration (Stage 3 addition,
 * `INSTRUCTIONS.md §7`).
 *
 * There is no role selector, and there never should be: the gateway hardcodes
 * `student` and ignores anything the client sends. Admin accounts stay
 * operator-provisioned (§3.2). A control here would imply a choice the server
 * does not honour.
 */

import { useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Check, Loader2, X } from "lucide-react";
import { api, auth, ApiCallError } from "@/lib/api";
import { AuthCard, AuthHero, GoogleSignInButton, OrDivider } from "@/app/components/auth-card";
import { InlineError } from "@/app/components/shell";
import { Button } from "@/app/components/ui/button";
import { Input } from "@/app/components/ui/input";
import { Label } from "@/app/components/ui/label";
import { Separator } from "@/app/components/ui/separator";

const MIN_PASSCODE_LENGTH = 8;

export default function SignupPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [passcode, setPasscode] = useState("");
  const [confirm, setConfirm] = useState("");
  // (Stage 5, §11.4) Collected here rather than later: archiving refuses
  // without a full name, so a candidate who skips this has sessions that
  // cannot be archived. Department and year are genuinely optional.
  const [fullName, setFullName] = useState("");
  const [department, setDepartment] = useState("");
  const [programYear, setProgramYear] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [touched, setTouched] = useState<{ passcode?: boolean; confirm?: boolean }>({});

  const longEnough = passcode.length >= MIN_PASSCODE_LENGTH;
  const matches = confirm !== "" && passcode === confirm;
  const showLengthState = touched.passcode && passcode !== "";
  const showMatchState = touched.confirm && confirm !== "";

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    if (passcode !== confirm) {
      setError("those two passcodes do not match");
      return;
    }
    if (passcode.length < MIN_PASSCODE_LENGTH) {
      setError(`your passcode needs at least ${MIN_PASSCODE_LENGTH} characters`);
      return;
    }

    setBusy(true);
    setError(null);
    try {
      const { token, user } = await api.register(email, passcode, {
        full_name: fullName,
        department,
        program_year: programYear,
      });
      auth.set(token, user.role);
      router.push("/home");
    } catch (err) {
      setError(err instanceof ApiCallError ? err.message : "could not create that account");
      setBusy(false);
    }
  }

  return (
    <AuthHero
      imageSeed="lattice-drift"
      headline="Build the habit before it counts."
      blurb="Set up once — every session after this one starts calibrated to your role and resume."
    >
      <AuthCard
        title="Create an account"
        description="Practice interviews with feedback that points at specific moments in what you said."
        footer={
          <span>
            Already have an account?{" "}
            <Link href="/" className="font-medium text-primary underline-offset-4 hover:underline">
              Sign in
            </Link>
          </span>
        }
      >
        {error ? <InlineError>{error}</InlineError> : null}

        <form onSubmit={onSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="email">Email</Label>
          <Input
            id="email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            autoComplete="username"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="full-name">Full name</Label>
          <Input
            id="full-name"
            type="text"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            autoComplete="name"
            required
          />
        </div>

        {/* Optional block, visually set apart so it is obvious it can be skipped. */}
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="department" className="text-muted-foreground">
              Department <span className="font-normal">(optional)</span>
            </Label>
            <Input
              id="department"
              type="text"
              value={department}
              onChange={(e) => setDepartment(e.target.value)}
              placeholder="Computer Science"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="program-year" className="text-muted-foreground">
              Year <span className="font-normal">(optional)</span>
            </Label>
            <Input
              id="program-year"
              type="text"
              value={programYear}
              onChange={(e) => setProgramYear(e.target.value)}
              placeholder="3rd Year"
            />
          </div>
        </div>

        <Separator />

        <div className="space-y-2">
          <Label htmlFor="passcode">Passcode</Label>
          <Input
            id="passcode"
            type="password"
            value={passcode}
            onChange={(e) => setPasscode(e.target.value)}
            onBlur={() => setTouched((t) => ({ ...t, passcode: true }))}
            autoComplete="new-password"
            minLength={MIN_PASSCODE_LENGTH}
            aria-invalid={(showLengthState && !longEnough) || undefined}
            aria-describedby="passcode-rule"
            required
          />
          {/* States the rule up front rather than only failing on submit. */}
          <Requirement
            id="passcode-rule"
            met={longEnough}
            show={showLengthState}
            text={`At least ${MIN_PASSCODE_LENGTH} characters`}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="confirm">Confirm passcode</Label>
          <Input
            id="confirm"
            type="password"
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            onBlur={() => setTouched((t) => ({ ...t, confirm: true }))}
            autoComplete="new-password"
            aria-invalid={(showMatchState && !matches) || undefined}
            aria-describedby="confirm-rule"
            required
          />
          <Requirement
            id="confirm-rule"
            met={matches}
            show={showMatchState}
            text={matches ? "Passcodes match" : "Passcodes do not match yet"}
          />
        </div>

        <Button type="submit" className="w-full" disabled={busy}>
          {busy ? <Loader2 className="animate-spin" aria-hidden="true" /> : null}
          {busy ? "Creating…" : "Create account"}
        </Button>
      </form>

      <OrDivider />
      {/* Same identity path as the Sign-in page's Google button (§3.2's
          "no self-service admin" still holds: role resolves server-side from
          the admin allowlist either way). A Google account with no `fullName`
          on file gets caught by the Home page's profile-completion prompt. */}
        <GoogleSignInButton label="Sign up with Google" />
      </AuthCard>
    </AuthHero>
  );
}

/**
 * One passcode rule and whether it is currently satisfied.
 *
 * Before the field is touched this is plain grey guidance, not a red failure —
 * an empty form a candidate has not filled in yet is not a form full of errors.
 */
function Requirement({
  id,
  met,
  show,
  text,
}: {
  id: string;
  met: boolean;
  show: boolean | undefined;
  text: string;
}) {
  return (
    <p
      id={id}
      className={
        !show
          ? "flex items-center gap-1.5 text-xs text-muted-foreground"
          : met
            ? "flex items-center gap-1.5 text-xs text-ok"
            : "flex items-center gap-1.5 text-xs text-destructive"
      }
    >
      {show ? (
        met ? (
          <Check className="size-3.5" aria-hidden="true" />
        ) : (
          <X className="size-3.5" aria-hidden="true" />
        )
      ) : (
        <span className="size-3.5" aria-hidden="true" />
      )}
      {text}
    </p>
  );
}

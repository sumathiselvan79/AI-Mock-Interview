"use client";

/**
 * The shell Sign-in and Sign-up share, plus the Google button they both carry.
 *
 * Kept as one component because the two pages previously drifted: the divider,
 * the Google button width, and the "already have an account" affordance were
 * copied between them and had already stopped matching. `AuthHero` is the
 * same idea one level up — the editorial split-hero frame both pages sit
 * inside, so a headline/image tweak is one edit instead of two near-copies.
 */

import type { ReactNode } from "react";
import { GATEWAY_URL } from "@/lib/api";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/app/components/ui/card";
import { cn } from "@/lib/utils";
import { useHeroReveal } from "@/lib/motion";

/**
 * The editorial split hero both auth pages open with: a big display
 * headline over a textured, non-literal image on wide screens, the form
 * itself as the "Action" panel. On narrow screens the image panel drops out
 * entirely rather than stacking above the form — a decorative image
 * pushing a sign-in field below the fold on a phone is a worse trade than
 * just not showing it there.
 *
 * The image is a moody abstract texture (never a stock "person" photo,
 * never a fabricated testimonial) — heavy filters keep it reading as
 * atmosphere, not stock photography.
 */
export function AuthHero({
  imageSeed,
  headline,
  blurb,
  children,
}: {
  imageSeed: string;
  headline: ReactNode;
  blurb: ReactNode;
  children: ReactNode;
}) {
  const heroRef = useHeroReveal<HTMLDivElement>();
  return (
    <div
      ref={heroRef}
      className="grid items-center gap-8 py-4 sm:py-8 lg:grid-cols-[1.05fr_1fr] lg:gap-14 lg:py-12"
    >
      <div className="hidden lg:block">
        <div className="relative aspect-[4/5] overflow-hidden rounded-2xl border">
          <img
            src={`https://picsum.photos/seed/${imageSeed}/1200/1500`}
            alt=""
            aria-hidden="true"
            className="h-full w-full object-cover opacity-90 grayscale contrast-125"
            style={{ mixBlendMode: "luminosity" }}
          />
          <div
            className="absolute inset-0"
            style={{
              background:
                "linear-gradient(180deg, color-mix(in oklab, var(--primary) 30%, transparent) 0%, transparent 45%), linear-gradient(0deg, var(--background) 0%, transparent 55%)",
            }}
          />
          <div className="absolute inset-x-0 bottom-0 p-8">
            <p className="font-display text-[2rem] font-semibold leading-[1.08] tracking-tight text-foreground">
              {headline}
            </p>
            <p className="mt-3 max-w-sm text-sm text-muted-foreground">{blurb}</p>
          </div>
        </div>
      </div>
      <div>{children}</div>
    </div>
  );
}

export function AuthCard({
  title,
  description,
  children,
  footer,
  className,
}: {
  title: ReactNode;
  description: ReactNode;
  children: ReactNode;
  footer?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("mx-auto w-full max-w-md py-2 sm:py-8", className)}>
      <Card className="border-border/80 shadow-lg shadow-primary/[0.03] backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="font-display text-2xl font-semibold sm:text-[1.75rem]">{title}</CardTitle>
          <CardDescription>{description}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">{children}</CardContent>
        {footer ? (
          <CardFooter className="justify-center border-t text-sm text-muted-foreground">
            {footer}
          </CardFooter>
        ) : null}
      </Card>
    </div>
  );
}

/** "or" with a rule either side — the old `p.divider`. */
export function OrDivider({ label = "or" }: { label?: string }) {
  return (
    <div className="flex items-center gap-3" aria-hidden="true">
      <span className="h-px flex-1 bg-border" />
      <span className="text-xs uppercase tracking-wide text-muted-foreground">{label}</span>
      <span className="h-px flex-1 bg-border" />
    </div>
  );
}

/**
 * Google's own mark, inline.
 *
 * Not a second icon set — lucide ships no brand marks, and a "Continue with
 * Google" button without Google's G does not read as one. Everything else in
 * this app is lucide.
 */
function GoogleMark() {
  return (
    <svg viewBox="0 0 18 18" className="size-4" aria-hidden="true" focusable="false">
      <path
        fill="#4285F4"
        d="M17.64 9.2c0-.64-.06-1.25-.16-1.84H9v3.48h4.84a4.14 4.14 0 0 1-1.8 2.72v2.26h2.91c1.7-1.57 2.69-3.88 2.69-6.62Z"
      />
      <path
        fill="#34A853"
        d="M9 18c2.43 0 4.47-.8 5.96-2.18l-2.91-2.26c-.81.54-1.84.86-3.05.86-2.34 0-4.32-1.58-5.03-3.7H.96v2.34A9 9 0 0 0 9 18Z"
      />
      <path
        fill="#FBBC05"
        d="M3.97 10.72a5.41 5.41 0 0 1 0-3.44V4.94H.96a9 9 0 0 0 0 8.12l3.01-2.34Z"
      />
      <path
        fill="#EA4335"
        d="M9 3.58c1.32 0 2.5.46 3.44 1.35l2.58-2.58C13.46.9 11.43 0 9 0A9 9 0 0 0 .96 4.94l3.01 2.34C4.68 5.16 6.66 3.58 9 3.58Z"
      />
    </svg>
  );
}

/**
 * A plain navigation, not a fetch call: GET /auth/google/start (auth.ts §5)
 * redirects the browser to Google's own consent screen, which this app cannot do
 * from inside a fetch response. The round trip back lands on /auth/callback,
 * which is the only page that reads the token this flow produces.
 *
 * An `<a>` styled as a button rather than a `<Button asChild>` around a Link,
 * because this must be a full document navigation off-origin — a client-side
 * route transition would never leave the app.
 */
export function GoogleSignInButton({ label = "Continue with Google" }: { label?: string }) {
  return (
    <a
      href={`${GATEWAY_URL}/auth/google/start`}
      className={cn(
        "inline-flex h-9 w-full items-center justify-center gap-2 rounded-md border bg-background",
        "text-sm font-medium shadow-xs transition-colors",
        "hover:bg-accent hover:text-accent-foreground",
        "outline-none focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50",
        "dark:border-input dark:bg-input/30 dark:hover:bg-input/50",
      )}
    >
      <GoogleMark />
      {label}
    </a>
  );
}

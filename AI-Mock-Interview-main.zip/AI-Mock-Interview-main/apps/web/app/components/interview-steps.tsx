"use client";

/**
 * Where the candidate is in setup.
 *
 * The three pages before the interview (`/interview/new`, `CONFIG`,
 * `TELEMETRY_CHECK` — CLAUDE.md §11) each used to open with no indication that
 * two more were coming, which makes a device check feel like an interruption
 * rather than the last step. This is orientation only; it is not a navigation
 * control, because the steps are gated by session state and a candidate cannot
 * jump to the device check before a session exists.
 */

import { Check } from "lucide-react";
import { cn } from "@/lib/utils";

const STEPS = [
  { key: "role", label: "Role & job description" },
  { key: "resume", label: "Resume & focus" },
  { key: "devices", label: "Device & consent" },
] as const;

export type SetupStep = (typeof STEPS)[number]["key"];

export function InterviewSteps({ current }: { current: SetupStep }) {
  const currentIndex = STEPS.findIndex((s) => s.key === current);

  return (
    <nav aria-label="Interview setup progress">
      <ol className="flex items-center text-sm">
        {STEPS.map((step, i) => {
          const done = i < currentIndex;
          const active = i === currentIndex;
          return (
            <li key={step.key} className="flex flex-1 items-center last:flex-none">
              <span
                className={cn(
                  "flex items-center gap-2.5",
                  active && "font-medium text-foreground",
                  done && "text-muted-foreground",
                  !active && !done && "text-muted-foreground/60",
                )}
                aria-current={active ? "step" : undefined}
              >
                <span
                  className={cn(
                    "flex size-7 shrink-0 items-center justify-center rounded-full border font-mono text-xs font-semibold transition-colors",
                    active && "border-primary bg-primary text-primary-foreground shadow-glow",
                    done && "border-ok/50 bg-ok/10 text-ok",
                    !active && !done && "border-border bg-card",
                  )}
                >
                  {done ? <Check className="size-3.5" aria-hidden="true" /> : i + 1}
                </span>
                <span className="hidden sm:inline">{step.label}</span>
                {/* The state is in the styling; say it in words too. */}
                {done ? <span className="sr-only">(done)</span> : null}
              </span>
              {i < STEPS.length - 1 ? (
                <span
                  aria-hidden="true"
                  className={cn("mx-3 h-px flex-1 sm:mx-4", done ? "bg-ok/40" : "bg-border")}
                />
              ) : null}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}

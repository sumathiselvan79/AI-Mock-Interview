"use client";

/**
 * The candidate's own interview history, on the Student Home page.
 *
 * This is the same list an Admin sees in the profile drill-down
 * (`app/admin/users/[userId]/page.tsx`), from the same rows: both render what
 * `app/http/session_summaries.py` builds, so a candidate and an Admin looking
 * at one interview see the same date, duration, status and score. It is a
 * second *renderer* of that list rather than a shared component only because
 * the two surfaces differ in more than styling — the Admin table opens a report
 * inline beside a scheduling panel, this one navigates to the candidate's own
 * report page and offers a download. The pieces that carry a rule
 * (`formatScore`, `formatDuration`, `SessionStatusBadge`) are imported, not
 * re-implemented, which is where drift would actually hurt.
 *
 * Three rules worth keeping:
 *
 *  - A null score renders `—`, never `0`. A session with no report has not
 *    scored zero (soul.md §"No fabrication", CLAUDE.md §15).
 *  - `has_report` gates the buttons; it is not a permission check. The gateway
 *    scopes `GET /sessions/:id/report` to the session's owner, and this flag
 *    only avoids offering a button that would 404.
 *  - No overall figure is computed here. `overall_score` arrives from the
 *    gateway; a second average in the browser is how the two start to disagree.
 */

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { CalendarClock, Download, Eye, Loader2 } from "lucide-react";
import { toast } from "sonner";

import { api, type CandidateSessionSummary } from "@/lib/api";
import { downloadAsJson } from "@/lib/download";
import { formatDate, formatDuration, formatScore } from "@/lib/format";
import { cn } from "@/lib/utils";
import {
  EmptyState,
  InlineError,
  Notice,
  SectionTitle,
  SessionStatusBadge,
} from "@/app/components/shell";
import { Button } from "@/app/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/app/components/ui/card";
import { Skeleton } from "@/app/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/app/components/ui/table";

export function InterviewHistory() {
  const [sessions, setSessions] = useState<CandidateSessionSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api
      .mySessions()
      .then((result) => setSessions(result.sessions))
      // Inline, not a toast: this is a section that failed to load, and the
      // candidate needs to know the list is missing rather than empty.
      .catch(() => setError("Could not load your interview history."))
      .finally(() => setLoading(false));
  }, []);

  return (
    <section className="space-y-4">
      <SectionTitle>Past interviews</SectionTitle>
      {error ? <InlineError>{error}</InlineError> : null}

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Your sessions</CardTitle>
          <Notice>Review the feedback from a previous session, or download the full report.</Notice>
        </CardHeader>

        {loading ? (
          <CardContent className="space-y-3">
            {[0, 1, 2].map((i) => (
              <Skeleton key={i} className="h-10 w-full" />
            ))}
          </CardContent>
        ) : sessions.length === 0 ? (
          <CardContent>
            <EmptyState icon={<CalendarClock aria-hidden="true" />} title="No past interviews yet">
              Your completed practice sessions and evidence-based reports will appear here.
            </EmptyState>
          </CardContent>
        ) : (
          <>
            {/* Desktop: one row per session. */}
            <CardContent className="hidden px-0 sm:block">
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead className="pl-6 text-xs uppercase tracking-wide">Date</TableHead>
                    <TableHead className="text-xs uppercase tracking-wide">Role</TableHead>
                    <TableHead className="text-xs uppercase tracking-wide">Duration</TableHead>
                    <TableHead className="text-right text-xs uppercase tracking-wide">Score</TableHead>
                    <TableHead className="text-xs uppercase tracking-wide">Status</TableHead>
                    <TableHead className="pr-6" />
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sessions.map((session) => (
                    <TableRow key={session.session_id}>
                      <TableCell className="whitespace-nowrap pl-6">
                        {formatDate(session.started_at)}
                      </TableCell>
                      <TableCell>{session.role}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        {formatDuration(session.duration_minutes)}
                      </TableCell>
                      {/* formatScore, not `?? 0`: no report is not a score of zero. */}
                      <TableCell className="whitespace-nowrap text-right font-mono tabular-nums">
                        {formatScore(session.overall_score)}
                      </TableCell>
                      <TableCell>
                        <SessionStatusBadge status={session.status} />
                      </TableCell>
                      <TableCell className="pr-6">
                        <ReportActions session={session} className="justify-end" />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>

            {/* Mobile: the same fields stacked, because six columns on a phone
                is a horizontal scrollbar hiding the two buttons that matter. */}
            <CardContent className="space-y-3 sm:hidden">
              {sessions.map((session) => (
                <div key={session.session_id} className="space-y-2.5 rounded-lg border p-3.5">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="truncate font-medium leading-tight">{session.role}</p>
                      <p className="text-xs text-muted-foreground">
                        {formatDate(session.started_at)} · {formatDuration(session.duration_minutes)}
                      </p>
                    </div>
                    <SessionStatusBadge status={session.status} />
                  </div>
                  <div className="flex flex-wrap items-center justify-between gap-2 border-t pt-2.5">
                    <span className="font-mono text-sm tabular-nums">
                      {formatScore(session.overall_score)}
                    </span>
                    <ReportActions session={session} />
                  </div>
                </div>
              ))}
            </CardContent>
          </>
        )}
      </Card>
    </section>
  );
}

/**
 * View / Download, or the reason there is neither.
 *
 * One component for both layouts so the empty case ("No report") cannot end up
 * worded one way in the table and another on the phone card.
 */
function ReportActions({
  session,
  className,
}: {
  session: CandidateSessionSummary;
  className?: string;
}) {
  const router = useRouter();
  const [downloading, setDownloading] = useState(false);

  if (!session.has_report) {
    return <span className="text-sm text-muted-foreground">No report</span>;
  }

  /**
   * Serialised in the browser from the report the gateway just returned — no
   * download endpoint is involved. The report-download routes are all under
   * `/admin` and would 403 here; `lib/download.ts` carries the full note.
   */
  async function download() {
    setDownloading(true);
    try {
      const { report } = await api.getReport(session.session_id);
      downloadAsJson(report, `interview-report-${session.session_id}.json`);
    } catch {
      toast.error("Could not download that report.");
    } finally {
      setDownloading(false);
    }
  }

  return (
    <span className={cn("flex flex-wrap items-center gap-1.5", className)}>
      <Button
        type="button"
        variant="outline"
        size="sm"
        onClick={() => router.push(`/interview/${session.session_id}/report`)}
      >
        <Eye aria-hidden="true" />
        View
      </Button>
      <Button
        type="button"
        variant="ghost"
        size="sm"
        disabled={downloading}
        onClick={() => void download()}
      >
        {downloading ? (
          <Loader2 className="animate-spin" aria-hidden="true" />
        ) : (
          <Download aria-hidden="true" />
        )}
        Download
      </Button>
    </span>
  );
}

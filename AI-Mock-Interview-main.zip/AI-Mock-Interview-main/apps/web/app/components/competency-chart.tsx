"use client";

/**
 * The competency breakdown chart.
 *
 * Its own module so `report-view.tsx` can pull it in with `next/dynamic`.
 * Recharts is ~130 kB, the chart cannot server-render anyway (it measures the
 * DOM before it draws), and the report page is the first thing a candidate sees
 * after finishing an interview — so it is loaded after the page rather than
 * inside it.
 */

import { Bar, BarChart, CartesianGrid, LabelList, XAxis, YAxis } from "recharts";

import type { CompetencyScore } from "@/lib/api";
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "@/app/components/ui/chart";

const CHART_CONFIG = {
  score: { label: "Score", color: "var(--chart-1)" },
} satisfies ChartConfig;

/**
 * Horizontal bars, one hue.
 *
 * The job is "compare magnitude across named categories", which is a bar
 * chart's job — not a radar, whose apparent shape changes with the order the
 * axes happen to be in, and not a multi-hue palette, because these are not
 * competing series that need telling apart. Horizontal rather than vertical
 * because competency names are words, not dates.
 *
 * FIXED 0-5 domain, the same rule as the admin score trend: a report whose
 * highest score is 3 must not draw that bar full-width, because the bar's length
 * means "where this sat on the rubric", not "how it compared to your other
 * answers in this session".
 */
export function CompetencyChart({ scores }: { scores: CompetencyScore[] }) {
  const data = scores.map((s) => ({ competency: s.competency, score: s.score }));
  const longest = Math.max(...scores.map((s) => s.competency.length), 8);
  // Enough room for the longest label without letting one long name squeeze the
  // plot area down to nothing.
  const axisWidth = Math.min(160, Math.max(80, longest * 6.6));
  // A fixed row height, so three competencies do not stretch to the same box as
  // eight and read as bigger bars.
  const height = scores.length * 36 + 28;

  return (
    <ChartContainer
      config={CHART_CONFIG}
      className="aspect-auto w-full"
      style={{ height: `${height}px` }}
    >
      <BarChart
        data={data}
        layout="vertical"
        margin={{ top: 4, right: 28, bottom: 0, left: 0 }}
        barCategoryGap="22%"
      >
        {/* Vertical rules only — for horizontal bars those are the value grid. */}
        <CartesianGrid horizontal={false} stroke="var(--border)" />
        <XAxis
          type="number"
          // The fixed domain. Do not replace with `domain={[0, "dataMax"]}`.
          domain={[0, 5]}
          ticks={[0, 1, 2, 3, 4, 5]}
          tickLine={false}
          axisLine={false}
          tick={{ fill: "var(--muted-foreground)", fontSize: 11 }}
        />
        <YAxis
          type="category"
          dataKey="competency"
          width={axisWidth}
          tickLine={false}
          axisLine={false}
          tick={{ fill: "var(--muted-foreground)", fontSize: 11 }}
        />
        <ChartTooltip
          cursor={{ fill: "var(--muted)" }}
          content={
            <ChartTooltipContent
              formatter={(value) => (
                <span className="font-mono font-medium tabular-nums">{Number(value)} / 5</span>
              )}
            />
          }
        />
        <Bar
          dataKey="score"
          fill="var(--color-score)"
          // Rounded at the data end only, anchored flat to the zero baseline.
          radius={[0, 4, 4, 0]}
          maxBarSize={18}
        >
          {/* Direct labels, so a value can be read without tracking back to the
              axis. Safe to label every bar here — a report has a handful of
              competencies, not a hundred points. */}
          <LabelList
            dataKey="score"
            position="right"
            offset={8}
            className="fill-foreground"
            fontSize={11}
          />
        </Bar>
      </BarChart>
    </ChartContainer>
  );
}

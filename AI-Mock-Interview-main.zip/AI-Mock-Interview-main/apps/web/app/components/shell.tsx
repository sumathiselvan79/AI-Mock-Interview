"use client";

/**
 * Page furniture shared by every route.
 *
 * These exist so the twelve pages in this app stop each inventing their own
 * heading margin and their own error paragraph. They are thin — a `PageHeader`
 * is a heading and a lede, not a layout engine — and they encode the
 * conventions written down in `globals.css`, in one place, so a change to the
 * rhythm is one edit rather than twelve.
 *
 * `InlineError` and `Notice` replace the old `.error` and `.notice` rules and
 * deliberately keep their semantics: an error here is amber (`--warn`), not red,
 * because this app's failures are "that didn't work, try again" rather than
 * "you have destroyed something". Red is reserved for `--destructive`.
 */

import type { ComponentType, ReactNode, Ref } from "react";
import { AlertTriangle, CheckCircle2, PlayCircle, XCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/app/components/ui/alert";
import { Badge } from "@/app/components/ui/badge";
import { cn } from "@/lib/utils";

/** Wide layout opt-in: `globals.css`'s `.mia-main:has([data-layout="wide"])`. */
export function WidePage({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div data-layout="wide" className={cn("space-y-6", className)}>
      {children}
    </div>
  );
}

export function Page({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cn("space-y-6", className)}>{children}</div>;
}

export function PageHeader({
  title,
  lede,
  actions,
  className,
}: {
  title: ReactNode;
  lede?: ReactNode;
  /** Buttons or links that belong to the page as a whole, right-aligned on wide screens. */
  actions?: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between",
        className,
      )}
    >
      <div className="min-w-0 space-y-1.5">
        <h1 className="font-display text-[1.75rem] font-semibold tracking-tight sm:text-4xl">{title}</h1>
        {lede ? <p className="max-w-prose text-muted-foreground">{lede}</p> : null}
      </div>
      {actions ? <div className="flex shrink-0 flex-wrap items-center gap-2">{actions}</div> : null}
    </div>
  );
}

export function SectionTitle({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return <h2 className={cn("text-base font-semibold", className)}>{children}</h2>;
}

/**
 * A gapless bento container: `grid-flow-dense` so the browser backfills
 * short cells with later items instead of leaving a hole, plus a fixed
 * minimum row height so 1-, 2-, and 4-cell cards interlock cleanly. Callers
 * size a cell with `col-span-*`/`row-span-*` on their own card markup
 * (typically a `Card` from `ui/card.tsx`) — this component only owns the
 * grid math, not what goes in each cell, so it fits the Home "at a glance"
 * section, the Admin dashboard feed, and the Report competency layout alike
 * without three separate grid implementations drifting apart.
 */
export function BentoGrid({
  children,
  className,
  ref,
}: {
  children: ReactNode;
  className?: string;
  /** React 19: a function component can take `ref` as a plain prop. Used by
      pages that want the grid's entrance to be a `useReveal`/`useHeroReveal`
      target instead of wrapping it in an extra element. */
  ref?: Ref<HTMLDivElement>;
}) {
  return (
    <div
      ref={ref}
      className={cn(
        "grid auto-rows-[minmax(7rem,auto)] grid-flow-dense grid-cols-2 gap-3 sm:grid-cols-4",
        className,
      )}
    >
      {children}
    </div>
  );
}

/**
 * An operation that did not work.
 *
 * `role="alert"` comes from the underlying Alert, so a screen reader announces
 * it when it appears rather than only when focus happens to land on it.
 */
export function InlineError({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <Alert variant="warn" className={className}>
      <AlertTriangle aria-hidden="true" />
      <AlertDescription>{children}</AlertDescription>
    </Alert>
  );
}

/** Secondary explanatory copy. The old `.notice`. */
export function Notice({ children, className }: { children: ReactNode; className?: string }) {
  return <p className={cn("text-sm text-muted-foreground", className)}>{children}</p>;
}

/**
 * A verbatim quote from the candidate, or a metadata line under a title. The old
 * `.evidence`. Rendered as a block so it stacks under whatever it annotates.
 */
export function Evidence({ children, className }: { children: ReactNode; className?: string }) {
  return <span className={cn("block text-sm text-muted-foreground", className)}>{children}</span>;
}

export function EmptyState({
  icon,
  title,
  children,
  className,
}: {
  icon?: ReactNode;
  title: ReactNode;
  children?: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex flex-col items-center gap-2 rounded-lg border border-dashed px-6 py-10 text-center",
        className,
      )}
    >
      {icon ? <div className="text-muted-foreground [&_svg]:size-6">{icon}</div> : null}
      <p className="font-medium">{title}</p>
      {children ? <p className="max-w-prose text-sm text-muted-foreground">{children}</p> : null}
    </div>
  );
}

export function StatGrid({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div
      className={cn("grid grid-cols-2 gap-3 sm:grid-cols-[repeat(auto-fit,minmax(9rem,1fr))]", className)}
    >
      {children}
    </div>
  );
}

/**
 * One number with a label.
 *
 * `value` is a `ReactNode` and never a `number | null` on purpose — the caller
 * formats it, because the formatters are where the null rule lives: a candidate
 * with no reports renders `—`, never `0` (`admin/ui.tsx` `formatScore`,
 * soul.md §"No fabrication"). Taking a raw number here would invite a component
 * that quietly prints a zero nobody scored.
 */
export function Stat({
  value,
  label,
  hint,
  emphasis = "number",
  className,
}: {
  value: ReactNode;
  label: ReactNode;
  hint?: ReactNode;
  /** `date` shrinks the value type so a full date does not wrap in a 9rem tile. */
  emphasis?: "number" | "date";
  className?: string;
}) {
  return (
    <div className={cn("rounded-lg border bg-background px-3.5 py-3", className)}>
      <div
        className={cn(
          "font-mono font-semibold leading-tight tabular-nums",
          emphasis === "number" ? "text-2xl" : "text-base",
        )}
      >
        {value}
      </div>
      <div className="mt-0.5 text-[0.7rem] font-medium uppercase tracking-wide text-muted-foreground">
        {label}
      </div>
      {hint ? <div className="mt-1 text-xs text-muted-foreground">{hint}</div> : null}
    </div>
  );
}

/**
 * A 0-5 competency meter.
 *
 * Fixed denominator, exactly like the sparkline's fixed domain: the bar shows
 * where an answer sat on the rubric, so it must not rescale to whatever the
 * highest score in this particular report happened to be.
 */
export function ScoreMeter({
  score,
  max = 5,
  className,
  label,
}: {
  score: number;
  max?: number;
  className?: string;
  label?: string;
}) {
  const pct = Math.max(0, Math.min(1, score / max)) * 100;
  return (
    <div
      className={cn("h-1.5 w-full overflow-hidden rounded-full bg-border", className)}
      role="meter"
      aria-valuenow={score}
      aria-valuemin={0}
      aria-valuemax={max}
      aria-label={label ?? `${score} out of ${max}`}
    >
      <div className="h-full rounded-full bg-primary transition-[width]" style={{ width: `${pct}%` }} />
    </div>
  );
}

/**
 * Status tones.
 *
 * `StatusPill` and `SessionStatusBadge` moved here from `app/admin/ui.tsx` when
 * the Student Home page grew its own interview-history list: a candidate and an
 * Admin look at the same three session states, and a second copy of them in a
 * student component is how "completed" ends up green on one page and grey on
 * the other. `app/admin/ui.tsx` re-exports both, exactly as it already does for
 * the formatters, so every existing `from "../ui"` import keeps working.
 */
export type Tone = "ok" | "warn" | "muted";

/**
 * The icon is not decoration: colour alone is not an accessible status signal,
 * and these three tones (`--ok`, `--warn`, `--muted`) are deliberately close in
 * value so the table stays quiet. Icon + word means the state survives
 * greyscale, colour-blindness and a forced-colours mode.
 */
export function StatusPill({
  tone,
  label,
  Icon,
  title,
}: {
  tone: Tone;
  label: string;
  Icon: ComponentType<{ className?: string }>;
  title?: string;
}) {
  return (
    <Badge variant={tone} title={title}>
      <Icon aria-hidden="true" />
      {label}
    </Badge>
  );
}

/** The three states a `session_summaries` row can be in (`status`, not `state`). */
export function SessionStatusBadge({ status }: { status: string }) {
  const { tone, Icon } =
    status === "completed"
      ? { tone: "ok" as Tone, Icon: CheckCircle2 }
      : status === "abandoned"
        ? { tone: "warn" as Tone, Icon: XCircle }
        : { tone: "muted" as Tone, Icon: PlayCircle };
  return <StatusPill tone={tone} label={status.replace("_", " ")} Icon={Icon} />;
}

"use client";

/**
 * Theme plumbing for the whole app.
 *
 * `next-themes` with `attribute="class"`, `defaultTheme="system"`. The
 * pre-Tailwind stylesheet themed purely off `@media (prefers-color-scheme)`;
 * "system" reproduces exactly that as the default, and the class strategy adds
 * what the media query could not — a per-visitor override from the header
 * toggle, remembered across visits.
 *
 * `disableTransitionOnChange` stops every colour-transitioning element on the
 * page from cross-fading at once when the theme flips, which reads as a glitch
 * rather than a transition.
 */

import { ThemeProvider as NextThemesProvider } from "next-themes";
import type { ReactNode } from "react";

export function ThemeProvider({ children }: { children: ReactNode }) {
  return (
    <NextThemesProvider
      attribute="class"
      defaultTheme="system"
      enableSystem
      disableTransitionOnChange
    >
      {children}
    </NextThemesProvider>
  );
}

"use client";

/**
 * The one report renderer.
 *
 * Extracted from `app/interview/[id]/report/page.tsx` in Stage 7 so the Admin
 * profile drill-down could show a candidate's report without a second
 * implementation (`ADMIN_FEATURE_PROMPT.md`: "don't build a second report
 * renderer"). Two renderers would drift, and the one that drifted would be the
 * admin-facing one nobody proof-reads — which is exactly the copy that must not
 * start showing more than a `Report` contains.
 *
 * `audience` changes the copy, never the fields. There is no admin-only branch
 * that reveals anything extra, because the input type has nothing extra in it:
 * a `Report` has no resume, audio, or transcript field (soul.md §"Admin role").
 *
 * (Stage 8) Two decisions in here that are constraints rather than taste:
 *
 *  - **Nothing on this page computes a score.** Stage 8 phrased this as "there
 *    is no overall score", because at the time there was none to show: the
 *    Report Agent emitted per-competency numbers and nothing else, so an
 *    average printed here would have been a figure nothing in the session
 *    produced (soul.md §"No fabrication"). The grading addition did not lift
 *    that rule, it satisfied it — `report.overallGrade` is now assigned by the
 *    Eval Tool from the same evidenced scores, banded once, server-side, and
 *    rendered here verbatim. What is still forbidden is this file deriving one:
 *    no `reduce` over `competencyScores`, no letter picked from a threshold in
 *    the browser. If the field is absent, the report says so and shows nothing.
 *  - **Evidence is marked up as quotation, commentary is not.** A candidate has
 *    to be able to tell "here is what you said" from "here is what we made of
 *    it" at a glance, because only the first is a fact about them. Quotes are
 *    `<blockquote>` with a rule and italics; the app's own words never are.
 */

import dynamic from "next/dynamic";
import { CircleAlert, Info, MonitorX, Quote, Sparkles, Target } from "lucide-react";

import type { CompetencyScore, Report } from "@/lib/api";
import { Alert, AlertDescription, AlertTitle } from "@/app/components/ui/alert";
import { Badge } from "@/app/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/app/components/ui/card";
import { Skeleton } from "@/app/components/ui/skeleton";
import { useReveal } from "@/lib/motion";
import { cn } from "@/lib/utils";

/**
 * Loaded after the page, not inside it.
 *
 * `ssr: false` costs nothing — Recharts measures the DOM before it draws, so it
 * renders an empty box server-side either way — and keeps ~130 kB out of the
 * first load of the page a candidate lands on straight after their interview.
 * The evidence list below carries every score as a number, so the report is
 * fully readable in the moment before the chart arrives.
 */
const CompetencyChart = dynamic(
  () => import("@/app/components/competency-chart").then((m) => m.CompetencyChart),
  { ssr: false, loading: () => <Skeleton className="h-40 w-full" /> },
);

export interface ReportViewProps {
  report: Report;
  /**
   * `candidate` addresses the person who sat the interview ("you"); `admin`
   * describes them in the third person. Copy only.
   */
  audience?: "candidate" | "admin";
}

export function ReportView({ report, audience = "candidate" }: ReportViewProps) {
  const isAdmin = audience === "admin";
  const stackRef = useReveal<HTMLDivElement>({ y: 16, stagger: 0.06, start: "top 90%" });

  return (
    <div ref={stackRef} className="space-y-6">
      {/*
        soul.md §3: the system never implies this is a real hiring decision, and
        says so where the candidate will see it. Kept at the TOP of the report
        and given a real alert treatment rather than a grey footnote — this is the
        one sentence that frames everything below it.
      */}
      {report.disclaimer ? (
        <Alert variant="muted">
          <Info aria-hidden="true" />
          <AlertDescription>{report.disclaimer}</AlertDescription>
        </Alert>
      ) : null}

      <OverallGrade report={report} audience={audience} />

      {report.competencyScores.length > 0 ? (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Competency scores</CardTitle>
              <CardDescription>
                Each one out of 5, on the same rubric every candidate is scored against.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <CompetencyChart scores={report.competencyScores} />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">What each score is based on</CardTitle>
              <CardDescription>
                {isAdmin
                  ? "Quoted from the session transcript — every score traces to something that was actually said."
                  : "Quoted from what you actually said. Nothing here is inferred."}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="divide-y">
                {report.competencyScores.map((score: CompetencyScore) => (
                  <li key={score.competency} className="space-y-2 py-4 first:pt-0 last:pb-0">
                    <div className="flex flex-wrap items-baseline justify-between gap-2">
                      <span className="font-medium">{score.competency}</span>
                      <span className="flex items-center gap-2">
                        {/* The grade sits NEXT to the number it was banded
                            from, never instead of it. A letter alone reads as
                            a verdict; the pair reads as a measurement. */}
                        {score.grade ? (
                          <Badge
                            variant={score.grade.isStrength ? "outline" : "muted"}
                            className={score.grade.isStrength ? "border-ok/40 font-normal text-ok" : "font-normal"}
                            title={score.grade.descriptor}
                          >
                            {score.grade.letter} · {score.grade.label}
                          </Badge>
                        ) : null}
                        <Badge variant="outline" className="font-mono tabular-nums">
                          {score.score} / 5
                        </Badge>
                      </span>
                    </div>
                    {score.evidence.length > 0 ? (
                      <ul className="space-y-2">
                        {score.evidence.map((quote, i) => (
                          <li key={i}>
                            {/* Quotation markup, not just a lighter grey: this is
                                the candidate's own words and must be
                                distinguishable from the app's commentary. */}
                            <blockquote className="flex gap-2 border-l-2 pl-3 text-sm italic text-muted-foreground">
                              <Quote className="mt-1 size-3 shrink-0 not-italic" aria-hidden="true" />
                              <span>{quote}</span>
                            </blockquote>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      // soul.md §6: say there is nothing to point at rather than
                      // letting a bare score imply evidence that was never cited.
                      <p className="text-sm text-muted-foreground">
                        No specific moment was cited for this one.
                      </p>
                    )}
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </>
      ) : null}

      {/* Strengths and focus areas are separate cards, not one two-column block:
          they are different kinds of claim and should not read as a balance
          sheet where one cancels the other out. */}
      {report.strengths.length > 0 ? (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Sparkles className="size-4 text-ok" aria-hidden="true" />
              Strengths
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {report.strengths.map((s) => (
                <li key={s} className="flex items-start gap-2.5 text-sm">
                  <span
                    className="mt-1.5 size-1.5 shrink-0 rounded-full bg-ok"
                    aria-hidden="true"
                  />
                  <span>{s}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      ) : null}

      {report.focusAreas.length > 0 ? (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Target className="size-4 text-warn" aria-hidden="true" />
              Areas to focus on
            </CardTitle>
            <CardDescription>
              {isAdmin
                ? "Raised during the session, with the evidence above."
                : "These came up during the session. Working on them before your next practice will make a visible difference."}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {report.focusAreas.map((area) => (
                <li key={area} className="flex items-start gap-2.5 text-sm">
                  <span
                    className="mt-1.5 size-1.5 shrink-0 rounded-full bg-warn"
                    aria-hidden="true"
                  />
                  <span>{area}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      ) : null}

      {report.browserActivity && report.browserActivity.exitCount > 0 ? (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <MonitorX className="size-4 text-muted-foreground" aria-hidden="true" />
              Browser activity
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {report.browserActivity.concludedEarly ? (
              <Alert variant="warn">
                <CircleAlert aria-hidden="true" />
                <AlertTitle>This session ended early</AlertTitle>
                <AlertDescription>
                  <p>
                    {isAdmin
                      ? `Ended after ${report.browserActivity.exitCount} fullscreen exits, more than the 3 allowed. The feedback above covers what was completed before then.`
                      : `You left fullscreen ${report.browserActivity.exitCount} times, more than the 3 allowed. Feedback above covers what was completed before then.`}
                  </p>
                </AlertDescription>
              </Alert>
            ) : (
              <p className="text-sm text-muted-foreground">
                {isAdmin
                  ? `Left fullscreen ${report.browserActivity.exitCount} time${report.browserActivity.exitCount === 1 ? "" : "s"} during this session.`
                  : `You left fullscreen ${report.browserActivity.exitCount} time${report.browserActivity.exitCount === 1 ? "" : "s"} during this session.`}
              </p>
            )}
            <ul className="space-y-1">
              {report.browserActivity.events.map((e, i) => (
                <li key={i} className="font-mono text-sm tabular-nums text-muted-foreground">
                  {new Date(e.timestamp).toLocaleString()}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      ) : null}
    </div>
  );
}

/**
 * The session's overall grade.
 *
 * Everything here is read from `report.overallGrade` and nothing is derived:
 * the band, the label, the number it was banded from and the sentence
 * explaining it were all assigned by the Eval Tool (see this file's header, and
 * `backend/app/tools/eval/grading.py`). That is what lets the report show one at
 * all — Stage 8 refused an overall score precisely because there was no such
 * assignment behind it.
 *
 * When the field is absent the card says so in words. It does NOT fall back to
 * the lowest band, and it does not quietly disappear either: a candidate whose
 * session could not be graded should be told that, not left to conclude their
 * grade was too bad to print (soul.md §"No fabrication").
 */
function OverallGrade({ report, audience }: { report: Report; audience: "candidate" | "admin" }) {
  const isAdmin = audience === "admin";
  const grade = report.overallGrade;

  if (!grade) {
    // Nothing to grade at all is a different (and quieter) fact than a session
    // that ran and could not be graded — the empty report already says the
    // first, so this card only speaks to the second.
    if (report.competencyScores.length === 0) return null;
    return (
      <Card>
        <CardContent className="py-5">
          <p className="text-sm text-muted-foreground">
            No overall grade was assigned for this session — the individual scores below still stand.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardContent className="flex flex-wrap items-center gap-x-6 gap-y-4 py-6">
        <div
          className={cn(
            "flex size-16 shrink-0 items-center justify-center rounded-2xl border text-3xl font-semibold",
            grade.isStrength ? "border-ok/40 bg-ok/10 text-ok" : "border-border bg-muted text-foreground",
          )}
          aria-hidden="true"
        >
          {grade.letter}
        </div>
        <div className="min-w-0 space-y-1">
          <p className="flex flex-wrap items-baseline gap-x-2">
            <span className="font-display text-xl tracking-tight">{grade.label}</span>
            {/* Never the letter on its own — see the header comment. */}
            <span className="font-mono text-sm tabular-nums text-muted-foreground">
              {grade.score.toFixed(1)} / 5 across {report.competencyScores.length}{" "}
              {report.competencyScores.length === 1 ? "topic" : "topics"}
            </span>
          </p>
          <p className="max-w-prose text-sm text-muted-foreground">
            {isAdmin
              ? `Graded on the ${grade.scaleVersion} scale. ${grade.descriptor}`
              : grade.descriptor}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

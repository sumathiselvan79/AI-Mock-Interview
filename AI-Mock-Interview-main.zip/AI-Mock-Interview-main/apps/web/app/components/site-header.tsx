"use client";

/**
 * The app bar.
 *
 * The disclaimer is not decoration and must not be removed or shortened away in
 * a later redesign: soul.md §3 requires that the system never implies it is a
 * human recruiter or a real hiring decision, and says so where a candidate will
 * see it. On a narrow screen it moves under the brand rather than being hidden
 * behind a breakpoint, because "visible" is the requirement.
 *
 * The interview room is the one route this bar does not render on, and the
 * disclaimer is exactly why that needed care rather than an early return: the
 * room is the screen where a candidate is actively talking to "the
 * interviewer", so it is the screen where soul.md §3's line matters most and
 * the last place it may quietly vanish from. The room therefore renders
 * `SAFETY_DISCLAIMER` itself, in its own status strip — the string is exported
 * from here rather than retyped there, because two copies of a sentence the
 * ethics doc mandates become two different sentences the first time one is
 * edited.
 */

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useTheme } from "next-themes";
import { useEffect, useState } from "react";
import { LogOut, Monitor, MoonStar, Sun } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/app/components/ui/dropdown-menu";
import { auth } from "@/lib/api";

/**
 * soul.md §3, in one place. Rendered by this bar on every route except the
 * interview room, and by the room's own `StatusBar` on that one.
 */
export const SAFETY_DISCLAIMER = "Practice, not a hiring decision";

/**
 * The live interview screen. Matched on the route rather than passed down as a
 * prop, because this bar is mounted once in the root layout above `<main>` and
 * has no other way to know what is underneath it.
 */
const ROOM_ROUTE = /^\/interview\/[^/]+\/room\/?$/;

export function SiteHeader() {
  const pathname = usePathname();

  // The room hides the nav chrome — brand link, Log out, theme toggle — so the
  // candidate is not one stray click from ending a session mid-answer, and so
  // the stage gets the full height. Every other route in the app, including
  // this session's own config, telemetry-check and report pages, keeps the bar
  // and keeps Log out reachable.
  if (ROOM_ROUTE.test(pathname ?? "")) return null;

  return (
    // A floating glass pill rather than a bar glued to the viewport edge —
    // the premium-nav treatment, kept sticky and full-width-safe (the pill
    // itself caps at 80rem and floats inside a full-bleed positioning
    // wrapper) so it still docks correctly at every breakpoint.
    <div className="sticky top-3 z-40 px-3 sm:px-6">
      <header className="mx-auto flex w-full max-w-[80rem] items-center justify-between gap-3 rounded-2xl border bg-card/80 px-4 py-2.5 shadow-lg shadow-black/[0.03] backdrop-blur-md supports-[backdrop-filter]:bg-card/65">
        <div className="flex min-w-0 flex-col gap-x-3 gap-y-0.5 sm:flex-row sm:items-baseline">
          <Link
            href="/"
            className="truncate font-display font-semibold tracking-tight outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50"
          >
            Mock Interview Practice
          </Link>
          {/* soul.md §3. Stays on screen at every width. */}
          <span className="text-xs text-muted-foreground sm:text-sm">{SAFETY_DISCLAIMER}</span>
        </div>
        <div className="flex shrink-0 items-center gap-1">
          <LogoutButton />
          <ThemeToggle />
        </div>
      </header>
    </div>
  );
}

/**
 * Only rendered once a session token is actually present — the header mounts
 * on every page, including the signed-out login and signup pages, and the
 * token lives in `sessionStorage` (client-only, see lib/api.ts), so this
 * mirrors the `mounted` gate `ThemeToggle` already uses below: nothing is
 * known about auth state during server render, so the first client render
 * has to match it exactly or React logs a hydration mismatch.
 */
function LogoutButton() {
  const router = useRouter();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  if (!mounted || !auth.token()) return null;

  return (
    <Button
      type="button"
      variant="ghost"
      size="sm"
      className="text-muted-foreground"
      onClick={() => {
        auth.clear();
        router.push("/");
      }}
    >
      <LogOut aria-hidden="true" />
      Log out
    </Button>
  );
}

const THEMES = [
  { value: "light", label: "Light", Icon: Sun },
  { value: "dark", label: "Dark", Icon: MoonStar },
  { value: "system", label: "System", Icon: Monitor },
] as const;

/**
 * Light / dark / system.
 *
 * The icon is only rendered after mount: on the server there is no way to know
 * which theme the visitor resolved to, and rendering a guess is the classic
 * next-themes hydration mismatch. A fixed-size placeholder holds the space so
 * the header does not shift when it appears.
 */
function ThemeToggle() {
  const { theme, setTheme, resolvedTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  if (!mounted) {
    return <div className="size-8" aria-hidden="true" />;
  }

  const Icon = resolvedTheme === "dark" ? MoonStar : Sun;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon-sm" aria-label="Change colour theme">
          <Icon />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {THEMES.map(({ value, label, Icon: ItemIcon }) => (
          <DropdownMenuItem
            key={value}
            onClick={() => setTheme(value)}
            className={theme === value ? "font-medium text-primary" : undefined}
          >
            <ItemIcon />
            {label}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

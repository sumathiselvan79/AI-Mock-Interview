"use client";

/**
 * Landing page for GET /auth/google/callback's redirect (apps/gateway
 * src/http/routes/google-auth.ts). The gateway put the token in the URL
 * fragment rather than a query string on purpose — a fragment is never sent
 * to any server (including this one) on the navigation that got us here, only
 * readable by this page's own JS via `window.location.hash`. That is why this
 * has to be a client component reading `window.location` rather than a server
 * component reading `searchParams`.
 */

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Loader2, ShieldAlert } from "lucide-react";
import { auth } from "@/lib/api";
import { Button } from "@/app/components/ui/button";
import { Card, CardContent } from "@/app/components/ui/card";

export default function GoogleCallbackPage() {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const params = new URLSearchParams(window.location.hash.replace(/^#/, ""));
    const token = params.get("token");
    const role = params.get("role");

    if (!token || !role) {
      setError("Google sign-in did not return a valid session. Please try again.");
      return;
    }

    auth.set(token, role);
    // Replace, not push: this URL carries a credential in the fragment and
    // should not be reachable via the back button once consumed.
    router.replace(role === "admin" ? "/admin" : "/home");
  }, [router]);

  return (
    <div className="mx-auto flex min-h-[70dvh] w-full max-w-md items-center py-2 sm:py-8">
      <Card className="w-full border-border/80 shadow-lg shadow-primary/[0.03]">
        <CardContent className="flex flex-col items-center gap-3 py-10 text-center">
          {error ? (
            <>
              <ShieldAlert className="size-6 text-warn" aria-hidden="true" />
              <div className="space-y-1">
                <p className="font-medium">Sign-in did not complete</p>
                <p className="text-sm text-muted-foreground">{error}</p>
              </div>
              <Button asChild variant="outline" className="mt-1">
                <Link href="/">Return to sign in</Link>
              </Button>
            </>
          ) : (
            <>
              {/* The whole page is a two-second wait before a redirect, so it
                  says which two seconds these are rather than rendering blank.
                  aria-live, because the redirect leaves before a screen reader
                  would otherwise reach the text. */}
              <Loader2 className="size-6 animate-spin text-primary" aria-hidden="true" />
              <div className="space-y-1" role="status" aria-live="polite">
                <p className="font-medium">Signing you in…</p>
                <p className="text-sm text-muted-foreground">
                  Completing your Google sign-in. This takes a moment.
                </p>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

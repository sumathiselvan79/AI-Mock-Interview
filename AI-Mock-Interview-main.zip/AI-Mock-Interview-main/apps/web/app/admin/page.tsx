"use client";

/**
 * Admin Home dashboard (CLAUDE.md §11, INSTRUCTIONS.md §3.1, §3.2): an
 * aggregated view of every candidate's report. No "start new interview"
 * option — Admins do not take interviews as candidates. Only what a `Report`
 * already contains is shown here; there is no raw resume, audio, or
 * transcript to render even if this page wanted to (soul.md §5).
 */

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { ChevronRight, FileBarChart, MonitorX } from "lucide-react";
import { api, auth, ApiCallError, type Report } from "@/lib/api";
import { formatDate, pluralize } from "@/lib/format";
import {
  BentoGrid,
  EmptyState,
  InlineError,
  Notice,
  PageHeader,
  SectionTitle,
  Stat,
  StatGrid,
  WidePage,
} from "@/app/components/shell";
import { AdminNav } from "./nav";
import { Badge } from "@/app/components/ui/badge";
import { Card, CardContent } from "@/app/components/ui/card";
import { Skeleton } from "@/app/components/ui/skeleton";
import { useReveal } from "@/lib/motion";

export default function AdminHomePage() {
  const router = useRouter();
  const listRef = useReveal<HTMLUListElement>({ y: 14, stagger: 0.05, start: "top 92%" });
  const [reports, setReports] = useState<Report[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (auth.role() === "student") {
      router.replace("/home");
      return;
    }
    if (!auth.token()) {
      router.replace("/");
      return;
    }
    api
      .adminReports()
      .then((result) => setReports(result.reports))
      .catch((err) => setError(err instanceof ApiCallError ? err.message : "could not load reports"));
  }, [router]);

  /**
   * Counts only.
   *
   * There is deliberately no aggregate average score here. The directory's
   * average is computed by the gateway, and the codebase has a test asserting
   * the directory and the store's own aggregate never drift — a second average
   * computed in the browser, from a different formula, is exactly how that drift
   * starts. Everything below is a direct count of reports in hand.
   */
  const summary = useMemo(() => {
    if (!reports) return null;
    const candidates = new Set(reports.map((r) => r.candidateId));
    const endedEarly = reports.filter((r) => r.browserActivity?.concludedEarly).length;
    const latest = reports.reduce<string | null>(
      (newest, r) => (newest === null || r.createdAt > newest ? r.createdAt : newest),
      null,
    );
    return { total: reports.length, candidates: candidates.size, endedEarly, latest };
  }, [reports]);

  const newestFirst = useMemo(
    () => (reports ? [...reports].sort((a, b) => b.createdAt.localeCompare(a.createdAt)) : []),
    [reports],
  );

  return (
    <WidePage>
      <PageHeader
        title="Candidate reports"
        lede="Every completed practice session, independent of whether the candidate is still connected."
      />
      <AdminNav />

      {error ? <InlineError>{error}</InlineError> : null}

      {summary ? (
        <BentoGrid className="grid-cols-2 gap-3 sm:grid-cols-4">
          <Stat value={summary.total} label="Reports compiled" />
          <Stat value={summary.candidates} label="Candidates covered" />
          <Stat
            value={summary.endedEarly}
            label="Ended early"
            hint={summary.endedEarly > 0 ? "Fullscreen exit limit" : undefined}
          />
          <Stat value={formatDate(summary.latest)} label="Most recent" emphasis="date" />
        </BentoGrid>
      ) : error ? null : (
        <StatGrid>
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className="rounded-lg border bg-background px-3.5 py-3">
              <Skeleton className="h-7 w-12" />
              <Skeleton className="mt-2 h-3 w-24" />
            </div>
          ))}
        </StatGrid>
      )}

      <section className="space-y-3">
        <SectionTitle>Latest reports</SectionTitle>

        {!reports && !error ? (
          <div className="space-y-2">
            {[0, 1, 2].map((i) => (
              <Card key={i}>
                <CardContent className="space-y-2">
                  <Skeleton className="h-4 w-1/3" />
                  <Skeleton className="h-3 w-2/3" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : null}

        {reports && reports.length === 0 ? (
          <EmptyState icon={<FileBarChart />} title="No completed sessions yet">
            A report appears here as soon as a candidate finishes an interview.
          </EmptyState>
        ) : null}

        {reports && reports.length > 0 ? (
          <ul ref={listRef} className="space-y-2">
            {newestFirst.map((report) => (
              <li key={report.sessionId}>
                {/*
                  `Report.candidateId` is the user id (a session is created with
                  `candidateId: req.auth.sub`), so this is the candidate's own
                  profile — the drill-down that already exists, rather than a new
                  route. Previously these rows were not clickable at all.
                */}
                <Link
                  href={`/admin/users/${report.candidateId}`}
                  className="block rounded-xl outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50"
                >
                  <Card className="py-4 transition-[transform,border-color,background-color,box-shadow] duration-300 hover:-translate-y-0.5 hover:border-primary/40 hover:bg-muted/40 hover:shadow-md">
                    <CardContent className="flex items-center gap-3 px-4">
                      <div className="min-w-0 flex-1 space-y-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="truncate font-medium">Candidate {report.candidateId}</span>
                          <Badge variant="muted">{formatDate(report.createdAt)}</Badge>
                          {report.browserActivity && report.browserActivity.exitCount > 0 ? (
                            <Badge variant="warn" title="Fullscreen exits during this session">
                              <MonitorX aria-hidden="true" />
                              {report.browserActivity.exitCount}
                              {report.browserActivity.concludedEarly ? " · ended early" : ""}
                            </Badge>
                          ) : null}
                        </div>
                        <Notice>
                          {pluralize(report.competencyScores.length, "competency", "competencies")}{" "}
                          scored · {pluralize(report.strengths.length, "strength")} ·{" "}
                          {pluralize(report.focusAreas.length, "focus area")}
                        </Notice>
                      </div>
                      <ChevronRight
                        className="size-4 shrink-0 text-muted-foreground"
                        aria-hidden="true"
                      />
                    </CardContent>
                  </Card>
                </Link>
              </li>
            ))}
          </ul>
        ) : null}
      </section>
    </WidePage>
  );
}

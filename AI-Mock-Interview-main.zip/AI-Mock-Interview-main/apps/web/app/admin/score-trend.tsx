"use client";

/**
 * The candidate score trend chart.
 *
 * Its own module, and NOT part of `admin/ui.tsx`, on purpose: `ui.tsx` also
 * exports the avatar and the status badges, which three chartless admin pages
 * import. While the chart lived in that file, every one of them pulled Recharts
 * into its bundle — the schedule form was carrying ~130 kB of charting library to
 * render an avatar. Keep this separated, and prefer a `next/dynamic` import at
 * the call site (see `admin/users/[userId]/page.tsx`).
 */

import { CartesianGrid, Line, LineChart, XAxis, YAxis } from "recharts";

import { formatDate } from "@/lib/format";
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "@/app/components/ui/chart";

const TREND_CONFIG = {
  score: { label: "Overall score", color: "var(--chart-1)" },
} satisfies ChartConfig;

/**
 * Score trend.
 *
 * Was an inline SVG sparkline; now a Recharts line via shadcn's chart wrapper,
 * which buys the thing the sparkline could not do — hovering a point to see
 * which interview it was and what it scored.
 *
 * Three rules carried over verbatim from the sparkline:
 *
 *  - **Fixed 0-5 domain**, not min/max of the data. Auto-scaling would make a
 *    candidate whose scores went 3.9 → 4.0 look like a dramatic climb. The point
 *    of the line is where they sit on the rubric, not how much they wobbled.
 *  - **No dot per point.** A dot per interview turns a 20-session line into
 *    noise, so the resting state marks only the hovered point; the rest appear
 *    one at a time under the cursor.
 *  - **One and zero points are not a chart.** A line needs two points to mean
 *    anything, and drawing one anyway invites reading a slope into a single
 *    interview. Both cases say so in words instead.
 *
 * Single series, so no legend — the section heading names it (and a legend box
 * for one line is the classic chart anti-pattern).
 */
export function ScoreTrend({ points }: { points: { at: string; score: number }[] }) {
  if (points.length === 0) {
    return <p className="text-sm text-muted-foreground">No scored interviews yet — nothing to trend.</p>;
  }
  if (points.length === 1) {
    return (
      <p className="text-sm text-muted-foreground">
        One interview so far, scoring {points[0]!.score.toFixed(1)} / 5. A trend needs a second.
      </p>
    );
  }

  const data = points.map((p, i) => ({
    index: i,
    score: p.score,
    label: formatDate(p.at),
  }));

  const first = points[0]!.score;
  const last = points[points.length - 1]!.score;
  const direction = last > first ? "up" : last < first ? "down" : "flat";

  return (
    <figure className="m-0 space-y-1.5">
      <ChartContainer
        config={TREND_CONFIG}
        className="aspect-auto h-40 w-full"
        role="img"
        aria-label={`Score trend across ${points.length} interviews: ${first.toFixed(1)} to ${last.toFixed(1)} out of 5, trending ${direction}.`}
      >
        {/* ChartContainer supplies the ResponsiveContainer; the chart is its
            direct child. */}
        <LineChart data={data} margin={{ top: 8, right: 12, bottom: 0, left: -18 }}>
          {/* Horizontal only, and recessive: the gridlines are there to read a
              value off, not to be part of the picture. */}
          <CartesianGrid vertical={false} stroke="var(--border)" />
          <XAxis
            dataKey="label"
            tickLine={false}
            axisLine={false}
            tickMargin={8}
            minTickGap={24}
            tick={{ fill: "var(--muted-foreground)", fontSize: 11 }}
          />
          <YAxis
            // The fixed domain. Do not replace with `domain={["auto","auto"]}`.
            domain={[0, 5]}
            ticks={[0, 1, 2, 3, 4, 5]}
            tickLine={false}
            axisLine={false}
            width={40}
            tick={{ fill: "var(--muted-foreground)", fontSize: 11 }}
          />
          <ChartTooltip
            cursor={{ stroke: "var(--border)", strokeWidth: 1 }}
            content={
              <ChartTooltipContent
                labelKey="label"
                formatter={(value) => (
                  <span className="font-mono font-medium tabular-nums">{Number(value).toFixed(1)} / 5</span>
                )}
              />
            }
          />
          <Line
            dataKey="score"
            type="monotone"
            stroke="var(--color-score)"
            strokeWidth={2}
            strokeLinecap="round"
            // Resting state: no dot. `activeDot` is the hover affordance, and
            // the surface-coloured ring keeps it legible over a gridline.
            dot={false}
            activeDot={{ r: 4, strokeWidth: 2, stroke: "var(--card)" }}
          />
        </LineChart>
      </ChartContainer>
      <figcaption className="font-mono text-sm text-muted-foreground tabular-nums">
        {points.length} interviews · {first.toFixed(1)} → {last.toFixed(1)} out of 5
      </figcaption>
    </figure>
  );
}

"use client";

/**
 * Schedule an interview — `ADMIN_FEATURE_PROMPT.md` Part 3.
 *
 * Grouped Who → What → When → Notify, with a confirmation step before anything
 * is sent. The confirmation is not decoration: this creates a real obligation
 * for named students, so it does not fire straight off a submit button. It is an
 * AlertDialog, which means it also cannot be dismissed by clicking past it.
 *
 * Consent is NOT on this form, and cannot be. `soul.md`
 * §"Consent-first monitoring" makes it the candidate's to give — the gateway
 * rejects a schedule that tries to carry it, and the form says so where an
 * Admin would otherwise go looking. Do not add a consent control here; the
 * request would be rejected server-side anyway, and the control would imply a
 * power an Admin does not have.
 */

import { Suspense, useCallback, useEffect, useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import {
  CalendarCheck,
  CheckCircle2,
  ChevronLeft,
  Loader2,
  Search,
  Send,
  ShieldAlert,
  Users,
  X,
} from "lucide-react";
import { api, auth, ApiCallError, type DirectoryRow, type ScheduleDraftBody } from "@/lib/api";
import { formatDateTime } from "@/lib/format";
import { InlineError, Notice, PageHeader, WidePage } from "@/app/components/shell";
import { AdminNav } from "../nav";
import { Avatar } from "../ui";
import { Alert, AlertDescription, AlertTitle } from "@/app/components/ui/alert";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/app/components/ui/alert-dialog";
import { Badge } from "@/app/components/ui/badge";
import { Button } from "@/app/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/app/components/ui/card";
import { Checkbox } from "@/app/components/ui/checkbox";
import { Input } from "@/app/components/ui/input";
import { Label } from "@/app/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/app/components/ui/select";
import { Skeleton } from "@/app/components/ui/skeleton";
import { Textarea } from "@/app/components/ui/textarea";

const INTERVIEW_TYPES = ["behavioral", "technical", "behavioral+technical", "coding", "full"];
const DIFFICULTIES = ["junior", "mid", "senior", "staff+"];
const RECURRENCES = ["none", "weekly", "biweekly", "monthly"];

/** `datetime-local` wants `YYYY-MM-DDTHH:mm` in LOCAL time, not an ISO instant. */
function toLocalInput(date: Date): string {
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

/** Field keys that client-side validation can attach a message to. */
type FieldKey = "candidates" | "role" | "duration" | "scheduledFor" | "deadline" | "notify";

export default function SchedulePage() {
  return (
    <Suspense
      fallback={
        <WidePage>
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-64 w-full" />
        </WidePage>
      }
    >
      <ScheduleForm />
    </Suspense>
  );
}

function ScheduleForm() {
  const router = useRouter();
  const searchParams = useSearchParams();

  const [candidates, setCandidates] = useState<DirectoryRow[]>([]);
  const [departments, setDepartments] = useState<string[]>([]);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [pickerSearch, setPickerSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  /** Per-field messages, so a problem is shown at the control that caused it. */
  const [problems, setProblems] = useState<Partial<Record<FieldKey, string>>>({});
  const [confirming, setConfirming] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState<number | null>(null);

  const tomorrowAt9 = useMemo(() => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    d.setHours(9, 0, 0, 0);
    return d;
  }, []);

  const [form, setForm] = useState({
    role: "",
    jobDescription: "",
    interviewType: "behavioral+technical",
    difficulty: "mid",
    durationMinutes: 45,
    scheduledFor: toLocalInput(tomorrowAt9),
    deadline: "",
    recurring: "none",
    codingRoundEnabled: false,
    notes: "",
    notifyInApp: true,
    notifyEmail: false,
  });

  useEffect(() => {
    if (auth.role() === "student") {
      router.replace("/home");
      return;
    }
    if (!auth.token()) router.replace("/");
  }, [router]);

  useEffect(() => {
    // The whole cohort, so the picker can offer everyone — a page of 25 would
    // make "select the whole department" quietly mean "25 of them".
    api
      .adminUsers({ page: 1, page_size: 100, sort: "fullName", direction: "asc" })
      .then((result) => {
        setCandidates(result.rows);
        setDepartments(result.departments);
        const preselected = (searchParams.get("candidates") ?? "").split(",").filter(Boolean);
        if (preselected.length > 0) setSelected(new Set(preselected));
      })
      .catch((err) => setError(err instanceof ApiCallError ? err.message : "could not load candidates"))
      .finally(() => setLoading(false));
  }, [searchParams]);

  const selectDepartment = useCallback(
    (department: string) => {
      setSelected((prev) => {
        const next = new Set(prev);
        candidates.filter((c) => c.department === department).forEach((c) => next.add(c.user_id));
        return next;
      });
    },
    [candidates],
  );

  const toggle = (userId: string) =>
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(userId)) next.delete(userId);
      else next.add(userId);
      return next;
    });

  /**
   * Client-side validation mirrors the gateway's, so the common mistakes are
   * caught before a round trip. Same rules as before; they are now attributed to
   * a field instead of collapsing into one line at the top of the page.
   */
  const validate = (): Partial<Record<FieldKey, string>> => {
    const found: Partial<Record<FieldKey, string>> = {};
    if (selected.size === 0) found.candidates = "Pick at least one candidate.";
    if (form.role.trim() === "") {
      found.role = "A role is required — it is what the questions are built from.";
    }
    if (
      !Number.isInteger(form.durationMinutes) ||
      form.durationMinutes < 10 ||
      form.durationMinutes > 180
    ) {
      found.duration = "Must be a whole number of minutes between 10 and 180.";
    }
    if (!form.scheduledFor) found.scheduledFor = "Pick when the interview window opens.";
    if (form.deadline && new Date(form.deadline) <= new Date(form.scheduledFor)) {
      found.deadline = "The deadline has to be after the window opens, or it can never be started.";
    }
    if (!form.notifyInApp && !form.notifyEmail) found.notify = "Pick at least one way to notify them.";
    return found;
  };

  const review = () => {
    const found = validate();
    setProblems(found);
    if (Object.keys(found).length === 0) setConfirming(true);
  };

  const submit = async () => {
    setSubmitting(true);
    setError(null);
    try {
      const notifyVia = [
        ...(form.notifyInApp ? ["in_app"] : []),
        ...(form.notifyEmail ? ["email"] : []),
      ];
      const body: ScheduleDraftBody = {
        candidate_ids: [...selected],
        role: form.role.trim(),
        job_description: form.jobDescription,
        interview_type: form.interviewType,
        difficulty: form.difficulty,
        duration_minutes: form.durationMinutes,
        scheduled_for: new Date(form.scheduledFor).toISOString(),
        deadline: form.deadline ? new Date(form.deadline).toISOString() : null,
        recurring: form.recurring,
        coding_round_enabled: form.codingRoundEnabled,
        notes: form.notes.trim() || null,
        notify_via: notifyVia,
      };
      const result = await api.adminSchedule(body);
      setDone(result.scheduled.length);
    } catch (err) {
      setError(err instanceof ApiCallError ? err.message : "could not schedule that interview");
    } finally {
      setSubmitting(false);
      setConfirming(false);
    }
  };

  if (done !== null) {
    return (
      <WidePage>
        <AdminNav />
        <Card className="mx-auto max-w-xl">
          <CardContent className="space-y-4 text-center">
            <CheckCircle2 className="mx-auto size-8 text-ok" aria-hidden="true" />
            <div className="space-y-1">
              <p className="text-lg font-semibold">Scheduled</p>
              <p className="text-sm text-muted-foreground">
                Assigned to <strong>{done}</strong> candidate{done === 1 ? "" : "s"}. It appears on
                their home page when the window opens.
              </p>
            </div>
            <Alert variant="muted" className="text-left">
              <ShieldAlert aria-hidden="true" />
              <AlertDescription>
                They will still be asked to upload a resume, pass the device check, and give consent
                before the interview starts — none of that is pre-answered here.
              </AlertDescription>
            </Alert>
            <div className="flex flex-wrap justify-center gap-2">
              <Button asChild>
                <Link href="/admin/scheduled">See scheduled interviews</Link>
              </Button>
              <Button asChild variant="outline">
                <Link href="/admin/users">Back to candidates</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </WidePage>
    );
  }

  const selectedRows = candidates.filter((c) => selected.has(c.user_id));
  const term = pickerSearch.trim().toLowerCase();
  const visibleCandidates = term
    ? candidates.filter(
        (c) =>
          (c.full_name ?? "").toLowerCase().includes(term) ||
          c.email.toLowerCase().includes(term) ||
          (c.department ?? "").toLowerCase().includes(term),
      )
    : candidates;

  return (
    <WidePage>
      <Link
        href="/admin/users"
        className="inline-flex w-fit items-center gap-1 text-sm text-muted-foreground outline-none transition-colors hover:text-foreground focus-visible:ring-[3px] focus-visible:ring-ring/50"
      >
        <ChevronLeft className="size-4" aria-hidden="true" />
        Candidates
      </Link>
      <PageHeader
        title="Schedule an interview"
        lede="Assign a mock interview to one candidate or a whole department."
      />
      <AdminNav />

      {error ? <InlineError>{error}</InlineError> : null}

      {/* ------------------------------------------------------------- Who */}
      <Section step={1} title="Who" description="Pick the candidates this is assigned to.">
        {loading ? (
          <div className="space-y-2">
            <Skeleton className="h-9 w-full" />
            <Skeleton className="h-40 w-full" />
          </div>
        ) : candidates.length === 0 ? (
          <Notice>There are no student accounts to schedule for yet.</Notice>
        ) : (
          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-sm text-muted-foreground">Add a whole department:</span>
              {departments.map((d) => (
                <Button key={d} type="button" variant="outline" size="xs" onClick={() => selectDepartment(d)}>
                  {d}
                </Button>
              ))}
              {selected.size > 0 ? (
                <Button
                  type="button"
                  variant="ghost"
                  size="xs"
                  className="text-muted-foreground"
                  onClick={() => setSelected(new Set())}
                >
                  <X aria-hidden="true" />
                  Clear ({selected.size})
                </Button>
              ) : null}
            </div>

            {/* Search over the picker. A cohort of 100 in a fixed-height
                scroller is not something you can find one person in. */}
            <div className="relative">
              <Search
                className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
                aria-hidden="true"
              />
              <Input
                type="text"
                value={pickerSearch}
                onChange={(e) => setPickerSearch(e.target.value)}
                placeholder="Filter by name, email or department"
                aria-label="Filter candidates"
                className="pl-8"
              />
            </div>

            {/* Bounded height so a large cohort cannot push the submit button
                off the screen. */}
            <div className="max-h-64 overflow-y-auto rounded-md border">
              {visibleCandidates.length === 0 ? (
                <p className="px-3 py-6 text-center text-sm text-muted-foreground">
                  No candidate matches “{pickerSearch}”.
                </p>
              ) : (
                <ul className="divide-y">
                  {visibleCandidates.map((c) => (
                    <li key={c.user_id}>
                      <label
                        htmlFor={`c-${c.user_id}`}
                        className="flex cursor-pointer items-center gap-3 px-3 py-2 font-normal transition-colors hover:bg-muted/50"
                      >
                        <Checkbox
                          id={`c-${c.user_id}`}
                          checked={selected.has(c.user_id)}
                          onCheckedChange={() => toggle(c.user_id)}
                        />
                        <Avatar name={c.full_name} email={c.email} url={c.avatar_url} size={1.6} />
                        <span className="min-w-0">
                          <span className="block truncate text-sm">{c.full_name ?? c.email}</span>
                          <span className="block truncate text-xs text-muted-foreground">
                            {c.email}
                            {c.department ? ` · ${c.department}` : ""}
                          </span>
                        </span>
                      </label>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <p className="text-sm text-muted-foreground">
              {selected.size === 0
                ? "None selected yet."
                : `${selected.size} selected of ${candidates.length}.`}
            </p>
            <FieldProblem message={problems.candidates} />
          </div>
        )}
      </Section>

      {/* ------------------------------------------------- What kind of interview */}
      <Section step={2} title="What kind of interview" description="How the session is calibrated.">
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="role">Role</Label>
            <Input
              id="role"
              type="text"
              placeholder="Senior Backend Engineer"
              value={form.role}
              onChange={(e) => setForm({ ...form, role: e.target.value })}
              aria-invalid={Boolean(problems.role) || undefined}
              aria-describedby={problems.role ? "role-problem" : undefined}
            />
            <FieldProblem id="role-problem" message={problems.role} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="type">Type</Label>
            <Select
              value={form.interviewType}
              onValueChange={(value) => setForm({ ...form, interviewType: value })}
            >
              <SelectTrigger id="type" className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {INTERVIEW_TYPES.map((t) => (
                  <SelectItem key={t} value={t}>
                    {t}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="difficulty">Level</Label>
            <Select
              value={form.difficulty}
              onValueChange={(value) => setForm({ ...form, difficulty: value })}
            >
              <SelectTrigger id="difficulty" className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {DIFFICULTIES.map((d) => (
                  <SelectItem key={d} value={d}>
                    {d}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="duration">Duration (minutes)</Label>
            <Input
              id="duration"
              type="number"
              min={10}
              max={180}
              value={form.durationMinutes}
              onChange={(e) => setForm({ ...form, durationMinutes: Number(e.target.value) })}
              aria-invalid={Boolean(problems.duration) || undefined}
              aria-describedby={problems.duration ? "duration-problem" : undefined}
            />
            <FieldProblem id="duration-problem" message={problems.duration} />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="jd">
            Job description{" "}
            <span className="font-normal text-muted-foreground">
              (optional — pre-fills the JD-fit check)
            </span>
          </Label>
          <Textarea
            id="jd"
            value={form.jobDescription}
            onChange={(e) => setForm({ ...form, jobDescription: e.target.value })}
            className="min-h-24"
          />
        </div>

        <div className="space-y-2">
          <div className="flex items-start gap-2.5">
            <Checkbox
              id="coding"
              checked={form.codingRoundEnabled}
              onCheckedChange={(value) => setForm({ ...form, codingRoundEnabled: value === true })}
              className="mt-0.5"
            />
            <Label htmlFor="coding" className="font-normal leading-snug">
              Include a live coding round
            </Label>
          </div>
          {/* soul.md §"Consent-first monitoring": the one place an Admin would
              plausibly look for a consent control, so it says explicitly that
              there is not one. */}
          <Notice>
            A coding round asks the candidate for clipboard-monitoring consent when it starts. You
            cannot answer that for them — they are asked at the device check, as always.
          </Notice>
        </div>
      </Section>

      {/* ------------------------------------------------------------ When */}
      <Section step={3} title="When" description="The window the candidate can start in.">
        <div className="grid gap-4 sm:grid-cols-3">
          <div className="space-y-2">
            <Label htmlFor="opens">Window opens</Label>
            <Input
              id="opens"
              type="datetime-local"
              value={form.scheduledFor}
              onChange={(e) => setForm({ ...form, scheduledFor: e.target.value })}
              aria-invalid={Boolean(problems.scheduledFor) || undefined}
            />
            <FieldProblem message={problems.scheduledFor} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="deadline">
              Deadline <span className="font-normal text-muted-foreground">(optional)</span>
            </Label>
            <Input
              id="deadline"
              type="datetime-local"
              value={form.deadline}
              onChange={(e) => setForm({ ...form, deadline: e.target.value })}
              aria-invalid={Boolean(problems.deadline) || undefined}
            />
            <FieldProblem message={problems.deadline} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="recurring">Repeat</Label>
            <Select
              value={form.recurring}
              onValueChange={(value) => setForm({ ...form, recurring: value })}
            >
              <SelectTrigger id="recurring" className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {RECURRENCES.map((r) => (
                  <SelectItem key={r} value={r}>
                    {r}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </Section>

      {/* ---------------------------------------------------------- Notify */}
      <Section step={4} title="Notify" description="How they find out about it.">
        <div className="space-y-3">
          <div className="flex items-start gap-2.5">
            <Checkbox
              id="inapp"
              checked={form.notifyInApp}
              onCheckedChange={(value) => setForm({ ...form, notifyInApp: value === true })}
              className="mt-0.5"
            />
            <Label htmlFor="inapp" className="font-normal leading-snug">
              In-app — shows on their home page when the window opens
            </Label>
          </div>
          <div className="flex items-start gap-2.5">
            <Checkbox
              id="email"
              checked={form.notifyEmail}
              onCheckedChange={(value) => setForm({ ...form, notifyEmail: value === true })}
              className="mt-0.5"
            />
            <Label htmlFor="email" className="font-normal leading-snug">
              Email{" "}
              <span className="text-muted-foreground">(recorded, not yet delivered — see below)</span>
            </Label>
          </div>
          <FieldProblem message={problems.notify} />
          <Notice>
            This deployment has no mail service wired up, so email is recorded as intent only. The
            in-app notification is the one that actually reaches the candidate.
          </Notice>
        </div>

        <div className="space-y-2">
          <Label htmlFor="notes">
            Internal note{" "}
            <span className="font-normal text-muted-foreground">
              (optional — admins only, never shown to the candidate)
            </span>
          </Label>
          <Textarea
            id="notes"
            value={form.notes}
            onChange={(e) => setForm({ ...form, notes: e.target.value })}
            className="min-h-20"
          />
        </div>
      </Section>

      <div className="flex flex-wrap items-center gap-3 border-t pt-5">
        <Button type="button" size="lg" onClick={review}>
          <CalendarCheck aria-hidden="true" />
          Review before sending
        </Button>
        <Button asChild variant="ghost">
          <Link href="/admin/users">Cancel</Link>
        </Button>
        {Object.keys(problems).length > 0 ? (
          <Notice className="text-warn">Some fields still need attention.</Notice>
        ) : null}
      </div>

      {/*
        The confirmation. An AlertDialog rather than an inline panel: this
        assigns work to named people, and an AlertDialog cannot be dismissed by
        clicking beside it the way a Dialog can.
      */}
      <AlertDialog open={confirming} onOpenChange={setConfirming}>
        <AlertDialogContent className="max-w-lg">
          <AlertDialogHeader>
            <AlertDialogTitle>
              Assign to {selected.size} candidate{selected.size === 1 ? "" : "s"}?
            </AlertDialogTitle>
            <AlertDialogDescription>
              A <strong>{form.difficulty}</strong> <strong>{form.interviewType}</strong> interview
              for <strong>{form.role}</strong> ({form.durationMinutes} min), opening{" "}
              {form.scheduledFor ? formatDateTime(new Date(form.scheduledFor).toISOString()) : "—"}
              {form.deadline
                ? `, due by ${formatDateTime(new Date(form.deadline).toISOString())}`
                : ""}
              .
            </AlertDialogDescription>
          </AlertDialogHeader>

          {/* Named, with faces. "12 candidates" is easy to get wrong; a list of
              people you can read is not. */}
          <div className="max-h-52 overflow-y-auto rounded-md border">
            <ul className="divide-y">
              {selectedRows.map((c) => (
                <li key={c.user_id} className="flex items-center gap-2.5 px-3 py-2">
                  <Avatar name={c.full_name} email={c.email} url={c.avatar_url} size={1.6} />
                  <span className="min-w-0">
                    <span className="block truncate text-sm">{c.full_name ?? c.email}</span>
                    <span className="block truncate text-xs text-muted-foreground">{c.email}</span>
                  </span>
                </li>
              ))}
            </ul>
          </div>

          <Alert variant="muted">
            <ShieldAlert aria-hidden="true" />
            <AlertTitle>You are not consenting on their behalf</AlertTitle>
            <AlertDescription>
              <p>
                Consent, resume upload and the JD-fit check still happen live for each candidate —
                this does not pre-answer any of them.
              </p>
            </AlertDescription>
          </Alert>

          <AlertDialogFooter>
            <AlertDialogCancel disabled={submitting}>Back</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                // Kept open while the request is in flight, so the button can
                // show its own pending state instead of the dialog vanishing.
                e.preventDefault();
                void submit();
              }}
              disabled={submitting}
            >
              {submitting ? <Loader2 className="animate-spin" aria-hidden="true" /> : <Send aria-hidden="true" />}
              {submitting
                ? "Sending…"
                : `Send ${selected.size} invitation${selected.size === 1 ? "" : "s"}`}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </WidePage>
  );
}

/** One numbered group of the form — the Who / What / When / Notify structure. */
function Section({
  step,
  title,
  description,
  children,
}: {
  step: number;
  title: string;
  description: string;
  children: React.ReactNode;
}) {
  return (
    <Card className="border-border/80">
      <CardHeader>
        <CardTitle className="flex items-center gap-3 text-base">
          <span className="flex size-8 shrink-0 items-center justify-center rounded-full border border-primary/40 bg-primary/10 font-mono text-sm font-semibold text-primary">
            {step}
          </span>
          {title}
        </CardTitle>
        <CardDescription className="pl-[2.75rem]">{description}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">{children}</CardContent>
    </Card>
  );
}

function FieldProblem({ id, message }: { id?: string; message?: string }) {
  if (!message) return null;
  return (
    <p id={id} className="text-sm text-destructive">
      {message}
    </p>
  );
}

"use client";

/**
 * Admin User Profile drill-down — `ADMIN_FEATURE_PROMPT.md` Part 2.
 *
 * Identity and aggregate stats, a score trend, and the candidate's full
 * interview history. Opening a session's report renders the SAME component the
 * candidate's own report page uses (`app/components/report-view.tsx`) — there
 * is deliberately no admin copy of that renderer to drift.
 *
 * The data boundary: every session row here is built from `Session` metadata
 * and the session's `Report`. There is no control that fetches a resume, an
 * audio blob, or a transcript, and the gateway has no admin route that would
 * serve one (soul.md §"Admin role").
 */

import { useCallback, useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import dynamic from "next/dynamic";
import Link from "next/link";
import {
  CalendarPlus,
  ChevronLeft,
  Download,
  Eye,
  EyeOff,
  StickyNote,
  TrendingUp,
} from "lucide-react";
import {
  api,
  auth,
  downloadJson,
  ApiCallError,
  type AdminUserProfileResponse,
  type Report,
} from "@/lib/api";
import { formatDate, formatDateTime, formatDuration, formatScore, formatScoreValue } from "@/lib/format";
import { ReportView } from "@/app/components/report-view";
import {
  BentoGrid,
  EmptyState,
  InlineError,
  Notice,
  SectionTitle,
  Stat,
  WidePage,
} from "@/app/components/shell";
import { AdminNav } from "../../nav";
import { Avatar, ScheduleBadge, SessionStatusBadge } from "../../ui";
import { Button } from "@/app/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/app/components/ui/card";
import { Skeleton } from "@/app/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/app/components/ui/table";

/** Same reasoning as the report's competency chart — see report-view.tsx. */
const ScoreTrend = dynamic(() => import("../../score-trend").then((m) => m.ScoreTrend), {
  ssr: false,
  loading: () => <Skeleton className="h-40 w-full" />,
});

export default function AdminUserProfilePage() {
  const params = useParams<{ userId: string }>();
  const userId = params.userId;
  const router = useRouter();

  const [data, setData] = useState<AdminUserProfileResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  /** The session whose report is expanded inline, and the report itself. */
  const [openSession, setOpenSession] = useState<string | null>(null);
  const [openReport, setOpenReport] = useState<Report | null>(null);
  const [reportError, setReportError] = useState<string | null>(null);

  useEffect(() => {
    if (auth.role() === "student") {
      router.replace("/home");
      return;
    }
    if (!auth.token()) router.replace("/");
  }, [router]);

  useEffect(() => {
    let cancelled = false;
    api
      .adminUser(userId)
      .then((result) => {
        if (!cancelled) setData(result);
      })
      .catch((err) => {
        if (!cancelled) setError(err instanceof ApiCallError ? err.message : "could not load this candidate");
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [userId]);

  const openReportFor = useCallback(
    async (sessionId: string) => {
      // A second click on the open row collapses it.
      if (openSession === sessionId) {
        setOpenSession(null);
        setOpenReport(null);
        return;
      }
      setOpenSession(sessionId);
      setOpenReport(null);
      setReportError(null);
      try {
        const result = await api.adminReport(sessionId);
        setOpenReport(result.report);
      } catch (err) {
        setReportError(err instanceof ApiCallError ? err.message : "could not load that report");
      }
    },
    [openSession],
  );

  const download = useCallback(async (path: string, filename: string) => {
    try {
      await downloadJson(path, filename);
    } catch (err) {
      setError(err instanceof ApiCallError ? err.message : "could not download that report");
    }
  }, []);

  if (loading) {
    return (
      <WidePage>
        <BackLink />
        <AdminNav />
        <Card>
          <CardContent className="space-y-3">
            <div className="flex items-center gap-3">
              <Skeleton className="size-12 rounded-full" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-5 w-48" />
                <Skeleton className="h-3 w-64" />
              </div>
            </div>
            <Skeleton className="h-16 w-full" />
          </CardContent>
        </Card>
      </WidePage>
    );
  }

  if (error && !data) {
    return (
      <WidePage>
        <BackLink />
        <AdminNav />
        <InlineError>{error}</InlineError>
      </WidePage>
    );
  }

  if (!data) return null;
  const { profile, sessions, scheduled } = data;

  return (
    <WidePage>
      <BackLink />
      <AdminNav />

      {error ? <InlineError>{error}</InlineError> : null}

      <Card className="overflow-hidden border-primary/20 bg-gradient-to-br from-primary/[0.05] via-card to-card">
        <CardContent className="space-y-5">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="flex min-w-0 items-center gap-4">
              <Avatar
                name={profile.full_name}
                email={profile.email}
                url={profile.avatar_url}
                size={3.5}
                className="shadow-glow"
              />
              <div className="min-w-0 space-y-0.5">
                <h1 className="truncate font-display text-2xl font-semibold tracking-tight">
                  {profile.full_name ?? profile.email}
                </h1>
                <p className="truncate text-sm text-muted-foreground">
                  {profile.email}
                  {profile.department ? ` · ${profile.department}` : ""}
                  {profile.program_year ? ` · ${profile.program_year}` : ""}
                </p>
                <p className="text-sm text-muted-foreground">
                  Joined {formatDate(profile.created_at)}
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <Button asChild variant="outline" size="sm">
                <Link href={`/admin/schedule?candidates=${profile.user_id}`}>
                  <CalendarPlus aria-hidden="true" />
                  Schedule an interview
                </Link>
              </Button>
              {profile.interviews_completed > 0 ? (
                <Button
                  type="button"
                  size="sm"
                  onClick={() =>
                    download(
                      `/admin/users/${profile.user_id}/reports/download`,
                      `reports-${profile.user_id}.json`,
                    )
                  }
                >
                  <Download aria-hidden="true" />
                  Download all reports
                </Button>
              ) : null}
            </div>
          </div>

          <BentoGrid className="grid-cols-2 gap-3 sm:grid-cols-4">
            <Stat value={profile.interviews_completed} label="Interviews" />
            {/* formatScoreValue: a candidate with no reports shows em-dash, not 0. */}
            <Stat value={formatScoreValue(profile.average_score)} label="Avg score / 5" />
            <Stat
              value={formatDate(profile.last_interview_at)}
              label="Last interview"
              emphasis="date"
            />
            <Stat value={sessions.length} label="Sessions started" />
          </BentoGrid>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <TrendingUp className="size-4 text-muted-foreground" aria-hidden="true" />
            Score trend
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ScoreTrend points={profile.score_trend} />
        </CardContent>
      </Card>

      {scheduled.length > 0 ? (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Assigned interviews</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="divide-y">
              {scheduled.map((s) => (
                <li
                  key={s.id}
                  className="flex flex-wrap items-start justify-between gap-3 py-3 first:pt-0 last:pb-0"
                >
                  <div className="min-w-0 space-y-1">
                    <p className="font-medium">{s.role}</p>
                    <Notice>
                      {s.interview_type} · {s.difficulty} · {s.duration_minutes} min · opens{" "}
                      {formatDateTime(s.scheduled_for)}
                    </Notice>
                    {/* Admin-only, never shown to the candidate — the student
                        projection has no `notes` key at all. */}
                    {s.notes ? (
                      <p className="flex items-start gap-1.5 text-sm text-muted-foreground">
                        <StickyNote className="mt-0.5 size-3.5 shrink-0" aria-hidden="true" />
                        {s.notes}
                      </p>
                    ) : null}
                  </div>
                  <ScheduleBadge status={s.status} />
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      ) : null}

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Interview history</CardTitle>
        </CardHeader>
        <CardContent className={sessions.length === 0 ? undefined : "px-0"}>
          {sessions.length === 0 ? (
            <EmptyState title="No interviews yet">
              This candidate has not started an interview.
            </EmptyState>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead className="pl-6 text-xs uppercase tracking-wide">Date</TableHead>
                  <TableHead className="text-xs uppercase tracking-wide">Role</TableHead>
                  <TableHead className="text-xs uppercase tracking-wide">Duration</TableHead>
                  <TableHead className="text-right text-xs uppercase tracking-wide">Score</TableHead>
                  <TableHead className="text-xs uppercase tracking-wide">Status</TableHead>
                  <TableHead className="pr-6" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {sessions.map((session) => (
                  <TableRow key={session.session_id}>
                    <TableCell className="whitespace-nowrap pl-6">
                      {formatDate(session.started_at)}
                    </TableCell>
                    <TableCell>{session.role}</TableCell>
                    <TableCell className="whitespace-nowrap">
                      {formatDuration(session.duration_minutes)}
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-right font-mono tabular-nums">
                      {formatScore(session.overall_score)}
                    </TableCell>
                    <TableCell>
                      <SessionStatusBadge status={session.status} />
                    </TableCell>
                    <TableCell className="pr-6">
                      {session.has_report ? (
                        <span className="flex justify-end gap-1.5">
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            aria-expanded={openSession === session.session_id}
                            onClick={() => void openReportFor(session.session_id)}
                          >
                            {openSession === session.session_id ? (
                              <EyeOff aria-hidden="true" />
                            ) : (
                              <Eye aria-hidden="true" />
                            )}
                            {openSession === session.session_id ? "Hide" : "View"}
                          </Button>
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() =>
                              download(
                                `/admin/reports/${session.session_id}/download`,
                                `report-${session.session_id}.json`,
                              )
                            }
                          >
                            <Download aria-hidden="true" />
                            <span className="sr-only sm:not-sr-only">Download</span>
                          </Button>
                        </span>
                      ) : (
                        <span className="block text-right text-sm text-muted-foreground">
                          No report
                        </span>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {openSession ? (
        <section className="space-y-3">
          <SectionTitle>
            Report — {formatDate(sessions.find((s) => s.session_id === openSession)?.started_at ?? null)}
          </SectionTitle>
          {reportError ? <InlineError>{reportError}</InlineError> : null}
          {!openReport && !reportError ? (
            <Card>
              <CardContent className="space-y-3">
                <Skeleton className="h-4 w-2/3" />
                <Skeleton className="h-4 w-1/2" />
                <Skeleton className="h-24 w-full" />
              </CardContent>
            </Card>
          ) : null}
          {/* The candidate's own renderer, in admin phrasing. Same fields, same
              component — see the note at the top of this file. */}
          {openReport ? <ReportView report={openReport} audience="admin" /> : null}
        </section>
      ) : null}
    </WidePage>
  );
}

function BackLink() {
  return (
    <Link
      href="/admin/users"
      className="inline-flex w-fit items-center gap-1 text-sm text-muted-foreground outline-none transition-colors hover:text-foreground focus-visible:ring-[3px] focus-visible:ring-ring/50"
    >
      <ChevronLeft className="size-4" aria-hidden="true" />
      Candidates
    </Link>
  );
}

"use client";

/**
 * Admin User Directory — `ADMIN_FEATURE_PROMPT.md` Part 1.
 *
 * Every candidate account with aggregate stats. Search, filters, sorting and
 * paging are all server-side: the page holds one page of rows and asks the
 * gateway again when the query changes, so the browser never sees the whole
 * cohort and the numbers cannot drift from what the gateway computed.
 *
 * Nothing rendered here comes from outside a candidate's `Report` or their own
 * account record — the row type has no field for a resume, audio, or a
 * transcript (soul.md §"Admin role").
 */

import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { ArrowDown, ArrowUp, CalendarPlus, RotateCcw, Search, Users, X } from "lucide-react";
import {
  api,
  auth,
  ApiCallError,
  type DirectoryQuery,
  type DirectoryResponse,
  type DirectoryRow,
} from "@/lib/api";
import { formatDate, formatScore } from "@/lib/format";
import { EmptyState, InlineError, Notice, PageHeader, WidePage } from "@/app/components/shell";
import { AdminNav } from "../nav";
import { Identity, StatusBadge } from "../ui";
import { Badge } from "@/app/components/ui/badge";
import { Button } from "@/app/components/ui/button";
import { Checkbox } from "@/app/components/ui/checkbox";
import { Input } from "@/app/components/ui/input";
import { Label } from "@/app/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/app/components/ui/select";
import { Skeleton } from "@/app/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/app/components/ui/table";
import { cn } from "@/lib/utils";

const COLUMNS: {
  key: string;
  label: string;
  sortable: boolean;
  numeric?: boolean;
  className?: string;
}[] = [
  { key: "fullName", label: "Candidate", sortable: true },
  { key: "department", label: "Department", sortable: true },
  { key: "interviewsCompleted", label: "Interviews", sortable: true, numeric: true },
  { key: "averageScore", label: "Avg score", sortable: true, numeric: true },
  { key: "lastInterviewAt", label: "Last interview", sortable: true },
  { key: "createdAt", label: "Joined", sortable: true },
  { key: "status", label: "Status", sortable: false },
];

const EMPTY_QUERY: DirectoryQuery = { page: 1, page_size: 25, sort: "createdAt", direction: "desc" };

/** The Select primitive cannot hold "" as a value, so "all" stands in for "no filter". */
const ALL = "all";

export default function AdminUsersPage() {
  const router = useRouter();
  const [query, setQuery] = useState<DirectoryQuery>(EMPTY_QUERY);
  /** The search box, debounced separately so typing does not fire a request per keystroke. */
  const [searchInput, setSearchInput] = useState("");
  const [data, setData] = useState<DirectoryResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<Set<string>>(new Set());

  useEffect(() => {
    if (auth.role() === "student") {
      router.replace("/home");
      return;
    }
    if (!auth.token()) router.replace("/");
  }, [router]);

  useEffect(() => {
    const timer = setTimeout(() => {
      // Any change to the search resets to page 1 — staying on page 4 of a
      // result set that now has one page shows an empty table.
      setQuery((q) => ({ ...q, search: searchInput || undefined, page: 1 }));
    }, 250);
    return () => clearTimeout(timer);
  }, [searchInput]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    api
      .adminUsers(query)
      .then((result) => {
        if (cancelled) return;
        setData(result);
        setError(null);
      })
      .catch((err) => {
        if (cancelled) return;
        setError(err instanceof ApiCallError ? err.message : "could not load the directory");
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [query]);

  const patch = useCallback((next: Partial<DirectoryQuery>) => {
    setQuery((q) => ({ ...q, ...next, page: next.page ?? 1 }));
  }, []);

  const toggleSort = useCallback((key: string) => {
    setQuery((q) => ({
      ...q,
      sort: key,
      // Clicking the active column flips direction; a new column starts
      // ascending, which is the least surprising default for a name.
      direction: q.sort === key && q.direction === "asc" ? "desc" : "asc",
      page: 1,
    }));
  }, []);

  const rows = data?.rows ?? [];
  const totalPages = data ? Math.max(1, Math.ceil(data.total / data.page_size)) : 1;

  const allSelected = rows.length > 0 && rows.every((r) => selected.has(r.user_id));
  const someSelected = rows.some((r) => selected.has(r.user_id));
  const toggleAll = () => {
    setSelected((prev) => {
      const next = new Set(prev);
      // Scoped to the visible page: "select all" silently selecting 300 people
      // an Admin cannot see is how a batch goes to the wrong cohort.
      if (allSelected) rows.forEach((r) => next.delete(r.user_id));
      else rows.forEach((r) => next.add(r.user_id));
      return next;
    });
  };

  const selectedIds = useMemo(() => [...selected], [selected]);
  const filtersActive =
    Boolean(query.search) ||
    Boolean(query.department) ||
    Boolean(query.status) ||
    query.min_score !== undefined ||
    query.max_score !== undefined ||
    Boolean(query.from);

  return (
    <WidePage>
      <PageHeader
        title="Candidates"
        lede="Every student account, with what their reports add up to. Select rows to schedule an interview for a group."
      />
      <AdminNav />

      {error ? <InlineError>{error}</InlineError> : null}

      {/* Filter bar. Every control here maps to a server-side query parameter —
          none of it filters the page already in the browser. */}
      <div className="flex flex-wrap items-end gap-3 rounded-xl border bg-card p-4">
        <div className="min-w-56 flex-1 space-y-1.5">
          <Label htmlFor="search" className="text-xs font-normal text-muted-foreground">
            Search
          </Label>
          <div className="relative">
            <Search
              className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
              aria-hidden="true"
            />
            <Input
              id="search"
              type="text"
              placeholder="Name or email"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              className="pl-8"
            />
          </div>
        </div>

        <div className="min-w-40 space-y-1.5">
          <Label htmlFor="dept" className="text-xs font-normal text-muted-foreground">
            Department
          </Label>
          <Select
            value={query.department ?? ALL}
            onValueChange={(value) => patch({ department: value === ALL ? undefined : value })}
          >
            <SelectTrigger id="dept" className="w-full">
              <SelectValue placeholder="All" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL}>All</SelectItem>
              {(data?.departments ?? []).map((d) => (
                <SelectItem key={d} value={d}>
                  {d}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="min-w-44 space-y-1.5">
          <Label htmlFor="status" className="text-xs font-normal text-muted-foreground">
            Status
          </Label>
          <Select
            value={query.status || ALL}
            onValueChange={(value) =>
              patch({ status: value === ALL ? undefined : (value as DirectoryQuery["status"]) })
            }
          >
            <SelectTrigger id="status" className="w-full">
              <SelectValue placeholder="All" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL}>All</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="interview_scheduled">Interview scheduled</SelectItem>
              <SelectItem value="no_activity">No activity</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="w-24 space-y-1.5">
          <Label htmlFor="minScore" className="text-xs font-normal text-muted-foreground">
            Min score
          </Label>
          <Input
            id="minScore"
            type="number"
            min={0}
            max={5}
            step={0.5}
            value={query.min_score ?? ""}
            onChange={(e) =>
              patch({ min_score: e.target.value === "" ? undefined : Number(e.target.value) })
            }
          />
        </div>

        <div className="w-24 space-y-1.5">
          <Label htmlFor="maxScore" className="text-xs font-normal text-muted-foreground">
            Max score
          </Label>
          <Input
            id="maxScore"
            type="number"
            min={0}
            max={5}
            step={0.5}
            value={query.max_score ?? ""}
            onChange={(e) =>
              patch({ max_score: e.target.value === "" ? undefined : Number(e.target.value) })
            }
          />
        </div>

        <div className="min-w-40 space-y-1.5">
          <Label htmlFor="from" className="text-xs font-normal text-muted-foreground">
            Interviewed after
          </Label>
          <Input
            id="from"
            type="date"
            value={query.from?.slice(0, 10) ?? ""}
            onChange={(e) =>
              patch({ from: e.target.value ? new Date(e.target.value).toISOString() : undefined })
            }
          />
        </div>

        <Button
          type="button"
          variant="ghost"
          size="sm"
          disabled={!filtersActive}
          onClick={() => {
            setSearchInput("");
            setQuery(EMPTY_QUERY);
          }}
        >
          <RotateCcw aria-hidden="true" />
          Reset
        </Button>
      </div>

      {/* Batch bar. Appears only with a selection, and states the count in words
          before offering the action — an Admin about to assign work to a group
          should see how big the group is. */}
      {selectedIds.length > 0 ? (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-primary/40 bg-primary/5 px-4 py-3">
          <span className="text-sm">
            <strong>{selectedIds.length}</strong> candidate{selectedIds.length === 1 ? "" : "s"}{" "}
            selected
          </span>
          <span className="flex flex-wrap items-center gap-2">
            <Button type="button" variant="ghost" size="sm" onClick={() => setSelected(new Set())}>
              <X aria-hidden="true" />
              Clear
            </Button>
            <Button asChild size="sm">
              <Link href={`/admin/schedule?candidates=${selectedIds.join(",")}`}>
                <CalendarPlus aria-hidden="true" />
                Schedule an interview
              </Link>
            </Button>
          </span>
        </div>
      ) : null}

      <div className="rounded-xl border bg-card shadow-sm">
        {/* containerClassName bounds the scroll container so the sticky header
            has something to stick to. See app/components/ui/table.tsx. */}
        <Table containerClassName="max-h-[65vh]">
          <TableHeader className="sticky top-0 z-10 bg-card">
            <TableRow className="hover:bg-transparent">
              <TableHead className="w-10">
                <Checkbox
                  aria-label="Select all on this page"
                  checked={allSelected ? true : someSelected ? "indeterminate" : false}
                  onCheckedChange={toggleAll}
                  disabled={rows.length === 0}
                />
              </TableHead>
              {COLUMNS.map((col) => {
                const active = query.sort === col.key;
                return (
                  <TableHead
                    key={col.key}
                    aria-sort={
                      active ? (query.direction === "asc" ? "ascending" : "descending") : "none"
                    }
                    className={cn(
                      "whitespace-nowrap text-xs uppercase tracking-wide",
                      col.numeric && "text-right",
                    )}
                  >
                    {col.sortable ? (
                      // A real button, so sorting is reachable by keyboard —
                      // the old implementation put onClick on the <th> itself.
                      <button
                        type="button"
                        onClick={() => toggleSort(col.key)}
                        className={cn(
                          "inline-flex items-center gap-1 rounded outline-none transition-colors hover:text-foreground focus-visible:ring-[3px] focus-visible:ring-ring/50",
                          active && "text-foreground",
                        )}
                      >
                        {col.label}
                        {active ? (
                          query.direction === "asc" ? (
                            <ArrowUp className="size-3 text-primary" aria-hidden="true" />
                          ) : (
                            <ArrowDown className="size-3 text-primary" aria-hidden="true" />
                          )
                        ) : null}
                      </button>
                    ) : (
                      col.label
                    )}
                  </TableHead>
                );
              })}
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading && !data
              ? Array.from({ length: 8 }).map((_, i) => (
                  <TableRow key={`skeleton-${i}`} className="hover:bg-transparent">
                    <TableCell colSpan={COLUMNS.length + 1}>
                      <Skeleton className="h-4" style={{ width: `${55 + (i % 4) * 11}%` }} />
                    </TableCell>
                  </TableRow>
                ))
              : rows.map((row) => (
                  <DirectoryTableRow
                    key={row.user_id}
                    row={row}
                    selected={selected}
                    setSelected={setSelected}
                  />
                ))}

            {!loading && rows.length === 0 ? (
              <TableRow className="hover:bg-transparent">
                <TableCell colSpan={COLUMNS.length + 1} className="p-0">
                  <EmptyState
                    icon={<Users />}
                    title={
                      data && data.total === 0 && !filtersActive
                        ? "No student accounts yet"
                        : "No candidates match these filters"
                    }
                    className="border-0"
                  >
                    {data && data.total === 0 && !filtersActive
                      ? "Accounts appear here as students sign up."
                      : "Try widening the score range or clearing the search."}
                  </EmptyState>
                </TableCell>
              </TableRow>
            ) : null}
          </TableBody>
        </Table>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <Notice>{data ? `Showing ${rows.length} of ${data.total} matching` : "…"}</Notice>
        <div className="flex items-center gap-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            disabled={(query.page ?? 1) <= 1}
            onClick={() => setQuery((q) => ({ ...q, page: (q.page ?? 1) - 1 }))}
          >
            Previous
          </Button>
          <Badge variant="muted" className="tabular-nums">
            Page {query.page ?? 1} of {totalPages}
          </Badge>
          <Button
            type="button"
            variant="outline"
            size="sm"
            disabled={(query.page ?? 1) >= totalPages}
            onClick={() => setQuery((q) => ({ ...q, page: (q.page ?? 1) + 1 }))}
          >
            Next
          </Button>
        </div>
      </div>
    </WidePage>
  );
}

function DirectoryTableRow({
  row,
  selected,
  setSelected,
}: {
  row: DirectoryRow;
  selected: Set<string>;
  setSelected: (fn: (prev: Set<string>) => Set<string>) => void;
}) {
  const router = useRouter();
  const toggle = () =>
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(row.user_id)) next.delete(row.user_id);
      else next.add(row.user_id);
      return next;
    });

  const open = () => router.push(`/admin/users/${row.user_id}`);
  const isSelected = selected.has(row.user_id);

  return (
    <TableRow
      className="cursor-pointer hover:bg-primary/[0.04]"
      data-state={isSelected ? "selected" : undefined}
      onClick={open}
      // The row was click-only before, so keyboard users had no way into a
      // profile from the table. Enter/Space on the focused row now opens it.
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          open();
        }
      }}
    >
      {/* The checkbox must not also open the profile. */}
      <TableCell onClick={(e) => e.stopPropagation()}>
        <Checkbox
          aria-label={`Select ${row.full_name ?? row.email}`}
          checked={isSelected}
          onCheckedChange={toggle}
        />
      </TableCell>
      <TableCell className="max-w-64">
        <Identity name={row.full_name} email={row.email} url={row.avatar_url} />
      </TableCell>
      <TableCell className="whitespace-nowrap">
        {row.department ?? <span className="text-muted-foreground">—</span>}
      </TableCell>
      <TableCell className="font-mono text-right tabular-nums">{row.interviews_completed}</TableCell>
      {/* formatScore, never `?? 0`: no reports is not a score of zero. */}
      <TableCell className="whitespace-nowrap text-right font-mono tabular-nums">
        {formatScore(row.average_score)}
      </TableCell>
      <TableCell className="whitespace-nowrap">{formatDate(row.last_interview_at)}</TableCell>
      <TableCell className="whitespace-nowrap">{formatDate(row.created_at)}</TableCell>
      <TableCell>
        <StatusBadge status={row.status} />
      </TableCell>
    </TableRow>
  );
}

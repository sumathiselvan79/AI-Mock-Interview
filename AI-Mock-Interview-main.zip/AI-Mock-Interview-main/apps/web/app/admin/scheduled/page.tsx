"use client";

/**
 * Scheduled Interviews — the admin list of everything assigned, with cancel.
 *
 * `status` here is the gateway's DERIVED status: `sent` and `missed` are
 * computed from the clock at read time rather than written by a job, so this
 * list never shows a "pending" interview whose deadline passed last week
 * (`packages/shared-types/src/scheduling.ts` `effectiveStatus`).
 */

import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { CalendarPlus, CalendarX, Code2, Loader2 } from "lucide-react";
import { api, auth, ApiCallError, type AdminSchedule } from "@/lib/api";
import { formatDateTime } from "@/lib/format";
import { EmptyState, InlineError, Notice, PageHeader, WidePage } from "@/app/components/shell";
import { AdminNav } from "../nav";
import { ScheduleBadge } from "../ui";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/app/components/ui/alert-dialog";
import { Button } from "@/app/components/ui/button";
import { Skeleton } from "@/app/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/app/components/ui/table";

const OPEN_STATUSES = new Set(["pending", "sent"]);

export default function ScheduledInterviewsPage() {
  const router = useRouter();
  const [schedules, setSchedules] = useState<AdminSchedule[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [showAll, setShowAll] = useState(false);

  useEffect(() => {
    if (auth.role() === "student") {
      router.replace("/home");
      return;
    }
    if (!auth.token()) router.replace("/");
  }, [router]);

  const load = useCallback(() => {
    api
      .adminScheduled()
      .then((result) => setSchedules(result.scheduled))
      .catch((err) =>
        setError(err instanceof ApiCallError ? err.message : "could not load scheduled interviews"),
      );
  }, []);

  useEffect(load, [load]);

  const cancel = async (id: string) => {
    setBusy(id);
    setError(null);
    try {
      await api.adminCancelSchedule(id);
      load();
    } catch (err) {
      setError(err instanceof ApiCallError ? err.message : "could not cancel that interview");
    } finally {
      setBusy(null);
    }
  };

  // Upcoming first by default: a finished or withdrawn assignment is history,
  // and burying the live ones under it is what makes this screen useless.
  const visible = useMemo(() => {
    if (!schedules) return [];
    return showAll ? schedules : schedules.filter((s) => OPEN_STATUSES.has(s.status));
  }, [schedules, showAll]);

  return (
    <WidePage>
      <PageHeader
        title="Scheduled interviews"
        lede="Everything assigned, and what became of it."
        actions={
          <Button asChild size="sm">
            <Link href="/admin/schedule">
              <CalendarPlus aria-hidden="true" />
              Schedule an interview
            </Link>
          </Button>
        }
      />
      <AdminNav />

      {error ? <InlineError>{error}</InlineError> : null}

      <div className="flex flex-wrap items-center gap-3">
        <Button type="button" variant="outline" size="sm" onClick={() => setShowAll(!showAll)}>
          {showAll ? "Show only upcoming" : "Show all, including finished"}
        </Button>
        {schedules ? (
          <Notice>
            {visible.length} of {schedules.length}
          </Notice>
        ) : null}
      </div>

      <div className="rounded-xl border bg-card shadow-sm">
        <Table>
          <TableHeader>
            <TableRow className="hover:bg-transparent">
              <TableHead className="pl-4 text-xs uppercase tracking-wide">Candidate</TableHead>
              <TableHead className="text-xs uppercase tracking-wide">Role</TableHead>
              <TableHead className="text-xs uppercase tracking-wide">Type</TableHead>
              <TableHead className="text-xs uppercase tracking-wide">Opens</TableHead>
              <TableHead className="text-xs uppercase tracking-wide">Deadline</TableHead>
              <TableHead className="text-xs uppercase tracking-wide">Status</TableHead>
              <TableHead className="pr-4" />
            </TableRow>
          </TableHeader>
          <TableBody>
            {!schedules
              ? Array.from({ length: 4 }).map((_, i) => (
                  <TableRow key={`s-${i}`} className="hover:bg-transparent">
                    <TableCell colSpan={7} className="pl-4">
                      <Skeleton className="h-4" style={{ width: `${55 + (i % 3) * 10}%` }} />
                    </TableCell>
                  </TableRow>
                ))
              : visible.map((s) => (
                  <TableRow key={s.id}>
                    <TableCell className="pl-4">
                      <Link
                        href={`/admin/users/${s.candidate_id}`}
                        className="font-medium text-primary underline-offset-4 outline-none hover:underline focus-visible:ring-[3px] focus-visible:ring-ring/50"
                      >
                        {s.candidate_name ?? s.candidate_email ?? s.candidate_id}
                      </Link>
                      {s.department ? (
                        <span className="block text-xs text-muted-foreground">{s.department}</span>
                      ) : null}
                    </TableCell>
                    <TableCell>{s.role}</TableCell>
                    <TableCell>
                      <span className="block">{s.interview_type}</span>
                      <span className="flex items-center gap-1 text-xs text-muted-foreground">
                        {s.difficulty} · {s.duration_minutes} min
                        {s.coding_round_enabled ? (
                          <>
                            {" · "}
                            <Code2 className="size-3" aria-hidden="true" />
                            coding
                          </>
                        ) : null}
                      </span>
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      {formatDateTime(s.scheduled_for)}
                    </TableCell>
                    <TableCell className="whitespace-nowrap">{formatDateTime(s.deadline)}</TableCell>
                    <TableCell>
                      <ScheduleBadge status={s.status} />
                    </TableCell>
                    <TableCell className="pr-4 text-right">
                      {OPEN_STATUSES.has(s.status) ? (
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button type="button" variant="ghost" size="sm" disabled={busy === s.id}>
                              {busy === s.id ? (
                                <Loader2 className="animate-spin" aria-hidden="true" />
                              ) : (
                                <CalendarX aria-hidden="true" />
                              )}
                              {busy === s.id ? "Cancelling…" : "Cancel"}
                            </Button>
                          </AlertDialogTrigger>
                          {/*
                            Withdrawing work assigned to a named student is not
                            an undo-able click — the same reasoning that put a
                            confirmation in front of creating one.
                          */}
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Cancel this interview?</AlertDialogTitle>
                              <AlertDialogDescription>
                                The <strong>{s.role}</strong> interview assigned to{" "}
                                <strong>{s.candidate_name ?? s.candidate_email ?? "this candidate"}</strong>{" "}
                                will be withdrawn and will stop appearing on their home page. This
                                cannot be undone — you would have to schedule a new one.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Keep it</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => void cancel(s.id)}
                                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                              >
                                Cancel the interview
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      ) : (
                        <span className="text-sm text-muted-foreground">—</span>
                      )}
                    </TableCell>
                  </TableRow>
                ))}

            {schedules && visible.length === 0 ? (
              <TableRow className="hover:bg-transparent">
                <TableCell colSpan={7} className="p-0">
                  <EmptyState
                    icon={<CalendarX />}
                    title={schedules.length === 0 ? "Nothing scheduled yet" : "No upcoming interviews"}
                    className="border-0"
                  >
                    {schedules.length === 0
                      ? "Assign one from a candidate's profile or the directory."
                      : "Everything assigned has been started, finished or withdrawn."}
                  </EmptyState>
                </TableCell>
              </TableRow>
            ) : null}
          </TableBody>
        </Table>
      </div>
    </WidePage>
  );
}

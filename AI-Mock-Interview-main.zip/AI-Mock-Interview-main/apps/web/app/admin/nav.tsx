"use client";

/**
 * The admin section's own nav.
 *
 * The four admin pages each hand-rolled their own set of links to the other
 * three, and they had already stopped agreeing — the dashboard offered
 * "Scheduled" and "Candidates", the directory offered only "Scheduled
 * interviews", and the profile page offered neither. One component, so there is
 * one answer to "where else can I go from here".
 */

import Link from "next/link";
import { usePathname } from "next/navigation";
import { CalendarClock, FileBarChart, Users } from "lucide-react";
import { cn } from "@/lib/utils";

const LINKS = [
  { href: "/admin", label: "Reports", Icon: FileBarChart },
  { href: "/admin/users", label: "Candidates", Icon: Users },
  { href: "/admin/scheduled", label: "Scheduled", Icon: CalendarClock },
] as const;

export function AdminNav() {
  const pathname = usePathname();

  return (
    <nav aria-label="Admin sections" className="w-fit rounded-full border bg-card/60 p-1">
      <ul className="flex flex-wrap gap-1">
        {LINKS.map(({ href, label, Icon }) => {
          // `/admin` must not light up for `/admin/users`; everything deeper
          // than its own segment should, so a profile page still shows
          // "Candidates" as current.
          const active = href === "/admin" ? pathname === "/admin" : pathname.startsWith(href);
          return (
            <li key={href}>
              <Link
                href={href}
                aria-current={active ? "page" : undefined}
                className={cn(
                  "flex items-center gap-2 rounded-full px-3.5 py-1.5 text-sm transition-colors outline-none",
                  "focus-visible:ring-[3px] focus-visible:ring-ring/50",
                  active
                    ? "bg-primary text-primary-foreground font-medium shadow-glow"
                    : "text-muted-foreground hover:bg-accent hover:text-foreground",
                )}
              >
                <Icon className="size-4" aria-hidden="true" />
                {label}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}

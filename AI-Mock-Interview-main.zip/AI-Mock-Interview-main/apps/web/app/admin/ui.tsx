"use client";

/**
 * (Stage 7, rebuilt in Stage 8) Small presentational pieces shared by the admin
 * pages, now on shadcn/ui primitives instead of the hand-rolled CSS this file
 * used to carry.
 *
 * The visual layer changed; none of the product rules did. Each one is written
 * out again next to the code that implements it, because these are the rules a
 * future redesign is most likely to "tidy away":
 *
 *  - a null score renders `—`, never `0`
 *  - a candidate with no avatar gets initials, never a broken image
 *  - a status is never colour-alone: every badge carries an icon and a word
 *
 * The score-trend chart deliberately does NOT live here — see
 * `app/admin/score-trend.tsx` for why. Keep this file free of chart imports:
 * three chartless pages import the badges below, and anything Recharts touches
 * lands in all of their bundles.
 */

import {
  CalendarClock,
  CheckCircle2,
  CircleDashed,
  CircleSlash,
  Clock,
  PlayCircle,
  XCircle,
} from "lucide-react";
import type { ComponentType } from "react";

import type { DirectoryStatus } from "@/lib/api";
import {
  Avatar as AvatarRoot,
  AvatarFallback,
  AvatarImage,
} from "@/app/components/ui/avatar";
import { StatusPill, type Tone } from "@/app/components/shell";
import { cn } from "@/lib/utils";

/** Initials, so a candidate with no Google avatar gets a real element not a broken image. */
function initialsOf(name: string | null, email: string): string {
  const source = (name ?? "").trim();
  if (source) {
    const parts = source.split(/\s+/);
    return (
      (parts[0]?.[0] ?? "") + (parts.length > 1 ? (parts[parts.length - 1]?.[0] ?? "") : "")
    ).toUpperCase();
  }
  return (email[0] ?? "?").toUpperCase();
}

/**
 * `size` stays a number of rem rather than becoming shadcn's `sm|default|lg`:
 * existing callers pass 1.6, 2 and 3, and the schedule form's 1.6 is not one of
 * the three named sizes. Radix's Avatar handles the image-failed case itself, so
 * the fallback is now structural rather than a branch here.
 */
export function Avatar({
  name,
  email,
  url,
  size = 2,
  className,
}: {
  name: string | null;
  email: string;
  url: string | null;
  size?: number;
  className?: string;
}) {
  return (
    <AvatarRoot
      className={cn("shrink-0 border bg-primary/15", className)}
      style={{ width: `${size}rem`, height: `${size}rem` }}
    >
      {url ? <AvatarImage src={url} alt="" referrerPolicy="no-referrer" /> : null}
      <AvatarFallback
        className="bg-transparent font-semibold text-primary"
        style={{ fontSize: `${Math.max(0.6, size * 0.36)}rem` }}
      >
        {initialsOf(name, email)}
      </AvatarFallback>
    </AvatarRoot>
  );
}

/** Avatar + name-over-email, the pairing every admin table row uses. */
export function Identity({
  name,
  email,
  url,
  size = 2,
  meta,
}: {
  name: string | null;
  email: string;
  url: string | null;
  size?: number;
  meta?: string | null;
}) {
  return (
    <span className="flex min-w-0 items-center gap-2.5">
      <Avatar name={name} email={email} url={url} size={size} />
      <span className="min-w-0">
        <span className="block truncate font-medium">{name ?? "—"}</span>
        <span className="block truncate text-xs text-muted-foreground">
          {email}
          {meta ? ` · ${meta}` : ""}
        </span>
      </span>
    </span>
  );
}

/**
 * Status badges.
 *
 * `StatusPill` (imported above) carries the rule these all rely on: the icon is
 * not decoration. Colour alone is not an accessible status signal, and these
 * three tones (`--ok`, `--warn`, `--muted`) are deliberately close in value so
 * a table stays quiet.
 */
const STATUS_COPY: Record<
  DirectoryStatus,
  { label: string; tone: Tone; Icon: ComponentType<{ className?: string }> }
> = {
  active: { label: "Active", tone: "ok", Icon: CheckCircle2 },
  interview_scheduled: { label: "Interview scheduled", tone: "warn", Icon: CalendarClock },
  no_activity: { label: "No activity", tone: "muted", Icon: CircleDashed },
};

export function StatusBadge({ status }: { status: DirectoryStatus }) {
  const copy = STATUS_COPY[status] ?? { label: status, tone: "muted" as Tone, Icon: CircleDashed };
  return <StatusPill tone={copy.tone} label={copy.label} Icon={copy.Icon} />;
}

const SCHEDULE_COPY: Record<
  string,
  { tone: Tone; Icon: ComponentType<{ className?: string }> }
> = {
  pending: { tone: "muted", Icon: Clock },
  sent: { tone: "warn", Icon: CalendarClock },
  started: { tone: "warn", Icon: PlayCircle },
  completed: { tone: "ok", Icon: CheckCircle2 },
  missed: { tone: "warn", Icon: XCircle },
  cancelled: { tone: "muted", Icon: CircleSlash },
};

export function ScheduleBadge({ status }: { status: string }) {
  const copy = SCHEDULE_COPY[status] ?? { tone: "muted" as Tone, Icon: CircleDashed };
  return <StatusPill tone={copy.tone} label={status.replace("_", " ")} Icon={copy.Icon} />;
}

/**
 * Two sets of shared pieces moved out of this file and are re-exported here, so
 * every existing `from "../ui"` import keeps working.
 *
 * The formatters went to `lib/format.ts`; `SessionStatusBadge` went to
 * `app/components/shell.tsx` when the Student Home page grew its own interview
 * history. Neither was ever admin-specific — a candidate reads the same three
 * session states and needs the same null-score rule (null renders `—`, never
 * `0`, soul.md §"No fabrication"). Until Stage 8 the Student Home page carried
 * its own inline copy of that rule, and it is exactly the copy that drifts.
 */
export { SessionStatusBadge } from "@/app/components/shell";

export {
  formatDate,
  formatDateTime,
  formatDuration,
  formatScore,
  formatScoreValue,
} from "@/lib/format";

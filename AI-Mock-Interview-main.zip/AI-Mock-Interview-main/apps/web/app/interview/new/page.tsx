"use client";

/**
 * Step one of the Interview Config page: the role and job description a session
 * is created with (INSTRUCTIONS.md §3.1, §7 `POST /sessions`).
 */

import { useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { ArrowRight, Briefcase, FileText, Loader2 } from "lucide-react";
import { api, ApiCallError } from "@/lib/api";
import { InlineError, Notice, Page, PageHeader } from "@/app/components/shell";
import { InterviewSteps } from "@/app/components/interview-steps";
import { useReveal } from "@/lib/motion";
import { Button } from "@/app/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/app/components/ui/card";
import { Input } from "@/app/components/ui/input";
import { Label } from "@/app/components/ui/label";
import { Textarea } from "@/app/components/ui/textarea";

export default function NewInterviewPage() {
  const router = useRouter();
  const formRef = useReveal<HTMLFormElement>({ y: 16, stagger: 0.1, start: "top 92%" });
  const [role, setRole] = useState("");
  const [jobDescription, setJobDescription] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const { session_id: sessionId } = await api.createSession(role, jobDescription);
      router.push(`/interview/${sessionId}/config`);
    } catch (err) {
      setError(err instanceof ApiCallError ? err.message : "could not start a session");
      setBusy(false);
    }
  }

  return (
    <Page>
      <InterviewSteps current="role" />
      <PageHeader
        title="New interview"
        lede="Tell us the role you are practising for. The job description is optional, but it shapes what the interview focuses on."
      />

      {error ? <InlineError>{error}</InlineError> : null}

      <form ref={formRef} onSubmit={onSubmit} className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Briefcase className="size-4 text-muted-foreground" aria-hidden="true" />
              Target role
            </CardTitle>
            <CardDescription>
              The one thing that is required — every question is calibrated against it.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            <Label htmlFor="role" className="sr-only">
              Target role
            </Label>
            <Input
              id="role"
              type="text"
              value={role}
              onChange={(e) => setRole(e.target.value)}
              placeholder="Senior Backend Engineer"
              required
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <FileText className="size-4 text-muted-foreground" aria-hidden="true" />
              Job description
              <span className="text-sm font-normal text-muted-foreground">(optional)</span>
            </CardTitle>
            <CardDescription>
              Paste the posting and the next step can show you which of its requirements your resume
              already covers.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            <Label htmlFor="jd" className="sr-only">
              Job description
            </Label>
            <Textarea
              id="jd"
              value={jobDescription}
              onChange={(e) => setJobDescription(e.target.value)}
              placeholder="Paste the job posting here."
              className="min-h-40"
            />
            <Notice>Skip it and the interview is calibrated from the role alone.</Notice>
          </CardContent>
        </Card>

        <div className="flex flex-wrap items-center gap-3">
          <Button type="submit" size="lg" disabled={busy}>
            {busy ? <Loader2 className="animate-spin" aria-hidden="true" /> : null}
            {busy ? "Setting up…" : "Continue"}
            {busy ? null : <ArrowRight aria-hidden="true" />}
          </Button>
          <Notice>Next: upload your resume.</Notice>
        </div>
      </form>
    </Page>
  );
}

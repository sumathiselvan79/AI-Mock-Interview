"use client";

/**
 * Interview Config page — CONFIG state, owned by the Resume Service Agent
 * (INSTRUCTIONS.md §3.1).
 *
 * Resume upload, resume delete, and the JD-fit result. Two rules from soul.md
 * are visible in the copy here, not just in the backend:
 *
 *  - JD fit is informational: it never blocks starting, and it is phrased as
 *    "expect more questions here", never as a verdict on whether the candidate
 *    is qualified (soul.md §3). Note the Continue button is never disabled by
 *    the fit score, and there is deliberately no red/green "pass" treatment on
 *    the percentage — it is a coverage number, not a grade.
 *  - Delete means delete: the button says the file is removed, and the backend
 *    hard-deletes it and verifies it is gone before reporting success (§8). The
 *    confirmation step exists because that is irreversible, not because the
 *    system is unsure.
 */

import { useCallback, useEffect, useRef, useState, type DragEvent } from "react";
import { useParams } from "next/navigation";
import {
  ArrowRight,
  CheckCircle2,
  CircleHelp,
  FileText,
  Loader2,
  Target,
  Trash2,
  Upload,
} from "lucide-react";
import {
  api,
  readFileAsBase64,
  ApiCallError,
  type JdFit,
} from "@/lib/api";
import {
  InlineError,
  Notice,
  Page,
  PageHeader,
  ScoreMeter,
} from "@/app/components/shell";
import { InterviewSteps } from "@/app/components/interview-steps";
import { useReveal } from "@/lib/motion";
import {
  Alert,
  AlertDescription,
  AlertTitle,
} from "@/app/components/ui/alert";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/app/components/ui/alert-dialog";
import { Badge } from "@/app/components/ui/badge";
import { Button } from "@/app/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/app/components/ui/card";
import { Separator } from "@/app/components/ui/separator";
import { cn } from "@/lib/utils";

const ACCEPTED = ".pdf,.docx,.txt,.md";

export default function InterviewConfigPage() {
  const params = useParams<{ id: string }>();
  const sessionId = params.id;
  const stackRef = useReveal<HTMLDivElement>({ y: 16, start: "top 92%" });

  const [jdFit, setJdFit] = useState<JdFit | null>(null);
  const [seniority, setSeniority] = useState<string | null>(null);
  const [hasResume, setHasResume] = useState(false);
  /** Known only for a file uploaded in THIS visit — the session record keeps a ref, not a name. */
  const [uploadedName, setUploadedName] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [advancing, setAdvancing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const busy = uploading || deleting || advancing;

  const refresh = useCallback(async () => {
    try {
      const [fit, session] = await Promise.all([api.jdFit(sessionId), api.getSession(sessionId)]);
      setJdFit(fit.jd_fit);
      setSeniority(fit.seniority_estimate);
      setHasResume(Boolean(session.session.resumeRef));
    } catch (err) {
      setError(err instanceof ApiCallError ? err.message : "could not load this session");
    }
  }, [sessionId]);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  async function onUpload(file: File) {
    setUploading(true);
    setError(null);
    setNotice(null);
    try {
      const result = await api.uploadResume(sessionId, {
        filename: file.name,
        contentType: file.type || "application/octet-stream",
        dataBase64: await readFileAsBase64(file),
      });
      setJdFit(result.jd_fit);
      setHasResume(true);
      setUploadedName(file.name);
      await refresh();
    } catch (err) {
      // Parse failures are surfaced as they are: an honest "that didn't work"
      // beats a plausible-sounding profile (soul.md §6).
      setError(err instanceof ApiCallError ? err.message : "could not read that file");
    } finally {
      setUploading(false);
    }
  }

  async function onDelete() {
    setDeleting(true);
    setError(null);
    try {
      await api.deleteResume(sessionId);
      setHasResume(false);
      setUploadedName(null);
      setNotice("Your resume file has been deleted from our storage.");
      await refresh();
    } catch (err) {
      setError(err instanceof ApiCallError ? err.message : "could not delete that file");
    } finally {
      setDeleting(false);
    }
  }

  async function onContinue() {
    setAdvancing(true);
    setError(null);
    try {
      // CREATED -> CONFIG -> TELEMETRY_CHECK, driven by the harness.
      await api.advance(sessionId, "CONFIG").catch(() => undefined);
      await api.advance(sessionId, "TELEMETRY_CHECK");
      window.location.href = `/interview/${sessionId}/telemetry-check`;
    } catch (err) {
      setError(err instanceof ApiCallError ? err.message : "could not continue");
      setAdvancing(false);
    }
  }

  return (
    <Page>
      <InterviewSteps current="resume" />
      <PageHeader
        title="Set up your interview"
        lede="Upload your resume so the questions are grounded in what you have actually worked on."
      />

      {error ? <InlineError>{error}</InlineError> : null}
      {notice ? (
        <Alert variant="muted">
          <CheckCircle2 aria-hidden="true" />
          <AlertDescription>{notice}</AlertDescription>
        </Alert>
      ) : null}

      <div ref={stackRef} className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Resume</CardTitle>
            <CardDescription>
              Used to tailor this session, and deleted when the session is over unless you ask us to
              keep it.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ResumeField
              hasResume={hasResume}
              uploadedName={uploadedName}
              seniority={seniority}
              uploading={uploading}
              deleting={deleting}
              onUpload={onUpload}
              onDelete={onDelete}
            />
          </CardContent>
        </Card>

        {jdFit ? <JdFitBlock fit={jdFit} /> : null}

        <Card className="border-primary/25 bg-gradient-to-br from-primary/[0.05] via-card to-card">
          <CardHeader>
            <CardTitle className="text-base">Next</CardTitle>
            <CardDescription>
              The device and consent check comes next, then the interview itself.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-wrap items-center gap-3">
            <Button type="button" size="lg" onClick={onContinue} disabled={busy}>
              {advancing ? <Loader2 className="animate-spin" aria-hidden="true" /> : null}
              {advancing ? "Continuing…" : "Continue to the device check"}
              {advancing ? null : <ArrowRight aria-hidden="true" />}
            </Button>
            {/* soul.md §3: the fit score never gates this button, and the copy has
                to say so where the candidate can see the score. */}
            <Notice>You can start whatever your fit score says.</Notice>
          </CardContent>
        </Card>
      </div>
    </Page>
  );
}

/**
 * The resume upload surface, in four states: empty, receiving a drag, uploading,
 * and holding a file.
 *
 * A real drop target rather than a bare `<input type="file">` — a resume is the
 * one file this app ever asks for, and dragging it in is how people move a
 * document. The input is still there underneath and still reachable by keyboard;
 * the drop zone is an enhancement on top, not a replacement.
 */
function ResumeField({
  hasResume,
  uploadedName,
  seniority,
  uploading,
  deleting,
  onUpload,
  onDelete,
}: {
  hasResume: boolean;
  uploadedName: string | null;
  seniority: string | null;
  uploading: boolean;
  deleting: boolean;
  onUpload: (file: File) => void | Promise<void>;
  onDelete: () => void | Promise<void>;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);

  const take = (files: FileList | null) => {
    const file = files?.[0];
    if (file) void onUpload(file);
  };

  const onDrop = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setDragging(false);
    take(event.dataTransfer.files);
  };

  if (uploading) {
    return (
      <div className="flex items-center gap-3 rounded-lg border border-dashed px-4 py-8">
        <Loader2 className="size-5 shrink-0 animate-spin text-primary" aria-hidden="true" />
        <div role="status" aria-live="polite">
          <p className="font-medium">Reading your resume…</p>
          <Notice>Extracting your resume's profile. This takes a few seconds.</Notice>
        </div>
      </div>
    );
  }

  if (hasResume) {
    return (
      <div className="space-y-3">
        <div className="flex flex-wrap items-center gap-3 rounded-lg border bg-muted/40 px-4 py-3">
          <FileText className="size-5 shrink-0 text-muted-foreground" aria-hidden="true" />
          <div className="min-w-0 flex-1">
            <p className="truncate font-medium">{uploadedName ?? "Resume on file"}</p>
            <Notice>
              {seniority ? `Read as ${seniority} level.` : "Uploaded and parsed."}
            </Notice>
          </div>
          <Badge variant="ok">
            <CheckCircle2 aria-hidden="true" />
            Uploaded
          </Badge>
        </div>

        <div className="flex flex-wrap gap-2">
          {/* Replace is upload-again; the backend overwrites the ref. */}
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => inputRef.current?.click()}
            disabled={deleting}
          >
            <Upload aria-hidden="true" />
            Replace
          </Button>

          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button type="button" variant="outline" size="sm" disabled={deleting}>
                {deleting ? (
                  <Loader2 className="animate-spin" aria-hidden="true" />
                ) : (
                  <Trash2 aria-hidden="true" />
                )}
                {deleting ? "Deleting…" : "Delete"}
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Delete your resume file?</AlertDialogTitle>
                <AlertDialogDescription>
                  This removes the file from our storage for good — it is a hard delete, not a flag,
                  and it cannot be undone. The interview will still run; the questions just will not
                  be grounded in your own experience. You can upload it again afterwards.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Keep it</AlertDialogCancel>
                <AlertDialogAction
                  onClick={() => void onDelete()}
                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                >
                  Delete it
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>

        <input
          ref={inputRef}
          id="resume"
          type="file"
          accept={ACCEPTED}
          className="hidden"
          onChange={(e) => take(e.target.files)}
        />
      </div>
    );
  }

  return (
    <div
      onDragOver={(e) => {
        e.preventDefault();
        setDragging(true);
      }}
      onDragLeave={() => setDragging(false)}
      onDrop={onDrop}
      className={cn(
        "rounded-xl border-2 border-dashed px-4 py-10 text-center transition-[border-color,background-color,box-shadow] duration-300",
        dragging
          ? "border-primary bg-primary/5 shadow-glow"
          : "hover:border-muted-foreground/40 hover:bg-muted/20",
      )}
    >
      <Upload
        className={cn(
          "mx-auto size-7 transition-transform duration-300",
          dragging ? "-translate-y-0.5 text-primary" : "text-muted-foreground",
        )}
        aria-hidden="true"
      />
      <p className="mt-2 font-medium">
        {dragging ? "Drop it here" : "Drag your resume here"}
      </p>
      <Notice className="mt-1">PDF, DOCX, TXT or MD.</Notice>
      {/* A real label bound to a real file input: the keyboard path and the
          screen-reader path both go through this, not through the drop zone. */}
      <Button asChild variant="outline" size="sm" className="mt-3">
        <label htmlFor="resume" className="cursor-pointer">Choose a file</label>
      </Button>
      <input
        ref={inputRef}
        id="resume"
        type="file"
        accept={ACCEPTED}
        className="sr-only"
        onChange={(e) => take(e.target.files)}
      />
    </div>
  );
}

/**
 * The JD-fit verdict.
 *
 * Deliberately NOT colour-graded. A 40% coverage number tinted red would read as
 * "you are not qualified", which is exactly the reading soul.md §3 forbids — the
 * number means "expect more questions in these areas". So the meter is the
 * neutral brand colour at any value, the matched and missing lists are given
 * equal visual weight, and the sentence explaining what the number is not sits
 * above both.
 */
function JdFitBlock({ fit }: { fit: JdFit }) {
  const pct = Math.round(fit.fit_score * 100);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <Target className="size-4 text-muted-foreground" aria-hidden="true" />
          What this interview will focus on
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="space-y-2">
          <div className="flex items-baseline justify-between gap-3">
            <span className="text-sm text-muted-foreground">
              Job-description coverage from your resume
            </span>
            <span className="font-mono text-3xl font-semibold tabular-nums">{pct}%</span>
          </div>
          <ScoreMeter
            score={pct}
            max={100}
            label={`Resume covers ${pct}% of this job description`}
          />
          <Notice>
            A lower number means expect more questions in the areas below — it is not a judgement on
            whether you should apply.
          </Notice>
        </div>

        {/* (Stage 5) The grounded explanation. Absent when the provider was
            unavailable or the claim failed the grounding check, in which case
            nothing is shown rather than something invented. */}
        {fit.rationale ? (
          <Alert variant="muted">
            <CircleHelp aria-hidden="true" />
            <AlertDescription>{fit.rationale}</AlertDescription>
          </Alert>
        ) : null}

        {fit.matched_requirements.length > 0 || fit.gaps.length > 0 ? (
          <>
            <Separator />
            <div className="grid gap-6 sm:grid-cols-2">
              {fit.matched_requirements.length > 0 ? (
                <div className="space-y-2">
                  <h3 className="text-sm font-semibold">Your resume already covers</h3>
                  <ul className="space-y-1.5">
                    {fit.matched_requirements.map((req) => (
                      <li key={req} className="flex items-start gap-2 text-sm">
                        <CheckCircle2 className="mt-0.5 size-3.5 shrink-0 text-ok" aria-hidden="true" />
                        <span>{req}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ) : null}

              {fit.gaps.length > 0 ? (
                <div className="space-y-2">
                  <h3 className="text-sm font-semibold">Job requirements</h3>
                  <ul className="space-y-1.5">
                    {fit.gaps.map((gap) => (
                      <li key={gap} className="flex items-start gap-2 text-sm">
                        <Target className="mt-0.5 size-3.5 shrink-0 text-warn" aria-hidden="true" />
                        <span>{gap}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ) : null}
            </div>
          </>
        ) : null}

        {/*
          soul.md §6: an agent without enough signal says so rather than guessing
          plausibly. When it does, the candidate is the one who should hear it.
        */}
        {fit.insufficient_signal && fit.insufficient_signal.length > 0 ? (
          <Alert variant="muted">
            <CircleHelp aria-hidden="true" />
            <AlertTitle>Not enough to go on for some of this</AlertTitle>
            <AlertDescription>
              <p>
                Your resume did not give a clear enough signal on{" "}
                {fit.insufficient_signal.join(", ")} — so nothing has been assumed either way.
              </p>
            </AlertDescription>
          </Alert>
        ) : null}
      </CardContent>
    </Card>
  );
}

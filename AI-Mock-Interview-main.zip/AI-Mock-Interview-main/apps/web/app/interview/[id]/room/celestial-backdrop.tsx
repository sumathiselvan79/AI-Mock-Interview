"use client";

/**
 * The interview room's backdrop — the particle field from `display.html`,
 * lifted out of that standalone widget and made the room's own background.
 *
 * What was ported, and what deliberately changed:
 *
 *  - **The physics are the original's.** Same ring (an inner and outer radius
 *    with `Math.random() + Math.random()` biasing particles toward the middle),
 *    same per-particle wobble, same pulsing core, same cyan/deep-blue palette,
 *    and the same trick that makes the trails work: each frame paints the
 *    background at 35% alpha rather than clearing, then draws in `lighter`
 *    composite mode so overlapping particles bloom.
 *  - **It is sized to the viewport, not to a 280px widget.** The radii and the
 *    core scale off the smaller viewport axis, so the ring stays a ring on a
 *    phone and on an ultrawide instead of being cropped or lost in the middle.
 *  - **It follows the app's theme instead of its own toggle.** `display.html`
 *    shipped a sun/moon switch; here the theme is the app's, read once and
 *    re-read when it changes, because a second theme control on the interview
 *    page would be a second source of truth for something the app already owns.
 *  - **It is dimmed and pushed behind everything.** As a widget it was the
 *    subject; as a backdrop it is not. Full-strength particles behind live
 *    interview text would fail contrast and pull the eye during exactly the
 *    part of the session that needs attention — so the whole canvas carries a
 *    low opacity and the page paints its own readable surfaces on top.
 *
 * Purely decorative: `aria-hidden`, `pointer-events-none`, fixed and behind the
 * content. Reduced motion is honoured by rendering ONE composed frame and
 * stopping — the field is still there, it just does not move.
 */

import { useEffect, useRef } from "react";
import { prefersReducedMotion } from "@/lib/motion";

interface Particle {
  angle: number;
  speed: number;
  size: number;
  color: string;
  alpha: number;
  wobbleSpeed: number;
  wobbleAmount: number;
  baseRadius: number;
  radius: number;
}

/** Scaled down from `display.html`'s 1200: this covers a whole viewport, not a 280px disc. */
const PARTICLE_COUNT = 900;

function isDark(): boolean {
  if (typeof document === "undefined") return true;
  const attr = document.documentElement.getAttribute("data-theme");
  if (attr === "dark") return true;
  if (attr === "light") return false;
  return document.documentElement.classList.contains("dark");
}

export function CelestialBackdrop() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;

    let raf = 0;
    let particles: Particle[] = [];
    let width = 0;
    let height = 0;
    let centerX = 0;
    let centerY = 0;
    let innerRadius = 0;
    let outerRadius = 0;
    let dark = isDark();
    const still = prefersReducedMotion();

    /**
     * The ring is sized off the SMALLER viewport axis so it never runs off the
     * edge, and the centre sits at the true middle of the page — the speech and
     * transcription panels now float left-center/right-center *over* the ring
     * rather than stacking below it, so there is no lower-half control area to
     * dodge any more. The ring is the thing they overlap.
     */
    function layout() {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      width = window.innerWidth;
      height = window.innerHeight;
      canvas!.width = Math.floor(width * dpr);
      canvas!.height = Math.floor(height * dpr);
      canvas!.style.width = `${width}px`;
      canvas!.style.height = `${height}px`;
      ctx!.setTransform(dpr, 0, 0, dpr, 0, 0);

      centerX = width / 2;
      centerY = height * 0.5;
      const reach = Math.min(width, height);
      innerRadius = reach * 0.16;
      outerRadius = reach * 0.46;
    }

    function seed() {
      particles = Array.from({ length: PARTICLE_COUNT }, () => {
        // The original's radius bias: two summed randoms cluster particles
        // toward the middle of the band rather than spreading them evenly.
        const radiusRandomness = Math.random() + Math.random();
        const radius = innerRadius + (radiusRandomness / 2) * (outerRadius - innerRadius);
        const r = Math.floor(Math.random() * 20 + 10);
        const g = Math.floor(Math.random() * 150 + 100);
        const b = Math.floor(Math.random() * 55 + 200);
        return {
          angle: Math.random() * Math.PI * 2,
          speed: Math.random() * 0.003 + 0.001,
          size: Math.random() * 1.2 + 0.3,
          color: `rgba(${r}, ${g}, ${b}, `,
          alpha: Math.random() * 0.8 + 0.2,
          wobbleSpeed: Math.random() * 0.05,
          wobbleAmount: Math.random() * (outerRadius * 0.07),
          baseRadius: radius,
          radius,
        };
      });
    }

    function drawCore(time: number) {
      const pulse = Math.sin(time * 0.004) * (innerRadius * 0.04);
      const coreRadius = innerRadius * 0.4 + pulse;
      const gradient = ctx!.createRadialGradient(centerX, centerY, 0, centerX, centerY, coreRadius * 2);

      if (dark) {
        gradient.addColorStop(0, "rgba(255, 255, 255, 1)");
        gradient.addColorStop(0.3, "rgba(100, 220, 255, 0.9)");
        gradient.addColorStop(0.7, "rgba(0, 100, 200, 0.4)");
        gradient.addColorStop(1, "rgba(0, 0, 0, 0)");
      } else {
        gradient.addColorStop(0, "rgba(0, 100, 255, 1)");
        gradient.addColorStop(0.3, "rgba(0, 150, 255, 0.9)");
        gradient.addColorStop(0.7, "rgba(0, 200, 255, 0.4)");
        gradient.addColorStop(1, "rgba(0, 0, 0, 0)");
      }

      ctx!.beginPath();
      ctx!.arc(centerX, centerY, coreRadius * 2, 0, Math.PI * 2);
      ctx!.fillStyle = gradient;
      ctx!.fill();
    }

    function frame(time: number) {
      // The original's trail trick: never clear, repaint the ground at 35%
      // alpha so what came before fades instead of vanishing.
      ctx!.globalCompositeOperation = "source-over";
      ctx!.fillStyle = dark ? "rgba(11, 12, 16, 0.35)" : "rgba(240, 242, 245, 0.35)";
      ctx!.fillRect(0, 0, width, height);

      ctx!.globalCompositeOperation = dark ? "lighter" : "source-over";
      drawCore(time);

      for (const p of particles) {
        p.angle += p.speed;
        p.radius = p.baseRadius + Math.sin(time * p.wobbleSpeed) * p.wobbleAmount;
        const x = centerX + Math.cos(p.angle) * p.radius;
        const y = centerY + Math.sin(p.angle) * p.radius;
        ctx!.beginPath();
        ctx!.arc(x, y, p.size, 0, Math.PI * 2);
        ctx!.fillStyle = p.color + p.alpha + ")";
        ctx!.fill();
      }
    }

    /**
     * Reduced motion still gets a field, just a still one. The trails are what
     * make a single frame look sparse, so it composes a handful of frames back
     * to back and then stops — same image, no movement.
     */
    function renderStill() {
      ctx!.globalCompositeOperation = "source-over";
      ctx!.fillStyle = dark ? "#0b0c10" : "#f0f2f5";
      ctx!.fillRect(0, 0, width, height);
      for (let i = 0; i < 12; i++) frame(i * 90);
    }

    function start() {
      layout();
      seed();
      cancelAnimationFrame(raf);
      if (still) {
        renderStill();
        return;
      }
      const loop = (time: number) => {
        frame(time);
        raf = requestAnimationFrame(loop);
      };
      raf = requestAnimationFrame(loop);
    }

    start();

    // Debounced: a drag-resize would otherwise reseed 900 particles per frame.
    let resizeTimer: ReturnType<typeof setTimeout>;
    const onResize = () => {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(start, 150);
    };
    window.addEventListener("resize", onResize);

    // The app owns the theme; this just follows it, from either direction —
    // an explicit `data-theme` toggle or the OS-level preference.
    const media = window.matchMedia("(prefers-color-scheme: dark)");
    const onThemeChange = () => {
      dark = isDark();
      if (still) renderStill();
    };
    media.addEventListener("change", onThemeChange);
    const observer = new MutationObserver(onThemeChange);
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme", "class"] });

    return () => {
      cancelAnimationFrame(raf);
      clearTimeout(resizeTimer);
      window.removeEventListener("resize", onResize);
      media.removeEventListener("change", onThemeChange);
      observer.disconnect();
    };
  }, []);

  return (
    <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden" aria-hidden="true">
      {/* Painted under the canvas so the trail-fade has something solid to fade
          toward, and so the page never shows a transparent gap on first paint. */}
      <div className="absolute inset-0 bg-background" />
      {/* Dimmed hard: as a backdrop this must never compete with live interview
          text for attention, and full-strength particles behind body copy fail
          contrast outright. */}
      <canvas ref={canvasRef} className="absolute inset-0 opacity-40 dark:opacity-55" />
      {/* A readability wash — heaviest at the bottom, where the answer controls
          sit, lightest at the top, where the ring is the point. */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "linear-gradient(to bottom, color-mix(in oklab, var(--background) 30%, transparent) 0%, color-mix(in oklab, var(--background) 55%, transparent) 45%, color-mix(in oklab, var(--background) 82%, transparent) 100%)",
        }}
      />
    </div>
  );
}

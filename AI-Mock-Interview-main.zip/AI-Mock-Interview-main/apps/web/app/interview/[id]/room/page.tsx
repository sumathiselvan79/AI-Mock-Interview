"use client";

/**
 * Interview Environment — `CALIBRATION` through `WRAP_UP`
 * (`INSTRUCTIONS.md §3.1`).
 *
 * Questions are spoken; answers are recorded and transcribed. Three rules from
 * soul.md are visible in the behaviour, not just the backend:
 *
 *  - **The typed fallback is always there.** Not hidden behind a failure, not a
 *    penalty. When transcription is not confident the page says so plainly and
 *    offers the keyboard with what it thought it heard, for the candidate to
 *    correct.
 *
 * **Record -> review -> submit.** The recorder runs until the candidate stops it
 * — there is no silence cutoff and no fixed clip length, so a long answer with
 * pauses in it is one recording, not several. Stopping only TRANSCRIBES: the
 * text comes back to the page for the candidate to read and correct, and nothing
 * is scored until they send it. That ordering is the point rather than a
 * convenience — a recogniser mishearing "REST" as "rest" would otherwise be
 * scored as the candidate's own words, and soul.md §5 does not allow a doubtful
 * transcript to become evidence. The correction is submitted through the
 * ordinary text path, so an edited answer and a typed one are the same thing to
 * every agent downstream.
 *  - **Paste detection only runs if it was consented to.** The listener is
 *    attached regardless, but the server discards the event without consent —
 *    and the page says which state it is in rather than implying it is watching.
 *  - **One coherent voice.** The follow-up is spoken in the same voice as the
 *    question, because to the candidate this is one interviewer, not eight
 *    agents.
 *
 * (Stage 8) Two things about how this page LOOKS are also rules, not taste:
 *
 *  - **The pacing bar nudges, it does not nag** (soul.md §4, Time Tracking
 *    Agent). It never turns red, never counts down in the tab title, and never
 *    animates as time runs out. Going over the budget is stated calmly and does
 *    not end anything.
 *  - **A follow-up is a continuation, not a new screen.** The question that
 *    prompted it, and the answer given, stay visible above it. Replacing the
 *    question text outright — which is what this page used to do — loses the
 *    thread at exactly the moment the candidate needs it.
 *
 * (Overlapping stage rebuild) The room is now one centered stage over the
 * `display.html` particle field (`celestial-backdrop.tsx`), which is itself
 * centered in the viewport rather than pinned above the fold:
 *
 *  - **Left-center: the interviewer's speech.** Every question and follow-up
 *    stays on screen in order, and the current line is revealed *as it is
 *    spoken* rather than appearing whole before the voice reaches it — the
 *    text and the audio are one delivery, not a caption racing its own
 *    soundtrack.
 *  - **Right-center: the candidate's transcription, and the controls under
 *    it.** The answer is transcribed live, so a candidate can see the mic is
 *    hearing them without waiting until they stop; the record/type/submit
 *    controls sit directly beneath it, since they act on exactly that text.
 *  - **Both panels overlap the ring, not just each other.** They are frosted
 *    glass — a blurred, translucent surface, not an opaque card — so the
 *    animated backdrop bleeds through at the edges instead of stopping dead
 *    at a box boundary.
 *
 *  The live transcript is a preview and is never what gets scored: what is
 *  submitted is still the Speech Service's transcript after the candidate has
 *  read it back (see `lib/speech.ts`).
 */

import { useCallback, useEffect, useMemo, useRef, useState, type RefObject } from "react";
import { useParams, useRouter } from "next/navigation";
import {
  AlertTriangle,
  CheckCircle2,
  ClipboardCheck,
  CornerDownRight,
  Handshake,
  Loader2,
  Maximize2,
  Mic,
  Minimize2,
  MicOff,
  PencilLine,
  Repeat,
  Send,
  SkipForward,
  Square,
  Volume2,
} from "lucide-react";
import { toast } from "sonner";
import gsap from "gsap";
import { GATEWAY_URL, api, auth, type AnswerEvaluation, type Grade } from "@/lib/api";
import { replyTo } from "@/lib/live-protocol";
import { answersForCurrentPrompt } from "@/lib/room-turns";
import { SAFETY_DISCLAIMER } from "@/app/components/site-header";
import { prefersReducedMotion } from "@/lib/motion";
import { dictationSupported, playClip, speak, startDictation, type Dictation, type SpeakHandle } from "@/lib/speech";
import { describeInputDevice, watchSilence, type InputDeviceHint, type SilenceWatch } from "@/lib/mic";
import { InlineError, Notice } from "@/app/components/shell";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/app/components/ui/alert-dialog";
import { Alert, AlertDescription, AlertTitle } from "@/app/components/ui/alert";
import { Badge } from "@/app/components/ui/badge";
import { Button } from "@/app/components/ui/button";
import { Card, CardContent } from "@/app/components/ui/card";
import { Textarea } from "@/app/components/ui/textarea";
import { cn } from "@/lib/utils";
import { CelestialBackdrop } from "./celestial-backdrop";

interface Question {
  id: string;
  text: string;
  topic: string;
  question_type: string;
  difficulty?: number;
  audio_url?: string | null;
}

interface FollowUp {
  answer_id: string;
  text: string;
  audio_url?: string | null;
}

type Phase =
  | "idle"
  | "asking"
  /** Question delivered; the candidate may start recording or start typing. */
  | "answering"
  /** Recording stopped, audio is with the Speech Service, no text back yet. */
  | "transcribing"
  /** Text is back and editable. Nothing is scored until the candidate sends. */
  | "reviewing"
  | "thinking"
  | "coding"
  | "done";

/**
 * One line of the conversation, in the order it happened.
 *
 * The whole exchange stays on screen rather than one question at a time. An
 * interview is a thread — "what did I already say about this?" is a fair
 * question to be able to answer by looking, and the follow-up logic depends on
 * the candidate remembering their own last answer.
 */
type Turn =
  | {
      id: string;
      role: "interviewer";
      /**
       * `clarification` is a question being repeated because the candidate
       * asked for it (HUMAN_INTERACTION_FLOW.md §3) — kept in the thread
       * because it happened, but labelled apart from a fresh question so the
       * transcript does not read as two questions on one topic.
       *
       * `greeting` is the interview saying hello (§8). It is in the thread for
       * the same reason: it was said. It is not a question, so it must never
       * hand the turn to the candidate the way a question does — nothing is
       * waiting to be answered when it plays.
       */
      kind: "question" | "follow_up" | "clarification" | "greeting";
      text: string;
      topic?: string;
      questionType?: string;
    }
  | {
      id: string;
      role: "candidate";
      text: string;
      /** True while this is the recogniser's running preview, not a sent answer. */
      live: boolean;
      /** The in-flight guess, shown apart from the settled text. */
      interim?: string;
      grade?: Grade | null;
    };

/** Fullscreen exits allowed before the harness concludes the session early. */
const EXIT_LIMIT = 3;

/**
 * How long a recording with NO speech in it runs before the room gives up on
 * it. The same 15 seconds the server caps a transcription at
 * (`STT_TIMEOUT_SECONDS`), and deliberately the same number: both are "this
 * turn is not going to produce a transcript, stop waiting", one because nothing
 * was said and one because the model could not finish. Nothing is submitted, so
 * the candidate loses no turn.
 *
 * It is measured from the last sound, not from the start of the recording — a
 * candidate thinking for twenty seconds before they begin is answering
 * normally, and cutting them off would be wrong.
 */
const SILENCE_TIMEOUT_MS = 15_000;

/**
 * How long a pause has to run, AFTER speech, before the recording stops itself.
 * Well above the pause inside a normal sentence: stopping on a mid-thought
 * breath would truncate the answer, which costs far more than a couple of
 * seconds of trailing silence the server's VAD trims off anyway.
 */
const TRAILING_SILENCE_MS = 2_500;

export default function InterviewRoomPage() {
  const params = useParams<{ id: string }>();
  const sessionId = params.id;
  const router = useRouter();

  const [phase, setPhase] = useState<Phase>("idle");
  const [question, setQuestion] = useState<Question | null>(null);
  const [followUp, setFollowUp] = useState<FollowUp | null>(null);
  /** The editable answer — whether it arrived from the recogniser or the keyboard. */
  const [typedAnswer, setTypedAnswer] = useState("");
  const [showTyped, setShowTyped] = useState(false);
  /** Set when the text on screen came from speech, so the page can say so. */
  const [draftFromSpeech, setDraftFromSpeech] = useState(false);
  const [draftEdited, setDraftEdited] = useState(false);
  const [retryNotice, setRetryNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [elapsed, setElapsed] = useState(0);
  /** From `timer_tick`'s `remaining_ms`; negative once the budget is spent. */
  const [remaining, setRemaining] = useState<number | null>(null);
  const [recording, setRecording] = useState(false);
  const [recordedMs, setRecordedMs] = useState(0);
  /** True once the silence watcher has heard anything, so the room can say so. */
  const [heardSpeech, setHeardSpeech] = useState(false);
  /** Set when a recording was abandoned for having no sound in it at all. */
  const [silenceNotice, setSilenceNotice] = useState<string | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [focusExitCount, setFocusExitCount] = useState(0);
  const [focusNotice, setFocusNotice] = useState<string | null>(null);
  const [concludedEarly, setConcludedEarly] = useState(false);

  /** The running conversation, oldest first. */
  const [turns, setTurns] = useState<Turn[]>([]);
  /**
   * How much of the CURRENT interviewer line has been spoken, 0..1. The reveal
   * is driven by the voice (see `lib/speech.ts`) rather than by a timer of the
   * page's own, so the words appear as they are heard.
   */
  const [spokenFraction, setSpokenFraction] = useState(1);
  const [revealingTurnId, setRevealingTurnId] = useState<string | null>(null);
  /**
   * The micro-acknowledgment the interviewer just made (§1), held only for the
   * gap between it and the real response. Deliberately NOT a `Turn`: "Mm-hm."
   * is a noise, not a line of the interview, and a transcript with one between
   * every question would be harder to read, not warmer.
   */
  const [acknowledgment, setAcknowledgment] = useState<string | null>(null);

  const socketRef = useRef<WebSocket | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  /** The live mic stream while recording — a second consumer (the waveform's
      own AnalyserNode) reads from this alongside the MediaRecorder; visual
      only, so it never touches the actual answer-submission path. */
  const streamRef = useRef<MediaStream | null>(null);
  /** So the fullscreenchange handler can tell an EXIT (true -> false) from an entry. */
  const wasFullscreenRef = useRef(false);
  /** The in-flight spoken line, so a new question can cut off the last one. */
  const speechRef = useRef<SpeakHandle | null>(null);
  /** The live recogniser for the answer being spoken right now. */
  const dictationRef = useRef<Dictation | null>(null);
  /** End-of-speech watcher for the recording in flight. */
  const silenceRef = useRef<SilenceWatch | null>(null);
  /** What the browser said about the capture device, sent with the audio. */
  const deviceHintRef = useRef<InputDeviceHint | null>(null);
  /** Set when a recording is being thrown away rather than submitted. */
  const abortedRef = useRef(false);
  /** Id of the candidate turn the recogniser is currently filling in. */
  const liveTurnRef = useRef<string | null>(null);

  const send = useCallback((message: Record<string, unknown>) => {
    const ws = socketRef.current;
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(message));
    }
  }, []);

  /** Clears the answer surface so one question's draft can never be sent for the next. */
  const resetDraft = useCallback(() => {
    setTypedAnswer("");
    setShowTyped(false);
    setDraftFromSpeech(false);
    setDraftEdited(false);
    setRetryNotice(null);
    setSilenceNotice(null);
    setHeardSpeech(false);
    setRecordedMs(0);
  }, []);

  // ------------------------------------------------------- speaking a line

  /**
   * Speaks one interviewer line and reveals it in step with the voice.
   *
   * Order of preference: real server audio, then the browser's own voice, then
   * silence — the same ladder the page has always used. What is new is that
   * every rung reports progress, so the reveal is driven by whichever one
   * actually spoke rather than by a guess. Silence reveals the line at once,
   * because there is nothing to keep pace with.
   */
  const speakLine = useCallback(
    async (turnId: string, text: string, audioUrl: string | null) => {
      speechRef.current?.cancel();
      setRevealingTurnId(turnId);
      setSpokenFraction(0);

      const onProgress = (fraction: number) => setSpokenFraction(fraction);
      const onDone = () => {
        setSpokenFraction(1);
        setRevealingTurnId(null);
        setPhase("answering");
      };

      // 1. Server-synthesised audio, when the sherpa-onnx models are installed.
      //    Fixture mode returns a 140Hz test tone rather than speech — playing
      //    that would be worse than silence, so it falls through to the browser
      //    voice instead.
      if (audioUrl) {
        const token = auth.token();
        try {
          const response = await fetch(`${GATEWAY_URL}/sessions/${sessionId}${audioUrl}`, {
            headers: token ? { authorization: `Bearer ${token}` } : {},
          });
          if (response.ok && response.headers.get("x-speech-provider") !== "fixture") {
            speechRef.current = playClip(URL.createObjectURL(await response.blob()), { onProgress, onDone });
            return;
          }
        } catch {
          // Fall through to the browser voice.
        }
      }

      // 2. The browser's own speech synthesis. Word-boundary events make this
      //    the most accurate reveal of the three.
      speechRef.current = speak({ text, onProgress, onDone });
    },
    [sessionId],
  );

  /**
   * Speaks a line that is not a turn of the interview — today, only the
   * micro-acknowledgment (§1).
   *
   * Separate from `speakLine` because the two differ in what they mean, not
   * just in what they play. `speakLine` drives the word-by-word reveal of a
   * line in the transcript and, when it finishes, hands control to the
   * candidate by moving the phase to "answering". Neither is right here: there
   * is no transcript line to reveal, and the interview is still thinking — the
   * candidate's turn has not come back round.
   */
  const speakAside = useCallback(
    async (text: string, audioUrl: string | null) => {
      speechRef.current?.cancel();

      if (audioUrl) {
        const token = auth.token();
        try {
          const response = await fetch(`${GATEWAY_URL}/sessions/${sessionId}${audioUrl}`, {
            headers: token ? { authorization: `Bearer ${token}` } : {},
          });
          if (response.ok && response.headers.get("x-speech-provider") !== "fixture") {
            speechRef.current = playClip(URL.createObjectURL(await response.blob()), { onProgress: () => {}, onDone: () => {} });
            return;
          }
        } catch {
          // Fall through to the browser voice.
        }
      }

      speechRef.current = speak({ text, onProgress: () => {}, onDone: () => {} });
    },
    [sessionId],
  );

  // Leaving the page mid-sentence must not leave a voice talking to an empty room.
  useEffect(() => {
    return () => {
      speechRef.current?.cancel();
      dictationRef.current?.stop();
      // The silence watcher holds an AudioContext of its own. Leaving it open
      // keeps the microphone indicator lit after the candidate has navigated
      // away, which reads as still being recorded.
      silenceRef.current?.stop();
    };
  }, []);

  // ------------------------------------------------------------ conversation

  const pushInterviewerTurn = useCallback(
    (kind: "question" | "follow_up" | "clarification" | "greeting", text: string, meta?: { topic?: string; questionType?: string }) => {
      const id = `${kind}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      setTurns((prev) => [
        // A live preview that was never sent (the candidate skipped, or the
        // recogniser heard nothing) must not be left sitting in the thread as
        // if it were an answer they gave.
        ...prev.filter((t) => !(t.role === "candidate" && t.live)),
        { id, role: "interviewer", kind, text, topic: meta?.topic, questionType: meta?.questionType },
      ]);
      return id;
    },
    [],
  );

  /** Replaces the live preview with what was actually submitted and scored. */
  const settleCandidateTurn = useCallback((text: string, grade?: Grade | null) => {
    const liveId = liveTurnRef.current;
    liveTurnRef.current = null;
    setTurns((prev) => {
      const existing = liveId ? prev.find((t) => t.id === liveId) : undefined;
      if (existing) {
        return prev.map((t) => (t.id === liveId ? { ...t, role: "candidate" as const, text, live: false, interim: undefined, grade } : t));
      }
      // Typed answers never had a preview to settle.
      return [...prev, { id: `answer-${Date.now()}`, role: "candidate", text, live: false, grade }];
    });
  }, []);

  /** Attaches a score that arrived after the answer was already on screen. */
  const attachGrade = useCallback((evaluation: AnswerEvaluation | null | undefined) => {
    const grade = evaluation?.grade;
    if (!grade) return;
    setTurns((prev) => {
      const lastCandidate = [...prev].reverse().find((t) => t.role === "candidate");
      if (!lastCandidate) return prev;
      return prev.map((t) => (t.id === lastCandidate.id ? { ...t, grade } : t));
    });
  }, []);

  // ------------------------------------------------------------ live channel

  useEffect(() => {
    const token = auth.token();
    if (!token) {
      setError("Your session has expired. Sign in again.");
      return;
    }

    // React Strict Mode double-mounts effects in dev. The first mount's
    // cleanup fires while the socket is still CONNECTING, and calling close()
    // on a CONNECTING socket produces the browser warning. Instead we use a
    // cancellation flag: the cleanup marks the socket as abandoned, and the
    // onopen handler closes it if the flag is set.
    let cancelled = false;

    const url = `${GATEWAY_URL.replace(/^http/, "ws")}/sessions/${sessionId}/live?token=${encodeURIComponent(token)}`;
    const socket = new WebSocket(url);
    socketRef.current = socket;

    socket.onmessage = (event) => {
      if (cancelled) return;
      const message = JSON.parse(String(event.data)) as Record<string, unknown>;

      // The gateway never volunteers the next question — it has to be asked
      // for. Without this the loop stalled dead after every answer: the server
      // acknowledged it, the page moved to "thinking", and nothing else was
      // going to speak, so the only way forward was the "Skip" button.
      const reply = replyTo(message);
      if (reply) send(reply);

      switch (message.type) {
        // (§1) The interviewer's "mm-hm", spoken while the score and the
        // follow-up decision are still being computed. It does not end the
        // candidate's turn, does not enter the transcript, and is never
        // replied to (see `replyTo`) — it only fills the gap that used to be
        // silence followed by a fully-formed reply.
        case "acknowledgment":
          setAcknowledgment(String(message.text ?? ""));
          void speakAside(String(message.text ?? ""), message.audio_url as string | null);
          return;

        // (§8) A line spoken to hold the conversation open while the server is
        // still working. Like `acknowledgment` it ends no turn and is never
        // replied to — the reply to the message that triggered it is still on
        // its way, and asking for a next question here would skip one.
        //
        // `opening` is the exception in kind but not in that rule: it is the
        // hello at the top of the session, so it belongs in the thread rather
        // than in the thinking indicator. It still hands the turn to nobody —
        // `speakAside`, not `speakLine`, because the first question has not
        // been asked yet.
        case "continuer": {
          const text = String(message.text ?? "");
          if (!text) return;
          if (message.kind === "opening") {
            pushInterviewerTurn("greeting", text);
          } else {
            setAcknowledgment(text);
            if (message.kind === "holding" || message.kind === "selection") setPhase("thinking");
          }
          void speakAside(text, message.audio_url as string | null);
          return;
        }

        // (§3) The candidate asked to hear the question again, or what it
        // meant. Nothing was scored and the same question is still on the
        // table — so no `setQuestion`, no `resetDraft` beyond the send, and no
        // request for a next question.
        case "clarification":
          setAcknowledgment(null);
          setPhase("asking");
          void speakLine(
            pushInterviewerTurn("clarification", String(message.text)),
            String(message.text),
            message.audio_url as string | null,
          );
          return;

        case "question":
          if (message.answered) {
            setPhase("thinking");
            attachGrade(message.evaluation as AnswerEvaluation | null | undefined);
            // The probe this reply answered is finished with.
            setFollowUp(null);
            return;
          }
          setAcknowledgment(null);
          setQuestion(message as unknown as Question);
          setFollowUp(null);
          resetDraft();
          setPhase("asking");
          void speakLine(
            pushInterviewerTurn("question", String(message.text), {
              topic: message.topic as string | undefined,
              questionType: message.question_type as string | undefined,
            }),
            String(message.text),
            message.audio_url as string | null,
          );
          return;

        case "follow_up":
          setAcknowledgment(null);
          setFollowUp({ answer_id: String(message.answer_id), text: String(message.text), audio_url: message.audio_url as string | null });
          resetDraft();
          setPhase("asking");
          void speakLine(pushInterviewerTurn("follow_up", String(message.text)), String(message.text), message.audio_url as string | null);
          return;

        case "transcript_draft":
          // Transcribed, not scored. The text is now the candidate's to correct
          // before anything is submitted.
          setTypedAnswer(String(message.transcript ?? ""));
          setDraftFromSpeech(true);
          setDraftEdited(false);
          setShowTyped(true);
          setRetryNotice(null);
          setPhase("reviewing");
          return;

        case "transcript_rejected": {
          // The candidate did nothing wrong: say what happened and hand them
          // the keyboard. The server's `reason` is used when it sent one —
          // "there was no speech in that" and "that was your speakers" need
          // different sentences from "that was hard to make out", and only the
          // server knows which happened.
          setRetryNotice(
            String(message.reason ?? "That was hard to make out — nothing has been scored. Correct it below, or record it again."),
          );
          // No pre-filled draft for the two refusals where any text would be
          // either invented or the interview's own question — see the REST
          // path above for the full reasoning.
          const noDraft = message.code === "no_speech_detected" || message.code === "audio_source_rejected";
          const draft = noDraft ? "" : String(message.draft_transcript ?? "");
          setTypedAnswer(draft);
          setDraftFromSpeech(Boolean(draft));
          setDraftEdited(false);
          setShowTyped(true);
          setPhase("reviewing");
          return;
        }

        case "timer_tick":
          setElapsed(Number(message.elapsed_ms ?? 0));
          if (message.remaining_ms !== undefined) setRemaining(Number(message.remaining_ms));
          return;

        case "paste_detected":
          // Transient and informational — a toast rather than a banner, so it
          // does not shove the question down the page mid-answer.
          toast(
            message.recorded
              ? "A paste was noted (time only, not the content) — you agreed to this on the previous page."
              : "Paste detection is off for this session.",
          );
          return;

        case "focus_recorded":
          if (message.recorded) setFocusExitCount(Number(message.exit_count ?? 0));
          return;

        case "session_complete":
          speechRef.current?.cancel();
          setPhase("done");
          setQuestion(null);
          setConcludedEarly(message.reason === "focus_exit_limit");
          // Trigger report generation and navigate to the report page.
          void api
            .generateReport(sessionId)
            .then(() => router.push(`/interview/${sessionId}/report`))
            .catch(() => router.push(`/interview/${sessionId}/report`));
          return;

        case "error":
          setError(String(message.message ?? "something went wrong"));
          return;

        default:
          return;
      }
    };

    socket.onopen = () => {
      if (cancelled) {
        socket.close();
        return;
      }
      send({ type: "next_question" });
    };
    socket.onerror = () => {
      if (!cancelled) setError("Lost the connection to the interview.");
    };

    return () => {
      cancelled = true;
      if (socket.readyState === WebSocket.OPEN) {
        socket.close();
      }
      // CONNECTING sockets are NOT closed here — they will close themselves
      // in the onopen handler above once they see `cancelled === true`.
    };
  }, [sessionId, send, resetDraft, router, speakLine, speakAside, pushInterviewerTurn, attachGrade]);

  // Paste detection. The listener is harmless on its own — the server decides
  // whether the event may be recorded, and discards it without consent.
  useEffect(() => {
    const onPaste = (e: Event) => {
      e.preventDefault();
      send({ type: "paste_detected", timestamp: new Date().toISOString() });
    };
    window.addEventListener("paste", onPaste);
    return () => window.removeEventListener("paste", onPaste);
  }, [send]);

  // How long the candidate has been speaking. Shown because a recording with no
  // stop condition otherwise gives no sign it is still running.
  useEffect(() => {
    if (!recording) return;
    const started = Date.now();
    const tick = setInterval(() => setRecordedMs(Date.now() - started), 250);
    return () => clearInterval(tick);
  }, [recording]);

  // Leaving the page mid-recording must not leave the mic open.
  useEffect(() => {
    return () => {
      if (mediaRecorderRef.current && mediaRecorderRef.current.state === "recording") {
        mediaRecorderRef.current.stop();
      }
      mediaRecorderRef.current = null;
    };
  }, []);

  // The Telemetry Check page's "Start the interview" click already requested
  // fullscreen — this is the fallback for a browser that carried that
  // activation across the navigation, or a session opened directly on this
  // page. Best-effort and silent: most browsers refuse a fullscreen request
  // with no direct user gesture behind it, and the interview works fine
  // windowed either way.
  useEffect(() => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
    }
  }, []);

  // Fullscreen-EXIT tracking. Entering fullscreen is not reported — only
  // leaving it is, since that is the "activity" the candidate agreed to have
  // recorded on the Telemetry Check page. The server silently discards this if
  // that consent was never given (soul.md §5), so the listener itself is
  // harmless to run unconditionally.
  useEffect(() => {
    wasFullscreenRef.current = !!document.fullscreenElement;
    setIsFullscreen(!!document.fullscreenElement);
    const onFullscreenChange = () => {
      const nowFullscreen = !!document.fullscreenElement;
      setIsFullscreen(nowFullscreen);

      if (wasFullscreenRef.current && !nowFullscreen) {
        send({ type: "focus_lost", timestamp: new Date().toISOString() });
        setFocusNotice(
          `You left fullscreen — this may be recorded if you agreed to it. Leaving more than ${EXIT_LIMIT} times ends the interview early.`,
        );
      }
      wasFullscreenRef.current = nowFullscreen;
    };
    document.addEventListener("fullscreenchange", onFullscreenChange);
    return () => document.removeEventListener("fullscreenchange", onFullscreenChange);
  }, [send]);

  const toggleFullscreen = useCallback(async () => {
    if (!document.fullscreenElement) {
      await document.documentElement.requestFullscreen().catch((err) => {
        console.error(`Error attempting to enable fullscreen: ${err.message}`);
      });
    } else {
      await document.exitFullscreen().catch((err) => {
        console.error(`Error attempting to disable fullscreen: ${err.message}`);
      });
    }
  }, []);

  // -------------------------------------------------------------- recording

  async function startRecording(): Promise<void> {
    setError(null);
    setRetryNotice(null);

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        // Echo cancellation is requested explicitly rather than left to the
        // browser default: it is the first line of defence against the
        // microphone hearing the interview's own question through open
        // speakers. The server still checks (`source.py`) — a request is not a
        // guarantee, and not every device honours it.
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      });
      streamRef.current = stream;
      const recorder = new MediaRecorder(stream);
      audioChunksRef.current = [];

      // What the browser knows about the capture device, sent with the audio so
      // the server can tell a microphone from a loopback of its own output.
      deviceHintRef.current = describeInputDevice(stream);

      // End-of-speech detection. Stops the recording when they stop talking,
      // and gives up after SILENCE_TIMEOUT_MS of a recording with no speech in
      // it at all — a muted microphone, rather than a long pause.
      silenceRef.current = watchSilence(stream, {
        timeoutMs: SILENCE_TIMEOUT_MS,
        trailingSilenceMs: TRAILING_SILENCE_MS,
        onSpeechStarted: () => setHeardSpeech(true),
        onSpeechEnded: () => stopRecording(),
        onSilenceTimeout: () => {
          // Nothing was said, so nothing is submitted. Sending it anyway would
          // spend a transcription on silence and come back with the server's
          // own "no speech detected" — the same outcome, slower, and phrased
          // as a failure rather than as what it is.
          setSilenceNotice(
            `No sound was picked up for ${Math.round(SILENCE_TIMEOUT_MS / 1000)} seconds. Check your microphone is on and not muted, then record again — nothing has been sent.`,
          );
          abortRecording();
        },
      });

      // The live preview. A separate, purely visual pipeline from the
      // MediaRecorder above: the recording is what gets transcribed and scored,
      // this is only so the candidate can see they are being heard. It failing
      // (or being unsupported) costs the preview and nothing else.
      const liveId = `answer-${Date.now()}`;
      liveTurnRef.current = liveId;
      setTurns((prev) => [...prev, { id: liveId, role: "candidate", text: "", live: true, interim: "" }]);
      dictationRef.current = startDictation({
        onUpdate: (settled, interim) =>
          setTurns((prev) => prev.map((t) => (t.id === liveId && t.role === "candidate" ? { ...t, text: settled, interim } : t))),
      });

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };

      recorder.onstop = async () => {
        const blob = new Blob(audioChunksRef.current);
        stream.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
        silenceRef.current?.stop();
        silenceRef.current = null;
        const heard = dictationRef.current?.stop() ?? "";
        dictationRef.current = null;
        setRecording(false);

        // An aborted recording (the silence timeout, or a re-record) has
        // already said what it needed to and must not be submitted.
        if (abortedRef.current) {
          abortedRef.current = false;
          setPhase("answering");
          return;
        }
        setPhase("transcribing");

        try {
          const { blobToWav, blobToBase64 } = await import("@/lib/audio");
          const wavBlob = await blobToWav(blob);
          const base64 = await blobToBase64(wavBlob);

          const res = await api.submitAudioAnswer(sessionId, question?.id || "", base64, deviceHintRef.current);

          if (!res.accepted) {
            // The server's own words when it has any — its four refusals mean
            // four different things and only one of them is "hard to make out".
            setRetryNotice(res.reason ?? res.message ?? "That was hard to make out. Correct it below, or record it again.");

            // Prefer the server's draft; fall back to what the browser heard.
            // Both are guesses, both are the candidate's to correct before
            // anything is scored — offering the better-populated one is a
            // convenience, not a change to what counts as evidence.
            //
            // Except for two refusals, where there must be no fallback at all:
            // `no_speech_detected` has nothing to correct, and
            // `audio_source_rejected` means the audio WAS the interview's own
            // question — the browser's caption of it is the question too, and
            // pre-filling that would invite the candidate to submit our words
            // as their answer.
            const noDraft = res.code === "no_speech_detected" || res.code === "audio_source_rejected";
            const draft = noDraft ? "" : res.draft_transcript || heard;
            setTypedAnswer(draft);
            setDraftFromSpeech(Boolean(draft));
            setDraftEdited(false);
            setShowTyped(true);
            setPhase("reviewing");
          } else if (res.answered === false && res.clarification) {
            // (§3) They asked to hear the question again rather than answering
            // it. The live preview was of that request, not of an answer, so it
            // is dropped: leaving it in the thread would show a one-line
            // "answer" that was never submitted or scored.
            const liveId = liveTurnRef.current;
            if (liveId) setTurns((prev) => prev.filter((t) => t.id !== liveId));
            liveTurnRef.current = null;
            resetDraft();
            setPhase("asking");
            void speakLine(
              pushInterviewerTurn("clarification", res.clarification.text),
              res.clarification.text,
              res.clarification.audio_url,
            );
          } else {
            settleCandidateTurn(res.transcript ?? heard, res.evaluation?.grade);
            setTypedAnswer("");

            if (res.follow_up) {
              setAcknowledgment(null);
              setFollowUp({
                answer_id: String(res.answer_id),
                text: String(res.follow_up.text),
                audio_url: res.follow_up.audio_url,
              });
              setPhase("asking");
              void speakLine(pushInterviewerTurn("follow_up", res.follow_up.text), res.follow_up.text, res.follow_up.audio_url);
            } else {
              // (§1) On this route the acknowledgment came back with everything
              // else rather than ahead of it, so it is shown rather than
              // spoken: it is already stale as audio, but it still labels the
              // wait for the next question with what the interviewer said.
              setAcknowledgment(res.acknowledgment?.text ?? null);
              setPhase("thinking");
              send({ type: "next_question" });
            }
          }
        } catch (err) {
          console.error("Audio submission failed:", err);
          setError("Could not send audio. You can type your answer instead.");
          setTypedAnswer((current) => current || heard);
          setShowTyped(true);
          setPhase("answering");
        }
      };

      recorder.start();
      mediaRecorderRef.current = recorder;
      setRecordedMs(0);
      setRecording(true);
    } catch {
      setError("Could not access microphone. You can type your answer instead.");
      setShowTyped(true);
    }
  }

  function stopRecording(): void {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === "recording") {
      mediaRecorderRef.current.stop();
    }
  }

  /** Stops the recording AND throws it away — nothing is submitted or scored. */
  function abortRecording(): void {
    abortedRef.current = true;
    // The live preview goes with it: it was a preview of a recording that is
    // not being sent, and leaving it in the thread would show an answer the
    // candidate never gave.
    const liveId = liveTurnRef.current;
    if (liveId) setTurns((prev) => prev.filter((t) => t.id !== liveId));
    liveTurnRef.current = null;
    stopRecording();
  }

  /** Throw the draft away and record the answer again from scratch. */
  function reRecord(): void {
    // The abandoned preview goes with the draft — leaving it in the thread
    // would show a first attempt the candidate explicitly discarded.
    const liveId = liveTurnRef.current;
    if (liveId) setTurns((prev) => prev.filter((t) => t.id !== liveId));
    liveTurnRef.current = null;
    resetDraft();
    setPhase("answering");
    void startRecording();
  }

  function submitTyped(): void {
    if (typedAnswer.trim() === "") return;
    send({
      type: followUp ? "submit_follow_up_text" : "submit_answer_text",
      question_id: question?.id,
      answer_id: followUp?.answer_id,
      follow_up_text: followUp?.text,
      transcript: typedAnswer,
    });
    settleCandidateTurn(typedAnswer);
    setShowTyped(false);
    setRetryNotice(null);
    setPhase("thinking");
  }

  // ------------------------------------------------------------------- view

  if (phase === "done") {
    return (
      // Same wide column as the live stage below, so the page does not reflow
      // from 80rem to 46rem at the moment the interview ends.
      <div data-layout="wide" className="relative space-y-6">
        <CelestialBackdrop />
        <StatusBar
          phase={phase}
          recording={false}
          elapsed={elapsed}
          remaining={remaining}
          isFullscreen={isFullscreen}
          onToggleFullscreen={toggleFullscreen}
          focusExitCount={focusExitCount}
        />
        <Card>
          <CardContent className="flex flex-col items-center gap-3 py-10 text-center">
            <CheckCircle2 className="size-7 text-ok" aria-hidden="true" />
            <div className="space-y-1" role="status" aria-live="polite">
              <p className="text-lg font-semibold">
                {concludedEarly ? "The interview ended early" : "That's the session"}
              </p>
              <p className="max-w-prose text-sm text-muted-foreground">
                {concludedEarly
                  ? `This session was concluded after you left fullscreen more than ${EXIT_LIMIT} times. Your feedback is being put together for what you did cover.`
                  : "Your feedback is being put together from what you said."}
              </p>
            </div>
            <p className="flex items-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="size-4 animate-spin" aria-hidden="true" />
              Taking you to your report…
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    // (UI change #3) `data-layout="wide"` opts this page into the 80rem column
    // (`globals.css`'s `.mia-main:has([data-layout="wide"])`, the same mechanism
    // the admin pages use) instead of inheriting the 46rem reading measure.
    //
    // That measure is what made the two panels nearly touch: it is sized for
    // prose, and 38% + 38% of 736px leaves ~166px between them for the backdrop
    // ring. The panels' own percentages were never the problem, the column was.
    <div data-layout="wide" className="relative space-y-5">
      <CelestialBackdrop />
      <StatusBar
        phase={phase}
        recording={recording}
        elapsed={elapsed}
        remaining={remaining}
        isFullscreen={isFullscreen}
        onToggleFullscreen={toggleFullscreen}
        focusExitCount={focusExitCount}
      />

      {error ? <InlineError>{error}</InlineError> : null}

      {/* Fullscreen exits are consequential (they can end the session), so this
          one stays a persistent banner rather than a toast, and carries the
          running count against the limit. */}
      {focusExitCount > 0 || focusNotice ? (
        <Alert variant="warn">
          <AlertTriangle aria-hidden="true" />
          <AlertTitle>
            {focusExitCount > 0
              ? `Left fullscreen ${focusExitCount} of ${EXIT_LIMIT} times`
              : "You left fullscreen"}
          </AlertTitle>
          <AlertDescription>
            <p>{focusNotice ?? `Leaving more than ${EXIT_LIMIT} times ends the interview early.`}</p>
          </AlertDescription>
        </Alert>
      ) : null}

      {/* The stage: speech to the left, transcription to the right, both
          vertically centered, with the backdrop ring centered in the gap
          between them. Below `lg` there is no left/right to pin to, so it falls
          back to a plain stack, speech first.

          Each side is bounded at both ends rather than left as a bare
          percentage of whatever the column happens to be. `max-w` stops a panel
          growing until it crowds the ring again on an ultrawide monitor, and
          the small inset keeps text off the true edge.

          The percentage steps at `xl` because the wide column alone does not
          fix the narrow end of `lg`. Measured, as a gap for the ring: 1024px
          went 165px -> 195px on the wider column alone, which is the same
          cramped look one breakpoint further out; 34% at `lg` makes it 273px,
          and 38% capped at 26rem holds it at 351px from 1280px up. The old
          number was never wrong for a wide viewport — it was wrong for the one
          case where both panels and the ring have to share 976px.

          The ring itself needs nothing: `CelestialBackdrop` is `fixed` and
          sized off the viewport, not this column, so a wider stage simply gives
          it more room to be seen. */}
      <div className="relative flex flex-col gap-5 lg:block lg:min-h-[64vh]">
        <div className="lg:absolute lg:left-[2%] lg:top-1/2 lg:z-0 lg:w-[34%] lg:max-w-[26rem] lg:-translate-y-1/2 xl:w-[38%]">
          <SpeechPanel turns={turns} phase={phase} revealingTurnId={revealingTurnId} spokenFraction={spokenFraction} acknowledgment={acknowledgment} />
        </div>

        <div className="lg:absolute lg:right-[2%] lg:top-1/2 lg:z-10 lg:w-[34%] lg:max-w-[26rem] lg:-translate-y-1/2 xl:w-[38%]">
          <TranscriptionPanel turns={turns}>
            <AnswerPanel
              phase={phase}
              recording={recording}
              recordedMs={recordedMs}
              retryNotice={retryNotice}
              silenceNotice={silenceNotice}
              heardSpeech={heardSpeech}
              showTyped={showTyped}
              typedAnswer={typedAnswer}
              draftFromSpeech={draftFromSpeech}
              draftEdited={draftEdited}
              onStartRecording={() => void startRecording()}
              onStopRecording={stopRecording}
              onReRecord={reRecord}
              onToggleTyped={() => setShowTyped(!showTyped)}
              onChangeTyped={(value) => {
                setTypedAnswer(value);
                setDraftEdited(true);
              }}
              onSubmit={submitTyped}
              onSkip={() => send({ type: "next_question", advance: true })}
              streamRef={streamRef}
            />
          </TranscriptionPanel>
        </div>
      </div>

      {/* Quiet, and clear of the glass panels above: an ending action reads as
          a decision, not a smudge, so it stays on the page's own solid
          surface rather than the frosted stage. */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border bg-card/80 px-4 py-3 backdrop-blur-md supports-[backdrop-filter]:bg-card/65 sm:px-6">
        <Notice>You can stop whenever you like — you will still get feedback on what you have done.</Notice>
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button type="button" variant="ghost" size="sm" className="text-muted-foreground">
              End the interview
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>End the interview now?</AlertDialogTitle>
              <AlertDialogDescription>
                You will get a report on the questions you have answered so far. The session cannot be
                resumed afterwards.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Keep going</AlertDialogCancel>
              <AlertDialogAction onClick={() => send({ type: "end_session" })}>
                End and get my feedback
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- status bar

const PHASE_COPY: Record<Phase, { label: string; hint: string }> = {
  idle: { label: "Connecting", hint: "Setting up the interview." },
  asking: { label: "Interviewer is speaking", hint: "Listen — your turn comes next." },
  answering: { label: "Your turn", hint: "Answer out loud, or type it." },
  transcribing: { label: "Writing down what you said", hint: "Nothing is scored yet." },
  reviewing: { label: "Read it back", hint: "Fix anything wrong, then send." },
  thinking: { label: "Considering your answer", hint: "One moment." },
  coding: { label: "Coding round", hint: "" },
  done: { label: "Finished", hint: "" },
};

/**
 * Phase, pacing and the fullscreen control, pinned under the app bar.
 *
 * The phase label is the answer to "is it me or the app right now?", which the
 * old page only implied through which button happened to be disabled. It is an
 * aria-live region, so a candidate using a screen reader hears the handover
 * instead of having to go looking for it.
 */
function StatusBar({
  phase,
  recording,
  elapsed,
  remaining,
  isFullscreen,
  onToggleFullscreen,
  focusExitCount,
}: {
  phase: Phase;
  recording: boolean;
  elapsed: number;
  remaining: number | null;
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  focusExitCount: number;
}) {
  const copy = PHASE_COPY[phase];
  const speaking = phase === "asking";
  const working = phase === "transcribing" || phase === "thinking";

  return (
    // `top-3` rather than the `top-[4.5rem]` this used to carry: that offset
    // existed to clear the sticky `SiteHeader` pill, and the room no longer
    // renders one, so the strip now docks where the header used to sit instead
    // of leaving 4.5rem of dead space above itself.
    <div className="sticky top-3 z-30 rounded-xl border bg-card/80 px-4 py-2.5 shadow-lg shadow-black/[0.04] backdrop-blur-md supports-[backdrop-filter]:bg-card/65 sm:px-6">
      <div className="flex flex-wrap items-center justify-between gap-x-4 gap-y-2">
        <div className="flex min-w-0 items-center gap-2.5" role="status" aria-live="polite">
          {recording ? (
            <span className="flex size-5 shrink-0 items-center justify-center">
              <span className="size-2.5 rounded-full bg-destructive" />
            </span>
          ) : speaking ? (
            <Volume2 className="size-5 shrink-0 text-primary" aria-hidden="true" />
          ) : working ? (
            <Loader2 className="size-5 shrink-0 animate-spin text-muted-foreground" aria-hidden="true" />
          ) : phase === "answering" ? (
            <Mic className="size-5 shrink-0 text-ok" aria-hidden="true" />
          ) : phase === "reviewing" ? (
            <PencilLine className="size-5 shrink-0 text-primary" aria-hidden="true" />
          ) : (
            <ClipboardCheck className="size-5 shrink-0 text-muted-foreground" aria-hidden="true" />
          )}

          <span className="min-w-0">
            <span
              className={cn(
                "block truncate text-sm font-medium leading-tight",
                recording && "text-destructive",
                speaking && "text-primary",
                phase === "answering" && "text-ok",
              )}
            >
              {/* The live duration lives on the answer panel's own indicator;
                  duplicating a ticking clock here would be two things to watch. */}
              {recording ? "Recording" : copy.label}
            </span>
            {copy.hint && !recording ? (
              <span className="block truncate text-xs text-muted-foreground">{copy.hint}</span>
            ) : null}
            {recording ? (
              <span className="block truncate text-xs text-muted-foreground">
                Take as long as you need.
              </span>
            ) : null}
          </span>
        </div>

        <div className="flex shrink-0 items-center gap-2">
          {/* soul.md §3, inherited from `SiteHeader`, which does not render on
              this route. It is not a status field and does not belong in the
              live region on the left — it never changes — so it sits here as
              plain standing text. Hidden below `sm` only because the strip is
              already three-deep on a phone; the candidate crossed the
              telemetry-check page, which still carries the bar, to get here. */}
          <span className="hidden text-xs text-muted-foreground sm:inline">{SAFETY_DISCLAIMER}</span>
          {focusExitCount > 0 ? (
            <Badge variant="warn" title="Times you have left fullscreen this session">
              {focusExitCount}/{EXIT_LIMIT} exits
            </Badge>
          ) : null}
          <Pacing elapsed={elapsed} remaining={remaining} />
          <Button
            type="button"
            variant="ghost"
            size="icon-sm"
            onClick={onToggleFullscreen}
            aria-label={isFullscreen ? "Leave fullscreen" : "Enter fullscreen"}
            title={isFullscreen ? "Leave fullscreen" : "Enter fullscreen"}
          >
            {isFullscreen ? <Minimize2 /> : <Maximize2 />}
          </Button>
        </div>
      </div>
    </div>
  );
}

/**
 * Elapsed time, and how much of the planned session is left.
 *
 * `remaining_ms` was already on every `timer_tick` and this page threw it away,
 * so there was no way to pace an answer. soul.md §4 gives the Time Tracking
 * Agent's register — "firm but unobtrusive. Nudges, doesn't nag; a countdown
 * should inform pacing, not manufacture stress." So: no colour change as the
 * bar fills, no animation, no red. Running over is stated plainly and ends
 * nothing.
 */
function Pacing({ elapsed, remaining }: { elapsed: number; remaining: number | null }) {
  if (remaining === null) {
    return (
      <span className="font-mono text-sm tabular-nums text-muted-foreground" aria-label="Time elapsed">
        {formatElapsed(elapsed)}
      </span>
    );
  }

  const budget = elapsed + remaining;
  const pct = budget > 0 ? Math.min(100, Math.max(0, (elapsed / budget) * 100)) : 0;
  const over = remaining < 0;
  const minutesLeft = Math.max(0, Math.round(remaining / 60000));

  return (
    <span className="flex items-center gap-2">
      <span
        className="hidden sm:block"
        title={over ? "Over the planned time" : `About ${minutesLeft} min left`}
      >
        <PacingRing pct={pct} over={over} />
      </span>
      <span className="font-mono text-sm tabular-nums text-muted-foreground">
        {formatElapsed(elapsed)}
        <span className="hidden sm:inline">
          {" · "}
          {over ? "over time" : `${minutesLeft}m left`}
        </span>
      </span>
    </span>
  );
}

/**
 * The pacing ring — a circular readout instead of the old flat bar, still
 * governed by the exact same rule (soul.md §4, see the file header comment):
 * never red, never an urgent pulse as time runs out. `over` swaps the stroke
 * to `--warn` (amber) and stops the ring at a full circle; nothing about the
 * transition speeds up or animates more aggressively near the deadline —
 * only the one calm colour change.
 */
function PacingRing({ pct, over }: { pct: number; over: boolean }) {
  const size = 28;
  const stroke = 3;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const offset = c * (1 - (over ? 1 : pct / 100));

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="-rotate-90" aria-hidden="true">
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--border)" strokeWidth={stroke} />
      <circle
        cx={size / 2}
        cy={size / 2}
        r={r}
        fill="none"
        stroke={over ? "var(--warn)" : "var(--primary)"}
        strokeWidth={stroke}
        strokeLinecap="round"
        strokeDasharray={c}
        strokeDashoffset={offset}
        style={{ transition: "stroke-dashoffset 0.6s ease, stroke 0.6s ease" }}
      />
    </svg>
  );
}

// ------------------------------------------------------------- stage panels

/**
 * Frosted-glass chrome shared by both stage panels: a blurred, translucent
 * surface rather than an opaque card, so the animated ring behind it bleeds
 * through instead of stopping dead at a box edge — the "smudge" is the
 * backdrop-blur plus a background low enough in opacity to still show motion
 * through it. `glow` is the same speaking-indicator the panel used to get
 * from its old `Card`, just now a parameter instead of a fixed class.
 */
function StageGlass({ glow, children }: { glow?: boolean; children: React.ReactNode }) {
  return (
    <div
      className={cn(
        "overflow-hidden rounded-2xl border border-border/50 bg-background/35 shadow-2xl shadow-black/10 backdrop-blur-xl backdrop-saturate-150 transition-[border-color,box-shadow] duration-500 supports-[backdrop-filter]:bg-background/20 dark:border-white/10",
        glow && "border-primary/50 shadow-glow",
      )}
    >
      {children}
    </div>
  );
}

/**
 * Scroll-pins a panel to its own bottom as `trigger` changes, unless the
 * candidate has deliberately scrolled up to re-read something earlier —
 * auto-scrolling past that is the reason "jump to latest" buttons exist. Each
 * stage panel scrolls independently, so this is one hook shared by both
 * rather than duplicated logic.
 */
function useAutoScrollPin(trigger: string | number) {
  const scrollerRef = useRef<HTMLDivElement | null>(null);
  const pinnedRef = useRef(true);

  const onScroll = useCallback(() => {
    const el = scrollerRef.current;
    if (!el) return;
    pinnedRef.current = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
  }, []);

  useEffect(() => {
    const el = scrollerRef.current;
    if (!el || !pinnedRef.current) return;
    el.scrollTo({ top: el.scrollHeight, behavior: prefersReducedMotion() ? "auto" : "smooth" });
    // `trigger` is a single value that changes on every new word revealed or
    // turn added — see the callers for what it's built from.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [trigger]);

  return { scrollerRef, onScroll };
}

/**
 * Left-center: the interviewer's speech, and nothing else. Only interviewer
 * turns — questions and follow-ups — so the panel is exactly what its name
 * says, with the current line still revealed in step with the voice.
 */
function SpeechPanel({
  turns,
  phase,
  revealingTurnId,
  spokenFraction,
  acknowledgment,
}: {
  turns: Turn[];
  phase: Phase;
  revealingTurnId: string | null;
  spokenFraction: number;
  acknowledgment: string | null;
}) {
  const interviewerTurns = useMemo(() => {
    const all = turns.filter((t): t is Extract<Turn, { role: "interviewer" }> => t.role === "interviewer");
    // Only show the current question group: find the last "question" turn and
    // return it plus any follow-ups / clarifications / greetings that follow it.
    let lastQuestionIdx = -1;
    for (let i = all.length - 1; i >= 0; i--) {
      if (all[i].kind === "question") {
        lastQuestionIdx = i;
        break;
      }
    }
    return lastQuestionIdx >= 0 ? all.slice(lastQuestionIdx) : all;
  }, [turns]);
  const { scrollerRef, onScroll } = useAutoScrollPin(`${interviewerTurns.length}-${spokenFraction}`);

  return (
    <StageGlass glow={phase === "asking"}>
      <div className="flex items-center justify-between border-b border-border/50 px-5 py-3">
        <h2 className="text-sm font-medium text-muted-foreground">Interviewer</h2>
      </div>

      <div
        ref={scrollerRef}
        onScroll={onScroll}
        className="max-h-[min(52vh,36rem)] space-y-5 overflow-y-auto px-5 py-5"
        // Every new line is announced, so the thread is followable without
        // sight — the same handover the status bar announces, in content form.
        aria-live="polite"
      >
        {interviewerTurns.length === 0 ? (
          <p className="font-display text-xl leading-snug tracking-tight text-muted-foreground">
            Waiting for the first question…
          </p>
        ) : null}

        {interviewerTurns.map((turn) => (
          <InterviewerTurn
            key={turn.id}
            turn={turn}
            revealing={turn.id === revealingTurnId}
            fraction={turn.id === revealingTurnId ? spokenFraction : 1}
          />
        ))}

        {phase === "thinking" ? <ThinkingBeat acknowledgment={acknowledgment} /> : null}
      </div>
    </StageGlass>
  );
}

/**
 * The gap between the interviewer's "mm-hm" and their actual next line
 * (HUMAN_INTERACTION_FLOW.md §1).
 *
 * Before the two-stage response, this gap was silence with nothing on screen,
 * and it read as the app having hung. It is a real pause now — the score and
 * the next question are genuinely being worked out — so it gets shown as one.
 *
 * The acknowledgment is set apart from the transcript deliberately: it is a
 * noise the interviewer made, not a line of the interview, and it disappears
 * when the real response arrives rather than staying in the thread.
 */
function ThinkingBeat({ acknowledgment }: { acknowledgment: string | null }) {
  return (
    <p className="flex items-baseline gap-2 text-muted-foreground" role="status" aria-live="polite">
      {acknowledgment ? <span className="font-display text-xl leading-snug tracking-tight">{acknowledgment}</span> : null}
      <span className="text-sm">
        Thinking
        {/* Three dots on a staggered fade rather than a spinner: a spinner reads
            as loading, and this is a person taking a moment. `motion-reduce`
            leaves them static, per the reduced-motion rule in globals.css. */}
        <span className="ml-0.5 inline-flex">
          {[0, 1, 2].map((i) => (
            <span key={i} className="animate-pulse motion-reduce:animate-none" style={{ animationDelay: `${i * 180}ms` }}>
              .
            </span>
          ))}
        </span>
      </span>
    </p>
  );
}

/**
 * Right-center: the candidate's transcription — every answer given so far,
 * with the live recognition preview on top — and, beneath it, the controls
 * that act on exactly that text (`children`, always the `AnswerPanel`). They
 * stay in one panel because they are one concern: this is where the
 * candidate's words become the record.
 */
function TranscriptionPanel({ turns, children }: { turns: Turn[]; children: React.ReactNode }) {
  // Only what has been said since the interviewer last spoke — see
  // `lib/room-turns.ts` for why this panel is scoped and `SpeechPanel` is not.
  // `turns` still holds the full history; this is a view filter and nothing
  // about scoring, `attachGrade`, `settleCandidateTurn` or what reaches the
  // backend reads it.
  const candidateTurns = useMemo(() => answersForCurrentPrompt(turns), [turns]);
  const lastTurn = candidateTurns[candidateTurns.length - 1];
  const liveText = lastTurn?.live ? `${lastTurn.text}${lastTurn.interim ?? ""}` : "";
  const { scrollerRef, onScroll } = useAutoScrollPin(`${candidateTurns.length}-${liveText}`);

  // Checked after mount, never during render: `dictationSupported()` reads
  // `window`, so asking during the server pass would render one thing on the
  // server and another on the client and trip hydration.
  const [captionsUnavailable, setCaptionsUnavailable] = useState(false);
  useEffect(() => setCaptionsUnavailable(!dictationSupported()), []);

  return (
    <StageGlass>
      <div className="flex items-center justify-between border-b border-border/50 px-5 py-3">
        <h2 className="text-sm font-medium text-muted-foreground">Your transcription</h2>
        {captionsUnavailable ? (
          // Said once, plainly, rather than leaving an empty preview panel
          // that reads as a broken mic. The recording itself is unaffected.
          <span className="text-xs text-muted-foreground">Live captions unavailable in this browser</span>
        ) : null}
      </div>

      <div
        ref={scrollerRef}
        onScroll={onScroll}
        className="max-h-[min(34vh,22rem)] space-y-5 overflow-y-auto px-5 py-5"
        aria-live="polite"
      >
        {candidateTurns.length === 0 ? (
          <p className="text-sm text-muted-foreground">Your answer will appear here as you speak or type.</p>
        ) : null}

        {candidateTurns.map((turn) => (
          <CandidateTurn key={turn.id} turn={turn} />
        ))}
      </div>

      <div className="border-t border-border/50 px-5 py-4">{children}</div>
    </StageGlass>
  );
}

/**
 * One interviewer line, revealed in step with the voice.
 *
 * The un-spoken remainder is rendered at very low opacity rather than removed,
 * so the paragraph does not reflow word by word — a line that jumps as it
 * fills is harder to read than one that simply brightens. It is also still
 * fully present in the DOM, which is what keeps the whole question available
 * to a screen reader and to select-and-copy rather than dribbling out.
 */
function InterviewerTurn({
  turn,
  revealing,
  fraction,
}: {
  turn: Extract<Turn, { role: "interviewer" }>;
  revealing: boolean;
  fraction: number;
}) {
  const words = useMemo(() => turn.text.split(/(\s+)/), [turn.text]);
  const spokenUpTo = Math.round(turn.text.length * fraction);

  const ref = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    if (!ref.current || prefersReducedMotion()) return;
    gsap.fromTo(ref.current, { opacity: 0, y: 6 }, { opacity: 1, y: 0, duration: 0.4, ease: "power2.out" });
  }, []);

  let cursor = 0;

  return (
    <div ref={ref} className="space-y-2">
      <div className="flex flex-wrap items-center gap-2">
        {turn.kind === "follow_up" ? (
          <Badge variant="secondary" className="font-normal">
            <CornerDownRight className="size-3" aria-hidden="true" />
            Follow-up
          </Badge>
        ) : turn.kind === "clarification" ? (
          // (§3) Labelled apart from a fresh question so the thread does not
          // read as the interview having asked two things. Nothing was scored
          // and no turn was spent — this is the same question, said again.
          <Badge variant="outline" className="font-normal">
            <Repeat className="size-3" aria-hidden="true" />
            Asked again
          </Badge>
        ) : turn.kind === "greeting" ? (
          // (§8) Explicitly not a question. Without a label the opening line
          // sits at the top of the thread looking like the first thing the
          // candidate was asked, and they answer it.
          <Badge variant="outline" className="font-normal">
            <Handshake className="size-3" aria-hidden="true" />
            Welcome
          </Badge>
        ) : null}
        {revealing ? (
          <span className="flex items-center gap-1.5 text-xs text-primary">
            <Volume2 className="size-3.5 animate-pulse" aria-hidden="true" />
            Speaking
          </span>
        ) : null}
      </div>

      <p className="font-display text-xl leading-snug tracking-tight">
        {words.map((word, i) => {
          const start = cursor;
          cursor += word.length;
          const spoken = !revealing || start < spokenUpTo;
          return (
            <span
              key={i}
              className={cn("transition-opacity duration-300", spoken ? "opacity-100" : "opacity-15")}
            >
              {word}
            </span>
          );
        })}
      </p>
    </div>
  );
}

/**
 * One answer. While it is live this is the recogniser's running preview, with
 * the in-flight guess held apart from the text it has settled on — a word that
 * is about to change must not look like one the candidate said.
 */
function CandidateTurn({ turn }: { turn: Extract<Turn, { role: "candidate" }> }) {
  const empty = !turn.text.trim() && !turn.interim?.trim();

  return (
    <div className={cn("space-y-1.5 border-l-2 pl-4", turn.live ? "border-destructive/60" : "border-border")}>
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs font-medium text-muted-foreground">You</span>
        {turn.live ? (
          <span className="flex items-center gap-1.5 text-xs text-destructive">
            <span className="size-1.5 animate-pulse rounded-full bg-destructive" aria-hidden="true" />
            Listening
          </span>
        ) : null}
        {turn.grade ? <GradeBadge grade={turn.grade} /> : null}
      </div>

      <p className={cn("text-sm leading-relaxed", turn.live ? "text-foreground" : "italic text-muted-foreground")}>
        {empty ? (
          <span className="text-muted-foreground">{turn.live ? "Listening…" : "—"}</span>
        ) : (
          <>
            {turn.text}
            {turn.interim ? <span className="text-muted-foreground"> {turn.interim}</span> : null}
          </>
        )}
      </p>
    </div>
  );
}

/**
 * A grade, as assigned by the Eval Tool.
 *
 * Deliberately small and neutral: this is practice, and a letter that shouts
 * during the interview would change how the next answer gets given. The score
 * it was banded from is always in the tooltip, because a letter with no number
 * behind it invites being read as a verdict rather than a measurement
 * (soul.md §3).
 */
function GradeBadge({ grade }: { grade: Grade }) {
  return (
    <Badge
      variant={grade.isStrength ? "outline" : "muted"}
      className={cn("font-normal", grade.isStrength && "border-ok/40 text-ok")}
      title={`${grade.score.toFixed(1)} / 5 — ${grade.descriptor}`}
    >
      {grade.letter} · {grade.label}
    </Badge>
  );
}

// --------------------------------------------------------------- answer panel

function AnswerPanel({
  phase,
  recording,
  recordedMs,
  retryNotice,
  silenceNotice,
  heardSpeech,
  showTyped,
  typedAnswer,
  draftFromSpeech,
  draftEdited,
  onStartRecording,
  onStopRecording,
  onReRecord,
  onToggleTyped,
  onChangeTyped,
  onSubmit,
  onSkip,
  streamRef,
}: {
  phase: Phase;
  recording: boolean;
  recordedMs: number;
  retryNotice: string | null;
  silenceNotice: string | null;
  heardSpeech: boolean;
  showTyped: boolean;
  typedAnswer: string;
  draftFromSpeech: boolean;
  draftEdited: boolean;
  onStartRecording: () => void;
  onStopRecording: () => void;
  onReRecord: () => void;
  onToggleTyped: () => void;
  onChangeTyped: (value: string) => void;
  onSubmit: () => void;
  onSkip: () => void;
  streamRef: RefObject<MediaStream | null>;
}) {
  const canRecord = phase === "answering" || phase === "reviewing";

  return (
    <div className="space-y-4">
      {retryNotice ? <InlineError>{retryNotice}</InlineError> : null}

      {/* A recording abandoned for having no sound in it. A warning rather than
          an error: nothing failed and nothing was lost — the microphone was off
          (`lib/mic.ts`, `SILENCE_TIMEOUT_MS`). */}
      {silenceNotice ? (
        <Alert variant="warn">
          <MicOff aria-hidden="true" />
          <AlertTitle>No sound was picked up</AlertTitle>
          <AlertDescription>
            <p>{silenceNotice}</p>
          </AlertDescription>
        </Alert>
      ) : null}

        <div className="flex flex-wrap items-center gap-2">
          {recording ? (
            <>
              <Button type="button" size="lg" onClick={onStopRecording}>
                <Square aria-hidden="true" />
                Stop and transcribe
              </Button>
              <span
                className="flex items-center gap-2 font-mono text-sm tabular-nums text-destructive"
                aria-live="polite"
              >
                <span className="size-2 animate-pulse rounded-full bg-destructive" aria-hidden="true" />
                Recording {formatElapsed(recordedMs)}
              </span>
              {/* Whether the microphone is actually hearing anything, from the
                  same watcher that will stop the recording when they finish.
                  A candidate whose mic is muted otherwise finds out only after
                  they have said their whole answer. */}
              <span className="flex items-center gap-1.5 text-sm text-muted-foreground" aria-live="polite">
                {heardSpeech ? (
                  <>
                    <Mic className="size-3.5 text-ok" aria-hidden="true" />
                    Hearing you
                  </>
                ) : (
                  <>
                    <MicOff className="size-3.5 text-warn" aria-hidden="true" />
                    Waiting for sound…
                  </>
                )}
              </span>
            </>
          ) : (
            <Button
              type="button"
              size="lg"
              // From `reviewing` this discards the draft first, so the old
              // text is never left on screen under a new recording.
              onClick={phase === "reviewing" ? onReRecord : onStartRecording}
              disabled={!canRecord}
            >
              <Mic aria-hidden="true" />
              {phase === "asking"
                ? "Listen first…"
                : phase === "transcribing"
                  ? "Transcribing…"
                  : phase === "thinking"
                    ? "One moment…"
                    : phase === "reviewing"
                      ? "Record again"
                      : "Answer out loud"}
            </Button>
          )}

          {/* Always available, never a punishment for the mic failing. */}
          {!recording && phase !== "reviewing" ? (
            <Button type="button" variant="outline" onClick={onToggleTyped}>
              <PencilLine aria-hidden="true" />
              {showTyped ? "Hide typing" : "Type instead"}
            </Button>
          ) : null}

          {!recording ? (
            <Button
              type="button"
              variant="ghost"
              className="ml-auto text-muted-foreground"
              onClick={onSkip}
            >
              <SkipForward aria-hidden="true" />
              Skip
            </Button>
          ) : null}
        </div>

        {recording ? (
          <>
            <RecordingWaveform streamRef={streamRef} active={recording} />
            <Notice>
              The recording keeps going until you stop it. What you say appears on the left as you speak —
              that is a preview only. Nothing is sent or scored until you have read it back and pressed send.
            </Notice>
          </>
        ) : null}

        {phase === "transcribing" ? (
          <p className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="size-4 animate-spin" aria-hidden="true" />
            Writing down what you said…
          </p>
        ) : null}

        {showTyped ? (
          <div className="space-y-2 border-t pt-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <label htmlFor="typed" className="text-sm font-medium">
                {draftFromSpeech ? "What we heard — correct anything that is wrong" : "Your answer"}
              </label>
              {draftFromSpeech && draftEdited ? (
                <Badge variant="muted">edited</Badge>
              ) : null}
            </div>

            {draftFromSpeech && !retryNotice ? (
              <Notice>
                This is a transcription, so it can get words wrong. Edit it freely — the text below is
                what gets scored, not the recording.
              </Notice>
            ) : null}

            <Textarea
              id="typed"
              value={typedAnswer}
              onChange={(e) => onChangeTyped(e.target.value)}
              rows={6}
              className="min-h-32"
              // A recogniser that returned nothing must not leave an
              // unexplained empty box after a long answer.
              placeholder={
                draftFromSpeech
                  ? "Nothing was made out — type your answer, or record it again."
                  : "Type your answer here"
              }
            />

            <div className="flex flex-wrap items-center gap-2">
              <Button type="button" onClick={onSubmit} disabled={typedAnswer.trim() === ""}>
                <Send aria-hidden="true" />
                Send answer
              </Button>
              {draftFromSpeech ? (
                <Button type="button" variant="outline" onClick={onReRecord}>
                  Discard and record again
                </Button>
              ) : null}
            </div>
          </div>
        ) : null}
    </div>
  );
}

/**
 * A real per-band waveform read from the same mic stream `MediaRecorder` is
 * capturing — a second `AnalyserNode` on the same `MediaStream`, not a
 * decorative loop. Entirely visual: wrapped in try/catch and cleaned up on
 * its own, so a failure here (or a browser without `AudioContext`) never
 * touches the actual record → transcribe → submit path above.
 */
function RecordingWaveform({
  streamRef,
  active,
}: {
  streamRef: RefObject<MediaStream | null>;
  active: boolean;
}) {
  const BAR_COUNT = 28;
  const barsRef = useRef<(HTMLSpanElement | null)[]>([]);

  useEffect(() => {
    if (!active || !streamRef.current) return;
    let raf = 0;
    let ctx: AudioContext | null = null;

    try {
      ctx = new AudioContext();
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 64;
      ctx.createMediaStreamSource(streamRef.current).connect(analyser);
      const data = new Uint8Array(analyser.frequencyBinCount);
      const step = Math.max(1, Math.floor(data.length / BAR_COUNT));

      const tick = () => {
        analyser.getByteFrequencyData(data);
        for (let i = 0; i < BAR_COUNT; i++) {
          const value = data[i * step] ?? 0;
          const pct = Math.max(8, Math.min(100, Math.round((value / 255) * 100)));
          const bar = barsRef.current[i];
          if (bar) bar.style.height = `${pct}%`;
        }
        raf = requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
    } catch {
      // Visual only — the recording itself does not depend on this.
    }

    return () => {
      cancelAnimationFrame(raf);
      if (ctx && ctx.state !== "closed") void ctx.close();
    };
  }, [active, streamRef]);

  return (
    <div className="flex h-10 items-end gap-[3px]" aria-hidden="true">
      {Array.from({ length: BAR_COUNT }).map((_, i) => (
        <span
          key={i}
          ref={(el) => {
            barsRef.current[i] = el;
          }}
          className="w-1 flex-1 rounded-full bg-destructive/60 transition-[height] duration-75 ease-out"
          style={{ height: "8%" }}
        />
      ))}
    </div>
  );
}

function formatElapsed(ms: number): string {
  const total = Math.floor(ms / 1000);
  return `${String(Math.floor(total / 60)).padStart(2, "0")}:${String(total % 60).padStart(2, "0")}`;
}

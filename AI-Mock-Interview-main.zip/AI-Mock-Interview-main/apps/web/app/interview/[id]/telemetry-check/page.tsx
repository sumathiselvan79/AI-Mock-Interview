"use client";

/**
 * Telemetry Check page — the `TELEMETRY_CHECK` state (`INSTRUCTIONS.md §3.1`).
 *
 * Two jobs: confirm the mic and speaker work, and capture consent.
 *
 * The consent part is the one that matters most (soul.md §"Consent-first
 * monitoring"). Each item says in plain language what is watched and why, none
 * of them is required to start the interview, and nothing here is pre-ticked —
 * a pre-ticked box is not consent. A single "accept all" checkbox is offered
 * alongside the list as a convenience for candidates happy with every option;
 * it is not itself pre-checked and does not stand in for reading the list.
 */

import { useCallback, useEffect, useRef, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import {
  AudioLines,
  Check,
  Loader2,
  Mic,
  Play,
  ShieldCheck,
  Volume2,
} from "lucide-react";
import { api, ApiCallError } from "@/lib/api";
import { InlineError, Notice, Page, PageHeader } from "@/app/components/shell";
import { InterviewSteps } from "@/app/components/interview-steps";
import { useReveal } from "@/lib/motion";
import { Badge } from "@/app/components/ui/badge";
import { Button } from "@/app/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/app/components/ui/card";
import { Checkbox } from "@/app/components/ui/checkbox";
import { Label } from "@/app/components/ui/label";
import { Switch } from "@/app/components/ui/switch";
import { cn } from "@/lib/utils";

interface ConsentState {
  telemetry: boolean;
  clipboardMonitor: boolean;
  audioRecording: boolean;
  crossSessionMemory: boolean;
  focusLossMonitoring: boolean;
}

const CONSENT_COPY: { key: keyof ConsentState; label: string; explanation: string }[] = [
  {
    key: "telemetry",
    label: "Detailed session telemetry",
    explanation:
      "Timings and event counts — how long you took per question, when a follow-up happened. Never the words you said.",
  },
  {
    key: "clipboardMonitor",
    label: "Paste detection during the coding round",
    explanation:
      "Records that a paste happened and when. Never what was pasted. Leave it off and the round runs unmonitored.",
  },
  {
    key: "audioRecording",
    label: "Keep my recordings",
    explanation:
      "By default your audio is deleted the moment it has been transcribed. Tick this to keep the recordings so you can listen back.",
  },
  {
    key: "crossSessionMemory",
    label: "Remember me between sessions",
    explanation:
      "Lets later sessions avoid repeating questions you have already had. Off means each session starts fresh.",
  },
  {
    key: "focusLossMonitoring",
    label: "Fullscreen-exit tracking",
    explanation:
      "The interview runs in fullscreen. If you tick this, the app records when you leave fullscreen and when — never what you did outside it. Leave more than 3 times and the session ends early, with feedback on what you covered. Leave it off and exits are not tracked or limited.",
  },
];

/** How long `checkMic` listens before deciding. */
const MIC_SAMPLE_MS = 4000;
/** A mic that never rose above this has not been proven to work. */
const NOISE_FLOOR = 0.02;

export default function TelemetryCheckPage() {
  const router = useRouter();
  const params = useParams<{ id: string }>();
  const sessionId = params.id;
  const deviceGridRef = useReveal<HTMLDivElement>({ y: 16, start: "top 92%" });

  const [micOk, setMicOk] = useState(false);
  /** Distinguishes "not tested yet" from "tested and heard nothing". */
  const [micTested, setMicTested] = useState(false);
  const [speakerOk, setSpeakerOk] = useState(false);
  const [micLevel, setMicLevel] = useState(0);
  const [checking, setChecking] = useState(false);
  const [tonePlaying, setTonePlaying] = useState(false);
  const [consent, setConsent] = useState<ConsentState>({
    telemetry: false,
    clipboardMonitor: false,
    audioRecording: false,
    crossSessionMemory: false,
    focusLossMonitoring: false,
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const streamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);

  // Release the microphone when the page goes away — holding it open after the
  // check would be exactly the kind of silent monitoring this page rules out.
  useEffect(
    () => () => {
      streamRef.current?.getTracks().forEach((track) => track.stop());
      if (audioContextRef.current && audioContextRef.current.state !== "closed") {
        void audioContextRef.current.close();
      }
    },
    [],
  );

  const checkMic = useCallback(async () => {
    setChecking(true);
    setError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const context = new AudioContext();
      audioContextRef.current = context;
      const analyser = context.createAnalyser();
      analyser.fftSize = 512;
      context.createMediaStreamSource(stream).connect(analyser);

      const samples = new Uint8Array(analyser.frequencyBinCount);
      let peak = 0;
      const started = Date.now();

      const sample = () => {
        analyser.getByteTimeDomainData(samples);
        let localPeak = 0;
        for (const value of samples) localPeak = Math.max(localPeak, Math.abs(value - 128) / 128);
        peak = Math.max(peak, localPeak);
        setMicLevel(localPeak);

        if (Date.now() - started < MIC_SAMPLE_MS) {
          requestAnimationFrame(sample);
        } else {
          setMicOk(peak > NOISE_FLOOR);
          setMicTested(true);
          setChecking(false);
          setMicLevel(0);
          stream.getTracks().forEach((track) => track.stop());
          if (context.state !== "closed") void context.close();
          audioContextRef.current = null;
        }
      };
      requestAnimationFrame(sample);
    } catch (err) {
      setError(
        `could not open your microphone: ${(err as Error).message}. You can still take the interview by typing.`,
      );
      setChecking(false);
    }
  }, []);

  /** Plays a short tone; the candidate confirms they heard it. */
  const checkSpeaker = useCallback(async () => {
    try {
      const context = new AudioContext();
      const oscillator = context.createOscillator();
      const gain = context.createGain();
      oscillator.frequency.value = 440;
      gain.gain.value = 0.1;
      oscillator.connect(gain).connect(context.destination);
      oscillator.start();
      setTonePlaying(true);
      setTimeout(() => {
        oscillator.stop();
        void context.close();
        setTonePlaying(false);
      }, 600);
    } catch (err) {
      setError(`could not play the test tone: ${(err as Error).message}`);
    }
  }, []);

  async function onContinue() {
    setBusy(true);
    setError(null);

    // Fullscreen has to be requested from this click — it is the candidate's
    // actual "start the interview" gesture, and browsers refuse a fullscreen
    // request that is not directly triggered by one. Requested unconditionally
    // (it is a display mode, not monitoring); the room page also retries on
    // mount as a fallback, and a candidate who declines or whose browser
    // blocks it can still take the interview windowed.
    try {
      await document.documentElement.requestFullscreen();
    } catch {
      // Not fatal — the room page's own fallback covers this, and the
      // interview works fine outside fullscreen.
    }

    try {
      const result = await api.telemetryCheck(sessionId, { micOk, speakerOk, consent });
      if (!result.passed) {
        setError(
          "The device check has not passed yet. Run the microphone and speaker checks above — the interview needs both.",
        );
        setBusy(false);
        return;
      }
      // Transition the session through CALIBRATION into QUESTION_LOOP so the
      // interview room's WebSocket can serve questions immediately.
      await api.beginInterview(sessionId);
      router.push(`/interview/${sessionId}/room`);
    } catch (err) {
      setError(err instanceof ApiCallError ? err.message : "could not save your choices");
      setBusy(false);
    }
  }

  const enabledCount = Object.values(consent).filter(Boolean).length;

  return (
    <Page>
      <InterviewSteps current="devices" />
      <PageHeader
        title="Before we start"
        lede="A quick device check, then what you are and are not comfortable with. Nothing here is required except the device check itself."
      />

      {error ? <InlineError>{error}</InlineError> : null}

      <div ref={deviceGridRef} className="grid gap-4 sm:grid-cols-2">
        <Card className={cn("transition-colors duration-500", micOk && "border-ok/40")}>
          <CardHeader>
            <CardTitle className="flex items-center justify-between gap-2 text-base">
              <span className="flex items-center gap-2">
                <Mic className="size-4 text-muted-foreground" aria-hidden="true" />
                Microphone
              </span>
              {micOk ? (
                <Badge variant="ok">
                  <Check aria-hidden="true" />
                  Working
                </Badge>
              ) : micTested ? (
                <Badge variant="warn">Heard nothing</Badge>
              ) : (
                <Badge variant="muted">Not tested</Badge>
              )}
            </CardTitle>
            <CardDescription>Required — the interview is spoken.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button
              type="button"
              variant={micOk ? "outline" : "default"}
              size="sm"
              onClick={checkMic}
              disabled={checking}
            >
              {checking ? (
                <Loader2 className="animate-spin" aria-hidden="true" />
              ) : (
                <AudioLines aria-hidden="true" />
              )}
              {checking ? "Listening…" : micOk ? "Test again" : "Test microphone"}
            </Button>

            <LevelMeter level={micLevel} active={checking} />

            <p className="text-sm text-muted-foreground" role="status" aria-live="polite">
              {checking
                ? "Say something for a few seconds."
                : micOk
                  ? "Microphone is working."
                  : micTested
                    ? "We could not hear anything. Check the right microphone is selected, then test again."
                    : "Not tested yet."}
            </p>
          </CardContent>
        </Card>

        <Card className={cn("transition-colors duration-500", speakerOk && "border-ok/40")}>
          <CardHeader>
            <CardTitle className="flex items-center justify-between gap-2 text-base">
              <span className="flex items-center gap-2">
                <Volume2 className="size-4 text-muted-foreground" aria-hidden="true" />
                Speaker
              </span>
              {speakerOk ? (
                <Badge variant="ok">
                  <Check aria-hidden="true" />
                  Confirmed
                </Badge>
              ) : (
                <Badge variant="muted">Not confirmed</Badge>
              )}
            </CardTitle>
            <CardDescription>Required — questions are read out to you.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button type="button" variant="outline" size="sm" onClick={checkSpeaker} disabled={tonePlaying}>
              <Play aria-hidden="true" />
              {tonePlaying ? "Playing…" : "Play a test tone"}
            </Button>

            <div className="flex items-start gap-2.5 rounded-md border bg-muted/40 px-3 py-2.5">
              <Checkbox
                id="speaker-ok"
                checked={speakerOk}
                onCheckedChange={(value) => setSpeakerOk(value === true)}
                className="mt-0.5"
              />
              <Label htmlFor="speaker-ok" className="font-normal leading-snug">
                I heard the tone
              </Label>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <ShieldCheck className="size-4 text-muted-foreground" aria-hidden="true" />
            What you are comfortable with
          </CardTitle>
          <CardDescription>
            These features can be enabled for your interview. You can take the whole interview
            with them off, and nothing here changes how you are scored.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="list-disc pl-5 space-y-4 marker:text-muted-foreground">
            {CONSENT_COPY.map((item) => (
              <li key={item.key} className="pl-1">
                <div className="min-w-0 space-y-1">
                  <span className="leading-snug font-medium block">
                    {item.label}
                  </span>
                  <p className="text-sm text-muted-foreground">
                    {item.explanation}
                  </p>
                </div>
              </li>
            ))}
          </ul>
          <div className="flex items-start gap-3 py-4 pt-4 mt-2 border-t">
            <Checkbox
              id="consent-all"
              checked={enabledCount === 5}
              onCheckedChange={(value) => 
                setConsent({
                  telemetry: value === true,
                  clipboardMonitor: value === true,
                  audioRecording: value === true,
                  crossSessionMemory: value === true,
                  focusLossMonitoring: value === true,
                })
              }
              className="mt-1"
            />
            <div className="min-w-0 space-y-1">
              <Label htmlFor="consent-all" className="leading-snug font-semibold">
                Accept all of the above
              </Label>
              <p className="text-sm text-muted-foreground">
                Turn on all monitoring and telemetry options for this session.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex flex-wrap items-center gap-3 border-t pt-5">
        <Button type="button" size="lg" onClick={onContinue} disabled={busy || !micOk || !speakerOk}>
          {busy ? <Loader2 className="animate-spin" aria-hidden="true" /> : null}
          {busy ? "Saving…" : "Start the interview"}
        </Button>
        {!micOk || !speakerOk ? (
          <Notice>Run both device checks above first.</Notice>
        ) : (
          <Notice>
            {enabledCount === 0
              ? "Starting with all five monitoring options off."
              : `Starting with ${enabledCount} of 5 monitoring options on.`}
          </Notice>
        )}
      </div>
    </Page>
  );
}

/**
 * Live input level.
 *
 * No CSS transition on the width: this is driven from requestAnimationFrame, and
 * a transition would smear 60 updates a second into a laggy blur that no longer
 * tracks the voice. Excluded from the accessibility tree because the status line
 * beside it already says the same thing in words.
 *
 * The scale is the same one the pre-Tailwind meter used (level x 200, capped),
 * so a normal speaking voice fills a useful part of the bar rather than a sliver.
 */
function LevelMeter({ level, active }: { level: number; active: boolean }) {
  const pct = Math.min(100, Math.round(level * 200));
  return (
    <div
      className="h-2.5 w-full overflow-hidden rounded-full bg-border"
      aria-hidden="true"
      style={active ? { boxShadow: "0 0 0 1px color-mix(in oklab, var(--ok) 40%, transparent)" } : undefined}
    >
      <div
        className={active ? "h-full rounded-full bg-gradient-to-r from-ok/70 to-ok" : "h-full rounded-full bg-transparent"}
        style={{ width: `${pct}%` }}
      />
    </div>
  );
}

"use client";

/**
 * Post-Interview Report page — `COMPLETED` state (CLAUDE.md §11,
 * INSTRUCTIONS.md §3.1).
 *
 * Triggers report generation if one does not exist yet, then renders the
 * evidence-based feedback. The report is the last thing a candidate touches,
 * so it must be clear, specific, and never imply anything that was not observed
 * (soul.md §6 "No fabrication").
 *
 * The feedback itself is rendered by `app/components/report-view.tsx`, which the
 * Admin drill-down also uses. Do not add report markup here — anything that
 * belongs to the report belongs in that component, or the two diverge
 * (CLAUDE.md §14).
 */

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { ArrowLeft, Download, Loader2 } from "lucide-react";
import { api, auth, ApiCallError, type Report } from "@/lib/api";
import { downloadAsJson } from "@/lib/download";
import { ReportView } from "@/app/components/report-view";
import { InlineError, Notice, Page, PageHeader } from "@/app/components/shell";
import { Button } from "@/app/components/ui/button";
import { Card, CardContent } from "@/app/components/ui/card";
import { Skeleton } from "@/app/components/ui/skeleton";

export default function ReportPage() {
  const params = useParams<{ id: string }>();
  const sessionId = params.id;
  const router = useRouter();

  const [report, setReport] = useState<Report | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  /**
   * The one refusal that is not a failure: the session finished with nothing
   * scoreable in it (every question skipped, or every answer too thin to
   * score). The Report Agent declines to invent a report rather than guessing
   * one (`soul.md §"No fabrication"`), and that is the correct outcome — but
   * its message is written for an engineer reading a log, and rendering it in
   * a red error box tells the candidate the app broke when in fact they simply
   * did not answer anything. Tracked apart from `error` so this page can say
   * what actually happened.
   */
  const [nothingToReport, setNothingToReport] = useState(false);

  useEffect(() => {
    if (!auth.token()) {
      router.replace("/");
      return;
    }

    async function loadReport() {
      try {
        // Try fetching an existing report first.
        const existing = await api.getReport(sessionId);
        setReport(existing.report);
        setLoading(false);
      } catch {
        // No report yet — trigger generation.
        try {
          const generated = await api.generateReport(sessionId);
          setReport(generated.report);
        } catch (err) {
          if (err instanceof ApiCallError && err.code === "insufficient_evidence") {
            setNothingToReport(true);
          } else {
            setError(err instanceof ApiCallError ? err.message : "could not load or generate the report");
          }
        } finally {
          setLoading(false);
        }
      }
    }
    void loadReport();
  }, [sessionId, router]);

  if (loading) {
    return (
      <Page>
        <PageHeader
          title="Putting your feedback together"
          lede="Reading back through the session. This usually takes a few seconds."
        />
        <Card>
          <CardContent className="space-y-3">
            <p className="flex items-center gap-2 text-sm text-muted-foreground" role="status" aria-live="polite">
              <Loader2 className="size-4 animate-spin" aria-hidden="true" />
              Compiling your results…
            </p>
            {/* Skeletons in the shape the report will take, so the page does not
                jump when the content lands. */}
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-4 w-1/2" />
            <Skeleton className="h-24 w-full" />
          </CardContent>
        </Card>
      </Page>
    );
  }

  // Said plainly, and without a score of any kind. There is a real temptation
  // to put a zero or a bottom grade here to fill the space — a candidate who
  // answered nothing has not scored zero, they have not been assessed, and the
  // two are different findings (`soul.md §"No fabrication"`, the same rule
  // behind `formatScore`'s `—` and the grading scale's absent-is-not-an-E).
  if (nothingToReport) {
    return (
      <Page>
        <PageHeader
          title="Nothing to report back on"
          lede="This session ended without an answer we could score, so there is no feedback to give — writing one anyway would mean inventing it."
        />
        <Card>
          <CardContent className="space-y-3">
            <p className="text-sm text-muted-foreground">
              That usually means the questions were skipped, or the answers were too short to work with.
              Nothing has been recorded against you, and this session does not count as a low score.
            </p>
            <p className="text-sm text-muted-foreground">
              Starting another interview and answering two or three questions in full is enough to get a
              real report back.
            </p>
          </CardContent>
        </Card>
        <div className="flex flex-wrap items-center gap-3 border-t pt-5">
          <Button type="button" onClick={() => router.push("/interview/new")}>
            Start another interview
          </Button>
          <Button type="button" variant="outline" onClick={() => router.push("/home")}>
            <ArrowLeft aria-hidden="true" />
            Back to home
          </Button>
        </div>
      </Page>
    );
  }

  if (error) {
    return (
      <Page>
        <PageHeader title="Report" />
        <InlineError>{error}</InlineError>
        <div>
          <Button type="button" variant="outline" onClick={() => router.push("/home")}>
            <ArrowLeft aria-hidden="true" />
            Back to home
          </Button>
        </div>
      </Page>
    );
  }

  if (!report) return null;

  return (
    <Page>
      <PageHeader
        title="Your interview feedback"
        lede="Everything here traces back to a specific moment in the session. Nothing is inferred or assumed."
        actions={
          // Generated from the report already in memory — there is no
          // candidate-facing download route on the gateway (see lib/download.ts)
          // and one was not invented for this.
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => downloadAsJson(report, `interview-report-${sessionId}.json`)}
          >
            <Download aria-hidden="true" />
            Download
          </Button>
        }
      />

      {/* One renderer, shared with the Admin drill-down — see report-view.tsx. */}
      <ReportView report={report} audience="candidate" />

      <div className="flex flex-wrap items-center gap-3 border-t pt-5">
        <Button type="button" onClick={() => router.push("/home")}>
          <ArrowLeft aria-hidden="true" />
          Back to home
        </Button>
        <Notice>Run another whenever you like — the focus areas above are a good place to start.</Notice>
      </div>
    </Page>
  );
}

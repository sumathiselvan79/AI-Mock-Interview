"use client";

/**
 * Login (INSTRUCTIONS.md §3.1). Role routing after login is a convenience only
 * — the gateway enforces the role on every request regardless of what this
 * component renders (§8).
 */

import { useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Loader2, MailCheck } from "lucide-react";
import { api, auth, ApiCallError } from "@/lib/api";
import { AuthCard, AuthHero, GoogleSignInButton, OrDivider } from "@/app/components/auth-card";
import { InlineError } from "@/app/components/shell";
import { Alert, AlertDescription } from "@/app/components/ui/alert";
import { Button } from "@/app/components/ui/button";
import { Input } from "@/app/components/ui/input";
import { Label } from "@/app/components/ui/label";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [passcode, setPasscode] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  /** Set once a field has been visited, so nothing is marked invalid before it has been used. */
  const [touched, setTouched] = useState<{ email?: boolean }>({});

  const emailLooksWrong = touched.email && email.trim() !== "" && !email.includes("@");

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const { token, user } = await api.login(email, passcode);
      auth.set(token, user.role);
      router.push(user.role === "admin" ? "/admin" : "/home");
    } catch (err) {
      setError(err instanceof ApiCallError ? err.message : "could not sign in");
    } finally {
      setBusy(false);
    }
  }

  async function onReset() {
    if (!email) {
      setError("enter your email address first");
      return;
    }
    setError(null);
    try {
      const result = await api.requestReset(email);
      // Deliberately the same message whether or not the account exists.
      setNotice(result.message);
    } catch {
      setNotice("if an account exists for that address, a reset link has been sent");
    }
  }

  return (
    <AuthHero
      imageSeed="signal-current"
      headline="Walk in already knowing where you stand."
      blurb="Every question is calibrated to the role. Every note points at something you actually said."
    >
      <AuthCard
        title="Sign in"
        description="Run a timed practice interview and get specific, evidence-based feedback."
        footer={
          <span>
            No account yet?{" "}
            <Link href="/signup" className="font-medium text-primary underline-offset-4 hover:underline">
              Create one
            </Link>
          </span>
        }
      >
        {error ? <InlineError>{error}</InlineError> : null}
        {notice ? (
          <Alert variant="muted">
            <MailCheck aria-hidden="true" />
            <AlertDescription>{notice}</AlertDescription>
          </Alert>
        ) : null}

        <form onSubmit={onSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              onBlur={() => setTouched((t) => ({ ...t, email: true }))}
              autoComplete="username"
              aria-invalid={emailLooksWrong || undefined}
              aria-describedby={emailLooksWrong ? "email-problem" : undefined}
              required
            />
            {emailLooksWrong ? (
              <p id="email-problem" className="text-sm text-destructive">
                That does not look like an email address.
              </p>
            ) : null}
          </div>

          <div className="space-y-2">
            <div className="flex items-baseline justify-between gap-2">
              <Label htmlFor="passcode">Passcode</Label>
              {/* A link-weight control: resetting is a rare path and should not
                  compete with Sign in for attention. */}
              <Button
                type="button"
                variant="link"
                size="xs"
                className="h-auto p-0 text-muted-foreground"
                onClick={onReset}
              >
                Forgot passcode?
              </Button>
            </div>
            <Input
              id="passcode"
              type="password"
              value={passcode}
              onChange={(e) => setPasscode(e.target.value)}
              autoComplete="current-password"
              required
            />
          </div>

          <Button type="submit" className="w-full" disabled={busy}>
            {busy ? <Loader2 className="animate-spin" aria-hidden="true" /> : null}
            {busy ? "Signing in…" : "Sign in"}
          </Button>
        </form>

        <OrDivider />
        <GoogleSignInButton />
      </AuthCard>
    </AuthHero>
  );
}

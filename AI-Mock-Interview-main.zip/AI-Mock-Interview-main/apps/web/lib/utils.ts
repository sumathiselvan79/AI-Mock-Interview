import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

/** shadcn/ui's class merger: conditional classes, with later Tailwind utilities
 *  beating earlier conflicting ones so a caller's `className` can override a
 *  component's default. */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

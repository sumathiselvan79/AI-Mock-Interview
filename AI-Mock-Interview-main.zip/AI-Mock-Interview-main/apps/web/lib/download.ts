/**
 * Client-side file download.
 *
 * Deliberately NOT in `lib/api.ts`: this makes no request. The gateway has
 * report-download routes, but all of them are under `/admin` — there is no
 * candidate-facing download endpoint, and calling an admin one from the
 * candidate's own report page would 403 even if it were appropriate.
 *
 * A candidate's report is already fully in memory by the time the page renders
 * it, so serialising what is on screen needs no endpoint at all. JSON rather
 * than PDF for the same reason the admin routes give JSON — see the comment on
 * `GET /admin/users/:userId/reports/download` about not adding a PDF toolchain.
 */

export function downloadAsJson(data: unknown, filename: string): void {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

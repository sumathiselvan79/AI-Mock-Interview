/**
 * Display formatters shared by every page.
 *
 * These used to live in `app/admin/ui.tsx`, while the Student Home page carried
 * its own inline copy of the same null rule. One of those two was always going
 * to drift, and the rule below is not a formatting preference — it is a
 * soul.md constraint. So it lives once, here, and `app/admin/ui.tsx` re-exports
 * it for its existing callers.
 */

/** `—` rather than "null" or "Invalid Date" for a candidate who has not got there yet. */
export function formatDate(value: string | null): string {
  if (!value) return "—";
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? "—" : parsed.toLocaleDateString();
}

export function formatDateTime(value: string | null): string {
  if (!value) return "—";
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? "—" : parsed.toLocaleString();
}

/**
 * One decimal, out of 5.
 *
 * Null is "—", never 0: a candidate with no reports has not scored zero, and
 * showing zero would read as a judgement the system never made
 * (soul.md §"No fabrication"). Do not add a `?? 0` anywhere near this.
 */
export function formatScore(value: number | null): string {
  return value === null ? "—" : `${value.toFixed(1)} / 5`;
}

/** The same rule, without the "/ 5" suffix, for a stat tile whose label carries it. */
export function formatScoreValue(value: number | null): string {
  return value === null ? "—" : value.toFixed(1);
}

/** `45 min`, or `—` for a session that never finished and has no duration. */
export function formatDuration(minutes: number | null): string {
  return minutes === null ? "—" : `${minutes} min`;
}

/** `1 strength` / `2 strengths` — an "(s)" in product copy reads as unfinished. */
export function pluralize(count: number, singular: string, plural = `${singular}s`): string {
  return `${count} ${count === 1 ? singular : plural}`;
}

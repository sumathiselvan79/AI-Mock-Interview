/**
 * The room's turn-list selectors.
 *
 * `page.tsx` keeps one flat, ordered array of the whole conversation —
 * interviewer and candidate turns interleaved, oldest first. Both panels read
 * that same array and show deliberately different slices of it, and which
 * slice is a decision rather than presentation:
 *
 *  - The interviewer side (`SpeechPanel`) shows the **whole** thread. "What did
 *    I already say about this?" is a fair question for a candidate to answer by
 *    looking, and the follow-up logic assumes they can.
 *  - The candidate side (`TranscriptionPanel`) shows only what has been said
 *    since the interviewer last spoke — `answersForCurrentPrompt` below.
 *
 * That asymmetry is the part worth testing directly, so it lives here as a pure
 * function rather than inline in the component, the same treatment and for the
 * same reason as `live-protocol.ts`'s `replyTo`.
 */

/** The shape both selectors need. The page's own `Turn` type is wider. */
export interface RoleTagged {
  role: "interviewer" | "candidate";
}

/**
 * Index of the last interviewer turn, or -1 when the interviewer has not spoken
 * yet. A plain reduce rather than a reversed `findIndex`, because the array is
 * the conversation in order and reversing it to answer "what happened most
 * recently" is a copy per render for no gain.
 */
export function lastInterviewerIndex(turns: readonly RoleTagged[]): number {
  return turns.reduce((idx, turn, i) => (turn.role === "interviewer" ? i : idx), -1);
}

/**
 * The candidate turns belonging to the prompt currently on the table.
 *
 * This panel used to show every candidate turn in the session, oldest first,
 * which left the previous answer sitting in the box while the next question was
 * being asked. That box is the one the candidate types into, so stale text in it
 * reads as part of what they are about to send. Scoping it to the current prompt
 * is a deliberate reversal of the panel's original "every answer given so far"
 * intent, not a bug fix.
 *
 * The cut moves on its own: the moment the page appends the next question,
 * follow-up, clarification or greeting, everything before it drops out of view.
 * There is no clear/reset call to forget to make — which is the whole reason the
 * rule is expressed as "after the last interviewer turn" rather than as a piece
 * of state something has to remember to update.
 *
 * A view filter only. The full history stays in `turns`, and nothing about
 * scoring, grading, or what reaches the backend reads this.
 */
export function answersForCurrentPrompt<T extends RoleTagged>(turns: readonly T[]): Extract<T, { role: "candidate" }>[] {
  return turns
    .slice(lastInterviewerIndex(turns) + 1)
    .filter((turn): turn is Extract<T, { role: "candidate" }> => turn.role === "candidate");
}

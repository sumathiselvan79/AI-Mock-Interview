/**
 * `MediaRecorder` records whatever codec the browser defaults to — WebM/Opus on
 * Chrome, Ogg/Opus on Firefox — never WAV. The Speech Service's decoder only
 * understands 16-bit PCM RIFF/WAV (`decodeWav` in
 * `mcp-servers/tool-speech-service/src/provider.ts`), so a raw recording sent
 * as-is fails every real transcription with "audio is not a RIFF/WAV file".
 * This decodes whatever the browser recorded (the browser can always decode its
 * own recording format) and re-encodes it as mono 16kHz PCM WAV, matching the
 * ASR model's expected input, before it ever leaves the client.
 */

const TARGET_SAMPLE_RATE = 16_000;
const WAV_HEADER_BYTES = 44;

export async function blobToWav(blob: Blob): Promise<Blob> {
  const arrayBuffer = await blob.arrayBuffer();
  const AudioContextCtor =
    window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  const decodeContext = new AudioContextCtor();
  let decoded: AudioBuffer;
  try {
    decoded = await decodeContext.decodeAudioData(arrayBuffer);
  } finally {
    void decodeContext.close();
  }

  // Rendering through a mono OfflineAudioContext downmixes and resamples in
  // one pass — exactly the mono/16kHz input the ASR model expects.
  const offline = new OfflineAudioContext(1, Math.ceil(decoded.duration * TARGET_SAMPLE_RATE), TARGET_SAMPLE_RATE);
  const source = offline.createBufferSource();
  source.buffer = decoded;
  source.connect(offline.destination);
  source.start(0);
  const rendered = await offline.startRendering();

  const samples = rendered.getChannelData(0);
  const pcm = new Int16Array(samples.length);
  for (let i = 0; i < samples.length; i += 1) {
    const clamped = Math.max(-1, Math.min(1, samples[i] as number));
    pcm[i] = Math.round(clamped * 32767);
  }

  return new Blob([encodeWav(pcm, TARGET_SAMPLE_RATE)], { type: "audio/wav" });
}

export function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(((reader.result as string) ?? "").split(",")[1] ?? "");
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(blob);
  });
}

/** Mirrors the server's own 16-bit PCM WAV writer (`tool-speech-service/src/provider.ts`). */
function encodeWav(samples: Int16Array, sampleRate: number): ArrayBuffer {
  const buffer = new ArrayBuffer(WAV_HEADER_BYTES + samples.length * 2);
  const view = new DataView(buffer);

  writeString(view, 0, "RIFF");
  view.setUint32(4, 36 + samples.length * 2, true);
  writeString(view, 8, "WAVE");
  writeString(view, 12, "fmt ");
  view.setUint32(16, 16, true); // PCM chunk size
  view.setUint16(20, 1, true); // format: PCM
  view.setUint16(22, 1, true); // channels: mono
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true); // byte rate
  view.setUint16(32, 2, true); // block align
  view.setUint16(34, 16, true); // bits per sample
  writeString(view, 36, "data");
  view.setUint32(40, samples.length * 2, true);
  for (let i = 0; i < samples.length; i += 1) view.setInt16(WAV_HEADER_BYTES + i * 2, samples[i] as number, true);

  return buffer;
}

function writeString(view: DataView, offset: number, text: string): void {
  for (let i = 0; i < text.length; i += 1) view.setUint8(offset + i, text.charCodeAt(i));
}

/**
 * Thin client for the gateway's REST surface (INSTRUCTIONS.md §7).
 *
 * The frontend never speaks MCP (CLAUDE.md §5) — every call here is REST to the
 * gateway, which routes to the Harness Agent.
 *
 * The token lives in sessionStorage: it is a short-lived, role-scoped bearer
 * token, and the role it carries is enforced by the gateway on every request,
 * so nothing here is a security control — it only decides what to render.
 */

export const GATEWAY_URL = process.env.NEXT_PUBLIC_GATEWAY_URL ?? "http://localhost:4000";

const TOKEN_KEY = "mia.token";
const ROLE_KEY = "mia.role";

export interface ApiError {
  code: string;
  message: string;
}

export class ApiCallError extends Error {
  constructor(
    readonly status: number,
    readonly code: string,
    message: string,
  ) {
    super(message);
  }
}

export const auth = {
  token: (): string | null => (typeof window === "undefined" ? null : sessionStorage.getItem(TOKEN_KEY)),
  role: (): string | null => (typeof window === "undefined" ? null : sessionStorage.getItem(ROLE_KEY)),
  set(token: string, role: string): void {
    sessionStorage.setItem(TOKEN_KEY, token);
    sessionStorage.setItem(ROLE_KEY, role);
  },
  clear(): void {
    sessionStorage.removeItem(TOKEN_KEY);
    sessionStorage.removeItem(ROLE_KEY);
  },
};

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const token = auth.token();
  const response = await fetch(`${GATEWAY_URL}${path}`, {
    ...init,
    headers: {
      "content-type": "application/json",
      ...(token ? { authorization: `Bearer ${token}` } : {}),
      ...(init.headers ?? {}),
    },
  });

  const text = await response.text();
  const body = text ? (JSON.parse(text) as Record<string, unknown>) : {};

  if (!response.ok) {
    const error = (body.error ?? {}) as Partial<ApiError>;
    throw new ApiCallError(
      response.status,
      error.code ?? "request_failed",
      error.message ?? `request failed with ${response.status}`,
    );
  }
  return body as T;
}

export interface TopicRelevance {
  topic: string;
  relevance_score: number;
  evidence: string;
}

export interface JdFit {
  fit_score: number;
  matched_requirements: string[];
  gaps: string[];
  /** (Stage 5) Grounded explanation. Absent when the provider was unavailable or the claim failed grounding. */
  rationale?: string;
  /** (Stage 5) JD-anchored topic weighting — how heavily the JD weights each topic. */
  topic_relevance?: TopicRelevance[];
  prompt_version?: string;
  insufficient_signal?: string[];
}

/** (Stage 5, §11.4) Profile fields a session archive is keyed on. */
export interface UserProfile {
  full_name: string | null;
  department: string | null;
  program_year: string | null;
}

export const api = {
  login: (email: string, passcode: string) =>
    request<{ token: string; user: { id: string; role: string; email: string } }>("/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, passcode }),
    }),

  /**
   * Self-service signup. The gateway fixes the role to `student` (§3.2).
   *
   * (Stage 5) Profile fields go in here rather than in a later step because
   * archiving refuses without a full name (§11.4) — a candidate who never
   * fills them in has sessions that silently cannot be archived.
   */
  register: (
    email: string,
    passcode: string,
    profile: { full_name?: string; department?: string; program_year?: string } = {},
  ) =>
    request<{ token: string; user: { id: string; role: string; email: string } }>("/auth/register", {
      method: "POST",
      body: JSON.stringify({ email, passcode, ...profile }),
    }),

  /** (Stage 5, §11.4) The catch-up path for an account that skipped its profile. */
  getProfile: () => request<{ profile: UserProfile; archive_ready: boolean }>("/me/profile"),

  updateProfile: (profile: { full_name?: string; department?: string; program_year?: string }) =>
    request<{ archive_ready: boolean }>("/me/profile", {
      method: "PATCH",
      body: JSON.stringify(profile),
    }),

  requestReset: (email: string) =>
    request<{ status: string; message: string }>("/auth/reset-passcode/request", {
      method: "POST",
      body: JSON.stringify({ email }),
    }),

  createSession: (role: string, jobDescription: string) =>
    request<{ session_id: string; state: string }>("/sessions", {
      method: "POST",
      body: JSON.stringify({ role, job_description: jobDescription }),
    }),

  getSession: (id: string) =>
    request<{ session: { id: string; state: string; role: string; resumeRef: string | null } }>(
      `/sessions/${id}`,
    ),

  uploadResume: (id: string, file: { filename: string; contentType: string; dataBase64: string }) =>
    request<{ jd_fit: JdFit; topic_relevance: TopicRelevance[] }>(`/sessions/${id}/resume`, {
      method: "POST",
      body: JSON.stringify({
        filename: file.filename,
        content_type: file.contentType,
        data_base64: file.dataBase64,
      }),
    }),

  deleteResume: (id: string) =>
    request<{ deleted: boolean }>(`/sessions/${id}/resume`, { method: "DELETE" }),

  submitAudioAnswer: (
    id: string,
    questionId: string,
    audioBase64: string,
    /**
     * What the browser knows about the capture device. A hint the server
     * re-checks, never a claim it acts on alone — see `lib/mic.ts`.
     */
    inputDevice?: { hint: string; label?: string; echo_cancellation?: boolean } | null,
  ) =>
    request<{
      accepted: boolean;
      action?: string;
      /**
       * Which refusal this is, when `accepted` is false:
       * `transcription_low_confidence` | `no_speech_detected` |
       * `audio_source_rejected` | `transcription_failed`.
       *
       * The first is the only one where falling back to the browser's own
       * live-caption guess is right. `no_speech_detected` has nothing to
       * correct, and `audio_source_rejected` means the audio was the
       * interview's own question — pre-filling that would invite the candidate
       * to submit it as their answer.
       */
      code?: string;
      reason?: string;
      draft_transcript?: string;
      message?: string;
      /**
       * False when the recording was a request to repeat or clarify rather
       * than an answer (HUMAN_INTERACTION_FLOW.md §3). Nothing was written and
       * nothing was scored: there is no `answer_id`, and the same question is
       * still waiting. Absent on a plain accepted answer, so treat only an
       * explicit `false` as "this turn did not happen".
       */
      answered?: boolean;
      clarification?: { kind: string; question_id: string; text: string; audio_url: string | null };
      answer_id?: string;
      transcript?: string;
      transcript_confidence?: number;
      /** `{ score, rationale, grade? }` — `grade` is the Eval Tool's band for that score. */
      evaluation?: AnswerEvaluation | null;
      follow_up?: { text: string; reason: string; audio_url: string | null };
      /**
       * The micro-acknowledgment spoken before the score existed (§1). On this
       * route it arrives with everything else; over the socket it arrives on
       * its own frame, first, which is where the timing actually matters.
       */
      acknowledgment?: { text: string; audio_url: string | null };
    }>(`/sessions/${id}/answers/audio`, {
      method: "POST",
      body: JSON.stringify({
        question_id: questionId,
        audio_base64: audioBase64,
        content_type: "audio/wav",
        ...(inputDevice ? { input_device: inputDevice } : {}),
      }),
    }),

  jdFit: (id: string) =>
    request<{
      jd_fit: JdFit | null;
      topic_relevance: TopicRelevance[];
      seniority_estimate: string | null;
      note: string;
      blocks_start: boolean;
    }>(`/sessions/${id}/jd-fit`),

  /** Records the device check and the per-session consent flags (§3, §8). */
  telemetryCheck: (
    id: string,
    input: {
      micOk: boolean;
      speakerOk: boolean;
      consent: {
        telemetry: boolean;
        clipboardMonitor: boolean;
        audioRecording: boolean;
        crossSessionMemory: boolean;
        focusLossMonitoring: boolean;
      };
    },
  ) =>
    request<{ passed: boolean; consent: Record<string, boolean> }>(`/sessions/${id}/telemetry-check`, {
      method: "POST",
      body: JSON.stringify({
        mic_ok: input.micOk,
        speaker_ok: input.speakerOk,
        consent: {
          telemetry: input.consent.telemetry,
          clipboard_monitor: input.consent.clipboardMonitor,
          audio_recording: input.consent.audioRecording,
          cross_session_memory: input.consent.crossSessionMemory,
          focus_loss_monitoring: input.consent.focusLossMonitoring,
        },
      }),
    }),

  advance: (id: string, to: string) =>
    request<{ session: { state: string } }>(`/sessions/${id}/advance`, {
      method: "POST",
      body: JSON.stringify({ to }),
    }),

  /** TELEMETRY_CHECK → CALIBRATION → QUESTION_LOOP (INSTRUCTIONS.md §7). */
  beginInterview: (id: string) =>
    request<{ state: string; topic_plan: unknown[] }>(`/sessions/${id}/begin`, {
      method: "POST",
    }),

  myStats: () =>
    request<{
      stats: {
        sessionsCompleted: number;
        averageScore: number | null;
        lastSessionAt: string | null;
        recurringFocusAreas: string[];
      };
      sessions_started: number;
    }>("/me/stats"),

  /** Admin Home dashboard — every candidate's report (INSTRUCTIONS.md §3.1, §7). */
  adminReports: () => request<{ reports: Report[] }>("/admin/reports"),

  adminReport: (sessionId: string) => request<{ report: Report }>(`/admin/reports/${sessionId}`),

  /** Fetch the report for a completed session (INSTRUCTIONS.md §7). */
  getReport: (sessionId: string) =>
    request<{ state: string; report: Report }>(`/sessions/${sessionId}/report`),

  /** Trigger report generation: WRAP_UP → REPORT_GENERATION → COMPLETED. */
  generateReport: (sessionId: string) =>
    request<{ state: string; report: Report }>(`/sessions/${sessionId}/report`, {
      method: "POST",
    }),

  // ------------------------------------------- (Stage 7) admin directory

  /** The user directory. Every filter is server-side; see ADMIN_FEATURE_PROMPT.md Part 1. */
  adminUsers: (query: DirectoryQuery = {}) => {
    const params = new URLSearchParams();
    for (const [key, value] of Object.entries(query)) {
      if (value !== undefined && value !== null && value !== "") params.set(key, String(value));
    }
    const qs = params.toString();
    return request<DirectoryResponse>(`/admin/users${qs ? `?${qs}` : ""}`);
  },

  adminUser: (userId: string) => request<AdminUserProfileResponse>(`/admin/users/${userId}`),

  adminScheduled: () => request<{ scheduled: AdminSchedule[] }>("/admin/scheduled-interviews"),

  adminSchedule: (draft: ScheduleDraftBody) =>
    request<{ scheduled: AdminSchedule[] }>("/admin/scheduled-interviews", {
      method: "POST",
      body: JSON.stringify(draft),
    }),

  adminCancelSchedule: (id: string) =>
    request<{ scheduled: AdminSchedule }>(`/admin/scheduled-interviews/${id}/cancel`, {
      method: "POST",
    }),

  /**
   * The signed-in candidate's own interview history (Home page).
   *
   * Scoped server-side to the bearer token's subject — there is no candidate id
   * to pass. Newest first.
   */
  mySessions: () => request<{ sessions: CandidateSessionSummary[] }>("/me/sessions"),

  /** What an Admin has assigned to the signed-in student. */
  myScheduledInterviews: () => request<{ scheduled: StudentSchedule[] }>("/me/scheduled-interviews"),

  /**
   * Starts an assigned interview. Creates an ordinary session seeded with the
   * assignment's role/JD — Interview Config still runs, because resume upload
   * and the JD-fit check are not skippable.
   */
  startScheduledInterview: (scheduledInterviewId: string) =>
    request<{ session_id: string; state: string; scheduled?: { role: string } }>("/sessions", {
      method: "POST",
      body: JSON.stringify({ scheduled_interview_id: scheduledInterviewId }),
    }),
};

/**
 * Downloads a report (or a candidate's whole set) as a JSON attachment.
 *
 * Not routed through `request`, which parses JSON into an object — this needs
 * the raw body and the browser's save dialog. The bearer token still travels
 * in the header rather than the URL, so the link cannot be copied out of a
 * browser history and replayed.
 */
export async function downloadJson(path: string, filename: string): Promise<void> {
  const token = auth.token();
  const response = await fetch(`${GATEWAY_URL}${path}`, {
    headers: token ? { authorization: `Bearer ${token}` } : {},
  });
  if (!response.ok) {
    const body = (await response.json().catch(() => ({}))) as { error?: Partial<ApiError> };
    throw new ApiCallError(
      response.status,
      body.error?.code ?? "download_failed",
      body.error?.message ?? "could not download that report",
    );
  }

  const url = URL.createObjectURL(await response.blob());
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

export type DirectoryStatus = "active" | "interview_scheduled" | "no_activity";

export interface DirectoryQuery {
  search?: string;
  department?: string;
  status?: DirectoryStatus | "";
  min_score?: number;
  max_score?: number;
  from?: string;
  to?: string;
  sort?: string;
  direction?: "asc" | "desc";
  page?: number;
  page_size?: number;
}

export interface DirectoryRow {
  user_id: string;
  email: string;
  full_name: string | null;
  department: string | null;
  avatar_url: string | null;
  interviews_completed: number;
  average_score: number | null;
  last_interview_at: string | null;
  created_at: string;
  status: DirectoryStatus;
}

export interface DirectoryResponse {
  rows: DirectoryRow[];
  total: number;
  page: number;
  page_size: number;
  departments: string[];
}

export interface AdminSchedule {
  id: string;
  candidate_id: string;
  candidate_email?: string | null;
  candidate_name?: string | null;
  department: string | null;
  role: string;
  job_description: string;
  interview_type: string;
  difficulty: string;
  duration_minutes: number;
  scheduled_for: string;
  deadline: string | null;
  recurring: string;
  coding_round_enabled: boolean;
  notes: string | null;
  notify_via: string[];
  status: string;
  session_id: string | null;
  created_at: string;
}

/** The student projection — deliberately has no `notes` or `created_by` key. */
export interface StudentSchedule {
  id: string;
  role: string;
  job_description: string;
  interview_type: string;
  difficulty: string;
  duration_minutes: number;
  scheduled_for: string;
  deadline: string | null;
  runs_coding_round: boolean;
  status: string;
  session_id: string | null;
  consent_note: string;
}

export interface ScheduleDraftBody {
  candidate_ids: string[];
  role: string;
  job_description?: string;
  interview_type: string;
  difficulty: string;
  duration_minutes: number;
  scheduled_for: string;
  deadline?: string | null;
  recurring?: string;
  coding_round_enabled?: boolean;
  notes?: string | null;
  notify_via?: string[];
}

/**
 * One row of a candidate's interview history.
 *
 * Named for whose history it is, not for who is reading it: the Admin profile
 * drill-down (`GET /admin/users/:userId`) and the candidate's own Home page
 * (`GET /me/sessions`) are served the same shape by the same backend helper
 * (`app/http/session_summaries.py`). `overall_score` is null for a session with
 * no report — render it through `formatScore`, never `?? 0`.
 */
export interface CandidateSessionSummary {
  session_id: string;
  role: string;
  state: string;
  status: "completed" | "abandoned" | "in_progress";
  started_at: string;
  duration_minutes: number | null;
  overall_score: number | null;
  has_report: boolean;
}

export interface AdminUserProfileResponse {
  profile: {
    user_id: string;
    email: string;
    full_name: string | null;
    department: string | null;
    program_year: string | null;
    avatar_url: string | null;
    created_at: string;
    interviews_completed: number;
    average_score: number | null;
    last_interview_at: string | null;
    score_trend: { at: string; score: number }[];
  };
  sessions: CandidateSessionSummary[];
  scheduled: AdminSchedule[];
}

/**
 * One banded score, as assigned by the Eval Tool (`backend/app/tools/eval/grading.py`).
 *
 * The band always travels with the number it was banded from, so nothing can
 * render a letter without the evidence-backed score behind it. Nothing on the
 * frontend derives a grade — a second ladder in the browser is how the report
 * and the room start disagreeing about the same answer.
 */
export interface Grade {
  letter: "A" | "B" | "C" | "D" | "E";
  label: string;
  score: number;
  descriptor: string;
  isStrength: boolean;
  scaleVersion: string;
}

/** One answer's live score, as pushed during the interview. */
export interface AnswerEvaluation {
  score: number;
  rationale: string;
  grade?: Grade | null;
}

export interface CompetencyScore {
  competency: string;
  score: number;
  evidence: string[];
  /** Absent for a report written before grading existed. Never defaulted to a band. */
  grade?: Grade | null;
}

export interface FocusEvent {
  timestamp: string;
}

export interface BrowserActivitySummary {
  exitCount: number;
  events: FocusEvent[];
  concludedEarly: boolean;
}

export interface Report {
  sessionId: string;
  candidateId: string;
  competencyScores: CompetencyScore[];
  /**
   * The session-level band. `null`/absent — rendered as `—`, never as the
   * bottom band — when nothing in the session could be graded: a candidate who
   * was never assessed has not failed (soul.md §"No fabrication"), the same
   * rule `formatScore` already enforces on a null score.
   */
  overallGrade?: Grade | null;
  strengths: string[];
  focusAreas: string[];
  browserActivity: BrowserActivitySummary;
  disclaimer: string;
  createdAt: string;
}

/** Reads a File into the base64 payload the upload endpoint expects. */
export function readFileAsBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("could not read that file"));
    reader.onload = () => {
      const result = String(reader.result);
      resolve(result.slice(result.indexOf(",") + 1));
    };
    reader.readAsDataURL(file);
  });
}

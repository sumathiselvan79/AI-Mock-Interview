"use client";

/**
 * Browser speech helpers for the interview room: speaking a line with a
 * progress signal, and live dictation while the candidate answers.
 *
 * Both exist for the same reason — the room shows text *as it happens* rather
 * than after it. A question appears word by word as it is spoken, and an answer
 * appears word by word as it is said. Neither is decoration: a candidate who
 * missed a word mid-question can read it instead of asking for a repeat, and a
 * candidate who cannot tell whether the mic is picking them up can now see that
 * it is.
 *
 * Two boundaries hold everywhere in this file:
 *
 *  - **Nothing here is authoritative.** The live dictation is a preview. The
 *    text that gets submitted and scored is still what comes back from the
 *    Speech Service and what the candidate then edits — soul.md §5 does not let
 *    a transcript nobody confirmed become evidence, and a browser recogniser is
 *    no more confirmed than a server one.
 *  - **Everything degrades to nothing.** Every capability here is missing in
 *    some real browser. Each helper reports that plainly and the room falls
 *    back to showing the whole line at once, which is exactly how it behaved
 *    before any of this existed.
 */

/** How the reveal is being driven, so the caller can say so when it matters. */
export type SpeechOutcome = "spoken" | "audio" | "silent";

export interface SpeakHandle {
  /** Stops playback/synthesis immediately. Safe to call more than once. */
  cancel: () => void;
}

interface SpeakOptions {
  text: string;
  /**
   * Fraction of the line that has been spoken, 0..1. Called many times per
   * second, so the caller should keep its handler cheap.
   */
  onProgress: (fraction: number) => void;
  /** Fired once when the line is finished, cancelled, or could not be spoken. */
  onDone: (outcome: SpeechOutcome) => void;
}

function supportsSynthesis(): boolean {
  return typeof window !== "undefined" && "speechSynthesis" in window;
}

/**
 * Speaks `text` with the browser's own voice, reporting how far through it is.
 *
 * Progress comes from `onboundary`, which fires at word boundaries with a
 * character index — that gives a reveal genuinely locked to the voice rather
 * than a timer that happens to look close. Not every engine fires it (notably
 * some Chromium builds with remote voices), so a timer runs alongside as a
 * floor: whichever is further ahead wins, and the reveal can therefore stall
 * behind the voice but never run ahead of it and spoil the line.
 */
export function speak({ text, onProgress, onDone }: SpeakOptions): SpeakHandle {
  if (!supportsSynthesis() || !text.trim()) {
    onProgress(1);
    onDone("silent");
    return { cancel: () => {} };
  }

  let finished = false;
  let raf = 0;
  let boundaryFraction = 0;

  const finish = (outcome: SpeechOutcome) => {
    if (finished) return;
    finished = true;
    cancelAnimationFrame(raf);
    onProgress(1);
    onDone(outcome);
  };

  try {
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;

    const voices = window.speechSynthesis.getVoices();
    const english =
      voices.find((v) => (v.lang === "en-US" || v.lang.startsWith("en")) && !v.name.toLowerCase().includes("deprecated")) ??
      voices.find((v) => v.lang.startsWith("en"));
    if (english) utterance.voice = english;

    utterance.onboundary = (event) => {
      if (finished || !event.charIndex) return;
      boundaryFraction = Math.min(1, event.charIndex / text.length);
    };
    utterance.onend = () => finish("spoken");
    utterance.onerror = () => finish("silent");

    // ~14 characters a second at rate 1.0 — close enough to natural speech to
    // keep the reveal moving when no boundary events arrive, and slow enough
    // that it stays behind a voice that IS reporting them.
    const started = performance.now();
    const estimatedMs = (text.length / 14) * 1000;
    const tick = () => {
      if (finished) return;
      const elapsed = Math.min(1, (performance.now() - started) / estimatedMs);
      onProgress(Math.max(boundaryFraction, elapsed * 0.98));
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);

    window.speechSynthesis.speak(utterance);
  } catch {
    finish("silent");
  }

  return {
    cancel: () => {
      try {
        window.speechSynthesis.cancel();
      } catch {
        // Nothing to stop.
      }
      finish("silent");
    },
  };
}

/**
 * Plays a server-synthesised clip, reporting progress from the audio clock.
 *
 * Used when the Speech Service returned real audio. There are no word
 * boundaries to read here, so progress is `currentTime / duration` — for a clip
 * of one sentence that tracks the voice closely enough to read along with.
 */
export function playClip(url: string, { onProgress, onDone }: Omit<SpeakOptions, "text">): SpeakHandle {
  let finished = false;
  let raf = 0;
  const audio = new Audio(url);

  const finish = (outcome: SpeechOutcome) => {
    if (finished) return;
    finished = true;
    cancelAnimationFrame(raf);
    onProgress(1);
    onDone(outcome);
  };

  const tick = () => {
    if (finished) return;
    if (audio.duration && Number.isFinite(audio.duration)) {
      onProgress(Math.min(1, audio.currentTime / audio.duration));
    }
    raf = requestAnimationFrame(tick);
  };

  audio.onended = () => finish("audio");
  audio.onerror = () => finish("silent");
  audio.onplay = () => {
    raf = requestAnimationFrame(tick);
  };

  audio.play().catch(() => finish("silent"));

  return {
    cancel: () => {
      audio.pause();
      finish("silent");
    },
  };
}

// ------------------------------------------------------------------ dictation

type SpeechRecognitionCtor = new () => SpeechRecognitionLike;

interface SpeechRecognitionLike {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onresult: ((event: { resultIndex: number; results: ArrayLike<{ 0: { transcript: string }; isFinal: boolean }> }) => void) | null;
  onerror: (() => void) | null;
  onend: (() => void) | null;
}

function recognitionCtor(): SpeechRecognitionCtor | null {
  if (typeof window === "undefined") return null;
  const w = window as unknown as { SpeechRecognition?: SpeechRecognitionCtor; webkitSpeechRecognition?: SpeechRecognitionCtor };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

export function dictationSupported(): boolean {
  return recognitionCtor() !== null;
}

export interface Dictation {
  /** Stops listening and returns everything the recogniser settled on. */
  stop: () => string;
}

/**
 * Live dictation for the duration of one answer.
 *
 * `onUpdate` receives the settled text and the in-flight guess separately, so
 * the room can show the two differently — what the recogniser has committed to
 * reads as text, what it is still deciding reads as provisional. Running them
 * together would present a word that is about to change as if it were final.
 *
 * `continuous` and a self-restart on `onend` are both deliberate: browser
 * recognisers stop on their own after a pause, and an answer with a thinking
 * pause in it is one answer, not two. This mirrors the recorder, which has no
 * silence cutoff either.
 */
export function startDictation({ onUpdate }: { onUpdate: (settled: string, interim: string) => void }): Dictation | null {
  const Ctor = recognitionCtor();
  if (!Ctor) return null;

  let settled = "";
  let stopped = false;
  let recognition: SpeechRecognitionLike;

  try {
    recognition = new Ctor();
  } catch {
    return null;
  }

  recognition.continuous = true;
  recognition.interimResults = true;
  recognition.lang = "en-US";

  recognition.onresult = (event) => {
    let interim = "";
    for (let i = event.resultIndex; i < event.results.length; i++) {
      const result = event.results[i];
      const chunk = result[0].transcript;
      if (result.isFinal) {
        settled = `${settled}${settled && !settled.endsWith(" ") ? " " : ""}${chunk.trim()}`;
      } else {
        interim += chunk;
      }
    }
    onUpdate(settled, interim.trim());
  };

  // A recogniser error is not the candidate's problem and never interrupts the
  // recording: the MediaRecorder is a separate pipeline, and the server
  // transcript is the one that counts. The preview simply stops updating.
  recognition.onerror = () => {};
  recognition.onend = () => {
    if (stopped) return;
    try {
      recognition.start();
    } catch {
      // Already restarting, or the engine is gone. Either way, nothing to do.
    }
  };

  try {
    recognition.start();
  } catch {
    return null;
  }

  return {
    stop: () => {
      stopped = true;
      try {
        recognition.stop();
      } catch {
        // Already stopped.
      }
      return settled.trim();
    },
  };
}

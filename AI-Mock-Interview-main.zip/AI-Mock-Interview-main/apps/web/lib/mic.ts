"use client";

/**
 * What the browser can tell the server about a recording that the audio alone
 * cannot: which device it came from, and when the speaking stopped.
 *
 * Two independent jobs, both belonging to the client because both need the
 * live `MediaStream` rather than the finished file:
 *
 *  - `describeInputDevice` — is this a microphone or a loopback of the system's
 *    own output? A candidate on open speakers has a microphone that can hear
 *    the interview's questions; a candidate who has selected "Stereo Mix" as
 *    their input has one that hears *only* that. The server refuses audio it
 *    can prove is our own voice coming back (`tools/speech_service/source.py`),
 *    and this is the half of that evidence only the browser holds.
 *
 *  - `watchSilence` — end-of-speech detection, so a recording stops when the
 *    candidate stops talking rather than when they remember to press a button.
 *    Also the client end of the 15-second timeout: silence that goes on that
 *    long is a candidate who is not going to answer, or a microphone that is
 *    not working, and either way there is nothing to send.
 *
 * **Neither is trusted, and neither decides anything.** The device description
 * is a hint the server re-checks; the silence watcher only stops a recording
 * early, which the candidate could have done themselves. Everything that
 * determines what gets scored still happens server-side — this file makes the
 * room more responsive, it does not move any judgement into the browser.
 */

/** What gets sent alongside the audio. Mirrors `input_device` in the MCP schema. */
export interface InputDeviceHint {
  hint: "microphone" | "speaker" | "unknown";
  label?: string;
  echo_cancellation?: boolean;
}

/**
 * Capture-device names that ARE the system's own output. Kept in step with
 * `_LOOPBACK_LABELS` in `tools/speech_service/source.py` — the server is the
 * authority and re-checks the raw label, so a browser this list misses is
 * caught there rather than let through.
 */
const LOOPBACK_LABELS = [
  "stereo mix",
  "what u hear",
  "wave out",
  "loopback",
  "cable output",
  "voicemeeter out",
  "blackhole",
  "soundflower",
  "monitor of ",
];

/**
 * Describes the device behind a live capture stream.
 *
 * Everything here is best-effort by construction: `label` is empty until the
 * user has granted permission at least once, `getSettings()` fills in different
 * fields on different engines, and Safari reports almost nothing. An
 * unreadable device is `"unknown"`, which means "the server decides on the
 * audio alone" — the behaviour before any of this existed.
 */
export function describeInputDevice(stream: MediaStream): InputDeviceHint {
  try {
    const track = stream.getAudioTracks()[0];
    if (!track) return { hint: "unknown" };

    const settings = track.getSettings?.() ?? {};
    const label = (track.label || "").trim();
    const lowered = label.toLowerCase();

    if (lowered && LOOPBACK_LABELS.some((marker) => lowered.includes(marker))) {
      return { hint: "speaker", label, echo_cancellation: settings.echoCancellation };
    }

    return {
      // A track that is not a known loopback is a microphone as far as the
      // browser is concerned. It says nothing about whether that microphone can
      // *hear* the speakers — that is the transcript check's job, server-side.
      hint: label ? "microphone" : "unknown",
      ...(label ? { label } : {}),
      ...(typeof settings.echoCancellation === "boolean" ? { echo_cancellation: settings.echoCancellation } : {}),
    };
  } catch {
    return { hint: "unknown" };
  }
}

export interface SilenceWatchOptions {
  /** Continuous silence, in ms, before `onSilenceTimeout` fires. */
  timeoutMs: number;
  /** Continuous silence, in ms, after speech has been heard, before `onSpeechEnded` fires. */
  trailingSilenceMs: number;
  /** Nobody ever started speaking — the mic is off, or they are not there. */
  onSilenceTimeout: () => void;
  /** They spoke and have now stopped. */
  onSpeechEnded: () => void;
  /** First time speech is detected, so the room can say it is hearing them. */
  onSpeechStarted?: () => void;
}

export interface SilenceWatch {
  stop: () => void;
  /** Whether any speech was detected at all, for the caller's own messaging. */
  heardSpeech: () => boolean;
}

/**
 * Frame threshold, in dBFS. Deliberately more permissive than the server's
 * adaptive gate in `vad.py`: the consequence of being wrong here is only that a
 * recording runs a second longer than it needed to, whereas the server's gate
 * decides whether audio is transcribed at all.
 */
const SILENCE_DBFS = -50;
const FRAME_MS = 100;

/**
 * Watches a live stream and reports when the speaking stops.
 *
 * Returns a no-op watch when the Web Audio API is unavailable, so a browser
 * without it simply keeps the manual stop button — the same fallback ladder
 * `lib/speech.ts` uses for every capability it depends on.
 */
export function watchSilence(stream: MediaStream, options: SilenceWatchOptions): SilenceWatch {
  let heard = false;
  let stopped = false;

  try {
    const AudioContextCtor =
      window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const context = new AudioContextCtor();
    const analyser = context.createAnalyser();
    analyser.fftSize = 2048;
    context.createMediaStreamSource(stream).connect(analyser);

    const samples = new Float32Array(analyser.fftSize);
    let silentMs = 0;

    const timer = window.setInterval(() => {
      if (stopped) return;
      analyser.getFloatTimeDomainData(samples);

      let sum = 0;
      for (let i = 0; i < samples.length; i += 1) sum += samples[i] * samples[i];
      const dbfs = 20 * Math.log10(Math.max(Math.sqrt(sum / samples.length), 1e-10));

      if (dbfs > SILENCE_DBFS) {
        if (!heard) {
          heard = true;
          options.onSpeechStarted?.();
        }
        silentMs = 0;
        return;
      }

      silentMs += FRAME_MS;

      // Two different silences with two different meanings. A pause after an
      // answer ends the recording; a recording that never had any speech in it
      // gets the full timeout before being given up on, because a candidate
      // thinking before they start talking is normal and cutting them off at
      // the trailing-silence threshold would be rude and wrong.
      if (heard && silentMs >= options.trailingSilenceMs) {
        stop();
        options.onSpeechEnded();
      } else if (!heard && silentMs >= options.timeoutMs) {
        stop();
        options.onSilenceTimeout();
      }
    }, FRAME_MS);

    function stop(): void {
      if (stopped) return;
      stopped = true;
      window.clearInterval(timer);
      void context.close();
    }

    return { stop, heardSpeech: () => heard };
  } catch {
    return { stop: () => {}, heardSpeech: () => heard };
  }
}

"use client";

/**
 * Shared GSAP motion primitives.
 *
 * Every animated page in this app should reach for one of these rather than
 * hand-rolling a `useGSAP` call, so the reduced-motion guard lives in exactly
 * one place. `globals.css`'s `prefers-reduced-motion` block only covers CSS
 * transitions/animations — it cannot reach a GSAP timeline created in JS, so
 * every export here checks `prefersReducedMotion()` itself before creating
 * one. A visitor who asked for less motion gets the finished state
 * immediately, not a skipped-then-jumping animation.
 */

import { useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { useGSAP } from "@gsap/react";

if (typeof window !== "undefined") {
  gsap.registerPlugin(ScrollTrigger);
}

export function prefersReducedMotion(): boolean {
  return typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

/**
 * Fade+rise reveal, triggered once a container scrolls into view. Animates
 * the container's direct children if it has any, otherwise the container
 * itself — so it works equally on a bento grid (each card staggers in) or a
 * single card.
 */
export function useReveal<T extends HTMLElement>(options?: {
  y?: number;
  stagger?: number;
  start?: string;
}) {
  const ref = useRef<T | null>(null);
  useGSAP(() => {
    if (!ref.current || prefersReducedMotion()) return;
    const el = ref.current;
    const targets = el.children.length ? Array.from(el.children) : [el];
    gsap.set(targets, { opacity: 0, y: options?.y ?? 24 });
    gsap.to(targets, {
      opacity: 1,
      y: 0,
      duration: 0.7,
      ease: "power3.out",
      stagger: options?.stagger ?? 0.08,
      scrollTrigger: {
        trigger: el,
        start: options?.start ?? "top 85%",
        once: true,
      },
    });
  }, []);
  return ref;
}

/**
 * Fade+rise entrance that fires on mount rather than on scroll — for hero
 * sections and above-the-fold content that should animate in immediately
 * instead of waiting for a ScrollTrigger that will never fire because the
 * element is already in view.
 */
export function useHeroReveal<T extends HTMLElement>(delay = 0) {
  const ref = useRef<T | null>(null);
  useGSAP(() => {
    if (!ref.current || prefersReducedMotion()) return;
    const el = ref.current;
    const targets = el.children.length ? Array.from(el.children) : [el];
    gsap.fromTo(
      targets,
      { opacity: 0, y: 28 },
      { opacity: 1, y: 0, duration: 0.9, delay, ease: "power3.out", stagger: 0.1 },
    );
  }, []);
  return ref;
}

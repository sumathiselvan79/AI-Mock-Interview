/**
 * The room page's half of the live-channel protocol.
 *
 * The gateway's socket is request/response in one direction only: it pushes
 * `question`, `follow_up` and `session_complete`, but it never volunteers the
 * NEXT question — the client has to ask for one. That is deliberate (the
 * candidate controls the pace), and it means every event that ends a turn has
 * to be paired with the request that starts the next one.
 *
 * Getting that pairing wrong stalls the whole interview with no error anywhere,
 * so it lives here as a pure function rather than inline in the component: it
 * is the one piece of the page that is protocol rather than presentation, and
 * it is the piece worth testing directly.
 */

/** A parsed server frame. Deliberately loose — the socket is untyped on the wire. */
export interface LiveServerEvent {
  type?: unknown;
  [key: string]: unknown;
}

/** A frame to send back. Open-ended so a future reply can carry payload fields. */
export interface ClientMessage {
  type: string;
  [key: string]: unknown;
}

/**
 * The message the page must send back in response to `event`, or null when the
 * event needs no reply.
 *
 * The only event that needs one is an accepted answer. The gateway replies to
 * `submit_answer_text`, `submit_answer_audio` and `submit_follow_up_*` with
 * `{ type: "question", answered: true }` — meaning "recorded, and there is no
 * follow-up to ask" — which ends the turn without starting another. A
 * `follow_up` needs no reply because the candidate answers it; a fresh question
 * (`answered` absent) must NOT be replied to, or the client would request
 * questions in a loop.
 *
 * Three events exist specifically to NOT end a turn, and so must never be
 * replied to (HUMAN_INTERACTION_FLOW.md §1, §3, §8): `acknowledgment` is the
 * "mm-hm" spoken while the real response is still being computed, `continuer`
 * is a line spoken to hold the conversation open while it still is, and
 * `clarification` is the interviewer repeating a question the candidate asked
 * about. Requesting the next question after any of them would skip a question
 * nobody answered. They fall through to `null` below, which is the correct
 * behaviour and is asserted in `live-protocol.test.ts`.
 *
 * `continuer` is the one that most needs the guard rather than merely
 * benefiting from it. The other two arrive after their handler has returned;
 * a continuer is pushed from *inside* a handler that is still running, so a
 * reply to it would put a `next_question` on the wire ahead of the answer the
 * client is still waiting for — and the question it skipped would be the one
 * that answer was about to produce.
 */
export function replyTo(event: LiveServerEvent): ClientMessage | null {
  if (event.type === "question" && event.answered === true) {
    return { type: "next_question" };
  }
  return null;
}

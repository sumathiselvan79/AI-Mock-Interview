/**
 * The transcription panel's scoping rule.
 *
 * Pinned here rather than left to the component because the failure mode is
 * silent and it is the candidate who pays for it: if the cut is wrong in one
 * direction the previous answer sits in the box the candidate types into while
 * the next question is being asked, and reads as part of what they are about to
 * send; wrong in the other and the answer they are still speaking disappears
 * mid-sentence. Neither throws, and neither looks like a bug in a screenshot
 * taken at the wrong moment.
 */

import { describe, expect, it } from "vitest";
import { answersForCurrentPrompt, lastInterviewerIndex } from "../lib/room-turns.js";

type Turn =
  | { id: string; role: "interviewer"; kind: string; text: string }
  | { id: string; role: "candidate"; text: string; live: boolean };

const ask = (id: string, kind = "question"): Turn => ({ id, role: "interviewer", kind, text: `Q ${id}` });
const say = (id: string, live = false): Turn => ({ id, role: "candidate", text: `A ${id}`, live });

const ids = (turns: readonly Turn[]) => turns.map((t) => t.id);

describe("answersForCurrentPrompt", () => {
  it("shows nothing before the candidate has spoken", () => {
    expect(answersForCurrentPrompt([ask("q1")])).toEqual([]);
  });

  it("shows the answer to the question currently on the table", () => {
    expect(ids(answersForCurrentPrompt([ask("q1"), say("a1")]))).toEqual(["a1"]);
  });

  it("drops the previous answer the moment the next question is appended", () => {
    // The whole point of the change. Nothing calls a reset — appending the
    // interviewer's turn is what moves the cut, so a missing clear() cannot
    // leave stale text behind.
    const turns = [ask("q1"), say("a1"), ask("q2")];
    expect(answersForCurrentPrompt(turns)).toEqual([]);
    expect(ids(answersForCurrentPrompt([...turns, say("a2")]))).toEqual(["a2"]);
  });

  it("treats every kind of interviewer turn as a new prompt", () => {
    // A follow-up, a repeat, and the session's greeting are all things the
    // interviewer said; an answer given before any of them belongs to what came
    // before it, not to what is being asked now.
    for (const kind of ["question", "follow_up", "clarification", "greeting"]) {
      expect(answersForCurrentPrompt([ask("q1"), say("a1"), ask("next", kind)])).toEqual([]);
    }
  });

  it("keeps every answer given since the last prompt, in order", () => {
    // A retry, or a live preview settling beside an earlier one: more than one
    // candidate turn can belong to a single prompt, and the panel shows them all.
    const turns = [ask("q1"), say("a1"), ask("q2"), say("a2"), say("a3")];
    expect(ids(answersForCurrentPrompt(turns))).toEqual(["a2", "a3"]);
  });

  it("keeps the in-flight live preview visible", () => {
    // The live turn is what the candidate is watching themselves say. Scoping
    // must never hide it, or dictation looks broken.
    const turns = [ask("q1"), say("a1"), ask("q2"), say("a2", true)];
    const shown = answersForCurrentPrompt(turns);
    expect(ids(shown)).toEqual(["a2"]);
    expect(shown[0].live).toBe(true);
  });

  it("shows an answer given before the interviewer ever spoke", () => {
    // Degenerate, but the -1 sentinel has to slice from 0 rather than from the
    // end — `slice(-1 + 1)` is `slice(0)`, not `slice(-1)`.
    expect(ids(answersForCurrentPrompt([say("a1")]))).toEqual(["a1"]);
  });

  it("is a filter, not a mutation", () => {
    const turns = [ask("q1"), say("a1"), ask("q2"), say("a2")];
    const before = ids(turns);
    answersForCurrentPrompt(turns);
    expect(ids(turns)).toEqual(before);
  });
});

describe("lastInterviewerIndex", () => {
  it("is -1 when the interviewer has not spoken", () => {
    expect(lastInterviewerIndex([])).toBe(-1);
    expect(lastInterviewerIndex([say("a1")])).toBe(-1);
  });

  it("finds the most recent one, not the first", () => {
    expect(lastInterviewerIndex([ask("q1"), say("a1"), ask("q2")])).toBe(2);
  });
});

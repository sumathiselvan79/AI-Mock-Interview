/**
 * Regression: the interview loop has to advance on its own.
 *
 * The gateway's live channel pushes questions but never volunteers the next
 * one — the client asks. The room page asked exactly once, in `socket.onopen`,
 * and nowhere else. So the first question arrived, the candidate answered it,
 * the server acknowledged with `{ type: "question", answered: true }`, the page
 * moved to phase "thinking" — and stopped. No error, no timeout, no second
 * question. The only control that still did anything was the "Skip" button,
 * which is labelled as skipping the question the candidate had just answered.
 *
 * The pairing of "turn ended" to "ask for the next one" is the protocol rule
 * being pinned here, including the two ways to get it wrong: never asking
 * (the stall) and asking on every `question` frame (an infinite loop).
 */

import { describe, expect, it } from "vitest";
import { replyTo } from "../lib/live-protocol.js";

describe("replyTo", () => {
  it("asks for the next question once an answer is accepted", () => {
    // What the gateway sends after `submit_answer_text` when the Follow-up
    // Agent decided no probe was warranted.
    expect(replyTo({ type: "question", answered: true, answer_id: "a1", evaluation: { score: 4 } })).toEqual({
      type: "next_question",
    });
  });

  it("asks for the next question once an answered follow-up is accepted", () => {
    // `submit_follow_up_text` / `submit_follow_up_audio` reply with the same
    // frame, carrying only the answer id.
    expect(replyTo({ type: "question", answered: true, answer_id: "a1" })).toEqual({ type: "next_question" });
  });

  it("does NOT ask again when a fresh question arrives", () => {
    // The other failure mode: replying to every `question` frame would make the
    // page request questions in a loop and burn the whole budget instantly.
    expect(
      replyTo({ type: "question", id: "q2", text: "Walk me through it.", topic: "systems", audio_url: null }),
    ).toBeNull();
  });

  it("does not ask while a follow-up is outstanding", () => {
    // The candidate answers the probe; requesting a new question here would
    // talk over it.
    expect(replyTo({ type: "follow_up", answer_id: "a1", text: "Why that tradeoff?" })).toBeNull();
  });

  it("does not ask after the micro-acknowledgment", () => {
    // (HUMAN_INTERACTION_FLOW.md §1) The "mm-hm" is spoken while the real
    // response is still being computed. Replying here would request the next
    // question before the answer that is still in flight has been scored — and
    // then two frames would race to be the next thing the candidate hears.
    expect(replyTo({ type: "acknowledgment", text: "Mm-hm.", audio_url: null })).toBeNull();
  });

  it("does not ask after any continuer, whatever its kind", () => {
    // (§8) A continuer is pushed from inside a handler that has not returned
    // yet — the reply the client is waiting for is still being computed. A
    // `next_question` sent here would land ahead of it and skip the question
    // that reply was about to produce. All four kinds, because the guard is on
    // the frame type and must not quietly become a guard on three of them.
    for (const kind of ["opening", "holding", "selection", "follow_up_receipt"]) {
      expect(replyTo({ type: "continuer", kind, text: "One moment.", audio_url: null })).toBeNull();
    }
  });

  it("does not ask after a repeat or clarify request", () => {
    // (§3) The candidate asked about the question rather than answering it.
    // Nothing was scored and the same question is still on the table; asking
    // for the next one would skip a question nobody has answered.
    expect(replyTo({ type: "clarification", kind: "repeat", question_id: "q1", text: "Of course. ..." })).toBeNull();
  });

  it("does not ask once the session is over", () => {
    expect(replyTo({ type: "session_complete", state: "WRAP_UP" })).toBeNull();
  });

  it("needs no reply for the informational frames", () => {
    for (const type of [
      "connected",
      "timer_tick",
      "transcript_draft",
      "transcript_rejected",
      "paste_detected",
      "focus_recorded",
      "coding_problem",
      "error",
    ]) {
      expect(replyTo({ type }), `${type} should need no reply`).toBeNull();
    }
  });

  it("treats a merely truthy `answered` as not answered", () => {
    // The flag is a literal `true` on the wire. Anything else is a frame this
    // client does not understand, and guessing would risk the infinite loop.
    expect(replyTo({ type: "question", answered: "yes" })).toBeNull();
    expect(replyTo({ type: "question", answered: 1 })).toBeNull();
    expect(replyTo({ type: "question", answered: false })).toBeNull();
  });

  it("ignores a frame with no type at all", () => {
    expect(replyTo({})).toBeNull();
    expect(replyTo({ answered: true })).toBeNull();
  });
});

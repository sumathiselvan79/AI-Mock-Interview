# Gateway image. Stage 1 runs TypeScript directly through tsx — there is no
# build step yet (see tsconfig.base.json). Swap in a bundle step before this
# goes anywhere near production traffic.

FROM node:22-alpine

WORKDIR /app

# Workspace manifests first, so `npm ci` is cached independently of source.
COPY package.json package-lock.json ./
COPY packages/shared-types/package.json packages/shared-types/
COPY packages/mcp-schemas/package.json packages/mcp-schemas/
COPY apps/gateway/package.json apps/gateway/
COPY agents/ agents/
COPY mcp-servers/ mcp-servers/

RUN npm ci --omit=dev --ignore-scripts

COPY . .

ENV NODE_ENV=production
ENV PORT=4000
EXPOSE 4000

# AUTH_TOKEN_SECRET, DATABASE_URL and REDIS_URL must be supplied at run time;
# the gateway refuses to start in production without a real signing secret.
CMD ["npx", "tsx", "apps/gateway/src/index.ts"]

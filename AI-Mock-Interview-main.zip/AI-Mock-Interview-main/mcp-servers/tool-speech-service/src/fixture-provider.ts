/**
 * Deterministic speech provider for CI and for `npm run dev` before models are
 * downloaded.
 *
 * It is a real audio codec, not a mock object: `synthesize` emits a genuine
 * 16-bit PCM WAV whose length tracks the text, and `transcribe` decodes a real
 * WAV and derives confidence from the actual signal amplitude. The transcript
 * rides in a standard `LIST/INFO` comment chunk, which is why a round trip
 * works without an acoustic model.
 *
 * What this does NOT do is recognise arbitrary speech — audio it did not
 * produce transcribes as a failure, loudly, rather than as a plausible guess.
 */

import {
  decodeWav,
  encodeWav,
  rms,
  TranscriptionFailed,
  type SpeechProvider,
  type SynthesisResult,
  type TranscriptionResult,
} from "./provider.js";

const SAMPLE_RATE = 16_000;
/** Roughly natural speaking pace, so durations are believable in the UI. */
const WORDS_PER_MINUTE = 150;
const MIN_DURATION_MS = 400;

/**
 * Amplitude the fixture writes for clean audio. A caller can scale a clip down
 * to simulate a bad microphone, which is exactly how the low-confidence path
 * gets exercised.
 */
const CLEAN_AMPLITUDE = 0.35;

/**
 * RMS of a clean clip, which is what `transcribe` compares an incoming clip
 * against. It is NOT `CLEAN_AMPLITUDE`: that is a peak, and the fixture writes a
 * carrier sine under a half-period sine envelope, each of which contributes a
 * 1/sqrt(2) factor — so a clean clip's RMS is half its peak. Comparing an RMS to
 * a peak capped the fixture's own clean audio at 0.5 confidence, below the
 * Speech Service's 0.6 floor, which meant no fixture-synthesised answer could
 * ever be accepted on a machine without the sherpa-onnx models.
 */
const CLEAN_RMS = CLEAN_AMPLITUDE * 0.5;

const INFO_CHUNK_ID = "LIST";
const COMMENT_TAG = "ICMT";

export class FixtureSpeechProvider implements SpeechProvider {
  readonly name = "fixture";

  async synthesize(text: string): Promise<SynthesisResult> {
    const words = text.split(/\s+/).filter(Boolean).length;
    const durationMs = Math.max(MIN_DURATION_MS, Math.round((words / WORDS_PER_MINUTE) * 60_000));
    const sampleCount = Math.round((durationMs / 1000) * SAMPLE_RATE);

    // A quiet tone rather than digital silence, so amplitude-based confidence
    // behaves the way it would on real speech.
    const samples = new Int16Array(sampleCount);
    for (let i = 0; i < sampleCount; i += 1) {
      const envelope = Math.sin((Math.PI * i) / sampleCount);
      samples[i] = Math.round(Math.sin((2 * Math.PI * 140 * i) / SAMPLE_RATE) * envelope * CLEAN_AMPLITUDE * 32767);
    }

    return {
      audio: withTranscript(encodeWav(samples, SAMPLE_RATE), text),
      durationMs,
      sampleRate: SAMPLE_RATE,
    };
  }

  async transcribe(audio: Uint8Array): Promise<TranscriptionResult> {
    const decoded = decodeWav(audio);
    const transcript = readTranscript(audio);

    if (transcript === null) {
      // Honest failure: this provider cannot recognise speech it did not
      // synthesise, and guessing would be fabrication (soul.md §6).
      throw new TranscriptionFailed(
        "the fixture speech provider cannot transcribe external audio — download the sherpa-onnx models (npm run speech:models) to transcribe real recordings",
      );
    }

    // Confidence from signal level: quiet or clipped audio is the real-world
    // reason a transcript should not be trusted.
    const level = rms(decoded.samples);
    const confidence = Math.max(0, Math.min(1, Math.round((level / CLEAN_RMS) * 100) / 100));

    return { transcript, confidence };
  }
}

/** Appends a LIST/INFO chunk carrying the transcript, before the data chunk. */
function withTranscript(wav: Uint8Array, text: string): Uint8Array {
  const buffer = Buffer.from(wav);
  const comment = Buffer.from(`${text}\0`, "utf8");
  const padded = comment.length % 2 === 0 ? comment : Buffer.concat([comment, Buffer.alloc(1)]);

  const listPayload = Buffer.concat([
    Buffer.from("INFO", "latin1"),
    Buffer.from(COMMENT_TAG, "latin1"),
    uint32(padded.length),
    padded,
  ]);
  const listChunk = Buffer.concat([Buffer.from(INFO_CHUNK_ID, "latin1"), uint32(listPayload.length), listPayload]);

  // Splice the chunk in after "WAVE" and before the fmt chunk, then fix RIFF size.
  const head = buffer.subarray(0, 12);
  const tail = buffer.subarray(12);
  const out = Buffer.concat([head, listChunk, tail]);
  out.writeUInt32LE(out.length - 8, 4);
  return new Uint8Array(out);
}

export function readTranscript(wav: Uint8Array): string | null {
  const buffer = Buffer.from(wav);
  let offset = 12;
  while (offset + 8 <= buffer.length) {
    const id = buffer.toString("latin1", offset, offset + 4);
    const size = buffer.readUInt32LE(offset + 4);
    if (id === INFO_CHUNK_ID) {
      const payload = buffer.subarray(offset + 8, offset + 8 + size);
      const tagIndex = payload.indexOf(COMMENT_TAG, 4, "latin1");
      if (tagIndex >= 0) {
        const length = payload.readUInt32LE(tagIndex + 4);
        return payload
          .subarray(tagIndex + 8, tagIndex + 8 + length)
          .toString("utf8")
          .replace(/\0+$/, "");
      }
    }
    offset += 8 + size + (size % 2);
  }
  return null;
}

/**
 * Scales a clip's amplitude. Used by tests and by the dev UI to reproduce the
 * "bad microphone" case that must trigger the typed-text fallback.
 */
export function attenuate(wav: Uint8Array, factor: number): Uint8Array {
  const buffer = Buffer.from(wav);
  let offset = 12;
  while (offset + 8 <= buffer.length) {
    const id = buffer.toString("latin1", offset, offset + 4);
    const size = buffer.readUInt32LE(offset + 4);
    if (id === "data") {
      const start = offset + 8;
      const end = Math.min(start + size, buffer.length);
      for (let i = start; i + 1 < end; i += 2) {
        buffer.writeInt16LE(Math.round(buffer.readInt16LE(i) * factor), i);
      }
      break;
    }
    offset += 8 + size + (size % 2);
  }
  return new Uint8Array(buffer);
}

function uint32(value: number): Buffer {
  const buffer = Buffer.alloc(4);
  buffer.writeUInt32LE(value, 0);
  return buffer;
}

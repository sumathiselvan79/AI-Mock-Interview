/**
 * Speech Service Tool — INSTRUCTIONS.md §5.6.
 *
 * `synthesize_speech` turns an agent's question into audio; `transcribe_speech`
 * turns a candidate's recording into text. Callable by the Harness Agent only —
 * the gateway enforces that via `ALLOWED_CALLERS`, because audio is a property
 * of the live frontend connection rather than any one agent's job.
 *
 * Two rules this tool owns rather than delegates:
 *
 *  - **Low confidence is an error, not a value.** Below `MIN_CONFIDENCE` the
 *    tool returns `transcription_low_confidence` instead of handing back a
 *    transcript, so nothing downstream can score it by accident
 *    (soul.md §5, `INSTRUCTIONS.md §5.6`). The transcript still travels *on the
 *    error* so the harness can offer it as a suggestion for the typed fallback
 *    — shown to the candidate to correct, never fed to Eval.
 *  - **Raw audio is retained only as long as it takes to produce a transcript**
 *    (§8), unless the candidate opted into keeping recordings. This tool deletes
 *    it in `transcribe_speech` itself rather than trusting a caller to remember.
 */

import {
  McpHandlerError,
  type FileStore,
  type McpServerHandler,
} from "@mia/shared-types";
import { FixtureSpeechProvider } from "./fixture-provider.js";
import { SherpaSpeechProvider, checkModels } from "./sherpa-provider.js";
import { SynthesisFailed, TranscriptionFailed, type SpeechProvider } from "./provider.js";

export * from "./provider.js";
export * from "./fixture-provider.js";
export * from "./sherpa-provider.js";

export const SERVER_NAME = "tool-speech-service";
export const METHODS = ["synthesize_speech", "transcribe_speech"] as const;

/**
 * Below this, a transcript must not reach the Follow-up Agent or the Eval Tool.
 * Matches the Eval Tool's own floor so the two cannot drift apart.
 */
export const MIN_CONFIDENCE = 0.6;

export interface SpeechServiceDeps {
  /** Audio blobs live in the same store as resumes, under `audio/`. */
  files: FileStore;
  provider: SpeechProvider;
  /** Whether this session's candidate opted into keeping recordings (§8). */
  audioRetentionOptIn?(sessionId: string): Promise<boolean>;
}

export interface ProviderChoice {
  provider: SpeechProvider;
  /** Why this provider was chosen — logged at startup so it is never a mystery. */
  reason: string;
}

/**
 * Loading the ONNX graphs costs seconds and hundreds of megabytes, so the
 * choice is made once per process per model directory. Without this, anything
 * that builds a second gateway — the test suite, a hot reload — pays the whole
 * cost again.
 */
const providerCache = new Map<string, ProviderChoice>();

/**
 * Picks the real provider when models are present and the fixture otherwise.
 * Never throws: a missing model must degrade the voice pipeline, not stop the
 * gateway from booting.
 */
export function selectSpeechProvider(modelDir: string): ProviderChoice {
  const cached = providerCache.get(modelDir);
  if (cached) return cached;

  const choice = loadSpeechProvider(modelDir);
  providerCache.set(modelDir, choice);
  return choice;
}

function loadSpeechProvider(modelDir: string): ProviderChoice {
  try {
    const availability = checkModels(modelDir);
    const provider = SherpaSpeechProvider.create({ modelDir });
    if (provider && availability.tts && availability.asr) {
      return { provider, reason: `sherpa-onnx models loaded from ${modelDir}` };
    }
    if (provider) {
      return {
        provider,
        reason: `sherpa-onnx partially loaded (tts: ${availability.tts}, asr: ${availability.asr})`,
      };
    }
    return {
      provider: new FixtureSpeechProvider(),
      reason: `no sherpa-onnx models in ${modelDir}; run "npm run speech:models" for real speech`,
    };
  } catch (err) {
    return {
      provider: new FixtureSpeechProvider(),
      reason: `sherpa-onnx unavailable (${(err as Error).message}); using the fixture provider`,
    };
  }
}

export function createToolSpeechServiceServer(deps: SpeechServiceDeps): McpServerHandler {
  return {
    name: SERVER_NAME,
    async call(method: string, params: unknown): Promise<unknown> {
      switch (method) {
        case "synthesize_speech":
          return synthesize(deps, params as { text: string; session_id?: string; voice?: string });
        case "transcribe_speech":
          return transcribe(deps, params as { audio_ref: string; session_id?: string });
        default:
          throw new McpHandlerError("unknown_method", `${SERVER_NAME} has no method ${method}`);
      }
    },
  };
}

async function synthesize(
  deps: SpeechServiceDeps,
  params: { text: string; session_id?: string; voice?: string },
) {
  try {
    const result = await deps.provider.synthesize(params.text, params.voice);
    const stored = await deps.files.put({
      sessionId: params.session_id ?? "shared",
      filename: `question-${Date.now()}.wav`,
      contentType: "audio/wav",
      bytes: result.audio,
    });
    return { audio_url: `/audio/${stored.ref}`, duration_ms: result.durationMs };
  } catch (err) {
    // The harness falls back to showing the question as text only (§5.6).
    throw new McpHandlerError(
      "synthesis_failed",
      err instanceof SynthesisFailed ? err.message : `synthesis failed: ${(err as Error).message}`,
    );
  }
}

async function transcribe(deps: SpeechServiceDeps, params: { audio_ref: string; session_id?: string }) {
  const ref = params.audio_ref.replace(/^\/audio\//, "");
  const stored = await deps.files.get(ref);
  if (!stored) {
    throw new McpHandlerError("transcription_failed", `no stored audio for ref ${params.audio_ref}`);
  }

  let result;
  try {
    result = await deps.provider.transcribe(stored.bytes);
  } catch (err) {
    await discardAudio(deps, ref, params.session_id);
    throw new McpHandlerError(
      "transcription_failed",
      err instanceof TranscriptionFailed ? err.message : `transcription failed: ${(err as Error).message}`,
    );
  }

  // Raw audio has served its purpose the moment a transcript exists (§8).
  await discardAudio(deps, ref, params.session_id);

  if (result.confidence < MIN_CONFIDENCE) {
    throw new McpHandlerError(
      "transcription_low_confidence",
      JSON.stringify({
        message: `transcription confidence ${result.confidence} is below ${MIN_CONFIDENCE}; re-prompt the candidate or offer the typed-text fallback`,
        confidence: result.confidence,
        // Carried so the harness can pre-fill the typed fallback for the
        // candidate to correct. It must never be scored as-is.
        draft_transcript: result.transcript,
      }),
    );
  }

  return { transcript: result.transcript, confidence: result.confidence };
}

async function discardAudio(deps: SpeechServiceDeps, ref: string, sessionId?: string): Promise<void> {
  if (sessionId && deps.audioRetentionOptIn && (await deps.audioRetentionOptIn(sessionId))) return;
  await deps.files.delete(ref);
}

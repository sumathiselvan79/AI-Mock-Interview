/**
 * The speech provider seam.
 *
 * `sherpa-onnx-node` is the real implementation (`CLAUDE.md §6`,
 * `INSTRUCTIONS.md §5.6`): self-hosted TTS and STT via ONNX Runtime, in-process,
 * no Python sidecar and no cloud API. It needs model files on disk, which are
 * downloaded separately (`npm run speech:models`) because they are far too
 * large to vendor.
 *
 * The fixture provider exists so the rest of the voice pipeline — audio
 * storage, refs, latency budgets, confidence thresholds, the low-confidence
 * fallback, consent gating — is exercised in CI on a machine with no models
 * present. It produces real WAV bytes and carries its transcript inside the
 * file, so everything around the acoustic model is genuinely tested; only the
 * acoustic model itself is stubbed.
 */

export interface SynthesisResult {
  /** 16-bit PCM WAV. */
  audio: Uint8Array;
  durationMs: number;
  sampleRate: number;
}

export interface TranscriptionResult {
  transcript: string;
  /** 0-1. Below the Speech Service's threshold the harness must not score it. */
  confidence: number;
}

export interface SpeechProvider {
  readonly name: string;
  synthesize(text: string, voice?: string): Promise<SynthesisResult>;
  transcribe(audio: Uint8Array): Promise<TranscriptionResult>;
  close?(): void;
}

export class SynthesisFailed extends Error {
  readonly code = "synthesis_failed";
}

export class TranscriptionFailed extends Error {
  readonly code = "transcription_failed";
}

// ------------------------------------------------------------------ WAV codec

const WAV_HEADER_BYTES = 44;

/** Minimal 16-bit mono PCM WAV writer. */
export function encodeWav(samples: Int16Array, sampleRate: number): Uint8Array {
  const buffer = Buffer.alloc(WAV_HEADER_BYTES + samples.length * 2);
  buffer.write("RIFF", 0);
  buffer.writeUInt32LE(36 + samples.length * 2, 4);
  buffer.write("WAVE", 8);
  buffer.write("fmt ", 12);
  buffer.writeUInt32LE(16, 16); // PCM chunk size
  buffer.writeUInt16LE(1, 20); // format: PCM
  buffer.writeUInt16LE(1, 22); // channels: mono
  buffer.writeUInt32LE(sampleRate, 24);
  buffer.writeUInt32LE(sampleRate * 2, 28); // byte rate
  buffer.writeUInt16LE(2, 32); // block align
  buffer.writeUInt16LE(16, 34); // bits per sample
  buffer.write("data", 36);
  buffer.writeUInt32LE(samples.length * 2, 40);
  for (let i = 0; i < samples.length; i += 1) buffer.writeInt16LE(samples[i] as number, 44 + i * 2);
  return new Uint8Array(buffer);
}

export interface DecodedWav {
  samples: Float32Array;
  sampleRate: number;
  durationMs: number;
}

export function decodeWav(bytes: Uint8Array): DecodedWav {
  const buffer = Buffer.from(bytes);
  if (buffer.length < WAV_HEADER_BYTES || buffer.toString("latin1", 0, 4) !== "RIFF") {
    throw new TranscriptionFailed("audio is not a RIFF/WAV file");
  }

  // Both `fmt ` and `data` are located by walking the chunk list. Reading them
  // at fixed offsets only works when `fmt ` happens to come first, and writers
  // legitimately put LIST/fact chunks ahead of it.
  let offset = 12;
  let sampleRate = 0;
  let bitsPerSample = 0;
  let dataStart = -1;
  let dataLength = 0;

  while (offset + 8 <= buffer.length) {
    const id = buffer.toString("latin1", offset, offset + 4);
    const size = buffer.readUInt32LE(offset + 4);
    const body = offset + 8;

    if (id === "fmt " && body + 16 <= buffer.length) {
      sampleRate = buffer.readUInt32LE(body + 4);
      bitsPerSample = buffer.readUInt16LE(body + 14);
    } else if (id === "data") {
      dataStart = body;
      dataLength = Math.min(size, buffer.length - dataStart);
      break;
    }
    offset += 8 + size + (size % 2);
  }

  if (sampleRate === 0) throw new TranscriptionFailed("WAV file has no fmt chunk");
  if (bitsPerSample !== 16) throw new TranscriptionFailed(`expected 16-bit PCM, got ${bitsPerSample}`);
  if (dataStart < 0) throw new TranscriptionFailed("WAV file has no data chunk");

  const sampleCount = Math.floor(dataLength / 2);
  const samples = new Float32Array(sampleCount);
  for (let i = 0; i < sampleCount; i += 1) {
    samples[i] = buffer.readInt16LE(dataStart + i * 2) / 32768;
  }
  return { samples, sampleRate, durationMs: Math.round((sampleCount / sampleRate) * 1000) };
}

/** Root-mean-square amplitude — the signal-quality proxy used for confidence. */
export function rms(samples: Float32Array): number {
  if (samples.length === 0) return 0;
  let sum = 0;
  for (const sample of samples) sum += sample * sample;
  return Math.sqrt(sum / samples.length);
}

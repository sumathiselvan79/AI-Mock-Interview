/**
 * sherpa-onnx-node speech provider — the real TTS/STT implementation
 * (`CLAUDE.md §6`, `INSTRUCTIONS.md §5.6`). Self-hosted, in-process, no Python
 * sidecar and no cloud API.
 *
 * Models are not vendored — they are hundreds of megabytes. Run
 * `npm run speech:models` to fetch them, then point `SPEECH_MODEL_DIR` at the
 * directory. Without them the Speech Service falls back to the fixture
 * provider and says so.
 *
 * **Warm-up matters.** Measured on this repo: the first synthesis after loading
 * the VITS model takes ~3.7s, and every one after it 140-250ms. The 1.5s budget
 * in `INSTRUCTIONS.md §9` is about what a candidate waits for mid-interview, so
 * the model is warmed at construction and never on the candidate's clock.
 */

import { existsSync } from "node:fs";
import { join } from "node:path";
import { createRequire } from "node:module";
import {
  decodeWav,
  encodeWav,
  rms,
  SynthesisFailed,
  TranscriptionFailed,
  type SpeechProvider,
  type SynthesisResult,
  type TranscriptionResult,
} from "./provider.js";

const require = createRequire(import.meta.url);

/** Default layout produced by `npm run speech:models`. */
export const TTS_MODEL_SUBDIR = "vits-piper-en_US-amy-low";
export const ASR_MODEL_SUBDIR = "sherpa-onnx-whisper-small.en";

export interface SherpaPaths {
  ttsModel: string;
  ttsTokens: string;
  ttsDataDir: string;
  asrEncoder: string;
  asrDecoder: string;
  asrTokens: string;
}

export function resolveModelPaths(modelDir: string): SherpaPaths {
  const tts = join(modelDir, TTS_MODEL_SUBDIR);
  const asr = join(modelDir, ASR_MODEL_SUBDIR);
  return {
    ttsModel: join(tts, "en_US-amy-low.onnx"),
    ttsTokens: join(tts, "tokens.txt"),
    ttsDataDir: join(tts, "espeak-ng-data"),
    asrEncoder: join(asr, "small.en-encoder.int8.onnx"),
    asrDecoder: join(asr, "small.en-decoder.int8.onnx"),
    asrTokens: join(asr, "small.en-tokens.txt"),
  };
}

export interface ModelAvailability {
  tts: boolean;
  asr: boolean;
  missing: string[];
}

export function checkModels(modelDir: string): ModelAvailability {
  const paths = resolveModelPaths(modelDir);
  const missing: string[] = [];
  const present = (path: string): boolean => {
    if (existsSync(path)) return true;
    missing.push(path);
    return false;
  };

  const tts = [paths.ttsModel, paths.ttsTokens, paths.ttsDataDir].map(present).every(Boolean);
  const asr = [paths.asrEncoder, paths.asrDecoder, paths.asrTokens].map(present).every(Boolean);
  return { tts, asr, missing };
}

interface SherpaTts {
  sampleRate: number;
  generate(input: { text: string; sid: number; speed: number }): { samples: Float32Array; sampleRate: number };
}

interface SherpaStream {
  acceptWaveform(input: { sampleRate: number; samples: Float32Array }): void;
}

interface SherpaRecognizer {
  createStream(): SherpaStream;
  decode(stream: SherpaStream): void;
  getResult(stream: SherpaStream): { text: string; tokens?: string[] };
}

export interface SherpaOptions {
  modelDir: string;
  numThreads?: number;
  /** Skip the warm-up synthesis. Only for tests that measure cold start. */
  skipWarmup?: boolean;
}

export class SherpaSpeechProvider implements SpeechProvider {
  readonly name = "sherpa-onnx";

  private tts: SherpaTts | null = null;
  private recognizer: SherpaRecognizer | null = null;

  private constructor(
    private readonly paths: SherpaPaths,
    private readonly availability: ModelAvailability,
    private readonly numThreads: number,
  ) {}

  /** Returns null when the models are not on disk, so the caller can fall back. */
  static create(options: SherpaOptions): SherpaSpeechProvider | null {
    const availability = checkModels(options.modelDir);
    if (!availability.tts && !availability.asr) return null;

    const provider = new SherpaSpeechProvider(
      resolveModelPaths(options.modelDir),
      availability,
      options.numThreads ?? 4,
    );
    provider.load();
    if (!options.skipWarmup) provider.warmUp();
    return provider;
  }

  private load(): void {
    // Required lazily: the native addon should not be loaded at import time on
    // a machine that has no models and will never use it.
    const sherpa = require("sherpa-onnx-node") as {
      OfflineTts: new (config: unknown) => SherpaTts;
      OfflineRecognizer: new (config: unknown) => SherpaRecognizer;
    };

    if (this.availability.tts) {
      this.tts = new sherpa.OfflineTts({
        model: {
          vits: { model: this.paths.ttsModel, tokens: this.paths.ttsTokens, dataDir: this.paths.ttsDataDir },
          numThreads: this.numThreads,
          debug: false,
          provider: "cpu",
        },
        maxNumSentences: 1,
      });
    }

    if (this.availability.asr) {
      this.recognizer = new sherpa.OfflineRecognizer({
        featConfig: { sampleRate: 16_000, featureDim: 80 },
        modelConfig: {
          whisper: { encoder: this.paths.asrEncoder, decoder: this.paths.asrDecoder },
          tokens: this.paths.asrTokens,
          numThreads: this.numThreads,
          debug: false,
          provider: "cpu",
        },
      });
    }
  }

  /** Pays the one-off ONNX graph cost at startup rather than mid-interview. */
  private warmUp(): void {
    try {
      this.tts?.generate({ text: "Ready.", sid: 0, speed: 1 });
    } catch {
      // A failed warm-up is not fatal; the first real call will surface it.
    }
  }

  async synthesize(text: string): Promise<SynthesisResult> {
    if (!this.tts) throw new SynthesisFailed("no TTS model loaded");
    if (text.trim() === "") throw new SynthesisFailed("cannot synthesise empty text");

    let generated: { samples: Float32Array; sampleRate: number };
    try {
      generated = this.tts.generate({ text, sid: 0, speed: 1 });
    } catch (err) {
      throw new SynthesisFailed(`sherpa-onnx synthesis failed: ${(err as Error).message}`);
    }

    const samples = new Int16Array(generated.samples.length);
    for (let i = 0; i < generated.samples.length; i += 1) {
      const clamped = Math.max(-1, Math.min(1, generated.samples[i] as number));
      samples[i] = Math.round(clamped * 32767);
    }

    return {
      audio: encodeWav(samples, generated.sampleRate),
      durationMs: Math.round((generated.samples.length / generated.sampleRate) * 1000),
      sampleRate: generated.sampleRate,
    };
  }

  async transcribe(audio: Uint8Array): Promise<TranscriptionResult> {
    if (!this.recognizer) throw new TranscriptionFailed("no ASR model loaded");

    const decoded = decodeWav(audio);
    let text: string;
    try {
      const stream = this.recognizer.createStream();
      stream.acceptWaveform({ sampleRate: decoded.sampleRate, samples: decoded.samples });
      this.recognizer.decode(stream);
      text = this.recognizer.getResult(stream).text ?? "";
    } catch (err) {
      throw new TranscriptionFailed(`sherpa-onnx transcription failed: ${(err as Error).message}`);
    }

    return { transcript: text.trim(), confidence: deriveConfidence(text, decoded.samples, decoded.durationMs) };
  }
}

/**
 * Whisper via sherpa-onnx returns text with no confidence score, so the tool
 * derives one — and that derivation is stated here rather than hidden, because
 * everything downstream (the re-prompt, the typed fallback, the Eval Tool's
 * refusal) keys off this number.
 *
 * It combines two observable signals:
 *  - **level**: audio too quiet to hear is the commonest real cause of a bad
 *    transcript;
 *  - **density**: words per second far outside natural speech means the decoder
 *    produced very little for the audio it was given, or hallucinated filler
 *    into silence.
 *
 * This is a proxy, not a model-reported probability. It is deliberately
 * pessimistic: it would rather send a good answer back for a re-prompt than let
 * a bad transcript be scored as if it were reliable (soul.md §5).
 */
export function deriveConfidence(text: string, samples: Float32Array, durationMs: number): number {
  const words = text.split(/\s+/).filter(Boolean).length;
  if (words === 0) return 0;

  const level = rms(samples);
  // Below about -40dBFS a recording is too quiet to trust.
  const levelScore = Math.min(1, level / 0.05);

  const seconds = Math.max(0.5, durationMs / 1000);
  const wordsPerSecond = words / seconds;
  // Natural speech sits around 2-3 words/second; score falls off either side.
  const densityScore =
    wordsPerSecond < 0.5 ? wordsPerSecond / 0.5 : wordsPerSecond > 6 ? Math.max(0, 1 - (wordsPerSecond - 6) / 6) : 1;

  return Math.round(Math.min(1, levelScore * 0.5 + densityScore * 0.5) * 100) / 100;
}

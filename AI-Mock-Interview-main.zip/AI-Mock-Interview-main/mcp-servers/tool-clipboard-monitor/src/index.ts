/**
 * Clipboard Monitor — INSTRUCTIONS.md §5.5, soul.md §5.
 *
 * Two hard requirements, both enforced here rather than upstream:
 *
 *  1. **`start_monitor` rejects a call without a valid `consent_token`.** Not a
 *     warning, not a default-off flag someone can flip — the tool refuses. This
 *     is what makes "no silent monitoring, ever" true even if the UI is
 *     bypassed or an agent is misconfigured.
 *  2. **Only a boolean and a timestamp are ever recorded.** The pasted content
 *     is not stored, not logged, and not accepted as a parameter — there is no
 *     field on `paste_event_detected` that could carry it, so it cannot leak by
 *     accident. Enabling full-content logging would require a separate,
 *     separately-consented feature (soul.md §5), which does not exist.
 *
 * The monitor itself is a browser-side listener: the frontend reports that a
 * paste happened, and this server decides whether that report is allowed to be
 * recorded at all.
 */

import {
  McpHandlerError,
  type ConsentVerdict,
  type McpServerHandler,
} from "@mia/shared-types";

export const SERVER_NAME = "tool-clipboard-monitor";
export const METHODS = ["start_monitor", "stop_monitor", "paste_event_detected"] as const;

export interface PasteEvent {
  sessionId: string;
  /** Always true — the event only exists because a paste happened. */
  detected: true;
  timestamp: string;
}

export interface ClipboardMonitorDeps {
  /** Verifies a consent token for this session and the clipboard_monitor scope. */
  verifyConsent(sessionId: string, token: string | undefined): ConsentVerdict;
  /** Records the event. Receives a boolean and a timestamp; there is nothing else to give it. */
  recordPaste(event: PasteEvent): Promise<void>;
}

export class ClipboardMonitorState {
  private readonly active = new Set<string>();

  start(sessionId: string): void {
    this.active.add(sessionId);
  }
  stop(sessionId: string): void {
    this.active.delete(sessionId);
  }
  isActive(sessionId: string): boolean {
    return this.active.has(sessionId);
  }
}

export function createToolClipboardMonitorServer(
  deps: ClipboardMonitorDeps,
  state = new ClipboardMonitorState(),
): McpServerHandler {
  return {
    name: SERVER_NAME,
    async call(method: string, params: unknown): Promise<unknown> {
      const p = (params ?? {}) as {
        session_id: string;
        consent_token?: string;
        timestamp?: string;
      };

      switch (method) {
        case "start_monitor": {
          const verdict = deps.verifyConsent(p.session_id, p.consent_token);
          if (!verdict.ok) {
            // The reason is named so an operator can tell a missing token from a
            // forged one, without the rejection ever being negotiable.
            throw new McpHandlerError(
              verdict.reason === "missing" ? "consent_missing" : "consent_invalid",
              `clipboard monitoring refused: consent token ${verdict.reason} for session ${p.session_id}`,
            );
          }
          state.start(p.session_id);
          return { monitoring: true, started_at: new Date().toISOString() };
        }

        case "stop_monitor": {
          state.stop(p.session_id);
          return { monitoring: false };
        }

        case "paste_event_detected": {
          // Monitoring that was never consented to cannot record anything, even
          // if the frontend reports an event.
          if (!state.isActive(p.session_id)) {
            throw new McpHandlerError(
              "consent_missing",
              `no active consented monitor for session ${p.session_id}; the event was discarded`,
            );
          }
          await deps.recordPaste({
            sessionId: p.session_id,
            detected: true,
            timestamp: p.timestamp ?? new Date().toISOString(),
          });
          return { recorded: true };
        }

        default:
          throw new McpHandlerError("unknown_method", `${SERVER_NAME} has no method ${method}`);
      }
    },
  };
}

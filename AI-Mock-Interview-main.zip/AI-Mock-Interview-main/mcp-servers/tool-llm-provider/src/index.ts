/**
 * LLM Provider Tool — INSTRUCTIONS.md §5.7.
 *
 * The thin server side of `packages/llm-client`. Routing and config only: no
 * prompt text and no interviewing judgement live here, which is what keeps the
 * Bedrock/OpenRouter/Groq choice a deployment concern rather than something
 * baked into agent code (§11.5).
 *
 * It exists as an MCP tool rather than an in-process import so that every
 * generation call gets the same treatment as every other tool call — session
 * auth, per-session rate limiting, schema validation on both sides, and one
 * auto-emitted `tool_called` span (`CLAUDE.md §5`). Sending resume, job
 * description and transcript text to a third party is exactly the kind of call
 * that should be counted and timed like any other, not made quietly in-process.
 *
 * What it never does: call another agent or another tool (§5.7). The grounding
 * check runs inside `packages/llm-client`, in-process, because it is an agent
 * validating its own generation rather than a cross-service interaction
 * (§11.3).
 */

import {
  McpHandlerError,
  type McpServerHandler,
} from "@mia/shared-types";
import { getLlmSchema } from "@mia/mcp-schemas";
import {
  PromptRegistry,
  ProviderUnavailableError,
  StructuredCallError,
  UnknownPromptVersion,
  resolveProvider,
  structuredCall,
  type ProviderName,
  type StructuredChatModel,
  type ToolDefinition,
} from "@mia/llm-client";

export const SERVER_NAME = "tool-llm-provider";
export const METHODS = ["generate_structured"] as const;

export interface LlmProviderDeps {
  /**
   * Pins the provider. Left unset, it is resolved from the environment on every
   * call — deliberately per-call rather than cached at construction, so this
   * server holds no state of its own (§11.1).
   */
  provider?: ProviderName;
  /** Substitutes the chat model. Used by tests to force a malformed or ungrounded response. */
  model?: StructuredChatModel;
  env?: NodeJS.ProcessEnv;
}

interface GenerateParams {
  session_id: string;
  tool_name: string;
  prompt_version: string;
  schema_ref: string;
  input: Record<string, unknown>;
  source_documents?: string[];
  llm_grounding_fallback?: boolean;
}

export function createToolLlmProviderServer(deps: LlmProviderDeps = {}): McpServerHandler {
  return {
    name: SERVER_NAME,
    async call(method: string, params: unknown): Promise<unknown> {
      if (method !== "generate_structured") {
        throw new McpHandlerError("unknown_method", `${SERVER_NAME} has no method ${method}`);
      }
      return generateStructured(deps, params as GenerateParams);
    },
  };
}

async function generateStructured(deps: LlmProviderDeps, params: GenerateParams) {
  const entry = getLlmSchema(params.schema_ref);
  if (!entry) {
    throw new McpHandlerError(
      "unknown_schema_ref",
      `no LLM schema registered as ${params.schema_ref} in /packages/mcp-schemas`,
    );
  }

  try {
    PromptRegistry.get(params.prompt_version);
  } catch (err) {
    if (err instanceof UnknownPromptVersion) {
      throw new McpHandlerError("unknown_prompt_version", err.message);
    }
    throw err;
  }

  const tool: ToolDefinition = {
    name: params.tool_name,
    description: params.tool_name,
    schema: entry.schema,
    promptVersion: params.prompt_version,
    schemaRef: params.schema_ref,
    requiredGroundedPaths: entry.requiredGroundedPaths,
  };

  const env = deps.env ?? process.env;
  const provider = deps.model?.provider ?? deps.provider ?? resolveProvider(env, params.tool_name).provider;

  try {
    const result = await structuredCall(tool, params.input, {
      provider,
      env,
      ...(deps.model ? { model: deps.model } : {}),
      ...(params.source_documents ? { sourceDocuments: params.source_documents } : {}),
      ...(params.llm_grounding_fallback ? { llmGroundingFallback: true } : {}),
    });

    return {
      output: result.output,
      grounded: result.grounded,
      insufficient_signal: result.insufficientSignal,
      prompt_version: result.promptVersion,
      provider: result.provider,
    };
  } catch (err) {
    // Both of these mean the same thing to the calling agent — take the
    // deterministic Stage-2 path — but they are reported apart because only one
    // of them says anything is wrong with the deployment (§5.7).
    if (err instanceof ProviderUnavailableError) {
      throw new McpHandlerError("provider_unavailable", err.message);
    }
    if (err instanceof StructuredCallError) {
      throw new McpHandlerError("schema_validation_failed", err.message);
    }
    throw err;
  }
}

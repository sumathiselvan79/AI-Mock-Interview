/**
 * Resume Parser Tool — INSTRUCTIONS.md §5.1.
 *
 * Takes a file reference, never inline bytes, so the raw resume never crosses
 * the MCP call log. Returns structured fields plus the normalised source lines
 * the Resume Service Agent quotes as evidence — it may only claim what is
 * literally in the document.
 *
 * `delete_resume` hard-deletes and then *verifies* the bytes are gone (§8):
 * "it is never just unlinked or hidden."
 *
 * (LLM addition) When a `toolClientFactory` is provided in `ResumeParserDeps`,
 * the parser tries the LLM-powered extraction path first (Ollama Cloud /
 * gemma4:31b-cloud). On any failure — provider unavailable, schema validation,
 * or timeout — it falls back silently to the existing deterministic regex
 * parser. The regex parser (`parse.ts`) is frozen and never removed.
 */

import { McpHandlerError, type FileStore, type McpServerHandler, type ToolClientFactory } from "@mia/shared-types";
import { assertReadable, extractText, ParseFailedError, toLines, UnsupportedFormatError } from "./extract.js";
import { parseResumeText, type ParsedResume } from "./parse.js";
import { RESUME_PARSE_TOOL } from "@mia/llm-client";
import type { ResumeParseGeneration } from "@mia/mcp-schemas";

export * from "./extract.js";
export * from "./parse.js";
export * from "./pdf-layout.js";

export const SERVER_NAME = "tool-resume-parser";
export const METHODS = ["parse_resume", "delete_resume"] as const;

export interface ResumeParserDeps {
  files: FileStore;
  /**
   * Optional. When supplied, the parser tries LLM-powered extraction first
   * (via `tool-llm-provider`) and falls back to the deterministic regex
   * parser on any failure. Built per-call using the session_id from params.
   */
  toolClientFactory?: ToolClientFactory;
}

export function createToolResumeParserServer(deps: ResumeParserDeps): McpServerHandler {
  return {
    name: SERVER_NAME,
    async call(method: string, params: unknown): Promise<unknown> {
      switch (method) {
        case "parse_resume":
          return parseResume(deps, params as { file_ref: string; session_id?: string });
        case "delete_resume":
          return deleteResume(deps, params as { file_ref: string });
        default:
          throw new McpHandlerError("unknown_method", `${SERVER_NAME} has no method ${method}`);
      }
    },
  };
}

async function parseResume(
  deps: ResumeParserDeps,
  params: { file_ref: string; session_id?: string },
) {
  const stored = await deps.files.get(params.file_ref);
  if (!stored) {
    throw new McpHandlerError("parse_failed", `no stored file for ref ${params.file_ref}`);
  }

  let text: string;
  try {
    text = await extractText(stored.bytes, stored.meta.filename, stored.meta.contentType);
    assertReadable(text);
  } catch (err) {
    if (err instanceof UnsupportedFormatError || err instanceof ParseFailedError) {
      throw new McpHandlerError(err.code, err.message);
    }
    throw err;
  }

  const lines = toLines(text);

  // Try LLM-powered extraction first, fall back to the frozen regex parser.
  if (deps.toolClientFactory && params.session_id) {
    const tools = deps.toolClientFactory(params.session_id, SERVER_NAME);
    const parsed = await parseWithLlmFallback(tools, lines);
    return {
      skills: parsed.skills,
      experience: parsed.experience,
      education: parsed.education,
      keywords: parsed.keywords,
      lines: parsed.lines,
    };
  }

  const parsed = parseResumeText(lines);
  return {
    skills: parsed.skills,
    experience: parsed.experience,
    education: parsed.education,
    keywords: parsed.keywords,
    lines: parsed.lines,
  };
}

/**
 * Tries LLM-powered structured extraction via the Ollama Cloud provider.
 * On ANY failure — provider unavailable, schema validation error, timeout,
 * or unexpected response shape — falls back silently to the frozen regex
 * parser. This matches the codebase's existing provider_unavailable →
 * Stage-2 fallback pattern (§5.7).
 */
async function parseWithLlmFallback(
  tools: ReturnType<ToolClientFactory>,
  lines: string[],
): Promise<ParsedResume> {
  try {
    const result = await tools.call<{
      output: ResumeParseGeneration | null;
      prompt_version: string;
    }>("tool-llm-provider", "generate_structured", {
      session_id: "resume-parse",
      tool_name: RESUME_PARSE_TOOL.name,
      prompt_version: RESUME_PARSE_TOOL.promptVersion,
      schema_ref: RESUME_PARSE_TOOL.schemaRef,
      input: { resume_lines: lines },
    });

    if (!result.output) {
      // Schema validation or grounding failed — fall back.
      return parseResumeText(lines);
    }

    const llm = result.output;
    return {
      skills: llm.skills,
      experience: llm.experience.map((e: any) => ({
        title: e.title,
        company: e.company,
        years: e.years,
      })),
      education: llm.education.map((e: any) => ({
        degree: e.degree,
        institution: e.institution,
      })),
      keywords: llm.keywords,
      lines,
    };
  } catch {
    // provider_unavailable, schema_validation_failed, timeout, or any other
    // error. The deterministic regex parser takes over silently.
    return parseResumeText(lines);
  }
}

async function deleteResume(deps: ResumeParserDeps, params: { file_ref: string }) {
  const deleted = await deps.files.delete(params.file_ref);
  // Read the backing store again rather than trusting the delete's return value.
  const verifiedAbsent = !(await deps.files.exists(params.file_ref));
  return { deleted, verified_absent: verifiedAbsent };
}

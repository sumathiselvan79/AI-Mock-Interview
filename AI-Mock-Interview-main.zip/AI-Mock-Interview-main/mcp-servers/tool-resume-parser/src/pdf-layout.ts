/**
 * Layout-aware PDF text extraction, adapted from open-resume's
 * `read-pdf.ts` / `group-text-items-into-lines.ts`
 * (https://github.com/xitanggg/open-resume, `lib/parse-resume-from-pdf`).
 *
 * `pdf-parse` (the previous extractor) already wraps pdfjs-dist and joins
 * its text items into a flat string, but it does so per-page with simple
 * newline heuristics and no recovery for a PDF whose glyphs arrived as many
 * adjacent single-character text items (common for resumes exported from
 * design tools) — that shows up downstream as topic-relevance evidence with
 * words split apart. This module reads pdfjs-dist's positioned text items
 * directly and reconstructs lines the way open-resume does: trust the
 * PDF's own `hasEOL` line breaks, then merge text items that sit closer
 * together than a typical character width back into one run.
 *
 * Runs against `pdfjs-dist/legacy/build/pdf.mjs` — the same Node-compatible,
 * worker-free build `pdf-parse` already uses in this dependency tree, so no
 * new native/browser integration surface is introduced.
 */

import { createRequire } from "node:module";
import { dirname, join } from "node:path";
import * as pdfjs from "pdfjs-dist/legacy/build/pdf.mjs";

/**
 * Without this, pdfjs-dist can't measure glyph widths for a PDF that
 * references one of the 14 standard fonts without embedding it (a common
 * case for text-based resumes exported from word processors), which
 * degrades exactly the character-width merge this module relies on to undo
 * split-up words. The font data ships inside the pdfjs-dist package itself.
 *
 * A plain filesystem path, not a `file://` URL: pdfjs-dist's Node font
 * factory (`BaseStandardFontDataFactory.fetch`) builds the final path by
 * string-concatenating `${baseUrl}${filename}` and hands that string
 * straight to `fs.promises.readFile`, which treats a `file://`-prefixed
 * string as a literal (invalid) path rather than parsing it as a URL —
 * `readFile` only special-cases an actual `URL` *object*, not a string that
 * merely looks like one. A `file://` string here fails silently into "font
 * data unavailable" on every load.
 */
const STANDARD_FONT_DATA_URL =
  join(dirname(createRequire(import.meta.url).resolve("pdfjs-dist/package.json")), "standard_fonts") + "/";

interface PositionedTextItem {
  text: string;
  x: number;
  y: number;
  width: number;
  height: number;
  fontName: string;
  hasEOL: boolean;
}

/** A resume-shaped set of stray glyphs that reliably signal split characters, not real words. */
const BULLET_POINTS = ["•", "●", "▪", "◦", "-", "*"];

async function readPdfTextItems(bytes: Uint8Array): Promise<PositionedTextItem[]> {
  const doc = await pdfjs.getDocument({ data: bytes, standardFontDataUrl: STANDARD_FONT_DATA_URL }).promise;
  const items: PositionedTextItem[] = [];

  try {
    for (let pageNumber = 1; pageNumber <= doc.numPages; pageNumber += 1) {
      const page = await doc.getPage(pageNumber);
      const textContent = await page.getTextContent();

      for (const raw of textContent.items) {
        if (!("str" in raw)) continue; // TextMarkedContent, not an actual glyph run
        items.push({
          text: raw.str,
          x: raw.transform[4],
          y: raw.transform[5],
          width: raw.width,
          height: raw.height,
          fontName: raw.fontName,
          hasEOL: raw.hasEOL,
        });
      }
      page.cleanup();
    }
  } finally {
    await doc.destroy();
  }

  // Empty-space items exist only to signal spacing/EOL; drop the ones that
  // carry neither real text nor a line break.
  return items.filter((item) => item.hasEOL || item.text.trim() !== "");
}

/**
 * Groups positioned text items into lines using the PDF's own `hasEOL`
 * breaks, then merges adjacent items separated by less than a typical
 * character width — the fix for a word that arrived as several single-glyph
 * text items with near-zero gaps between them.
 */
function groupTextItemsIntoLines(items: PositionedTextItem[]): PositionedTextItem[][] {
  const lines: PositionedTextItem[][] = [];

  let line: PositionedTextItem[] = [];
  for (const item of items) {
    if (item.hasEOL) {
      if (item.text.trim() !== "") line.push({ ...item });
      lines.push(line);
      line = [];
    } else if (item.text.trim() !== "") {
      line.push({ ...item });
    }
  }
  if (line.length > 0) lines.push(line);

  const typicalCharWidth = getTypicalCharWidth(items.filter((i) => i.text.trim() !== ""));
  if (typicalCharWidth > 0) {
    for (const currentLine of lines) {
      for (let i = currentLine.length - 1; i > 0; i -= 1) {
        const current = currentLine[i]!;
        const left = currentLine[i - 1]!;
        const leftEndX = left.x + left.width;
        const distance = current.x - leftEndX;
        if (distance <= typicalCharWidth) {
          if (needsSpaceBetween(left.text, current.text)) left.text += " ";
          left.text += current.text;
          left.width = current.x + current.width - left.x;
          currentLine.splice(i, 1);
        }
      }
    }
  }

  return lines;
}

function needsSpaceBetween(leftText: string, rightText: string): boolean {
  const leftEnd = leftText.at(-1);
  const rightStart = rightText[0];
  return (
    ([":", ",", "|", ".", ...BULLET_POINTS].includes(leftEnd ?? "") && rightStart !== " ") ||
    (leftEnd !== " " && ["|", ...BULLET_POINTS].includes(rightStart ?? ""))
  );
}

/**
 * The average glyph width among items sharing the resume's most common font
 * and line height — the yardstick "closer than this means split, not two
 * separate words" is measured against, rather than a fixed pixel constant
 * that would be wrong at another font size.
 */
function getTypicalCharWidth(items: PositionedTextItem[]): number {
  const heightCounts = new Map<number, number>();
  const fontCharCounts = new Map<string, number>();
  let commonHeight = 0;
  let heightMax = 0;
  let commonFont = "";
  let fontMax = 0;

  for (const item of items) {
    const heightCount = (heightCounts.get(item.height) ?? 0) + 1;
    heightCounts.set(item.height, heightCount);
    if (heightCount > heightMax) {
      heightMax = heightCount;
      commonHeight = item.height;
    }

    const fontCount = (fontCharCounts.get(item.fontName) ?? 0) + item.text.length;
    fontCharCounts.set(item.fontName, fontCount);
    if (fontCount > fontMax) {
      fontMax = fontCount;
      commonFont = item.fontName;
    }
  }

  const common = items.filter((item) => item.fontName === commonFont && item.height === commonHeight);
  const totalWidth = common.reduce((sum, item) => sum + item.width, 0);
  const totalChars = common.reduce((sum, item) => sum + item.text.length, 0);
  return totalChars > 0 ? totalWidth / totalChars : 0;
}

/**
 * Reads a PDF's text with layout awareness and returns clean, ordered,
 * word-intact lines — what every downstream resume rule (topic matching,
 * the regex parser, the LLM parser) expects `toLines` to have already given
 * it.
 */
export async function extractLinesFromPdf(bytes: Uint8Array): Promise<string[]> {
  const items = await readPdfTextItems(bytes);
  const lines = groupTextItemsIntoLines(items);
  return lines
    .map((line) => line.map((item) => item.text).join("").replace(/\s+/g, " ").trim())
    .filter((line) => line.length > 0);
}

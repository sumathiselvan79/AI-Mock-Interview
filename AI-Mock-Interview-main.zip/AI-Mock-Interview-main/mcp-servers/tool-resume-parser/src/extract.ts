/**
 * Text extraction per format. Kept separate from parsing so an unreadable file
 * fails as `unsupported_format` / `parse_failed` rather than silently producing
 * an empty profile — INSTRUCTIONS.md §5.1: "agent must surface these plainly,
 * never guess at content."
 */

export type SupportedFormat = "txt" | "md" | "pdf" | "docx";

export class UnsupportedFormatError extends Error {
  readonly code = "unsupported_format";
}

export class ParseFailedError extends Error {
  readonly code = "parse_failed";
}

const EXTENSION_FORMATS: Record<string, SupportedFormat> = {
  txt: "txt",
  text: "txt",
  md: "md",
  markdown: "md",
  pdf: "pdf",
  docx: "docx",
};

const CONTENT_TYPE_FORMATS: Record<string, SupportedFormat> = {
  "text/plain": "txt",
  "text/markdown": "md",
  "application/pdf": "pdf",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "docx",
};

export function detectFormat(filename: string, contentType: string): SupportedFormat {
  const extension = filename.split(".").pop()?.toLowerCase() ?? "";
  const byExtension = EXTENSION_FORMATS[extension];
  if (byExtension) return byExtension;

  const byContentType = CONTENT_TYPE_FORMATS[contentType.split(";")[0]?.trim().toLowerCase() ?? ""];
  if (byContentType) return byContentType;

  throw new UnsupportedFormatError(
    `unsupported resume format: ${filename || contentType || "unknown"}; accepted: pdf, docx, txt, md`,
  );
}

/** `.doc` is a common upload and is *not* supported — say so specifically. */
export function assertNotLegacyDoc(filename: string): void {
  if (filename.toLowerCase().endsWith(".doc")) {
    throw new UnsupportedFormatError("legacy .doc files are not supported; export as .docx or .pdf");
  }
}

export async function extractText(
  bytes: Uint8Array,
  filename: string,
  contentType: string,
): Promise<string> {
  assertNotLegacyDoc(filename);
  const format = detectFormat(filename, contentType);

  try {
    switch (format) {
      case "txt":
      case "md":
        return new TextDecoder("utf-8").decode(bytes);
      case "docx": {
        const mammoth = await import("mammoth");
        const result = await mammoth.extractRawText({ buffer: Buffer.from(bytes) });
        return result.value;
      }
      case "pdf": {
        const { extractLinesFromPdf } = await import("./pdf-layout.js");
        const lines = await extractLinesFromPdf(bytes);
        return lines.join("\n");
      }
    }
  } catch (err) {
    throw new ParseFailedError(`could not read the ${format} file: ${(err as Error).message}`);
  }
}

/**
 * A scanned resume yields a file that opens fine and contains almost no text.
 * That is a parse failure, not an empty candidate.
 */
export function assertReadable(text: string): void {
  const wordCount = text.split(/\s+/).filter(Boolean).length;
  if (wordCount < 20) {
    throw new ParseFailedError(
      `only ${wordCount} words of text could be read — if this is a scanned resume, upload a text-based PDF or a .docx`,
    );
  }
}

/** Normalised, non-empty lines. This is what every downstream rule matches against. */
export function toLines(text: string): string[] {
  return text
    .replace(/\r\n?/g, "\n")
    .replace(/[‘’]/g, "'")
    .replace(/[“”]/g, '"')
    .replace(/[–—]/g, "-")
    .split("\n")
    .map((line) => line.replace(/^[\s•·▪◦*\-–]+/, "").trim())
    .filter((line) => line.length > 0);
}

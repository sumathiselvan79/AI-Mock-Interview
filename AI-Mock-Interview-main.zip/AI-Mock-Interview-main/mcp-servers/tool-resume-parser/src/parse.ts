/**
 * Structured extraction from resume text.
 *
 * Every field this produces is a literal slice of the source, never a
 * paraphrase or an inference from a job title — the Resume Service Agent's
 * evidence requirement (INSTRUCTIONS.md §4.2, soul.md §"No fabrication") is only
 * as good as this layer's refusal to invent.
 */

export interface ParsedResume {
  skills: string[];
  experience: { title: string; company: string; years: number }[];
  education: { degree: string; institution: string }[];
  keywords: string[];
  /** Normalised source lines, so callers can quote real text as evidence. */
  lines: string[];
}

type SectionName = "skills" | "experience" | "education" | "summary" | "projects" | "other";

const SECTION_HEADINGS: { name: SectionName; pattern: RegExp }[] = [
  { name: "skills", pattern: /^(technical\s+)?(skills|technologies|tech\s+stack|competencies)\b/i },
  {
    name: "experience",
    pattern: /^(work\s+|professional\s+|employment\s+)?(experience|history|positions)\b/i,
  },
  { name: "education", pattern: /^(education|academics|qualifications)\b/i },
  { name: "summary", pattern: /^(summary|profile|objective|about)\b/i },
  { name: "projects", pattern: /^(projects|open\s+source|publications)\b/i },
];

/** A heading is a short line that matches a known section name. */
function headingFor(line: string): SectionName | null {
  if (line.length > 40) return null;
  const stripped = line.replace(/[:•\-–]+$/, "").trim();
  for (const { name, pattern } of SECTION_HEADINGS) {
    if (pattern.test(stripped)) return name;
  }
  return null;
}

export function splitSections(lines: string[]): Map<SectionName, string[]> {
  const sections = new Map<SectionName, string[]>();
  let current: SectionName = "other";
  for (const line of lines) {
    const heading = headingFor(line);
    if (heading) {
      current = heading;
      if (!sections.has(current)) sections.set(current, []);
      continue;
    }
    const bucket = sections.get(current) ?? [];
    bucket.push(line);
    sections.set(current, bucket);
  }
  return sections;
}

const SKILL_SPLIT = /[,;|•·]|\s{3,}/;

function looksLikeSkillList(line: string): boolean {
  const parts = line.split(SKILL_SPLIT).map((p) => p.trim()).filter(Boolean);
  if (parts.length < 2) return false;
  // Skill lists are short items; prose split on commas is not.
  return parts.every((p) => p.split(/\s+/).length <= 4) && parts.length <= 30;
}

export function extractSkills(sections: Map<SectionName, string[]>): string[] {
  const skills = new Set<string>();
  for (const line of sections.get("skills") ?? []) {
    const withoutLabel = line.replace(/^[A-Za-z /&+]{0,30}:\s*/, "");
    for (const part of withoutLabel.split(SKILL_SPLIT)) {
      const skill = part.trim().replace(/\.$/, "");
      // Keep it a skill, not a sentence.
      if (skill.length >= 2 && skill.length <= 40 && skill.split(/\s+/).length <= 4) {
        skills.add(skill);
      }
    }
  }
  return [...skills];
}

const YEAR = "(19|20)\\d{2}";
const DATE_RANGE = new RegExp(
  `(${YEAR})\\s*(?:-|to|–|until)\\s*(${YEAR}|present|current|now)`,
  "i",
);

function yearsFromRange(line: string): number | null {
  const match = DATE_RANGE.exec(line);
  if (!match) return null;
  const start = Number.parseInt(match[1] as string, 10);
  const endRaw = (match[3] as string).toLowerCase();
  const end = /^\d{4}$/.test(endRaw) ? Number.parseInt(endRaw, 10) : new Date().getFullYear();
  const years = end - start;
  return years >= 0 && years < 60 ? years : null;
}

const TITLE_COMPANY = [
  // "Senior Engineer at Acme" / "Senior Engineer, Acme"
  /^(?<title>[A-Z][\w+/&.\- ]{2,50}?)\s*(?:,|\bat\b|@|\||-)\s*(?<company>[A-Z][\w+/&.,'\- ]{1,60}?)\s*(?:[|,(–-]|$)/,
];

export function extractExperience(
  sections: Map<SectionName, string[]>,
): { title: string; company: string; years: number }[] {
  const out: { title: string; company: string; years: number }[] = [];
  const seen = new Set<string>();
  const lines = sections.get("experience") ?? [];

  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i] as string;
    for (const pattern of TITLE_COMPANY) {
      const match = pattern.exec(line);
      const title = match?.groups?.title?.trim();
      const company = match?.groups?.company?.trim().replace(/[,\-–|]+$/, "");
      if (!title || !company) continue;
      // Dates often sit on the same line or the one after it.
      const years = yearsFromRange(line) ?? yearsFromRange(lines[i + 1] ?? "") ?? 0;
      const key = `${title.toLowerCase()}@${company.toLowerCase()}`;
      if (!seen.has(key)) {
        seen.add(key);
        out.push({ title, company, years });
      }
      break;
    }
  }
  return out;
}

const DEGREE = /\b(b\.?sc|b\.?s|b\.?a|b\.?tech|m\.?sc|m\.?s|m\.?tech|mba|ph\.?d|bachelor|master|doctorate|diploma)\b/i;

export function extractEducation(
  sections: Map<SectionName, string[]>,
): { degree: string; institution: string }[] {
  const out: { degree: string; institution: string }[] = [];
  const lines = sections.get("education") ?? [];

  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i] as string;
    if (!DEGREE.test(line)) continue;

    const parts = line.split(/\s*(?:,|\bat\b|\bfrom\b|\||-)\s*/i).map((p) => p.trim()).filter(Boolean);
    const degree = parts.find((p) => DEGREE.test(p)) ?? line;
    const institution =
      parts.find((p) => p !== degree && /[A-Za-z]{4,}/.test(p) && !/^\(?\d/.test(p)) ??
      (lines[i + 1] && !DEGREE.test(lines[i + 1] as string) ? (lines[i + 1] as string) : "");

    out.push({
      degree: degree.replace(/\s*\(?\d{4}.*$/, "").trim(),
      institution: institution.replace(/\s*\(?\d{4}.*$/, "").trim(),
    });
  }
  return out;
}

const STOPWORDS = new Set([
  "the", "and", "for", "with", "from", "that", "this", "were", "was", "are", "our", "their", "its",
  "into", "over", "using", "used", "use", "across", "within", "while", "after", "before", "than",
  "then", "them", "they", "have", "has", "had", "not", "but", "all", "any", "can", "will", "would",
  "should", "could", "also", "more", "most", "other", "such", "which", "who", "whom", "how", "what",
  "when", "where", "why", "his", "her", "him", "she", "hers", "you", "your", "yours", "about",
  "team", "teams", "work", "worked", "working", "years", "year", "new", "including", "well",
]);

/** Frequency-ranked content words. Used for keyword matching, never shown as a claim. */
export function extractKeywords(lines: string[], limit = 40): string[] {
  const counts = new Map<string, number>();
  for (const line of lines) {
    for (const raw of line.toLowerCase().split(/[^a-z0-9+#./-]+/)) {
      const token = raw.replace(/^[.\-/]+|[.\-/]+$/g, "");
      if (token.length < 3 || token.length > 30) continue;
      if (STOPWORDS.has(token)) continue;
      if (/^\d+$/.test(token)) continue;
      counts.set(token, (counts.get(token) ?? 0) + 1);
    }
  }
  return [...counts.entries()]
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
    .slice(0, limit)
    .map(([token]) => token);
}

export function parseResumeText(lines: string[]): ParsedResume {
  const sections = splitSections(lines);

  // A resume with no recognised headings still has to parse: fall back to
  // treating the whole document as the experience section rather than
  // returning nothing.
  if (!sections.has("experience") && !sections.has("skills")) {
    sections.set("experience", lines);
    sections.set("skills", lines.filter(looksLikeSkillList));
  }

  return {
    skills: extractSkills(sections),
    experience: extractExperience(sections),
    education: extractEducation(sections),
    keywords: extractKeywords(lines),
    lines,
  };
}

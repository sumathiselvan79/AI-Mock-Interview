/**
 * ToolTelemetry — INSTRUCTIONS.md §5.4.
 *
 * Fire-and-forget event sink. Payloads carry IDs and timings only. Calls no tools directly.
 *
 * STAGE 1 (TRACKING.md). Stage 1 ships the server registration only, so the
 * harness's routing table, the schema registry and the gateway's telemetry path
 * are complete and testable end to end; every method answers `not_implemented`
 * until Stage 1 fills it in.
 */

import { McpHandlerError, type McpServerHandler } from "@mia/shared-types";

export const SERVER_NAME = "tool-telemetry";
export const IMPLEMENTED_IN_STAGE = 1;

export const METHODS = ["emit_event"] as const;
export type Method = (typeof METHODS)[number];

export function createToolTelemetryServer(): McpServerHandler {
  return {
    name: SERVER_NAME,
    async call(method: string): Promise<never> {
      if (!(METHODS as readonly string[]).includes(method)) {
        throw new McpHandlerError("unknown_method", `${SERVER_NAME} has no method ${method}`);
      }
      throw new McpHandlerError(
        "not_implemented",
        `${SERVER_NAME}.${method} is scheduled for Stage ${IMPLEMENTED_IN_STAGE}`,
      );
    },
  };
}

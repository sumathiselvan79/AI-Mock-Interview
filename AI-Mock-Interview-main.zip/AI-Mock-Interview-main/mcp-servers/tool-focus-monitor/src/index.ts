/**
 * Focus Monitor — fullscreen-exit tracking during the active interview
 * (INSTRUCTIONS.md §5.5-adjacent, soul.md §5 "Consent-first monitoring").
 *
 * Same two hard requirements as the Clipboard Monitor, and for the same
 * reasons:
 *
 *  1. **`start_monitor` rejects a call without a valid `consent_token`.** Not a
 *     warning, not a default-off flag someone can flip — the tool refuses. This
 *     is what makes "no silent monitoring, ever" true even if the UI is
 *     bypassed or the harness is misconfigured.
 *  2. **Only a timestamp is ever recorded.** What the candidate did in another
 *     window or tab is never asked for and has no field to carry it — the
 *     event exists solely because fullscreen was exited, nothing else.
 *
 * The monitor itself is a browser-side listener (`fullscreenchange`): the
 * frontend reports that fullscreen was exited, and this server decides
 * whether that report is allowed to be recorded at all, then hands back the
 * running count so the caller can decide whether the session has now had too
 * many.
 */

import {
  McpHandlerError,
  type ConsentVerdict,
  type McpServerHandler,
} from "@mia/shared-types";

export const SERVER_NAME = "tool-focus-monitor";
export const METHODS = ["start_monitor", "stop_monitor", "focus_event_detected"] as const;

export interface FocusLossEvent {
  sessionId: string;
  /** Always true — the event only exists because an exit happened. */
  detected: true;
  timestamp: string;
}

export interface FocusMonitorDeps {
  /** Verifies a consent token for this session and the focus_monitoring scope. */
  verifyConsent(sessionId: string, token: string | undefined): ConsentVerdict;
  /** Records the event and returns the session's running exit count. */
  recordFocusLoss(event: FocusLossEvent): Promise<{ exitCount: number }>;
}

export class FocusMonitorState {
  private readonly active = new Set<string>();

  start(sessionId: string): void {
    this.active.add(sessionId);
  }
  stop(sessionId: string): void {
    this.active.delete(sessionId);
  }
  isActive(sessionId: string): boolean {
    return this.active.has(sessionId);
  }
}

export function createToolFocusMonitorServer(
  deps: FocusMonitorDeps,
  state = new FocusMonitorState(),
): McpServerHandler {
  return {
    name: SERVER_NAME,
    async call(method: string, params: unknown): Promise<unknown> {
      const p = (params ?? {}) as {
        session_id: string;
        consent_token?: string;
        timestamp?: string;
      };

      switch (method) {
        case "start_monitor": {
          const verdict = deps.verifyConsent(p.session_id, p.consent_token);
          if (!verdict.ok) {
            throw new McpHandlerError(
              verdict.reason === "missing" ? "consent_missing" : "consent_invalid",
              `focus monitoring refused: consent token ${verdict.reason} for session ${p.session_id}`,
            );
          }
          state.start(p.session_id);
          return { monitoring: true, started_at: new Date().toISOString() };
        }

        case "stop_monitor": {
          state.stop(p.session_id);
          return { monitoring: false };
        }

        case "focus_event_detected": {
          // Monitoring that was never consented to cannot record anything, even
          // if the frontend reports an event.
          if (!state.isActive(p.session_id)) {
            throw new McpHandlerError(
              "consent_missing",
              `no active consented monitor for session ${p.session_id}; the event was discarded`,
            );
          }
          const { exitCount } = await deps.recordFocusLoss({
            sessionId: p.session_id,
            detected: true,
            timestamp: p.timestamp ?? new Date().toISOString(),
          });
          return { recorded: true, exit_count: exitCount };
        }

        default:
          throw new McpHandlerError("unknown_method", `${SERVER_NAME} has no method ${method}`);
      }
    },
  };
}

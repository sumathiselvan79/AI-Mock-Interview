/**
 * Time Tracking Tool — INSTRUCTIONS.md §5.3.
 *
 * Redis-backed segment timers. No agent runs its own timers (CLAUDE.md §10);
 * they all come here, so a session's pacing is one clock rather than seven.
 *
 * `get_elapsed` reports `nudge` before `expired` so the harness always has a
 * heads-up state to act on — a segment is never silently cut off (§4.6).
 */

import { McpHandlerError, type McpServerHandler } from "@mia/shared-types";

export const SERVER_NAME = "tool-time-tracking";
export const METHODS = ["start_timer", "pause_timer", "resume_timer", "get_elapsed"] as const;

export type SegmentState = "on_track" | "nudge" | "expired";

/** Warn once a segment is inside the last 20% of its budget, or its last 30s. */
export const NUDGE_FRACTION = 0.2;
export const NUDGE_FLOOR_MS = 30_000;

export interface TimerState {
  segmentId: string;
  budgetMs: number;
  startedAt: number;
  pausedAt: number | null;
  pausedMs: number;
}

export interface TimerStore {
  saveTimer(state: TimerState): Promise<void>;
  loadTimer(segmentId: string): Promise<TimerState | null>;
  clearTimer(segmentId: string): Promise<void>;
}

export interface TimeTrackingDeps {
  timers: TimerStore;
  /** Injectable so tests can advance time without sleeping. */
  now?: () => number;
}

export function createToolTimeTrackingServer(deps: TimeTrackingDeps): McpServerHandler {
  const now = deps.now ?? (() => Date.now());

  const load = async (segmentId: string): Promise<TimerState> => {
    const timer = await deps.timers.loadTimer(segmentId);
    if (!timer) throw new McpHandlerError("unknown_segment", `no timer for segment ${segmentId}`);
    return timer;
  };

  return {
    name: SERVER_NAME,
    async call(method: string, params: unknown): Promise<unknown> {
      const p = (params ?? {}) as { segment_id: string; budget_ms?: number };

      switch (method) {
        case "start_timer": {
          const state: TimerState = {
            segmentId: p.segment_id,
            budgetMs: p.budget_ms as number,
            startedAt: now(),
            pausedAt: null,
            pausedMs: 0,
          };
          await deps.timers.saveTimer(state);
          return { segment_id: state.segmentId, started_at: new Date(state.startedAt).toISOString() };
        }

        case "pause_timer": {
          const timer = await load(p.segment_id);
          if (timer.pausedAt === null) {
            timer.pausedAt = now();
            await deps.timers.saveTimer(timer);
          }
          return { paused: true, elapsed_ms: elapsedMs(timer, now()) };
        }

        case "resume_timer": {
          const timer = await load(p.segment_id);
          if (timer.pausedAt !== null) {
            timer.pausedMs += now() - timer.pausedAt;
            timer.pausedAt = null;
            await deps.timers.saveTimer(timer);
          }
          return { resumed: true, elapsed_ms: elapsedMs(timer, now()) };
        }

        case "get_elapsed": {
          const timer = await load(p.segment_id);
          const elapsed = elapsedMs(timer, now());
          const remaining = timer.budgetMs - elapsed;
          return {
            elapsed_ms: elapsed,
            remaining_ms: remaining,
            segment_state: segmentStateFor(remaining, timer.budgetMs),
          };
        }

        default:
          throw new McpHandlerError("unknown_method", `${SERVER_NAME} has no method ${method}`);
      }
    },
  };
}

/** Paused time never counts against the candidate's budget. */
export function elapsedMs(timer: TimerState, now: number): number {
  const frozen = timer.pausedAt === null ? 0 : now - timer.pausedAt;
  return Math.max(0, now - timer.startedAt - timer.pausedMs - frozen);
}

export function segmentStateFor(remainingMs: number, budgetMs: number): SegmentState {
  if (remainingMs <= 0) return "expired";
  const threshold = Math.max(budgetMs * NUDGE_FRACTION, Math.min(NUDGE_FLOOR_MS, budgetMs));
  return remainingMs <= threshold ? "nudge" : "on_track";
}

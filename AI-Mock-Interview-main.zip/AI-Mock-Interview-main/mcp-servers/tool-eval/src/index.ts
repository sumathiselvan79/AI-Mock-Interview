/**
 * Eval Tool — INSTRUCTIONS.md §5.2.
 *
 * Scores an answer against a versioned rubric and persists an `Evaluation`
 * record, so scores survive a dropped session and are what the Report Agent and
 * Admin dashboard read from later.
 *
 * Two refusals are deliberate, and both come from soul.md:
 *  - too little to go on → `insufficient_transcript`, not a low score. A thin
 *    answer is not the same as a bad one, and guessing would be fabrication.
 *  - a low-confidence speech-to-text transcript is never scored silently
 *    (soul.md §5); the caller must resolve it first.
 *
 * The scorer is deterministic and evidence-first: every point comes from a span
 * of the transcript it can point at. Swapping in a model-backed scorer means
 * replacing `scoreAgainstRubric` — the contract, the persistence and the
 * refusals stay where they are.
 */

import { randomUUID } from "node:crypto";
import {
  McpHandlerError,
  type EvaluationStore,
  type McpServerHandler,
} from "@mia/shared-types";
import { getRubric, type Rubric } from "./rubrics.js";

export * from "./rubrics.js";

export const SERVER_NAME = "tool-eval";
export const METHODS = ["evaluate_answer", "verify_concepts"] as const;

/**
 * (Stage 6, §4.4) A concept counts as demonstrated when at least half its
 * label's distinctive terms show up in the transcript, or the label appears
 * near-verbatim. Concept labels are short phrases (2-6 words), unlike a full
 * reference answer, so the bar is deliberately lower than `termCoverage`'s use
 * in `scoreAgainstRubric` — one matched word out of two is real signal here in
 * a way it wouldn't be against a whole paragraph.
 */
export const CONCEPT_VERIFIED_THRESHOLD = 0.5;

/** Below this, a transcript is treated as unreliable and must not be scored. */
export const MIN_SCOREABLE_CONFIDENCE = 0.6;

export interface EvalDeps {
  evaluations: EvaluationStore;
}

interface EvaluateParams {
  rubric_id: string;
  answer_id?: string;
  question: string;
  answer_transcript: string;
  transcript_confidence?: number;
  /** (Stage 5, §4.4) The Question Agent's model answer, for comparison only. */
  reference_answer?: string;
  /** (Stage 5, §6) The prompt version that produced that reference answer, stamped onto the Evaluation. */
  prompt_version?: string;
  extra?: { test_results?: { case: string; passed: boolean }[] };
}

export interface ScoreResult {
  score: number;
  rationale: string;
  evidenceSpans: { start: number; end: number }[];
  matchedSignals: string[];
  missingSignals: string[];
}

interface VerifyConceptsParams {
  answer_transcript: string;
  /** The target tier's concept ids paired with their labels — see `extractionMatrix` (INSTRUCTIONS.md §4.3). */
  concepts: { id: string; label: string }[];
}

export interface ConceptVerificationResult {
  verifiedConceptIds: string[];
  unverifiedConceptIds: string[];
}

export function createToolEvalServer(deps: EvalDeps): McpServerHandler {
  return {
    name: SERVER_NAME,
    async call(method: string, params: unknown): Promise<unknown> {
      switch (method) {
        case "evaluate_answer":
          return evaluateAnswer(deps, params as EvaluateParams);
        case "verify_concepts": {
          const p = params as VerifyConceptsParams;
          const result = verifyConcepts(p.answer_transcript ?? "", p.concepts ?? []);
          return {
            verified_concept_ids: result.verifiedConceptIds,
            unverified_concept_ids: result.unverifiedConceptIds,
          };
        }
        default:
          throw new McpHandlerError("unknown_method", `${SERVER_NAME} has no method ${method}`);
      }
    },
  };
}

/**
 * Deterministic, evidence-first like every other judgement in this tool: a
 * concept is "verified" only because specific words from its label actually
 * appear in the transcript, never because a model said so with no pointer
 * back to the text (soul.md §"No fabrication").
 */
export function verifyConcepts(
  transcript: string,
  concepts: { id: string; label: string }[],
): ConceptVerificationResult {
  const verifiedConceptIds: string[] = [];
  const unverifiedConceptIds: string[] = [];

  for (const concept of concepts) {
    const coverage = termCoverage(transcript, concept.label);
    const nearVerbatim = transcript.toLowerCase().includes(concept.label.toLowerCase());
    if (coverage >= CONCEPT_VERIFIED_THRESHOLD || nearVerbatim) {
      verifiedConceptIds.push(concept.id);
    } else {
      unverifiedConceptIds.push(concept.id);
    }
  }

  return { verifiedConceptIds, unverifiedConceptIds };
}

async function evaluateAnswer(deps: EvalDeps, params: EvaluateParams) {
  const rubric = getRubric(params.rubric_id);
  if (!rubric) {
    throw new McpHandlerError("unknown_rubric_id", `no rubric ${params.rubric_id} in this tool`);
  }

  if (
    params.transcript_confidence !== undefined &&
    params.transcript_confidence < MIN_SCOREABLE_CONFIDENCE
  ) {
    throw new McpHandlerError(
      "insufficient_transcript",
      `transcript confidence ${params.transcript_confidence} is below ${MIN_SCOREABLE_CONFIDENCE}; re-prompt or take typed text rather than scoring a guess`,
    );
  }

  const transcript = params.answer_transcript ?? "";
  const wordCount = transcript.split(/\s+/).filter(Boolean).length;
  if (wordCount < rubric.minWords) {
    throw new McpHandlerError(
      "insufficient_transcript",
      `${wordCount} words is too little to score against ${rubric.id} (needs ${rubric.minWords})`,
    );
  }

  const result = scoreAgainstRubric(
    rubric,
    transcript,
    params.extra?.test_results,
    params.reference_answer,
  );

  if (params.answer_id) {
    await deps.evaluations.append({
      id: randomUUID(),
      answerId: params.answer_id,
      rubricId: rubric.id,
      score: result.score,
      rationale: result.rationale,
      evidenceSpans: result.evidenceSpans,
      // Only stamped when a generated reference answer actually informed the
      // score — a rubric-only score is not an LLM-backed one (§6).
      ...(params.reference_answer && params.prompt_version
        ? { promptVersion: params.prompt_version }
        : {}),
      createdAt: new Date().toISOString(),
    });
  }

  return {
    score: result.score,
    rationale: result.rationale,
    evidence_spans: result.evidenceSpans,
  };
}

/**
 * Scores 0-5. Each rubric signal contributes its weight only when it matches
 * the transcript, and each match contributes the span that produced it — so a
 * score can always be traced back to specific words the candidate said.
 */
export function scoreAgainstRubric(
  rubric: Rubric,
  transcript: string,
  testResults?: { case: string; passed: boolean }[],
  referenceAnswer?: string,
): ScoreResult {
  const spans: { start: number; end: number }[] = [];
  const matched: string[] = [];
  const missing: string[] = [];
  let earned = 0;
  const total = rubric.signals.reduce((sum, s) => sum + s.weight, 0);

  for (const signal of rubric.signals) {
    let hit = false;
    for (const pattern of signal.patterns) {
      // Patterns are module-level and carry /g, so reset before reuse.
      const scoped = new RegExp(pattern.source, pattern.flags.includes("g") ? pattern.flags : `${pattern.flags}g`);
      for (const match of transcript.matchAll(scoped)) {
        if (match.index === undefined) continue;
        hit = true;
        spans.push({ start: match.index, end: match.index + match[0].length });
        // One span per signal is enough to evidence it; more just adds noise.
        break;
      }
      if (hit) break;
    }
    if (hit) {
      earned += signal.weight;
      matched.push(signal.label);
    } else {
      missing.push(signal.label);
    }
  }

  let ratio = total === 0 ? 0 : earned / total;

  // For coding, executed tests are harder evidence than anything in the
  // talk-through, so they move the score directly.
  if (testResults && testResults.length > 0) {
    const passRate = testResults.filter((t) => t.passed).length / testResults.length;
    ratio = ratio * 0.4 + passRate * 0.6;
  }

  // (Stage 5, §4.4) The Question Agent's reference answer, when there is one,
  // can only ever RAISE a score — never lower it.
  //
  // That asymmetry is the whole point. soul.md §"A reference answer is a
  // comparison aid" requires that "a candidate who reaches the same competence
  // by a different route must score the same as one who happens to match the
  // reference answer's wording". A symmetric blend would quietly punish the
  // different route for not matching wording, so the reference answer is a
  // floor-raiser and nothing else. When it is absent — every Stage 1-4 call —
  // the arithmetic below is untouched.
  let referenceCoverage: number | null = null;
  if (referenceAnswer) {
    referenceCoverage = termCoverage(transcript, referenceAnswer);
    ratio = Math.max(ratio, ratio * 0.8 + referenceCoverage * 0.2);
  }

  const score = Math.round(ratio * 5 * 10) / 10;

  const rationaleParts: string[] = [];
  if (matched.length > 0) rationaleParts.push(`Present: ${matched.join("; ")}.`);
  if (missing.length > 0) rationaleParts.push(`Not evidenced: ${missing.join("; ")}.`);
  if (testResults && testResults.length > 0) {
    rationaleParts.push(
      `${testResults.filter((t) => t.passed).length} of ${testResults.length} test cases passed.`,
    );
  }
  if (referenceCoverage !== null) {
    rationaleParts.push(
      `Covers ${Math.round(referenceCoverage * 100)}% of the points a reference answer would make.`,
    );
  }

  return {
    score,
    rationale: rationaleParts.join(" "),
    // Never empty: the schema requires at least one span, and a score with no
    // evidence must not exist. When nothing matched, the span is the opening of
    // the answer the judgement was made on.
    evidenceSpans: spans.length > 0 ? dedupeSpans(spans) : [{ start: 0, end: Math.min(120, transcript.length) }],
    matchedSignals: matched,
    missingSignals: missing,
  };
}

/**
 * Fraction of the reference answer's distinctive terms that the transcript also
 * uses. Stopwords are dropped so the measure tracks substance rather than
 * grammar, and it is symmetric to phrasing: a candidate who says "idempotent"
 * where the reference says "idempotency" is a miss here, which is precisely why
 * this can only raise a score and never lower one.
 */
export function termCoverage(transcript: string, referenceAnswer: string): number {
  const terms = (text: string): Set<string> =>
    new Set(
      text
        .toLowerCase()
        .split(/[^a-z0-9+#.]+/)
        .filter((word) => word.length > 3 && !STOPWORDS.has(word)),
    );

  const wanted = terms(referenceAnswer);
  if (wanted.size === 0) return 0;

  const said = terms(transcript);
  let hits = 0;
  for (const term of wanted) if (said.has(term)) hits += 1;
  return hits / wanted.size;
}

const STOPWORDS = new Set([
  "about", "after", "also", "answer", "because", "been", "before", "being", "both", "candidate",
  "could", "different", "does", "each", "even", "every", "from", "have", "here", "into", "just",
  "like", "made", "make", "many", "more", "most", "much", "must", "name", "names", "only", "over",
  "reference", "same", "should", "some", "strong", "such", "than", "that", "their", "them", "then",
  "there", "these", "they", "thing", "this", "those", "through", "under", "very", "well", "were",
  "what", "when", "where", "which", "while", "with", "would", "your",
]);

function dedupeSpans(spans: { start: number; end: number }[]): { start: number; end: number }[] {
  const sorted = [...spans].sort((a, b) => a.start - b.start);
  const out: { start: number; end: number }[] = [];
  for (const span of sorted) {
    const last = out[out.length - 1];
    if (last && span.start <= last.end) {
      last.end = Math.max(last.end, span.end);
    } else {
      out.push({ ...span });
    }
  }
  return out;
}

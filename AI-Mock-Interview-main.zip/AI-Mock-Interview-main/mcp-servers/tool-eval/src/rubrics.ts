/**
 * Versioned scoring rubrics.
 *
 * These live in the Eval Tool and nowhere else, so the Question Agent, Coding
 * Agent and Report Agent all score the same way (CLAUDE.md §8). A rubric is a
 * set of *signals*; a signal only counts when it can point at the span of
 * transcript that produced it, which is what makes `evidence_spans` real rather
 * than decorative (soul.md §"No fabrication").
 *
 * Fairness constraints baked into the signal set (soul.md §3, §5):
 *  - no signal rewards vocabulary, fluency, accent, or phrasing;
 *  - every signal is about the substance of what was described — a concrete
 *    situation, actions the candidate took, an outcome, reasoning about
 *    tradeoffs;
 *  - communication style is never blended into a technical or behavioural score.
 */

export interface RubricSignal {
  id: string;
  /** What a strong answer shows. Surfaced in the rationale. */
  label: string;
  /** Matched against the transcript; the match offsets become evidence spans. */
  patterns: RegExp[];
  weight: number;
}

export interface Rubric {
  id: string;
  version: number;
  appliesTo: "behavioral" | "technical" | "coding";
  /** Below this many words there is not enough to score (§5.2). */
  minWords: number;
  signals: RubricSignal[];
}

/**
 * "What did *you* actually do": first person followed by a past-tense verb.
 * `\w+ed` carries the regular cases so the signal is not hostage to a
 * hand-written verb list — an answer saying "I raised the pool" is describing
 * an action just as much as one saying "I implemented a pool".
 */
const ACTION_VERBS =
  /\b(?:i|we)\s+(?:\w+ed|built|wrote|led|ran|chose|took|made|set|got|found|split|rewrote|sent|brought|kept|drove|shipped|spent|went|began|broke|caught|dealt|held|left|lost|met|paid|put|read|sold|taught|told|thought|understood|won|dug|rebuilt|undid)\b/gi;

const OUTCOME =
  /\b(as a result|which (?:meant|led|resulted)|the (?:result|outcome|impact) was|ended up|after (?:that|which)|since then|we went from|dropped (?:from|to)|went from|reduced|increased|improved|cut|saved|eliminated)\b/gi;

const METRIC = /\b\d+(?:\.\d+)?\s?(?:%|percent|x|ms|s\b|seconds|minutes|hours|days|weeks|months|k\b|m\b|users|requests|rps|qps|gb|tb|dollars|\$)/gi;

const SITUATION =
  /\b(at (?:my|the) (?:last|previous|current)|when i (?:was|joined)|the (?:context|situation|problem) was|we had a|our team (?:was|had)|on a project|last (?:year|quarter|month)|in \d{4})\b/gi;

const TRADEOFF =
  /\b(tradeoff|trade-off|the (?:downside|drawback|cost) (?:was|is)|on the other hand|instead of|rather than|we (?:chose|picked|decided) .{0,40}\bbecause\b|the alternative|we considered|we ruled out|at the expense of)\b/gi;

const REASONING =
  /\b(because|the reason|so that|which meant|in order to|this let us|the risk was|we assumed|it depends on|first .{0,60}then)\b/gi;

const SPECIFIC_TECH =
  /\b(postgres|mysql|redis|kafka|rabbitmq|kubernetes|docker|terraform|aws|gcp|azure|react|typescript|python|java|go\b|rust|node|grpc|graphql|s3|dynamodb|spark|airflow|prometheus|grafana|datadog|nginx|elasticsearch)\b/gi;

const SELF_CORRECTION =
  /\b(what i'd do differently|in hindsight|looking back|i got that wrong|i was wrong|the mistake (?:i|we) made|i should have|next time i)\b/gi;

export const RUBRICS: readonly Rubric[] = [
  {
    id: "behavioral_v1",
    version: 1,
    appliesTo: "behavioral",
    minWords: 25,
    signals: [
      { id: "situation", label: "sets out a specific situation rather than a general habit", patterns: [SITUATION], weight: 1 },
      { id: "actions", label: "describes what they personally did", patterns: [ACTION_VERBS], weight: 1.5 },
      { id: "outcome", label: "states how it turned out", patterns: [OUTCOME], weight: 1 },
      { id: "specifics", label: "grounds the answer in concrete numbers or named systems", patterns: [METRIC, SPECIFIC_TECH], weight: 0.75 },
      { id: "reflection", label: "reflects on the decision or what they'd change", patterns: [SELF_CORRECTION, TRADEOFF], weight: 0.75 },
    ],
  },
  {
    id: "technical_v1",
    version: 1,
    appliesTo: "technical",
    minWords: 25,
    signals: [
      { id: "reasoning", label: "explains why, not just what", patterns: [REASONING], weight: 1.5 },
      { id: "tradeoffs", label: "weighs at least one alternative", patterns: [TRADEOFF], weight: 1.5 },
      { id: "specifics", label: "names concrete systems, numbers, or mechanisms", patterns: [SPECIFIC_TECH, METRIC], weight: 1 },
      { id: "experience", label: "draws on something they actually did", patterns: [ACTION_VERBS, SITUATION], weight: 1 },
    ],
  },
  {
    id: "coding_round_v1",
    version: 1,
    appliesTo: "coding",
    minWords: 10,
    signals: [
      { id: "reasoning", label: "explains the approach before or while coding", patterns: [REASONING], weight: 1.5 },
      { id: "tradeoffs", label: "considers complexity or an alternative approach", patterns: [TRADEOFF, /\bO\(.{1,10}\)/g], weight: 1.5 },
      { id: "edge_cases", label: "raises edge cases or failure modes", patterns: [/\b(edge case|empty|null|overflow|off by one|boundary|invalid input|what if)\b/gi], weight: 1 },
    ],
  },
];

export function getRubric(rubricId: string): Rubric | undefined {
  return RUBRICS.find((r) => r.id === rubricId);
}

export function rubricIds(): string[] {
  return RUBRICS.map((r) => r.id);
}

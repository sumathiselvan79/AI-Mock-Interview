/**
 * `npm run check:llm` — does this deployment's LLM configuration actually work?
 *
 * A deployment can boot, pass every test and serve a whole interview with a
 * dead API key: `resolveProvider` degrades to the fixture and the agents take
 * their deterministic Stage-2 path, exactly as designed (INSTRUCTIONS.md §5.7).
 * That is the right behaviour at runtime and the wrong thing to discover in
 * production, so this script asks the question no unit test can — is the
 * configured provider REACHABLE, and does a real generation come back schema-
 * valid and grounded?
 *
 * It exercises the same seam the agents use (`structuredCall`, the registered
 * prompt versions, the real schemas), never a provider SDK directly, so a pass
 * here means the agents' path works and not merely that a key is well-formed.
 *
 * Exit code is 0 only when the resolved provider generated, schema-validated
 * and grounded all three calls — safe to gate a deploy on.
 */

import { join } from "node:path";
import {
  FOLLOW_UP_TOOL,
  JD_FIT_TOOL,
  JD_REQUIREMENTS_TOOL,
  QUESTION_TOOL,
  RESUME_PARSE_TOOL,
  ProviderUnavailableError,
  StructuredCallError,
  resolveProvider,
  structuredCall,
  type ProviderName,
  type ToolDefinition,
} from "@mia/llm-client";

try {
  process.loadEnvFile(join(process.cwd(), ".env"));
} catch {
  // Already-exported env vars are the deployed case; a missing .env is fine.
}

/** Enough resume/JD to ground on, small enough to keep the check cheap. */
const RESUME = [
  "Built a Node.js order-service handling 4k requests/second at peak.",
  "Added partial indexes on the orders table that cut a nightly reconciliation report from 6 minutes to 11 seconds.",
  "Led the migration from a single Postgres instance to a read-replica topology.",
].join("\n");

const JD = [
  "Senior Backend Engineer.",
  "You will own high-throughput services and their database layer.",
  "Requires strong Postgres, API design, and distributed systems experience.",
].join("\n");

const ANSWER = "I looked at the slow query log, saw the reconciliation query was doing a seq scan, and added an index.";

const CHECKS: { label: string; tool: ToolDefinition<never>; input: unknown; sourceDocuments: string[] }[] = [
  {
    label: "question generation",
    tool: QUESTION_TOOL as never,
    input: {
      role: "Senior Backend Engineer",
      topic_plan: [
        { topic: "databases", max_questions: 2, source: "resume" },
        { topic: "apis and services", max_questions: 2, source: "jd_gap" },
      ],
      candidate_profile_lines: RESUME.split("\n"),
      baseline: { topic: "databases", type: "technical", difficulty: 3, tier: 2, text: "How do you diagnose a slow query?" },
    },
    sourceDocuments: [RESUME, "databases (max 2, from resume)", "apis and services (max 2, from jd_gap)"],
  },
  {
    label: "resume/JD fit",
    tool: JD_FIT_TOOL as never,
    input: {
      role: "Senior Backend Engineer",
      job_description: JD,
      resume_lines: RESUME.split("\n"),
      matched_requirements: ["Postgres", "high-throughput services"],
      gaps: ["distributed systems"],
      candidate_topics: ["databases", "apis and services", "system design"],
    },
    sourceDocuments: [RESUME, JD],
  },
  {
    label: "follow-up probing",
    tool: FOLLOW_UP_TOOL as never,
    input: {
      question: "Walk me through how you found which query needed the partial index.",
      answer_transcript: ANSWER,
      baseline: {
        should_follow_up: true,
        follow_up_text: "Why a partial index rather than a full one?",
        reason: "The answer names the diagnostic but not the index shape.",
      },
    },
    sourceDocuments: [RESUME, ANSWER],
  },
  {
    label: "resume parsing",
    tool: RESUME_PARSE_TOOL as never,
    input: { resume_lines: RESUME.split("\n") },
    sourceDocuments: [],
  },
  {
    label: "JD requirements extraction",
    tool: JD_REQUIREMENTS_TOOL as never,
    input: { role: "Senior Backend Engineer", job_description: JD },
    sourceDocuments: [],
  },
];

function mask(value: string | undefined): string {
  return value ? `${value.slice(0, 6)}…${value.slice(-4)}` : "(unset)";
}

const choice = resolveProvider(process.env);
console.log(`provider   : ${choice.provider} — ${choice.reason}`);
console.log(`tracing    : ${choice.tracing.enabled ? "on" : "off"} — ${choice.tracing.reason}`);
console.log(`groq key   : ${mask(process.env.GROQ_API_KEY)}`);
console.log(`openrouter : ${mask(process.env.OPENROUTER_API_KEY)}`);

if (choice.provider === "fixture") {
  // Not a failure — it is the documented degraded mode — but never what you
  // want in a deployment you just tried to verify.
  console.log("\nThe fixture provider is in use, so no network call was made and no live key was checked.");
  console.log("Set LLM_PROVIDER and the matching credential to check a real provider.");
  process.exit(1);
}

let failures = 0;

for (const check of CHECKS) {
  const started = Date.now();
  try {
    const result = await structuredCall(check.tool, check.input, {
      sourceDocuments: check.sourceDocuments,
      provider: choice.provider as ProviderName,
    });
    const ms = Date.now() - started;

    if (!result.output) {
      // Schema-valid but a REQUIRED claim was ungrounded — the model reached us
      // and answered, so the connection is fine; the generation is not (§11.3).
      failures += 1;
      console.log(`\nFAIL ${check.label} (${ms}ms) — required claims ungrounded: ${result.insufficientSignal.join(", ")}`);
      continue;
    }

    const caveat = result.grounded ? "" : ` (optional claims dropped: ${result.insufficientSignal.join(", ")})`;
    console.log(`\nOK   ${check.label} (${ms}ms) via ${result.provider}, prompt ${result.promptVersion}${caveat}`);
    console.log(`     ${summarize(result.output)}`);
  } catch (err) {
    failures += 1;
    if (err instanceof ProviderUnavailableError) {
      console.log(`\nFAIL ${check.label} — provider unreachable: ${err.message}`);
    } else if (err instanceof StructuredCallError) {
      console.log(`\nFAIL ${check.label} — reachable, but no schema-valid response after retry: ${err.message}`);
    } else {
      console.log(`\nFAIL ${check.label} — ${(err as Error).message}`);
    }
  }
}

/** One line of proof that something real came back, not just a 200. */
function summarize(output: unknown): string {
  const value = output as {
    question?: { text?: string };
    follow_up_text?: string;
    rationale?: { value?: string };
    skills?: string[];
    role_level?: string;
  };
  const text =
    value.question?.text ??
    value.follow_up_text ??
    value.rationale?.value ??
    (value.skills ? `skills: ${value.skills.slice(0, 5).join(", ")}` : undefined) ??
    (value.role_level ? `role_level: ${value.role_level}` : undefined) ??
    JSON.stringify(output);
  return text.replace(/\s+/g, " ").slice(0, 160);
}

console.log(
  failures === 0
    ? `\nAll ${CHECKS.length} LLM-backed calls work against ${choice.provider}.`
    : `\n${failures} of ${CHECKS.length} LLM-backed calls failed against ${choice.provider}.`,
);
process.exit(failures === 0 ? 0 : 1);

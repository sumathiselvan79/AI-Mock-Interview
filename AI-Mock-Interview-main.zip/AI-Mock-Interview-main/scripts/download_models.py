import urllib.request
import tarfile
import os

MODELS_DIR = "models"

URLS = [
    "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-whisper-tiny.en.tar.bz2"
]

def download_and_extract():
    os.makedirs(MODELS_DIR, exist_ok=True)
    
    for url in URLS:
        filename = url.split("/")[-1]
        filepath = os.path.join(MODELS_DIR, filename)
        
        if not os.path.exists(filepath):
            print(f"Downloading {filename}...")
            urllib.request.urlretrieve(url, filepath)
        
        print(f"Extracting {filename}...")
        with tarfile.open(filepath, "r:bz2") as tar:
            tar.extractall(path=MODELS_DIR)
            
    print("Done! Models are ready.")

if __name__ == "__main__":
    download_and_extract()

/**
 * Sandbox bootstrap. Runs INSIDE the isolated child process, before any
 * candidate code, and never inside an agent process (soul.md §5: "Never let the
 * Coding Agent execute candidate-submitted code outside an isolated sandbox").
 *
 * Layered on purpose, because no single Node-level mechanism is a real security
 * boundary on its own:
 *
 *   1. The process is spawned with Node's permission model enabled and no
 *      --allow-* flags, so `child_process`, `worker_threads` and native addons
 *      are denied by the runtime itself.
 *   2. This file removes network access — module-level (`net`, `http`, `dns`,
 *      …) and global (`fetch`, `WebSocket`) — before user code is loaded. The
 *      permission model does not cover the network, so this layer does.
 *   3. Filesystem modules are blocked here as well, so the failure is a clean
 *      refusal rather than depending on which permission flags happen to be set.
 *   4. Candidate code runs in a fresh `vm` context with a minimal global set.
 *   5. The parent enforces a wall-clock timeout and a heap cap, and kills the
 *      whole process tree if either is exceeded.
 *
 * `vm` alone is explicitly NOT a sandbox — Node documents that. It is the
 * innermost layer here, not the boundary. The production answer is a container
 * or microVM per execution (`INSTRUCTIONS.md §10`); this bootstrap is what makes
 * the same contract testable and safe enough to run locally.
 */

"use strict";

const Module = require("node:module");
const vm = require("node:vm");

const BLOCKED_MODULES = new Set([
  "fs", "node:fs", "fs/promises", "node:fs/promises",
  "net", "node:net", "http", "node:http", "https", "node:https",
  "http2", "node:http2", "dgram", "node:dgram", "dns", "node:dns",
  "dns/promises", "node:dns/promises", "tls", "node:tls",
  "child_process", "node:child_process", "worker_threads", "node:worker_threads",
  "cluster", "node:cluster", "inspector", "node:inspector",
  "v8", "node:v8", "vm", "node:vm", "repl", "node:repl",
  "process", "node:process", "module", "node:module",
]);

const originalLoad = Module._load;
Module._load = function guardedLoad(request, parent, isMain) {
  if (BLOCKED_MODULES.has(request)) {
    const error = new Error(`access to "${request}" is blocked inside the sandbox`);
    error.code = "ERR_SANDBOX_BLOCKED";
    throw error;
  }
  return originalLoad(request, parent, isMain);
};

// Network reachable without require(): remove it outright.
for (const name of ["fetch", "WebSocket", "XMLHttpRequest", "EventSource", "navigator"]) {
  try {
    delete globalThis[name];
  } catch {
    // Non-configurable in some builds; overwrite instead.
    try {
      globalThis[name] = undefined;
    } catch {
      /* nothing more to try; the module guard and permission model still apply */
    }
  }
}

let payload = "";
process.stdin.on("data", (chunk) => {
  payload += chunk;
});

process.stdin.on("end", () => {
  let request;
  try {
    request = JSON.parse(payload);
  } catch (err) {
    send({ ok: false, error: { type: "harness", message: `unreadable payload: ${err.message}` } });
    return;
  }
  run(request);
});

function run(request) {
  const logs = [];
  const results = [];

  const sandboxConsole = {
    log: (...args) => logs.push(args.map(stringify).join(" ")),
    error: (...args) => logs.push(args.map(stringify).join(" ")),
    warn: (...args) => logs.push(args.map(stringify).join(" ")),
    info: (...args) => logs.push(args.map(stringify).join(" ")),
  };

  // A deliberately small global surface: no require, no process, no timers that
  // could outlive the run.
  const context = vm.createContext({
    console: sandboxConsole,
    Math,
    JSON,
    Date,
    Number,
    String,
    Boolean,
    Array,
    Object,
    Map,
    Set,
    WeakMap,
    WeakSet,
    Promise,
    RegExp,
    Error,
    TypeError,
    RangeError,
    Symbol,
    BigInt,
    isNaN,
    isFinite,
    parseInt,
    parseFloat,
    structuredClone,
  });

  let solution;
  try {
    // The submission defines a function; the harness calls it per test case.
    const factory = vm.runInContext(
      `(function(){ ${request.code}\n; return typeof ${request.entryPoint} === "function" ? ${request.entryPoint} : undefined; })()`,
      context,
      { timeout: request.compileTimeoutMs || 2000, displayErrors: true },
    );
    solution = factory;
  } catch (err) {
    send({ ok: false, error: { type: classify(err), message: err.message }, logs });
    return;
  }

  if (typeof solution !== "function") {
    send({
      ok: false,
      error: {
        type: "no_entry_point",
        message: `no function named "${request.entryPoint}" was defined`,
      },
      logs,
    });
    return;
  }

  for (const testCase of request.testCases) {
    const startedAt = Date.now();
    try {
      const actual = vm.runInContext("__solution.apply(null, __args)", withArgs(context, solution, testCase.args), {
        timeout: request.caseTimeoutMs || 1000,
        displayErrors: true,
      });
      results.push({
        case: testCase.name,
        passed: deepEqual(actual, testCase.expected),
        durationMs: Date.now() - startedAt,
        ...(deepEqual(actual, testCase.expected) ? {} : { actual: preview(actual) }),
      });
    } catch (err) {
      results.push({
        case: testCase.name,
        passed: false,
        durationMs: Date.now() - startedAt,
        error: { type: classify(err), message: err.message },
      });
    }
  }

  send({ ok: true, results, logs });
}

function withArgs(context, solution, args) {
  context.__solution = solution;
  context.__args = args;
  return context;
}

function classify(err) {
  if (err && err.code === "ERR_SANDBOX_BLOCKED") return "blocked";
  if (err && err.code === "ERR_ACCESS_DENIED") return "blocked";
  if (err && /Script execution timed out/i.test(err.message || "")) return "timeout";
  return "runtime";
}

function stringify(value) {
  if (typeof value === "string") return value;
  try {
    return JSON.stringify(value);
  } catch {
    return String(value);
  }
}

function preview(value) {
  const text = stringify(value);
  return text.length > 200 ? `${text.slice(0, 200)}…` : text;
}

function deepEqual(a, b) {
  if (a === b) return true;
  if (typeof a !== typeof b) return false;
  if (a === null || b === null) return false;
  if (typeof a !== "object") return Number.isNaN(a) && Number.isNaN(b);
  if (Array.isArray(a) !== Array.isArray(b)) return false;
  const aKeys = Object.keys(a);
  const bKeys = Object.keys(b);
  if (aKeys.length !== bKeys.length) return false;
  return aKeys.every((key) => deepEqual(a[key], b[key]));
}

/**
 * Results are framed with a sentinel so anything the candidate code printed to
 * stdout cannot be mistaken for the runner's own output.
 */
const RESULT_SENTINEL = "__MIA_SANDBOX_RESULT__";

function send(message) {
  process.stdout.write([RESULT_SENTINEL, JSON.stringify(message), ""].join("\n"));
}

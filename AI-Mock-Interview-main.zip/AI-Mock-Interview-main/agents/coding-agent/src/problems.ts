/**
 * Coding problems. Data, not prompts, for the same reason the question bank is
 * (`packages/interview-domain`): the set can be reviewed by whoever owns
 * interview subject-matter expertise rather than being buried in agent code.
 *
 * Each problem carries visible examples the candidate sees and hidden cases they
 * do not — the hidden ones are what stop a solution that special-cases the
 * examples from passing.
 */

import type { TestCase } from "./runner.js";

export interface CodingProblem {
  id: string;
  title: string;
  /** Shown to the candidate. */
  statement: string;
  entryPoint: string;
  signature: string;
  difficulty: number;
  /** Topics this problem exercises, matching the shared topic vocabulary. */
  topics: string[];
  examples: { input: string; output: string }[];
  visibleCases: TestCase[];
  hiddenCases: TestCase[];
}

export const CODING_PROBLEMS: readonly CodingProblem[] = [
  {
    id: "rate-limiter",
    title: "Fixed-window rate limiter",
    statement:
      "Implement `allow(events, limit, windowMs)`. `events` is an array of millisecond timestamps in ascending order, each a request from one user. Return an array of booleans: true if that request should be allowed, false if it exceeds `limit` requests within any fixed window of `windowMs` starting at the first allowed request of the window.",
    entryPoint: "allow",
    signature: "function allow(events, limit, windowMs) -> boolean[]",
    difficulty: 3,
    topics: ["system design", "reliability and operations"],
    examples: [
      { input: "allow([0, 100, 200], 2, 1000)", output: "[true, true, false]" },
      { input: "allow([0, 1500], 1, 1000)", output: "[true, true]" },
    ],
    visibleCases: [
      { name: "under the limit", args: [[0, 100], 2, 1000], expected: [true, true] },
      { name: "third in window rejected", args: [[0, 100, 200], 2, 1000], expected: [true, true, false] },
    ],
    hiddenCases: [
      { name: "window resets", args: [[0, 1500], 1, 1000], expected: [true, true] },
      { name: "empty input", args: [[], 3, 1000], expected: [] },
      { name: "boundary is exclusive", args: [[0, 1000], 1, 1000], expected: [true, true] },
      {
        name: "burst then quiet then burst",
        args: [[0, 10, 20, 5000, 5010, 5020], 2, 1000],
        expected: [true, true, false, true, true, false],
      },
    ],
  },
  {
    id: "merge-intervals",
    title: "Merge overlapping intervals",
    statement:
      "Implement `merge(intervals)` where `intervals` is an array of `[start, end]` pairs in any order. Return the intervals merged so none overlap, sorted by start. Touching intervals ([1,3] and [3,5]) count as overlapping.",
    entryPoint: "merge",
    signature: "function merge(intervals) -> [start, end][]",
    difficulty: 2,
    topics: ["databases", "data engineering"],
    examples: [
      { input: "merge([[1,3],[2,6],[8,10]])", output: "[[1,6],[8,10]]" },
      { input: "merge([[1,4],[4,5]])", output: "[[1,5]]" },
    ],
    visibleCases: [
      { name: "overlapping", args: [[[1, 3], [2, 6], [8, 10]]], expected: [[1, 6], [8, 10]] },
      { name: "touching", args: [[[1, 4], [4, 5]]], expected: [[1, 5]] },
    ],
    hiddenCases: [
      { name: "unsorted input", args: [[[8, 10], [1, 3], [2, 6]]], expected: [[1, 6], [8, 10]] },
      { name: "fully contained", args: [[[1, 10], [2, 3]]], expected: [[1, 10]] },
      { name: "empty", args: [[]], expected: [] },
      { name: "single", args: [[[5, 7]]], expected: [[5, 7]] },
    ],
  },
  {
    id: "retry-backoff",
    title: "Retry schedule with capped backoff",
    statement:
      "Implement `schedule(attempts, baseMs, capMs)`. Return the delay before each retry using exponential backoff — `baseMs * 2^n` for the nth retry, starting at n = 0 — capped at `capMs`. Return an array of length `attempts`.",
    entryPoint: "schedule",
    signature: "function schedule(attempts, baseMs, capMs) -> number[]",
    difficulty: 2,
    topics: ["reliability and operations", "apis and services"],
    examples: [
      { input: "schedule(4, 100, 1000)", output: "[100, 200, 400, 800]" },
      { input: "schedule(5, 100, 300)", output: "[100, 200, 300, 300, 300]" },
    ],
    visibleCases: [
      { name: "uncapped", args: [4, 100, 1000], expected: [100, 200, 400, 800] },
      { name: "capped", args: [5, 100, 300], expected: [100, 200, 300, 300, 300] },
    ],
    hiddenCases: [
      { name: "zero attempts", args: [0, 100, 1000], expected: [] },
      { name: "cap below base", args: [3, 500, 100], expected: [100, 100, 100] },
      { name: "single attempt", args: [1, 50, 5000], expected: [50] },
    ],
  },
  {
    id: "dedupe-events",
    title: "Deduplicate events by idempotency key",
    statement:
      "Implement `dedupe(events)` where each event is `{ key, value }`. Return the values of the first event for each key, in the order those keys were first seen. Later events with a key already seen are dropped.",
    entryPoint: "dedupe",
    signature: "function dedupe(events) -> value[]",
    difficulty: 1,
    topics: ["distributed systems", "apis and services"],
    examples: [
      { input: 'dedupe([{key:"a",value:1},{key:"a",value:2},{key:"b",value:3}])', output: "[1, 3]" },
    ],
    visibleCases: [
      {
        name: "drops repeats",
        args: [[{ key: "a", value: 1 }, { key: "a", value: 2 }, { key: "b", value: 3 }]],
        expected: [1, 3],
      },
    ],
    hiddenCases: [
      { name: "empty", args: [[]], expected: [] },
      {
        name: "order preserved",
        args: [[{ key: "b", value: 1 }, { key: "a", value: 2 }, { key: "b", value: 9 }]],
        expected: [1, 2],
      },
      {
        name: "falsy values kept",
        args: [[{ key: "a", value: 0 }, { key: "a", value: 5 }]],
        expected: [0],
      },
    ],
  },
];

/**
 * Picks a problem near the candidate's difficulty target, preferring one whose
 * topics the interview already covered so the coding round follows on from the
 * conversation instead of arriving from nowhere.
 */
export function selectProblem(input: {
  difficultyTarget: number;
  coveredTopics?: string[];
  excludeIds?: string[];
}): CodingProblem {
  const covered = new Set(input.coveredTopics ?? []);
  const excluded = new Set(input.excludeIds ?? []);

  const candidates = CODING_PROBLEMS.filter((p) => !excluded.has(p.id));
  const pool = candidates.length > 0 ? candidates : CODING_PROBLEMS;

  return [...pool].sort((a, b) => {
    const aOverlap = a.topics.some((t) => covered.has(t)) ? 0 : 1;
    const bOverlap = b.topics.some((t) => covered.has(t)) ? 0 : 1;
    if (aOverlap !== bOverlap) return aOverlap - bOverlap;
    return (
      Math.abs(a.difficulty - input.difficultyTarget) - Math.abs(b.difficulty - input.difficultyTarget) ||
      a.id.localeCompare(b.id)
    );
  })[0] as CodingProblem;
}

export function getProblem(id: string): CodingProblem | undefined {
  return CODING_PROBLEMS.find((p) => p.id === id);
}

/**
 * Sandboxed execution runner.
 *
 * Candidate code runs in a **separate process**, never in the Coding Agent
 * (soul.md §5). The parent's job is the outer boundary: the permission model
 * flag, the heap cap, the wall-clock timeout, and killing the process if it
 * refuses to finish. `sandbox-bootstrap.cjs` handles what happens inside.
 *
 * Threat model, stated plainly: this stops a candidate's code from reading the
 * filesystem, reaching the network, spawning processes, or hanging the agent.
 * It is not a defence against a determined V8 escape — the production answer is
 * one container or microVM per execution (`INSTRUCTIONS.md §10`). What it does
 * give is a boundary that is enforced, testable, and identical in shape to the
 * containerised version, so swapping the two changes this file only.
 */

import { spawn } from "node:child_process";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const BOOTSTRAP = join(dirname(fileURLToPath(import.meta.url)), "sandbox-bootstrap.cjs");
const RESULT_SENTINEL = "__MIA_SANDBOX_RESULT__";

/** Per INSTRUCTIONS.md §9: sandboxed code execution stays under 5s. */
export const DEFAULT_TIMEOUT_MS = 5_000;
export const DEFAULT_HEAP_MB = 128;
export const MAX_CODE_BYTES = 64 * 1024;

export interface TestCase {
  name: string;
  args: unknown[];
  expected: unknown;
}

export interface CaseResult {
  case: string;
  passed: boolean;
  durationMs: number;
  actual?: string;
  error?: { type: string; message: string };
}

export interface RunOutcome {
  ok: boolean;
  results: CaseResult[];
  logs: string[];
  error?: { type: string; message: string };
  /** Wall-clock time for the whole run, including process start-up. */
  elapsedMs: number;
}

export interface RunRequest {
  code: string;
  entryPoint: string;
  testCases: TestCase[];
  timeoutMs?: number;
  heapMb?: number;
}

export async function runInSandbox(request: RunRequest): Promise<RunOutcome> {
  const startedAt = Date.now();

  if (request.code.length > MAX_CODE_BYTES) {
    return {
      ok: false,
      results: [],
      logs: [],
      error: { type: "too_large", message: `submission exceeds ${MAX_CODE_BYTES} bytes` },
      elapsedMs: Date.now() - startedAt,
    };
  }

  const timeoutMs = request.timeoutMs ?? DEFAULT_TIMEOUT_MS;

  const child = spawn(
    process.execPath,
    [
      // Node's permission model: with no --allow-* flags, child processes,
      // worker threads and native addons are denied by the runtime.
      "--permission",
      // Reading the bootstrap itself is the one filesystem grant needed to start.
      `--allow-fs-read=${BOOTSTRAP}`,
      `--max-old-space-size=${request.heapMb ?? DEFAULT_HEAP_MB}`,
      "--no-warnings",
      BOOTSTRAP,
    ],
    {
      stdio: ["pipe", "pipe", "pipe"],
      // No inherited environment: credentials and connection strings in the
      // agent's env must not be visible to candidate code.
      env: { NODE_ENV: "sandbox" },
      cwd: dirname(BOOTSTRAP),
      windowsHide: true,
    },
  );

  let stdout = "";
  let stderr = "";
  let timedOut = false;

  const timer = setTimeout(() => {
    timedOut = true;
    child.kill("SIGKILL");
  }, timeoutMs);

  child.stdout.on("data", (chunk: Buffer) => {
    stdout += chunk.toString();
    // A runaway `console.log` loop must not exhaust the parent's memory either.
    if (stdout.length > 2 * 1024 * 1024) child.kill("SIGKILL");
  });
  child.stderr.on("data", (chunk: Buffer) => {
    stderr += chunk.toString();
  });

  child.stdin.write(JSON.stringify(request));
  child.stdin.end();

  const exitCode = await new Promise<number | null>((resolve) => {
    child.on("close", (code) => resolve(code));
    child.on("error", () => resolve(null));
  });
  clearTimeout(timer);

  const elapsedMs = Date.now() - startedAt;

  if (timedOut) {
    return {
      ok: false,
      results: [],
      logs: [],
      error: {
        type: "timeout",
        message: `execution exceeded ${timeoutMs}ms and the sandbox was terminated`,
      },
      elapsedMs,
    };
  }

  const parsed = parseResult(stdout);
  if (!parsed) {
    return {
      ok: false,
      results: [],
      logs: [],
      error: {
        type: exitCode === 0 ? "no_result" : "crashed",
        message: firstLine(stderr) || `sandbox exited with code ${exitCode} and produced no result`,
      },
      elapsedMs,
    };
  }

  return { ...parsed, elapsedMs };
}

function parseResult(stdout: string): Omit<RunOutcome, "elapsedMs"> | null {
  const index = stdout.lastIndexOf(RESULT_SENTINEL);
  if (index < 0) return null;
  const payload = stdout.slice(index + RESULT_SENTINEL.length).trim();
  try {
    const parsed = JSON.parse(payload) as Partial<RunOutcome>;
    return {
      ok: parsed.ok ?? false,
      results: parsed.results ?? [],
      logs: parsed.logs ?? [],
      ...(parsed.error ? { error: parsed.error } : {}),
    };
  } catch {
    return null;
  }
}

function firstLine(text: string): string {
  return text.split("\n").find((line) => line.trim().length > 0)?.trim() ?? "";
}

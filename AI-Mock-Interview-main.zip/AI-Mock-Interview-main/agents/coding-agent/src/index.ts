/**
 * Coding Agent — INSTRUCTIONS.md §4.5.
 *
 * Presents a problem, executes submissions in an isolated sandbox, and
 * evaluates correctness alongside the candidate's reasoning.
 *
 * Voice (soul.md §4): "patient and exact. Evaluates correctness and the
 * candidate's reasoning process, not just whether the final output matched."
 * That shows up concretely: the Eval Tool scores the talk-through *and* the
 * executed test results, so a candidate who explains a sound approach but slips
 * on an edge case is not scored as though they understood nothing.
 *
 * Execution never happens in this process — `runner.ts` spawns a constrained
 * child (soul.md §5).
 */

import {
  McpHandlerError,
  type McpServerHandler,
  type ToolClientFactory,
} from "@mia/shared-types";
import { runInSandbox, type CaseResult } from "./runner.js";
import { getProblem, selectProblem, type CodingProblem } from "./problems.js";

export * from "./runner.js";
export * from "./problems.js";

export const SERVER_NAME = "coding-agent";
export const METHODS = ["start_coding_round", "submit_code", "get_round_result"] as const;

export interface CodingAgentDeps {
  toolClient: ToolClientFactory;
  /** Consent token for clipboard monitoring, when the candidate granted it. */
  clipboardConsentToken?(sessionId: string): Promise<string | null>;
}

export interface RoundState {
  sessionId: string;
  problemId: string;
  startedAt: string;
  submissions: number;
  lastResult?: SubmissionResult;
  /** The talk-through text the last scored submission was evaluated against — kept so the Report Agent can quote it (§4.8), never surfaced to the candidate as-is. */
  lastTalkThrough?: string;
}

export interface SubmissionResult {
  passed: number;
  total: number;
  results: CaseResult[];
  logs: string[];
  error?: { type: string; message: string };
  evaluation: { score: number; rationale: string; evidenceSpans: { start: number; end: number }[] } | null;
  evaluationNote?: string;
}

/** Rounds are in-memory: a coding round is live state, like a timer. */
export class CodingRoundStore {
  private readonly rounds = new Map<string, RoundState>();

  start(state: RoundState): void {
    this.rounds.set(state.sessionId, state);
  }
  get(sessionId: string): RoundState | undefined {
    return this.rounds.get(sessionId);
  }
  update(sessionId: string, patch: Partial<RoundState>): void {
    const existing = this.rounds.get(sessionId);
    if (existing) this.rounds.set(sessionId, { ...existing, ...patch });
  }
}

export function createCodingAgentServer(
  deps: CodingAgentDeps,
  rounds = new CodingRoundStore(),
): McpServerHandler {
  return {
    name: SERVER_NAME,
    async call(method: string, params: unknown): Promise<unknown> {
      switch (method) {
        case "start_coding_round":
          return startRound(deps, rounds, params as StartParams);
        case "submit_code":
          return submitCode(deps, rounds, params as SubmitParams);
        case "get_round_result": {
          const { session_id: sessionId } = params as { session_id: string };
          const round = rounds.get(sessionId);
          if (!round) throw new McpHandlerError("no_active_round", `no coding round for ${sessionId}`);
          const problem = getProblem(round.problemId);
          return {
            problem_id: round.problemId,
            // Enough for the Report Agent to place this round's score under the
            // right topics without a second hop back through this agent (§4.8).
            problem: problem
              ? { title: problem.title, statement: problem.statement, topics: problem.topics }
              : null,
            submissions: round.submissions,
            result: round.lastResult ? toWire(round.lastResult) : null,
            talk_through: round.lastTalkThrough ?? "",
          };
        }
        default:
          throw new McpHandlerError("unknown_method", `${SERVER_NAME} has no method ${method}`);
      }
    },
  };
}

interface StartParams {
  session_id: string;
  difficulty_target?: number;
  covered_topics?: string[];
}

async function startRound(deps: CodingAgentDeps, rounds: CodingRoundStore, params: StartParams) {
  const problem = selectProblem({
    difficultyTarget: params.difficulty_target ?? 3,
    ...(params.covered_topics ? { coveredTopics: params.covered_topics } : {}),
  });

  rounds.start({
    sessionId: params.session_id,
    problemId: problem.id,
    startedAt: new Date().toISOString(),
    submissions: 0,
  });

  // Clipboard monitoring only starts if the candidate consented; without a
  // token the tool refuses, and the round continues unmonitored rather than
  // being blocked (soul.md §"Consent-first monitoring").
  const consentToken = await deps.clipboardConsentToken?.(params.session_id);
  let monitoring = false;
  if (consentToken) {
    try {
      await deps.toolClient(params.session_id, SERVER_NAME).call("tool-clipboard-monitor", "start_monitor", {
        session_id: params.session_id,
        consent_token: consentToken,
      });
      monitoring = true;
    } catch {
      monitoring = false;
    }
  }

  return {
    problem: {
      id: problem.id,
      title: problem.title,
      statement: problem.statement,
      signature: problem.signature,
      entry_point: problem.entryPoint,
      difficulty: problem.difficulty,
      examples: problem.examples,
    },
    clipboard_monitoring: monitoring,
    started_at: new Date().toISOString(),
  };
}

interface SubmitParams {
  session_id: string;
  code: string;
  language?: string;
  /** The candidate's spoken talk-through, already transcribed by the harness. */
  talk_through?: string;
}

async function submitCode(deps: CodingAgentDeps, rounds: CodingRoundStore, params: SubmitParams) {
  const round = rounds.get(params.session_id);
  if (!round) throw new McpHandlerError("no_active_round", `no coding round for ${params.session_id}`);

  const problem = getProblem(round.problemId);
  if (!problem) throw new McpHandlerError("unknown_problem", `problem ${round.problemId} is gone`);

  if ((params.language ?? "javascript").toLowerCase() !== "javascript") {
    throw new McpHandlerError(
      "unsupported_language",
      `only javascript runs in this sandbox; got ${params.language}`,
    );
  }

  const outcome = await runInSandbox({
    code: params.code,
    entryPoint: problem.entryPoint,
    // Hidden cases run alongside the visible ones: passing the examples is not
    // the same as solving the problem.
    testCases: [...problem.visibleCases, ...problem.hiddenCases],
  });

  const passed = outcome.results.filter((r) => r.passed).length;

  const result: SubmissionResult = {
    passed,
    total: outcome.results.length,
    results: outcome.results,
    logs: outcome.logs,
    ...(outcome.error ? { error: outcome.error } : {}),
    evaluation: null,
  };

  // Score the reasoning and the tests together, through the Eval Tool — the
  // rubric lives there, never here (CLAUDE.md §8).
  try {
    const scored = await deps.toolClient(params.session_id, SERVER_NAME).call<{
      score: number;
      rationale: string;
      evidence_spans: { start: number; end: number }[];
    }>("tool-eval", "evaluate_answer", {
      rubric_id: "coding_round_v1",
      question: problem.statement,
      answer_transcript: params.talk_through ?? "",
      extra: { test_results: outcome.results.map((r) => ({ case: r.case, passed: r.passed })) },
    });
    result.evaluation = { score: scored.score, rationale: scored.rationale, evidenceSpans: scored.evidence_spans };
  } catch (err) {
    // A candidate who wrote code but said nothing cannot be scored on
    // reasoning; that is reported, not guessed at.
    result.evaluationNote = (err as Error).message;
  }

  rounds.update(params.session_id, {
    submissions: round.submissions + 1,
    lastResult: result,
    lastTalkThrough: params.talk_through ?? "",
  });

  return toWire(result);
}

/**
 * What the candidate is shown. Hidden-case *names* are included so failures are
 * actionable, but never their inputs — that would turn the round into a
 * guess-the-fixture exercise.
 */
function toWire(result: SubmissionResult) {
  return {
    passed: result.passed,
    total: result.total,
    results: result.results.map((r) => ({
      case: r.case,
      passed: r.passed,
      duration_ms: r.durationMs,
      ...(r.error ? { error: r.error } : {}),
    })),
    logs: result.logs.slice(0, 50),
    ...(result.error ? { error: result.error } : {}),
    evaluation: result.evaluation
      ? {
          score: result.evaluation.score,
          rationale: result.evaluation.rationale,
          evidence_spans: result.evaluation.evidenceSpans,
        }
      : null,
    ...(result.evaluationNote ? { evaluation_note: result.evaluationNote } : {}),
  };
}

export type { CodingProblem };

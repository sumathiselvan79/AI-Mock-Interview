/**
 * Report Agent — INSTRUCTIONS.md §4.8.
 *
 * Compiles the final evidence-linked report: one competency score per topic,
 * evidence-linked strengths/focus areas, and the required disclaimer.
 *
 * The Harness Agent assembles the full per-question transcript (question,
 * answer, and every persisted Evaluation) and hands it over as `params` —
 * this agent never reads storage directly, the same separation the Question
 * Agent already follows for `topic_plan`/`topic_counts` (§4.3). The Harness
 * Agent persists whatever `Report` this returns; this agent has no storage
 * dependency at all, only `toolClient` for the holistic pass.
 *
 * Voice (soul.md §4): "fair and evidence-based. Frames even a weak
 * performance constructively, always tied to specific moments in the
 * transcript." Concretely: every `evidence` string is a verbatim slice of an
 * actual answer transcript (via the Eval Tool's `evidence_spans`), and a topic
 * with no scoreable answer gets no competency score at all — it is named in
 * `focus_areas` instead, never guessed at (soul.md §"No fabrication").
 */

import {
  McpHandlerError,
  REPORT_DISCLAIMER,
  type CompetencyScore,
  type McpServerHandler,
  type ToolClient,
  type ToolClientFactory,
} from "@mia/shared-types";

export const SERVER_NAME = "report-agent";
export const METHODS = ["generate_report"] as const;
export type Method = (typeof METHODS)[number];

/** A score at or above this (of 5) is reported as a strength, not a focus area. */
export const STRENGTH_THRESHOLD = 3.5;

/** Same denomination the Harness Agent uses when scoring live answers (RUBRIC_FOR_TYPE, interview.ts). */
const RUBRIC_FOR_TYPE: Readonly<Record<"behavioral" | "technical" | "coding", string>> = {
  behavioral: "behavioral_v1",
  technical: "technical_v1",
  coding: "coding_round_v1",
};

interface EvidenceSpan {
  start: number;
  end: number;
}

interface TranscriptAnswerEvaluation {
  rubric_id: string;
  score: number;
  rationale: string;
  evidence_spans: EvidenceSpan[];
}

interface TranscriptEntry {
  question_id: string;
  topic: string;
  type: "behavioral" | "technical" | "coding";
  text: string;
  answer: { id: string; transcript: string; submitted_at: string } | null;
  evaluations: TranscriptAnswerEvaluation[];
}

interface GenerateReportParams {
  session_id: string;
  candidate_id: string;
  transcript: TranscriptEntry[];
}

export interface ReportAgentDeps {
  toolClient: ToolClientFactory;
}

export function createReportAgentServer(deps: ReportAgentDeps): McpServerHandler {
  return {
    name: SERVER_NAME,
    async call(method: string, params: unknown): Promise<unknown> {
      if (!(METHODS as readonly string[]).includes(method)) {
        throw new McpHandlerError("unknown_method", `${SERVER_NAME} has no method ${method}`);
      }
      return generateReport(deps, params as GenerateReportParams);
    },
  };
}

function sliceEvidence(transcript: string, span: EvidenceSpan): string | null {
  const text = transcript.slice(span.start, Math.min(span.end, transcript.length)).trim();
  return text.length > 0 ? text : null;
}

/** A crude majority vote; ties resolve to whichever type appears first. */
function dominantType(entries: TranscriptEntry[]): TranscriptEntry["type"] {
  const counts = new Map<TranscriptEntry["type"], number>();
  for (const entry of entries) counts.set(entry.type, (counts.get(entry.type) ?? 0) + 1);
  let best = entries[0]!.type;
  let bestCount = 0;
  for (const [type, count] of counts) {
    if (count > bestCount) {
      best = type;
      bestCount = count;
    }
  }
  return best;
}

const round1 = (n: number): number => Math.round(n * 10) / 10;

interface TopicResult {
  competency: CompetencyScore | null;
  /** Set when the topic had no scoreable answer at all — never silently dropped. */
  insufficientReason?: string;
}

/**
 * One topic's competency score: the average of every persisted per-answer
 * score, refined by one additional holistic pass over the topic's answers
 * combined (the "final holistic scoring pass" INSTRUCTIONS.md §4.8 calls
 * for) — genuinely a fresh Eval Tool call, not a re-read of the old ones.
 * If the combined transcript is too thin for that pass, the per-answer
 * average stands alone rather than the call failing the whole report.
 */
async function scoreTopic(tools: ToolClient, topic: string, entries: TranscriptEntry[]): Promise<TopicResult> {
  const evaluated = entries.filter((e) => e.answer && e.evaluations.length > 0);
  if (evaluated.length === 0) {
    return {
      competency: null,
      insufficientReason: `Not enough was said on ${topic} to score it — worth giving a fuller, more specific answer here next time.`,
    };
  }

  const perAnswerScores = evaluated.flatMap((e) => e.evaluations.map((ev) => ev.score));
  const averageScore = perAnswerScores.reduce((a, b) => a + b, 0) / perAnswerScores.length;

  const evidence: string[] = [];
  for (const entry of evaluated) {
    const span = entry.evaluations[0]?.evidence_spans[0];
    if (!span) continue;
    const quote = sliceEvidence(entry.answer!.transcript, span);
    if (quote && !evidence.includes(quote)) evidence.push(quote);
    if (evidence.length >= 2) break;
  }

  const rubricId = RUBRIC_FOR_TYPE[dominantType(evaluated)];
  const combinedTranscript = evaluated.map((e) => e.answer!.transcript).join(" ");

  let finalScore = averageScore;
  try {
    const holistic = await tools.call<{ score: number; evidence_spans: EvidenceSpan[] }>(
      "tool-eval",
      "evaluate_answer",
      {
        rubric_id: rubricId,
        question: `Overall performance across ${evaluated.length} question(s) on ${topic}`,
        answer_transcript: combinedTranscript,
      },
    );
    finalScore = round1((averageScore + holistic.score) / 2);
    if (evidence.length < 2) {
      const span = holistic.evidence_spans[0];
      const quote = span ? sliceEvidence(combinedTranscript, span) : null;
      if (quote && !evidence.includes(quote)) evidence.push(quote);
    }
  } catch (err) {
    // A thin combined transcript is not a report failure — the per-answer
    // average, already evidenced, stands on its own (soul.md §"No fabrication").
    if (!(err instanceof McpHandlerError && err.code === "insufficient_transcript")) throw err;
    finalScore = round1(averageScore);
  }

  // Every competency must cite real evidence; if scoring somehow produced none
  // (should not happen — evaluate_answer never persists a spanless score), this
  // topic is reported as unscoreable rather than asserting an unevidenced number.
  if (evidence.length === 0) {
    return {
      competency: null,
      insufficientReason: `${topic} was scored but no quotable evidence survived — treating it as unscoreable rather than reporting an unevidenced number.`,
    };
  }

  return { competency: { competency: topic, score: finalScore, evidence } };
}

async function generateReport(deps: ReportAgentDeps, params: GenerateReportParams) {
  const hasAnyEvidence = params.transcript.some((e) => e.answer && e.evaluations.length > 0);
  if (!hasAnyEvidence) {
    throw new McpHandlerError(
      "insufficient_evidence",
      "no answer in this session could be scored; refusing to guess at a report rather than inventing scores",
    );
  }

  const tools = deps.toolClient(params.session_id, SERVER_NAME);

  const byTopic = new Map<string, TranscriptEntry[]>();
  for (const entry of params.transcript) {
    const list = byTopic.get(entry.topic) ?? [];
    list.push(entry);
    byTopic.set(entry.topic, list);
  }

  const competencyScores: CompetencyScore[] = [];
  const insufficientNotes: string[] = [];

  for (const [topic, entries] of byTopic) {
    const result = await scoreTopic(tools, topic, entries);
    if (result.competency) competencyScores.push(result.competency);
    else if (result.insufficientReason) insufficientNotes.push(result.insufficientReason);
  }

  const strengths = competencyScores
    .filter((c) => c.score >= STRENGTH_THRESHOLD)
    .sort((a, b) => b.score - a.score)
    .map((c) => `Strong on ${c.competency} — for example: "${c.evidence[0]}"`);

  const focusAreas = [
    ...competencyScores
      .filter((c) => c.score < STRENGTH_THRESHOLD)
      .sort((a, b) => a.score - b.score)
      .map((c) => `Worth strengthening: ${c.competency} — the answer given was "${c.evidence[0]}"`),
    ...insufficientNotes,
  ];

  return {
    competency_scores: competencyScores.map((c) => ({
      competency: c.competency,
      score: c.score,
      evidence: c.evidence,
    })),
    strengths,
    focus_areas: focusAreas,
    disclaimer: REPORT_DISCLAIMER,
  };
}

/**
 * Topic planning — INSTRUCTIONS.md §4.3, step by step:
 *
 *  1. Start from the resume's `topic_relevance[]` and union it with the role's
 *     fixed `required_topics[]` plus any `jd_fit.gaps[]`.
 *  2. Distribute `question_budget` across that set, weighted by relevance, with
 *     a floor of 1 and a ceiling of 3 per topic. Every required topic gets at
 *     least one slot even at relevance 0.
 *  3. The result is `topic_plan[]`.
 *
 * The floor and ceiling are what soul.md §"Balanced coverage" is asking for: no
 * single standout line on a resume gets to dominate a session, and a
 * role-critical topic is covered even when the resume is silent on it.
 */

import { TOPIC_QUESTION_CEILING, TOPIC_QUESTION_FLOOR, type TopicPlanEntry, type TopicRelevance } from "@mia/shared-types";

export interface BuildTopicPlanInput {
  topicRelevance: TopicRelevance[];
  requiredTopics: string[];
  jdGapTopics?: string[];
  questionBudget: number;
}

interface Candidate {
  topic: string;
  weight: number;
  source: TopicPlanEntry["source"];
}

export function buildTopicPlan(input: BuildTopicPlanInput): TopicPlanEntry[] {
  const { questionBudget } = input;
  const jdGapTopics = input.jdGapTopics ?? [];

  const candidates = new Map<string, Candidate>();

  // Resume-derived topics, strongest first.
  for (const entry of input.topicRelevance) {
    if (entry.relevanceScore <= 0) continue;
    candidates.set(entry.topic, {
      topic: entry.topic,
      weight: entry.relevanceScore,
      source: "resume",
    });
  }

  // Role requirements and JD gaps. A topic already present keeps its resume
  // weight — the requirement only guarantees it a slot, it does not inflate it.
  for (const topic of jdGapTopics) {
    if (!candidates.has(topic)) {
      candidates.set(topic, { topic, weight: 0, source: "jd_gap" });
    }
  }
  for (const topic of input.requiredTopics) {
    if (!candidates.has(topic)) {
      candidates.set(topic, { topic, weight: 0, source: "role_requirement" });
    }
  }

  if (candidates.size === 0) return [];

  const guaranteed = new Set([...input.requiredTopics, ...jdGapTopics]);

  // Order: relevance first, then guaranteed topics, so that when the budget is
  // tighter than the topic set the interview still covers what the role demands.
  const ordered = [...candidates.values()].sort((a, b) => {
    if (b.weight !== a.weight) return b.weight - a.weight;
    const aGuaranteed = guaranteed.has(a.topic) ? 1 : 0;
    const bGuaranteed = guaranteed.has(b.topic) ? 1 : 0;
    if (aGuaranteed !== bGuaranteed) return bGuaranteed - aGuaranteed;
    return a.topic.localeCompare(b.topic);
  });

  // A budget smaller than the topic set cannot give everyone a slot. Required
  // topics keep theirs; the weakest resume-only topics drop out entirely rather
  // than every topic getting a fractional, unusable share.
  const selected = selectWithinBudget(ordered, guaranteed, questionBudget);

  // Everyone starts at the floor, then leftover budget is handed out by weight,
  // never past the ceiling.
  const plan = new Map<string, number>(selected.map((c) => [c.topic, TOPIC_QUESTION_FLOOR]));
  let remaining = questionBudget - selected.length;

  const totalWeight = selected.reduce((sum, c) => sum + c.weight, 0);
  if (remaining > 0 && totalWeight > 0) {
    for (const candidate of selected) {
      if (remaining <= 0) break;
      const share = Math.floor((candidate.weight / totalWeight) * (questionBudget - selected.length));
      const grant = Math.min(share, TOPIC_QUESTION_CEILING - TOPIC_QUESTION_FLOOR, remaining);
      if (grant > 0) {
        plan.set(candidate.topic, (plan.get(candidate.topic) ?? 0) + grant);
        remaining -= grant;
      }
    }
  }

  // Rounding leaves a remainder; give it to the strongest topics still under
  // the ceiling, in order.
  while (remaining > 0) {
    const next = selected.find((c) => (plan.get(c.topic) ?? 0) < TOPIC_QUESTION_CEILING);
    if (!next) break;
    plan.set(next.topic, (plan.get(next.topic) ?? 0) + 1);
    remaining -= 1;
    // Re-sort so the extra slots spread rather than piling onto the first topic.
    selected.sort((a, b) => (plan.get(a.topic) ?? 0) - (plan.get(b.topic) ?? 0) || b.weight - a.weight);
  }

  return selected.map((candidate) => ({
    topic: candidate.topic,
    maxQuestions: plan.get(candidate.topic) ?? TOPIC_QUESTION_FLOOR,
    source: candidate.source,
  }));
}

function selectWithinBudget(
  ordered: Candidate[],
  guaranteed: Set<string>,
  budget: number,
): Candidate[] {
  if (ordered.length <= budget) return [...ordered];

  const mustKeep = ordered.filter((c) => guaranteed.has(c.topic));
  const optional = ordered.filter((c) => !guaranteed.has(c.topic));
  const room = Math.max(0, budget - mustKeep.length);

  // If the required topics alone exceed the budget, they all still get a slot:
  // covering what the role demands beats respecting the budget exactly.
  const selected = [...mustKeep, ...optional.slice(0, room)];
  return ordered.filter((c) => selected.includes(c));
}

/** Total questions a plan accounts for. Should equal the budget when it fits. */
export function planCapacity(plan: TopicPlanEntry[]): number {
  return plan.reduce((sum, entry) => sum + entry.maxQuestions, 0);
}

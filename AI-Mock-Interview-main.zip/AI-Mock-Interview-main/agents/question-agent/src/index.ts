/**
 * Question Agent — INSTRUCTIONS.md §4.3.
 *
 * Owns CALIBRATION (building the topic plan) and question selection during
 * QUESTION_LOOP. Two rules do the real work here:
 *
 *  - **Quota enforcement.** Before selecting, any topic already at
 *    `topic_plan[topic].max_questions` is excluded for the rest of the session.
 *    If *every* topic is capped while budget remains, the agent may exceed one
 *    cap as a last resort — and must flag it with `quota_override: true` so the
 *    harness logs it. Never a silent over-drill of one topic.
 *  - **Progressive difficulty.** It opens below the target and works up
 *    (soul.md §4), rather than leading with the hardest question in the pool.
 *
 * `topic_counts` always arrives from the harness (sourced from the Memory
 * Agent). This agent never queries the Memory Agent directly (§4.7).
 */

import { randomUUID } from "node:crypto";
import {
  McpHandlerError,
  type McpServerHandler,
  type Question,
  type ToolClient,
  type ToolClientFactory,
  type TopicPlanEntry,
  type TopicRelevance,
} from "@mia/shared-types";
import {
  QUESTION_BANK,
  questionsForTopic,
  requiredTopicsFor,
  tierOf,
  getTopic,
  type BankQuestion,
  type Tier,
} from "@mia/interview-domain";
import { QUESTION_TOOL, type QuestionInput } from "@mia/llm-client";
import { buildTopicPlan } from "./topic-plan.js";

export * from "./topic-plan.js";

export const SERVER_NAME = "question-agent";
export const METHODS = ["build_topic_plan", "get_next_question"] as const;

export interface QuestionAgentDeps {
  /**
   * Reaches the Eval Tool for difficulty calibration (§4.3) and, from Stage 5,
   * the LLM Provider Tool for question + reference-answer generation. Optional:
   * without it the agent is exactly its Stage-2 self, which is also the
   * fallback whenever generation fails.
   */
  toolClient?: ToolClientFactory;
}

export interface SelectQuestionInput {
  sessionId: string;
  topicPlan: TopicPlanEntry[];
  topicCounts: Record<string, number>;
  askedQuestionIds: string[];
  difficultyTarget: number;
  /**
   * (Stage 6, §4.3) Tier of the last question asked in each topic, from the
   * Memory Agent's derivation. When supplied for a topic, escalation for that
   * topic runs off it and `topicScores` rather than the global difficulty
   * curve below — per-topic tiering is what `extractionMatrix.tier_N` is for.
   */
  topicTier?: Record<string, number>;
  /** (Stage 6, §4.3) Per-topic score history — what `escalationTriggerCondition` evaluates. */
  topicScores?: Record<string, number[]>;
}

export interface SelectedQuestion {
  question: Question;
  quotaOverride: boolean;
  /** Set when a quota override happened, for the harness's telemetry. */
  overrideReason?: string;
}

export function createQuestionAgentServer(deps: QuestionAgentDeps = {}): McpServerHandler {
  return {
    name: SERVER_NAME,
    async call(method: string, params: unknown): Promise<unknown> {
      switch (method) {
        case "build_topic_plan": {
          const p = params as {
            role: string;
            question_budget: number;
            topic_relevance?: { topic: string; relevance_score: number; evidence: string }[];
            jd_gap_topics?: string[];
          };
          const plan = buildTopicPlan({
            topicRelevance: (p.topic_relevance ?? []).map((t) => ({
              topic: t.topic,
              relevanceScore: t.relevance_score,
              evidence: t.evidence,
            })),
            requiredTopics: requiredTopicsFor(p.role),
            jdGapTopics: p.jd_gap_topics ?? [],
            questionBudget: p.question_budget,
          });
          return {
            topic_plan: plan.map((entry) => ({
              topic: entry.topic,
              max_questions: entry.maxQuestions,
              source: entry.source,
            })),
          };
        }

        case "get_next_question": {
          const p = params as {
            session_id: string;
            role?: string;
            topic_plan: { topic: string; max_questions: number; source: TopicPlanEntry["source"] }[];
            topic_counts?: Record<string, number>;
            topic_tier?: Record<string, number>;
            topic_scores?: Record<string, number[]>;
            asked_question_ids?: string[];
            difficulty_target?: number;
            recent_scores?: number[];
            candidate_profile_lines?: string[];
          };
          // The harness supplies the raw performance signal; deciding what
          // difficulty that implies is this agent's job (§4.3). Still computed
          // as the fallback for topics `topic_tier` has no entry for yet.
          const difficultyTarget =
            p.difficulty_target ?? difficultyTargetFrom(p.recent_scores ?? []);
          const topicPlan = p.topic_plan.map((e) => ({
            topic: e.topic,
            maxQuestions: e.max_questions,
            source: e.source,
          }));
          const selected = selectNextQuestion({
            sessionId: p.session_id,
            topicPlan,
            topicCounts: p.topic_counts ?? {},
            askedQuestionIds: p.asked_question_ids ?? [],
            difficultyTarget,
            topicTier: p.topic_tier ?? {},
            topicScores: p.topic_scores ?? {},
          });

          // (Stage 5) Selection above is deterministic and stays that way — the
          // quota rules, the per-topic cap and the difficulty curve are
          // properties of the system, not of a model's mood (§4.3). Generation
          // only rewrites the chosen slot's text and adds a reference answer.
          const generated = deps.toolClient
            ? await generateQuestion(deps.toolClient(p.session_id, SERVER_NAME), {
                sessionId: p.session_id,
                role: p.role ?? "",
                topicPlan,
                candidateProfileLines: p.candidate_profile_lines ?? [],
                selected: selected.question,
              })
            : null;

          return {
            question: {
              id: selected.question.id,
              bank_id: selected.question.bankId,
              session_id: selected.question.sessionId,
              text: generated?.text ?? selected.question.text,
              topic: selected.question.topic,
              type: selected.question.type,
              difficulty: selected.question.difficulty,
              ...(selected.question.tier !== undefined ? { tier: selected.question.tier } : {}),
              ...(selected.question.targetConceptIds
                ? { target_concept_ids: selected.question.targetConceptIds }
                : {}),
              quota_override: selected.quotaOverride,
              ...(generated?.promptVersion ? { prompt_version: generated.promptVersion } : {}),
            },
            // Deliberately a SIBLING of `question`, not a field on it (§4.3,
            // §6). The harness routes it straight to the Memory Agent; it must
            // never round-trip through the Question object that reaches the
            // frontend, the transcript, or any table a candidate or Admin can
            // read (soul.md §5, Stage 5 addition).
            ...(generated?.referenceAnswer ? { reference_answer: generated.referenceAnswer } : {}),
            ...(selected.overrideReason ? { override_reason: selected.overrideReason } : {}),
          };
        }

        default:
          throw new McpHandlerError("unknown_method", `${SERVER_NAME} has no method ${method}`);
      }
    },
  };
}

/**
 * (Stage 5, §4.3) Rewrites the selected slot's question text and produces its
 * reference answer in the same call (soul.md §"A reference answer is a
 * comparison aid").
 *
 * Returns null — meaning "keep the bank question, and score without a reference
 * answer" — on every failure path: provider unavailable, no schema-valid
 * response after the retry, a failed grounding check, or a generated `topic`
 * that is not on the plan. §4.3 asks for exactly that last one: a question
 * about a topic with no plan entry is an inconsistent question, and falling
 * back to the bank slot is better than asking it.
 */
async function generateQuestion(
  tools: ToolClient,
  input: {
    sessionId: string;
    role: string;
    topicPlan: TopicPlanEntry[];
    candidateProfileLines: string[];
    selected: Question;
  },
): Promise<{ text: string; referenceAnswer: string; promptVersion: string } | null> {
  const bankQuestion = QUESTION_BANK.find((q) => q.id === input.selected.bankId);

  const promptInput: QuestionInput = {
    role: input.role,
    topic_plan: input.topicPlan.map((e) => ({
      topic: e.topic,
      max_questions: e.maxQuestions,
      source: e.source,
    })),
    candidate_profile_lines: input.candidateProfileLines,
    baseline: {
      text: input.selected.text,
      topic: input.selected.topic,
      // The bank has no `coding` entries; a coding exercise is the Coding
      // Agent's job, not this one's (§4.5).
      type: input.selected.type === "coding" ? "technical" : input.selected.type,
      difficulty: input.selected.difficulty,
      ...(input.selected.tier !== undefined ? { tier: input.selected.tier } : {}),
      ...(bankQuestion ? { expected_signals: bankQuestion.expectedSignals } : {}),
    },
  };

  // What a generated `grounding.evidence` has to be a verbatim slice of: the
  // plan this session is running, and the profile it was built from.
  const planText = input.topicPlan.map((e) => `${e.topic} (${e.source})`).join("\n");

  let generated: {
    output: {
      question: { text: string; topic: string };
      reference_answer: string;
    } | null;
    prompt_version: string;
  };

  try {
    generated = await tools.call("tool-llm-provider", "generate_structured", {
      session_id: input.sessionId,
      tool_name: QUESTION_TOOL.name,
      prompt_version: QUESTION_TOOL.promptVersion,
      schema_ref: QUESTION_TOOL.schemaRef,
      input: promptInput,
      source_documents: [planText, input.candidateProfileLines.join("\n")],
    });
  } catch {
    return null;
  }

  if (!generated.output) return null;

  const onPlan = input.topicPlan.some((entry) => entry.topic === generated.output?.question.topic);
  if (!onPlan) return null;

  return {
    text: generated.output.question.text,
    referenceAnswer: generated.output.reference_answer,
    promptVersion: generated.prompt_version,
  };
}

export class NoQuestionsLeft extends McpHandlerError {
  constructor(message: string) {
    super("no_questions_available", message);
  }
}

export function selectNextQuestion(input: SelectQuestionInput): SelectedQuestion {
  // `askedQuestionIds` are bank ids, so the same question is never repeated
  // even though each asking gets its own `Question.id`.
  const asked = new Set(input.askedQuestionIds);

  const underCap = input.topicPlan.filter(
    (entry) => (input.topicCounts[entry.topic] ?? 0) < entry.maxQuestions,
  );

  // Normal path: pick from topics still under their cap.
  const fromUnderCap = pickFrom(underCap, input, asked);
  if (fromUnderCap) return { question: fromUnderCap.question, quotaOverride: false };

  // Last resort (§4.3): every topic is capped but the budget is not spent. Go
  // over one cap — explicitly flagged, never silently.
  const fromOverride = pickFrom(input.topicPlan, input, asked);
  if (fromOverride) {
    return {
      question: { ...fromOverride.question, quotaOverride: true },
      quotaOverride: true,
      overrideReason:
        underCap.length === 0
          ? "every topic in the plan reached its cap before the question budget was spent"
          : "no unasked question remained under any topic's cap",
    };
  }

  throw new NoQuestionsLeft(
    "the question bank has no unasked question left for any topic in this plan",
  );
}

function pickFrom(
  entries: TopicPlanEntry[],
  input: SelectQuestionInput,
  asked: Set<string>,
): { question: Question } | null {
  // Behavioral topics last. Then least-covered topic first, so coverage stays even.
  const ordered = [...entries].sort((a, b) => {
    const aKind = getTopic(a.topic)?.kind === "behavioral" ? 1 : 0;
    const bKind = getTopic(b.topic)?.kind === "behavioral" ? 1 : 0;
    if (aKind !== bKind) return aKind - bKind;

    const aCount = input.topicCounts[a.topic] ?? 0;
    const bCount = input.topicCounts[b.topic] ?? 0;
    if (aCount !== bCount) return aCount - bCount;
    return b.maxQuestions - a.maxQuestions || a.topic.localeCompare(b.topic);
  });

  for (const entry of ordered) {
    const candidates = questionsForTopic(entry.topic).filter((q) => !asked.has(q.id));
    if (candidates.length === 0) continue;

    const askedInTopic = input.topicCounts[entry.topic] ?? 0;
    const tier = nextTierFor(entry.topic, askedInTopic, input);
    const chosen = pickByTier(candidates, tier);

    return { question: toQuestion(chosen, input.sessionId) };
  }
  return null;
}

/**
 * (Stage 6, §4.3) Per-topic tier escalation — what `extractionMatrix.tier_N.
 * escalationTriggerCondition` actually evaluates. When the Memory Agent has a
 * tier on record for this topic, that plus this topic's own score history
 * decides whether the next question steps up, steps back, or holds; a strong
 * answer at tier 1 in "databases" should not be able to escalate "system
 * design" too (soul.md §"Balanced coverage" — coverage, and now depth, stay
 * per-topic, not blended into one global curve).
 *
 * A topic with no tier on record yet (never asked this session) falls back to
 * the pre-Stage-6 global difficulty curve, mapped onto a tier — the same
 * "opens below target, climbs on revisit" behavior Stage 2-5 callers still get
 * when they don't supply `topicTier`/`topicScores` at all.
 */
export function nextTierFor(topic: string, askedInTopic: number, input: SelectQuestionInput): Tier {
  const recorded = input.topicTier?.[topic];
  if (recorded !== undefined) {
    const current = clampTier(recorded);
    const scores = input.topicScores?.[topic] ?? [];
    if (scores.length === 0) return current;
    const recent = scores.slice(-2);
    const average = recent.reduce((sum, s) => sum + s, 0) / recent.length;
    if (average >= 4 && current < 3) return (current + 1) as Tier;
    if (average <= 2 && current > 1) return (current - 1) as Tier;
    return current;
  }

  const wanted = Math.max(1, Math.min(5, input.difficultyTarget - 1 + askedInTopic));
  return tierOf(wanted);
}

function clampTier(tier: number): Tier {
  if (tier < 1) return 1;
  if (tier > 3) return 3;
  return tier as Tier;
}

/**
 * Prefers an unasked question at exactly the wanted tier; falls back to the
 * nearest tier that still has one, so a topic never dead-ends just because its
 * tier-1 slot was already asked.
 */
export function pickByTier(candidates: BankQuestion[], tier: Tier): BankQuestion {
  return [...candidates].sort(
    (a, b) =>
      Math.abs(a.tier - tier) - Math.abs(b.tier - tier) ||
      a.tier - b.tier ||
      a.id.localeCompare(b.id),
  )[0] as BankQuestion;
}

function toQuestion(bankQuestion: BankQuestion, sessionId: string): Question {
  return {
    // A fresh id per asking; `bankId` is what dedupes against what was asked.
    id: randomUUID(),
    bankId: bankQuestion.id,
    sessionId,
    text: bankQuestion.text,
    topic: bankQuestion.topic,
    type: bankQuestion.type,
    difficulty: bankQuestion.difficulty,
    tier: bankQuestion.tier,
    targetConceptIds: bankQuestion.conceptIds,
    askedAt: new Date().toISOString(),
  };
}

/**
 * Difficulty target from the running performance signal: strong answers pull
 * the next question up, weak ones pull it down, and it never leaves 1-5.
 * Calibration only — the Question Agent does not score (§4.3).
 */
export function difficultyTargetFrom(recentScores: number[], base = 3): number {
  if (recentScores.length === 0) return base;
  const recent = recentScores.slice(-3);
  const average = recent.reduce((sum, s) => sum + s, 0) / recent.length;
  if (average >= 4) return Math.min(5, base + 1);
  if (average <= 2) return Math.max(1, base - 1);
  return base;
}

/** Every topic the bank can actually ask about — used to sanity-check a plan. */
export function coveredTopics(): string[] {
  return [...new Set(QUESTION_BANK.map((q) => q.topic))];
}

export type { TopicRelevance };

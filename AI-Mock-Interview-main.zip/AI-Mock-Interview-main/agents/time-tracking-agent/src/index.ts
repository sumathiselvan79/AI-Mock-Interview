/**
 * Time Tracking Agent — INSTRUCTIONS.md §4.6.
 *
 * Enforces and communicates per-segment time budgets. It never ends a segment
 * itself: it reports `nudge` before `expired` so the harness can warn the
 * candidate first (§4.6, soul.md §4 — "nudges, doesn't nag; a countdown should
 * inform pacing, not manufacture stress").
 *
 * Segment ids are `${sessionId}:${segment}`, so one session's clocks can never
 * collide with another's.
 */

import { McpHandlerError, type McpServerHandler, type ToolClientFactory } from "@mia/shared-types";

export const SERVER_NAME = "time-tracking-agent";
export const METHODS = ["start_segment", "stop_segment", "get_segment_state"] as const;

/** Default budgets in ms. A role or session may override them later. */
export const SEGMENT_BUDGETS = {
  question: 4 * 60_000,
  follow_up: 2 * 60_000,
  coding_round: 25 * 60_000,
  session: 45 * 60_000,
} as const;

export type SegmentKind = keyof typeof SEGMENT_BUDGETS;

export interface TimeTrackingDeps {
  toolClient: ToolClientFactory;
}

export const segmentId = (sessionId: string, segment: string): string => `${sessionId}:${segment}`;

export function createTimeTrackingAgentServer(deps: TimeTrackingDeps): McpServerHandler {
  return {
    name: SERVER_NAME,
    async call(method: string, params: unknown): Promise<unknown> {
      const p = (params ?? {}) as {
        session_id: string;
        segment: string;
        budget_ms?: number;
      };
      const tools = deps.toolClient(p.session_id, SERVER_NAME);
      const id = segmentId(p.session_id, p.segment);

      switch (method) {
        case "start_segment": {
          const budgetMs = p.budget_ms ?? SEGMENT_BUDGETS[p.segment as SegmentKind] ?? SEGMENT_BUDGETS.question;
          const result = await tools.call<{ segment_id: string; started_at: string }>(
            "tool-time-tracking",
            "start_timer",
            { segment_id: id, budget_ms: budgetMs },
          );
          return { segment_id: result.segment_id, started_at: result.started_at, budget_ms: budgetMs };
        }

        case "stop_segment": {
          const state = await tools.call<{ elapsed_ms: number; remaining_ms: number; segment_state: string }>(
            "tool-time-tracking",
            "get_elapsed",
            { segment_id: id },
          );
          return { elapsed_ms: state.elapsed_ms, segment_state: state.segment_state };
        }

        case "get_segment_state": {
          return tools.call("tool-time-tracking", "get_elapsed", { segment_id: id });
        }

        default:
          throw new McpHandlerError("unknown_method", `${SERVER_NAME} has no method ${method}`);
      }
    },
  };
}

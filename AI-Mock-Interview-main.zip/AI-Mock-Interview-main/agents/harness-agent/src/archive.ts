/**
 * Session archive compilation — INSTRUCTIONS.md §11.4.
 *
 * A job, not an agent (§11.4): there is no decision-making here, only assembly
 * from records that already exist. It is triggered by the Harness Agent at
 * `COMPLETED`, strictly after the Stage 4 retention/redaction job.
 *
 * That ordering is the entire safety property. This file contains no redaction
 * logic and deliberately should not: it reads the primary record as-is, so
 * whatever §8 already removed is simply not there to copy. An archive can
 * therefore never be more permissive than the primary record at write time
 * (soul.md §5 Stage 5 guardrail), and that stays true without anyone having to
 * remember to keep two redaction implementations in step.
 */

import {
  ArchiveRefused,
  type AnswerStore,
  type EvaluationStore,
  type Evaluation,
  type QuestionStore,
  type ReportStore,
  type Session,
  type SessionArchive,
} from "@mia/shared-types";

/** Just enough of the user store to resolve the archive's profile fields. */
export interface ArchiveUserLookup {
  findById(id: string): Promise<
    { id: string; fullName?: string; department?: string; programYear?: string } | null
  >;
}

export interface ArchiveSources {
  users: ArchiveUserLookup;
  questions: QuestionStore;
  answers: AnswerStore;
  evaluations: EvaluationStore;
  reports: ReportStore;
}

export async function compileSessionArchive(
  sources: ArchiveSources,
  session: Session,
): Promise<SessionArchive> {
  const candidate = await sources.users.findById(session.candidateId);

  // §11.4 step 2: a hard stop, not an "archive with blanks". An archive keyed
  // to a candidate whose name nobody recorded is worse than no archive — an
  // admin reading it later cannot tell whose it is.
  if (!candidate?.fullName) {
    throw new ArchiveRefused(
      `session ${session.id} cannot be archived: candidate ${session.candidateId} has no full name on their profile`,
    );
  }

  const report = await sources.reports.getBySession(session.id);
  if (!report) {
    throw new ArchiveRefused(`session ${session.id} has no report; there is nothing to archive yet`);
  }

  const questions = await sources.questions.listBySession(session.id);
  const answers = [];
  const evaluations: Evaluation[] = [];

  for (const question of questions) {
    const answer = await sources.answers.getByQuestion(question.id);
    if (!answer) continue;
    answers.push(answer);
    evaluations.push(...(await sources.evaluations.listByAnswer(answer.id)));
  }

  return {
    sessionId: session.id,
    candidateId: session.candidateId,
    candidateName: candidate.fullName,
    ...(candidate.department ? { department: candidate.department } : {}),
    ...(candidate.programYear ? { programYear: candidate.programYear } : {}),
    archivedAt: new Date().toISOString(),
    document: {
      session,
      topicPlan: session.topicPlan,
      questions,
      answers,
      evaluations,
      report,
    },
  };
}

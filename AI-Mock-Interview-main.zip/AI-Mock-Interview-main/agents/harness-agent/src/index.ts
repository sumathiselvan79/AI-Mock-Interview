/**
 * Harness Agent — MCP host, session state machine, sole interface to the frontend.
 *
 * Stage 1 scope (TRACKING.md): the state machine is real and authoritative; the
 * per-state work is wired as no-ops that later stages replace with MCP calls to
 * the specialized agents. The harness never speaks to the candidate (soul.md §2)
 * and is the only component that may write `Session.state`.
 */

import {
  MAX_FOCUS_EXITS,
  type AnswerStore,
  type EvaluationStore,
  type QuestionStore,
  type Report,
  type ReportStore,
  type Session,
  type SessionState,
  type SessionStore,
  type StateWriteGrant,
  type TelemetrySink,
  type ToolClientFactory,
} from "@mia/shared-types";
import { ArchiveRefused, type SessionArchive, type SessionArchiveStore } from "@mia/shared-types";
import { canTransition, requiresTelemetryCheck, STATE_OWNER } from "./state-machine.js";
import { compileSessionArchive, type ArchiveUserLookup } from "./archive.js";

export * from "./archive.js";
import {
  InterviewOrchestrator,
  type AnswerResult,
  type LowConfidenceTranscript,
  type NextQuestionResult,
  type SpokenText,
  type TranscriptionOutcome,
} from "./interview.js";

export * from "./state-machine.js";
export * from "./interview.js";

/**
 * The capability that authorizes a `Session.state` write.
 *
 * The symbol is module-private and never exported, so no other package can
 * forge an equivalent grant — importing this object from `@mia/harness-agent`
 * is the only way to obtain one, and the session store compares by identity.
 */
const HARNESS_TOKEN: unique symbol = Symbol("harness-agent.state-write");

export const HARNESS_GRANT: StateWriteGrant = Object.freeze({
  actor: "harness-agent" as const,
  token: HARNESS_TOKEN,
});

export class TransitionRejected extends Error {
  constructor(
    message: string,
    readonly from: SessionState,
    readonly to: SessionState,
  ) {
    super(message);
    this.name = "TransitionRejected";
  }
}

export interface HarnessDeps {
  sessions: SessionStore;
  telemetry: TelemetrySink;
  /**
   * Reads the device-check result recorded by POST /sessions/:id/telemetry-check.
   * Nothing downstream of TELEMETRY_CHECK may start until this is true
   * (INSTRUCTIONS.md §3).
   */
  telemetryCheckPassed(sessionId: string): Promise<boolean>;

  // Stage 2: what the harness needs to run QUESTION_LOOP. Optional so a Stage 1
  // style harness (state machine only) can still be constructed in isolation.
  questions?: QuestionStore;
  answers?: AnswerStore;
  evaluations?: EvaluationStore;
  toolClient?: ToolClientFactory;

  // Stage 4: where REPORT_GENERATION persists its result. Optional for the
  // same reason the Stage 2 deps are — a harness built without it simply
  // cannot reach REPORT_GENERATION.
  reports?: ReportStore;

  /**
   * Stage 5: the Supabase-hosted archive store, and the user lookup the
   * archive's profile fields come from (§11.4). Both optional — a deployment
   * without an archive store completes sessions exactly as Stage 4 did, which
   * is the correct behaviour for one that has not provisioned the second
   * database.
   */
  archives?: SessionArchiveStore;
  users?: ArchiveUserLookup;

  /** See `InterviewDeps.focusConsentToken` — passed straight through. */
  focusConsentToken?(sessionId: string): Promise<string | null>;
}

/** What a state handler reports back. In Stage 1 every handler is a no-op. */
export interface StateResult {
  done: boolean;
  note: string;
}

export class HarnessAgent {
  private readonly interview: InterviewOrchestrator | null;

  constructor(private readonly deps: HarnessDeps) {
    this.deps.sessions.registerStateWriter(HARNESS_GRANT);

    this.interview =
      deps.questions && deps.answers && deps.evaluations && deps.toolClient
        ? new InterviewOrchestrator({
            sessions: deps.sessions,
            questions: deps.questions,
            answers: deps.answers,
            evaluations: deps.evaluations,
            telemetry: deps.telemetry,
            toolClient: deps.toolClient,
            ...(deps.focusConsentToken ? { focusConsentToken: deps.focusConsentToken } : {}),
          })
        : null;
  }

  async getSession(sessionId: string): Promise<Session | null> {
    return this.deps.sessions.get(sessionId);
  }

  private orchestrator(): InterviewOrchestrator {
    if (!this.interview) {
      throw new Error("this harness was built without the interview-loop dependencies");
    }
    return this.interview;
  }

  private async requireSession(sessionId: string): Promise<Session> {
    const session = await this.deps.sessions.get(sessionId);
    if (!session) throw new Error(`unknown session ${sessionId}`);
    return session;
  }

  /**
   * CONFIG: route the uploaded resume to the Resume Service Agent and return
   * the JD-fit result for the Interview Config page. Informational only — a low
   * fit score never blocks a candidate from starting (soul.md §3).
   */
  async profileResume(sessionId: string) {
    return this.orchestrator().profileResume(await this.requireSession(sessionId));
  }

  /**
   * Routes a delete request to the Resume Service Agent, which hard-deletes the
   * stored file and verifies it is gone before reporting success (§8).
   */
  async deleteResume(sessionId: string): Promise<boolean> {
    await this.requireSession(sessionId);
    const result = await this.deps
      .toolClient!(sessionId, "harness-agent")
      .call<{ deleted: boolean }>("resume-service-agent", "delete_resume", { session_id: sessionId });
    return result.deleted;
  }

  /**
   * Moves a configured session into the interview proper:
   * TELEMETRY_CHECK -> CALIBRATION (build the topic plan) -> QUESTION_LOOP.
   * The device-check gate is enforced by `transition`, not re-checked here.
   */
  async beginInterview(sessionId: string): Promise<Session> {
    let session = await this.requireSession(sessionId);

    if (session.state === "TELEMETRY_CHECK") {
      session = await this.transition(sessionId, "CALIBRATION", "telemetry_check_passed");
    }
    if (session.state !== "CALIBRATION") {
      throw new TransitionRejected(
        `beginInterview expects CALIBRATION, session is in ${session.state}`,
        session.state,
        "CALIBRATION",
      );
    }

    session = await this.orchestrator().buildTopicPlan(session);

    if (session.topicPlan.length === 0) {
      throw new TransitionRejected(
        "no topic plan could be built — upload a resume or set a role with required topics first",
        session.state,
        "QUESTION_LOOP",
      );
    }

    // The overall session clock starts when questioning does, not at login.
    await this.deps.toolClient?.(sessionId, "harness-agent").call(
      "time-tracking-agent",
      "start_segment",
      { session_id: sessionId, segment: "session" },
    );

    // Fullscreen-exit tracking starts here too, for the same reason: "the
    // active interview" begins now, not at login. No-ops without consent.
    await this.orchestrator().startFocusMonitor(sessionId);

    return this.transition(sessionId, "QUESTION_LOOP", "topic_plan_ready");
  }

  /**
   * One turn of the loop. When the budget is spent the harness — not the
   * Question Agent — decides the interview is over and moves the session on.
   */
  async nextQuestion(sessionId: string, options: { advance?: boolean } = {}): Promise<NextQuestionResult> {
    const session = await this.requireSession(sessionId);
    if (session.state !== "QUESTION_LOOP") {
      throw new TransitionRejected(
        `questions are only served during QUESTION_LOOP; session is in ${session.state}`,
        session.state,
        "QUESTION_LOOP",
      );
    }

    const result = await this.orchestrator().nextQuestion(session, options);
    if (result.done) await this.transition(sessionId, "WRAP_UP", "question_budget_spent");
    return result;
  }

  async submitAnswer(input: {
    sessionId: string;
    questionId: string;
    transcript: string;
    transcriptConfidence?: number;
  }): Promise<AnswerResult> {
    const session = await this.requireSession(input.sessionId);
    return this.orchestrator().submitAnswer({
      session,
      questionId: input.questionId,
      transcript: input.transcript,
      ...(input.transcriptConfidence === undefined
        ? {}
        : { transcriptConfidence: input.transcriptConfidence }),
    });
  }

  /**
   * `sessionId` is required, not inferred from the answer: it is what the
   * orchestrator checks `answerId` against, so a client-supplied answer id can
   * only ever reach the session the caller was already authorized for.
   */
  async submitFollowUpAnswer(input: {
    sessionId: string;
    answerId: string;
    followUpText: string;
    transcript: string;
  }) {
    await this.requireSession(input.sessionId);
    return this.orchestrator().submitFollowUpAnswer(input);
  }

  /** Synthesises any text the candidate is about to hear (§4.1). */
  async speak(sessionId: string, text: string): Promise<SpokenText> {
    return this.orchestrator().speak(sessionId, text);
  }

  /**
   * Transcribes a recording and stops — nothing is scored, no state moves.
   *
   * This is the review-before-submit path: the candidate sees what was heard,
   * corrects it if the recogniser got it wrong, and only then submits, through
   * the ordinary text path. Keeping it separate from `submitAudioAnswer` is the
   * point — an answer the candidate has not confirmed must not be able to reach
   * the Eval Tool, and a method that both transcribes AND scores cannot offer
   * that guarantee. The audio is deleted by the Speech Service as it transcribes
   * (§8), so ending here leaves nothing behind either.
   */
  async transcribeAudio(input: { sessionId: string; audioRef: string }): Promise<TranscriptionOutcome> {
    await this.requireSession(input.sessionId);
    return this.orchestrator().transcribe(input.sessionId, input.audioRef);
  }

  /**
   * A spoken answer. Transcription happens first, and a low-confidence result
   * stops here: the caller is told to re-prompt or offer the typed fallback,
   * and nothing reaches the Eval Tool or the Follow-up Agent
   * (`INSTRUCTIONS.md §5.6`, soul.md §5).
   */
  async submitAudioAnswer(input: {
    sessionId: string;
    questionId: string;
    audioRef: string;
  }): Promise<{ accepted: false; retry: LowConfidenceTranscript } | { accepted: true; result: AnswerResult }> {
    const session = await this.requireSession(input.sessionId);
    const transcription = await this.orchestrator().transcribe(input.sessionId, input.audioRef);

    if (!transcription.accepted) return { accepted: false, retry: transcription };

    const result = await this.orchestrator().submitAnswer({
      session,
      questionId: input.questionId,
      transcript: transcription.transcript,
      transcriptConfidence: transcription.confidence,
    });
    return { accepted: true, result };
  }

  async submitFollowUpAudioAnswer(input: {
    sessionId: string;
    answerId: string;
    followUpText: string;
    audioRef: string;
  }): Promise<{ accepted: false; retry: LowConfidenceTranscript } | { accepted: true; result: { answer: import("@mia/shared-types").Answer } }> {
    await this.requireSession(input.sessionId);
    const transcription = await this.orchestrator().transcribe(input.sessionId, input.audioRef);
    if (!transcription.accepted) return { accepted: false, retry: transcription };

    const result = await this.orchestrator().submitFollowUpAnswer({
      sessionId: input.sessionId,
      answerId: input.answerId,
      followUpText: input.followUpText,
      transcript: transcription.transcript,
    });
    return { accepted: true, result: { answer: result } };
  }

  async startCodingRound(sessionId: string) {
    let session = await this.requireSession(sessionId);

    if (session.state === "QUESTION_LOOP") {
      session = await this.transition(sessionId, "CODING_ROUND", "question_loop_complete");
    }
    if (session.state !== "CODING_ROUND") {
      throw new TransitionRejected(
        `the coding round runs in CODING_ROUND; session is in ${session.state}`,
        session.state,
        "CODING_ROUND",
      );
    }

    const started = await this.orchestrator().startCodingRound(session);
    await this.deps.telemetry.emit("coding_round_started", sessionId, {
      problem_id: String(started.problem.id ?? "unknown"),
      clipboard_monitoring: started.clipboardMonitoring,
    });
    return started;
  }

  async submitCode(input: {
    sessionId: string;
    code: string;
    language?: string;
    talkThrough?: string;
  }) {
    const session = await this.requireSession(input.sessionId);
    const result = await this.orchestrator().submitCode({
      session,
      code: input.code,
      ...(input.language ? { language: input.language } : {}),
      ...(input.talkThrough ? { talkThrough: input.talkThrough } : {}),
    });

    // Sizes and counts only — never the submitted code (§8).
    await this.deps.telemetry.emit("code_submitted", input.sessionId, {
      code_bytes: input.code.length,
      passed: Number(result.passed ?? 0),
      total: Number(result.total ?? 0),
    });
    return result;
  }

  /**
   * A consented paste during the coding round. The Clipboard Monitor writes the
   * telemetry itself — it is the component that decides whether the event may
   * be recorded at all, so it is also the one that records it. The harness does
   * not emit a second event (`CLAUDE.md §8`: don't hand-roll a second logging
   * path).
   */
  async recordPasteEvent(sessionId: string, timestamp: string): Promise<boolean> {
    return this.orchestrator().recordPasteEvent(sessionId, timestamp);
  }

  /**
   * A consented fullscreen exit. On the 4th recorded exit ("more than 3",
   * `MAX_FOCUS_EXITS`) the session is wrapped up automatically — the same
   * closing message and transition an early "End the interview" click
   * produces (soul.md §"Respect for what this is": feedback on what was
   * covered, not a silent kick), not a separate punitive path.
   */
  async recordFocusEvent(
    sessionId: string,
    timestamp: string,
  ): Promise<{
    recorded: boolean;
    exitCount: number;
    concluded: boolean;
    wrapUp?: { session: Session; spoken: SpokenText };
  }> {
    const result = await this.orchestrator().recordFocusEvent(sessionId, timestamp);
    if (!result.recorded || result.exitCount <= MAX_FOCUS_EXITS) {
      return { ...result, concluded: false };
    }

    await this.deps.telemetry.emit("interview_concluded_early", sessionId, {
      exit_count: result.exitCount,
    });
    const wrapUp = await this.wrapUp(sessionId);
    return { ...result, concluded: true, wrapUp };
  }

  /** WRAP_UP: the harness's own closing message, then on to the report. */
  async wrapUp(sessionId: string): Promise<{ session: Session; spoken: SpokenText }> {
    let session = await this.requireSession(sessionId);
    if (session.state === "QUESTION_LOOP" || session.state === "CODING_ROUND") {
      session = await this.transition(sessionId, "WRAP_UP", "interview_finished");
    }
    const spoken = await this.orchestrator().speak(
      sessionId,
      "That's the end of the session. Your feedback is being put together now — it will point at specific moments from this conversation, so you can see exactly what to work on.",
    );
    return { session, spoken };
  }

  /**
   * WRAP_UP -> REPORT_GENERATION -> COMPLETED. Compiles and persists the
   * report, then purges what §8 says is no longer needed once it exists: the
   * raw resume (already routed through the same hard-delete path as an
   * explicit candidate delete, §4.2) and every answer's full transcript,
   * unless the candidate opted into keeping their recordings for personal
   * review (`consent.audioRecording` — the one "keep my personal review data
   * longer" flag this schema has; INSTRUCTIONS.md §5.6 and §8 use near-identical
   * wording for audio and transcript retention, so this reuses that flag for
   * both rather than adding a second one for the same candidate intent).
   * Redaction happens after persistence, so the report's own evidence quotes —
   * already extracted verbatim into the report — are unaffected.
   */
  async generateReport(sessionId: string): Promise<{ session: Session; report: Report }> {
    if (!this.deps.reports) {
      throw new Error("this harness was built without a report store");
    }

    let session = await this.requireSession(sessionId);
    if (session.state === "WRAP_UP") {
      session = await this.transition(sessionId, "REPORT_GENERATION", "wrap_up_complete");
    }
    if (session.state !== "REPORT_GENERATION") {
      throw new TransitionRejected(
        `report generation runs in REPORT_GENERATION; session is in ${session.state}`,
        session.state,
        "REPORT_GENERATION",
      );
    }

    const report = await this.orchestrator().generateReport(session);
    await this.deps.reports.create(report);

    if (session.resumeRef) await this.deleteResume(sessionId);

    if (!session.consent.audioRecording) {
      for (const question of await this.deps.questions!.listBySession(sessionId)) {
        const answer = await this.deps.answers!.getByQuestion(question.id);
        if (answer) await this.deps.answers!.redact(answer.id);
      }
    }

    const completed = await this.transition(sessionId, "COMPLETED", "report_generated");

    // (Stage 5, §11.4) Archiving runs HERE and nowhere earlier: strictly after
    // the retention/redaction above, so the archive can never be more
    // permissive than the primary record at the moment it is compiled
    // (soul.md §5 Stage 5 guardrail). Ordering is the whole mechanism — there
    // is no redaction step inside the archive job, because there does not need
    // to be one if it only ever reads an already-redacted record.
    await this.archiveSession(completed);

    // The reference answers and jd_fit working state this session was holding
    // have no purpose past COMPLETED, and §4.7 says they are dropped when the
    // session ends rather than left to a TTL.
    await this.forgetSessionMemory(sessionId);

    return { session: completed, report };
  }

  /**
   * Compiles and ships the session archive (§11.4).
   *
   * A job, not an agent: there is no decision-making here, only assembly.
   *
   * Failure never propagates. §11.4 is explicit that "if archiving fails, the
   * session still completes normally for the candidate" — a candidate's report
   * must not be held hostage to an export copy destined for an admin dashboard.
   * The failure is emitted as telemetry so a retry has something to key off.
   */
  async archiveSession(session: Session): Promise<SessionArchive | null> {
    if (!this.deps.archives) return null;

    try {
      const archive = await compileSessionArchive(
        {
          users: this.deps.users!,
          questions: this.deps.questions!,
          answers: this.deps.answers!,
          evaluations: this.deps.evaluations!,
          reports: this.deps.reports!,
        },
        session,
      );
      await this.deps.archives.upsert(archive);
      await this.deps.telemetry.emit("session_archived", session.id, {
        candidate_id: session.candidateId,
        questions: archive.document.questions.length,
        answers: archive.document.answers.length,
        evaluations: archive.document.evaluations.length,
      });
      return archive;
    } catch (err) {
      // Includes the §11.4 step 2 hard stop (no `User.fullName`). Reported
      // plainly rather than archived with blanks.
      await this.deps.telemetry.emit("session_archive_failed", session.id, {
        reason: err instanceof ArchiveRefused ? err.code : "archive_error",
        message: (err as Error).message,
      });
      return null;
    }
  }

  private async forgetSessionMemory(sessionId: string): Promise<void> {
    try {
      await this.deps.toolClient?.(sessionId, "harness-agent").call("memory-agent", "forget_session", {
        session_id: sessionId,
      });
    } catch {
      // Working memory has a TTL of its own; failing to clear it early is not
      // a reason to fail a completed session.
    }
  }

  /**
   * Move a session to `to`. Rejects illegal transitions and any transition past
   * an unpassed telemetry check. Emits `session_state_changed` telemetry with
   * IDs and states only — never any session content (§8).
   */
  async transition(sessionId: string, to: SessionState, reason = "harness_decision"): Promise<Session> {
    const session = await this.deps.sessions.get(sessionId);
    if (!session) throw new TransitionRejected(`unknown session ${sessionId}`, "CREATED", to);

    const check = canTransition(session.state, to);
    if (!check.allowed) {
      throw new TransitionRejected(check.reason ?? "illegal transition", session.state, to);
    }

    if (requiresTelemetryCheck(to) && !(await this.deps.telemetryCheckPassed(sessionId))) {
      throw new TransitionRejected(
        `telemetry check has not passed; ${to} is gated behind it`,
        session.state,
        to,
      );
    }

    const updated = await this.deps.sessions.setState(sessionId, to, HARNESS_GRANT, reason);

    await this.deps.telemetry.emit("session_state_changed", sessionId, {
      from_state: session.state,
      to_state: to,
      owner: STATE_OWNER[to],
      reason,
    });

    return updated;
  }

  /** Terminal abort. Always available so a partial report can still be handed back (§3). */
  async abort(sessionId: string, reason: string): Promise<Session> {
    return this.transition(sessionId, "ABORTED", reason);
  }

  /**
   * Per-state work. Stage 1: no-ops. Each later stage replaces one entry with a
   * real MCP call to the owning agent — the routing shape stays identical.
   */
  async runState(sessionId: string): Promise<StateResult> {
    const session = await this.deps.sessions.get(sessionId);
    if (!session) return { done: false, note: `unknown session ${sessionId}` };
    return {
      done: true,
      note: `no-op: ${session.state} is owned by ${STATE_OWNER[session.state]}, wired in a later stage`,
    };
  }
}

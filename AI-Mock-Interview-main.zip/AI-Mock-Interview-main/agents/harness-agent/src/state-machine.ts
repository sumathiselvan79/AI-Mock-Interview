/**
 * Session state machine — INSTRUCTIONS.md §3.
 *
 * Pure functions only: no I/O, no store access, so the legal-transition rules
 * can be unit tested on their own and reused by any future harness transport.
 */

import {
  SESSION_TRANSITIONS,
  TERMINAL_STATES,
  type SessionState,
} from "@mia/shared-types";

export interface TransitionCheck {
  allowed: boolean;
  reason?: string;
}

/** Every non-terminal state may be aborted (candidate leaves, unrecoverable error). */
export function allowedNextStates(from: SessionState): SessionState[] {
  if (TERMINAL_STATES.includes(from)) return [];
  return [...(SESSION_TRANSITIONS[from] ?? []), "ABORTED"];
}

export function canTransition(from: SessionState, to: SessionState): TransitionCheck {
  if (from === to) {
    return { allowed: false, reason: `already in ${from}` };
  }
  if (TERMINAL_STATES.includes(from)) {
    return { allowed: false, reason: `${from} is terminal` };
  }
  if (!allowedNextStates(from).includes(to)) {
    return {
      allowed: false,
      reason: `illegal transition ${from} -> ${to}; legal: ${allowedNextStates(from).join(", ")}`,
    };
  }
  return { allowed: true };
}

/**
 * Which agent owns the work done in a given state. The harness routes to this
 * agent on entry; the agent returns a result and a "done" signal, and the
 * harness — never the agent — decides the next state.
 */
export const STATE_OWNER: Readonly<Record<SessionState, string>> = {
  CREATED: "harness-agent",
  CONFIG: "resume-service-agent",
  TELEMETRY_CHECK: "harness-agent",
  CALIBRATION: "question-agent",
  QUESTION_LOOP: "question-agent",
  CODING_ROUND: "coding-agent",
  WRAP_UP: "harness-agent",
  REPORT_GENERATION: "report-agent",
  COMPLETED: "harness-agent",
  ABORTED: "harness-agent",
};

/**
 * Nothing downstream of TELEMETRY_CHECK may start until it passes
 * (INSTRUCTIONS.md §3). Stage 1 wires the guard; the device-check result it
 * reads is recorded by POST /sessions/:id/telemetry-check.
 */
export function requiresTelemetryCheck(to: SessionState): boolean {
  const gated: SessionState[] = [
    "CALIBRATION",
    "QUESTION_LOOP",
    "CODING_ROUND",
    "WRAP_UP",
    "REPORT_GENERATION",
  ];
  return gated.includes(to);
}

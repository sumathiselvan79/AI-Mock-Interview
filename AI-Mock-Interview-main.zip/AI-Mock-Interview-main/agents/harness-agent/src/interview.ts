/**
 * QUESTION_LOOP orchestration — the harness routing every step of a live
 * interview (INSTRUCTIONS.md §3, §4.1).
 *
 * Everything here is routing and state, never interviewing: the harness decides
 * *what happens next*, and each specialized agent decides *what to say*. The
 * harness never speaks to the candidate (soul.md §2), and no agent here talks
 * to another — every hop goes out through the MCP Gateway and comes back before
 * the next one starts.
 */

import { randomUUID } from "node:crypto";
import {
  MAX_FOCUS_EXITS,
  McpHandlerError,
  type Answer,
  type AnswerStore,
  type EvaluationStore,
  type LiveSessionState,
  type Question,
  type QuestionStore,
  type Report,
  type Session,
  type SessionStore,
  type TelemetrySink,
  type ToolClient,
  type ToolClientFactory,
} from "@mia/shared-types";

export const CALLER = "harness-agent";

/**
 * The Speech Service packs its detail into the error message as JSON so the
 * confidence and the draft survive the MCP error boundary. Falls back to the
 * raw message if that ever changes.
 */
function parseLowConfidence(message: string): {
  message: string;
  confidence?: number;
  draftTranscript?: string;
} {
  try {
    const parsed = JSON.parse(message) as {
      message?: string;
      confidence?: number;
      draft_transcript?: string;
    };
    return {
      message: parsed.message ?? message,
      ...(parsed.confidence === undefined ? {} : { confidence: parsed.confidence }),
      ...(parsed.draft_transcript === undefined ? {} : { draftTranscript: parsed.draft_transcript }),
    };
  } catch {
    return { message };
  }
}

/** Which rubric the Eval Tool should apply to an answer of a given type. */
export const RUBRIC_FOR_TYPE: Readonly<Record<Question["type"], string>> = {
  behavioral: "behavioral_v1",
  technical: "technical_v1",
  coding: "coding_round_v1",
};

export interface InterviewDeps {
  sessions: SessionStore;
  questions: QuestionStore;
  answers: AnswerStore;
  evaluations: EvaluationStore;
  telemetry: TelemetrySink;
  toolClient: ToolClientFactory;
  /**
   * Mints a consent token for fullscreen-exit tracking, or null when the
   * candidate never agreed to it on the Telemetry Check page. Optional so an
   * orchestrator built without it simply never starts the monitor — the same
   * "absent dependency degrades the feature, not the harness" contract as
   * every other Stage 2+ addition here.
   */
  focusConsentToken?(sessionId: string): Promise<string | null>;
}

export interface NextQuestionResult {
  done: boolean;
  question?: Question;
  /** Present when the loop is over, so the caller knows why. */
  note?: string;
  /** Present when the question could not be synthesised and is text-only. */
  speechNote?: string;
  askedCount: number;
  questionBudget: number;
}

export interface AnswerResult {
  answer: Answer;
  evaluation: { score: number; rationale: string } | null;
  /** Set when the answer could not be scored — surfaced plainly, never hidden. */
  evaluationNote?: string;
  followUp: { text: string; reason: string; audioUrl?: string } | null;
  /** (Stage 6, §4.4) Present whenever the Follow-up Agent had a tool client to reach the Eval Tool with. */
  extraction?: Answer["extraction"];
  nextAction?: Answer["nextAction"];
  /** (Stage 6, §12.6) The composed snapshot — see `LiveSessionState`'s doc comment. Present under the same condition as `extraction`/`nextAction`. */
  liveSessionState?: LiveSessionState;
}

/** What the frontend needs to play a question aloud, with the text always present. */
export interface SpokenText {
  text: string;
  audioUrl?: string;
  durationMs?: number;
  /** Set when synthesis failed and the candidate will see text only (§5.6). */
  speechNote?: string;
}

/**
 * A transcription the harness refused to accept. The draft is carried so the
 * candidate can be shown what was heard and correct it — it is never passed to
 * the Eval Tool or the Follow-up Agent (soul.md §5).
 */
export interface LowConfidenceTranscript {
  accepted: false;
  reason: string;
  confidence?: number;
  draftTranscript?: string;
}

export interface AcceptedTranscript {
  accepted: true;
  transcript: string;
  confidence: number;
}

export type TranscriptionOutcome = AcceptedTranscript | LowConfidenceTranscript;

/** Wire shape of a `JdFit` as the Resume Service Agent returns it (§4.2). */
export interface JdFitWire {
  fit_score: number;
  matched_requirements: string[];
  gaps: string[];
  rationale?: string;
  topic_relevance?: { topic: string; relevance_score: number; evidence: string }[];
  prompt_version?: string;
  insufficient_signal?: string[];
  role_level?: "junior" | "mid" | "senior" | "lead" | "staff+";
  key_technologies?: string[];
}

interface SessionContextResponse {
  session_context: {
    asked_question_ids: string[];
    topic_counts: Record<string, number>;
    topic_tier: Record<string, number>;
    questions_asked: number;
  };
}

export class InterviewOrchestrator {
  constructor(private readonly deps: InterviewDeps) {}

  private tools(sessionId: string): ToolClient {
    return this.deps.toolClient(sessionId, CALLER);
  }

  /**
   * CONFIG: hands the uploaded resume to the Resume Service Agent, which parses
   * it, scores topic relevance, and checks JD fit. Parse failures propagate — a
   * candidate is told the file could not be read rather than handed an invented
   * profile (soul.md §6).
   */
  async profileResume(session: Session): Promise<{
    topicRelevance: { topic: string; relevance_score: number; evidence: string }[];
    jdFit: JdFitWire;
  }> {
    if (!session.resumeRef) throw new Error("session has no uploaded resume");
    const tools = this.tools(session.id);

    // (Stage 5) The jd_fit draft round trip runs THROUGH the harness rather
    // than the Resume Service Agent reading the Memory Agent itself. Two agents
    // that need to coordinate coordinate here (CLAUDE.md §5 golden rule), which
    // costs one extra hop and keeps the session auditable from one place.
    //
    // The draft is looked up by resume fingerprint, which the agent only
    // returns after parsing — so the first call of a session never has one, and
    // a *replace* that produced identical content on the second call does.
    const draft = await this.jdFitDraft(session.id, session.jdFitFingerprint);

    const result = await tools.call<{
      profile: unknown;
      topic_relevance: { topic: string; relevance_score: number; evidence: string }[];
      jd_fit: JdFitWire;
      jd_gap_topics: string[];
      resume_fingerprint: string;
    }>("resume-service-agent", "parse_and_profile", {
      session_id: session.id,
      file_ref: session.resumeRef,
      role: session.role,
      ...(session.jobDescription ? { job_description: session.jobDescription } : {}),
      ...(draft ? { jd_fit_draft: draft } : {}),
    });

    // Only the generated fields are worth remembering; the deterministic ones
    // are cheap to recompute and must never be served from a cache that could
    // drift from the parse (§4.7).
    if (result.jd_fit.prompt_version) {
      await tools.call("memory-agent", "remember_jd_fit_draft", {
        session_id: session.id,
        resume_fingerprint: result.resume_fingerprint,
        jd_fit: {
          ...(result.jd_fit.rationale === undefined ? {} : { rationale: result.jd_fit.rationale }),
          ...(result.jd_fit.topic_relevance === undefined
            ? {}
            : {
                topicRelevance: result.jd_fit.topic_relevance.map((t) => ({
                  topic: t.topic,
                  relevanceScore: t.relevance_score,
                  evidence: t.evidence,
                })),
              }),
          promptVersion: result.jd_fit.prompt_version,
          ...(result.jd_fit.role_level === undefined ? {} : { roleLevel: result.jd_fit.role_level }),
          ...(result.jd_fit.key_technologies === undefined
            ? {}
            : { keyTechnologies: result.jd_fit.key_technologies }),
        },
      });
      await this.deps.sessions.patch(session.id, { jdFitFingerprint: result.resume_fingerprint });
    }

    return { topicRelevance: result.topic_relevance, jdFit: result.jd_fit };
  }

  /** Reads back a jd_fit generated earlier this session for this exact resume (§4.7). */
  private async jdFitDraft(sessionId: string, fingerprint: string | null): Promise<Record<string, unknown> | null> {
    if (!fingerprint) return null;
    try {
      const result = await this.tools(sessionId).call<{ found: boolean; jd_fit?: Record<string, unknown> }>(
        "memory-agent",
        "get_jd_fit_draft",
        { session_id: sessionId, resume_fingerprint: fingerprint },
      );
      return result.found && result.jd_fit ? result.jd_fit : null;
    } catch {
      // Working memory is an optimisation. Losing it costs one provider call,
      // never the config step.
      return null;
    }
  }

  /**
   * CALIBRATION: builds the session's topic plan from resume relevance, the
   * role's required topics and any JD gaps, then persists it. Called once —
   * `topic_plan` is set at CALIBRATION and read on every later call (§4.3).
   */
  async buildTopicPlan(session: Session): Promise<Session> {
    const profile = session.candidateProfile;
    // Computed by the Resume Service Agent at CONFIG and stored on the session,
    // so building the plan needs no second trip and works after the raw resume
    // has been deleted (§8).
    const jdGapTopics = session.jdGapTopics;

    const { topic_plan: plan } = await this.tools(session.id).call<{
      topic_plan: { topic: string; max_questions: number; source: "resume" | "role_requirement" | "jd_gap" }[];
    }>("question-agent", "build_topic_plan", {
      session_id: session.id,
      role: session.role,
      question_budget: session.questionBudget,
      topic_relevance: (profile?.topicRelevance ?? []).map((t) => ({
        topic: t.topic,
        relevance_score: t.relevanceScore,
        evidence: t.evidence,
      })),
      jd_gap_topics: jdGapTopics,
    });

    return this.deps.sessions.patch(session.id, {
      topicPlan: plan.map((entry) => ({
        topic: entry.topic,
        maxQuestions: entry.max_questions,
        source: entry.source,
      })),
    });
  }

  /**
   * One turn of QUESTION_LOOP. Reads `topic_counts` from the Memory Agent and
   * passes them to the Question Agent — which never queries memory itself
   * (§4.7) — then persists whatever comes back.
   *
   * Resume-safe by default: this is called every time the live channel opens,
   * including a reconnect (dropped wifi, a refreshed room tab, a restarted
   * gateway), not only when the candidate is genuinely ready to move on. If
   * the most recently asked question has no answer yet, that same question is
   * re-served rather than generating a replacement — a reconnect must not
   * silently burn a question-budget and topic-quota slot on a question the
   * candidate never got to answer. Only an explicit `advance` (the Skip
   * control) is allowed to abandon a pending question and generate the next
   * one.
   */
  async nextQuestion(session: Session, options: { advance?: boolean } = {}): Promise<NextQuestionResult> {
    const tools = this.tools(session.id);

    if (!options.advance) {
      const asked = await this.deps.questions.listBySession(session.id);
      const pending = asked[asked.length - 1];
      if (pending) {
        const answered = await this.deps.answers.getByQuestion(pending.id);
        if (!answered) {
          const spoken = await this.speak(session.id, pending.text);
          return {
            done: false,
            question: spoken.audioUrl ? { ...pending, audioUrl: spoken.audioUrl } : pending,
            ...(spoken.speechNote ? { speechNote: spoken.speechNote } : {}),
            askedCount: asked.length,
            questionBudget: session.questionBudget,
          };
        }
      }
    }

    const { session_context: context } = await tools.call<SessionContextResponse>(
      "memory-agent",
      "get_session_context",
      { session_id: session.id },
    );

    if (context.questions_asked >= session.questionBudget) {
      return {
        done: true,
        note: `question budget of ${session.questionBudget} is spent`,
        askedCount: context.questions_asked,
        questionBudget: session.questionBudget,
      };
    }

    // The Question Agent calibrates difficulty from these; the harness supplies
    // the signal but does not decide what to do with it (§4.3).
    const evaluations = await this.deps.evaluations.listBySession(session.id);
    const recentScores = evaluations.map((e) => e.score);
    // (Stage 6, §4.3) Per-topic score history — what per-topic tier escalation
    // runs against, as distinct from the global `recentScores` curve above.
    const topicScores = await this.topicScoresByTopic(session.id, evaluations);

    const result = await tools.call<{
      question: {
        id: string;
        bank_id: string;
        session_id: string;
        text: string;
        topic: string;
        type: Question["type"];
        difficulty: number;
        tier?: number;
        target_concept_ids?: string[];
        quota_override: boolean;
        prompt_version?: string;
      };
      reference_answer?: string;
      override_reason?: string;
    }>("question-agent", "get_next_question", {
      session_id: session.id,
      role: session.role,
      topic_plan: session.topicPlan.map((entry) => ({
        topic: entry.topic,
        max_questions: entry.maxQuestions,
        source: entry.source,
      })),
      topic_counts: context.topic_counts,
      topic_tier: context.topic_tier,
      topic_scores: topicScores,
      asked_question_ids: context.asked_question_ids,
      recent_scores: recentScores,
      // (Stage 5) What a generated question must stay consistent with, and the
      // source document its grounding check runs against (§4.3).
      candidate_profile_lines: profileLines(session),
    });

    const question = await this.deps.questions.append({
      id: result.question.id,
      bankId: result.question.bank_id,
      sessionId: session.id,
      text: result.question.text,
      topic: result.question.topic,
      type: result.question.type,
      difficulty: result.question.difficulty,
      ...(result.question.tier === undefined ? {} : { tier: result.question.tier as 1 | 2 | 3 }),
      ...(result.question.target_concept_ids ? { targetConceptIds: result.question.target_concept_ids } : {}),
      quotaOverride: result.question.quota_override,
      // Note what is NOT written here: `reference_answer`. It never touches the
      // questions table (§6, soul.md §5 Stage 5 addition).
      ...(result.question.prompt_version ? { promptVersion: result.question.prompt_version } : {}),
      askedAt: new Date().toISOString(),
    });

    await tools.call("memory-agent", "record_question_asked", {
      session_id: session.id,
      question_id: question.id,
      topic: question.topic,
    });

    // (Stage 5, §4.3) The reference answer goes straight from the Question
    // Agent to the Memory Agent by way of the harness, and stops there. It is
    // read back only by the Follow-up Question Agent, for scoring.
    if (result.reference_answer) {
      await tools.call("memory-agent", "remember_reference_answer", {
        session_id: session.id,
        question_id: question.id,
        reference_answer: result.reference_answer,
      });
    }

    // Per-question clock. No agent runs its own timer (CLAUDE.md §10).
    await tools.call("time-tracking-agent", "start_segment", {
      session_id: session.id,
      segment: `question:${question.id}`,
    });

    await this.deps.telemetry.emit("question_asked", session.id, {
      question_id: question.id,
      topic: question.topic,
      type: question.type,
      difficulty: question.difficulty,
      quota_override: question.quotaOverride ?? false,
    });

    // An override is always logged as its own event — the whole point of the
    // flag is that over-drilling a topic can never be silent (§4.3).
    if (result.question.quota_override) {
      await this.deps.telemetry.emit("quota_override_used", session.id, {
        question_id: question.id,
        topic: question.topic,
        reason: result.override_reason ?? "unspecified",
      });
    }

    // Spoken before it reaches the frontend (§4.1). If synthesis fails the
    // candidate reads it instead — the interview does not stop for audio.
    const spoken = await this.speak(session.id, question.text);

    return {
      done: false,
      question: spoken.audioUrl ? { ...question, audioUrl: spoken.audioUrl } : question,
      ...(spoken.speechNote ? { speechNote: spoken.speechNote } : {}),
      askedCount: context.questions_asked + 1,
      questionBudget: session.questionBudget,
    };
  }

  /**
   * (Stage 6, §4.3) Groups this session's scores by the topic of the question
   * they came from — one join (evaluation -> answer -> question), the same
   * shape `MemoryEvaluationStore.listBySession` already does, computed here
   * rather than added as a new Memory Agent method since the harness already
   * holds every piece the join needs.
   */
  private async topicScoresByTopic(
    sessionId: string,
    evaluations: { answerId: string; score: number }[],
  ): Promise<Record<string, number[]>> {
    if (evaluations.length === 0) return {};

    const questions = await this.deps.questions.listBySession(sessionId);
    const topicByQuestionId = new Map(questions.map((q) => [q.id, q.topic]));
    const answers = await Promise.all(evaluations.map((e) => this.deps.answers.get(e.answerId)));

    const topicScores: Record<string, number[]> = {};
    evaluations.forEach((evaluation, index) => {
      const answer = answers[index];
      const topic = answer ? topicByQuestionId.get(answer.questionId) : undefined;
      if (!topic) return;
      (topicScores[topic] ??= []).push(evaluation.score);
    });
    return topicScores;
  }

  /**
   * Records an answer, scores it, and asks whether a follow-up is warranted.
   *
   * A transcript the Eval Tool refuses to score comes back as
   * `evaluationNote` — never as a quietly invented low score
   * (soul.md §"No fabrication").
   */
  async submitAnswer(input: {
    session: Session;
    questionId: string;
    transcript: string;
    transcriptConfidence?: number;
  }): Promise<AnswerResult> {
    const question = await this.deps.questions.get(input.questionId);
    if (!question || question.sessionId !== input.session.id) {
      throw new Error(`question ${input.questionId} does not belong to this session`);
    }

    const tools = this.tools(input.session.id);

    const answer = await this.deps.answers.append({
      id: randomUUID(),
      questionId: question.id,
      transcript: input.transcript,
      ...(input.transcriptConfidence === undefined
        ? {}
        : { transcriptConfidence: input.transcriptConfidence }),
      followUps: [],
      submittedAt: new Date().toISOString(),
    });

    const segment = await tools.call<{ elapsed_ms: number }>("time-tracking-agent", "stop_segment", {
      session_id: input.session.id,
      segment: `question:${question.id}`,
    });

    // (Stage 5, §11.2) Scoring moved INTO the follow-up call. It used to be a
    // separate Eval hop here; folding it in is what lets the score inform the
    // follow-up decision, and it still persists an `Evaluation` immediately
    // (the Eval Tool does that whenever `answer_id` is supplied) rather than
    // deferring to REPORT_GENERATION.
    const referenceAnswer = await this.referenceAnswer(input.session.id, question.id);

    const followUpResponse = await tools.call<{
      should_follow_up: boolean;
      follow_up_text?: string;
      reason: string;
      anti_patterns_detected?: string[];
      next_action?: {
        system_directive: "escalate" | "pivot" | "drill_down";
        target_concept_id_for_next_prompt: string | null;
        synthesized_framing_strategy: string;
        generated_follow_up_prompt: string | null;
      };
      verified_concept_ids?: string[];
      unverified_concept_ids?: string[];
      score?: { rubric_id: string; value: number; rationale: string };
      score_note?: string;
    }>("followup-agent", "consider_follow_up", {
      session_id: input.session.id,
      question: question.text,
      answer_id: answer.id,
      answer_transcript: answer.transcript,
      rubric_id: RUBRIC_FOR_TYPE[question.type],
      ...(input.transcriptConfidence === undefined
        ? {}
        : { transcript_confidence: input.transcriptConfidence }),
      // Relayed from the Memory Agent by the harness — the Follow-up Agent
      // never queries it directly (CLAUDE.md §5, §4.7).
      ...(referenceAnswer ? { reference_answer: referenceAnswer } : {}),
      // Stamped onto the persisted Evaluation so a score is traceable to the
      // prompt version whose reference answer informed it (§6, §11.5).
      ...(referenceAnswer && question.promptVersion
        ? { prompt_version: question.promptVersion }
        : {}),
      // (Stage 6, §4.4) What the concept-verification pass and the
      // escalate/pivot/drill_down decision run against.
      ...(question.tier === undefined ? {} : { tier: question.tier }),
      ...(question.targetConceptIds ? { target_concept_ids: question.targetConceptIds } : {}),
    });

    const evaluation = followUpResponse.score
      ? { score: followUpResponse.score.value, rationale: followUpResponse.score.rationale }
      : null;
    const evaluationNote = followUpResponse.score_note;

    let followUp: { text: string; reason: string; audioUrl?: string } | null = null;
    if (followUpResponse.should_follow_up && followUpResponse.follow_up_text) {
      // The probe is spoken too, so the candidate hears one continuous voice
      // rather than a question aloud and a follow-up in text (soul.md §2).
      const spoken = await this.speak(input.session.id, followUpResponse.follow_up_text);
      followUp = {
        text: followUpResponse.follow_up_text,
        reason: followUpResponse.reason,
        ...(spoken.audioUrl ? { audioUrl: spoken.audioUrl } : {}),
      };
    }

    if (followUp) {
      await this.deps.telemetry.emit("follow_up_triggered", input.session.id, {
        question_id: question.id,
        answer_id: answer.id,
        reason: followUp.reason,
      });
    }

    // (Stage 6, §4.4) An enrichment on top of the score/follow-up decision
    // above, not a gate on either — a Follow-up Agent built without a tool
    // client (or one whose Eval Tool call failed) simply omits `next_action`.
    let extraction: Answer["extraction"];
    let nextAction: Answer["nextAction"];
    let liveSessionState: LiveSessionState | undefined;
    if (followUpResponse.next_action) {
      extraction = {
        transcribedInputChunk: answer.transcript,
        verifiedConceptIds: followUpResponse.verified_concept_ids ?? [],
        unverifiedConceptIds: followUpResponse.unverified_concept_ids ?? [],
        antiPatternsDetected: followUpResponse.anti_patterns_detected ?? [],
      };
      nextAction = {
        systemDirective: followUpResponse.next_action.system_directive,
        targetConceptIdForNextPrompt: followUpResponse.next_action.target_concept_id_for_next_prompt,
        synthesizedFramingStrategy: followUpResponse.next_action.synthesized_framing_strategy,
        generatedFollowUpPrompt: followUpResponse.next_action.generated_follow_up_prompt,
      };
      try {
        // `transcribedInputChunk` never gets a second, redaction-blind copy at
        // rest — see the field's doc comment on `ExtractionProcessorResult`.
        const { transcribedInputChunk: _ephemeralOnly, ...persistedExtraction } = extraction;
        await this.deps.answers.recordExtraction(answer.id, persistedExtraction, nextAction);
      } catch {
        // The answer and its score are already durable; losing this write
        // loses an enrichment, never the underlying record.
      }

      liveSessionState = composeLiveSessionState({
        session: input.session,
        question,
        extraction,
        nextAction,
        score: followUpResponse.score?.value,
        elapsedMs: segment.elapsed_ms,
      });
    }

    return {
      answer,
      evaluation,
      ...(evaluationNote ? { evaluationNote } : {}),
      followUp,
      ...(extraction ? { extraction } : {}),
      ...(nextAction ? { nextAction } : {}),
      ...(liveSessionState ? { liveSessionState } : {}),
    };
  }

  /**
   * (Stage 5, §4.4) Records an answered follow-up and scores that exchange.
   *
   * The score lands on this specific `follow_ups[]` entry, not in a new
   * top-level `Evaluation` — a follow-up is a sub-unit of the answer it belongs
   * to, and `evaluations.evidence_spans` already means "indices into
   * `answers.transcript`" for every existing reader of that table (§11.7). Here
   * the spans index into the follow-up's own transcript.
   */
  async submitFollowUpAnswer(input: {
    sessionId: string;
    answerId: string;
    followUpText: string;
    transcript: string;
  }): Promise<Answer> {
    // The same ownership guard `submitAnswer` applies to `questionId`, and for
    // the same reason: `answerId` arrives from the client, and without this an
    // authenticated candidate could append a follow-up transcript onto an
    // answer in someone else's session. Checked BEFORE anything is written —
    // a rejected call must not leave a follow-up behind on the victim's answer.
    const existing = await this.deps.answers.get(input.answerId);
    const question = existing ? await this.deps.questions.get(existing.questionId) : null;
    if (!existing || !question || question.sessionId !== input.sessionId) {
      throw new Error(`answer ${input.answerId} does not belong to this session`);
    }

    const answer = await this.deps.answers.appendFollowUp(input.answerId, {
      text: input.followUpText,
      transcript: input.transcript,
    });

    try {
      const scored = await this.tools(question.sessionId).call<{
        scored: boolean;
        score?: {
          rubric_id: string;
          value: number;
          rationale: string;
          evidence_spans: { start: number; end: number }[];
        };
      }>("followup-agent", "score_follow_up_exchange", {
        session_id: question.sessionId,
        question: question.text,
        follow_up_text: input.followUpText,
        follow_up_transcript: input.transcript,
        rubric_id: RUBRIC_FOR_TYPE[question.type],
      });

      if (!scored.scored || !scored.score) return answer;

      const index = answer.followUps.length - 1;
      return this.deps.answers.scoreFollowUp(input.answerId, index, {
        rubricId: scored.score.rubric_id,
        value: scored.score.value,
        rationale: scored.score.rationale,
        evidenceSpans: scored.score.evidence_spans,
      });
    } catch {
      // An unscoreable follow-up is a normal outcome, not a lost exchange —
      // the transcript is already recorded above (soul.md §6).
      return answer;
    }
  }

  /**
   * (Stage 5, §4.4) Reads the question's reference answer out of the Memory
   * Agent so it can be relayed to the Follow-up Agent for scoring.
   *
   * Absent is normal: a question that came from the deterministic bank path has
   * no reference answer, and scoring proceeds on the rubric alone.
   */
  private async referenceAnswer(sessionId: string, questionId: string): Promise<string | null> {
    try {
      const result = await this.tools(sessionId).call<{ found: boolean; reference_answer?: string }>(
        "memory-agent",
        "get_reference_answer",
        { session_id: sessionId, question_id: questionId },
      );
      return result.found ? (result.reference_answer ?? null) : null;
    } catch {
      return null;
    }
  }

  // ------------------------------------------------------------------ voice

  /**
   * Every question or follow-up an agent produces goes through here before it
   * reaches the candidate (§4.1). No specialized agent calls the Speech Service
   * itself, so the voice pipeline stays in one auditable place.
   *
   * Synthesis failure is not fatal: the candidate reads the question instead
   * (§5.6). Losing audio must never lose the interview.
   */
  async speak(sessionId: string, text: string): Promise<SpokenText> {
    try {
      const result = await this.tools(sessionId).call<{ audio_url: string; duration_ms: number }>(
        "tool-speech-service",
        "synthesize_speech",
        { text, session_id: sessionId },
      );
      return { text, audioUrl: result.audio_url, durationMs: result.duration_ms };
    } catch (err) {
      return {
        text,
        speechNote: `audio unavailable (${(err as Error).message}); showing the question as text`,
      };
    }
  }

  /**
   * Transcribes a recorded answer. A low-confidence result is returned as a
   * refusal rather than a transcript, so the caller has to choose between
   * re-prompting and the typed fallback — there is no code path that quietly
   * scores a doubtful transcript (soul.md §5).
   */
  async transcribe(sessionId: string, audioRef: string): Promise<TranscriptionOutcome> {
    try {
      const result = await this.tools(sessionId).call<{ transcript: string; confidence: number }>(
        "tool-speech-service",
        "transcribe_speech",
        { audio_ref: audioRef, session_id: sessionId },
      );
      return { accepted: true, transcript: result.transcript, confidence: result.confidence };
    } catch (err) {
      const error = err as { code?: string; message: string };

      if (error.code === "transcription_low_confidence") {
        const detail = parseLowConfidence(error.message);
        await this.deps.telemetry.emit("transcription_low_confidence", sessionId, {
          confidence: detail.confidence ?? null,
        });
        return {
          accepted: false,
          reason: detail.message,
          ...(detail.confidence === undefined ? {} : { confidence: detail.confidence }),
          ...(detail.draftTranscript === undefined ? {} : { draftTranscript: detail.draftTranscript }),
        };
      }

      return { accepted: false, reason: error.message };
    }
  }

  // ----------------------------------------------------------- coding round

  /**
   * CODING_ROUND. The problem statement is spoken like any other prompt, and
   * clipboard monitoring starts only if the candidate consented — the Coding
   * Agent asks the tool, and the tool refuses without a valid token.
   */
  async startCodingRound(session: Session): Promise<{
    problem: Record<string, unknown>;
    clipboardMonitoring: boolean;
    spoken: SpokenText;
  }> {
    const askedTopics = (await this.deps.questions.listBySession(session.id)).map((q) => q.topic);

    const result = await this.tools(session.id).call<{
      problem: { title: string; statement: string } & Record<string, unknown>;
      clipboard_monitoring: boolean;
    }>("coding-agent", "start_coding_round", {
      session_id: session.id,
      covered_topics: [...new Set(askedTopics)],
    });

    await this.tools(session.id).call("time-tracking-agent", "start_segment", {
      session_id: session.id,
      segment: "coding_round",
    });

    return {
      problem: result.problem,
      clipboardMonitoring: result.clipboard_monitoring,
      spoken: await this.speak(session.id, `${result.problem.title}. ${result.problem.statement}`),
    };
  }

  async submitCode(input: {
    session: Session;
    code: string;
    language?: string;
    talkThrough?: string;
  }): Promise<Record<string, unknown>> {
    return this.tools(input.session.id).call<Record<string, unknown>>("coding-agent", "submit_code", {
      session_id: input.session.id,
      code: input.code,
      ...(input.language ? { language: input.language } : {}),
      ...(input.talkThrough ? { talk_through: input.talkThrough } : {}),
    });
  }

  /** Records a consented paste event: a boolean and a timestamp, nothing else. */
  async recordPasteEvent(sessionId: string, timestamp: string): Promise<boolean> {
    try {
      await this.tools(sessionId).call("tool-clipboard-monitor", "paste_event_detected", {
        session_id: sessionId,
        detected: true,
        timestamp,
      });
      return true;
    } catch {
      // No consent means no record. Not an error the candidate needs to see.
      return false;
    }
  }

  /**
   * Starts fullscreen-exit tracking for the whole active interview — called
   * once, from `beginInterview`, not per-round the way the Coding Agent starts
   * clipboard monitoring. Best-effort: no consent (or no dep at all) simply
   * means the monitor never starts, exactly like every other consent gate here.
   */
  async startFocusMonitor(sessionId: string): Promise<void> {
    const token = await this.deps.focusConsentToken?.(sessionId);
    if (!token) return;
    try {
      await this.tools(sessionId).call("tool-focus-monitor", "start_monitor", {
        session_id: sessionId,
        consent_token: token,
      });
    } catch {
      // A monitor that failed to start is the same as one that was never
      // consented to — the interview still runs.
    }
  }

  /** Records a consented fullscreen-exit event and returns the running count. */
  async recordFocusEvent(sessionId: string, timestamp: string): Promise<{ recorded: boolean; exitCount: number }> {
    try {
      const result = await this.tools(sessionId).call<{ recorded: boolean; exit_count: number }>(
        "tool-focus-monitor",
        "focus_event_detected",
        { session_id: sessionId, detected: true, timestamp },
      );
      return { recorded: result.recorded, exitCount: result.exit_count };
    } catch {
      // No consent (or no monitor started) means no record — not an error the
      // candidate needs to see.
      return { recorded: false, exitCount: 0 };
    }
  }

  // ------------------------------------------------------------- reporting

  /**
   * REPORT_GENERATION: gathers every question, its answer, and every
   * persisted Evaluation into one transcript, folds in the coding round's
   * result when one ran (it lives outside questions/answers — the Coding
   * Agent's own live state, §4.5 — so it would otherwise be silently dropped
   * from the report), and hands the whole thing to the Report Agent to
   * compile. Nothing here scores anything itself; it only assembles what was
   * already evidenced during the interview (soul.md §"No fabrication").
   */
  async generateReport(session: Session): Promise<Report> {
    const questions = await this.deps.questions.listBySession(session.id);
    const transcript: TranscriptEntry[] = [];

    for (const question of questions) {
      const answer = await this.deps.answers.getByQuestion(question.id);
      const evaluations = answer ? await this.deps.evaluations.listByAnswer(answer.id) : [];
      transcript.push({
        question_id: question.id,
        topic: question.topic,
        type: question.type,
        text: question.text,
        answer: answer
          ? { id: answer.id, transcript: answer.transcript, submitted_at: answer.submittedAt }
          : null,
        evaluations: evaluations.map((e) => ({
          rubric_id: e.rubricId,
          score: e.score,
          rationale: e.rationale,
          evidence_spans: e.evidenceSpans,
        })),
      });
    }

    try {
      const round = await this.tools(session.id).call<CodingRoundResult>("coding-agent", "get_round_result", {
        session_id: session.id,
      });

      if (round.result?.evaluation && round.problem) {
        transcript.push({
          question_id: `coding-round:${round.problem_id}`,
          // A fixed label, not one of the resume/role topics: mixing a coding
          // score into a topic like "distributed systems" would blend two
          // different rubrics' signals under one name.
          topic: "coding round",
          type: "coding",
          text: round.problem.statement,
          answer: {
            id: `coding-round:${round.problem_id}`,
            transcript: round.talk_through,
            submitted_at: new Date().toISOString(),
          },
          evaluations: [
            {
              rubric_id: "coding_round_v1",
              score: round.result.evaluation.score,
              rationale: round.result.evaluation.rationale,
              evidence_spans: round.result.evaluation.evidence_spans,
            },
          ],
        });
      }
    } catch (err) {
      // Most sessions never run a coding round at all (soul.md §3: it branches
      // per role) — that is not a report failure.
      if (!(err instanceof McpHandlerError && err.code === "no_active_round")) throw err;
    }

    const result = await this.tools(session.id).call<{
      competency_scores: { competency: string; score: number; evidence: string[] }[];
      strengths: string[];
      focus_areas: string[];
      disclaimer: string;
    }>("report-agent", "generate_report", {
      session_id: session.id,
      candidate_id: session.candidateId,
      transcript,
    });

    return {
      sessionId: session.id,
      candidateId: session.candidateId,
      competencyScores: result.competency_scores.map((c) => ({
        competency: c.competency,
        score: c.score,
        evidence: c.evidence,
      })),
      strengths: result.strengths,
      focusAreas: result.focus_areas,
      // A direct copy of `Session.focusEvents` — never re-derived from
      // telemetry or guessed at, per soul.md §"No fabrication" applied to
      // proctoring signals the same way it applies to scores.
      browserActivity: {
        exitCount: session.focusEvents.length,
        events: session.focusEvents,
        concludedEarly: session.focusEvents.length > MAX_FOCUS_EXITS,
      },
      disclaimer: result.disclaimer,
      createdAt: new Date().toISOString(),
    };
  }
}

/**
 * (Stage 5) The resume-derived lines a generated question must stay consistent
 * with, and the source document its grounding check runs against (§4.3).
 *
 * Built from the stored `candidateProfile` rather than the resume file, so it
 * still works after the raw resume has been hard-deleted (§8).
 */
/**
 * (Stage 6, §12.6) Assembles `LiveSessionState` from pieces that already have
 * exactly one owner each — `Session` (harness), `Question` (Question Agent),
 * `extraction`/`nextAction` (Follow-up Agent, just computed above), and the
 * Time Tracking Tool's own elapsed-time reading. A pure function, not a
 * method: everything it needs is a parameter, nothing is read from `this`, so
 * it composes without adding a second place any of this state could drift.
 */
export function composeLiveSessionState(input: {
  session: Session;
  question: Question;
  extraction: NonNullable<Answer["extraction"]>;
  nextAction: NonNullable<Answer["nextAction"]>;
  score: number | undefined;
  elapsedMs: number;
}): LiveSessionState {
  const { session, question, extraction, nextAction, score, elapsedMs } = input;

  return {
    sessionId: session.id,
    candidateId: session.candidateId,
    activeTopicId: question.topic,
    sessionMetrics: {
      elapsedTimeSeconds: Math.round(elapsedMs / 1000),
      // This turn's score, not a running session-wide average — see the
      // field's doc comment on `LiveSessionState`. Rubric scores are 0-5.
      topicCompetencyScore: score === undefined ? 0 : Math.max(0, Math.min(1, score / 5)),
      currentDemonstratedTier: question.tier ?? 1,
    },
    contextEngine: {
      activeResumeAnchor: resumeAnchorFor(session, question.topic),
      lastDeliveredPrompt: question.text,
    },
    extractionProcessor: extraction,
    nextActionGenerator: nextAction,
  };
}

/**
 * Resolves `dynamicFraming.resumeContextIntegrationRule`
 * (`packages/interview-domain/blueprint.ts`) for one candidate: the
 * highest-relevance `topic_relevance` evidence line for this topic, falling
 * back to a plain statement that the resume gave no evidence for it rather
 * than inventing an anchor (soul.md §"No fabrication").
 */
function resumeAnchorFor(session: Session, topic: string): string {
  const entry = session.candidateProfile?.topicRelevance
    .filter((t) => t.topic === topic)
    .sort((a, b) => b.relevanceScore - a.relevanceScore)[0];
  return entry?.evidence ?? `no resume evidence on file for ${topic}`;
}

function profileLines(session: Session): string[] {
  const profile = session.candidateProfile;
  if (!profile) return [];
  return [
    ...profile.topicRelevance.map((t) => t.evidence),
    ...profile.experience.map((e) => `${e.title} at ${e.company}`),
    ...profile.skills,
  ].filter((line) => line.trim().length > 0);
}

interface TranscriptEntry {
  question_id: string;
  topic: string;
  type: Question["type"];
  text: string;
  answer: { id: string; transcript: string; submitted_at: string } | null;
  evaluations: { rubric_id: string; score: number; rationale: string; evidence_spans: { start: number; end: number }[] }[];
}

interface CodingRoundResult {
  problem_id: string;
  problem: { title: string; statement: string; topics: string[] } | null;
  submissions: number;
  result: {
    evaluation: { score: number; rationale: string; evidence_spans: { start: number; end: number }[] } | null;
  } | null;
  talk_through: string;
}

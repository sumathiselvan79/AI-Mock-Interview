/**
 * Follow-up Question Agent — INSTRUCTIONS.md §4.4.
 *
 * Given an answer, decides whether to probe deeper and writes the probe.
 *
 * Two constraints shape everything here:
 *  - **Never generic.** "A follow-up must target a specific gap or claim in the
 *    answer, never a generic 'tell me more'" (§4.4). Every probe this agent
 *    produces quotes or names something the candidate actually said, and the
 *    `reason` says which gap it is aimed at.
 *  - **Probing, not trapping.** soul.md §3: a good follow-up "makes a strong
 *    candidate demonstrate why they're strong, and gives a struggling candidate
 *    a fair chance to recover". So a thin answer gets an opening, not an
 *    accusation.
 *
 * A low-confidence transcript is never probed (soul.md §5) — the harness must
 * re-prompt or take typed text first.
 */

import {
  McpHandlerError,
  type McpServerHandler,
  type NextActionDirective,
  type ToolClient,
  type ToolClientFactory,
} from "@mia/shared-types";
import { labelFromConceptId } from "@mia/interview-domain";
import { FOLLOW_UP_TOOL, type FollowUpInput } from "@mia/llm-client";

export const SERVER_NAME = "followup-agent";
export const METHODS = ["consider_follow_up", "score_follow_up_exchange"] as const;

export interface FollowupAgentDeps {
  /**
   * (Stage 5) Reaches the Eval Tool for the answer's score and the LLM Provider
   * Tool for the probe itself. Optional: without it this agent is exactly its
   * Stage-2 self, which is also the fallback whenever generation fails.
   */
  toolClient?: ToolClientFactory;
}

export interface AnswerScore {
  rubricId: string;
  value: number;
  rationale: string;
  evidenceSpans: { start: number; end: number }[];
}

/** Below this, the transcript is not reliable enough to reason about. */
export const MIN_CONFIDENCE = 0.6;

export interface FollowUpDecision {
  shouldFollowUp: boolean;
  followUpText?: string;
  reason: string;
  /** (Stage 6, §4.4) The gap detector's full hit list, not just the one it chose to probe. */
  antiPatternsDetected: string[];
}

interface ConceptVerification {
  verified: string[];
  unverified: string[];
}

interface NextActionWire {
  // Never "conclude" here — this agent has no view of the session's question
  // budget, so only the Harness Agent sets that (§4.4).
  system_directive: Exclude<NextActionDirective, "conclude">;
  target_concept_id_for_next_prompt: string | null;
  synthesized_framing_strategy: string;
  generated_follow_up_prompt: string | null;
}

interface Gap {
  id: string;
  reason: string;
  /** Builds the probe from something the candidate actually said. */
  probe: (anchor: string) => string;
}

/**
 * "I <past-tense verb>". `\w+ed` covers the regular cases (raised, traced,
 * migrated) so the agent is not limited to a hand-written verb list that would
 * quietly under-detect real answers; the alternation covers the irregulars.
 */
const FIRST_PERSON_ACTION =
  /\b(?:i|we)\s+(?:\w+ed|built|wrote|led|ran|chose|took|made|set|got|found|split|rewrote|sent|brought|kept|drove|shipped|spent|went|began|broke|caught|dealt|held|left|lost|met|paid|put|read|sold|taught|told|thought|understood|won|dug|rebuilt|undid)\b/i;

const OUTCOME =
  /\b(?:as a result|which meant|the result was|the outcome|the impact|ended up|we went from|reduced|increased|improved|cut|saved)\b/i;

const METRIC = /\b\d+(?:\.\d+)?\s?(?:%|percent|x|ms|s\b|seconds|minutes|hours|days|weeks|months|k\b|m\b|users|requests|rps|qps)/i;

const TRADEOFF =
  /\b(?:tradeoff|trade-off|instead of|rather than|the alternative|we considered|the downside|the drawback|because)\b/i;

const HEDGE = /\b(?:kind of|sort of|i guess|probably|maybe|i think|something like|or whatever|roughly)\b/i;

const TEAM_CREDIT = /\bwe\b/i;

/**
 * Ordered by what an interviewer would probe first: a claim with no owner, then
 * a claim with no result, then a decision with no reasoning.
 */
const GAPS: readonly Gap[] = [
  {
    id: "no_personal_action",
    reason: "the answer describes what happened but not what the candidate personally did",
    probe: (anchor) =>
      `You described ${anchor} — what was your own part in that? Walk me through what you specifically did.`,
  },
  {
    id: "team_without_self",
    reason: "the answer is framed entirely as team work, so the candidate's own contribution is unclear",
    probe: (anchor) =>
      `You said "${anchor}" — where did your work end and the rest of the team's begin?`,
  },
  {
    id: "no_outcome",
    reason: "the answer describes actions but never says how it turned out",
    probe: (anchor) => `After ${anchor}, how did it turn out? What changed once it was in place?`,
  },
  {
    id: "unquantified_claim",
    reason: "the answer claims an improvement without any measure of it",
    probe: (anchor) =>
      `You mentioned ${anchor} — do you remember roughly what it was before and after? Even a ballpark is fine.`,
  },
  {
    id: "no_reasoning",
    reason: "the answer states a decision without the reasoning or the alternatives behind it",
    probe: (anchor) => `Why ${anchor} rather than another approach? What else was on the table?`,
  },
  {
    id: "hedged_claim",
    reason: "a key part of the answer is hedged, so it is unclear what the candidate actually knows",
    probe: (anchor) =>
      `You said "${anchor}" — can you pin that down a bit? I'd rather hear what you're sure of than a guess.`,
  },
];

export function createFollowupAgentServer(deps: FollowupAgentDeps = {}): McpServerHandler {
  return {
    name: SERVER_NAME,
    async call(method: string, params: unknown): Promise<unknown> {
      switch (method) {
        case "consider_follow_up":
          return considerFollowUpCall(deps, params as ConsiderParams);
        case "score_follow_up_exchange":
          return scoreFollowUpExchange(deps, params as ScoreExchangeParams);
        default:
          throw new McpHandlerError("unknown_method", `${SERVER_NAME} has no method ${method}`);
      }
    },
  };
}

interface ConsiderParams {
  session_id?: string;
  question: string;
  answer_id?: string;
  answer_transcript: string;
  transcript_confidence?: number;
  reference_answer?: string;
  /** The prompt version that produced `reference_answer` (§6). */
  prompt_version?: string;
  rubric_id?: string;
  /** (Stage 6, §4.4) The triggering question's tier and target concepts. */
  tier?: number;
  target_concept_ids?: string[];
}

interface ScoreExchangeParams {
  session_id: string;
  question: string;
  follow_up_text: string;
  follow_up_transcript: string;
  rubric_id?: string;
  reference_answer?: string;
}

/**
 * (Stage 5, §4.4/§11.2) Score first, then decide.
 *
 * The order matters and is not an implementation detail: scoring at follow-up
 * time rather than at REPORT_GENERATION is what leaves a dropped session with
 * scored answers on record. The score MAY inform the decision — a shaky answer
 * is a reason to give the candidate a chance to recover — but per
 * soul.md §"Scoring the answer doesn't change why the follow-up gets asked", a
 * high score never suppresses a follow-up a specific gap warrants, and the
 * probe is never phrased as a verdict on the score.
 */
async function considerFollowUpCall(deps: FollowupAgentDeps, p: ConsiderParams) {
  const tools = deps.toolClient && p.session_id ? deps.toolClient(p.session_id, SERVER_NAME) : null;

  // 1. The deterministic gap detector, unchanged from Stage 2. It is what
  //    decides *whether* there is something specific to probe; the model only
  //    gets to phrase it.
  const decision = considerFollowUp({
    question: p.question,
    answerTranscript: p.answer_transcript,
    ...(p.transcript_confidence === undefined ? {} : { transcriptConfidence: p.transcript_confidence }),
  });

  // 2. Score the triggering answer, persisted immediately as an `Evaluation`
  //    because `answer_id` is supplied (§5.2, §11.2). A low-confidence
  //    transcript is never scored — the Eval Tool refuses, and that refusal is
  //    surfaced rather than swallowed (soul.md §5).
  const scored = tools ? await scoreAnswer(tools, p) : null;
  const score = scored?.score ?? null;

  // 3. Phrase the probe. Grounding requires `targeted_gap.evidence` to be a
  //    verbatim slice of the answer, which is what stops a generated probe from
  //    being a generic "tell me more" wearing a specific-sounding sentence.
  const generated =
    tools && decision.shouldFollowUp ? await generateProbe(tools, p, decision) : null;

  const shouldFollowUp = generated ? generated.should_follow_up : decision.shouldFollowUp;
  const followUpText = generated?.follow_up_text ?? decision.followUpText;

  // 4. (Stage 6, §4.4) Concept verification, against this question's own
  //    target concepts — never withheld from a strong answer and never run for
  //    its own sake; it feeds directly into the next-action decision below.
  const verification =
    tools && p.target_concept_ids && p.target_concept_ids.length > 0
      ? await verifyConcepts(tools, p.answer_transcript, p.target_concept_ids)
      : null;

  const nextAction = computeNextAction({
    shouldFollowUp,
    followUpText,
    reason: generated?.reason ?? decision.reason,
    verification,
    tier: p.tier,
  });

  return {
    should_follow_up: shouldFollowUp,
    ...(shouldFollowUp && followUpText ? { follow_up_text: followUpText } : {}),
    reason: generated?.reason ?? decision.reason,
    anti_patterns_detected: decision.antiPatternsDetected,
    next_action: nextAction,
    ...(verification ? { verified_concept_ids: verification.verified, unverified_concept_ids: verification.unverified } : {}),
    ...(score ? { score: toWireScore(score) } : {}),
    // The Eval Tool's own words, not a paraphrase of them. "12 words is too
    // little to score against behavioral_v1" tells the candidate something
    // actionable; "declined to score" tells them nothing (soul.md §6).
    ...(scored?.note ? { score_note: scored.note } : {}),
  };
}

/**
 * (Stage 6, §4.4) Deterministic, same as everything else this agent decides
 * for itself — the LLM call above only phrases the probe, never whether to
 * escalate, pivot, or drill down.
 */
function computeNextAction(input: {
  shouldFollowUp: boolean;
  followUpText?: string;
  reason: string;
  verification: ConceptVerification | null;
  tier?: number;
}): NextActionWire {
  if (input.shouldFollowUp) {
    return {
      system_directive: "drill_down",
      target_concept_id_for_next_prompt: input.verification?.unverified[0] ?? null,
      synthesized_framing_strategy: `Target the detected gap (${input.reason}) with a probe anchored in what the candidate actually said — never a generic "tell me more".`,
      generated_follow_up_prompt: input.followUpText ?? null,
    };
  }

  const coverage = input.verification;
  const tierCovered = coverage !== null && coverage.verified.length > 0 && coverage.unverified.length === 0;

  if (tierCovered && input.tier !== undefined && input.tier < 3) {
    return {
      system_directive: "escalate",
      target_concept_id_for_next_prompt: null,
      synthesized_framing_strategy: `This topic's tier ${input.tier} concepts are covered; frame the topic's next question at tier ${input.tier + 1}, anchored in a fresh resume or JD context rather than repeating what was just covered.`,
      generated_follow_up_prompt: null,
    };
  }

  return {
    system_directive: "pivot",
    target_concept_id_for_next_prompt: coverage?.unverified[0] ?? null,
    synthesized_framing_strategy:
      "No specific gap to probe and nothing to escalate into right now; move to the next question in the plan.",
    generated_follow_up_prompt: null,
  };
}

/**
 * (Stage 6, §4.4) Concept ids carry no label of their own on the wire — see
 * `labelFromConceptId` — so the Eval Tool's term-matching runs against the
 * best-effort label reconstructed from the id.
 */
async function verifyConcepts(
  tools: ToolClient,
  transcript: string,
  conceptIds: string[],
): Promise<ConceptVerification | null> {
  try {
    const result = await tools.call<{ verified_concept_ids: string[]; unverified_concept_ids: string[] }>(
      "tool-eval",
      "verify_concepts",
      {
        answer_transcript: transcript,
        concepts: conceptIds.map((id) => ({ id, label: labelFromConceptId(id) })),
      },
    );
    return { verified: result.verified_concept_ids, unverified: result.unverified_concept_ids };
  } catch {
    // Verification is an enrichment, not a gate — losing it must not lose the
    // follow-up decision itself.
    return null;
  }
}

/**
 * (Stage 5, §4.4) Scores an answered follow-up.
 *
 * Deliberately does NOT create a second top-level `Evaluation`: a follow-up is
 * a sub-unit of the answer it belongs to, and `evaluations.evidence_spans`
 * already means "indices into `answers.transcript`" for every existing consumer
 * of that table (§11.7). The score is written onto `answers.follow_ups[i]` by
 * the harness instead, where its spans index into THIS follow-up's transcript.
 */
async function scoreFollowUpExchange(deps: FollowupAgentDeps, p: ScoreExchangeParams) {
  if (!deps.toolClient) {
    throw new McpHandlerError(
      "eval_unavailable",
      `${SERVER_NAME} was constructed without a tool client; it cannot reach the Eval Tool`,
    );
  }

  const tools = deps.toolClient(p.session_id, SERVER_NAME);
  try {
    const scored = await tools.call<{
      score: number;
      rationale: string;
      evidence_spans: { start: number; end: number }[];
    }>("tool-eval", "evaluate_answer", {
      rubric_id: p.rubric_id ?? "behavioral_v1",
      // No `answer_id`: passing one would persist a top-level Evaluation, which
      // is exactly what §11.2 says not to do for a follow-up exchange.
      question: p.follow_up_text,
      answer_transcript: p.follow_up_transcript,
      ...(p.reference_answer ? { reference_answer: p.reference_answer } : {}),
    });

    return {
      scored: true,
      score: {
        rubric_id: p.rubric_id ?? "behavioral_v1",
        value: scored.score,
        rationale: scored.rationale,
        evidence_spans: scored.evidence_spans,
      },
    };
  } catch (err) {
    // `insufficient_transcript` is a normal outcome for a one-line follow-up
    // answer. Reported plainly, never as a quietly invented low score.
    return { scored: false, note: (err as Error).message };
  }
}

/**
 * Returns the score, or the Eval Tool's own reason for refusing one. Both are
 * normal outcomes — a thin or low-confidence transcript is refused rather than
 * given a quietly invented low score (§5.2, soul.md §"No fabrication").
 */
async function scoreAnswer(
  tools: ToolClient,
  p: ConsiderParams,
): Promise<{ score: AnswerScore | null; note?: string } | null> {
  if (!p.answer_id) return null;
  try {
    const scored = await tools.call<{
      score: number;
      rationale: string;
      evidence_spans: { start: number; end: number }[];
    }>("tool-eval", "evaluate_answer", {
      rubric_id: p.rubric_id ?? "behavioral_v1",
      answer_id: p.answer_id,
      question: p.question,
      answer_transcript: p.answer_transcript,
      ...(p.transcript_confidence === undefined ? {} : { transcript_confidence: p.transcript_confidence }),
      ...(p.reference_answer ? { reference_answer: p.reference_answer } : {}),
      ...(p.prompt_version ? { prompt_version: p.prompt_version } : {}),
    });
    return {
      score: {
        rubricId: p.rubric_id ?? "behavioral_v1",
        value: scored.score,
        rationale: scored.rationale,
        evidenceSpans: scored.evidence_spans,
      },
    };
  } catch (err) {
    return { score: null, note: (err as Error).message };
  }
}

async function generateProbe(
  tools: ToolClient,
  p: ConsiderParams,
  decision: FollowUpDecision,
): Promise<{ should_follow_up: boolean; follow_up_text?: string; reason: string } | null> {
  const promptInput: FollowUpInput = {
    question: p.question,
    answer_transcript: p.answer_transcript,
    baseline: {
      should_follow_up: decision.shouldFollowUp,
      ...(decision.followUpText ? { follow_up_text: decision.followUpText } : {}),
      reason: decision.reason,
    },
  };

  try {
    const generated = await tools.call<{
      output: { should_follow_up: boolean; follow_up_text?: string; reason: string } | null;
    }>("tool-llm-provider", "generate_structured", {
      session_id: p.session_id ?? "",
      tool_name: FOLLOW_UP_TOOL.name,
      prompt_version: FOLLOW_UP_TOOL.promptVersion,
      schema_ref: FOLLOW_UP_TOOL.schemaRef,
      input: promptInput,
      // The answer itself is the only admissible source for a probe's target.
      source_documents: [p.answer_transcript],
    });
    return generated.output;
  } catch {
    // Provider unavailable, or no schema-valid response after the retry: the
    // Stage-2 probe is already specific and already quotes the candidate.
    return null;
  }
}

function toWireScore(score: AnswerScore) {
  return {
    rubric_id: score.rubricId,
    value: score.value,
    rationale: score.rationale,
    evidence_spans: score.evidenceSpans,
  };
}

export function considerFollowUp(input: {
  question: string;
  answerTranscript: string;
  transcriptConfidence?: number;
}): FollowUpDecision {
  const transcript = (input.answerTranscript ?? "").trim();

  if (input.transcriptConfidence !== undefined && input.transcriptConfidence < MIN_CONFIDENCE) {
    return {
      shouldFollowUp: false,
      reason: `transcript confidence ${input.transcriptConfidence} is below ${MIN_CONFIDENCE}; the harness should re-prompt or take typed text rather than probe a guess`,
      antiPatternsDetected: ["low_confidence_transcript"],
    };
  }

  const words = transcript.split(/\s+/).filter(Boolean);

  // A near-empty answer is not a gap to probe — it is a candidate who needs a
  // way in. Give them the question back with a concrete starting point.
  if (words.length < 15) {
    return {
      shouldFollowUp: true,
      followUpText:
        "Let's take that one from a specific angle: think of one time this came up for you, and start with what the situation was.",
      reason: "answer too short to contain a claim to probe; offering a concrete way in instead",
      antiPatternsDetected: ["too_short_to_probe"],
    };
  }

  const sentences = transcript
    .split(/(?<=[.!?])\s+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 0);

  const hasAction = FIRST_PERSON_ACTION.test(transcript);
  const hasOutcome = OUTCOME.test(transcript);
  const hasMetric = METRIC.test(transcript);
  const hasReasoning = TRADEOFF.test(transcript);
  const hedge = HEDGE.exec(transcript);

  const detected: { gap: Gap; anchor: string }[] = [];

  if (!hasAction && TEAM_CREDIT.test(transcript)) {
    detected.push({ gap: gap("team_without_self"), anchor: clause(sentences, TEAM_CREDIT) });
  } else if (!hasAction) {
    detected.push({ gap: gap("no_personal_action"), anchor: subjectOf(sentences[0] ?? transcript) });
  }
  if (hasAction && !hasOutcome) {
    detected.push({ gap: gap("no_outcome"), anchor: subjectOf(clause(sentences, FIRST_PERSON_ACTION)) });
  }
  if (hasOutcome && !hasMetric) {
    detected.push({ gap: gap("unquantified_claim"), anchor: subjectOf(clause(sentences, OUTCOME)) });
  }
  if (!hasReasoning) {
    detected.push({ gap: gap("no_reasoning"), anchor: subjectOf(sentences[0] ?? transcript) });
  }
  if (hedge?.[0]) {
    detected.push({ gap: gap("hedged_claim"), anchor: clause(sentences, HEDGE) });
  }

  const first = detected[0];
  if (!first) {
    return {
      shouldFollowUp: false,
      reason:
        "the answer already covers a specific situation, the candidate's own actions, the outcome and the reasoning — there is no gap worth probing",
      antiPatternsDetected: [],
    };
  }

  return {
    shouldFollowUp: true,
    followUpText: first.gap.probe(first.anchor),
    reason: first.gap.reason,
    antiPatternsDetected: detected.map((d) => d.gap.id),
  };
}

function gap(id: string): Gap {
  const found = GAPS.find((g) => g.id === id);
  if (!found) throw new Error(`unknown gap ${id}`);
  return found;
}

/** The sentence a pattern matched in, trimmed to something quotable. */
function clause(sentences: string[], pattern: RegExp): string {
  const sentence = sentences.find((s) => pattern.test(s)) ?? sentences[0] ?? "";
  return truncate(sentence, 90);
}

/** Turns a sentence into a phrase that reads naturally after "You described …". */
function subjectOf(sentence: string): string {
  const cleaned = sentence
    .replace(/^(so|well|basically|yeah|um|uh|okay|right)[,\s]+/i, "")
    .replace(/^(i|we)\s+/i, "")
    .replace(/[.!?]+$/, "")
    .trim();
  return truncate(cleaned || sentence, 90);
}

function truncate(text: string, max: number): string {
  return text.length <= max ? text : `${text.slice(0, max).trimEnd()}…`;
}

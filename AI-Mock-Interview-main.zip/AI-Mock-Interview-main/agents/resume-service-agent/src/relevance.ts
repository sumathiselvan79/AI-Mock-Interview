/**
 * Topic relevance and JD fit.
 *
 * The one rule that governs this whole file (INSTRUCTIONS.md §4.2, soul.md
 * §"No fabrication"): every score must be traceable to specific parsed text.
 * So `evidence` is always a verbatim line from the resume — never a summary,
 * never an inference from a job title. If no line supports a topic, the topic
 * gets no relevance entry at all, and the Question Agent will pick it up as a
 * role requirement instead if the role demands it.
 */

import { TOPICS, termPattern, type TopicDefinition } from "@mia/interview-domain";
import type { JdFit, TopicRelevance } from "@mia/shared-types";

export interface TopicMatch {
  topic: string;
  relevanceScore: number;
  evidence: string;
  matchedTerms: string[];
}

/** Lines mentioning a topic's terms, with the terms that matched. */
function matchesFor(topic: TopicDefinition, lines: string[]): { line: string; terms: string[] }[] {
  const out: { line: string; terms: string[] }[] = [];
  for (const line of lines) {
    const terms = topic.terms.filter((term) => termPattern(term).test(line));
    if (terms.length > 0) out.push({ line, terms });
  }
  return out;
}

/**
 * Relevance rises with how many distinct terms appear and across how many
 * lines, and saturates — a resume that says "Kubernetes" nine times is not
 * three times as relevant as one that says it three times.
 */
function scoreFor(distinctTerms: number, matchedLines: number): number {
  const termComponent = Math.min(1, distinctTerms / 4) * 0.6;
  const spreadComponent = Math.min(1, matchedLines / 3) * 0.4;
  return Math.round((termComponent + spreadComponent) * 100) / 100;
}

export function computeTopicRelevance(lines: string[]): TopicRelevance[] {
  const out: TopicRelevance[] = [];

  for (const topic of TOPICS) {
    const matches = matchesFor(topic, lines);
    if (matches.length === 0) continue;

    const distinctTerms = new Set(matches.flatMap((m) => m.terms)).size;
    // The evidence line is the one that matched the most terms — the strongest
    // single piece of support, quoted exactly as it appears.
    const best = [...matches].sort((a, b) => b.terms.length - a.terms.length)[0];

    out.push({
      topic: topic.topic,
      relevanceScore: scoreFor(distinctTerms, matches.length),
      evidence: (best as { line: string }).line,
    });
  }

  return out.sort((a, b) => b.relevanceScore - a.relevanceScore);
}

/**
 * Splits a job description into requirement-shaped statements: bullets, or
 * sentences that read like a demand ("must have", "experience with", "you will").
 */
export function extractRequirements(jobDescription: string): string[] {
  const lines = jobDescription
    .replace(/\r\n?/g, "\n")
    .split(/\n|(?<=[.;])\s+(?=[A-Z])/)
    .map((line) => line.replace(/^[\s•·▪◦*\-–]+/, "").trim())
    .filter((line) => line.length >= 12 && line.length <= 300);

  // Prefix-matching on purpose: a JD says "Familiarity", "proficiency" and
  // "requirements" as often as the bare stems, and an anchored \b after each
  // stem would miss every one of them.
  const REQUIREMENT =
    /\b(?:experience|proficien\w*|familiar\w*|knowledge|expertise|must have|should have|require\w*|responsible for|you will|ability to|strong|deep|background in|own\w*|build\w*|design\w*|maintain\w*|lead\w*|mentor\w*|plus\b)/i;

  const seen = new Set<string>();
  return lines.filter((line) => {
    if (!REQUIREMENT.test(line)) return false;
    const key = line.toLowerCase();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

/**
 * A requirement counts as matched when the resume shows evidence for a topic
 * the requirement is about, or repeats the requirement's own distinctive terms.
 * Everything else is a gap — and gaps become interview topics rather than
 * disqualifications (soul.md §"JD-fit is informational, not a gate").
 */
export function computeJdFit(
  jobDescription: string,
  lines: string[],
  topicRelevance: TopicRelevance[],
): JdFit {
  const requirements = extractRequirements(jobDescription);
  if (requirements.length === 0) {
    return { fitScore: 0, matchedRequirements: [], gaps: [] };
  }

  const supportedTopics = new Set(
    topicRelevance.filter((t) => t.relevanceScore >= 0.3).map((t) => t.topic),
  );
  const resumeText = lines.join("\n");

  const matched: string[] = [];
  const gaps: string[] = [];

  for (const requirement of requirements) {
    const topicsInRequirement = TOPICS.filter((topic) =>
      topic.terms.some((term) => termPattern(term).test(requirement)),
    );

    const topicSupported = topicsInRequirement.some((topic) => supportedTopics.has(topic.topic));

    // Fall back to the requirement's own content words when it maps to no known
    // topic — a JD can ask for something the topic vocabulary doesn't cover.
    const contentWords = requirement
      .toLowerCase()
      .split(/[^a-z0-9+#.]+/)
      .filter((word) => word.length >= 5);
    const wordSupport =
      contentWords.length > 0 &&
      contentWords.filter((word) => termPattern(word).test(resumeText)).length / contentWords.length >= 0.5;

    if (topicSupported || wordSupport) matched.push(requirement);
    else gaps.push(requirement);
  }

  return {
    fitScore: Math.round((matched.length / requirements.length) * 100) / 100,
    matchedRequirements: matched,
    gaps,
  };
}

/**
 * The topics a JD demands that the resume gives no evidence for. These become
 * `required_topics` for the topic plan (§4.3) — "a thin resume in a required
 * area is a reason to ask about it, not to skip it".
 */
export function gapTopics(gaps: string[], topicRelevance: TopicRelevance[]): string[] {
  const supported = new Set(topicRelevance.filter((t) => t.relevanceScore >= 0.3).map((t) => t.topic));
  const out = new Set<string>();
  for (const gap of gaps) {
    for (const topic of TOPICS) {
      if (supported.has(topic.topic)) continue;
      if (topic.terms.some((term) => termPattern(term).test(gap))) out.add(topic.topic);
    }
  }
  return [...out];
}

export function estimateSeniority(
  experience: { title: string; company: string; years: number }[],
  lines: string[],
): "junior" | "mid" | "senior" | "staff+" {
  const text = lines.join(" ").toLowerCase();
  if (/\b(staff|principal|distinguished|head of|vp of) engineer|architect\b/.test(text)) return "staff+";

  const totalYears = experience.reduce((sum, e) => sum + e.years, 0);
  const titles = experience.map((e) => e.title.toLowerCase()).join(" ");

  if (/\b(senior|sr\.?|lead|manager)\b/.test(titles) || totalYears >= 7) return "senior";
  if (totalYears >= 3) return "mid";
  return "junior";
}

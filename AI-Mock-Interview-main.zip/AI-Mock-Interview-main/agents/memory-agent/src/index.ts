/**
 * Memory Agent — INSTRUCTIONS.md §4.7.
 *
 * Session-scoped working memory: what has been asked, and the running per-topic
 * counts against the session's topic plan. The Harness Agent reads
 * `topic_counts` from here and passes it to the Question Agent on every
 * `get_next_question` call — the Question Agent never queries this agent
 * directly.
 *
 * Counts are *derived* from the persisted questions rather than kept in a
 * separate counter. A counter can drift from what was actually asked; a
 * derivation cannot, and it survives a restart mid-session for free.
 *
 * Cross-session recall is opt-in at the account level and returns only what a
 * candidate would expect it to remember — previously asked questions, so the
 * next session does not repeat them (soul.md §5).
 */

import {
  McpHandlerError,
  type McpServerHandler,
  type QuestionStore,
  type SessionScratchStore,
  type SessionStore,
} from "@mia/shared-types";

export const SERVER_NAME = "memory-agent";
export const METHODS = [
  "get_session_context",
  "record_question_asked",
  "get_prior_context",
  // (Stage 5) Session-scoped, non-durable working memory — §4.7.
  "remember_reference_answer",
  "get_reference_answer",
  "remember_jd_fit_draft",
  "get_jd_fit_draft",
  "forget_session",
] as const;

/**
 * (Stage 5) Scratch keys. Namespaced so `forget_session` is one operation and
 * nothing has to enumerate what a session might be holding.
 */
const REFERENCE_ANSWER_KEY = (questionId: string): string => `reference-answer:${questionId}`;
const JD_FIT_DRAFT_KEY = "jd-fit-draft";

export interface SessionContext {
  askedQuestionIds: string[];
  topicCounts: Record<string, number>;
  /** (Stage 6, §4.3) Tier of the last question asked in each topic. Absent topics start at tier 1. */
  topicTier: Record<string, number>;
  questionsAsked: number;
}

export interface MemoryAgentDeps {
  questions: QuestionStore;
  sessions: SessionStore;
  /** Cross-session recall is gated on this being true for the account. */
  crossSessionOptIn(candidateId: string): Promise<boolean>;
  /**
   * (Stage 5) Ephemeral, session-scoped store (§4.7). Optional so a Stage 2
   * style Memory Agent can still be constructed; the Stage 5 methods refuse
   * rather than silently no-op without it.
   */
  scratch?: SessionScratchStore;
}

/**
 * (Stage 5) What the Resume Service Agent parks here mid-CONFIG so a resume
 * replace that did not actually change the resume can reuse the generated
 * fields instead of paying for another LLM call (§4.7).
 */
export interface JdFitDraft {
  /** Identifies the resume the draft was generated from. */
  resumeFingerprint: string;
  jdFit: Record<string, unknown>;
}

export function createMemoryAgentServer(deps: MemoryAgentDeps): McpServerHandler {
  return {
    name: SERVER_NAME,
    async call(method: string, params: unknown): Promise<unknown> {
      const p = (params ?? {}) as { session_id?: string; candidate_id?: string };

      switch (method) {
        case "get_session_context": {
          const context = await getSessionContext(deps, p.session_id as string);
          return {
            session_context: {
              asked_question_ids: context.askedQuestionIds,
              topic_counts: context.topicCounts,
              topic_tier: context.topicTier,
              questions_asked: context.questionsAsked,
            },
          };
        }

        case "record_question_asked": {
          // The question is persisted by the harness as it is asked, so the
          // count derives itself. This method stays in the contract as the
          // explicit signal (§4.7) and returns the freshly derived counts.
          const context = await getSessionContext(deps, p.session_id as string);
          return {
            recorded: true,
            topic_counts: context.topicCounts,
          };
        }

        case "get_prior_context": {
          return getPriorContext(deps, p.candidate_id as string);
        }

        // ------------------------------------------- (Stage 5) working memory

        case "remember_reference_answer": {
          const q = params as { session_id: string; question_id: string; reference_answer: string };
          await scratch(deps).setSessionScratch(
            q.session_id,
            REFERENCE_ANSWER_KEY(q.question_id),
            q.reference_answer,
          );
          return { remembered: true };
        }

        case "get_reference_answer": {
          const q = params as { session_id: string; question_id: string };
          const answer = await scratch(deps).getSessionScratch<string>(
            q.session_id,
            REFERENCE_ANSWER_KEY(q.question_id),
          );
          // Absent is a normal outcome, not an error: a question generated on
          // the deterministic bank path has no reference answer, and the
          // Follow-up Agent has to score without one (§4.3).
          return answer === null ? { found: false } : { found: true, reference_answer: answer };
        }

        case "remember_jd_fit_draft": {
          const q = params as { session_id: string; resume_fingerprint: string; jd_fit: Record<string, unknown> };
          await scratch(deps).setSessionScratch(q.session_id, JD_FIT_DRAFT_KEY, {
            resumeFingerprint: q.resume_fingerprint,
            jdFit: q.jd_fit,
          } satisfies JdFitDraft);
          return { remembered: true };
        }

        case "get_jd_fit_draft": {
          const q = params as { session_id: string; resume_fingerprint: string };
          const draft = await scratch(deps).getSessionScratch<JdFitDraft>(q.session_id, JD_FIT_DRAFT_KEY);
          // A draft for a *different* resume is not a hit. Returning it would
          // attach one resume's generated rationale to another's parse, which
          // is fabrication however cheap it is (soul.md §"No fabrication").
          return draft && draft.resumeFingerprint === q.resume_fingerprint
            ? { found: true, jd_fit: draft.jdFit }
            : { found: false };
        }

        case "forget_session": {
          const q = params as { session_id: string };
          await scratch(deps).clearSessionScratch(q.session_id);
          return { forgotten: true };
        }

        default:
          throw new McpHandlerError("unknown_method", `${SERVER_NAME} has no method ${method}`);
      }
    },
  };
}

/**
 * (Stage 5) The scratch store, or a plain refusal. Silently no-opping would let
 * a reference answer look remembered and come back empty at scoring time.
 */
function scratch(deps: MemoryAgentDeps): SessionScratchStore {
  if (!deps.scratch) {
    throw new McpHandlerError(
      "scratch_unavailable",
      `${SERVER_NAME} was constructed without a session-scoped store; §4.7 working memory is unavailable`,
    );
  }
  return deps.scratch;
}

export async function getSessionContext(
  deps: MemoryAgentDeps,
  sessionId: string,
): Promise<SessionContext> {
  const asked = await deps.questions.listBySession(sessionId);
  const topicCounts: Record<string, number> = {};
  // (Stage 6, §4.3) Derived like `topicCounts`: the tier of the LAST question
  // asked in a topic, read straight off the persisted questions rather than a
  // separate counter that could drift.
  const topicTier: Record<string, number> = {};
  for (const question of asked) {
    topicCounts[question.topic] = (topicCounts[question.topic] ?? 0) + 1;
    if (question.tier !== undefined) topicTier[question.topic] = question.tier;
  }
  return {
    askedQuestionIds: asked.map((q) => q.bankId),
    topicCounts,
    topicTier,
    questionsAsked: asked.length,
  };
}

/**
 * Opt-in only. Without consent this returns nothing at all — not a redacted
 * shape, not an empty-but-present object with counts in it.
 */
export async function getPriorContext(
  deps: MemoryAgentDeps,
  candidateId: string,
): Promise<{ opted_in: boolean; previously_asked_question_ids?: string[]; sessions_seen?: number }> {
  if (!(await deps.crossSessionOptIn(candidateId))) {
    return { opted_in: false };
  }

  const sessions = await deps.sessions.listByCandidate(candidateId);
  const previouslyAsked = new Set<string>();
  for (const session of sessions) {
    for (const question of await deps.questions.listBySession(session.id)) {
      previouslyAsked.add(question.bankId);
    }
  }

  return {
    opted_in: true,
    previously_asked_question_ids: [...previouslyAsked],
    sessions_seen: sessions.length,
  };
}

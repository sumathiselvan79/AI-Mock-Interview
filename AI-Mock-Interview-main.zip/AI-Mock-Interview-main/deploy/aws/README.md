# AWS deployment (single EC2 host, Docker Compose)

Region `ap-southeast-2`, profile `varun-kumar`. One `m7i-flex.large` runs web,
backend, Postgres, Redis and Caddy (automatic HTTPS). No SSH: use SSM.

| Resource | Name |
|---|---|
| EC2 instance | `mia-app` (id in `aws ec2 describe-instances --filters Name=tag:Name,Values=mia-app`) |
| Elastic IP | 13.54.189.166 |
| URLs | `https://app.13-54-189-166.sslip.io` (web), `https://api.13-54-189-166.sslip.io` (API) |
| S3 bucket (source tarball, bootstrap script) | `mia-deploy-727266258830-apse2` |
| Secret (prod env + DB password) | Secrets Manager `mia/prod-env` |
| IAM | role/instance profile `mia-ec2-role` / `mia-ec2-profile` |
| Security group | `mia-web` (80/443 only) |

Every command below assumes `export AWS_PROFILE=varun-kumar AWS_REGION=ap-southeast-2`
and a current login (`aws login --profile varun-kumar`, valid 12h).

## Redeploy after a code change
```bash
# from the repo root: package the source (no node_modules, .venv, .env, big models)
tar czf /tmp/src.tgz --exclude=node_modules --exclude=.venv --exclude=.git --exclude=.next \
  --exclude=__pycache__ --exclude='*.pyc' --exclude='*.log' --exclude='*.egg-info' \
  --exclude=.env --exclude='.env.*' --exclude=uploads --exclude='models/sherpa-onnx-whisper-*' \
  --exclude='*.tsbuildinfo' --exclude=tests \
  package.json package-lock.json apps agents packages mcp-servers backend deploy models
aws s3 cp /tmp/src.tgz s3://mia-deploy-727266258830-apse2/src.tgz
IID=$(aws ec2 describe-instances --filters Name=tag:Name,Values=mia-app Name=instance-state-name,Values=running --query 'Reservations[0].Instances[0].InstanceId' --output text)
aws s3 cp deploy/aws/bootstrap.sh s3://mia-deploy-727266258830-apse2/bootstrap.sh
aws ssm send-command --instance-ids $IID --document-name AWS-RunShellScript --timeout-seconds 3000 --parameters \
 'commands=["export DEPLOY_BUCKET=mia-deploy-727266258830-apse2 AWS_REGION=ap-southeast-2","aws s3 cp s3://mia-deploy-727266258830-apse2/bootstrap.sh /tmp/bootstrap.sh","nohup bash /tmp/bootstrap.sh > /var/log/mia-deploy.log 2>&1 &"]'
```

## Logs / shell on the instance
```bash
aws ssm start-session --target $IID        # needs the Session Manager plugin
# on the instance:
cd /opt/mia/src && sudo docker compose -f deploy/aws/docker-compose.prod.yml --env-file /opt/mia/host.env logs -f backend
```

## Change a secret / env value
Edit the JSON in Secrets Manager (`prod.env` and `host.env` keys), then redeploy as above.

## Save credit: stop / start
```bash
aws ec2 stop-instances --instance-ids $IID     # compute billing stops; disk + Elastic IP still bill
aws ec2 start-instances --instance-ids $IID    # containers restart on their own (restart: unless-stopped)
```

## Tear everything down
```bash
aws ec2 terminate-instances --instance-ids $IID
aws ec2 release-address --allocation-id eipalloc-0d7c79c69ec253e60   # after the instance is gone
aws secretsmanager delete-secret --secret-id mia/prod-env --force-delete-without-recovery
aws s3 rb s3://mia-deploy-727266258830-apse2 --force
aws iam remove-role-from-instance-profile --instance-profile-name mia-ec2-profile --role-name mia-ec2-role
aws iam delete-instance-profile --instance-profile-name mia-ec2-profile
aws iam delete-role-policy --role-name mia-ec2-role --policy-name mia-deploy-read
aws iam detach-role-policy --role-name mia-ec2-role --policy-arn arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore
aws iam delete-role --role-name mia-ec2-role
aws ec2 delete-security-group --group-id sg-0e7ce63cb20b669fd
```

# Production-readiness audit: test results and bug audit

Date: 2026-11-06. Scope: the repo as of `9ffc500` plus the uncommitted working tree. Nothing on AWS or prod was touched, and no source file was edited.
Evidence tags follow OPS_NOTES: **REPRODUCED** (I watched it happen locally), **CODE-READ**, **SUSPECTED**.
Scratch dir for all runs (venvs, logs, repro scripts):
`/tmp/claude-1000/-run-media-varun-New-Volume-Projects-Mock-Interview-AI/79fb14dd-8638-4b26-b472-cd221db8982e/scratchpad`
(abbreviated `$S` below). The repro scripts are `$S/repro/restart_midinterview.py` and `$S/repro/prehijack.py`.

---

## Part A: test results

### A.1 Backend (Python, fixture mode, no LLM keys)

Environment:
```bash
uv venv $S/venv --python 3.12
VIRTUAL_ENV=$S/venv uv pip install -e "backend[speech,llm,dev]"      # resolves latest: sherpa-onnx 2.0.1, PyJWT 2.15.1
# each smoke script runs under a scrubbed env (no keys, repo .env not loaded by the smoke scripts):
env -i PATH="$S/venv/bin:<node 26.8.1 bin>:/usr/bin:/bin" HOME=$HOME PYTHONDONTWRITEBYTECODE=1 \
    $S/venv/bin/python tests/<smoke>.py            # cwd = backend/
env -i ... $S/venv/bin/python -m pytest -p no:cacheprovider -q            # cwd = backend/
```
The `smoke_stage*.py` files are **scripts, not pytest tests**. They run at import time, have no `test_` functions, and do not match pytest's default `test_*.py` pattern. A plain `pytest` therefore collects only `test_stt_pipeline.py`, so I ran each smoke script directly, as their docstrings instruct.

| Suite | Latest deps (`$S/venv`) | Result | Notes |
|---|---|---|---|
| smoke_stage1 | 21 OK | PASS | |
| smoke_stage2_resume | 27 OK | PASS | |
| smoke_stage3_question_loop | 49 OK | PASS | |
| smoke_stage_admin | 85 OK | PASS | |
| smoke_stage_coding | 14 OK | PASS | real Node 26.8.1 sandbox |
| smoke_stage_continuers | 68 OK | PASS | |
| smoke_stage_dynamic_eval | 36 OK | PASS | |
| smoke_stage_dynamic_routing | 110 OK | PASS | |
| smoke_stage_human_flow | 86 OK | PASS | |
| smoke_stage_live_channel | 11 OK | PASS | |
| smoke_stage_llm | 18 OK | PASS | |
| smoke_stage_voice_http | 14 OK | PASS | |
| **smoke_stage_google_oauth** | 6 OK, then FAIL | **FAIL (dep drift)** | `AssertionError: callback redirects on success: 400 {"error":{"code":"invalid_id_token","message":"could not decode Google ID token"}}` |
| **smoke_stage_voice** | 7 OK, then FAIL | **FAIL (dep drift, real prod risk)** | `sherpa-onnx ... phoneme_codepoints is empty, no lexicon, and no frontend available` then `ZeroDivisionError: division by zero` at `backend/app/tools/speech_service/sherpa_provider.py:166` |
| **smoke_stage_whisper_stt** | 38 OK, then FAIL | **FAIL (same TTS cause)** | the end-to-end step synthesises with TTS first: same `ZeroDivisionError` |
| **smoke_stage_postgres** | 0 OK | **FAIL (env)** | `OSError: Connect call failed ('127.0.0.1', 5432)`: no Postgres running |
| pytest (`test_stt_pipeline.py`) | 9 passed | PASS | `pytest` with no args gives the same 9 |

**Fixing the environment, and the cause of each failure:**
- **Postgres (environment).** I started scratch `postgres:16-alpine` (port 55432) and `redis:7-alpine` (port 56379), then ran `python -m app.storage.migrate`, which applied 001–008. After that, `smoke_stage_postgres` gives **33 OK, PASS** on both the latest and the pinned venv. Containers removed afterwards.
- **TTS (real dependency regression).** `pyproject.toml` declares `sherpa-onnx>=1.10`, which resolves to **2.0.1** today. The 2.x Piper/VITS path no longer synthesises with the repo's `espeak-ng-data` layout. It returns zero samples, and `sherpa_provider.py:166` then divides by `sample_rate == 0`. I rebuilt in `$S/venv2` pinned to the versions in the repo's (Windows) `.venv`: `sherpa-onnx==1.13.6`, `pyjwt==2.13.0`. Results: **voice 10 OK PASS, whisper_stt 44 OK PASS**. REPRODUCED.
- **Google OAuth (test-fixture breakage, not prod).** PyJWT 2.15.1 now base64-checks the signature segment even with `verify_signature=False`. The test's fake token ends in `.fake-signature`, which is invalid base64 (`DecodeError: Invalid crypto padding`). Real Google tokens have valid signatures, so login itself is unaffected. With PyJWT 2.13.0: **16 OK, PASS**. REPRODUCED.

**Backend totals.**
- Latest deps, no DB: 12/16 smoke scripts pass, plus pytest 9/9.
- Latest deps with scratch Postgres/Redis: 13/16 pass. The 3 failures are all dependency drift.
- Pinned deps (sherpa-onnx 1.13.6, PyJWT 2.13.0) with scratch Postgres/Redis: **16/16 smoke scripts pass, 642 OK assertions, plus pytest 9/9.**

The prod image builds with the same unpinned `pip install -e ".[speech,llm]"` (`deploy/aws/backend.Dockerfile:177`). **The next rebuild ships broken TTS** (see P1-2).

### A.2 Web (`apps/web`)

| Check | Command | Result |
|---|---|---|
| Typecheck | `npx tsc -p apps/web/tsconfig.json --noEmit` (repo root) | **PASS** (exit 0, no diagnostics). `tsconfig.tsbuildinfo` restored afterwards. |
| Vitest, in place | `npx vitest run apps/web/tests` (repo root) | **ENV FAIL**: `Cannot start service: Host version "0.21.5" does not match binary version "0.28.1"`. The repo's `node_modules` has a mismatched esbuild binary (mixed Windows/Linux installs). |
| Vitest, clean copy | copied the workspace (no `node_modules`) to `$S/webcopy`; `npm ci --workspace @mia/web --include-workspace-root`; `npx vitest run apps/web/tests` | **PASS: 2 files, 21 tests** (room-turns 10, live-protocol 11) |
| Prod build | `$S/webcopy`: `NEXT_PUBLIC_GATEWAY_URL=https://api.example.test NODE_ENV=production npm run build --workspace @mia/web` | **PASS**: Next 15.5.22, compiled in 7.8s, lint and type checks passed, 13 static pages, 16 routes |

Notes:
- npm 11.19 now **blocks install scripts by default** (`npm warn install-scripts esbuild@0.21.5 (postinstall)`). The build and tests still pass because esbuild/swc ship platform binaries as optional deps. Keep this in mind if a dependency that needs a postinstall (for example `sharp`) is added; `npm ci` in `web.Dockerfile` will not run it.
- **Local Node is 26.8.1**, below the `>= 26.12.1` floor the Dockerfiles cite (CVE-2026-111497, Brotli decoder RCE). That is fine for offline tests, but don't use it to serve anything. `/usr/bin/node` on this machine is 26.12.0; the mise one on PATH is 26.8.1.
- Side effect: the editable install regenerated the gitignored `backend/mia_backend.egg-info/`. No tracked file changed.

---

## Part B: bug audit, ranked

| # | Sev | Finding | Evidence | Patch design | Effort |
|---|---|---|---|---|---|
| 1 | **P0** | **Account pre-hijack escalates to admin.** `/auth/register` doesn't verify email ownership. A later Google login for the same email goes through `upsert_identity`, which only updates `role` (`ON CONFLICT (email) DO UPDATE SET role = EXCLUDED.role`) and **keeps the attacker's passcode hash**. Anyone who registers an allowlisted admin email before the admin first signs in gets an admin passcode login. The same path lets anyone pre-claim any student's account. | **REPRODUCED** `$S/repro/prehijack.py`: register `boss@example.com` (student), then admin signs in with Google (302), then attacker `/auth/login` with own passcode gives **200, role admin**, then `/admin/users` **200**. Code: `backend/app/storage/postgres.py:255-268`, `backend/app/auth/service.py:134-175`, `backend/app/http/routes/auth.py:21-54`. | (a) When an identity login lands on an existing row whose passcode was never verified, **reset `passcode_hash` to an unusable random hash** (or invalidate it) and bump a `token_version`. (b) Never let `upsert_identity` raise a row to `admin` while it still holds a client-chosen passcode; require Google for admin login (reject passcode login when `role='admin'`). (c) Longer term, add email verification for passcode signups. Add a regression check to `smoke_stage_google_oauth.py`. | S |
| 2 | **P0** | **Coding sandbox: any self-registered student can kill the backend and exhaust host memory.** The `vm` context leaks outer-realm objects, so `Object.constructor("return process")()` returns the real `process`. From there: `process.kill(process.ppid, "SIGTERM")` stops uvicorn (in the container it is PID 1 with a SIGTERM handler). That drops every live session; `restart: unless-stopped` brings it back with every open WebSocket gone. `new Uint8Array(...)` is off-heap, so `--max-old-space-size=128` doesn't cap it: 6 × 256 MB = 1.5 GB allocated fine, on a host shared with Postgres. There is no concurrency cap on submissions. **What it cannot reach today (verified on Node 26.8.1 and 26.12.0):** env (scrubbed to `NODE_ENV`), filesystem (permission model gives `ERR_ACCESS_DENIED`), network (`net.connect`, `dns`, `dgram` all `ERR_ACCESS_DENIED`; the bootstrap's comment that "the permission model does not cover the network" is out of date for Node ≥25). The only boundary between candidate code and the container that holds every secret is Node's permission model, which Node's docs say is not a defence against malicious code. Beyond that sits IMDS, which serves the `mia-ec2-role` credentials that can read Secrets Manager `mia/prod-env`. `os.networkInterfaces()` and `process.getBuiltinModule` are also reachable. | **REPRODUCED** with the shipped `sandbox-bootstrap.cjs` and the same flags as `runner.py:92-107`: escape to `process`; `getBuiltinModule("net")` resolves; `kill(ppid,0)` ok; real SIGTERM delivered to a Python parent (`$S/sbx/parent.py`, output `parent received: ['SIGTERM']`); 1.5 GB off-heap with a 128 MB heap cap. Code: `backend/app/agents/coding/runner.py:84-143`, `agents/coding-agent/src/sandbox-bootstrap.cjs:96-131`. | **Today:** a feature flag (sketch below) to turn the round off in prod. **Real fix:** a separate, locked-down `sandbox` container (sketch below): no secrets, no egress, its own PID namespace and uid, cgroup memory/pids/CPU caps, read-only rootfs, one Node child per run. The backend calls it over an internal-only network. Also add an `asyncio.Semaphore` on concurrent runs, and set the EC2 IMDS hop limit to 1 so no container can reach IMDS. | flag: S; container: M |
| 3 | **P0** | **No backups of anything durable.** `pgdata`, `uploads` and `caddy_data` are local docker volumes on one EBS root volume. Nothing dumps or snapshots them. Terminating the instance, a volume failure, or a bad `docker compose down -v` loses every account, report and resume. | **CODE-READ** `deploy/aws/docker-compose.prod.yml:67-68,95-96,130-134`; `bootstrap.sh` has no backup step. | Nightly `pg_dump -Fc` via a systemd timer, piped to `aws s3 cp` into a versioned bucket with a lifecycle rule. Needs `s3:PutObject` on a `backups/` prefix added to the instance role (an AWS change, for the owner to make). Add a Data Lifecycle Manager daily EBS snapshot as a second layer. Test a restore once. | S |
| 4 | **P1** | **A Redis restart permanently breaks every in-flight interview.** The MCP session token, device check, scratch and timers live only in Redis (`--save "" --appendonly no`). After any Redis restart (instance reboot, the README's **stop/start credit-saving workflow**, a container recreate, OOM), every MCP call for an existing session fails, and there is no recovery path. A plain **backend** restart is fine over REST: `active_sessions` rebuilds from Postgres as designed. | **REPRODUCED** `$S/repro/restart_midinterview.py` on real PG+Redis: before restart the answer gives 201; after a backend restart (new app, `active_sessions` cleared) next question 200 and answer 201; after a Redis flush, next question gives **502 `{"code":"unauthorized","message":"invalid or missing session token for this MCP call"}`** on every call. Code: `backend/app/mcp/gateway.py:88`, `backend/app/http/routes/sessions.py:89-90`, `backend/app/storage/redis_store.py:70-74`, compose `:79`. | (a) Turn on AOF: `redis-server --appendonly yes --appendfsync everysec` with a `redisdata` volume. (b) Make the session token re-derivable: `_ToolClient.call` re-mints and re-stores it when the key is missing and the session is non-terminal (it is an HMAC of `session_id` and a nonce, so persist the nonce in the `sessions` row). Do the same for `get_device_check`: fall back to a persisted `telemetry_check_passed` column. | S–M |
| 5 | **P1** | **Unpinned Python deps: the next image rebuild ships broken TTS.** `sherpa-onnx>=1.10` resolves to 2.0.1, which returns zero samples, and every `synthesize_speech` call then raises `ZeroDivisionError`. There is no lockfile. spaCy's model, faster-whisper and LangChain all float as well. The deployed image may predate 2.0.1; that can't be checked without touching prod. | **REPRODUCED** (Part A.1). `backend/pyproject.toml:24-31`, `deploy/aws/backend.Dockerfile:177-179`, `sherpa_provider.py:156-167`. | Commit a `uv.lock` (or `requirements.lock` with hashes) and install from it in the Dockerfile. For now pin `sherpa-onnx>=1.10,<2`. Add a build-time smoke step (`RUN python -c "...synthesize('Ready.')..."`) so a broken voice fails the build, not the interview. Guard `sample_rate == 0` / empty samples as `SynthesisFailed`. Update the google-oauth test fixture to emit a valid base64 signature segment. | S |
| 6 | **P1** | **Bearer tokens are written to the container logs.** The room opens `wss://.../sessions/<id>/live?token=<bearer>` and uvicorn's access log prints the full query string. Every live session's 1-hour admin/student token ends up in `docker logs` / json-log files. | **REPRODUCED**: local uvicorn in `NODE_ENV=production`, then log line `"WebSocket /sessions/abc/live?token=SECRET-BEARER-TOKEN-VALUE" [accepted]`. Code: `apps/web/app/interview/[id]/room/page.tsx:450`, `backend/app/http/live_channel.py:339`. | Fastest: run uvicorn with `--no-access-log` and rely on Caddy access logs, which redact query strings with a `log` + `format filter` on `request>uri`. Better: have the client send the token as the first WS message (or as `Sec-WebSocket-Protocol`), or exchange it for a 30-second single-use ticket via `POST /sessions/:id/live-ticket`. | S |
| 7 | **P1** | **Docker logs are never rotated.** There's no `/etc/docker/daemon.json` and no `logging:` options, so json-file grows without bound on the 40 GB root disk shared with `pgdata`. When the disk fills, Postgres stops accepting writes. | **CODE-READ** `bootstrap.sh` (no daemon config), compose (no `logging:`). Scanner traffic like `/storage/logs/laravel.log` adds to it (each probe is one 404 access-log line, REPRODUCED locally). | In `bootstrap.sh`, before starting Docker: `{"log-driver":"local","log-opts":{"max-size":"20m","max-file":"5"}}` in `/etc/docker/daemon.json`, then `systemctl restart docker`. Or add an `x-logging` anchor to every service in compose. | XS |
| 8 | **P1** | **Every redeploy silently stalls live interviews, with downtime and no health gating.** `up -d` recreates backend and web. The room has **no `onclose`/reconnect handler**, and `send()` silently drops messages when the socket isn't open, so a candidate mid-answer submits and waits on "thinking" forever until they reload. Caddy `depends_on` web/backend without `condition: service_healthy`, web has **no healthcheck**, and there is no health-aware upstream. Result: 502s until the backend loads spaCy/Whisper (start-period 60s). The on-host `docker compose build` (Next build and pip) also competes with live traffic for the 2 vCPUs for several minutes. | **CODE-READ** `apps/web/app/interview/[id]/room/page.tsx:276-281,451` (no close handler), compose `:103-128`, `bootstrap.sh:48-51`. Downtime size: SUSPECTED, not measured on prod. | Client: add `socket.onclose`/`onerror` that shows "Connection lost, reconnecting…" and reconnects with backoff, re-requesting `next_question` (the server is already reload-safe over REST). Compose: web healthcheck (`node -e "fetch('http://127.0.0.1:3000').then(r=>process.exit(r.ok?0:1))"`), caddy `depends_on: {backend: {condition: service_healthy}, web: {condition: service_healthy}}`, and Caddy `reverse_proxy { health_uri /health  lb_try_duration 30s }` so requests are held instead of 502'd during a swap. Pipeline: build images off-box (CI, push to ECR, or `docker save` to S3), only `pull` and `up` on the host, and deploy outside interview hours. | M |
| 9 | **P1** | **No rate limiting on auth.** `/auth/login`, `/auth/register` and `/auth/reset-passcode/request` are unthrottled, which allows passcode brute force (8-char minimum) and mass signups. Every new account can then run the sandbox (#2). | **REPRODUCED**: 12 consecutive bad logins, all 401, never 429. `backend/app/http/routes/auth.py`; the only limiter is per-session MCP (`mcp/gateway.py:118-127`). | Redis fixed-window limiter keyed by `ip` and by `email` (for example 10/min/IP and 5/15min/email for login, 5/hour/IP for register). Run uvicorn with `--proxy-headers --forwarded-allow-ips=<caddy net>` so the client IP is real. Optionally Caddy `rate_limit` (needs a plugin build) as an outer layer. | S |
| 10 | **P1** | **Config fails open on a single mistyped or missing variable.** Every safety gate keys on `NODE_ENV == "production"` exactly. If it is missing or misspelled (`prod`, `Production`), you get dev-login (any email, allowlist-resolved role, so instant admin) if `ALLOW_DEV_AUTH=true` is present; `/internal/mcp`; `CORS *` with credentials; and the `dev-only-insecure-secret` HMAC key if the secret is also missing. Separately, `STORAGE_DRIVER` defaults to **memory**. A prod env without it boots fine on in-memory stores, the migration still succeeds against Postgres, and everything is lost on restart. `FRONTEND_URL` defaults to `http://localhost:3000`, which would silently CORS-block the real app. | **REPRODUCED**: uvicorn with `NODE_ENV=production STORAGE_DRIVER=memory` booted without a warning. **CODE-READ** `backend/app/config.py:128-173`, `gateway.py:355,387,422,448`. The current prod values can't be verified without reading secrets (OPS_NOTES says `NODE_ENV=production` is set). Check `GET /health`: `"storage"` must be `"postgres"`. | In `load_config`: allow only `NODE_ENV ∈ {development,test,production}` and raise otherwise. In production, **require** `STORAGE_DRIVER=postgres`, a non-default `FRONTEND_URL` (https), non-empty `DATABASE_URL`/`REDIS_URL`, and raise if `ALLOW_DEV_AUTH` is set at all. Fail at boot, not at first request. | XS |
| 11 | **P1** | **Passcode reset doesn't work in production.** The only `ResetMailer` is `MemoryResetMailer`, which appends tokens to an in-process list. The user is told to check their email and nothing arrives; the list also grows without bound from an unauthenticated endpoint. | **CODE-READ** `backend/app/auth/service.py:37-52`, `gateway.py:186`; there is no other mailer class anywhere in `backend/app`. | Implement an SES mailer (AWS-native and cheap; needs a verified sender, which is an owner action). Until then, hide "forgot passcode" in prod and fail startup if `NODE_ENV=production` and the mailer is the memory one. | S |
| 12 | P2 | **Supabase archive and OAuth profile snapshots aren't wired.** `archives=None`, `oauth_profiles=None` always; `_archive_session` is a no-op. `SUPABASE_DB_URL` (a service-role credential) is read but never used, so admin `/admin/archives*` always reports "not configured", and holding the secret only adds exposure. CLAUDE.md §6 describes both as live. | **CODE-READ** `backend/app/storage/__init__.py:92-100`, `agents/harness/harness.py:363-372`. | Either remove `SUPABASE_DB_URL` from prod.env until F12 lands, or port the store. Update the docs either way. | S / M |
| 13 | P2 | **PII in logs (beyond #6).** Redaction is key-based plus 200-char truncation, so values under other keys leak up to 200 chars: `unhandled_error.message=str(err)` (asyncpg messages include row values such as emails), `live_socket_error`, `oauth_profile_snapshot_failed.error`. Uvicorn also logs the Google callback's `?code=&state=`. The logger also keeps **every line forever** in `Logger._lines`, a slow memory leak. | **CODE-READ** `backend/app/logging_.py:51-63,75-90`, `gateway.py:109-111`, `live_channel.py:362`, `auth/service.py:162-164`. | Log `type(err).__name__` and an error code instead of `str(err)` in those three places. Make `_lines` a `collections.deque(maxlen=1000)` (or keep it only when `node_env == "test"`). | XS |
| 14 | P2 | **Unpinned and unverified supply chain in the pipeline.** `caddy:2`, `postgres:16-alpine`, `redis:7-alpine`, `python:3.12-slim` are floating tags. docker-compose and buildx come from GitHub `releases/latest` with **no checksum**, as root. `node:26.13.0-slim` is pinned by tag but not digest. A redeploy can change behaviour with no code change. | **CODE-READ** `bootstrap.sh:20-28`, compose `:61,76,114`, `backend.Dockerfile:154-156`, `web.Dockerfile:199`. | Pin compose/buildx to explicit versions and verify `sha256sum -c` against the release checksums. Pin images by `tag@sha256:digest` and bump them on purpose (Renovate/Dependabot). | S |
| 15 | P2 | **Host config isn't reboot-safe.** Swap (`fallocate` + `swapon`) isn't added to `/etc/fstab`, so after a reboot the 8 GB host runs Whisper, Postgres, Next and the sandbox with no swap. `systemctl enable docker` only runs on the first-install branch (fine on AL2023, where Docker isn't preinstalled; fragile on another AMI). `jq` is only installed on that branch too. `rm -rf /opt/mia/src` before the build leaves the bind-mounted `Caddyfile` pointing at a deleted inode until Caddy is recreated. | **CODE-READ** `bootstrap.sh:12-15,31-33,37`. | `grep -q /swapfile /etc/fstab \|\| echo '/swapfile none swap sw 0 0' >> /etc/fstab`; always run `dnf install -y jq` and `systemctl enable --now docker`. Extract to `/opt/mia/releases/<ts>` and switch a symlink, keeping the previous release for rollback. | XS |
| 16 | P2 | **No security headers, and API docs are public.** No HSTS, CSP, `X-Frame-Options`/`frame-ancestors`, `X-Content-Type-Options` or `Referrer-Policy`, and Next sends `X-Powered-By`. Bearer tokens live in `sessionStorage`, so an XSS means account takeover and CSP matters. FastAPI `/docs` and `/openapi.json` are served in production. | **REPRODUCED** locally: `/docs` 200, `/openapi.json` 200 with `NODE_ENV=production`; `/health` headers show none of the above. **CODE-READ** `Caddyfile`, `apps/web/next.config.mjs`, `gateway.py:358`. | Caddy `header { Strict-Transport-Security "max-age=31536000" X-Content-Type-Options nosniff Referrer-Policy strict-origin-when-cross-origin X-Frame-Options DENY -Server }`, and a CSP on `app.*` (`connect-src 'self' https://api.* wss://api.*; media-src blob: https://api.*`). `FastAPI(docs_url=None, redoc_url=None, openapi_url=None)` in production. `poweredByHeader: false` in Next. | S |
| 17 | P2 | **Scanner traffic** (`/storage/logs/laravel.log`, `/.env`, `/wp-login.php`…) reaches uvicorn and is logged. It is harmless (404), but it's noise in the logs and the only thing in front is Caddy, which has no filtering. | **REPRODUCED** locally: 404 plus an access-log line. | Caddy: `@scanners path *.php /.env* /.git/* /wp-* /storage/logs/* /vendor/*` then `abort @scanners` on both hosts. Pair with log rotation (#7). | XS |
| 18 | P2 | **Retention gaps.** Resumes are deleted and transcripts redacted only inside report generation. Abandoned sessions (never reaching `REPORT_GENERATION`) keep the resume file on the `uploads` volume and the full transcripts indefinitely, and no retention job exists in `backend/`. | **CODE-READ** `agents/harness/harness.py:344-351`; `grep retention` finds no job. | A daily job (systemd timer: `docker compose run --rm backend python -m app.jobs.retention`) that applies the same delete/redact rules to sessions idle for more than N days. | S |
| 19 | P2 | **Web image hygiene.** It copies every workspace including the frozen TS gateway and agents, installs dev deps, and runs `npm run start` as PID 1 (npm forwards SIGTERM poorly, so a ~10s kill on every deploy). `.next` is root-owned while the process runs as `node`, so Next's cache writes fail. | **CODE-READ** `deploy/aws/web.Dockerfile`. | Next `output: "standalone"`, a multi-stage build that copies `.next/standalone` + `.next/static`, `CMD ["node","apps/web/server.js"]`, `chown node` the cache dir, and `init: true` in compose. | S |
| 20 | P2 | **The test gate doesn't run itself.** `pytest` collects 9 tests; the 16 smoke scripts (642 assertions) only run by hand. The local `node_modules` esbuild mismatch breaks `npm test` on this machine. | **REPRODUCED** (Part A). | A `tests/test_smoke_scripts.py` that runs each script with `runpy`, as a subprocess with the scrubbed env, marked `postgres` where needed. Run in CI on Linux with `npm ci`. | XS |

### Sandbox fix: concrete sketches

**Step 1 (same day): turn the round off in prod.**
```python
# backend/app/config.py
coding_round_enabled: bool = True
...
coding_round_enabled=env.get("CODING_ROUND_ENABLED", "false" if node_env == "production" else "true").lower() == "true",

# backend/app/agents/harness/harness.py, where QUESTION_LOOP completes (around :288)
if not self._config.coding_round_enabled:
    return await self.transition(session_id, "WRAP_UP", "coding_round_disabled")

# backend/app/http/routes/voice.py:205,219 and live_channel.py:296
if not config.coding_round_enabled:
    raise HttpError(404, "coding_round_disabled", "the coding round is not available")
# and register create_coding_agent_server only when enabled (gateway.py:337)
```

**Step 2: separate sandbox container (no secrets, no egress, own PID namespace and uid, cgroup caps).**
```yaml
# deploy/aws/docker-compose.prod.yml (additions)
networks:
  default: {}                  # backend, postgres, redis, web, caddy (unchanged)
  sandbox_net:
    internal: true             # no route out: no internet, no IMDS (169.254.169.254)

services:
  sandbox:
    build: { context: ../.., dockerfile: deploy/aws/sandbox.Dockerfile }
    restart: unless-stopped
    networks: [sandbox_net]    # NOT on default: cannot reach postgres/redis
    user: "65534:65534"
    read_only: true
    tmpfs: ["/tmp:size=16m,noexec"]
    cap_drop: [ALL]
    security_opt: ["no-new-privileges:true"]
    pids_limit: 64
    mem_limit: 768m            # caps the off-heap bomb for the whole container
    memswap_limit: 768m
    cpus: 1.0
    init: true
    environment: { SANDBOX_MAX_CONCURRENT: "2" }   # no env_file: no secrets exist here
    healthcheck: { test: ["CMD","node","-e","fetch('http://127.0.0.1:7070/health').then(r=>process.exit(r.ok?0:1))"], interval: 10s }

  backend:
    networks: [default, sandbox_net]
    environment:
      SANDBOX_URL: http://sandbox:7070
```
```dockerfile
# deploy/aws/sandbox.Dockerfile
FROM node:26.13.0-slim
WORKDIR /sandbox
COPY agents/coding-agent/src/sandbox-bootstrap.cjs agents/coding-agent/src/sandbox-server.cjs ./
USER 65534:65534
CMD ["node", "sandbox-server.cjs"]
```
```js
// agents/coding-agent/src/sandbox-server.cjs  (sketch: about 50 lines)
// POST /run {code, entryPoint, testCases} -> spawns ONE child per request:
//   node --permission --allow-fs-read=<bootstrap> --max-old-space-size=128 bootstrap.cjs
// with env {NODE_ENV:"sandbox"}, detached:true, a 5s timer that does process.kill(-child.pid,"SIGKILL"),
// a semaphore of SANDBOX_MAX_CONCURRENT (429 when full), 64 KB body cap, 2 MB stdout cap,
// and returns the child's sentinel-framed stdout verbatim. A child that kills its parent
// now only kills this server (restarted by compose), never the backend.
```
```python
# backend/app/agents/coding/runner.py: keep the signature; swap the transport when SANDBOX_URL is set
async def run_in_sandbox(*, code, entry_point, test_cases, timeout_ms=DEFAULT_TIMEOUT_MS, heap_mb=DEFAULT_HEAP_MB):
    url = os.environ.get("SANDBOX_URL")
    if not url:
        return await _run_local(...)            # today's code path, dev only
    async with httpx.AsyncClient(timeout=timeout_ms / 1000 + 2) as client:
        r = await client.post(f"{url}/run", json=request)
    if r.status_code == 429:
        return RunOutcome(ok=False, error={"type": "busy", "message": "the sandbox is busy, try again"})
    return _parse_result(r.text) or RunOutcome(ok=False, error={"type": "crashed", "message": "sandbox returned no result"})
# in production, refuse _run_local (raise at startup if NODE_ENV=production and SANDBOX_URL is unset)
```
Also remove `node` from `backend.Dockerfile` (lines 154, 167-168) once the sandbox container exists. Keep the in-bootstrap layers; they become defence in depth. Independently, ask the account owner to set the instance's IMDS `HttpPutResponseHopLimit=1` (an AWS change, not made here). With that, no container can fetch the role credentials even if network egress is ever opened.

### Things checked and found OK
- `_sandbox_env()` really does scrub the environment. Node 26's permission model really denies fs and net (REPRODUCED).
- `ALLOW_DEV_AUTH` is double-gated (`config.py:165`, `gateway.py:422`). `AUTH_TOKEN_SECRET` has a ≥32-char check in production (`config.py:131`). Roles never come from the client or Google (`auth/roles.py`). Login is constant-time against a dummy hash (`auth/service.py:111-116`).
- A backend restart alone doesn't lose interview state over REST: `active_sessions` is rebuilt from Postgres (REPRODUCED, #4).
- Backend container runs as uid 10001 with a healthcheck. `prod.env`/`host.env` are written with `umask 077`. Migrations run before `up -d`, and a failed build leaves the old containers serving (`set -e`).

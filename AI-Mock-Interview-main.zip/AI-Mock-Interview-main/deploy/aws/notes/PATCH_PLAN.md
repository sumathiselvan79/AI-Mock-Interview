# Production patch plan (2026-11-06)

Sources: `notes/e2e.md` (live journey, LLM), `notes/cors.md` (cross-origin), `notes/audit.md` (tests, readiness).
Each item cites its source note, which has the evidence and `file:line`. Order matters: later phases assume earlier ones.

## Phase 0: stopgaps on the live system (no code change)
| ID | Action | Why |
|---|---|---|
| S1 | Empty `ADMIN_EMAIL_ALLOWLIST` in secret `mia/prod-env`, restart backend. Read-only check: count accounts on allowlisted emails (counts only). | Account takeover to admin is live (audit P0-1) |
| S2 | Set `CODING_ROUND_ENABLED=false` once the flag exists (Phase 1). Until then, accept the risk: the UI never calls the coding routes (e2e #7), but the API does. | Sandbox escape kills the backend (audit P0-2) |

## Phase 1: security (blocks everything else)
| ID | Fix | Source |
|---|---|---|
| A1 | Google login promoting a row to admin must not keep a passcode the Google user didn't set. On a role change to admin in `upsert_identity` (`storage/postgres.py:255-268`, plus the memory store twin), overwrite `passcode_hash` with an unusable one. Regression test: register the allowlisted email with a passcode, sign in via Google, and the old passcode must fail. | audit P0-1 |
| A2 | `CODING_ROUND_ENABLED` flag (default false in production): the routes return 404/feature_disabled. Separate no-egress sandbox container = follow-up ticket. | audit P0-2 |
| A3 | Bearer token out of logs: run uvicorn with `--no-access-log` or a query-string-redacting access-log filter. Longer term, move the WS token from `?token=` to the first message or a subprotocol. | cors #3, e2e #4, audit P1 |
| A4 | `NODE_ENV` must be `production` or `development` (or `test`); anything else fails at boot. Dev CORS uses an explicit origin list, not `*` with credentials. | cors #4 |
| A5 | Rate limit `/auth/login`, `/auth/register` and the reset routes (per IP and per email, Redis-backed). | audit P1 |
| A6 | Production refuses to boot on `STORAGE_DRIVER=memory` or a missing `FRONTEND_URL`/`AUTH_TOKEN_SECRET` (fail closed). | audit P1, cors #5 |

## Phase 2: correctness
| ID | Fix | Source |
|---|---|---|
| C1 | **Pin Python dependencies** with a lock file (e.g. `uv pip compile` → `backend/requirements.lock`) installed by the Dockerfile; `sherpa-onnx<1.13`. Matches the versions that pass all 642 checks. | e2e #1, audit P1 |
| C2 | TTS warm-up failure must surface: `/health` reports `speech.tts: degraded`, and the log line is an error, not a swallow. | e2e #1 |
| C3 | TTS-unavailable notice must not be a WS `error` frame on every question (`live_channel.py:207`): send it once per session as a non-error notice. | e2e #5 |
| C4 | JD-fit LLM output fails validation 3/3; the suspected cause is the prompt offering 40 topics against a schema capped at 12 (`schemas.py:77`). **First capture the real validation error** (see E1), then fix the prompt/schema. A fallback must not report `fit_score: 1.0` as if assessed. | e2e #2 |
| C5 | Follow-up LLM fails validation 7/8: capture the error (E1), then fix. Template fallback: add `ms`/`milliseconds` and other units to `METRIC_RE` (`interview_domain/signals.py:37`), fix the "context on For caching" grammar, and extend `smoke_stage_human_flow.py` adversarial cases first (CLAUDE.md §17). | e2e #3 |
| C6 | Grade band from the displayed, rounded score, not the raw one (`tools/eval/grading.py:127-131`): "2.5 · D" next to "2.5 · C". | e2e #6 |
| C7 | Groq: a 30 s timeout plus a fallback call made a 45 s turn. Set a tighter per-call timeout and one bounded retry. | e2e #8 |
| C8 | CORS: register `_BodySizeLimitMiddleware` inside `CORSMiddleware` so a 413 carries the header (`gateway.py:382-396`). Invalid UTF-8 JSON → 400, not 500. Regression test with an `Origin` header. | cors #1, #5 |
| C9 | Caddy `handle_errors` for the API host adds CORS headers to 502/503/504; `api.ts` maps network errors to `ApiCallError` with a "service unavailable" message. | cors #2 |
| C10 | A Redis restart breaks every in-progress interview (502 on each call): degrade to "session expired, start again" (or rebuild from Postgres). | audit P1 |

## Phase 3: ops and pipeline
| ID | Fix | Source |
|---|---|---|
| O1 | Docker log rotation (`/etc/docker/daemon.json`: `max-size 10m`, `max-file 5`). | audit P1 |
| O2 | Backups: nightly `pg_dump` + uploads tarball to S3 (systemd timer); 14-day S3 lifecycle. AWS Backup for EBS if it's available on the plan. | audit P0-3 |
| O3 | Pin image tags (caddy, postgres, redis) and the compose/buildx versions with checksums; persist swap in `/etc/fstab`. | audit P2 |
| O4 | Web healthcheck; caddy `depends_on: condition: service_healthy`; build new images *before* stopping the old ones (`build` then `up -d`, which bootstrap already does), and document the expected seconds of downtime. | audit P1 |
| O5 | Security headers in Caddy (HSTS, nosniff, frame-ancestors, referrer-policy); disable FastAPI `/docs` and `/openapi.json` in production. | audit P2 |
| O6 | **Post-deploy gate**: bootstrap ends by running `deploy/aws/smoke_prod.py --strict`. Deploy is "done" only when it passes. | new |

## Phase 4: environment (pit of success)
| ID | Change |
|---|---|
| E1 | LLM validation failures and fallbacks emit a structured log line (call name, prompt version, error class/path; no prompt or answer text, per CLAUDE.md §8). Today a fallback leaves no trace outside `tool_called` rows. |
| E2 | `pytest` must collect the smoke scripts (today plain `pytest` collects 1 of 17 files, so a green run means nothing). Add a `conftest.py` or a `backend/tests/run_all.py` with one exit code. |
| E3 | One command for the full local gate: backend smokes + web typecheck + vitest + `next build`. Document it in `deploy/aws/OPS_NOTES.md`. |

## Deferred (product work, not blocking this deploy)
- Coding round UI is not wired in the web app (e2e #7). Feature work; keep the flag off until the sandbox container exists.
- Passcode reset never emails (audit P1): needs SES (on the Free-plan list) plus a verified sender.
- Separate no-egress sandbox container (audit P0-2, real fix).
- WebSocket reconnect in the room after a redeploy (audit P1).

## Final test run (after Phase 1-3 are deployed)
`backend` full smoke gate (E2) + web gate (E3) locally, then the redeploy, then
`uv run --with httpx --with websockets deploy/aws/smoke_prod.py --strict --answer-wav deploy/aws/notes/fixtures/answer16k.wav`
→ must be 0 FAIL and 0 WARN, with TTS audio present and JD-fit/follow-up answered by the LLM. Then delete the `smoketest+` users.

# Security fixes: A1, A2, A4 (config side), A5, A6

Date: 2026-11-06. Working tree only, nothing committed, nothing on AWS touched.
Evidence tags as in OPS_NOTES: REPRODUCED / CODE-READ / SUSPECTED.
Scratch dir `$S` = `/tmp/claude-1000/-run-media-varun-New-Volume-Projects-Mock-Interview-AI/79fb14dd-8638-4b26-b472-cd221db8982e/scratchpad`
(logs in `$S/impl-sec/`).

## Files changed (all inside my ownership set)
| File | What |
|---|---|
| `backend/app/storage/postgres.py:255-279` | A1: `upsert_identity` ON CONFLICT also sets `passcode_hash = EXCLUDED.passcode_hash` (`:270`) |
| `backend/app/storage/memory.py:120-131` | A1: memory twin replaces `passcode_hash` on the existing-row branch (`:128`) |
| `backend/app/storage/types.py:48-60` | A1: protocol docstring now states the new contract |
| `backend/app/auth/service.py:140-146` | A1: comment only (the random unusable hash is now written on both branches) |
| `backend/app/config.py` | A2/A4/A5/A6: new fields `:79-96`, helpers `_bool :125`, `_origin :138`, `_cidrs :162`, `_storage_driver :177`, `load_config :188-277` |
| `backend/app/http/rate_limit.py` (new) | A5: policies `:52`, `client_ip :76`, `enforce_auth_rate_limit :110` |
| `backend/app/http/routes/auth.py:30,65,77,87` | A5: limiter called in register, login, reset request, reset confirm |
| `backend/app/http/routes/voice.py:48-53,216-217,231-232` | A2: `coding_round_disabled()` 404 on both coding routes |
| `backend/app/http/live_channel.py:311-315` | A2: `submit_code` WS message answers an `error` frame `coding_round_disabled` (edited with a scoped replace; the C3 `notices_sent` edits another agent made in the same file are intact) |
| `backend/tests/smoke_stage_security.py` (new) | memory-driver checks for all five items |
| `backend/tests/smoke_stage_security_postgres.py` (new) | A1 + A5 against real Postgres + Redis |

## A1: pre-hijack escalation (audit P0-1)
**Change.** On an identity login (Google, dev-login) that lands on an existing row, the row's
`passcode_hash` is replaced with a hash of a discarded random value, in both stores. I went wider
than the plan's "on a role change to admin": the audit shows the same path pre-claims any
student, and the store cannot tell an attacker's passcode from the owner's because `/auth/register`
never verifies the email. The Google login is the first proof of ownership, so any earlier
passcode is dropped. The owner can set a new one through reset (proves the mailbox; tested).

**Reverse case (attacker registers AFTER the Google identity exists).** CODE-READ + REPRODUCED:
`users.create` hits the unique email (`postgres.py:214-223` translates `UniqueViolationError`,
memory raises the same `ValueError`) and register returns **409 `registration_failed`**; the
Google-created row's hash is of a discarded random value, so passcode login is 401. The only other
way to set a passcode on that row is reset-confirm, which needs the emailed token. Safe.

**Regression test, before and after (REPRODUCED).**
- Before the fix, memory (`smoke_stage_security.py`):
  `AssertionError: A1: the attacker's pre-registered passcode no longer logs in after the Google login: 200`
- Before the fix, Postgres (`smoke_stage_security_postgres.py`): `... after the admin's Google login: 200`
  and the response body showed `"role":"admin"` for the attacker's passcode login.
- After: both pass (401 `invalid_credentials`), plus the student-pre-claim, reverse-order,
  repeat-Google-login and reset-afterwards checks.

**Left undone / trade-offs.**
- A user who deliberately uses both a passcode and Google loses the passcode on each Google login
  (they can keep using Google, or reset). Fixing that needs a `passcode_verified_at` column
  (set by reset-confirm, rotate only when null), i.e. a new file in `backend/migrations/`, which is
  outside my set. Existing prod accounts that signed up with a passcode and later used Google will
  find their passcode no longer works after their next Google login.
- Session tokens already minted for the attacker stay valid until expiry (1h, `AUTH_TOKEN_TTL_SECONDS`).
  They carry the role at mint time (student), so no admin access, but there is no revocation
  (`token_version`) mechanism. Same migration would be needed.
- Not done: audit option (b) "reject passcode login for admins". Operator-provisioned admins use
  passcodes by design (CLAUDE.md §11), so that is a product decision.
- Stopgap S1 (empty `ADMIN_EMAIL_ALLOWLIST`, count affected accounts) is still needed for rows
  that were already hijacked before this deploys: the fix only acts on the *next* Google login.

## A2: `CODING_ROUND_ENABLED` (audit P0-2)
**Change.** `config.coding_round_enabled` (`config.py:273`), default `false` when
`NODE_ENV=production`, `true` otherwise; strict parse (`true/false/1/0`, anything else raises at
load). When off: `POST /sessions/:id/coding-round` and `.../coding-round/submissions` return
**404 `{"error":{"code":"coding_round_disabled",...}}`** before the harness is touched (session
stays in `QUESTION_LOOP`), and the WS `submit_code` message gets an `error` frame with the same
code. These are the only paths that reach `run_in_sandbox` in production (`/internal/mcp` is
dev-only, CODE-READ `gateway.py`).

**Needs another file (gateway agent).** Defence in depth: register `create_coding_agent_server`
only when `config.coding_round_enabled` (`gateway.py:337`), so nothing can reach the runner even
through a future route. Real fix (separate no-egress sandbox container) is still the follow-up.

## A4 (config side): `NODE_ENV` and `cors_origins`
- `NODE_ENV` must be exactly `development`, `test` or `production`; anything else (`prod`,
  `Production`, ` production`, empty) raises at load (`config.py:197-199`). Absent still means
  development (local default). **Recommend** `ENV NODE_ENV=production` in
  `deploy/aws/backend.Dockerfile` (not my file; today only prod.env sets it, CODE-READ).
- `config.cors_origins: list[str]` (`config.py:86`): production = `[frontend_url]`;
  development/test = `[frontend_url, http://localhost:3000, http://127.0.0.1:3000, *CORS_DEV_ORIGINS]`,
  deduplicated and each normalised; a `*` entry is dropped; `CORS_DEV_ORIGINS` is ignored in
  production. Not wired into `CORSMiddleware`; the gateway agent's `_cors_origins` already reads
  this field.

## A5: auth rate limits (audit P1 #9)
**Change.** `backend/app/http/rate_limit.py`, using the existing `storage.live.increment_rate_counter`
(Redis INCR+PEXPIRE under the postgres driver, in-process dict under memory; the same primitive
the MCP limiter uses). Reached via `request.app.state`, so `gateway.py` needed no change.

| Route | per IP | per email |
|---|---|---|
| `POST /auth/login` | 10 / min | 10 / 15 min |
| `POST /auth/register` | 20 / hour (campus NAT) | none |
| `POST /auth/reset-passcode/request` | 10 / hour | 5 / hour |
| `POST /auth/reset-passcode/confirm` | 10 / 15 min | none |

- 429 body is the app's shape: `{"error":{"code":"rate_limited","message":"too many attempts; ..."}}`.
  No `Retry-After` header: `install_error_handlers` (`http/errors.py`, not mine) sets no headers.
- Login is checked before the scrypt verify. The reset-request limit applies whether or not the
  account exists, so it is not an enumeration oracle.
- Emails are SHA-256 hashed before they become Redis keys; log lines carry only `action`/`scope`
  (no email, no IP). If the counter store raises, the limiter fails open and logs
  `auth_rate_limit_unavailable` (error class only).
- **Client IP**: the TCP peer, unless the peer is in `config.trusted_proxy_cidrs`; then
  `X-Forwarded-For` is read right to left and the first non-trusted hop is the client. An
  untrusted peer's header is ignored (tested: rotating XFF from a direct peer still hits 429).
  Default trusted set: production = loopback + RFC1918 + `fc00::/7` (the backend publishes no
  port, so only containers on the compose network, i.e. Caddy, can be the peer; CODE-READ
  `docker-compose.prod.yml`); dev/test = loopback. Override with `TRUSTED_PROXY_CIDRS`
  (malformed entry raises at load). Caddy's default `reverse_proxy` sets XFF to the real client.
- `AUTH_RATE_LIMIT_ENABLED`: always on in production (the env var is ignored there), default on in
  development, default **off in test**, because existing smoke scripts register dozens of accounts
  from one TestClient address. The new tests turn it on explicitly.
- Trade-off: the per-email login budget lets anyone lock a victim's passcode login for 15 min.
  Google sign-in is unaffected.

## A6: fail closed at boot (audit P1 #10, cors #5/#6)
In production `load_config` now raises for: `STORAGE_DRIVER` not exactly `postgres` (missing,
`memory`, or misspelled; a misspelling also raises in dev/test instead of silently using memory);
missing/empty `DATABASE_URL` or `REDIS_URL`; `AUTH_TOKEN_SECRET` < 32 chars (existing);
`ALLOW_DEV_AUTH` truthy (`false`, the `.env.example` value, still boots); missing `FRONTEND_URL`,
non-https, with a path/query/fragment/credentials, or a comma list. `FRONTEND_URL` is stored
normalised (lowercase host, default port dropped, no trailing slash) in every env, which also fixes
the `//auth/callback` double slash in `google_auth.py:121` (cors #6) without touching that file.

**Before the next deploy, check prod.env (key names / SET only):** `STORAGE_DRIVER=postgres`,
`FRONTEND_URL` is the bare `https://app...` origin, `ALLOW_DEV_AUTH` absent or `false`. If any is
off, the backend will now refuse to start (intended), and `bootstrap.sh`'s migrate step, which
also calls `load_config`, will fail first.

## Tests (pinned venv `$S/venv2`: sherpa-onnx 1.13.6, PyJWT 2.13.0; Node 26.8.1; scratch `postgres:16-alpine` :55433 and `redis:7-alpine` :56380, migrations 001-008 applied)
Each script run under `env -i` (no keys, no repo `.env`), cwd `backend/`, runner `$S/impl-sec/run_all.sh`, logs `$S/impl-sec/results/`.

| Suite | Result |
|---|---|
| **smoke_stage_security** (new) | 77 OK, PASS |
| **smoke_stage_security_postgres** (new) | 11 OK, PASS |
| smoke_stage1 | 21 OK, PASS |
| smoke_stage2_resume | 27 OK, PASS |
| smoke_stage3_question_loop | 49 OK, PASS |
| smoke_stage_admin | 85 OK, PASS |
| smoke_stage_coding | 14 OK, PASS (flag defaults on in test; real Node sandbox) |
| smoke_stage_continuers | 68 OK, PASS |
| smoke_stage_dynamic_eval | 36 OK, PASS |
| smoke_stage_dynamic_routing | 110 OK, PASS |
| smoke_stage_google_oauth | 16 OK, PASS |
| smoke_stage_human_flow | 86 OK, PASS |
| smoke_stage_live_channel | 11 OK, PASS |
| smoke_stage_llm | 18 OK, PASS |
| smoke_stage_postgres | 33 OK, PASS |
| smoke_stage_voice_http | 14 OK, PASS |
| smoke_stage_voice | 10 OK, PASS |
| smoke_stage_whisper_stt | 44 OK, PASS |
| pytest `tests/test_stt_pipeline.py` | 9 passed |

The 16 existing scripts total **642 OK**, the same as the audit's pinned baseline, so no regressions.
New checks: 88. The run happened while the other agents were editing `gateway.py`/`live_channel.py`,
so it covers their working-tree state at that moment too.

The before-fix failures are in `$S/impl-sec/before_mem.txt` and `$S/impl-sec/before_pg.txt`.
`before_pg.txt` contains a JWT signed with the test secret `x*32`. It is worthless, but don't paste it anywhere.

## For other owners
- **gateway agent:** register the coding agent server only when `config.coding_round_enabled`
  (`gateway.py:337`). `_cors_origins` can drop its fallback now that the field exists.
- **migrations owner:** `passcode_verified_at` and `token_version` columns would remove the
  A1 trade-offs listed above.
- **deploy:** add `ENV NODE_ENV=production` to `backend.Dockerfile`, and set `CODING_ROUND_ENABLED=false`
  in prod.env explicitly for clarity (it already defaults to false). Before the deploy, check the prod.env keys listed under A6.
  If uvicorn is ever started with `--proxy-headers --forwarded-allow-ips=*`, `request.client`
  becomes the forwarded IP and `client_ip` still works, but don't combine that with an empty `TRUSTED_PROXY_CIDRS`.

# CORS and cross-origin behaviour in production: adversarial review (2026-11-06)

Scope: browser on `https://app.13-54-189-166.sslip.io` calling `https://api.13-54-189-166.sslip.io`
(REST and WebSocket), through Caddy. Read-only. Nothing in source or on prod was changed. No prod
data was created: registering a `smoketest+` user was blocked by the permission layer, so 403 on
an authenticated route is CODE-READ, not REPRODUCED.

Prod versions (REPRODUCED via SSM `docker exec aws-backend-1`): starlette 1.10.0, fastapi 0.162.0,
uvicorn 0.54.0. The bundle's baked gateway URL is `https://api.13-54-189-166.sslip.io` (REPRODUCED
by grepping the served `/_next/static` chunks).

## How the middleware actually stacks

`backend/app/gateway.py:382-396` adds the middleware in this order: `_UnhandledErrorMiddleware`, then
`CORSMiddleware`, then `_BodySizeLimitMiddleware`. Starlette makes the last one added the outermost,
so a request passes through them like this:

```
ServerErrorMiddleware  (Starlette; holds the @app.exception_handler(Exception) from errors.py:50)
  _BodySizeLimitMiddleware      <- OUTSIDE CORS: anything it returns has no ACAO
    CORSMiddleware
      _UnhandledErrorMiddleware <- inside CORS: its 500s do get ACAO (good, as the comment intends)
        ExceptionMiddleware (HttpError / JSONDecodeError handlers)
          router
```

The comment at `gateway.py:378-381` explains why the unhandled-error middleware is placed inside CORS.
Nobody applied the same reasoning to the body-size middleware, which ended up outside it.

---

## Ranked findings

### 1. 413 from the body-size cap carries no CORS headers. REPRODUCED. Severity: HIGH (user-facing)

`gateway.py:129-136` returns its 413 from outside CORSMiddleware.

```
curl -s -D - -H "Origin: https://app.13-54-189-166.sslip.io" -H "content-type: application/json" \
  --data-binary @big.json https://api.13-54-189-166.sslip.io/auth/login        # big.json = 1.1 MB
HTTP/2 413
content-type: application/json
server: uvicorn
via: 1.1 Caddy
content-length: 76
{"error":{"code":"payload_too_large","message":"request body is too large"}}
# no access-control-allow-origin, no vary
```
The blob route behaves the same: a 29 MB body to `POST /sessions/abc/answers/audio` returned an
identical 413 with no ACAO header. The blob cap is base64(max(5 MB resume, 20 MB audio)) + 64 KiB,
about 28 MB.

What the user sees: the browser reports `TypeError: Failed to fetch` and the console shows "No
'Access-Control-Allow-Origin' header", so the real 413 never reaches the page.
- Config page (`apps/web/app/interview/[id]/config/page.tsx:128`): a resume over about 21 MB shows
  "could not read that file". A resume between 5 and 21 MB passes the middleware, then fails the
  route's own check (`interview.py:115-116`, inside CORS), so that user gets the clear message
  "resume is N bytes; the limit is 5242880". The user-visible behaviour depends on which size band
  the file falls into.
- Room (`room/page.tsx:862-866`): "Could not send audio. You can type your answer instead." This is
  a reasonable fallback, but it hides the cause.
- The client never checks `file.size` before upload, so the full 28 MB+ base64 body is sent before
  the server rejects it.

Patch:
- `gateway.py:382-396`: register `_BodySizeLimitMiddleware` first (before `_UnhandledErrorMiddleware`)
  so the order becomes CORS > Unhandled > BodySize > app. Update the comment block at 378-381 to cover
  both middlewares. Preflights carry no body, so the reorder cannot affect them.
- Client side, optional: in `config/page.tsx` `onUpload`, reject files over 5 MB before reading them.
  The limit would be exposed through a `NEXT_PUBLIC_MAX_RESUME_BYTES` build arg or hardcoded, with a
  note that it must match `MAX_RESUME_BYTES`.
- Regression test `backend/tests/smoke_cors.py`, in the same style as `smoke_stage1.py`: build
  `create_app(CreateAppOptions(config=load_config({"NODE_ENV": "production", "AUTH_TOKEN_SECRET":
  "x"*32, "FRONTEND_URL": "https://app.example", ...memory storage...})))` and use a `TestClient`.
  Assert that `POST /auth/login` with a 1.1 MB body and `Origin: https://app.example` returns 413
  with `access-control-allow-origin == "https://app.example"`. Do the same for a 29 MB body on
  `/sessions/x/answers/audio`.

### 2. Caddy-generated errors (502/503/504) carry no CORS headers. REPRODUCED for one case; the rest CODE-READ. Severity: MEDIUM

`deploy/aws/Caddyfile:9-11` is a bare `reverse_proxy`. When the backend is down, restarting, or
stuck in the 10-minute healthcheck restart, or when the upstream drops the connection, Caddy answers
by itself with no ACAO header. Reproduced with a request whose declared Content-Length did not match
its body:
```
curl -s -D - --max-time 15 -H "Origin: https://app.13-54-189-166.sslip.io" -H "content-type: application/json" \
  -H "authorization: Bearer x" -H "Content-Length: 200000000" --data-binary '{}' \
  https://api.13-54-189-166.sslip.io/sessions/abc/resume
HTTP/2 502
server: Caddy
content-length: 0
```
What the user sees: every page shows its generic fallback ("could not load your stats", "could not
sign in", and so on) while the console shows a CORS error. Anyone debugging will start with the
CORS config instead of the backend, which is the actual cause. A backend restart mid-interview turns
into a run of CORS errors.

Patch, in `Caddyfile`, inside the `{$API_HOST}` block. This only fires for errors Caddy generates;
upstream responses pass through untouched, so headers cannot be duplicated.
```
handle_errors {
	@fromapp header Origin https://{$APP_HOST}
	header @fromapp Access-Control-Allow-Origin "https://{$APP_HOST}"
	header @fromapp Access-Control-Allow-Credentials "true"
	header Vary Origin
	header Content-Type application/json
	respond `{"error":{"code":"upstream_unavailable","message":"the server is unavailable; try again in a moment"}}` {err.status_code}
}
```
Test locally, not on prod: start the prod compose, `docker compose stop backend`, then
`curl -D - -H "Origin: https://$APP_HOST" https://$API_HOST/health` should return 502 with ACAO.
Repeat with a foreign Origin and confirm there is no ACAO. Also run `caddy validate`.

Related client change (`apps/web/lib/api.ts:44-67`): `request()` lets a fetch `TypeError` escape,
and `JSON.parse` throws `SyntaxError` on a non-JSON body. Wrap both and raise `ApiCallError(0,
"network_error", "could not reach the server")` and `ApiCallError(status, "bad_response", ...)`. That
way every page's `instanceof ApiCallError` branch shows an honest message instead of the generic
fallback. No backend test is needed; a vitest case in `apps/web` can mock fetch to reject.

### 3. WebSocket bearer tokens are written to the backend's access log. REPRODUCED. Severity: MEDIUM (security, cross-origin-adjacent)

The browser WebSocket API cannot set headers, so the token travels as `?token=`
(`room/page.tsx:450`, `live_channel.py:339`). uvicorn's default access log
(`deploy/aws/backend.Dockerfile:48`, no `--no-access-log`) prints the full path, including the
query string:
```
# SSM: docker logs --since 30m aws-backend-1 | grep -F token=garbage   (my own probe token)
INFO:     172.18.0.6:46688 - "WebSocket /sessions/abc/live?token=garbage" [accepted]
# SSM: docker logs aws-backend-1 | grep -c "live?token="  ->  4 (2 mine; 2 from real sessions, values not printed)
```
Caddy logs nothing for this path (count 0), because no `log` directive is configured. Anyone with
`docker logs` access, or a future log shipper, can collect live, role-scoped tokens. That includes
admin tokens, which are valid for the whole token TTL.

Patch, choose one:
- (a) Quick: add a `logging.Filter` on the `uvicorn.access` logger, installed in `app/main.py`, that
  rewrites `token=[^&" ]+` to `token=REDACTED`. Keep the access log.
- (b) Better: stop putting the token in the URL. Accept on connect, require the first client frame
  to be `{"type":"auth","token":...}` within about 5 s, and otherwise close with 4401. Alternatively,
  carry the token in `Sec-WebSocket-Protocol` and echo back a fixed subprotocol. This needs matching
  changes in `room/page.tsx:450` and `live-protocol.ts`.

Test: a unit test for the filter, feeding in a log record with `token=abc` and asserting the output
contains no `abc`. For (b), extend `smoke_stage_live_channel.py`: connecting with `?token=` and no
auth frame gets a 4401 close, and the auth frame path succeeds.

### 4. WebSocket does not check Origin. REPRODUCED. Severity: LOW (defence in depth)

`live_channel.py:334` calls `websocket.accept()` without inspecting Origin, and Caddy passes the
upgrade through:
```
curl -s --http1.1 -i -N -H "Connection: Upgrade" -H "Upgrade: websocket" -H "Sec-WebSocket-Version: 13" \
  -H "Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==" -H "Origin: https://evil.example" \
  "https://api.13-54-189-166.sslip.io/sessions/abc/live?token=garbage"
HTTP/1.1 101 Switching Protocols ... Server: Caddy / Server: uvicorn
<close frame 4401 "unauthorized">
```
The same request with the app origin produced an identical handshake, so through Caddy the
handshake works from the real origin. The CSWSH impact is low because authentication is a token the
attacker's page cannot read (it sits in sessionStorage on the app origin), not an ambient cookie.
The gap becomes exploitable the moment someone moves auth to a cookie.

Patch: in `live_channel.py`, before `accept()`, read `websocket.headers.get("origin")`. If it is
present and not equal to the normalised `frontend_url` (production) or not in the dev allow list,
call `await websocket.close(code=4403)` (before accept, Starlette turns this into an HTTP 403). An
absent Origin means a non-browser client and stays allowed. Test: in
`smoke_stage_live_channel.py`, `client.websocket_connect(url, headers={"origin":
"https://evil.example"})` should raise `WebSocketDisconnect`, and the app origin should connect.

### 5. Dev mode reflects any Origin with credentials; NODE_ENV fails open. CODE-READ (Starlette source on prod). Severity: MEDIUM if misconfigured, otherwise LOW

`gateway.py:387` uses `allow_origins=["*"]` together with `allow_credentials=True`. Per the spec,
`*` cannot be combined with credentials. Starlette 1.10 works around it: `cors.py:37`
`preflight_explicit_allow_origin = not allow_all_origins or allow_credentials`, and `cors.py:163-164`
"if allow_all_origins and allow_credentials: allow_explicit_origin(origin)". Both preflights and
simple responses therefore echo back whatever Origin arrives, with `allow-credentials: true`. In
effect every site is allowed with credentials.

The production branch triggers only on the exact string `production` (`gateway.py:387`,
`config.py:96`). `NODE_ENV=Production`, `prod`, or an unset value falls back to development, which
also skips the 32-character secret check (`config.py:99`), registers `/internal/mcp`, dev-ping and,
with `ALLOW_DEV_AUTH=true`, dev-login. The CORS reflection on its own is low impact today, because
auth is a bearer token rather than a cookie. The only cookies are the OAuth state cookies on
`Path=/auth/google`. Combined with the other dev-only routes, though, a misconfigured environment is
a real exposure.

Patch:
- `config.py`: reject any `NODE_ENV` outside {`development`, `test`, `production`} with a
  `RuntimeError` at load.
- `gateway.py:387`: in non-production, use an explicit list (`frontend_url`, `http://localhost:3000`,
  `http://127.0.0.1:3000`) or `allow_origin_regex=r"^http://(localhost|127\.0\.0\.1)(:\d+)?$"`
  instead of `"*"`.

Test: `load_config({"NODE_ENV": "prod"})` raises. In dev mode, `GET /health` with
`Origin: https://evil.example` returns no ACAO.

### 6. FRONTEND_URL is not validated; production silently defaults to localhost. CODE-READ, with one part REPRODUCED. Severity: LOW to MEDIUM

- Exact-match behaviour against the live config (REPRODUCED, `GET /health` with Origin). Only
  `https://app.13-54-189-166.sslip.io` gets ACAO. These all get none: the same with `/`, with
  uppercase `APP.`, with `:443`, `http://app...`, `https://www.app...`, `http://localhost:3000`, and
  `null`. Browsers normalise Origin (lowercase host, no default port, no slash), so this is correct
  for the real app. The only trailing-slash mismatch the code tolerates is a slash on FRONTEND_URL
  itself, via `.rstrip("/")`.
- `localhost` dev hitting prod is blocked by design. A developer pointing `NEXT_PUBLIC_GATEWAY_URL`
  at prod gets CORS errors everywhere. That is correct, but it should be documented.
- `config.py:77,141`: if FRONTEND_URL is missing in production, it defaults to
  `http://localhost:3000`. The real app then fails on every call with a CORS error, and prod allows
  localhost:3000 with credentials. An uppercase host or a path in FRONTEND_URL would also break
  matching silently, and a comma-separated list is unsupported.
- `google_auth.py:121` uses `config.frontend_url` without `.rstrip("/")`, so a trailing slash gives
  `https://app...//auth/callback#token=...`.

Patch: in `load_config`, when in production, require FRONTEND_URL. Parse it with
`urllib.parse.urlsplit` and require `https`, an empty path or `/`, and no query or fragment. Store
the normalised value `f"{scheme}://{host.lower()}{':'+port if non-default}"` and use it at both
`gateway.py:387` and `google_auth.py:121`. Test: `load_config` raises for a missing value, for
`http://`, and for a value with a path. `"https://App.Example/"` normalises to
`"https://app.example"`.

### 7. Every request is preflighted, including bodyless GET and DELETE. REPRODUCED (timing). Severity: LOW (latency)

`api.ts:49-52` always sends `content-type: application/json`. Together with `authorization`, every
call is non-simple, so the browser sends an OPTIONS request first. That is unavoidable when
`authorization` is present. The preflight cache is 600 s per URL, but URLs contain session ids and
audio refs, so the cache rarely hits: every TTS clip fetch (`room/page.tsx:326,363`) and every new
session URL costs an extra round trip. Measured from this machine:
`preflight total=1.06s connect=0.35s` on a new connection.

Patch: only add `content-type` when `init.body` is present. This does not remove preflights (the
`authorization` header still forces them). To actually save round trips, raise `max_age` on
CORSMiddleware to 3600-7200 s; Chrome caps it at 7200 s.

### 8. The room reads `x-speech-provider` cross-origin; it is never exposed and never set. CODE-READ. Severity: LOW

`room/page.tsx:329,366` checks `response.headers.get("x-speech-provider") !== "fixture"` to avoid
playing the fixture provider's 140 Hz test tone. Cross-origin, a non-safelisted response header is
readable only if `Access-Control-Expose-Headers` lists it, and CORSMiddleware's `expose_headers`
defaults to `[]`. On top of that, the backend never sets this header (`voice.py:171` sends only
`cache-control`). So the check always passes, and if prod ever fell back to the fixture TTS,
candidates would hear the tone.

Patch: set `x-speech-provider` in `voice.py:get_audio` from the stored file metadata or the provider
name, and add `expose_headers=["x-speech-provider"]` at `gateway.py:383-391`. Test: TestClient
`GET /sessions/{id}/audio/{ref}` with Origin returns `access-control-expose-headers` containing
`x-speech-provider`.

### 9. Invalid UTF-8 in a JSON body returns 500 instead of 400. REPRODUCED. Severity: LOW (not CORS; ACAO present)

```
printf '{"email":"\xff\xfe"}' | curl -s -D - -H "Origin: https://app.13-54-189-166.sslip.io" \
  -H "content-type: application/json" --data-binary @- https://api.13-54-189-166.sslip.io/auth/login
HTTP/2 500   access-control-allow-origin: https://app.13-54-189-166.sslip.io
```
`gateway.py:400` handles only `JSONDecodeError`, but `request.json()` raises `UnicodeDecodeError`
here. The fix is a matching handler that returns 400 `invalid_json`, with a test for the same request.

### 10. Google OAuth flow. CODE-READ, with headers REPRODUCED. Severity: LOW (UX only)

The flow is made of navigations, not fetches, so CORS does not apply. `GET /auth/google/start`
returns a 302 to accounts.google.com with `redirect_uri=https://api.../auth/google/callback`.
Cookies: `HttpOnly; Max-Age=600; Path=/auth/google; SameSite=lax; Secure` (REPRODUCED). Lax cookies
are sent on the top-level GET back from Google, so the flow works. The token comes back in the URL
fragment of `${frontend_url}/auth/callback` (`google_auth.py:121`), which is correct.
The one weakness: every failure on the callback (`google_auth.py:58-61`, for example
`invalid_oauth_state`, or a user who hits Back) renders a raw JSON error page on the API origin.
Patch: redirect to `${frontend_url}/auth/callback#error=<code>` and let the SPA show it. Test: extend
`smoke_stage_google_oauth.py` so a callback with no cookies asserts a 302 to the frontend with
`#error=`.

---

## Verified OK (REPRODUCED unless marked)

- **Preflight, every method and header the client uses:** GET, POST, PATCH and DELETE with
  `authorization,content-type` on `/me/profile`, `/sessions/abc/resume`, `/sessions/abc/audio/x/y.wav`,
  `/admin/archives/x/download`, and an unknown path all return 200 with ACAO = app origin,
  allow-credentials, and allow-methods `DELETE, GET, HEAD, OPTIONS, PATCH, POST, PUT, QUERY`. The
  client never uses multipart: resume and audio go as base64 inside JSON, `api.ts:145-153`. A foreign
  origin's preflight gets `400 Disallowed CORS origin` with no ACAO, as it should.
- **Error statuses inside the stack carry ACAO:** 400 (`invalid_json`, `invalid_request`), 401 (no
  token, bad token, bad login), 404 (unknown route), 405, and 500 (via `_UnhandledErrorMiddleware`).
  403 and 429 come from the same `HttpError` handler inside CORS (CODE-READ, `errors.py:44-48`,
  `interview.py:70-71`).
- **`allow_credentials=True` with a concrete origin:** correct and harmless. `credentials` is never
  set in the client and there are no auth cookies, so the flag is unnecessary but does no harm.
  Leave it on, or turn it off to shrink the surface; nothing in the client depends on it.
- **Caddy:** neither adds nor strips nor duplicates CORS headers (exactly one ACAO over HTTP/1.1 and
  HTTP/2). HTTP to HTTPS is a 308 from Caddy, which would break a preflight (browsers do not follow
  redirects on preflight), but the bundle is baked with `https://`, so the redirect never happens
  for real users.
- **uvicorn/h11-level malformed HTTP:** the browser cannot produce it, and Caddy sits in front. Not
  a real browser case.
- **`ServerErrorMiddleware` outermost:** only exceptions raised in `_BodySizeLimitMiddleware` itself
  could reach it without CORS, and its dispatch is trivial. Fixing #1 by reordering removes even
  that.

## Probe files

Scratch payloads were `big.json` (1.1 MB) and `huge.json` (29 MB) in the session scratchpad. The WS
probe used `token=garbage`. No prod data was created.

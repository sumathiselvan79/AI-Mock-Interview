# E2E production test — 2026-11-06 (13:24–13:33 UTC)

Target: API `https://api.13-54-189-166.sslip.io`, web origin `https://app.13-54-189-166.sslip.io`
(`Origin` header sent on every request). Read-only on AWS; no redeploy; no source edits outside
`deploy/aws/notes/` and `deploy/aws/smoke_prod.py`.

## Verdict

The pipeline works end to end in production: register → login → session → resume/JD-fit →
consent → begin → WebSocket and REST turns → STT → coding round (real Node sandbox, 6/6) →
wrap-up → report → stats. Three full runs, every one reached `COMPLETED`.

It is **not** healthy, though:
- **TTS is completely dead.** No question, acknowledgment, follow-up, coding prompt or closing
  line has produced audio since the 13:00 deploy.
- **Two of the four LLM-backed steps nearly always fall back to deterministic code and still
  report success:** JD-fit rationale (3/3 failed) and follow-up probes (7/8 failed). The
  deterministic follow-up path then asks for things the candidate already said.
- Question synthesis (Groq) works, but one call in nine hit the 30 s provider timeout, which made
  a 45 s turn.

## Repeatable script

`uv run --with httpx --with websockets deploy/aws/smoke_prod.py --api https://api.13-54-189-166.sslip.io --web https://app.13-54-189-166.sslip.io --answer-wav deploy/aws/notes/fixtures/answer16k.wav`

- It exits 1 on any FAIL. `--strict` also turns WARN (LLM fallback, grade-band clash) into FAIL.
  `--budget N` (default 4, the browser default is 8).
- `fixtures/answer16k.wav` is 16.4 s of synthesized speech (Piper amy-low, generated locally with
  `sherpa-onnx<1.13`) saying an answer about a FastAPI/Postgres index and Redis.
- The browser's order of calls comes from `apps/web/lib/api.ts`, `app/interview/[id]/config/page.tsx:155-156`,
  `telemetry-check/page.tsx:223` and `room/page.tsx` (WS `next_question`/`submit_answer_text`,
  REST `answers/audio`, `generateReport` on `session_complete`).
- Deviations from the browser: it sends `question_budget` (the API supports it; the browser
  doesn't send it). It also calls the coding-round routes, which the web UI never calls (bug 9).

### Final run output (run 3, session `a213ced9-9c63-4d07-8c16-4a4f7c68a275`)

| # | step | endpoint | status | latency | result | note |
|---|---|---|---|---|---|---|
| 1 | health | `GET /health` | 200 | 1111 ms | PASS |  |
| 2 | cors_preflight | `OPTIONS /auth/register` | 200 | 355 ms | PASS | allow-origin=https://app.13-54-189-166.sslip.io |
| 3 | register | `POST /auth/register` | 201 | 445 ms | PASS |  |
| 4 | login | `POST /auth/login` | 200 | 396 ms | PASS |  |
| 5 | me_profile | `GET /me/profile` | 200 | 363 ms | PASS |  |
| 6 | create_session | `POST /sessions` | 201 | 364 ms | PASS |  |
| 7 | resume_upload_jd_fit | `POST /sessions/{id}/resume` | 201 | 12435 ms | PASS |  |
| 8 | jd_fit_llm_generated | `(resume upload response)` | - | 12435 ms | WARN | prompt_version=None rationale=no fit=1.0 |
| 9 | jd_fit_read | `GET /sessions/{id}/jd-fit` | 200 | 358 ms | PASS |  |
| 10 | advance_CONFIG | `POST /sessions/{id}/advance` | 200 | 363 ms | PASS |  |
| 11 | advance_TELEMETRY_CHECK | `POST /sessions/{id}/advance` | 200 | 367 ms | PASS |  |
| 12 | telemetry_check_consent | `POST /sessions/{id}/telemetry-check` | 200 | 364 ms | PASS |  |
| 13 | begin_interview | `POST /sessions/{id}/begin` | 200 | 386 ms | PASS |  |
| 14 | topic_plan_built | `(begin response)` | - | 386 ms | PASS | 7 topics, state=QUESTION_LOOP |
| 15 | ws_connect | `WS /sessions/{id}/live` | 101 | 1072 ms | PASS | {"type": "connected", "session_id": "a213ced9-9c63-4d07-8c16-4a4f7c68a275", "state": "QUESTION_LOOP"} |
| 16 | ws_next_question_1 | `WS next_question` | - | 371 ms | PASS | topic=introduction audio=no continuers=[] |
| 17 | ws_answer_1 | `WS submit_answer_text` | - | 2808 ms | PASS | frames=['error', 'acknowledgment', 'question'] score=3.0 grade=C |
| 18 | ws_next_question_2 | `WS next_question` | - | 5821 ms | PASS | topic=apis and services audio=no continuers=['selection'] |
| 19 | ws_answer_2 | `WS submit_answer_text` | - | 5168 ms | PASS | frames=['error', 'acknowledgment', 'continuer', 'follow_up'] follow_up reason=the answer describes actions but never says how it turned out |
| 20 | ws_follow_up_2 | `WS submit_follow_up_text` | - | 367 ms | PASS | ["continuer", "question"] |
| 21 | rest_next_question_3 | `GET /sessions/{id}/questions/next` | 200 | 4479 ms | PASS |  |
| 22 | tts_question_audio | `(question.audio_url)` | - | 0 ms | FAIL | no audio_url; speech_note=audio unavailable (synthesis failed: division by zero); showing the question as text |
| 23 | stt_silence_refused | `POST /sessions/{id}/answers/audio` | 202 | 1443 ms | PASS |  |
| 24 | stt_silence_code | `(response)` | - | 0 ms | PASS | code=no_speech_detected draft=None |
| 25 | stt_speech_answer | `POST /sessions/{id}/answers/audio` | 201 | 5645 ms | PASS |  |
| 26 | stt_transcript_quality | `(response)` | 201 | 5645 ms | PASS | accepted=True code=None conf=0.8100000023841858 text='In my last project, I designed a REST API in Python with fast API and…' |
| 27 | rest_audio_scored | `(answer response)` | - | 5645 ms | PASS | score=2.0 grade=D follow_up=True note= |
| 28 | rest_follow_up_answer_audio_turn | `POST /sessions/{id}/answers/971461ce-ade5-4e13-a4ef-e5167531c239/follow-up` | 201 | 373 ms | PASS |  |
| 29 | rest_next_question_4 | `GET /sessions/{id}/questions/next` | 200 | 19778 ms | PASS |  |
| 30 | meta_utterance_repeat | `POST /sessions/{id}/answers` | 201 | 366 ms | PASS |  |
| 31 | rest_answer_text | `POST /sessions/{id}/answers` | 201 | 3722 ms | PASS |  |
| 32 | rest_text_scored | `(answer response)` | - | 3722 ms | PASS | score=2.5 grade=C follow_up=True note= |
| 33 | rest_follow_up_answer | `POST /sessions/{id}/answers/b722fe4d-6d0c-4492-a104-e21334d140f3/follow-up` | 201 | 366 ms | PASS |  |
| 34 | coding_round_start | `POST /sessions/{id}/coding-round` | 201 | 379 ms | PASS |  |
| 35 | coding_submission | `POST /sessions/{id}/coding-round/submissions` | 201 | 410 ms | PASS |  |
| 36 | coding_tests_pass | `(submission)` | - | 410 ms | PASS | rate-limiter: 6/6 |
| 37 | wrap_up | `POST /sessions/{id}/wrap-up` | 200 | 372 ms | PASS |  |
| 38 | wrap_up_state | `(response)` | - | 0 ms | PASS | state=WRAP_UP audio=no |
| 39 | report_generate | `POST /sessions/{id}/report` | 201 | 412 ms | PASS |  |
| 40 | report_content | `(report response)` | - | 412 ms | PASS | state=COMPLETED competencies=5 overall=2.4/D |
| 41 | grade_bands_consistent | `(report + answers)` | - | 0 ms | PASS |  |
| 42 | report_read | `GET /sessions/{id}/report` | 200 | 360 ms | PASS |  |
| 43 | transcript_read | `GET /sessions/{id}/transcript` | 200 | 362 ms | PASS |  |
| 44 | me_stats | `GET /me/stats` | 200 | 361 ms | PASS |  |
| 45 | me_stats_counts_session | `(response)` | - | 0 ms | PASS | sessionsCompleted=1 |

user=smoketest+e2e1793971909@example.com session=a213ced9-9c63-4d07-8c16-4a4f7c68a275
summary: PASS=43 FAIL=1 WARN=1 SKIP=0

The two non-PASS rows are bug 1 (TTS) and bug 2 (JD-fit fallback). Runs 1 and 2 were earlier
script revisions: run 1 surfaced the WS `error`-frame issue (bug 4), and run 2 had the same
results with TTS rated WARN.

## LLM findings (spans read from `telemetry_events`, `tool_called` server=`tool-llm-provider`, all 3 sessions)

The provider config is `LLM_PROVIDER=ollama` (`gpt-oss:120b`, ollama.com), `QUESTION_AGENT_LLM_PROVIDER=groq`
(`openai/gpt-oss-120b`) and `RESUME_SERVICE_LLM_PROVIDER=ollama`, all with keys set. That means no
fixture is involved: every `ok` span is a real provider answer.

| LLM step (caller → tool) | provider | ok | failed | latency (min/avg/max) | user-visible effect |
|---|---|---|---|---|---|
| Resume parse (`tool-resume-parser`) | ollama | 3 | 0 | 3.7 / 4.0 / 4.2 s | fine |
| JD requirements `role_level`/`key_technologies` (resume-service) | ollama | 3 | 0 | ~2.3–3.8 s | fine (`role_level=mid`, 8–9 technologies) |
| Self-intro parse (resume-service) | ollama | 3 | 0 | ~2.3–3.8 s | fine |
| **JD-fit rationale + topic_relevance** (resume-service) | ollama | **0** | **3** `schema_validation_failed` | 7.3 / 7.8 / 8.2 s | `rationale` absent, `prompt_version` null, still 201 |
| Question synthesis v6 (`question-agent`) | groq | 8 | 1 `provider_unavailable` (30 011 ms timeout) | 2.8 / 8.6 / 19.4 s | 7 of 7 non-intro questions synthesized (v6), except one turn that fell to v5 after the timeout |
| **Follow-up probe** (`followup-agent`) | ollama | 1 | **7** `schema_validation_failed` | 3.3 / 3.9 / 5.8 s | template probes from the gap detector. The one `ok` span still shipped template text (bug 6). |
| Report / eval / grading | none (deterministic Eval Tool) | – | – | <15 ms | by design |

Question provenance (`questions.prompt_version`): the intro always comes from the bank (by design).
Every other question was `question-agent/v6`, except one `question-agent/v5` (run 2, `reliability
and operations`) after Groq timed out. The synthesized questions draw on earlier answers, e.g. "You
mentioned the sequential scan on a 40 million-row table…", so callbacks and grounding are working.

**Observability gap:** none of these failures write anything to the backend application log. The
only record is a `tool_called` row in Postgres with `error_code`, and the validation message itself
is never stored anywhere (`app/tools/llm_provider/server.py:105-111` turns it into an
`McpHandlerError`; the callers swallow it with `except Exception: return {}`/`None` at
`agents/resume_service/server.py:249` and `agents/followup/server.py:682`). I tried to get the exact
pydantic error by running a reproducer inside the backend container. The permission system blocked
that (a write to the remote shell), so the causes below are SUSPECTED.

## Bugs

| # | Sev | Status | What | Where |
|---|---|---|---|---|
| 1 | High | REPRODUCED | TTS returns no audio, ever | `backend/pyproject.toml:26`, `app/tools/speech_service/sherpa_provider.py:146,157-166` |
| 2 | High | REPRODUCED (failure) / SUSPECTED (cause) | JD-fit LLM always fails validation and is silently dropped | `app/llm_client/schemas.py:77`, `agents/resume_service/server.py:249` |
| 3 | High | REPRODUCED (failure) / SUSPECTED (cause) | Follow-up LLM fails validation in 7 of 8 calls, so probes come from regex templates | `agents/followup/server.py:668-683,336` |
| 4 | Med | REPRODUCED | A degraded-TTS note is pushed as a WS `error` frame on every question, so the room shows an error banner | `app/http/live_channel.py:207-208`, `apps/web/app/interview/[id]/room/page.tsx:608-610` |
| 5 | Med | REPRODUCED | Gap detector false positives: asks "give me a sense of the scale" after "400 milliseconds to 30 milliseconds", and "what happened as a result" after "load dropped by about 60 percent" | `app/interview_domain/signals.py:37-40`, `agents/followup/server.py:112-115` |
| 6 | Med | REPRODUCED | Template probes quote a truncated raw sentence and read as broken English | `agents/followup/server.py:132-142,776-785` |
| 7 | Med | REPRODUCED | Session bearer token is written to the backend access log in the WS URL | `app/http/live_channel.py:339`, `deploy/aws/backend.Dockerfile:48` |
| 8 | Med | REPRODUCED | The same displayed score carries different letters (overall "2.5 · D" next to an answer "2.5 · C") | `app/tools/eval/grading.py:127-131` |
| 9 | Med | CODE-READ | The coding round cannot be reached from the web UI | `apps/web/lib/api.ts` (no `coding-round` call), `room/page.tsx` |
| 10 | Med | REPRODUCED | A provider timeout makes a 45 s question turn (30 s timeout, then a second LLM call) | `app/llm_client/provider.py:41`, `agents/question/server.py:399` → v5 path |
| 11 | Low | REPRODUCED | LLM and TTS failures are invisible in application logs | see "Observability gap" |
| 12 | Low | SUSPECTED | JD fit `fit_score: 1.0` with `gaps: []`, because the deterministic matcher treats each JD sentence as a requirement and matched all three | resume parser / `agents/resume_service` deterministic path |
| 13 | Low | SUSPECTED | A correct coding solution (6/6 tests) scores 2.4 "D" with the evidence span `"empty"` | coding-agent → `tool-eval` |
| 14 | Low | CODE-READ | The room checks the `x-speech-provider` header, but the backend never sets it, and CORS would not expose it anyway | `room/page.tsx:329,366`, `app/http/routes/voice.py:157-172` |

### Details

**1. TTS dead (REPRODUCED).** Prod runs `sherpa-onnx 2.0.1` (from `pip show` in `aws-backend-1`),
and `pyproject.toml:26` allows any version `>=1.10`. In 2.x, `OfflineTts.generate()` with the
Piper/espeak config at `sherpa_provider.py:116-128` logs `phoneme_codepoints is empty, no lexicon,
and no frontend available` and returns 0 samples at `sample_rate=0`. `sherpa_provider.py:166` then
raises `ZeroDivisionError`, and the response carries the speech note `audio unavailable (synthesis
failed: division by zero)`.
- Reproduced locally: `sherpa-onnx` 2.0.1 gives 0 samples, `sherpa-onnx<1.13` with the same model
  dir produces audio (that is how the fixture WAV was made).
- Startup hides it. The warm-up at `:146` swallows the failure, and the gateway logs
  `speech_provider_selected provider=sherpa-onnx+faster-whisper` as if all were well.
- Since 13:00 the backend log has 27+ `Failed to convert … to token IDs` lines, one per spoken line.
- Expected: question audio. Observed: `audio_url: null` on every question. Fix: pin
  `sherpa-onnx<2` (or adopt the 2.x API), and make the warm-up failure fatal or at least downgrade
  the provider choice.

**2. JD-fit LLM silently dropped (REPRODUCED 3/3).** Request: `POST /sessions/{id}/resume` with a
realistic text resume. Observed: 201 after about 12 s, a `tool_called` span with
`schema_validation_failed` (about 7.8 s, after the default retry), and `jd_fit.rationale` and
`jd_fit.prompt_version` both null. Expected: a grounded rationale.
- Suspected cause: the prompt sends all 40 `TOPICS` as "TOPICS TO CONSIDER SCORING", but
  `JdFitGeneration.topic_relevance` is capped at `max_length=12` (`schemas.py:77`).
- The fallback-while-claiming-success: the API gives no signal that the enrichment failed (no
  `insufficient_signal`, no note), and `fit_score` is 1.0 (bug 12).

**3. Follow-up LLM fails 7/8 (REPRODUCED).** Every answer with a gap produced a span of
`followup-agent → tool-llm-provider: schema_validation_failed` after 3.3–5.8 s. The candidate still
pays that latency, and then gets the deterministic template. Cause not captured (see the
observability gap). In the one `ok` call (run 1, Q4), `follow_up_text` still came from the template,
because `server.py:336` falls back when the generated `follow_up_text` is empty or null while still
using the LLM's `reason`. The LLM reason and the template question therefore disagree.

**4. TTS note as a WS `error` frame (REPRODUCED).** After every `question` frame the server sends
`{"type":"error","message":"audio unavailable …"}` (`live_channel.py:207-208`). The room handles
any `error` with `setError(...)` (`room/page.tsx:608-610`), so every question shows "error" chrome.
It also arrives where a client expects the reply to its next message: run 1's client read it as the
answer's reply. Expected: a `speech_note` field on the `question` frame.

**5. False-positive probes (REPRODUCED).**
- Run 2, databases question, spoken answer (Whisper transcript "…cut query latency from about 400
  milliseconds to 30 milliseconds…"). Probe: "You mentioned added an index on the orders table,
  which cut query latency from about 400 milliseconds… — can you give me a sense of the scale? Even
  a rough before-and-after would help…". `METRIC_RE` (`signals.py:37-40`) matches `ms` but not
  `milliseconds`, which is how Whisper and people say it.
- Caching answer "…Database load dropped by about 60 percent". Probe: "What happened as a result?"
  `_OUTCOME` (`followup/server.py:112-115`) has no `dropped`, `fell`, `brought … down` or
  `went down`.
- These detectors are what candidates actually experience, because bug 3 sends nearly every
  follow-up down this path.

**6. Broken template English (REPRODUCED).** Run 2 and 3 probes include "That's helpful context on
For caching shipment lookups I used Redis with a cache-aside pattern and a five minute TTL…. What
happened as a result?" and "You mentioned added an index on the orders table…". `_subject_of`
(`:776-781`) strips the leading pronoun and truncates at 90 characters, but it doesn't turn the
sentence into a noun phrase.

**7. Bearer token in logs (REPRODUCED).** Uvicorn's access log records
`"WebSocket /sessions/<id>/live?token=eyJ…" [accepted]`, the full signed 1-hour student token (2
lines from this run; values not copied here). The browser has to send it as a query parameter
(`live_channel.py:339`). Uvicorn is started without access-log filtering (`backend.Dockerfile:48`).
CLAUDE.md §8 and the redacting logger exist to prevent exactly this. Fix: an access-log filter that
strips `token=`, or `--no-access-log` plus app-level request logging.

**8. Grade-band clash (REPRODUCED, run 1).** The answers had competency scores 3.0, 2.0, 2.5 and 2.4,
mean 2.475. `grade_for` picks the band from the raw 2.475 (D, which needs ≥2.5 for C) but reports
`score: round(2.475*10)/10 = 2.5`. So the report shows the overall as "2.5 · D Developing" while the
databases answer shows "2.5 · C Competent". Fix: band the rounded value, or show the unrounded one.
The script now checks for this (`grade_bands_consistent`).

**9. Coding round unreachable from the web (CODE-READ).** `apps/web` has no call to
`POST /sessions/{id}/coding-round` or `/coding-round/submissions`, and the room never sends WS
`submit_code`. A `"coding"` phase label exists (`room/page.tsx:1101`), but nothing enters it. The
backend path works (merge-intervals and rate-limiter both 6/6 in the real sandbox), but only an API
client can reach it.

**10. 45 s turn on a provider timeout (REPRODUCED, run 2 Q4).** `GET /questions/next` took 44 808 ms.
The timeline was: Groq v6 synthesis hit `PROVIDER_TIMEOUT_S=30` and returned `provider_unavailable`
after 30 011 ms, then a second v5 sharpening call took 14.4 s. There was no continuer on REST
(by design), and the browser would only get one continuer line. Consider a shorter synthesis
timeout, or skipping the second LLM call once the provider has just timed out.

**12/13 (SUSPECTED).**
- Bug 12: `matched_requirements` is the three raw JD sentences and `gaps` is empty, so a resume
  with no SQS or observability evidence scores `fit_score: 1.0`.
- Bug 13: a correct solution (6/6 tests, sensible talk-through) produced a "coding round"
  competency of 2.4 "D" with evidence `["empty"]`, a word from the talk-through text. Evidence spans
  across the report are 2-word fragments ("I owned", "I designed").

## Errors and warnings in logs during the run (13:24–13:33 UTC)

- **backend** (`aws-backend-1`): 129 lines in the window, 0 tracebacks, 0 non-2xx responses for
  my traffic.
  - 27 sherpa `Failed to convert '<text>' to token IDs` stderr lines (bug 1). Note that they put
    question and follow-up text, which quotes the candidate's answer, into the log in plaintext.
  - 2 access-log lines containing the WS token (bug 7).
  - JSON warnings: `live_message_failed` and `live_socket_error` ("Cannot call send once a close
    message has been sent"), both from run 1's client closing the socket mid-handler, so
    test-client induced. After the close, the handler's failure is logged with the generic code
    `failed`.
- **caddy**: startup-only `HTTP/2`/`HTTP/3 skipped … requires TLS` on :80 (benign), plus one
  `request declared a Content-Length of 200000000 but only wrote 2 bytes` at 13:18:46. That was
  before my run, from another tester's 413 probes.
- **web** (`aws-web-1`): 2 × `Server Reference ID did not match the expected format` (before my
  run; looks like scanner traffic posting bogus server-action IDs). Nothing during my run.
- **Scanner noise** (not mine): `/.ssh/id_rsa`, `/wp-admin/…` and similar return 404 from the
  backend, which is fine.

## Test users created (all completed one session each)

| email | session | state |
|---|---|---|
| smoketest+e2e1793971489@example.com | 43d3257b-602e-47ce-a74e-efef797a519f | COMPLETED |
| smoketest+e2e1793971714@example.com | 117c4f5c-0131-49c8-99ab-10dbdffc1019 | COMPLETED |
| smoketest+e2e1793971909@example.com | a213ced9-9c63-4d07-8c16-4a4f7c68a275 | COMPLETED |

The passcode is the fixed test value in `smoke_prod.py`. Each run of the script creates one more
`smoketest+e2e<unix-ts>@example.com` user.

## Not covered

- Admin views: there is no admin account, and admins are operator-provisioned only.
- Google OAuth and passcode reset email delivery.
- Spoken follow-up over WS (`submit_follow_up_audio`) and WS `transcribe_audio`.
- The budget-exhausted `session_complete` path, because the script pins budget 4 and goes to
  coding before spending it.
- Clipboard paste events and focus events.

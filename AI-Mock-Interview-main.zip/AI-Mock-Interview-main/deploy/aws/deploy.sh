#!/usr/bin/env bash
# One-command production deploy, run from your machine (not the instance).
#
#   deploy/aws/deploy.sh                 # package -> upload -> bootstrap -> wait -> smoke
#   deploy/aws/deploy.sh --package-only  # build + check the tarball locally and stop (no AWS)
#
# Steps, each of which must succeed or the script exits non-zero:
#   1. package the source (same excludes as before; see `package` below)
#   2. upload src.tgz + bootstrap.sh to the deploy bucket
#   3. start bootstrap.sh on the instance through SSM (in the background there,
#      so the SSM command does not hit its output/time limits)
#   4. poll the instance, streaming new lines of the bootstrap log, until it exits
#   5. run deploy/aws/smoke_prod.py --strict against the public URLs
# On failure it prints the rollback command (images tagged :previous by
# bootstrap.sh before it built). Never prints secret values.
#
# Needs: aws CLI v2 with a current login (`aws login --profile varun-kumar`),
# tar, python3, uv. Environment overrides: AWS_PROFILE, AWS_REGION,
# DEPLOY_BUCKET, MIA_INSTANCE_NAME, MIA_API_URL, MIA_WEB_URL, MIA_DEPLOY_TIMEOUT
# (seconds, default 3600), MIA_SMOKE_ARGS (extra smoke_prod.py args).
set -Eeuo pipefail

export AWS_PROFILE="${AWS_PROFILE:-varun-kumar}"
export AWS_REGION="${AWS_REGION:-ap-southeast-2}"
export AWS_PAGER=""
BUCKET="${DEPLOY_BUCKET:-mia-deploy-727266258830-apse2}"
INSTANCE_NAME="${MIA_INSTANCE_NAME:-mia-app}"
API_URL="${MIA_API_URL:-https://api.13-54-189-166.sslip.io}"
WEB_URL="${MIA_WEB_URL:-https://app.13-54-189-166.sslip.io}"
TIMEOUT="${MIA_DEPLOY_TIMEOUT:-3600}"
POLL_SECONDS=20

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
WORK="$(mktemp -d "${TMPDIR:-/tmp}/mia-deploy.XXXXXX")"
trap 'rm -rf "$WORK"' EXIT

DEPLOY_ID="$(date -u +%Y%m%dT%H%M%SZ)"
REMOTE_LOG="/var/log/mia-deploy-${DEPLOY_ID}.log"
REMOTE_RC="/var/log/mia-deploy-${DEPLOY_ID}.rc"
IID=""
STAGE="start"

say() { printf '\n== [%s] %s\n' "$(date +%H:%M:%S)" "$*"; }

rollback_hint() {
  local iid="${IID:-<instance-id>}"
  cat >&2 <<EOF

DEPLOY FAILED at stage: ${STAGE}

To roll back to the images that were running before this deploy (tagged
:previous by bootstrap.sh; DB migrations are NOT rolled back):

  aws ssm send-command --instance-ids ${iid} --document-name AWS-RunShellScript --parameters \\
    'commands=["cd /opt/mia/src && MIA_IMAGE_TAG=previous docker compose -f deploy/aws/docker-compose.prod.yml --env-file /opt/mia/host.env up -d --no-build --wait backend web"]'

Bootstrap log on the instance: ${REMOTE_LOG}
EOF
}
fail() {
  echo "error: $*" >&2
  exit 1
}
on_error() {
  local rc=$?
  [ "$STAGE" = "package" ] || [ "$STAGE" = "preflight" ] || rollback_hint
  exit "$rc"
}
trap on_error ERR

# ------------------------------------------------------------- 1. package
package() {
  STAGE="package"
  say "packaging source"
  # Same set and excludes the README has always used. tests/ stays out of the
  # image; models/sherpa-onnx-whisper-* is the old ASR model nothing selects.
  ( cd "$ROOT" && tar czf "$WORK/src.tgz" --exclude=node_modules --exclude=.venv --exclude=.git --exclude=.next \
      --exclude=__pycache__ --exclude='*.pyc' --exclude='*.log' --exclude='*.egg-info' \
      --exclude=.env --exclude='.env.*' --exclude=uploads --exclude='models/sherpa-onnx-whisper-*' \
      --exclude='*.tsbuildinfo' --exclude=tests \
      package.json package-lock.json apps agents packages mcp-servers backend deploy models )
  # The image build depends on these; catch a bad tarball here, not on the host.
  local listing
  listing="$(tar tzf "$WORK/src.tgz")"
  for required in backend/requirements.lock deploy/aws/bootstrap.sh deploy/aws/backup.sh \
                  deploy/aws/Caddyfile deploy/aws/docker-compose.prod.yml \
                  models/vits-piper-en_US-amy-low/en_US-amy-low.onnx; do
    grep -qxF "$required" <<<"$listing" || fail "tarball is missing $required"
  done
  if grep -qE '(^|/)\.env($|\.)' <<<"$listing"; then
    fail "tarball contains a .env file; refusing to upload it"
  fi
  echo "src.tgz: $(du -h "$WORK/src.tgz" | cut -f1)"
}

# json array of shell commands for AWS-RunShellScript
ssm_params() {
  python3 -c 'import json,sys; print(json.dumps({"commands": sys.argv[1:]}))' "$@"
}

# Runs commands on the instance and prints their stdout. Waits for completion.
ssm_run() {
  local params cid status
  params="$(ssm_params "$@")"
  cid="$(aws ssm send-command --instance-ids "$IID" --document-name AWS-RunShellScript \
          --timeout-seconds 600 --parameters "$params" --query Command.CommandId --output text)"
  # `wait command-executed` exits non-zero when the command fails, which is
  # information we want to read rather than abort on.
  aws ssm wait command-executed --command-id "$cid" --instance-id "$IID" 2>/dev/null || true
  status="$(aws ssm get-command-invocation --command-id "$cid" --instance-id "$IID" --query Status --output text)"
  aws ssm get-command-invocation --command-id "$cid" --instance-id "$IID" --query StandardOutputContent --output text
  [ "$status" = "Success" ] || { echo "SSM command $cid ended: $status" >&2; return 1; }
}

main() {
  local package_only=0
  for arg in "$@"; do
    case "$arg" in
      --package-only) package_only=1 ;;
      -h|--help) sed -n '2,22p' "${BASH_SOURCE[0]}"; exit 0 ;;
      *) fail "unknown argument: $arg" ;;
    esac
  done

  STAGE="preflight"
  for tool in tar python3; do command -v "$tool" >/dev/null || fail "$tool not found"; done
  if [ "$package_only" = 0 ]; then
    for tool in aws uv; do command -v "$tool" >/dev/null || fail "$tool not found"; done
    aws sts get-caller-identity --query Account --output text >/dev/null \
      || fail "AWS credentials missing or expired: run 'aws login --profile $AWS_PROFILE'"
  fi

  package
  if [ "$package_only" = 1 ]; then
    local out="${MIA_PACKAGE_OUT:-${TMPDIR:-/tmp}/mia-src-${DEPLOY_ID}.tgz}"
    cp "$WORK/src.tgz" "$out"
    echo "wrote $out (not uploaded)"
    trap - ERR
    return 0
  fi

  # ------------------------------------------------------------ 2. upload
  STAGE="upload"
  IID="$(aws ec2 describe-instances --filters "Name=tag:Name,Values=${INSTANCE_NAME}" Name=instance-state-name,Values=running \
          --query 'Reservations[0].Instances[0].InstanceId' --output text)"
  [ -n "$IID" ] && [ "$IID" != "None" ] || fail "no running instance tagged Name=${INSTANCE_NAME}"
  say "uploading to s3://${BUCKET} (instance ${IID})"
  aws s3 cp "$WORK/src.tgz" "s3://${BUCKET}/src.tgz" --only-show-errors
  aws s3 cp "$ROOT/deploy/aws/bootstrap.sh" "s3://${BUCKET}/bootstrap.sh" --only-show-errors

  # --------------------------------------------------------- 3. bootstrap
  STAGE="bootstrap"
  say "starting bootstrap on ${IID} (deploy ${DEPLOY_ID})"
  ssm_run \
    "export DEPLOY_BUCKET=${BUCKET} AWS_REGION=${AWS_REGION}" \
    "aws s3 cp s3://${BUCKET}/bootstrap.sh /tmp/bootstrap.sh --only-show-errors" \
    "ln -sf ${REMOTE_LOG} /var/log/mia-deploy.log" \
    "nohup bash -c 'bash /tmp/bootstrap.sh > ${REMOTE_LOG} 2>&1; echo \$? > ${REMOTE_RC}' > /dev/null 2>&1 &" \
    "echo started" >/dev/null

  # ----------------------------------------------------- 4. wait + stream
  local seen=0 started out rc="" lines
  started="$(date +%s)"
  while :; do
    sleep "$POLL_SECONDS"
    # New lines since the last poll (capped, and cut wide, so one poll stays
    # well inside SSM's 24 KB output limit), then the line count and exit code.
    out="$(ssm_run \
      "tail -n +$((seen + 1)) ${REMOTE_LOG} 2>/dev/null | head -n 150 | cut -c1-240" \
      "echo __LINES__ \$(wc -l < ${REMOTE_LOG} 2>/dev/null || echo 0)" \
      "[ -f ${REMOTE_RC} ] && echo __RC__ \$(cat ${REMOTE_RC}) || true")" || { echo "(poll failed; retrying)" >&2; continue; }
    grep -vE '^__(LINES|RC)__ ' <<<"$out" | sed '/^$/d' || true
    lines="$(sed -n 's/^__LINES__ //p' <<<"$out")"
    rc="$(sed -n 's/^__RC__ //p' <<<"$out")"
    # Advance by what was actually printed (at most 150), not the total, so a
    # burst of output is streamed over several polls rather than skipped.
    if [ -n "$lines" ]; then
      seen=$(( lines < seen + 150 ? lines : seen + 150 ))
    fi
    if [ -n "$rc" ] && [ "${lines:-0}" -le "$seen" ]; then
      break
    fi
    if [ $(( $(date +%s) - started )) -gt "$TIMEOUT" ]; then
      fail "bootstrap still running after ${TIMEOUT}s (log: ${REMOTE_LOG})"
    fi
  done
  if [ "$rc" != "0" ]; then
    # bootstrap.sh prints container state and the last backend log lines on
    # failure; show the end of the log again in case it scrolled past.
    say "bootstrap exited ${rc}; last 80 lines of ${REMOTE_LOG}:"
    ssm_run "tail -n 80 ${REMOTE_LOG} | cut -c1-240" || true
    fail "bootstrap failed (exit ${rc})"
  fi

  # ------------------------------------------------------------ 5. smoke
  STAGE="smoke"
  say "running smoke_prod.py --strict against ${API_URL}"
  # shellcheck disable=SC2086  # MIA_SMOKE_ARGS is a deliberate word list
  ( cd "$ROOT" && uv run --quiet --with httpx --with websockets deploy/aws/smoke_prod.py --strict \
      --api "$API_URL" --web "$WEB_URL" \
      --answer-wav deploy/aws/notes/fixtures/answer16k.wav ${MIA_SMOKE_ARGS:-} )

  STAGE="done"
  trap - ERR
  say "DEPLOY OK (${DEPLOY_ID}). The smoke run created one smoketest+<ts>@example.com user; delete it when convenient."
}

main "$@"

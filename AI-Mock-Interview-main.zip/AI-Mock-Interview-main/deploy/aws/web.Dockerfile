# Build context: the repository root.
# NEXT_PUBLIC_GATEWAY_URL is inlined into the client bundle at build time, so
# it has to be a build arg, not a runtime variable.

# Pinned: >= 26.12.1 is required (CVE-2026-111497, Brotli decoder RCE).
# Digest-pinned too (same index digest as backend.Dockerfile's node stage).
FROM node:26.13.0-slim@sha256:5adad64f9a1fca2d51972caa65983634c8a774eb300d72b20f7f2a0f60368072

ENV NEXT_TELEMETRY_DISABLED=1
WORKDIR /app

COPY package.json package-lock.json ./
COPY apps ./apps
COPY packages ./packages
COPY agents ./agents
COPY mcp-servers ./mcp-servers

RUN npm ci --workspace @mia/web --include-workspace-root

ARG NEXT_PUBLIC_GATEWAY_URL
ENV NEXT_PUBLIC_GATEWAY_URL=${NEXT_PUBLIC_GATEWAY_URL}
RUN npm run build --workspace @mia/web

USER node
EXPOSE 3000
CMD ["npm", "run", "start", "--workspace", "@mia/web"]

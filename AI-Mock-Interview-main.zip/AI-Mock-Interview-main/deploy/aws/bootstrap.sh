#!/usr/bin/env bash
# Runs ON the EC2 instance (Amazon Linux 2023), as root, via SSM Run Command.
# Installs Docker, pulls the source tarball + secrets, builds, migrates, starts.
# Re-runnable: it redeploys whatever is currently in S3 / Secrets Manager, and
# every host-config step below is idempotent (it changes nothing the second time).
#
# Normally started by deploy/aws/deploy.sh, which waits for it and then runs the
# production smoke test. Ends with "BOOTSTRAP OK" on success.
set -Eeuo pipefail

REGION="${AWS_REGION:-ap-southeast-2}"
BUCKET="${DEPLOY_BUCKET:?DEPLOY_BUCKET not set}"
SECRET_ID="${SECRET_ID:-mia/prod-env}"
export AWS_DEFAULT_REGION="$REGION"

# Pinned CLI plugins (audit P2 #14). sha256 values are the ones published in
# each release's checksums.txt. To bump: change the version, copy the new line.
COMPOSE_VERSION=v5.7.0
COMPOSE_SHA256=7758048ad38e580f22559603312874fec8bb638d021a9e64182385fc17cc12a2
BUILDX_VERSION=v0.38.2
BUILDX_SHA256=7992ec09413b80ff57ba4e081f56fc833d7bac1d5e71143c6c809e7e6065f6d6

log() { echo "== $(date -u +%H:%M:%S) $*"; }

# ---------------------------------------------------------------- packages
if ! command -v docker >/dev/null; then
  dnf install -y docker tar gzip
fi
command -v jq >/dev/null || dnf install -y jq

# ---------------------------------------------- docker daemon: log rotation
# Without this json-file logs grow until the disk (shared with pgdata) fills
# (audit P1 #7). Options apply to containers created after the change; this
# deploy recreates them. live-restore keeps containers running across a
# daemon restart, so a future change here does not drop live interviews.
DAEMON_JSON='{
  "log-driver": "json-file",
  "log-opts": { "max-size": "10m", "max-file": "5" },
  "live-restore": true
}'
mkdir -p /etc/docker
printf '%s\n' "$DAEMON_JSON" > /etc/docker/daemon.json.new
if cmp -s /etc/docker/daemon.json.new /etc/docker/daemon.json; then
  rm -f /etc/docker/daemon.json.new
else
  log "writing /etc/docker/daemon.json"
  mv /etc/docker/daemon.json.new /etc/docker/daemon.json
  if systemctl is-active --quiet docker; then
    log "daemon.json changed: restarting docker"
    systemctl restart docker
  fi
fi
systemctl enable --now docker

# -------------------------------------- docker compose + buildx (pinned)
# CLI plugins, not in the AL2023 repos. Replaced whenever the installed binary
# is not the pinned one; a checksum mismatch aborts the deploy.
install_plugin() {  # name url sha256
  local dest="$PLUGINS/$1" tmp
  if [ -x "$dest" ] && echo "$3  $dest" | sha256sum -c --status; then
    return 0
  fi
  log "installing $1 from $2"
  tmp=$(mktemp)
  curl -fsSL "$2" -o "$tmp"
  if ! echo "$3  $tmp" | sha256sum -c --status; then
    rm -f "$tmp"
    echo "checksum mismatch for $1 ($2)" >&2
    exit 1
  fi
  install -m 0755 "$tmp" "$dest"
  rm -f "$tmp"
}
PLUGINS=/usr/local/lib/docker/cli-plugins
mkdir -p "$PLUGINS"
install_plugin docker-compose \
  "https://github.com/docker/compose/releases/download/${COMPOSE_VERSION}/docker-compose-linux-x86_64" "$COMPOSE_SHA256"
install_plugin docker-buildx \
  "https://github.com/docker/buildx/releases/download/${BUILDX_VERSION}/buildx-${BUILDX_VERSION}.linux-amd64" "$BUILDX_SHA256"

# ----------------------------------------------------------------- swap
# Headroom for the Next.js build and Whisper model load. In /etc/fstab so it
# survives a reboot (audit P2 #15).
if [ ! -f /swapfile ]; then
  fallocate -l 4G /swapfile && chmod 600 /swapfile && mkswap /swapfile
fi
swapon --show | grep -q /swapfile || swapon /swapfile
grep -qE '^/swapfile\s' /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab

# --------------------------------------------------------- source + secrets
log "fetching source"
aws s3 cp "s3://${BUCKET}/src.tgz" /tmp/src.tgz --only-show-errors
rm -rf /opt/mia/src && mkdir -p /opt/mia/src
tar xzf /tmp/src.tgz -C /opt/mia/src && rm -f /tmp/src.tgz

(
  umask 077
  SECRET=$(aws secretsmanager get-secret-value --secret-id "$SECRET_ID" --query SecretString --output text)
  echo "$SECRET" | jq -r '.["prod.env"]' > /opt/mia/prod.env
  echo "$SECRET" | jq -r '.["host.env"]' > /opt/mia/host.env
)

cd /opt/mia/src
DC="docker compose -f deploy/aws/docker-compose.prod.yml --env-file /opt/mia/host.env"

# On any failure from here on, show why the backend is not up: its state and
# its last log lines (the app's own logs; prod.env values are never echoed by
# this script, and the backend's config errors name keys, not values).
on_failure() {
  local rc=$?
  echo "BOOTSTRAP FAILED (exit $rc)" >&2
  echo "--- container state" >&2
  $DC ps -a >&2 || true
  echo "--- last 60 backend log lines" >&2
  $DC logs --no-color --tail 60 backend >&2 || true
  exit "$rc"
}
trap on_failure ERR

# ------------------------------------------------- nightly backup (systemd)
install -m 0755 deploy/aws/backup.sh /usr/local/sbin/mia-backup
cat > /etc/systemd/system/mia-backup.service <<EOF
[Unit]
Description=Mock-Interview AI nightly backup (pg_dump + uploads to S3)
After=docker.service
Requires=docker.service

[Service]
Type=oneshot
Environment=DEPLOY_BUCKET=${BUCKET} AWS_REGION=${REGION}
ExecStart=/usr/local/sbin/mia-backup
EOF
cat > /etc/systemd/system/mia-backup.timer <<'EOF'
[Unit]
Description=Run mia-backup nightly

[Timer]
# 17:30 UTC = 03:30 AEST / 04:30 AEDT, outside interview hours.
OnCalendar=*-*-* 17:30:00 UTC
RandomizedDelaySec=10m
Persistent=true

[Install]
WantedBy=timers.target
EOF
systemctl daemon-reload
systemctl enable --now mia-backup.timer

# ---------------------------------------------------- rollback point
# Tag the images the *running* containers use as :previous, before building
# over :latest. `deploy.sh` prints the command that switches back to them.
for svc in backend web; do
  cid=$($DC ps -q "$svc" 2>/dev/null || true)
  if [ -n "$cid" ]; then
    img=$(docker inspect --format '{{.Image}}' "$cid")
    docker tag "$img" "aws-${svc}:previous"
    log "tagged running aws-${svc} image as aws-${svc}:previous"
  fi
done

# -------------------------------------------------------- build + migrate
# Build first: the old containers keep serving until `up -d` swaps them.
log "building images"
$DC build

# Validate the new Caddyfile with the pinned Caddy before it goes live. The
# live path must exist as a FILE first, or the bind mount creates a directory.
touch /opt/mia/Caddyfile
log "validating Caddyfile"
$DC run --rm --no-deps -T -v "$PWD/deploy/aws/Caddyfile:/tmp/Caddyfile.new:ro" caddy \
  caddy validate --config /tmp/Caddyfile.new --adapter caddyfile
# Rewrite in place (same inode) so the running container sees the new file.
CADDY_CHANGED=0
cmp -s deploy/aws/Caddyfile /opt/mia/Caddyfile || CADDY_CHANGED=1
cat deploy/aws/Caddyfile > /opt/mia/Caddyfile

$DC up -d postgres redis
log "running migrations"
$DC run --rm backend python -m app.storage.migrate

# Waits for the healthchecks (caddy depends on web + backend being healthy),
# so a backend that exits at boot fails the deploy here.
log "starting services"
$DC up -d --wait --wait-timeout 300
if [ "$CADDY_CHANGED" = 1 ]; then
  log "reloading Caddy config"
  $DC exec -T caddy caddy reload --config /etc/caddy/Caddyfile --adapter caddyfile
fi
$DC ps
trap - ERR
log "BOOTSTRAP OK"

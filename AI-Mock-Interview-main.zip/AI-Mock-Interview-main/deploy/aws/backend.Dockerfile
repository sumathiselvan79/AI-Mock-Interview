# Build context: the repository root (see docker-compose.prod.yml).
#
# The backend resolves every relative path (models/, uploads/, the coding
# sandbox bootstrap) against the *repository root* (backend/app/paths.py), so
# the image keeps the repo layout under /app:
#   /app/backend  /app/agents/coding-agent/src  /app/models  /app/uploads
#
# Base images are pinned by tag AND digest: a rebuild with no code change must
# not change behaviour. Bump them on purpose (resolve a new digest with
# `docker buildx imagetools inspect <image:tag>`), never by accident.

# Pinned: >= 26.12.1 is required (CVE-2026-111497, Brotli decoder RCE).
FROM node:26.13.0-slim@sha256:5adad64f9a1fca2d51972caa65983634c8a774eb300d72b20f7f2a0f60368072 AS node

FROM python:3.12.16-slim-trixie@sha256:4840d514c583a4d3d8cad3940e68dee6f0f6f3635c12fcd0a3d74c21a5b93a54

ENV PYTHONUNBUFFERED=1 \
    PIP_NO_CACHE_DIR=1 \
    PIP_DISABLE_PIP_VERSION_CHECK=1 \
    HF_HOME=/opt/hf

RUN apt-get update \
 && apt-get install -y --no-install-recommends libgomp1 libstdc++6 libatomic1 curl \
 && rm -rf /var/lib/apt/lists/*

# Node is only here to run the coding round's sandbox (agents/coding-agent).
COPY --from=node /usr/local/bin/node /usr/local/bin/node
RUN ldd /usr/local/bin/node | grep -i 'not found' || true; node -v

WORKDIR /app/backend

# Dependencies first, from the hashed lock (backend/requirements.lock, made by
# `uv pip compile` for Linux x86_64 / CPython 3.12 / extras speech+llm). This
# is the exact set that passes the backend smoke gate; `pip install -e .` on
# the bare ranges in pyproject.toml is what shipped sherpa-onnx 2.x and broke
# TTS. --require-hashes makes pip refuse anything the lock did not name.
COPY backend/requirements.lock ./
RUN pip install --require-hashes --no-deps -r requirements.lock \
 && pip install --no-deps \
      "en_core_web_sm @ https://github.com/explosion/spacy-models/releases/download/en_core_web_sm-3.8.0/en_core_web_sm-3.8.0-py3-none-any.whl#sha256=1932429db727d4bff3deed6b34cfc05df17794f4a52eeb26cf8928f7c1a0fb85" \
 && python -c "from faster_whisper import WhisperModel; WhisperModel('tiny.en', device='cpu', compute_type='int8')"

COPY backend/pyproject.toml ./
COPY backend/app ./app
COPY backend/mcp_schemas ./mcp_schemas
COPY backend/migrations ./migrations

# The project itself, with --no-deps: every dependency already came from the
# lock above. Editable so REPO_ROOT (paths.py) stays /app, not site-packages.
# `pip check` fails the build if pyproject.toml's ranges and the lock disagree.
RUN pip install --no-deps -e . && pip check

COPY agents/coding-agent/src /app/agents/coding-agent/src
COPY models /app/models

# Build-time voice smoke: a TTS stack that returns no audio fails the BUILD,
# not the first interview. Exercises the real provider on the shipped model.
RUN python -c "\
import asyncio; \
from app.tools.speech_service.sherpa_provider import SherpaSpeechProvider; \
p = SherpaSpeechProvider.create(model_dir='/app/models', num_threads=1, skip_warmup=True); \
assert p is not None, 'TTS model files missing under /app/models'; \
r = asyncio.run(p.synthesize('Ready.')); \
assert r.sample_rate > 0 and r.duration_ms > 0 and len(r.audio) > 44, (r.sample_rate, r.duration_ms, len(r.audio)); \
print('voice smoke ok:', r.sample_rate, 'Hz,', r.duration_ms, 'ms')"

# Default to production so a container started without prod.env fails closed
# at boot (load_config refuses a missing STORAGE_DRIVER/FRONTEND_URL/... in
# production, impl-security.md A4/A6) instead of booting a dev config.
# prod.env sets it too. Set after the build-time RUN steps on purpose.
ENV NODE_ENV=production

RUN useradd --uid 10001 --create-home app \
 && mkdir -p /app/uploads \
 && chown -R app:app /app/uploads /opt/hf
USER app

EXPOSE 4000
HEALTHCHECK --interval=30s --timeout=5s --start-period=60s --retries=3 \
  CMD curl -fsS http://127.0.0.1:4000/health || exit 1

# --no-access-log: uvicorn's access log prints the full request line, and the
# live channel carries the bearer token as `?token=` (WebSocket API cannot set
# headers). The app's own structured logs (app/logging_.py) are unaffected.
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "4000", "--no-access-log"]

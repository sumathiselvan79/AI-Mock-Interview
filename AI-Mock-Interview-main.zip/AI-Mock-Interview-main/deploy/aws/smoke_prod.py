#!/usr/bin/env python3
"""End-to-end production smoke test for the Mock-Interview AI deployment.

Drives one full student journey the way the browser does (same routes, same
order, an `Origin` header on every request) and prints a PASS/FAIL table.
Exits non-zero if any required step fails.

    uv run --with httpx --with websockets deploy/aws/smoke_prod.py \
        --api https://api.13-54-189-166.sslip.io \
        --web https://app.13-54-189-166.sslip.io \
        [--answer-wav deploy/aws/notes/fixtures/answer16k.wav] [--budget 4]

Journey: health -> CORS preflight -> register -> login -> create session ->
resume upload (JD fit) -> jd-fit read -> CONFIG -> TELEMETRY_CHECK ->
telemetry/consent -> begin -> 2 turns over the WebSocket live channel ->
REST turn with silence (expects no_speech refusal) and a spoken WAV (expects
transcription) -> REST typed turn + repeat-request (meta utterance) -> TTS
audio fetch -> coding round + submission -> wrap-up -> report -> report read
-> /me/stats.

Creates one user `smoketest+<unix-ts>@example.com`. Prints no secrets; the
bearer token is never printed.

"WARN" rows are checks that the journey survives but that indicate a
degraded production (an LLM-backed field fell back to its deterministic
path, a grade-band inconsistency). They do not fail the run unless --strict.
Question TTS returning no audio is a FAIL: every question is meant to be spoken.
"""

from __future__ import annotations

import argparse
import asyncio
import base64
import io
import json
import struct
import sys
import time
import wave
from dataclasses import dataclass, field
from typing import Any, Optional

import httpx
import websockets

RESUME = """Jordan Rivera
Backend Software Engineer | jordan.rivera@example.com

SUMMARY
Backend engineer with 4 years building Python and Go services on AWS.

EXPERIENCE
Software Engineer, Parcelwise Logistics (2022 - present)
- Built a FastAPI order-tracking service backed by PostgreSQL serving 2,000 requests per second.
- Added composite indexes and query rewrites that cut p95 latency from 420 ms to 35 ms.
- Introduced Redis caching for shipment lookups, reducing database load by 60 percent.
- Designed an event pipeline on Kafka with idempotent consumers and a dead-letter queue.
- Led migration from a monolith to three services deployed on ECS with Terraform.

Junior Developer, Brightline Apps (2020 - 2022)
- Wrote REST APIs in Node.js and Express; added JWT authentication and rate limiting.
- Set up CI with GitHub Actions running pytest and integration tests against Docker Compose.

SKILLS
Python, Go, JavaScript, PostgreSQL, Redis, Kafka, Docker, AWS (ECS, RDS, S3), Terraform, system design

EDUCATION
B.Sc. Computer Science, State University, 2020
"""

JOB_DESCRIPTION = (
    "We are hiring a Backend Engineer to design and operate high-traffic APIs. "
    "Requirements: strong Python or Go, PostgreSQL schema design and query tuning, "
    "caching with Redis, message queues (Kafka or SQS), REST API design, "
    "observability, and experience deploying containerised services on AWS. "
    "Nice to have: system design for distributed systems, Terraform."
)

ANSWERS = [
    "At Parcelwise I owned the order-tracking API. The p95 latency was around 420 milliseconds because "
    "the main lookup did a sequential scan on a 40 million row table. I used EXPLAIN ANALYZE, added a "
    "composite index on customer_id and created_at, and rewrote an OR condition into a UNION. That brought "
    "p95 down to about 35 milliseconds. The trade-off was slower writes, so I measured insert throughput "
    "before and after and it dropped by about 5 percent, which was acceptable.",
    "For caching shipment lookups I used Redis with a cache-aside pattern and a five minute TTL. The hard "
    "part was invalidation: when a shipment status changed, the consumer that wrote to Postgres also "
    "deleted the key, and I added a short jittered TTL to avoid a thundering herd. Database load dropped by "
    "about 60 percent. If I did it again I would add request coalescing so concurrent misses only hit the "
    "database once.",
    "Our Kafka consumers had to be idempotent because the producer could retry. Each event carried an event "
    "id and we stored processed ids in a Postgres table with a unique constraint inside the same "
    "transaction as the write, so a duplicate simply failed the insert and was skipped. Poison messages "
    "went to a dead-letter topic after three attempts with exponential backoff, and we alerted on its lag.",
    "When we split the monolith I started with the strangler pattern: put a routing layer in front, moved "
    "the tracking endpoints first because they had the clearest boundary, and kept the shared database "
    "read-only for the new service until we had migrated its tables. Each service deployed on ECS through "
    "Terraform, and we used contract tests so the remaining monolith could not break the new API.",
]

FOLLOW_UP_ANSWER = (
    "Concretely, I would measure it first: add a metric for cache hit ratio and p99 latency per endpoint, "
    "then load test with realistic traffic. If the hit ratio was below about 80 percent I would revisit the "
    "key design before adding more capacity."
)

CODING_SOLUTIONS = {
    "rate-limiter": """
function allow(events, limit, windowMs) {
  const out = [];
  let windowStart = null;
  let count = 0;
  for (const t of events) {
    if (windowStart === null || t - windowStart >= windowMs) { windowStart = t; count = 0; }
    count += 1;
    out.push(count <= limit);
  }
  return out;
}
""",
    "merge-intervals": """
function merge(intervals) {
  const sorted = [...intervals].sort((a, b) => a[0] - b[0]);
  const out = [];
  for (const [s, e] of sorted) {
    const last = out[out.length - 1];
    if (last && s <= last[1]) last[1] = Math.max(last[1], e);
    else out.push([s, e]);
  }
  return out;
}
""",
    "retry-backoff": """
function schedule(attempts, baseMs, capMs) {
  const out = [];
  for (let n = 0; n < attempts; n++) out.push(Math.min(baseMs * (2 ** n), capMs));
  return out;
}
""",
    "dedupe-events": """
function dedupe(events) {
  const seen = new Set();
  const out = [];
  for (const e of events) {
    if (seen.has(e.key)) continue;
    seen.add(e.key);
    out.push(e.value);
  }
  return out;
}
""",
}


@dataclass
class Step:
    name: str
    endpoint: str
    status: str
    latency_ms: float
    verdict: str  # PASS | FAIL | WARN | SKIP
    note: str = ""


@dataclass
class Ctx:
    api: str
    web: str
    strict: bool
    budget: int
    answer_wav: Optional[str]
    steps: list[Step] = field(default_factory=list)
    token: str = ""
    session_id: str = ""
    questions: list[dict[str, Any]] = field(default_factory=list)
    llm: dict[str, Any] = field(default_factory=dict)
    email: str = ""


def _short(value: Any, n: int = 160) -> str:
    text = value if isinstance(value, str) else json.dumps(value, default=str)
    return text if len(text) <= n else text[: n - 1] + "…"


def silence_wav(seconds: float = 3.0, rate: int = 16000) -> bytes:
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(b"\x00\x00" * int(rate * seconds))
    return buf.getvalue()


def wav_stats(data: bytes) -> dict[str, Any]:
    """Frames and peak amplitude of a PCM WAV, or an error string."""
    try:
        with wave.open(io.BytesIO(data), "rb") as w:
            frames = w.getnframes()
            raw = w.readframes(frames)
            width = w.getsampwidth()
            peak = 0
            if width == 2 and raw:
                count = len(raw) // 2
                samples = struct.unpack(f"<{count}h", raw[: count * 2])
                peak = max(abs(s) for s in samples) if samples else 0
            return {"frames": frames, "rate": w.getframerate(), "seconds": round(frames / max(1, w.getframerate()), 2), "peak": peak}
    except Exception as err:  # noqa: BLE001
        return {"error": str(err)}


class Runner:
    def __init__(self, ctx: Ctx) -> None:
        self.ctx = ctx
        self.client = httpx.Client(
            base_url=ctx.api,
            timeout=httpx.Timeout(240.0, connect=15.0),
            headers={"Origin": ctx.web, "content-type": "application/json"},
        )

    # ------------------------------------------------------------ helpers
    def record(self, name: str, endpoint: str, status: Any, latency_ms: float, verdict: str, note: str = "") -> None:
        if verdict == "WARN" and self.ctx.strict:
            verdict = "FAIL"
        self.ctx.steps.append(Step(name, endpoint, str(status), latency_ms, verdict, note))
        print(f"[{verdict:4}] {name:34} {endpoint:48} {status!s:>5} {latency_ms:8.0f}ms  {note}", flush=True)

    def call(self, method: str, path: str, **kwargs: Any) -> tuple[httpx.Response, float]:
        headers = kwargs.pop("headers", {})
        if self.ctx.token:
            headers.setdefault("authorization", f"Bearer {self.ctx.token}")
        started = time.perf_counter()
        response = self.client.request(method, path, headers=headers, **kwargs)
        return response, (time.perf_counter() - started) * 1000

    def step(self, name: str, method: str, path: str, expect: tuple[int, ...], **kwargs: Any) -> Optional[dict[str, Any]]:
        try:
            r, ms = self.call(method, path, **kwargs)
        except Exception as err:  # noqa: BLE001
            self.record(name, f"{method} {self._templ(path)}", "EXC", 0, "FAIL", _short(repr(err)))
            return None
        body: Any
        try:
            body = r.json() if r.content else {}
        except ValueError:
            body = {"_raw": r.text[:200]}
        ok = r.status_code in expect
        note = "" if ok else _short(body)
        self.record(name, f"{method} {self._templ(path)}", r.status_code, ms, "PASS" if ok else "FAIL", note)
        if isinstance(body, dict):
            body["_status"] = r.status_code
            body["_ms"] = ms
            body["_cors"] = r.headers.get("access-control-allow-origin")
        return body if ok else None

    def _templ(self, path: str) -> str:
        return path.replace(self.ctx.session_id, "{id}") if self.ctx.session_id else path

    # -------------------------------------------------------------- steps
    def run(self) -> None:
        c = self.ctx
        self.step("health", "GET", "/health", (200,))

        # CORS preflight exactly as the browser sends it.
        try:
            r, ms = self.call(
                "OPTIONS",
                "/auth/register",
                headers={"Access-Control-Request-Method": "POST", "Access-Control-Request-Headers": "content-type,authorization"},
            )
            allow = r.headers.get("access-control-allow-origin")
            ok = r.status_code in (200, 204) and allow == c.web
            self.record("cors_preflight", "OPTIONS /auth/register", r.status_code, ms, "PASS" if ok else "FAIL", f"allow-origin={allow}")
        except Exception as err:  # noqa: BLE001
            self.record("cors_preflight", "OPTIONS /auth/register", "EXC", 0, "FAIL", repr(err))

        c.email = f"smoketest+e2e{int(time.time())}@example.com"
        passcode = "smoke-test-passcode-2026"
        reg = self.step(
            "register",
            "POST",
            "/auth/register",
            (201,),
            json={"email": c.email, "passcode": passcode, "full_name": "Smoke Test E2E", "department": "QA", "program_year": "2026"},
        )
        if not reg:
            return
        login = self.step("login", "POST", "/auth/login", (200,), json={"email": c.email, "passcode": passcode})
        if not login:
            return
        c.token = login["token"]
        self.step("me_profile", "GET", "/me/profile", (200,))

        # The browser sends role + job_description only (budget defaults to 8);
        # this script pins a smaller budget so a run stays a few minutes long.
        created = self.step(
            "create_session",
            "POST",
            "/sessions",
            (201,),
            json={"role": "Backend Engineer", "job_description": JOB_DESCRIPTION, "question_budget": c.budget},
        )
        if not created:
            return
        c.session_id = created["session_id"]
        sid = c.session_id

        up = self.step(
            "resume_upload_jd_fit",
            "POST",
            f"/sessions/{sid}/resume",
            (201,),
            json={"filename": "jordan-rivera-resume.txt", "content_type": "text/plain", "data_base64": base64.b64encode(RESUME.encode()).decode()},
        )
        if up:
            jd = up.get("jd_fit") or {}
            c.llm["jd_fit"] = {
                "prompt_version": jd.get("prompt_version"),
                "has_rationale": bool(jd.get("rationale")),
                "fit_score": jd.get("fit_score"),
                "key_technologies": jd.get("key_technologies"),
                "role_level": jd.get("role_level"),
                "insufficient_signal": jd.get("insufficient_signal"),
                "topic_relevance_n": len(up.get("topic_relevance") or []),
                "latency_ms": round(up["_ms"]),
            }
            llm_ok = bool(jd.get("prompt_version")) and bool(jd.get("rationale"))
            self.record(
                "jd_fit_llm_generated",
                "(resume upload response)",
                "-",
                up["_ms"],
                "PASS" if llm_ok else "WARN",
                f"prompt_version={jd.get('prompt_version')} rationale={'yes' if jd.get('rationale') else 'no'} fit={jd.get('fit_score')}",
            )

        self.step("jd_fit_read", "GET", f"/sessions/{sid}/jd-fit", (200,))
        self.step("advance_CONFIG", "POST", f"/sessions/{sid}/advance", (200,), json={"to": "CONFIG"})
        self.step("advance_TELEMETRY_CHECK", "POST", f"/sessions/{sid}/advance", (200,), json={"to": "TELEMETRY_CHECK"})
        tc = self.step(
            "telemetry_check_consent",
            "POST",
            f"/sessions/{sid}/telemetry-check",
            (200,),
            json={
                "mic_ok": True,
                "speaker_ok": True,
                "consent": {"telemetry": True, "clipboard_monitor": True, "audio_recording": False, "cross_session_memory": False, "focus_loss_monitoring": True},
            },
        )
        if tc and tc.get("passed") is not True:
            self.record("telemetry_check_passed", "(response)", "-", 0, "FAIL", _short(tc))

        began = self.step("begin_interview", "POST", f"/sessions/{sid}/begin", (200,))
        if not began:
            return
        plan = began.get("topic_plan") or []
        self.record("topic_plan_built", "(begin response)", "-", began["_ms"], "PASS" if plan else "FAIL", f"{len(plan)} topics, state={began.get('state')}")

        # Two turns over the live channel — the browser's path for typed answers.
        asyncio.run(self.live_turns(2))

        # A REST turn: silence first (must be refused), then real speech.
        q = self.rest_next_question("rest_next_question_3")
        if q:
            self.audio_checks(q)
            self.stt_turn(q)

        # A REST typed turn, preceded by a repeat request (must not be scored).
        q = self.rest_next_question("rest_next_question_4")
        if q:
            meta = self.step("meta_utterance_repeat", "POST", f"/sessions/{sid}/answers", (201,), json={"question_id": q["id"], "transcript": "Sorry, can you repeat that?"})
            if meta is not None and meta.get("answered") is not False:
                self.record("meta_utterance_not_scored", "(response)", "-", 0, "FAIL", "repeat request was scored as an answer")
            ans = self.step("rest_answer_text", "POST", f"/sessions/{sid}/answers", (201,), json={"question_id": q["id"], "transcript": ANSWERS[3]})
            if ans:
                self.note_answer("rest_text", ans)
                if ans.get("follow_up"):
                    self.step(
                        "rest_follow_up_answer",
                        "POST",
                        f"/sessions/{sid}/answers/{ans['answer_id']}/follow-up",
                        (201,),
                        json={"follow_up_text": ans["follow_up"]["text"], "transcript": FOLLOW_UP_ANSWER},
                    )

        self.coding_round()

        wrap = self.step("wrap_up", "POST", f"/sessions/{sid}/wrap-up", (200,))
        if wrap:
            self.record("wrap_up_state", "(response)", "-", 0, "PASS" if wrap.get("state") == "WRAP_UP" else "FAIL", f"state={wrap.get('state')} audio={'yes' if wrap.get('audio_url') else 'no'}")

        rep = self.step("report_generate", "POST", f"/sessions/{sid}/report", (200, 201))
        if rep:
            report = rep.get("report") or {}
            scores = report.get("competencyScores") or report.get("competency_scores") or []
            grade = report.get("overallGrade") or report.get("overall_grade")
            c.llm["report"] = {"competencies": len(scores), "overall_grade": grade, "state": rep.get("state")}
            ok = rep.get("state") == "COMPLETED" and len(scores) > 0
            self.record("report_content", "(report response)", "-", rep["_ms"], "PASS" if ok else "FAIL", f"state={rep.get('state')} competencies={len(scores)} overall={(grade or {}).get('score')}/{(grade or {}).get('letter')}")
            # The same displayed score must never carry two different letters.
            seen_letters: dict[Any, set] = {}
            for g in [s.get("grade") for s in scores] + [grade]:
                if isinstance(g, dict):
                    seen_letters.setdefault(g.get("score"), set()).add(g.get("letter"))
            for a in c.llm.get("answers", []):
                g = a.get("grade")
                if isinstance(g, dict):
                    seen_letters.setdefault(g.get("score"), set()).add(g.get("letter"))
            clash = {k: sorted(v) for k, v in seen_letters.items() if len(v) > 1}
            self.record("grade_bands_consistent", "(report + answers)", "-", 0, "WARN" if clash else "PASS", f"same score, different letter: {clash}" if clash else "")
            c.llm["report"]["competency_scores"] = [(s.get("competency"), s.get("score"), (s.get("grade") or {}).get("letter"), s.get("evidence")) for s in scores]
        self.step("report_read", "GET", f"/sessions/{sid}/report", (200,))
        self.step("transcript_read", "GET", f"/sessions/{sid}/transcript", (200,))
        stats = self.step("me_stats", "GET", "/me/stats", (200,))
        if stats:
            completed = (stats.get("stats") or {}).get("sessionsCompleted")
            self.record("me_stats_counts_session", "(response)", "-", 0, "PASS" if completed == 1 else "FAIL", f"sessionsCompleted={completed}")

    # ---------------------------------------------------------- the turns
    def note_answer(self, label: str, body: dict[str, Any]) -> None:
        ev = body.get("evaluation") or {}
        self.ctx.llm.setdefault("answers", []).append(
            {
                "via": label,
                "score": ev.get("score"),
                "grade": ev.get("grade"),
                "evaluation_note": body.get("evaluation_note"),
                "follow_up": bool(body.get("follow_up")),
                "follow_up_reason": (body.get("follow_up") or {}).get("reason"),
                "ack": (body.get("acknowledgment") or {}).get("text"),
                "next_action": body.get("next_action"),
                "latency_ms": round(body.get("_ms") or 0),
            }
        )
        verdict = "PASS" if ev.get("score") is not None else "WARN"
        self.record(f"{label}_scored", "(answer response)", "-", body.get("_ms") or 0, verdict, f"score={ev.get('score')} grade={ev.get('grade')} follow_up={bool(body.get('follow_up'))} note={_short(body.get('evaluation_note') or '', 60)}")

    def rest_next_question(self, name: str) -> Optional[dict[str, Any]]:
        body = self.step(name, "GET", f"/sessions/{self.ctx.session_id}/questions/next", (200,))
        if not body:
            return None
        if body.get("done"):
            self.record(f"{name}_not_done", "(response)", "-", 0, "FAIL", f"loop ended early: {_short(body)}")
            return None
        q = body["question"]
        q["_ms"] = body["_ms"]
        q["speech_note"] = body.get("speech_note")
        self.ctx.questions.append({"via": "rest", **{k: q.get(k) for k in ("id", "topic", "tier", "type", "audio_url")}, "text": _short(q.get("text"), 120), "latency_ms": round(body["_ms"]), "speech_note": body.get("speech_note")})
        return q

    def audio_checks(self, q: dict[str, Any]) -> None:
        url = q.get("audio_url")
        if not url:
            # Every question is meant to be spoken (CLAUDE.md §1); no audio at all is a failure, not a degradation.
            self.record("tts_question_audio", "(question.audio_url)", "-", 0, "FAIL", f"no audio_url; speech_note={_short(q.get('speech_note') or '', 90)}")
            return
        path = f"/sessions/{self.ctx.session_id}{url}"
        try:
            r, ms = self.call("GET", path)
        except Exception as err:  # noqa: BLE001
            self.record("tts_question_audio", "GET /sessions/{id}/audio/{ref}", "EXC", 0, "FAIL", repr(err))
            return
        stats = wav_stats(r.content) if r.status_code == 200 else {}
        ok = r.status_code == 200 and stats.get("frames", 0) > 1600 and stats.get("peak", 0) > 500
        self.ctx.llm["tts"] = {"status": r.status_code, "bytes": len(r.content), "content_type": r.headers.get("content-type"), "x_speech_provider": r.headers.get("x-speech-provider"), **stats}
        self.record("tts_question_audio", "GET /sessions/{id}/audio/{ref}", r.status_code, ms, "PASS" if ok else "FAIL", f"{len(r.content)}B {stats}")

    def stt_turn(self, q: dict[str, Any]) -> None:
        sid = self.ctx.session_id
        body = self.step(
            "stt_silence_refused",
            "POST",
            f"/sessions/{sid}/answers/audio",
            (202,),
            json={"question_id": q["id"], "audio_base64": base64.b64encode(silence_wav()).decode(), "content_type": "audio/wav", "input_device": {"hint": "microphone"}},
        )
        if body is not None:
            self.record("stt_silence_code", "(response)", "-", 0, "PASS" if body.get("code") == "no_speech_detected" and not body.get("draft_transcript") else "FAIL", f"code={body.get('code')} draft={body.get('draft_transcript')!r}")

        if not self.ctx.answer_wav:
            self.record("stt_speech_answer", "POST /sessions/{id}/answers/audio", "-", 0, "SKIP", "no --answer-wav given")
            ans = self.step("rest_answer_text_q3", "POST", f"/sessions/{sid}/answers", (201,), json={"question_id": q["id"], "transcript": ANSWERS[2]})
            if ans:
                self.note_answer("rest_text_q3", ans)
            return
        with open(self.ctx.answer_wav, "rb") as fh:
            audio = fh.read()
        body = self.step(
            "stt_speech_answer",
            "POST",
            f"/sessions/{sid}/answers/audio",
            (201, 202),
            json={"question_id": q["id"], "audio_base64": base64.b64encode(audio).decode(), "content_type": "audio/wav", "input_device": {"hint": "microphone", "label": "Built-in Microphone", "echo_cancellation": True}},
        )
        if body is None:
            return
        transcript = body.get("transcript") or ""
        accepted = body.get("accepted") is True
        hit = all(word in transcript.lower() for word in ("index", "latency"))
        self.ctx.llm["stt"] = {"accepted": accepted, "code": body.get("code"), "confidence": body.get("transcript_confidence") or body.get("confidence"), "transcript": _short(transcript, 200), "latency_ms": round(body["_ms"])}
        self.record("stt_transcript_quality", "(response)", body["_status"], body["_ms"], "PASS" if accepted and hit else "FAIL", f"accepted={accepted} code={body.get('code')} conf={body.get('transcript_confidence')} text={_short(transcript, 70)!r}")
        if accepted and body.get("answered"):
            self.note_answer("rest_audio", body)
            if body.get("follow_up"):
                self.step(
                    "rest_follow_up_answer_audio_turn",
                    "POST",
                    f"/sessions/{sid}/answers/{body['answer_id']}/follow-up",
                    (201,),
                    json={"follow_up_text": body["follow_up"]["text"], "transcript": FOLLOW_UP_ANSWER},
                )
        elif not accepted:
            ans = self.step("rest_answer_text_q3_fallback", "POST", f"/sessions/{sid}/answers", (201,), json={"question_id": q["id"], "transcript": ANSWERS[2]})
            if ans:
                self.note_answer("rest_text_q3", ans)

    async def live_turns(self, turns: int) -> None:
        sid = self.ctx.session_id
        ws_url = self.ctx.api.replace("https://", "wss://").replace("http://", "ws://") + f"/sessions/{sid}/live?token={self.ctx.token}"
        started = time.perf_counter()
        try:
            ws = await asyncio.wait_for(websockets.connect(ws_url, origin=self.ctx.web, max_size=2**24, open_timeout=20), 30)
        except Exception as err:  # noqa: BLE001
            self.record("ws_connect", "WS /sessions/{id}/live", "EXC", 0, "FAIL", _short(repr(err)))
            return

        async def recv_until(types: set[str], timeout: float = 240.0) -> tuple[Optional[dict[str, Any]], list[dict[str, Any]]]:
            seen: list[dict[str, Any]] = []
            deadline = time.perf_counter() + timeout
            while time.perf_counter() < deadline:
                raw = await asyncio.wait_for(ws.recv(), deadline - time.perf_counter())
                msg = json.loads(raw)
                if msg.get("type") == "timer_tick":
                    continue
                seen.append(msg)
                # The server pushes a question's speech_note as an `error` frame
                # with no `code` (live_channel.py). It is a degraded-TTS notice,
                # not a reply, so it must not end the wait.
                if msg.get("type") == "error" and "code" not in msg:
                    self.ctx.llm.setdefault("ws_speech_notes", []).append(_short(msg.get("message"), 120))
                    continue
                if msg.get("type") in types:
                    return msg, seen
            return None, seen

        try:
            hello, _ = await recv_until({"connected", "error"}, 20)
            ms = (time.perf_counter() - started) * 1000
            self.record("ws_connect", "WS /sessions/{id}/live", "101", ms, "PASS" if hello and hello["type"] == "connected" else "FAIL", _short(hello))

            for turn in range(turns):
                t0 = time.perf_counter()
                await ws.send(json.dumps({"type": "next_question"}))
                msg, seen = await recv_until({"question", "session_complete", "error"})
                ms = (time.perf_counter() - t0) * 1000
                if not msg or msg["type"] != "question":
                    self.record(f"ws_next_question_{turn + 1}", "WS next_question", "-", ms, "FAIL", _short(seen))
                    return
                continuers = [m.get("kind") for m in seen if m["type"] == "continuer"]
                self.ctx.questions.append({"via": "ws", "id": msg.get("id"), "topic": msg.get("topic"), "type": msg.get("question_type"), "audio_url": msg.get("audio_url"), "text": _short(msg.get("text"), 120), "latency_ms": round(ms), "continuers": continuers})
                self.record(f"ws_next_question_{turn + 1}", "WS next_question", "-", ms, "PASS", f"topic={msg.get('topic')} audio={'yes' if msg.get('audio_url') else 'no'} continuers={continuers}")

                t0 = time.perf_counter()
                await ws.send(json.dumps({"type": "submit_answer_text", "question_id": msg["id"], "transcript": ANSWERS[turn]}))
                reply, seen = await recv_until({"question", "follow_up", "clarification", "error"})
                ms = (time.perf_counter() - t0) * 1000
                kinds = [m["type"] for m in seen]
                if not reply or reply["type"] == "error":
                    self.record(f"ws_answer_{turn + 1}", "WS submit_answer_text", "-", ms, "FAIL", _short(seen))
                    return
                ack = next((m.get("text") for m in seen if m["type"] == "acknowledgment"), None)
                entry = {"via": f"ws_{turn + 1}", "frames": kinds, "ack": ack, "latency_ms": round(ms)}
                if reply["type"] == "follow_up":
                    entry["follow_up"] = True
                    entry["follow_up_reason"] = reply.get("reason")
                    self.record(f"ws_answer_{turn + 1}", "WS submit_answer_text", "-", ms, "PASS", f"frames={kinds} follow_up reason={reply.get('reason')}")
                    t0 = time.perf_counter()
                    await ws.send(json.dumps({"type": "submit_follow_up_text", "answer_id": reply["answer_id"], "follow_up_text": reply["text"], "transcript": FOLLOW_UP_ANSWER}))
                    done, seen2 = await recv_until({"question", "error"})
                    ms2 = (time.perf_counter() - t0) * 1000
                    self.record(f"ws_follow_up_{turn + 1}", "WS submit_follow_up_text", "-", ms2, "PASS" if done and done["type"] == "question" else "FAIL", _short([m["type"] for m in seen2]))
                else:
                    ev = reply.get("evaluation") or {}
                    entry.update({"score": ev.get("score"), "grade": ev.get("grade"), "evaluation_note": reply.get("evaluation_note")})
                    verdict = "PASS" if reply["type"] == "question" and reply.get("answered") else "FAIL"
                    self.record(f"ws_answer_{turn + 1}", "WS submit_answer_text", "-", ms, verdict, f"frames={kinds} score={ev.get('score')} grade={ev.get('grade')}")
                self.ctx.llm.setdefault("answers", []).append(entry)
        except Exception as err:  # noqa: BLE001
            self.record("ws_turns", "WS /sessions/{id}/live", "EXC", 0, "FAIL", _short(repr(err)))
        finally:
            await ws.close()

    def coding_round(self) -> None:
        sid = self.ctx.session_id
        # Production turns the round off (CODING_ROUND_ENABLED=false, PATCH_PLAN A2):
        # a 404 whose error code says "disabled" is the flag working, not a failure.
        try:
            r, ms = self.call("POST", f"/sessions/{sid}/coding-round")
        except Exception as err:  # noqa: BLE001
            self.record("coding_round_start", "POST /sessions/{id}/coding-round", "EXC", 0, "FAIL", _short(repr(err)))
            return
        if r.status_code == 404:
            try:
                code = str(((r.json() or {}).get("error") or {}).get("code", ""))
            except ValueError:
                code = ""
            disabled = "disabled" in code
            self.record("coding_round_start", "POST /sessions/{id}/coding-round", 404, ms, "SKIP" if disabled else "FAIL", f"code={code or '-'}" + (" (feature flag off)" if disabled else ""))
            return
        try:
            started = r.json() if r.content else {}
        except ValueError:
            started = {"_raw": r.text[:200]}
        ok = r.status_code == 201 and isinstance(started, dict)
        self.record("coding_round_start", "POST /sessions/{id}/coding-round", r.status_code, ms, "PASS" if ok else "FAIL", "" if ok else _short(started))
        if not ok:
            return
        problem = started.get("problem") or {}
        solution = CODING_SOLUTIONS.get(problem.get("id"))
        if not solution:
            self.record("coding_solution_known", "(problem)", "-", 0, "WARN", f"unknown problem id {problem.get('id')}; submitting a stub")
            solution = f"function {problem.get('entry_point', 'solve')}() {{ return null; }}"
        sub = self.step(
            "coding_submission",
            "POST",
            f"/sessions/{sid}/coding-round/submissions",
            (201,),
            json={"code": solution, "language": "javascript", "talk_through": "I walk the input once and keep only the state I need, handling empty input directly."},
        )
        if sub:
            passed, total = sub.get("passed"), sub.get("total")
            self.ctx.llm["coding"] = {"problem": problem.get("id"), "passed": passed, "total": total, "latency_ms": round(sub["_ms"])}
            self.record("coding_tests_pass", "(submission)", "-", sub["_ms"], "PASS" if total and passed == total else "FAIL", f"{problem.get('id')}: {passed}/{total}")


def print_table(ctx: Ctx) -> None:
    print("\n| # | step | endpoint | status | latency | result | note |")
    print("|---|---|---|---|---|---|---|")
    for i, s in enumerate(ctx.steps, 1):
        print(f"| {i} | {s.name} | `{s.endpoint}` | {s.status} | {s.latency_ms:.0f} ms | {s.verdict} | {s.note.replace('|', '/')} |")
    counts = {v: sum(1 for s in ctx.steps if s.verdict == v) for v in ("PASS", "FAIL", "WARN", "SKIP")}
    print(f"\nuser={ctx.email} session={ctx.session_id}")
    print("summary: " + " ".join(f"{k}={v}" for k, v in counts.items()))
    print("\nquestions:\n" + json.dumps(ctx.questions, indent=1, default=str))
    print("\nllm/speech observations:\n" + json.dumps(ctx.llm, indent=1, default=str))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--api", default="https://api.13-54-189-166.sslip.io")
    parser.add_argument("--web", default="https://app.13-54-189-166.sslip.io")
    parser.add_argument("--answer-wav", default=None, help="16 kHz mono PCM WAV of a spoken answer (enables the STT happy path)")
    parser.add_argument("--budget", type=int, default=4, help="question budget (>=4; the browser default is 8)")
    parser.add_argument("--strict", action="store_true", help="treat WARN (degraded) rows as failures")
    args = parser.parse_args()

    ctx = Ctx(api=args.api.rstrip("/"), web=args.web.rstrip("/"), strict=args.strict, budget=max(4, args.budget), answer_wav=args.answer_wav)
    runner = Runner(ctx)
    try:
        runner.run()
    except Exception as err:  # noqa: BLE001
        runner.record("unhandled", "-", "EXC", 0, "FAIL", _short(repr(err)))
    print_table(ctx)
    return 1 if any(s.verdict == "FAIL" for s in ctx.steps) else 0


if __name__ == "__main__":
    sys.exit(main())

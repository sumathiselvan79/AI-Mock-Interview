#!/usr/bin/env bash
# Nightly backup of everything durable on the host (audit P0 #3).
# Installed by bootstrap.sh as /usr/local/sbin/mia-backup and run by
# mia-backup.timer. Run it by hand the same way: `sudo systemctl start mia-backup`.
#
# Writes, under s3://$DEPLOY_BUCKET/backups/nightly/<UTC timestamp>/:
#   pg.dump      pg_dump -Fc of the `mia` database (restore with pg_restore)
#   uploads.tgz  tarball of the backend's uploads volume
#   SHA256SUMS   checksums of both
# The S3 lifecycle rule in README expires them after 14 days.
#
# Files are written locally and verified before upload, so a failed dump never
# leaves a truncated object in S3 that looks like a good backup.
set -euo pipefail

BUCKET="${DEPLOY_BUCKET:?DEPLOY_BUCKET not set}"
export AWS_DEFAULT_REGION="${AWS_REGION:-ap-southeast-2}"
SRC=/opt/mia/src
DC=(docker compose -f "$SRC/deploy/aws/docker-compose.prod.yml" --env-file /opt/mia/host.env)

TS=$(date -u +%Y%m%dT%H%M%SZ)
DEST="s3://${BUCKET}/backups/nightly/${TS}"
WORK=$(mktemp -d /var/tmp/mia-backup.XXXXXX)
trap 'rm -rf "$WORK"' EXIT
umask 077

cd "$SRC"

echo "mia-backup: dumping postgres"
"${DC[@]}" exec -T postgres pg_dump -U mia -d mia -Fc > "$WORK/pg.dump"
# A custom-format dump that pg_restore cannot list is not a backup.
"${DC[@]}" exec -T postgres pg_restore --list < "$WORK/pg.dump" > /dev/null

echo "mia-backup: archiving uploads"
"${DC[@]}" exec -T backend tar czf - -C /app/uploads . > "$WORK/uploads.tgz"
tar tzf "$WORK/uploads.tgz" > /dev/null

( cd "$WORK" && sha256sum pg.dump uploads.tgz > SHA256SUMS )

for f in pg.dump uploads.tgz SHA256SUMS; do
  aws s3 cp "$WORK/$f" "$DEST/$f" --only-show-errors
done

echo "mia-backup: ok ${DEST}/ ($(du -h "$WORK/pg.dump" | cut -f1) db, $(du -h "$WORK/uploads.tgz" | cut -f1) uploads)"

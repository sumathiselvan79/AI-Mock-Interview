# Ops notes: production on AWS (shared briefing for agents and humans)

Read `deploy/aws/README.md` first (resources, redeploy, teardown). This file holds
the operating rules and the tribal knowledge that README doesn't.

## Access
- Shell env for every AWS call: `export PATH="$HOME/.local/bin:$PATH" AWS_PROFILE=varun-kumar AWS_REGION=ap-southeast-2 AWS_PAGER=""`
- Credentials come from `aws login --profile varun-kumar` (valid 12h). If calls fail with expired/missing
  credentials, STOP and report it. Only the human can re-login (browser flow).
- Instance: `i-0d2505b3fcb3daa96` (tag `mia-app`). No SSH. Run commands through SSM:
  `aws ssm send-command --instance-ids <iid> --document-name AWS-RunShellScript --parameters 'commands=["..."]'`
  then `aws ssm get-command-invocation --command-id <cid> --instance-id <iid>`.
- On the instance: source is in `/opt/mia/src`. Compose:
  `docker compose -f deploy/aws/docker-compose.prod.yml --env-file /opt/mia/host.env <cmd>`
  Containers: `aws-backend-1`, `aws-web-1`, `aws-postgres-1`, `aws-redis-1`, `aws-caddy-1`.
- Public URLs: web `https://app.13-54-189-166.sslip.io`, API `https://api.13-54-189-166.sslip.io`.

## Rules (hard)
- Never print, log, or write secret values (`/opt/mia/prod.env`, `/opt/mia/host.env`, local `.env`,
  Secrets Manager `mia/prod-env`). Print key names or SET/empty only.
- Don't change AWS resources (create/delete/modify) or redeploy unless your brief says so.
- Test data in prod: use emails `smoketest+<anything>@example.com` so it can be found and cleaned up.
- Write findings to `deploy/aws/notes/<your-topic>.md`. Cite `file:line`. Mark each claim as
  REPRODUCED (you saw it happen), CODE-READ (from reading code), or SUSPECTED.

## Architecture facts (verified 2026-11-06)
- Account is on the AWS **Free plan** ($100 credit). Only free-tier-eligible EC2 types can launch;
  Fargate/NAT Gateway are not on the supported list. Hence a single m7i-flex.large + Docker Compose.
- Caddy terminates TLS (Let's Encrypt, sslip.io hostnames) and reverse-proxies `app.*` → web:3000,
  `api.*` → backend:4000.
- Backend runs `NODE_ENV=production`. CORS: production allows exactly `FRONTEND_URL`
  (`backend/app/gateway.py`, the CORSMiddleware block). Before 2026-11-06 it allowed no origin at all.
- LLM providers in prod: `LLM_PROVIDER=ollama` (hosted, `https://ollama.com/v1`), question agent = groq,
  resume service = ollama. LangSmith tracing is disabled in production by design.
- Speech: TTS = sherpa-onnx Piper voice from `/app/models`; STT = faster-whisper tiny.en (baked into image).
- The coding sandbox (`backend/app/agents/coding/runner.py`) runs candidate JS with Node INSIDE the
  backend container, which holds the secrets. Known production risk.
- Backend keeps live interview sessions in an in-process dict (`backend/app/http/session_tracker.py`),
  so it must stay a single uvicorn process.
- Local machine: backend `.venv` is a Windows venv (unusable on Linux). Build a Linux venv with `uv`
  in a scratch dir if you need to run backend tests locally.
